=== ZYMARG WC Product Grid ===
Contributors: zymarg
Tags: woocommerce, elementor, product grid, product slider, dokan, astra, quick view, wishlist, trending, algolia, recommendations
Requires at least: 6.2
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 2.17.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Standalone WooCommerce product grid and slider rendering engine. Renders via shortcode, PHP API, or the optional Elementor widgets. Quick View modal, Buy Now flow, wishlist, trending, similar, vendor, Algolia search, per-visitor recommendations, and more.

== Description ==

A rendering engine that displays WooCommerce products as a responsive grid or as a Swiper-powered slider. Since 2.7.0 Elementor is entirely optional: the same engine is reachable through the `[zymarg_products]` shortcode, the `Public_API::render()` PHP API used by standalone plugins and template packs, and - when Elementor happens to be installed - a full set of Elementor widgets with visual styling controls. It ships fourteen product-source modes including a per-visitor "Recommended For You" personalised feed, a catalog-wide "Best-Selling" source, and a Dokan-aware "Current Vendor" source for Single Store templates (with built-in subsets for featured / trending / best-selling within the vendor).

= Features =

* **One widget, two layouts**: ZYMARG Product Grid renders as either a responsive grid or a Swiper-powered slider, controlled by the Layout setting.
* **Fourteen product sources**: All products, Dynamic, Featured, Best-Selling, Trending, Recommended For You (personalised), Similar, More From Seller (Dokan), Current Vendor's Products (Dokan store pages, with All / Featured / Trending / Best-Selling subsets), Recently Viewed, Wishlist, Category (auto-detected), Algolia (search results), Flash Deals (time-limited sales only).
* **Eleven toggleable card elements**: image, discount badge (percent / amount / both), stock badge, wishlist heart, quick view, add-to-cart, title (1-3 line clamp), rating (auto-hides), sold count (auto-hides), bold current price, strikethrough subscript old price.
* **Heading section** above the grid with toggle, alignment, "View All" link.
* **Three responsive breakpoints** with locked icon positioning per spec.
* **Variable product pricing** rule: lowest sale price bold + lowest regular strikethrough, left-aligned.

= Quick View modal =

* Opens on click of the eye icon.
* Auto-detected colour swatches for `color` / `colour` / `pa_color` attribute slugs.
* Other attributes render as rounded dropdowns.
* Add-to-Cart and Buy Now action buttons.
* "View full details" link to the PDP.
* Focus trap, escape-to-close, click-outside-to-close.
* Six-tier responsive sizing from Large Desktop (1600px+) down to Small Mobile (<600px).

= Buy Now flow =

* Snapshots the user's cart, replaces with the chosen product, redirects to checkout.
* On order completion: original cart restored.
* On abandon (15-min token expiry or user navigates away from checkout): cart restored.
* Existing cart never lost.

= Trending engine =

* Action Scheduler-driven engagement pipeline.
* Click / quick-view / wishlist-add / cart-add events buffered + flushed every 5 min.
* Top-200 trending list recomputed every 30 min.
* Cold-start seeding from last 90 days of orders on activation.
* Editor-preview diagnostic buttons (Recompute / Flush / Reset).

= Dokan integration =

* "More From Seller" source with 4-step vendor resolution waterfall.
* Staff module support.
* Per-vendor cache (30 min) with auto-invalidation.
* Hides widget when vendor has no other products.
* Editor-preview diagnostic buttons (Clear cache / Test resolution).
* Vendor profile row on every card with avatar, name, location, and store link.

= Algolia integration =

* Source mode for the search-results page.
* Click-position tracking via Algolia analytics IDs (`data-algolia-query-id` / `data-algolia-position`).
* Click events routed through the plugin's own `track_click` AJAX endpoint.

= Wishlist =

* Logged-in: synced via user meta across devices.
* Guest: cookie + WC session, survives session expiry.
* Login merge: guest cookie unioned into user meta on login.
* Cache-safe heart hydration on every page load.

= Recently Viewed =

* Tracks every product page view automatically.
* Logged-in: user meta. Guest: cookie + WC session.

= Security =

* All AJAX endpoints nonce-protected.
* Per-IP rate limiter with daily-rotating salt.
* Configurable per-action limits.
* All internal SQL uses `$wpdb->prepare()` with placeholders.
* No custom database tables.
* HPOS + Cart/Checkout Blocks compatibility declared.

= Compatibility =

* WordPress 6.2+, PHP 7.4-8.3.
* WooCommerce 7.0+ (HPOS-ready, Blocks-ready).
* Elementor Free 3.18+ - OPTIONAL since 2.7.0. Only required if you want to build with the Elementor widgets; the shortcode and PHP API work without it (no Pro required).
* Astra theme (free + Pro detected).
* Dokan Lite + Pro 3.10+.
* Swiper 11 (since 2.7.0 the bundled local copy is preferred, then any already-registered Elementor Swiper handle, then a jsDelivr CDN fallback). Version 11.2.10 is bundled in `assets/js/` and `assets/css/`, so sliders work with no Elementor and no internet dependency.

= Extensibility =

* Theme template overrides under `theme/zymarg-wcpg/<path>`.
* Filterable product-source registry via `zymarg_wcpg_source_registry` (register custom sources without touching the plugin).
* All AJAX handlers are class-based and replaceable via standard WP filters.

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/` (or upload the zip in WP Admin → Plugins → Add New).
2. Activate "ZYMARG WC Product Grid" from the Plugins screen.
3. Make sure WooCommerce is active. Elementor is optional - install it only if you want the visual widgets.

**Data persistence policy (since 1.4.7)** — `Delete` in WP Admin is **non-destructive by default**. Your customers' wishlists, recently-viewed lists, and trending engagement counters are preserved across uninstall / reinstall / upgrade. To opt in to a full destructive wipe, add `add_filter( 'zymarg_wcpg_wipe_all_data_on_uninstall', '__return_true' );` in your code OR define `ZYMARG_WCPG_WIPE_ON_UNINSTALL` (true) in `wp-config.php` before uninstalling.

1. Upload the `zymarg-wc-product-grid` folder to `/wp-content/plugins/`.
2. Activate the plugin through the Plugins screen.
3. Edit any page with Elementor and look for the **ZYMARG WooCommerce** category in the widgets panel.

== Changelog ==
= 2.17.2 =
* **Change: storefront toasts now use the ZYMARG OS theme's shared toast system.** The plugin previously rendered its own `.zymarg-wcpg__toast` popup, so shoppers could see several visually different toast styles on one store, and none of these notices were visible to the theme's Toast Notification screen — they could not be reviewed or switched off there.
* Every toast (add to cart, wishlist add/remove, rate-limit and generic errors, quick view, wishlist button) is now emitted through `window.ZymargToast` and tagged with the source `zymarg-product-grid`, so it appears in the theme's toast activity log and can be turned on or off from Theme → Toast Notification.
* The `toast( message, type )` signature is unchanged, so all existing call sites in `frontend.js`, `quickview.js` and `wishlist-button.js` (and the public `ZYMARGWCPG.toast` helper) keep working exactly as before.
* New: an optional third argument passes extra theme-toast options through — `title`, `duration`, and `action` — so the localized wishlist URL can finally render a real "View wishlist" button on the wishlist toast.
* **No loss of standalone support:** the original popup implementation is retained as an automatic fallback. If the ZYMARG OS theme is not active, the plugin renders its own toast exactly as before, so it still works on any theme.
* Housekeeping: the readme `Stable tag:` was stuck at 2.17.0 while the plugin header reported 2.17.1; both now track the real version, and the version constant is bumped in step with the header.

= 2.17.0 =
* New: Guide page under ZYMARG -- full manual for sources, shortcodes, slider/marquee, Flash Deals, current vendor subsets, PHP API and hooks.
* New: Live Render Log in Engine Diagnostics -- see which pages render which sources and whether they produced output.
* New: Source Test Bench -- render any source on demand with optional preview.
* New: Issue count badge on the ZYMARG menu for render and query failures.
* Removed: duplicate Product Grid submenu (it rendered the diagnostics page unstyled).


= 2.16.1 =
* Fix: marquee stopped at the end of the track on desktop and would not resume until dragged.
* Fix: added a stall guard and a coast timeout so the drift can never latch off permanently.

= 2.16.0 =
* Marquee rebuilt as a frame-driven drift engine instead of Swiper autoplay.
* Marquee now works together with free scroll.
* Fix: hovering a marquee slider now pauses it on the spot and resumes from the same position.
* Fix: holding a marquee slider on touch pauses in place; releasing resumes it.

= 2.15.0 =
* Added slider marquee mode: `slider_marquee="yes"` for continuous edge-to-edge drift.
* Added `slider_marquee_speed` (500-20000 ms, default 4000) to control drift speed.
* Marquee pauses on hover and while dragging, and resumes on release.
* Marquee honours prefers-reduced-motion.

= 2.14.0 =
* New: `slider_pagination="none"` hides slider pagination directly from the shortcode. Also accepts off, hide, no, false and 0. Overrides the ZYMARG Template Pack progress-bar default with no Template Pack update needed.

= 2.13.1 =
* Fix: Slider loop was still discarded when Smooth free scroll was on. The clone runway added in 2.13.0 exceeded Swiper's slide budget, so Swiper disabled looping itself. Runway is now derived from the budget and re-clamped at runtime.
* Fix: Minimum-slide guard was too strict and blocked valid setups such as 8 products at 5 columns.
* Fix: Restored the 2.12.0 changelog heading, renamed in error by the 2.13.0 release.

= 2.13.0 =
* Changed: Slider loop now works while Smooth free scroll is on -- the two are independent settings again. Free-scroll sliders no longer dead-end on the last card.
* Changed: Edge resistance is dropped for looping sliders; non-looping sliders are unaffected.
* Added: Loop is disabled automatically, with a WP_DEBUG notice, when there are too few products for Swiper to clone.

= 2.12.0 =

Additive API release. No visual changes, no behaviour changes for existing
callers.

* New: `Public_API::query()` returns products for a source without rendering
  markup, for consumer plugins that supply their own layout and cards.
* New: `Public_API::has_source()` reports whether a source key is registered
  and its class actually loadable, so consumers stop keeping their own
  hardcoded source lists.
* New: `Query_Builder::get_registry()` exposes the filtered source registry.
* New: `zymarg_query_failed` action, mirroring `zymarg_render_failed`.

= 2.11.0 =

Correctness and hardening release. No visual changes.

* Fix: Section cache could serve one grid's markup to another. The cache key
  covered the query but not the display settings.
* Fix: Load More returned cards that did not match the first page (twelve
  missing settings; countdown lost its source context in AJAX).
* Fix: Admin debug overlay could be cached and served to logged-out visitors.
* Fix: Per-IP rate limits could be bypassed with a forged X-Forwarded-For
  header. Proxy headers now require opt-in.
* Fix: Add to Cart lock is acquired atomically.
* Fix: Category and search pages no longer leave empty product shells.
* Fix: HIDE_WIDGET decisions are cached.
* Fix: Guest wishlist cookie is capped below the browser limit.
* Fix: Sliders injected after page load now initialise.
* Fix: Sale-window start is filterable on write as well as read.
* Fix: Elementor discount badge / sold-count options no longer self-reset.

= 2.10.3 =

Slider wrappers now expose the active card template as data-card-template, so
card templates can style slider chrome (pagination, arrows) that renders
outside the card itself. No visual change on its own.

= 2.10.2 =
* Fix: Slider still showed one full-width card on first load after 2.10.1. On pages that render the grid from a shortcode, the plugin's stylesheets are printed in the footer rather than the head, so the whole grid painted unstyled before snapping into place. The asset preloader now recognises [zymarg_products] and puts the frontend CSS, slider bundle, Swiper CSS and card template stylesheet in <head>.
* Fix: The slider now also inlines its slide-sizing rules as critical CSS, so the layout is correct at first paint even when the shortcode lives inside a widget, popup, reusable block or template part that the preloader cannot see.

= 2.10.1 =
* Fix: Slider showed a single full-width card until Swiper initialised, then snapped into its column layout. The slider wrapper now emits its resolved column counts and slide spacing as CSS custom properties so slides are sized correctly at first paint. Fixed in the engine, so it applies to every card template.
* Fix: A slider whose JS never initialises (e.g. a page builder preview) now lays out with the correct columns instead of one full-width card.

Entries for 1.6.5 through 2.0.8 were absent from this file — the readme
changelog and `Stable tag` had drifted while `docs/CHANGELOG.md` continued to
be maintained. They are summarised below from those records in 2.1.0. See
`docs/CHANGELOG.md` for the full detail of each release.

= 2.9.0 =
* New: **Flash Deals countdown timer.** Cards whose sale has a scheduled end date can now show a live "Ends in 2d 04h 11m" timer that ticks down in the browser. Enable it under Settings > Countdown Timer, or with show_countdown="yes" in the shortcode.
* Behavior: the default is "Automatic", which shows the timer for the Flash Deals source only and leaves every other source untouched. Set it to "Always" to show timers on any source, or "Never" to switch it off entirely.
* Behavior: the timer self-suppresses. A product with no sale end date simply renders no timer, so turning the countdown on for a Featured or Best Selling grid cannot produce a broken or empty timer.
* New: countdown_position places the timer below the price (default), over the product image as a pill, or between the image and the title.
* Behavior: works on every card template, including the ZYMARG Template Pack card and any card you add later, because the timer renders through the shared card hooks rather than being written into a specific template file.
* Behavior: cache-safe by design. The server only ever prints an absolute sale end timestamp and the digits are drawn in the browser, so a cached grid can never serve a frozen or already-expired countdown.
* Behavior: when a timer reaches zero the card stays exactly where it is and the digits are replaced with "Deal ended", so the grid does not reflow and a slider does not jump under the visitor's cursor.
* Behavior: a badly-set visitor device clock is corrected against the server clock, so a wrong local time does not produce a wrong or pre-expired timer.
* Behavior: one shared one-second ticker drives every timer on the page, it pauses while the browser tab is hidden, and cards arriving via Load More or infinite scroll are picked up automatically.
* New: styling controls for the countdown (text colour, background, ended-state colour, responsive font size) in the Elementor Style tab.

= 2.8.0 =
* New: **Flash Deals source.** A fourteenth product source that shows only genuinely time-limited discounts: the product must be on sale right now AND carry a sale end date that is still in the future. A product discounted with no end date is a permanent price, not a flash deal, and is excluded by design. Use it with source="flash_deals" or by picking "Flash Deals (time-limited sales)" in the Elementor Source dropdown.
* Behavior: variable products are resolved through their variations, because WooCommerce stores sale windows on the variation and never on the parent. The soonest-ending qualifying variation represents the product, so variable products are no longer silently dropped.
* Behavior: default ordering is "ending soonest first" via the new flash_orderby setting, which also offers biggest-discount-first plus the usual price / title / date / popularity / rating / random modes. flash_orderby replaces the main Order by setting for this source only.
* New: flash_min_discount (0-100) hides deals below a minimum discount percentage. Default 0 = show every time-limited sale.
* New: flash_vendor_scope controls Dokan scoping. "auto" (default) is site-wide everywhere but automatically narrows to the vendor whose store page is being viewed; "site" is always site-wide; "vendor" shows the current vendor only and hides the widget away from a store page.
* Behavior: when no flash deal is active the whole widget hides itself rather than rendering an empty row.
* Behavior: the render cache TTL is clamped to the soonest sale end time, so a finished flash deal cannot outlive its own sale window in the page cache.
* New: three wishlist localisation strings the engine was not exposing to JavaScript - removedFromWishlist, viewWishlist, and a top-level wishlistUrl. Template packs and themes that bridge the zymarg_wcpg:wishlist:changed event can now show a translated "Removed from wishlist" message and a "View wishlist" action link. wishlistUrl resolves from the zymarg_wcpg_wishlist_page_id option, then a page with the wishlist slug, and is filterable via zymarg_wcpg_wishlist_url.
* Internal: the Dokan vendor detector moved from Source_Current_Vendor up to Source_Base as a shared protected method, so vendor-aware sources share one resolution path instead of duplicating it. Behaviour is unchanged.
* New filters: zymarg_wcpg_flash_deals_vendor_id, zymarg_wcpg_wishlist_url.

= 2.7.0 =
* Change: **Elementor is no longer required.** It was listed under "Requires Plugins" in the plugin header and enforced as a hard activation blocker, which meant WordPress refused to let you deactivate or delete Elementor while this plugin was active - even though the engine renders perfectly through the shortcode and PHP API. Elementor is now treated as one optional consumer among several.
* Change: The Elementor widget loader is only registered when Elementor is actually active, so no Elementor classes are touched on a site without it.
* Change: The Elementor version check (3.18+) now runs only when Elementor is present, and reports as an optional notice rather than a blocker.
* New: Swiper 11.2.10 is bundled with the plugin (`assets/js/swiper-bundle.min.js`, `assets/css/swiper-bundle.min.css`). Slider layouts no longer depend on Elementor shipping Swiper, and no longer fall through to the jsDelivr CDN on a normal install.
* Change: Swiper resolution order is now local bundle first, then an already-registered Elementor handle, then CDN.
* New: Card icons (add to cart, quick view, wishlist idle/active, slider prev/next arrows) fall back to bundled inline SVGs when Elementor's icon library is unavailable. Previously these were Font Awesome `<i>` tags that rendered as blank squares without Elementor. Filterable via `zymarg_wcpg_inline_svg_icon` and `zymarg_wcpg_icon_svg_map`.
* New: Shortcode parity with the Elementor widget. New slider attributes slider_arrows, slider_pagination, slider_loop, slider_autoplay, slider_autoplay_delay, slider_speed, slider_space_between; new heading attributes heading_subtext and heading_alignment; new pagination attribute load_more_text.
* Behavior: every new attribute is opt-in. Omitting it leaves the value to Config_Defaults and to template-pack overrides, so existing shortcodes render exactly as before.
* Security: the load_more AJAX action is rate limited again (120 requests per minute per visitor). It was removed in 1.5.8 when it was a click-only action; infinite scroll (2.6.0) now fires it from a scroll observer, so a stuck sentinel or a scripted scroll could otherwise issue product queries unthrottled. A real shopper makes at most 5 auto-requests per grid.

= 2.6.1 =
* New: The [zymarg_products] shortcode can now render the heading "View All" link. Previously this was reachable only from the Elementor widget or a direct Public_API::render() config array.
* New shortcode attributes: show_view_all, view_all_text, view_all_url, view_all_auto_vendor, view_all_vendor_product_id.
* Behavior: view_all_url accepts a plain URL string; Config_Normalizer converts it to the { url, is_external, nofollow } array shape the wrapper templates read. Leaving it empty while view_all_auto_vendor="true" lets Public_API resolve the current vendor store URL automatically.
* Behavior: every new attribute is opt-in. Omitting it leaves the value to Config_Defaults, so existing shortcodes render exactly as before.
* Docs: shortcode usage block now documents the View All and infinite-scroll examples.

= 2.6.0 =
* New: Infinite scroll pagination mode for the grid layout. Products load automatically as the visitor scrolls, with a frosted-glass loader pill.
* New: Separate auto-load batch sizes per device (desktop 20, tablet 20, mobile 10), independent of the first-page product count.
* New: Auto-load caps per device (desktop 100, tablet 100, mobile 50). The cap counts auto-loaded products only; once reached the Load more button takes over and automatic loading stops.
* New: Loader pill states, ported from the approved mockup: animated dots while loading, and a confirmation pill when every product has loaded.
* Improvement: Load more requests can now send an explicit offset and batch size, so a batch size that differs from the first-page size never skips or duplicates products.
* Improvement: Infinite scroll degrades gracefully. Without JavaScript or IntersectionObserver support the standard Load more button is used instead.
* Improvement: Device batch sizes and caps are resolved in the browser, so full-page caching cannot serve desktop values to mobile visitors.
* Accessibility: The loader announces politely to screen readers and all loader animation is disabled under prefers-reduced-motion.

= 2.5.0 =
* New: Smooth free scroll for the slider layout on BOTH templates (classic + ZYMARG). The slider now glides continuously with momentum instead of snapping one product at a time. Enabled by default.
* New: Mouse wheel / trackpad horizontal scrolling for the slider, releasing to normal page scroll at the ends. Enabled by default.
* New: Elementor controls "Smooth free scroll" and "Mouse wheel scroll" (both default On) in the Slider section; new shortcode attributes free_scroll and mousewheel.
* Change: In smooth free-scroll mode looping is disabled (Swiper limitation) — turn off "Smooth free scroll" to use Loop. Step-based autoplay is unchanged.

= 2.4.4 =
* Fix: Slider layout now honors the grid gap. Swiper slide spacing (spaceBetween) inherits the layout gap when no explicit "Slide spacing" is set, so a single gap value drives BOTH grid and slider for every consumer (shortcode, standalone plugins, Elementor). Previously the slider ignored the gap and always used a fixed 20px.
* Change: The Elementor "Slide spacing (px)" control now defaults to empty (= match the grid gap); set a value to override per instance.
* Compatibility: With Template Pack 1.4.3, ZYMARG grids apply an 8px gap on both grid and slider; classic and other templates keep the 6px global default.

= 2.4.3 =
* Change: Default grid gap reduced to 6px (from 14px in 2.4.2; originally a hardcoded 20px). Applies globally to the Elementor widget, the [zymarg_products] shortcode, and standalone plugins via the --grid-gap custom property. Gives a tighter, fuller catalog-style grid. Overridable per instance (Elementor "Grid gap" control or the shortcode gap attribute).
* Compatibility: No breaking changes — only the default value changed; widgets/shortcodes with an explicit gap are untouched. The ZYMARG Template Pack (v1.4.2+) sets its own 8px default for ZYMARG-branded grids; classic and other templates use the 6px engine default.

= 2.4.2 =
* Fix: The grid gap knob was dead. The grid CSS hardcoded `gap: 20px`, so neither the config `layout.gap` value nor any Elementor override actually reached the front end. Gap is now wired end-to-end.
* New: Grid gap is emitted as a `--grid-gap` CSS custom property on the grid wrapper (`grid-wrapper.php`), and the stylesheet uses `gap: var(--grid-gap, …)`. The gap is now consistent across every consumer — Elementor widget, shortcode, and standalone plugins — not just the Elementor widget.
* New: `gap` attribute for the `[zymarg_products]` shortcode (e.g. `gap="12"`), clamped to 0–100px. Empty uses the Config_Defaults value.
* Change: Default grid gap set to 14px (down from the previous hardcoded 20px).

= 2.4.1 =
* Fix: Slider progress-bar pagination did not render. The wrapper passed Swiper the pagination type `progress` instead of Swiper 11's required `progressbar`, so no pagination element was created for the ZYMARG slider default. `slider-wrapper.php` now maps to the correct Swiper type.

= 2.4.0 =
* New: Automatic "Current Vendor" resolution. The `vendor` source now auto-detects the vendor from the current context (the product/store being viewed) when no explicit vendor ID is provided; an explicit ID still takes precedence. Usable on Single Product and Single Store templates with no manual configuration.
* New: Slider defaults are now configurable by template packs — pagination type (bullets / progress bar) and navigation arrows on/off — each still overridable per instance in Elementor.
* New: Heading "View All" link support for non-Elementor (shortcode / standalone) consumers.

= 2.3.0 =
* Fix: Card templates now render consistently for non-Elementor consumers. Cards rendered via the `[zymarg_products]` shortcode and the `Public_API` (standalone plugins) previously missed setup performed only by the Elementor widget, so they could render incomplete outside Elementor. The render path was unified so all three consumers produce identical card output.

= 2.2.0 =
* New: **Card template selector in the Elementor widget.** Content → Layout → Card template. Until now the widget had no such control and always rendered the `classic` card regardless of which templates were registered — a card template could only be chosen via the shortcode or PHP, which made the whole template-pack system unreachable for anyone building pages visually. The dropdown is populated from `Template_Manager::get_registered_cards()`, so activating a template plugin makes its template selectable with no change to the widget.
* New: `zymarg_card_template_labels` filter. The registry stores slug => path and carries no display name, so labels are derived from the slug (`my_fancy-card` becomes "My Fancy Card"). A template plugin can supply a proper label instead. The filter can rename an option but cannot add or remove one — the registry stays the source of truth.
* Change: `classic` is always listed first and labelled "Classic (default)"; remaining templates are sorted alphabetically so the dropdown order does not depend on which order plugins happened to load in.
* Compatibility: Existing widgets are unaffected. A widget saved before 2.2.0 has no `card_template` setting, so the control default applies and it continues to render `classic` exactly as before. If a template plugin is later deactivated, `Config_Normalizer` still validates the saved slug against the registry and falls back to `classic`, so no page breaks.
* Docs: Corrected a wrong example in `docs/09-templates.md`. It showed `'config' => [ 'template' => 'fashion' ]`, but the canonical key is `$config['card']['template']` — a top-level `template` inside `config` is silently ignored and the render falls back to `classic`. Anyone following the documentation would have concluded the feature was broken. Both occurrences fixed and the constraint called out explicitly.
* Docs: `docs/02-shortcode.md` did not document the `card_template` attribute at all, despite it shipping in v2.0.7. Added, including the distinction between `template` (a Template Registry appearance preset) and `card_template` (the design of each individual product card) — two similarly named attributes that do different things.
* Docs: Removed the now-obsolete "when the widget exposes a template selector in a future release" note, and added the `card_template` → `card.template` mapping to the Elementor control tables in `ARCHITECTURE.md`.

= 2.1.0 =
* Fix (blocker): Card templates registered by a standalone plugin rendered as **empty cards**. `Template_Manager::register_card()` stores an absolute path, but `Template_Loader` unconditionally prefixed every path with this plugin's own `templates/` directory, producing a nonexistent path. `file_exists()` failed, the loader returned nothing, and `render_card()` returned an empty string for every product — so the grid emitted its wrapper with no cards inside and no warning of any kind. `Template_Loader` now detects absolute paths and loads them directly. This is the second bug to have blocked external template packs; v2.0.8 fixed the missing `zymarg_wcpg_init` hook, and this fixes the path resolution behind it.
* Fix (blocker): Theme overrides now work for externally registered templates. Because an absolute path outside this plugin carries no meaningful override key, `render_card()` supplies one derived from the slug, so themes have one predictable location for core and external templates alike: `theme/zymarg-wcpg/cards/{slug}/product-card.php`.
* Fix (high): A card template's own `style.css` / `script.js` were never enqueued for external templates. `Asset_Manager` read the slug from `$config['template']`, which does not exist in a normalized config (canonical: `$config['card']['template']`), so it always resolved to `classic`; and it only ever searched this plugin's own `templates/cards/{slug}/` directory. Asset lookup now happens relative to the template's own directory, so an external template's assets load from its own plugin folder.
* Fix (high): All four page consumers queried the wrong products. v2.0.3 deliberately removed `query.source` from every built-in template config, making the source the consumer's responsibility, but the consumers were never updated to pass one — so all four silently fell through to the default `all` source. Related Products showed the newest products site-wide instead of similar ones; Dokan store pages showed every vendor's products instead of that vendor's; category archives ignored the category; and search results ignored the search term. Each consumer now declares its source explicitly (`similar`, `current_vendor`, `category`, `algolia`).
* Fix (medium): Render cache keys collided. `build_key()` read `$config['template']` and `$config['query']['total_products']`, neither of which exists in a normalized config, so both silently fell back to their defaults. Two renders differing only by card template, or only by product limit, produced an identical cache key and served each other's HTML for the life of the entry (default 300s). Both now read the canonical `card.template` and `query.limit` keys.
* Fix (low): The `ZYMARG_DEBUG` overlay reported the card template from the same nonexistent key, so it always displayed `classic` regardless of the template actually rendering — the one tool for diagnosing template problems was misreporting them.
* Fix (low): The `zymarg_products` and `zymarg_render_config` filters both received an empty array as their `$context` argument despite documenting it as the resolved context. Context-aware extensions were impossible to write. Both now receive the real context. `Config_Normalizer::normalize()` gains an optional third `$context` parameter; existing callers are unaffected.
* New: `zymarg_render_failed` action, fired when a render throws. `Public_API::render()` still fails soft and returns an empty string, but the throwable is no longer discarded silently — it is logged under `WP_DEBUG` and exposed to monitoring extensions. Previously any pipeline failure was indistinguishable from "no products found".
* New: `Template_Manager::get_card_assets( $slug )` returns the path, public URL and cache-busting version for a template's companion CSS/JS. Template_Manager remains the only class that knows where files live; Asset_Manager only decides how to enqueue. External assets are versioned by file modification time, since template plugins version independently of this engine.
* New: Templates that cannot be located now log a diagnostic under `WP_DEBUG` instead of failing silently.
* Docs: `Stable tag` corrected from 1.6.4 to 2.1.0, and the 1.6.5–2.0.8 changelog gap backfilled from `docs/CHANGELOG.md`.
* Docs: `ARCHITECTURE.md` corrected. The per-template asset section described intended rather than actual behaviour; the Slot → Template map's "Default source" column documented behaviour removed in v2.0.3. Added a Template Path Contract section and a Known Gaps section recording that layout templates are still hardcoded (no `register_layout()` yet), that the Context Engine is not implemented and six source classes still read global WordPress state directly, and that native search has no source so search falls back unfiltered when Algolia is not configured.

= 2.0.8 =
* Fix: `zymarg_wcpg_init` was never fired. Template packs hooked it to register card templates, but `Plugin::init()` only fired `zymarg_wcpg_loaded`, so registration never ran and the engine always fell back to `classic`. Both hooks now fire in sequence.
* Docs: ARCHITECTURE.md updated — Milestone 7 (Template Registry API) marked complete, Milestone 10 (Independent Template Plugins) marked architecture-proven.

= 2.0.7 =
* New: `card_template` shortcode attribute. `[zymarg_products card_template="zymarg"]` passes the slug into `config['card']['template']`, validated by `Config_Normalizer` against `Template_Manager::is_registered_card()` with a `classic` fallback.

= 2.0.6 =
* New: `card.template` config key in `Config_Defaults` — the canonical location for the card template slug. This was the final piece connecting `register_card()` to the renderer.
* New: `Template_Manager::is_registered_card( $slug )`, used by `Config_Normalizer` to validate a slug without inspecting the registry directly.
* Change: `grid-wrapper.php` and `slider-wrapper.php` read the slug from `$config['card']['template']` instead of the top-level `$config['template']`.

= 2.0.5 =
* New: Template registry API — `Template_Manager::register_card()`, `unregister_card()`, and `get_registered_cards()`. Standalone plugins can add card templates without modifying core. Validation rejects bad slugs, empty paths, core overrides and duplicates, emitting `E_USER_WARNING`. First registration wins.
* Change: `CARD_TEMPLATES` reduced to the immutable core seed — core ships exactly one card template, `classic`.
* Removed: `templates/cards/zymarg/` is no longer bundled. The ZYMARG card ships as a standalone template plugin that registers itself.

= 2.0.4 =
* New: ZYMARG card template (`templates/cards/zymarg/`) — branded alternative to classic with 1:1 imagery, corner badges, compact rating/sold row, circular add-to-cart, Dokan vendor row, full dark-mode support, and its own auto-loaded stylesheet. (Extracted to a standalone plugin in 2.0.5.)

= 2.0.3 =
* Change: Built-in templates no longer bind to a source. Templates define appearance; the consumer chooses the source. All five built-in templates now carry only visual/structural config.
* Change: `grid-wrapper.php` emits CSS custom properties for column counts so card stylesheets can respond to config without editing CSS.
* New: Per-card-template CSS/JS auto-loading via `Asset_Manager`.
* New: `docs/09-templates.md`; `docs/07-standalone-plugin-integration.md` revised.

= 2.0.2 =
* Fix: `zymarg_layout_template` filter contract violation — `render_layout()` resolved the path independently, so the filter affected lifecycle hooks but not the file actually loaded. The path is now resolved once and shared.
* Fix: Orphaned docblock artifacts in `Template_Manager`; plugin header `Version:` formatting; stray `.bak` file removed from the package.
* New: `ZYMARG_DEBUG` diagnostic overlay for logged-in administrators showing source, card template, layout, product count, cache status, consumer, slot and resolved template path.

= 2.0.1 =
* New: Milestone 6 — Template Infrastructure. `Template_Manager` becomes the single class that knows template file locations; `Render_Engine` no longer knows filenames. Adds `CARD_TEMPLATES`, `LAYOUT_TEMPLATES`, `resolve_layout_path()`, `render_card()`, and the `zymarg_layout_template` / `zymarg_card_template` filters.
* New: Milestone 5 — `Asset_Manager` service. `Render_Engine::enqueue_assets()` removed.

= 2.0.0 =
* New: Cache Manager — HTML render cache with O(1) version-bump invalidation, `wp_cache_*` primary backend and transient fallback, 300s default TTL filterable via `zymarg_cache_ttl`, and preview/editor/Customizer bypass.
* New: Engine Diagnostics admin page.

= 1.6.5 =
* Change: Milestone 4 — Consumer Migration. All page consumers now call `Public_API::render()`. `Related_Products_Consumer` introduced. Shortcode migrated to the canonical config structure.

= 1.6.4 =
* Architecture: Canonical configuration schema frozen and locked. Introduced two new first-class sections: `heading` (show, text, subtext, tag, alignment, view_all_*) and `pagination` (mode, load_more_text). These join `query`, `layout`, `card`, and `responsive` as the six permanent top-level config sections.
* Change: `pagination_mode` and `load_more_text` moved from `layout` section to the new `pagination` section in `Config_Defaults`. The compatibility shim in `Render_Engine::config_to_settings()` maps `pagination.mode` → `$settings['pagination_mode']` and `pagination.load_more_text` → `$settings['load_more_text']` so all existing templates continue to work without modification.
* New: `heading` section added to `Config_Defaults` with `show => false` as default — the engine is neutral and consumers opt in. Full heading key set: show, text, subtext, tag, alignment, show_view_all, view_all_text, view_all_url, view_all_auto_vendor.
* New: `heading` and `pagination` added to `Config_Normalizer::DEEP_MERGE_KEYS`. Enum validation added for `pagination.mode` (none|load_more), `heading.tag` (h1–h6, div, span), and `heading.alignment` (left|center|right). Responsive inheritance deliberately excludes heading and pagination — only layout and card are inherited across breakpoints.
* New: `Render_Engine::config_to_settings()` shim updated — heading section maps to flat legacy $settings keys (show_heading, heading_text, heading_tag, heading_alignment, view_all_*); pagination section maps to pagination_mode and load_more_text. All existing templates unchanged.
* New: `Public_API::VERSION = '1.0.0'` constant added. Future consumer plugins can use version_compare() to confirm API compatibility before calling render().
* New: `includes/Assets/` directory reserved for Milestone 5 (Asset Manager). `includes/Components/` directory reserved for Milestone 6 (Component Platform). No classes yet — namespaces reserved to avoid future folder restructuring.
* New: `ARCHITECTURE.md` added to plugin root — permanent reference document containing the full architectural plan, purpose statement, progress tracker, canonical config schema, full pipeline diagram, file structure with status markers, milestone roadmap, slot/template map, consumer migration checklist, stable interface list, and 13 locked architectural rules. Version-stamped so status is always traceable to a specific release.
* No changes to any Elementor widget, template, CSS, JavaScript, AJAX handler, Query_Builder, or Template_Loader.

= 1.6.3 =
* Enhancement: Engine Diagnostics page fully redesigned with ZYMARG brand design system — primary purple gradient header (#9500a5 → #bd00d1), 12px card border-radius, purple box-shadows, pill badges, branded table headers, and product name pills using the soft gradient.
* Enhancement: Per-section execution timing added to v4 (Public API), v5 (Render Engine), and v6 (Query Builder) — each section displays its own ⏱ ms measurement independently.
* Enhancement: v7 dashboard rebuilt as a metric card grid — Engine Version, Checks Passed (N/N), Public API timing + byte count, Render Engine timing, Query Builder timing + product count, Templates registered, Slots registered, Page Execution time, Memory Used (with Peak), Bootstrap status.
* Enhancement: Overall status bar added above metric cards — green gradient for pass, red for fail, shows checks passed ratio at a glance.
* No changes to any engine class, template, CSS, JavaScript, AJAX handler, or Elementor widget.

= 1.6.2 =
* New: Top-level ZYMARG admin menu registered at position 3 (below Dashboard). Uses a global constant guard so future ZYMARG plugins never duplicate the menu.
* New: `includes/Admin/class-admin.php` — admin bootstrap, boots all admin submodules, no-op on frontend via `is_admin()` guard.
* New: `includes/Admin/class-engine-diagnostics.php` — permanent Engine Diagnostics page (ZYMARG → Engine Diagnostics) with seven diagnostic versions: v1 page load confirmation, v2 autoloader/class check, v3 bootstrap + registry inspection, v4 Public API smoke test, v5 Render Engine direct test, v6 Query Builder test, v7 full status card dashboard with overall PASS/FAIL result.
* New: `Admin::init()` called from `Plugin::init()` after `Api_Bootstrap::init()`, keeping engine and admin boot paths fully independent.
* No changes to any template, CSS, JavaScript, AJAX handler, Elementor widget, or engine classes.

= 1.6.1 =
* Maintenance: Version constant and plugin header aligned to 1.6.1 following post-release verification pass.
* Fix: Autoloader confirmed resolving all new framework namespaces correctly — `Zymarg\WCPG\Api`, `Zymarg\WCPG\Bootstrap`, `Zymarg\WCPG\Context`, `Zymarg\WCPG\Adapters`, `Zymarg\WCPG\Registry`, `Zymarg\WCPG\Render` — no class-not-found errors on activation.
* Fix: `Api_Bootstrap::is_initialized()` guard in `Public_API::render()` now correctly prevents render calls before the plugin has fully booted, returning an empty string and logging a `_doing_it_wrong()` notice in debug mode instead of throwing a fatal error.
* Fix: `Render_Engine` correctly passes both `$config` and a backward-compatible `$settings` alias to existing templates, so `grid-wrapper.php` and `slider-wrapper.php` render without modification through the new pipeline.
* Fix: `Config_Normalizer` deep-merge confirmed producing a complete config tree (query, layout, card, responsive keys all present) even when the template config is minimal — downstream templates never receive missing keys.
* Verified: Full end-to-end pipeline test passed — autoloader, bootstrap, Public API, Context Resolver, Config Normalizer, Query Adapter, Query Builder, Render Engine, Template Loader, grid wrapper, and product card all confirmed working in sequence.
* Verified: All existing frontend behaviour confirmed unchanged — CSS assets enqueued correctly, wrapper classes preserved (`zymarg-wcpg`, `zymarg-wcpg__grid`, `zymarg-wcpg__card`), grid layout CSS applied, and all JavaScript behaviours (Quick View, Wishlist, Add to Cart, Load More, Slider, hover effects) functioning correctly through the new Render Engine.
* Verified: Existing Elementor widget untouched and rendering identically to pre-1.6.0 — backward compatibility fully preserved.
* No changes to any template, CSS, JavaScript, AJAX handler, or Elementor widget controls.

= 1.6.0 =
* Architecture: Introduced the ZYMARG Product Grid Rendering Framework — a standalone rendering pipeline that operates independently of Elementor, allowing other ZYMARG plugins (Store, Single Product, Category, Search, Homepage, etc.) to render product grids without requiring Elementor to be active.
* New: `Api_Bootstrap` — single orchestrator that boots the framework after all core plugin subsystems have initialised, fires the `zymarg_wcpg_api_loaded` action when the Public API is ready.
* New: `Slot_Registry` — owns the slot → template slug mapping. Five built-in slots: `related-products`, `store-products`, `homepage-featured`, `category-products`, `search-results`. Fully filterable via `zymarg_product_grid_slots`. Slots stored as structured records (template, label, description, enabled) for future admin UI use.
* New: `Template_Registry` — owns the template slug → configuration mapping. Five built-in templates: `related-grid`, `store-grid`, `homepage-grid`, `category-grid`, `search-grid`. Fully filterable via `zymarg_product_grid_templates`. Templates store only what makes them unique; all defaults are supplied by `Config_Defaults`.
* New: `Config_Defaults` — single source of truth for all framework-level defaults (query, layout, card, responsive). Filterable via `zymarg_product_grid_defaults`. Templates and callers only override what differs; one change here propagates to every template automatically.
* New: `Context_Resolver` — converts partial caller context (product_id, vendor_id, category_id, search, products, etc.) into a complete, predictable context array. Derives vendor ID from product via Dokan or post_author fallback. Derives primary category respecting Yoast/RankMath primary category meta. Fully filterable via `zymarg_product_grid_context`. Never reads WordPress globals unless caller passes explicit context.
* New: `Query_Adapter` — stateless translation layer between the canonical query format and the legacy `Query_Builder::get_products()` settings array. `Query_Builder` is completely untouched. Only the adapter knows the legacy key names (`limit` → `total_products`, `sort` → `orderby`, `direction` → `order`). Filterable via `zymarg_product_grid_query_settings`.
* New: `Config_Normalizer` — merges framework defaults → card style defaults (reserved) → template config → caller overrides into one complete, validated, renderer-ready config. Handles responsive inheritance (tablet inherits desktop, mobile inherits tablet) so the Render Engine receives fully resolved breakpoint configs. Validates numeric bounds (columns 1–6, limit 1–100, gap 0–200), enum values (layout type, price position, vendor position, ATC position, etc.), and boolean card flags. Filterable via `zymarg_product_grid_config`.
* New: `Render_Engine` — receives a complete normalized config and a product collection, resolves the template file from the layout type, fires before/after lifecycle hooks (`zymarg_product_grid_before_render`, `zymarg_product_grid_html`, `zymarg_product_grid_after_render`), and returns an HTML string. Passes a backward-compatible `$settings` alias alongside `$config` so existing templates work without modification.
* New: `Public_API` (`Zymarg_Product_Grid::render()`) — stable static facade with a three-mode input priority: explicit config > template slug > slot. Supports automatic querying (API resolves products from context), pre-supplied products (skip Query Engine), and custom query override. Handles `HIDE_WIDGET` sentinel from source classes. Exceptions never escape — production always returns a string. Pipeline hooks at request start and end (`zymarg_product_grid_render_request`, `zymarg_product_grid_render_complete`).
* New: `zymarg_render_grid()` — global convenience function, a pure alias for `Zymarg_Product_Grid::render()` for use in theme templates and shortcodes.
* Architecture: Elementor widget completely untouched. The new pipeline is a parallel path — existing Elementor-driven rendering is unchanged. The Elementor adapter (`Settings_Adapter`) is deferred to a future milestone.
* Architecture: All new classes use a single `Api_Bootstrap::init()` call added to `Plugin::init()` after Elementor registration, before the `zymarg_wcpg_loaded` action fires.
* No changes to any existing template, CSS, JavaScript, AJAX handler, Query_Builder, Template_Loader, or Elementor widget.

= 1.5.22 =
* Feature: **Vendor Category Filter integration** — the Product Grid widget (source: Current Vendor) can now be paired with the ZYMARG Theme Builder Vendor Category Filter widget for AJAX-powered, no-reload category filtering on Single Store pages.
* New control: **Filter Group ID** text field (Content → Layout, visible only when Source = Current Vendor). Set the same ID on this grid AND the Vendor Category Filter widget to pair them. Grids with no Group ID set (or a different ID) are completely unaffected.
* New: `data-filter-group` attribute on the `.zymarg-wcpg` wrapper DOM element, driven by the `filter_group_id` control value.
* New: `filter_group_id` added to the `$payload_keys` array in `templates/grid/grid-wrapper.php` so the Load More AJAX handler receives and preserves the group ID across paginated pages.
* New JS (`assets/js/frontend.js`): `zymarg:vcf:filter` custom event listener. When the Vendor Category Filter widget dispatches the event, the listener finds the paired grid by `data-filter-group`, shows an opacity fade loading state on the grid, fires the existing `load_more` AJAX handler with `page=1` + `current_vendor_category_term_id` injected, then swaps the card HTML and re-hydrates wishlist hearts. Load More button is reset to page 2 and the active term ID is stored on the button so paginated pages stay within the same category.
* New CSS (`assets/css/frontend.css`): `.zymarg-wcpg__grid.is-loading { opacity: 0.4; pointer-events: none; transition: opacity 150ms ease; }` — visual feedback during the AJAX card swap.
* Fix (`includes/Ajax/Handlers/class-handler-load-more.php`): `current_vendor_category_term_id` and `filter_group_id` added to the POST allowlist. A new injection block for `source = current_vendor` reads `$_POST['current_vendor_category_term_id']`, sanitises with `absint()`, and stores as `$settings['_category_term_id']` — the same underscore-prefix convention used by the Category source's `_category_term_id`.
* Fix (`includes/Query/class-source-current-vendor.php`): `_category_term_id` is now read from `$settings` and included in the Vendor_Cache variant key (so filtered results are cached separately from unfiltered). All 4 subset methods (`query_all_newest`, `query_featured`, `query_best_selling`, `query_trending`) accept an `$extra_cat_tax` parameter; when `_category_term_id > 0` a `product_cat IN [term_id]` clause is injected into `$extra_tax` before `run_vendor_query()` is called. The Trending cold-start best-selling fallback also receives the category clause so fallback results are consistently scoped.
* No changes to any other source, any card template, or any other AJAX handler. Zero breaking changes.

= 1.5.21 =
* Fix: Wishlist Button count badge now always anchors to the icon, regardless of layout. Previously the badge was absolutely positioned relative to the entire button container, so on "Icon + Label" or "Label + Icon" layouts it floated above the whole button rather than sitting on the icon specifically. The badge is now rendered inside the icon span (which becomes the positioning context), so it always appears on the icon corner.
* Feature: Wishlist Button layout is now a responsive control. Desktop, tablet, and mobile can each be set to a different layout (Icon only / Icon + Label / Label + Icon / Label only) independently in the Elementor panel. Default for all devices is "Icon only". Responsive layout classes on the wrapper drive CSS-level visibility per device, with matching Elementor editor device-class overrides so the correct layout previews in the editor.

= 1.5.19 =
* Fix: Reverts the broken v1.5.17 variant-visibility CSS change that caused both the desktop and tablet rating-row variants to render simultaneously at 768–1024px tablet width (two rows of rating+sold content appearing on every card). The correct media-query logic is restored: `--variant-desktop` is hidden at ≤1024px and `--variant-tablet` is shown at ≤1024px (hiding again at ≤767px where `--variant-mobile` takes over. The Elementor editor device-class rules from v1.5.18 (`.elementor-device-tablet` / `.elementor-device-mobile` selectors) are retained so the editor preview also shows the correct single variant per device mode.

= 1.5.18 =
* Fix: The Elementor editor's tablet and mobile preview now shows the correct meta-layout variant (Inline, Count first, or Indicator) matching what the user set per device. Previously the editor's responsive preview buttons switch device mode via JavaScript class changes on the canvas wrapper (`.elementor-device-tablet` / `.elementor-device-mobile`) but don't reliably trigger CSS `@media` breakpoints inside the preview frame, so the desktop variant remained visible in tablet/mobile preview even when a different layout was set. Added editor-specific CSS rules targeting Elementor's device classes that mirror the breakpoint logic and show only the correct variant per device in the editor preview.
* No changes to frontend rendering — the live site already shows the correct variant per device via `@media` queries. This is a preview-only fix.

= 1.5.17 =
* Fix: The gap between the 5-star graphic and the "(4.5)" numeric average is now truly 1px. Previous attempts used `gap: 1px` on the flex container, but flex gap is measured from the outer edge of the box, and Unicode star glyphs have an advance-width that slightly exceeds their font-size — causing residual visual space. v1.5.17 sets `gap: 0` on the container and instead uses `margin-right: 1px` on the stars span, which is not affected by glyph advance-width.
* Fix: Rating and sold count row (Inline and Count first layouts) is now visible on tablet AND desktop. Previously the row could disappear on tablet when the template de-duplicated the desktop+tablet variants into a single `--variant-desktop` div — the CSS then hid it unconditionally at ���1024px. The variant visibility rules are rewritten so `--variant-desktop` remains visible from 768px upward (covering both tablet and desktop), and is only hidden at ≤767px (mobile).
* Feature: Rating, divider, and sold count now spread evenly across the full available width of the meta row, on all three layouts (Inline, Count first, Indicator). The meta-end group uses `justify-content: space-between` so the rating element anchors to the left, sold count to the right, and the divider lands naturally in between — no empty space on the right side of the row.

= 1.5.16 =
* Fix: The "More From Seller" and "Current Vendor's Products" sources now render for vendors who are also administrators / the site owner — on both single-product pages and Dokan store pages. Root cause: both sources gated on Dokan's `dokan_enable_selling` / `dokan_publishing` user meta (via `Vendor_Resolver::check_vendor_status()`, and additionally via `user_can_sell()` during store-page detection). Administrators receive their selling rights from their role/capability, not from those meta flags, so the gates failed and the widget hid itself — even though Dokan rendered the store and product pages and the Theme Builder Store Hero / Seller Card widgets rendered the same vendor correctly.
* Change: Both sources now trust Dokan as the single source of truth, exactly like the Theme Builder vendor widgets: they resolve the vendor id and then render whenever `dokan_get_vendor()` returns a valid vendor object. No `dokan_enable_selling` / `dokan_publishing` gating.
* Change: `Source_Current_Vendor` vendor detection was rewritten to mirror Theme Builder's `zymarg_tb_resolve_current_vendor()` — `author` query var first, then Dokan's `dokan_is_store_page()` + queried user, then the `author_name` slug — with the `user_can_sell()` gate removed (and that now-unused private method deleted).
* Compatibility: `Vendor_Resolver::check_vendor_status()` remains available as a public method for backward compatibility; it is simply no longer called by these two sources. Normal Vendor-role stores (e.g. srijan) behave exactly as before; this release only unblocks admin/site-owner vendor accounts. Ordering, subsets, staff inclusion, the v1.5.14 dual-signal product query, and the v1.5.15 cache-version key are all unchanged.

= 1.5.15 =
* Fix: The "Current Vendor's Products" source now renders on the store pages of vendors who are also administrators / the site owner. Root cause: the source's internal seller check used a raw `dokan_enable_selling === 'yes'` user-meta test, but Dokan treats administrators as enabled sellers implicitly (by role/capability) and often leaves that meta unset on admin accounts. The widget therefore failed vendor detection and hid itself — even though Dokan rendered the store page and counted the products correctly. It now defers to Dokan's own canonical `dokan_is_seller_enabled()` helper (falling back to the raw meta check only when the helper is unavailable), so our detection agrees with Dokan's.
* Fix: Both vendor sources now include the plugin version in their `Vendor_Cache` variant key, so upgrading the plugin automatically orphans any stale cached result sets from an earlier version. Previously an empty result cached before the v1.5.14 / v1.5.15 fixes could keep a vendor grid hidden for up to the full 30-minute cache TTL after upgrading.
* No changes to ordering, subsets, staff inclusion, the vendor product query, or the vendor-profile row — this release only corrects vendor detection for admin/site-owner accounts and makes the cache upgrade-safe.

= 1.5.14 =
* Fix: The "More From Seller" and "Current Vendor's Products" sources now display products that were created by an admin in wp-admin and then assigned to a vendor via Dokan's "Vendor" metabox. Previously both sources queried products by `post_author` only (`author__in`), which misses admin-assigned products — those keep `post_author` = the admin and store the real vendor in the `_dokan_vendor_id` post meta. For any vendor whose catalog was built that way, the grid returned nothing and hid itself.
* New: `Vendor_Resolver::get_vendor_product_ids( $author_ids, $limit = 500 )` resolves a vendor's products by BOTH ownership signals — `post_author` AND `_dokan_vendor_id` meta — merged and de-duplicated. This is the vendor->products counterpart to the product->vendor fix shipped in v1.5.10 (where `resolve()` learned to read `_dokan_vendor_id`).
* Both vendor sources now drive their ordered query with `post__in` built from that helper instead of `author__in`. All existing ordering and subset behaviour (rating / sales / price / random / newest / featured / trending / best-selling, staff-module inclusion, stock filter, catalog-visibility) is preserved unchanged — only the set of products considered "this vendor's" is corrected.
* No changes to vendor status gating (`check_vendor_status()` / `user_can_sell()` remain intact) — the vendor is correctly Enabled in Dokan, so those gates were never the cause; the bug was purely in how the product query selected products.

= 1.5.13 =
* Fix: The 1px gap between the 5-star graphic and the "(5.0)" numeric average is now truly enforced. Added `overflow: hidden` to `.zymarg-wcpg__rating-stars` to clip trailing Unicode glyph advance width that was creating visual padding beyond the container's computed width -- the parent's `gap: 1px` is now the ONLY space between stars and count.
* Fix: Sold count no longer disappears on narrow cards. v1.5.12's approach made the rating element unshrinkable which pushed the sold count off-screen. v1.5.13 makes the rating element shrinkable (`flex-shrink: 1` on `.zymarg-wcpg__rating`) and adds `min-width: 30px` to `.zymarg-wcpg__sold` so it always remains visible (truncated with "..." at worst, but never gone). Changed `justify-content` from `space-between` to `flex-start` so items pack tightly without wasting distributed gap space.
* No changes to stock badge -- stays exactly where it is, unshrinkable.

= 1.5.12 =
* Fix: Rating + sold count row no longer overflows the content box width when a stock badge is also present. The meta-end group (stars + numeric average + divider + sold count) now clips within its parent bounds (`overflow: hidden` on `.zymarg-wcpg__meta-end`) and the sold count text can truncate with ellipsis when space is tight (`flex-shrink: 1` + `text-overflow: ellipsis` on `.zymarg-wcpg__sold`).
* Fix: Tightened the gap between the 5-star graphic and the parenthesized numeric average from 4px to 1px (`.zymarg-wcpg__rating--with-count { gap: 1px }`). The original 4px spacing was contributing to the overflow on narrow cards where both stock badge and rating are visible.
* No changes to the stock badge positioning or sizing — it stays exactly where it is.

= 1.5.11 =
* Fix: Long vendor names no longer push the Add to Cart button (or any other element paired into the vendor row) off-screen. When the vendor row is in `--has-atc` mode, the vendor container now participates in flex shrinking (`flex: 1 1 auto; min-width: 0; overflow: hidden`) so the vendor name ellipsis-truncates with "..." while the ATC button stays fixed in position.
* Feature: "Inline" and "Count first" rating layouts now display the parenthesized numeric average alongside the 5-star graphic - e.g. stars (4.5) | Sold 55. Previously only the "Indicator" layout showed the numeric count. This makes the rating information more readable, especially on mobile where the star graphic alone was too small to interpret quickly.
* Fix: The star-size Style tab control now correctly resizes the 5-star graphic on "Inline" and "Count first" layouts. Previously the base CSS used `!important` overrides (added in v1.4.2 to fight Astra theme leaks) that defeated Elementor's generated inline styles. Replaced with a `--zymarg-star-size` CSS custom property that the Elementor control targets directly - the stars now resize in the editor preview and on the frontend as expected.

= 1.5.10 =
* Fix (finalises v1.5.9): Vendor row was still missing on EVERY product owned by admin / site-owner vendor accounts, even after v1.5.9's `_dokan_vendor_id` addition. v1.5.9's resolver change was correct but incomplete — the strict-equality validation gates further down the render path (`Vendor_Resolver::check_vendor_status()` in `templates/grid/vendor.php`, and `dokan_get_store_info()['store_name']` for the display name) continued to reject the vendor account. This release rewires the render path to trust Dokan's own Vendor object as the single source of truth, matching how the Theme Builder Seller Card and Store Hero widgets have always resolved vendors.
* Refactor: `Vendor_Resolver::resolve()` is now a two-step lookup — `_dokan_vendor_id` post meta first, then `post_author` — with no `dokan_enable_selling` / `dokan_publishing` meta gating. Business rules like "hide suspended vendors" belong at the render layer or, better, at the query layer that produces the grid — enforcing them inside the resolver caused this bug on legitimate vendor accounts whose meta was written in unexpected shapes (e.g. `dokan_enable_selling` stored as `'1'` instead of `'yes'` for admin-promoted vendors, or `dokan_profile_settings` missing the `store_name` key for vendors edited via `Dokan → Vendors → Edit Vendor`).
* Refactor: `templates/grid/vendor.php` now calls `dokan_get_vendor( $vendor_id )` — when the Vendor object is null the row omits itself, when non-null the row renders. No status gating in between. Store name resolves via the new `zymarg_tb_get_vendor_display_name()` helper introduced in Theme Builder 3.19.0 (soft `function_exists()` dependency, with a byte-equivalent local fallback so this plugin still works if Theme Builder is deactivated). Store URL resolves via `$vendor->get_shop_url()` — same pattern the Theme Builder widgets already use.
* Compatibility: `Vendor_Resolver::check_vendor_status()` is intentionally retained as a public method for backward compatibility with any third-party extension or future call site that still wants the strict validator. It's simply no longer called from the grid card template.

= 1.5.9 =
* Fix: Vendor row was missing on any product that had been created by an admin from wp-admin and then assigned to a vendor via Dokan's "Vendor" metabox on the product edit screen. Root cause: `Vendor_Resolver::resolve()` did not check the `_dokan_vendor_id` post meta — which is where Dokan Pro stores admin-assigned vendor ownership independent of `post_author`. For admin-authored products, all three existing resolver steps returned 0 (post_author points to the admin, who is not a Dokan vendor), so `templates/grid/vendor.php` output nothing, `$vendor_has_content` became `false`, and the widget's ATC pairing silently fell back from `with_vendor` to `with_price`. Meanwhile Dokan's own single-product store info box worked correctly because it reads `_dokan_vendor_id` first.
* Fix: Added a Step 0 to `Vendor_Resolver::resolve()` that reads `_dokan_vendor_id` and returns it as the authoritative vendor ID when present, matching Dokan Pro's own resolution order. Existing Steps 1-3 remain as the fallback chain for products where `_dokan_vendor_id` is unset (i.e. vendor-dashboard-created products).
* Fix: `templates/grid/vendor.php` no longer wraps the per-product vendor-id lookup in the shared `Vendor_Cache` layer. The previous code passed `$product_id` where the cache API expected a `$vendor_id`, storing transients under a key namespace (`zymarg_vendor_{PRODUCT_ID}_*`) that the cache-invalidation hooks (`on_user_meta_change`, `on_product_save`) never touched — so a stale `array(0)` could persist for up to 30 minutes with no way to evict it short of a manual TTL wait. `Vendor_Resolver::resolve()` is fast enough on its own (all reads are backed by WP's object cache) that no dedicated transient is warranted at this layer.
* Fix: Version drift — `ZYMARG_WCPG_VERSION` PHP constant had been stuck at `1.5.5` since v1.5.6 despite the plugin header, readme Stable tag, and zip filename all correctly incrementing. Anything that relied on the constant (e.g. the `zymarg_wcpg_version` option written on activation, any migration guards) would report `1.5.5` on a v1.5.8 install. v1.5.9 realigns the constant to match the header.

= 1.5.8 =
* Fix: Back-to-back Add to Cart clicks on different products losing the first item.
* Root cause: two rapid ATC AJAX requests could race — both load the WC session, each modifies their in-memory cart independently, and the LAST save overwrites the earlier one. Customer's cart ends up with only the 2nd product.
* Fix: added a per-user (or per-session for guests) transient mutex in `Handler_Add_To_Cart::handle()`. Concurrent Add to Cart requests from the same customer now queue with a 100ms poll interval (max 3s wait). Requests from OTHER customers are completely unaffected.
* The lock is released via both the fast path (before send_success) and a `register_shutdown_function` safety net so it's ALWAYS released even on fatal errors.
* Also: rate limiting reduced to only the 3 actions that need it — `buy_now` (order creation), `search_cards` (DB-heavy queries), and `track_click` (analytics spam). Removed from `add_to_cart`, `wishlist`, `quick_view`, `hydrate`, `load_more` — these were causing legitimate-user friction with no real threat protection value. Admins can still re-add rate limits via the `zymarg_wcpg_rate_limits` filter.

= 1.5.7 =
* Cross-plugin Buy Now lock: refuse to start if woo-swatches' Buy Now flow is already mid-flight (detected via `wse_bnw_active` session flag). Prevents two simultaneous Buy Now state machines from corrupting each other's cart snapshots.
* No behavioral change when woo-swatches is not active or has no mid-flight session.

= 1.5.6 =
* Safety fix: Rename Buy Now session backup key from `zymarg_cart_backup` to `zymarg_wcpg_buy_now_backup`.
* Prevents a near-collision with ZYMARG Cart plugin's partial-checkout key `_zymarg_cart_backup` (one-character difference). If anyone ever "normalized" either key as a typo fix, both plugins would silently corrupt each other's cart data.
* No behavioral change — Buy Now flow works identically. The key rename is internal; no customer-facing impact.
* Active Buy Now sessions from v1.5.5 will gracefully fail-safe (treated as no active session, original cart preserved).

= 1.5.5 =
* New product source: **Best-Selling products** (catalog-wide).
  Drop the ZYMARG Product Grid widget anywhere and it renders the
  store's best-sellers ordered by WooCommerce's `total_sales` lifetime
  counter (the same field WC Reports and `[products orderby="popularity"]`
  use). All shared widget controls (Show out-of-stock, Include / Exclude
  products and categories) still apply; only the generic Order-by
  control is locked to total_sales DESC for this source.
* New **Subset** control on the **Current Vendor's Products (Dokan
  Store Page)** source. Drop the widget onto a Dokan Single Store
  template and pick which slice of the vendor's catalog to render:
    - **All products** (default) — newest first, full inventory
    - **Featured only** — vendor's WooCommerce-featured products
    - **Trending only** — vendor's products ranked by their OWN 30-day
      engagement score (clicks + quick-views + wishlist adds + cart
      adds, weighted). Per-vendor trending, NOT the catalog-wide
      trending list, so every vendor with engagement always has
      trending products to show.
    - **Best-selling only** — vendor's products ranked by `total_sales` DESC
* Per-vendor Trending cold-start: when a vendor has no engagement data
  yet, the Trending subset falls back to best-selling order; if the
  vendor has no sales either, it falls back to newest-first — so the
  widget always renders something visually consistent rather than
  hiding itself.
* Cache variant now keys on the chosen subset, so different widgets
  showing different subsets of the same vendor never collide on the
  shared `Vendor_Cache` layer.
* `zymarg_wcpg_current_vendor_id` filter (introduced in v1.5.4) keeps
  working unchanged — themes that inject a vendor ID from a custom
  context get the new subset behaviour automatically.
* No template changes. No breaking changes. The default subset is
  "All" which produces identical output to v1.5.4 for any existing
  Current Vendor widgets, so the upgrade is fully transparent.

= 1.5.4 =
* New product source: **Current Vendor's Products (Dokan Store Page)**.
  Drop the ZYMARG Product Grid widget onto a Dokan Single Store template
  (whether via ZYMARG Theme Builder, Elementor Pro Loop templates, or any
  other Theme Builder layer) and the grid auto-scopes to the vendor whose
  store page the visitor is currently viewing — newest products first,
  including the vendor's full inventory (in-stock + out-of-stock), matching
  how Dokan's native store template behaves.
* Auto-detection only by design — there is no manual vendor ID override on
  this source. Editors who want to render a specific vendor's products
  elsewhere (a homepage hero, a marketing landing page, a popup) should
  continue using the existing "More From Seller (Dokan)" source, which
  supports both manual product / vendor selection and the existing 4-step
  resolution waterfall.
* Auto-detection waterfall: (1) `dokan_is_store_page()` + queried `WP_User`,
  (2) the `author` query var validated against `dokan_enable_selling`,
  (3) the `author_name` slug fallback resolved via `get_user_by()`. Only
  Dokan-enabled vendors pass — regular WordPress author archives are not
  treated as stores.
* Honours the Dokan **Staff module** via a per-widget toggle ("Include
  staff products", default on) — matches the inventory the vendor sees on
  their own dashboard. Suspended vendors are hidden cleanly. The widget
  hides itself with no markup on any non-store page, so it is safe to drop
  into global templates.
* Cached per-vendor (30 min) via the existing `Vendor_Cache` layer, with
  the cache variant including the include-staff flag and the requested
  limit so different widget configurations don't collide.
* New extension filter `zymarg_wcpg_current_vendor_id` for themes and
  custom Theme Builder dynamic-content tags that want to inject a vendor
  ID from a non-store context (a vendor-bound popup, a CPT bound to a
  vendor, etc).
* No changes to the existing "More From Seller" source. No template
  changes. No breaking changes. Theme overrides from any earlier version
  continue to work unchanged.

= 1.5.3 =
* Improved: empty-state copy on both the wishlist and recently-viewed
  shortcodes now uses ZYMARG's warmer, more confident brand voice.
  - Wishlist (empty): "Nothing saved yet. Tap the heart on anything you
    love and it'll be waiting for you here — across all your devices."
  - Recently Viewed (empty): "You're new here. The products you look at
    will live in this space ��� across all your devices." (Button changed
    from "Browse products" to "Start exploring".)
* Both messages remain fully overridable per-shortcode via the
  `empty_message` attribute and translatable via the standard text
  domain (`zymarg-wcpg`).

= 1.5.2 =
* Fix: layout shift (FOUC) on the Wishlist page on first load. The card
  stylesheet is now enqueued into <head> as soon as the page is identified
  as containing a Wishlist or Recently Viewed shortcode (or as being a
  WooCommerce My Account page), so cards never paint unstyled. The
  Elementor widget and homepage paths are unchanged.
* New shortcode `[zymarg_wcpg_recently_viewed]` — drops the visitor's
  recently-viewed grid into any page (My Account, a popup, a standalone
  page) using the SAME card template as the homepage / search / wishlist /
  category pages. Reads from the existing Recently_Viewed tracker — no
  duplicate cookies, no new tables. Attributes: `columns` (1–6, default 4),
  `limit` (1–20, default 20), `empty_message`. Filter:
  `zymarg_wcpg_recently_viewed_card_settings`.
* No behaviour changes anywhere else.

= 1.5.1 =
* Fix: `[zymarg_wcpg_wishlist]` now renders cards using THIS plugin's own
  `grid/product-card.php` template (via `\Zymarg\WCPG\Template_Loader`), so
  the wishlist tab in My Account looks **identical** to your Product Grid
  widgets, the homepage, the search results page and Connection Engine
  category pages. Previously the shortcode fell back to WooCommerce's
  default `content-product.php`, which inherited the active theme's plain
  card styling.
* The shortcode also now enqueues the storefront card runtime
  (`zymarg-wcpg-frontend` CSS+JS and `zymarg-wcpg-quickview` CSS+JS) so
  hearts, Quick View and Add-to-Cart all work inside the wishlist grid —
  no more inert cards.
* The Quick View modal shell is auto-mounted in the footer when the
  shortcode is on a page, matching how the search results page handles it.
* New filter `zymarg_wcpg_wishlist_card_settings` (defaults mirror the
  Connection Engine recipe: image, badges, wishlist heart, quick view,
  ATC, title, vendor profile, price below rating, sold count, inline
  meta layout). Override any of these to tweak which card features show
  inside the wishlist grid.

= 1.5.0 =
* New Elementor widget: **ZYMARG Wishlist Button**. A drag-into-the-header
  button that takes customers straight to the My Account → Wishlist tab in
  one tap.
* Fully customisable via Elementor:
  * Icon — Elementor's full library (FontAwesome + custom SVG upload), any
    icon you want, defaults to a heart.
  * Layout — Icon only, Icon + Label, Label + Icon, Label only.
  * Count badge — separate position (top-right / top-left / bottom-right /
    bottom-left / inline), offsets, min size, padding, radius, typography,
    background, text colour, border, optional pulse animation on update.
  * Container — padding, border, radius, hover background, box-shadow,
    transition duration, normal + hover icon/label colours.
  * Link — auto-detects the My Account → Wishlist URL via
    `wc_get_account_endpoint_url( 'wishlist' )`, falls back to
    `/my-account/wishlist/`. Override with a custom URL if you want.
    Open-in-new-tab and rel=nofollow supported.
  * Visibility — hide the widget when the wishlist is empty, hide for
    guests, hide just the badge when empty.
* Live count badge: the badge stays in sync without a page refresh.
  Heart toggles anywhere on the page now broadcast a
  `zymarg_wcpg:wishlist:changed` event with the new count; the button
  listens and bumps the badge with a pop animation. A second event,
  `zymarg_wcpg:wishlist:hydrated`, fires after the cache-safe /hydrate
  call so the badge is accurate even when the page is served from a
  full-page cache.
* hydrate JS no longer short-circuits on pages that have a Wishlist Button
  but no heart icons — it now runs whenever EITHER is present.
* Asset handle: `zymarg-wcpg-wishlist-button` (CSS + deferred JS, only
  enqueued when the widget is rendered).

= 1.4.7 =
* New: data-persistence policy. `uninstall.php` is now **non-destructive by
  default** — deleting the plugin in WP Admin no longer wipes wishlists,
  recently-viewed lists, trending engagement counters, or any other user
  data. Only short-lived rate-limit transients are cleared (they're pure
  infrastructure). You can freely Delete / Reinstall / Upgrade the plugin
  and your customers' saved items stay put.
* Opt-in destructive cleanup (legacy ≤1.4.5 behaviour) is still available:
  either add the filter
  `add_filter( 'zymarg_wcpg_wipe_all_data_on_uninstall', '__return_true' );`
  or define the constant `ZYMARG_WCPG_WIPE_ON_UNINSTALL` (true) in
  `wp-config.php` before uninstalling.

= 1.4.6 =
* New: `[zymarg_wcpg_wishlist]` shortcode — renders the current visitor's
  wishlist as a server-side product grid that works on any page and any
  theme without Elementor. Designed primarily to drop into the My Account
  → Wishlist tab so users can find their saved items whenever they want.
  Attributes: `columns="3"` (1-6, defaults to 3), `empty_message="..."`.
  Resolves each saved ID directly via `wc_get_product()` (bypasses
  WP_Query filters — multilingual, vendor-scope, B2B catalog visibility —
  that could silently drop wishlist items), self-heals stale IDs (deleted
  or unpublished products are pruned automatically), shows a friendly
  empty state with a Shop link when the list is empty, and renders cards
  through WooCommerce's own `content-product.php` template so they inherit
  the active theme's styling.
* Packaging: the inner folder slug is now stable (`zymarg-wc-product-grid/`)
  — earlier versions baked the version into the folder name, which caused
  WordPress to treat each upload as a new plugin and refuse to activate it
  alongside the previous version ("Cannot redeclare function" fatal).
  Migrating from a `ZYMARG WC Product Grid v1.4.x/` folder: Plugins →
  Deactivate the old version → Delete → upload v1.4.6 → Activate.
* Hardening: `zymarg_wcpg_admin_notice()` is now wrapped in a
  `function_exists` guard so a stale copy of the plugin in a different
  folder can never trigger an activation fatal again.

= 1.4.5 =
* Fix (Quick View - Buy Now button): the v1.4.4 two-shade-purple approach (Add to cart `#9500a5` + Buy now `#bd00d1`) was too subtle - on a live site the two buttons looked almost identical. v1.4.5 restyles **Buy Now as an outlined / ghost button** so the two action buttons are visually distinct at every state.
* New Buy Now styling:
    - **Default**: white background, `#9500a5` (primary purple) text, `1.5px` solid `#9500a5` border
    - **Hover**: filled `#bd00d1` (primary-container, brighter purple) background, white text, matching border. The brighter hover shade is **opposite direction on the purple spectrum** from Add to cart's hover (`#7a0089` darker), so the two buttons never look the same simultaneously.
    - **Disabled**: white background, `#857183` (outline) muted text, `1.5px` solid `#d8bfd3` (outline-variant) border. Stays white per user request - no muted purple fill.
* Add to cart styling is **unchanged** from v1.4.4 (solid `#9500a5` default, `#7a0089` hover, muted lavender disabled).
* Layout-stability fix: Buy Now's padding is reduced by 1.5px on each axis (`14px 16px` -> `12.5px 14.5px`) to compensate for its 1.5px border, so it matches the Add to cart filled button's outer dimensions pixel-for-pixel.
* Transition coverage: `transition` shorthand on `.zymarg-wcpg__qv-btn` now animates `background`, `color`, AND `border-color` (v1.4.4 only animated background) so the ghost-to-filled transformation on Buy Now hover happens smoothly across all three properties.
* No template / structure / HTML / JS changes. CSS-only patch. Same DOM, same data, same accessibility.

= 1.4.4 =
* Feature (Quick View - swatches): variation swatches inside the Quick View modal are now **uniform text-only pill buttons** for every attribute type (color, image, label, button, select). The original auto-detection in `Quick_View_Data` is preserved in case any custom CSS/JS keys off `data-attr-type`, but the visible UI is now consistent regardless of attribute type. Matches the user's single-product-page Woo Swatches plugin visual style.
* Feature (Quick View - swatch states): default state has a thin lavender outline-variant border (`#d8bfd3`), hover tints the background to surface (`#faf8ff`), selected state turns solid ZYMARG primary purple (`#9500a5`) with white text, unavailable state is dimmed + line-through. All states use brand palette tokens, no hardcoded greys.
* Feature (Quick View - quantity stepper): redesigned as a **single rounded container** with `−` on the left, centered number, `+` on the right. 48px tall, brand-aligned `#d8bfd3` border, transparent buttons with `#faf8ff` hover. Full-width within its column. Replaces the previous segmented design where each element had its own pill.
* Feature (Quick View - action buttons): Add to cart and Buy now are now styled in the ZYMARG brand palette and laid out **inline side-by-side** (50/50 split with a 10px gap):
    - **Add to cart**: solid `#9500a5` primary purple background, white text
    - **Buy now**: solid `#bd00d1` primary-container purple (slightly brighter shade for visual differentiation)
    - **Hover states**: Add to cart darkens to `#7a0089`, Buy now darkens to `#a000b8`
    - **Disabled state** (when variation not yet selected on variable products): both buttons go to `#d8bfd3` muted lavender with `#534152` text, matching the disabled look on the single-product page.
* Responsive (Quick View - action buttons): at Small Mobile viewport (<600px, where the modal is full-screen and the right column gets cramped), the two action buttons **auto-stack vertically** while staying full-width. Tablet and Large Mobile keep them inline side-by-side.
* Refactor (Quick View CSS): consolidated the prior 5 swatch-variant style blocks (`--color`, `--image`, `--label`, `--button`, plus the `<select>` styles) into a single unified pill style. Removed `.zymarg-wcpg__qv-swatch-icon` and `.zymarg-wcpg__qv-swatch-letter` rendering from the template; the corresponding CSS keeps them hidden as a safety net for theme overrides still emitting those elements.
* Quick View internal accent: the "View full details" link color updated from generic `#1a73e8` blue to brand `#9500a5` purple to match the rest of the modal.
* Compatibility: 100% backward compatible. Quick View AJAX endpoint, variation matching JS, Add-to-cart flow, Buy-now cart-snapshot state machine, focus trap, escape-to-close, click-outside-to-close, modal sizing across all 6 responsive tiers - **all untouched**. Theme overrides of `swatches.php` from any prior version keep working (won't pick up the unified pill style until re-copied from v1.4.4 - additive only; legacy icon/letter spans hidden via CSS fallback).

= 1.4.3 =
* Fix (mobile divider): the divider between rating and sold count is now visible at every breakpoint. v1.4.2 hid it at <=480px to save 5px of horizontal space, but user feedback confirmed the divider is essential UX (`rating | divider | sold count` is the intended visual). The hide rule has been removed and the divider element returns on mobile in all three layouts (inline, count_first, count_indicator).
* Fix (font-size mismatch): the indicator rating value (`★ 4.5`) and the sold count text are now the **same size** on mobile. Before v1.4.3, the indicator value was 11px (via the count-indicator override) while the sold count was still 13px (no mobile override), making them visually mismatched. Sold count is now explicitly 11px at <=480px to match the indicator value. Desktop and tablet sizes are unchanged (both already 13px there).
* Fix (empty row right side): the meta row at narrow viewports was left-bunched with empty space on the right. Rating + divider + sold-count are now wrapped in a `.zymarg-wcpg__meta-end` flex group with `flex: 1` and `justify-content: space-between`. The stock badge stays anchored at the row's left edge; the rating-sold cluster fills the remaining width with the rating element pushed to the left of the group and the sold count pushed to the right - so the divider lands naturally in the centre. Works uniformly across all three layouts.
* Architecture: the meta-row template now emits a two-tier structure when both a stock badge and rating-or-sold exist: `<.zymarg-wcpg__meta><stock-badge><.zymarg-wcpg__meta-end>rating + divider + sold</></ >`. When stock badge is absent, `.zymarg-wcpg__meta-end` is the only child and still fills the full row width (rating left, sold right). When stock badge is the only thing rendering, no end-group wrapper is emitted (single-element row, left-aligned by default).
* Theme override note: themes that copy `templates/grid/rating-soldcount.php` from v1.4.2 or earlier will keep working but won't get the new distribution behaviour until re-copied from v1.4.3. The wrapper class is purely additive - no signature changes.
* Compatibility: 100% backward compatible. All existing widget settings, theme overrides, AJAX payloads continue to work unchanged. CSS additions only - no removals.

= 1.4.2 =
* Feature: **Rating & sold count Layout is now a responsive control** — pick `Inline` / `Count first` / `Indicator` (★ 4.5) independently per Desktop / Tablet / Mobile under Content → Rating & sold count → Layout. New defaults: Desktop=Inline, Tablet=Inline, **Mobile=Indicator** (so narrow cards automatically swap the 5-star graphic for the compact `★ 4.5` variant).
* Feature: New responsive SWITCHER **Show "Sold" word** under the same section. When off, sold count renders as just the number (e.g. `120` instead of `Sold 120`). Defaults: Desktop=Show, Tablet=Show, **Mobile=Hide**. Saves ~30px of horizontal space on narrow cards. The `+` suffix from the `Sold {n}+` format is preserved (becomes `120+`) so rounded counts still read correctly.
* Fix (rating star width): aggressive size compression on the 5-star graphic. Star font-size 11px → **9px** and `letter-spacing` 1px → **0**, dropping the total 5-star block from ~60.5px to **~45px** (~26% narrower). `!important` flags applied so Astra theme + LiteSpeed cache no longer override the rule (a long-standing reason the v1.3.26 11px change wasn't visible on live sites).
* Fix (375px content row clipping): the v1.3.28 meta row used `overflow: hidden` + `flex-shrink: 1` + `text-overflow: ellipsis` on the sold count to enforce single-line behaviour, but on 2-column 375px viewports the sold count was being clipped to zero width and disappearing entirely after the divider. The clipping logic is replaced with **structural compression**: at viewports ≤480px the stock badge gets tighter padding (4px 10px → 2px 6px), the meta gap drops from 8px to 4px, the divider hides, and the price + vendor row gaps shrink to 4px. Combined with the responsive layout + show-sold-text controls above, all three content rows now fit on a single line at 375px without ellipsis or clipping.
* Architecture: the rating-soldcount template now signature-dedupes the three breakpoint variants. When desktop/tablet/mobile would render identical HTML (the common case for users who haven't customised per-device) a **single** variant is emitted with the `--variant-all` class. When they differ, up to three variants are emitted with `--variant-desktop` / `-tablet` / `-mobile` classes and CSS at Elementor's 1024px / 767px breakpoints shows exactly one at a time. Per-device variation costs no extra HTML on the default path.
* New: Load More AJAX payload now echoes `meta_layout_tablet`, `meta_layout_mobile`, `show_sold_text`, `show_sold_text_tablet`, `show_sold_text_mobile` so paginated cards preserve the user's per-breakpoint settings.
* Compatibility: 100% backward compatible. Widgets saved before v1.4.2 that only had `meta_layout` set (non-responsive) auto-inherit that value for tablet + mobile, then the indicator variant kicks in on mobile via the new default. To preserve pre-1.4.2 mobile behaviour exactly, set `Layout (Mobile) = Inline` in the widget. No template signature changes; the `rating-soldcount.php` template still accepts the same input variables. Theme overrides from any prior version continue to work, but won't get the responsive variant feature until re-copied from v1.4.2.

= 1.4.1 =
* Feature: Heading "View All" link now auto-resolves to the vendor's Dokan storefront URL when **Source = More From Seller (Dokan)**. New SWITCHER control **Auto-link to vendor store** under Content → Heading, default ON, visible only when source = vendor AND View All is enabled. When on, the manual View All URL field is hidden (no point showing an input that gets overridden) and the button links to the same vendor that the source itself resolves on the page. Toggle off to fall back to a manual URL.
* Detection logic mirrors `Source_Vendor::detect_vendor_context_product_id()` exactly, so the View All link and the products grid always agree on which vendor they point to. Honours the existing `vendor_auto_detect` + `vendor_product_id` settings.
* Fallback chain (any failure returns settings unchanged - manual URL still works): Dokan inactive → no product context → vendor unresolved → vendor suspended → `dokan_get_store_url()` returns empty. In all those cases the existing "hide link when URL is empty" guard in `grid-wrapper.php` / `slider-wrapper.php` takes over silently.
* Target / nofollow / new-tab settings on the manual URL field are preserved when the auto override fires — only the URL string itself is overridden.
* Resolution happens BEFORE the template loads in `Widget_Product_Grid::render()`, so theme overrides of `templates/grid/grid-wrapper.php` and `templates/slider/slider-wrapper.php` automatically benefit. Both grid and slider layouts work identically.
* New helper: `Vendor_Resolver::get_store_url( $vendor_id )` — wraps Dokan's official `dokan_get_store_url()` with safety checks (Dokan version guard, throwable safety, falsy-return normalisation). Returns absolute URL on success or empty string on failure.
* Compatibility: 100% backward compatible. Existing widgets with manual URLs saved keep their stored value untouched — the override only happens in-memory at render time when the conditions match. Legacy widgets with no `view_all_auto_vendor` setting get the auto behaviour by default (matches the new control's default).

= 1.4.0 =
* Feature: New product source **"Recommended For You"** — per-visitor personalised feed available from the Source dropdown alongside the existing ten modes. Builds a taste profile from the visitor's wishlist, recently-viewed products, purchase history (last 180 days, logged-in users only), and engagement events; scores a bounded candidate pool of up to 200 products across five weighted dimensions (category, purchase, brand, seller, trending); applies a soft 24-hour recency penalty so the feed never re-shows the same item the visitor just looked at; enforces a max-products-per-vendor cap (default 3) so a single Dokan seller never dominates the grid.
* Feature: Scoring weights are fully admin-tunable via five SLIDER controls in **Layout → Recommended For You settings**. Defaults: Category 40, Purchase 30, Brand 15, Seller 10, Trending 5. Weights are normalised at runtime so absolute values don't matter — only the ratio between them does.
* Feature: Brand affinity auto-detects `product_brand` (WooCommerce 9.x+ native), `pwb-brand` (Perfect Brands), or `yith_product_brand` (YITH WooCommerce Brands). When no brand taxonomy is detected the brand-weight slot is redistributed evenly between category and purchase, so the "15%" setting is never silently wasted. Filterable via `zymarg_wcpg_brand_taxonomy`.
* Feature: Seller affinity uses the existing 4-step Vendor_Resolver waterfall. Auto-redistributes to category weight when Dokan is not active.
* Feature: Cold-start strategy control with four options — **hybrid** (default: 50% similar-to-recently-viewed + 30% trending + 20% best-sellers), **trending** (pure trending top-N), **featured** (WooCommerce featured flag), **bestsellers** (lifetime total_sales). Activates automatically when the visitor's profile has fewer than 3 total engagement-weight points (brand-new guest, fresh install).
* Feature: Toggle **Hide already-purchased products** (default on, last-180-day order history). Turn off for replenishment / consumables stores.
* Feature: Final scored ID list cached per-visitor via the new `Affinity_Cache` layer. Logged-in users get a 1h transient keyed by `user_id + settings hash`. Guests get a 15min transient keyed by a hash of their RV/wishlist cookie state. Cache is invalidated atomically on wishlist add/remove (`zymarg_wcpg_wishlist_changed`), cart add (`woocommerce_add_to_cart`), and order completed/processing transitions — via per-user salt rotation in `user_meta` so we never have to scan the transients table.
* Architecture: Three new classes under `includes/Recommendations/` — `Affinity_Profile` (taste-profile builder, normalises category/brand/vendor scores to 0..1, computes 10th/90th-percentile price band), `Affinity_Cache` (transient + salt-rotation layer), `Cold_Start_Fallback` (hybrid/trending/featured/bestsellers strategies). One new source class — `includes/Query/class-source-recommended.php`. All wired into the existing `Query_Builder` registry via the `zymarg_wcpg_source_registry` filter so custom sources can still plug in without code changes.
* Compatibility: 100% backward compatible. The new source is opt-in — existing widgets keep their current source unchanged. All new controls default to safe values. No template changes. Theme overrides of `templates/grid/*.php` from any earlier version continue to work unchanged.

= 1.3.29 =
* Fix (critical): Discount badge was still rendering on a new line below the price on cards where ATC is paired with the vendor or meta row (i.e. not in the price row). Root cause: my v1.3.26 fix used `.zymarg-wcpg__row--price { display: flex; flex-wrap: nowrap; ... }` which is a single-class selector (specificity 0,1,0). The base rule `.zymarg-wcpg__row { display: block; ... }` is defined LATER in the same CSS file with the same specificity (0,1,0), so the cascade picked the later block rule. The v1.3.26 fix appeared to work ONLY when ATC was paired into the price row, because that adds `.zymarg-wcpg__row--has-atc { display: flex }` even later in the file. Cards with ATC paired elsewhere had a block-level price row and the inline discount badge fell to a new line.
* Resolution: rule promoted to compound selector `.zymarg-wcpg__row.zymarg-wcpg__row--price` (specificity 0,2,0), which beats the base block rule unconditionally regardless of file order. Applies to all 3 price-position variants (above title, above rating, below rating) and all ATC-pairing modes.
* No template or PHP changes - CSS specificity fix only. Theme overrides unaffected.

= 1.3.28 =
* Feature (UX): Price row, meta row (rating + sold count) and vendor row are now single-line on every viewport from 375px upward. No more wrapping to a second line on narrow mobile cards - every product card now has exactly 4 predictable rows (title clamped to your line count, plus three single-line rows), so the grid stays visually uniform.
* Technique: `flex-wrap: nowrap` on all 3 rows + `min-width: 0` on flex containers + priority-based ellipsis truncation. Critical elements (prices, discount badge, stock badge, star icon, divider, avatar, ATC button) never shrink. Soft text (sold count, vendor name, vendor location) truncates with ellipsis (`...`) when space is tight.
* Truncation priority order: vendor location -> vendor name -> sold count. Prices and badges never truncate.
* Vendor row UX update: name and location now sit side-by-side on a single line separated by `·` (middle dot), e.g. `Vendor X · Dhaka`. Previously stacked vertically. Separator only appears when location is rendered.
* Removed: `Stacked` option from **Content -> Rating & sold count -> Layout**. Widgets that had stacked saved fall back to `Inline` automatically (graceful migration - no broken cards). If you preferred stacked, the v1.3.27 implementation is preserved in git history.
* Layout options now (3, down from 4): `Inline`, `Count first`, `Indicator`.
* Backwards compatibility: theme overrides of `rating-soldcount.php` from v1.3.27 still work - the layout validator silently coerces unknown values to `inline`. CSS for `.zymarg-wcpg__meta--stacked` kept on disk as a no-op safety net for theme overrides still emitting the class.

= 1.3.27 =
* Refactor: **Style > Content Box Spacing & Widths** section simplified to **Style > Content Box Spacing**. The ten per-element max-width controls added in v1.3.26 have been removed in favour of the four per-row gap controls only. Net result: 14 controls -> 4 controls, all still responsive (separate values per desktop / tablet / mobile).
* Kept controls (still responsive): content rows gap, meta row gap, price row gap, vendor row gap.
* Removed controls: stock badge / rating / divider / sold count max-widths in meta row; price / discount badge / ATC max-widths in price row; vendor name / vendor location max-widths in vendor row; ATC max-width in standalone ATC row.
* Migration: widgets that already had max-width values saved from v1.3.26 will silently ignore those saved values - the controls are gone so they have no effect. No visual regression because the underlying CSS defaults are still in place. If max-width control is needed again in future, restore from v1.3.26 git history.
* Backwards compatibility: every kept control still defaults to unset, so freshly upgraded widgets render identically to v1.3.26.

= 1.3.26 =
* Fix: Discount badge no longer wraps to a new line below the price on narrow mobile screens (e.g. two-column 375px viewports). The price row now uses `display:flex` with `flex-wrap:nowrap` and the price text element gets `min-width:0` so it can shrink/truncate if a card is genuinely too narrow to fit everything. The badge stays inline with the price on desktop, tablet and mobile.
* Improvement: Rating stars reduced from 14px to 11px (height/width scaled to match). Total stars row drops from 80px wide x 16px tall to 60.5px wide x 11px tall — better proportion next to small price/title text on mobile cards.
* Feature: New meta layout option "Indicator — ★ 4.5 | Sold count". Replaces the 5-star graphic with a single star icon and the numeric average rating. Useful for compact cards on mobile where the 5-star graphic competes with price + stock badge for horizontal space. Selectable under **Content → Rating & sold count → Layout**.
* Feature: Typography group control added for the stock badge under **Style → Stock badge**. Font family, size, weight, line-height, letter-spacing and text transform — applied to both in-stock and out-of-stock variants so they stay visually consistent.
* Feature: New **Style → Content Box Spacing & Widths** section. ~14 new responsive controls (separate values per desktop / tablet / mobile) for fine-grained layout control of every content-box row:
  * Content rows — gap between rows.
  * Meta row — gap between elements; max width per element (stock badge, rating, divider, sold count). The sold count and rating widths force ellipsis truncation when the cap is hit.
  * Price row — gap between elements; max width per element (price, discount badge, ATC button).
  * Vendor row — gap between elements; max width per element (vendor name, vendor location). Name and location both truncate with ellipsis when capped.
  * Standalone ATC row — max width for the ATC button.
* Backwards compatibility: every new control defaults to "unset" so a freshly upgraded widget renders identically to v1.3.25. Controls only kick in when the user explicitly sets a value.

= 1.3.25 =
* Feature: Discount badge moved from the image overlay into the price row. Now sits inline next to the price, before the Add-to-Cart button. Applies to all breakpoints (desktop, tablet, mobile).
* Feature: Stock badge ("In stock" / "Out of stock") moved from the image overlay into the meta row. Now sits inline as the leftmost element, before the rating and sold count. Applies to all breakpoints.
* Feature: New Quick View "Display style" control added under Content > Quick view CTA. Two options: "Hover only" (default — icon is hidden until the user hovers the card on a hover-capable device) and "Always visible" (legacy behaviour). Touch devices that report `hover: none` fall back to always-visible regardless of the setting, so the icon is never permanently hidden on phones/tablets that detect as desktop by width.
* Compatibility: Theme overrides that copy `templates/grid/rating-soldcount.php` from earlier versions will continue to work — the new `$stock_badge_html` template variable is optional and defaults to empty. To opt into the new stock-badge-in-meta-row layout, re-copy the template from this version.
* Compatibility: Theme overrides that copy `templates/grid/badges.php` from earlier versions still load without errors. The plugin no longer calls that file from `product-card.php`, but it remains on disk. Themes that rely on the absolutely-positioned image-overlay badges can restore the old layout by editing their copy of `product-card.php` to re-call `badges.php`.
* Internal: AJAX search-page handler defaults to `quickview_display=always` so the search results page UX is unchanged.

= 1.3.24 =
* Maintenance: Fixed Composer PSR-4 prefix in `composer.json` (was `Aspeyash\WCPG\`, now correctly `Zymarg\WCPG\` to match every `namespace` declaration). Prevents an autoload break the day anyone runs `composer install` or `composer dump-autoload`.
* Docs: `readme.txt` refreshed to match the current codebase. Updated plugin name, contributor handle, Stable tag (was 1.3.19), Tested up to (6.6 -> 6.7), and the feature list (now 10 product sources including Algolia and Category; one widget with two layouts, not two widgets).
* Security (hardening): All three remaining direct-SQL queries that used `IN ($ids_in)` string interpolation now use `$wpdb->prepare()` with `%d` placeholders. Affected files: `Trending/class-trending-calculator.php` (publish-date and lifetime-sales lookups), `Query/class-source-trending.php` (re-score date lookup). Values were already int-cast, so this is not a fix for an exploitable vulnerability — it is a defence-in-depth cleanup that also removes the `phpcs:ignore` suppressions.
* Security (hardening): Wishlist cookie reader now caps incoming cookie size at 4 KB before `json_decode()`. Prevents a malicious client from forcing the server to parse an oversized JSON payload. Browsers cap cookies at 4 KB anyway, so legitimate users see no change.
* Tooling: Added `.github/workflows/version-drift-check.yml` GitHub Action. On every push and PR, unzips the plugin and confirms that the plugin header version, the `ZYMARG_WCPG_VERSION` constant, and the readme `Stable tag` all match. Build fails on drift. Prevents the kind of drift the 1.3.19 -> 1.3.23 mismatch caused.

= 1.3.23 =
* See plugin history. (No functional changes carried forward; baseline for the 1.3.24 maintenance pass.)

= 1.3.19 =
* Improvement: Vendor avatar is now fully customizable in Elementor. New controls added to the Vendor Profile section: Avatar size expanded from 16–48px to 12–80px range. Avatar side — choose Left (default) or Right of the vendor name. Avatar shape — Circle (default), Rounded square, or Square. Show border toggle with a color picker. All controls are conditional (only visible when avatar display is enabled) and apply instantly in the Elementor editor preview.

= 1.3.18 =
* Improvement: Quick View modal now uses a full 6-tier responsive sizing spec. Large Desktop (1600px+) 960px/90vh; Desktop (1200-1599px) 900px/90vh; Laptop (992-1199px) 820px/90vh — all two-column 50/50. Tablet (768-991px) 92vw/720px max/92vh two-column 45/55 with tighter padding and smaller typography. Large Mobile (600-767px) 95vw/95vh single column with touch-friendly 44px button targets. Small Mobile (<600px) full-screen 100vw/100vh single column with 48px touch targets. Previously the modal was the same size on all devices above 600px.

= 1.3.17 =
* Fix: Quick View button on the Algolia search results page did nothing when clicked. Root cause: the modal overlay shell (`.zymarg-wcpg__qv-overlay`) is only injected into `wp_footer` when `QuickView_Modal::flag_mount()` is called, which previously only happened inside the Elementor widget renderer. On the standalone search results page no widget renders, so the shell was never printed and `quickview.js` had no DOM element to open. Fix: `flag_mount()` is now called inside `enqueue_search_page_assets()` so the modal shell is always present on search pages.

= 1.3.16 =
* Fix (critical): Add to Cart returning "Something went wrong" on all pages. Root cause: WooCommerce 7.0+ with HPOS does not automatically load the cart/session for AJAX requests. WC()->cart existed as an object but had no session, so add_to_cart() silently returned false triggering the error response. Fix: wc_load_cart() is now called at the top of both Handler_Add_To_Cart and Handler_Buy_Now before any cart operations. This correctly initialises WC()->cart, WC()->customer, and WC()->session for the AJAX context. Wishlist and QuickView were unaffected because they never touch WC()->cart.

= 1.3.15 =
* Fix (critical): is_search_page() was only checking ?s= and ?q= query strings. ZYMARG search uses clean URLs (/search/query) with no query string, so the check always returned false — scripts and nonce were never enqueued on the search page. Quickview and ATC AJAX calls failed because ZYMARGWCPG.nonce was never in the page. Fixed by adding a regex check against REQUEST_URI for the /search/ path prefix.
* Fix: Search page JS was enqueued in wp_footer at priority 1 (after wp_localize_script had already output). Moved both CSS and JS enqueue to wp_enqueue_scripts priority 15 so the inline ZYMARGWCPG localize block is correctly output in <head> before the deferred scripts execute. Nonce is now always present for ATC and quickview on the search page.
* Fix: Split enqueue_search_page_styles() and enqueue_search_page_scripts() methods merged into single enqueue_search_page_assets() hooked at wp_enqueue_scripts priority 15.

= 1.3.14 =
* Fix: Quick view button and Add to Cart now work correctly on the search results page. Root cause: quickview.js had an early-exit guard at line 3 (`if (!ns.ajaxUrl) return`) that caused the entire script to bail out on the search page because ZYMARGWCPG is populated asynchronously there — all 12 event handlers never registered so clicks did nothing. Fix: removed the early-exit guard entirely. All handlers use $(document).on() delegation and are registered immediately at script parse time. ajaxUrl and nonce are now read lazily inside each handler via getNs() at click time, by which point ZYMARGWCPG is always fully populated. frontend.js already had the correct lazy getNs() pattern and required no changes.

= 1.3.13 =
* Fix: Vendor profile now enabled on search results page (show_vendor = yes) to match Elementor widget defaults. Search page should mirror homepage exactly — same features, same design, same behaviour.

= 1.3.12 =
* Fix: Search results page now inherits all card features added since v1.3.5. The AJAX handler (class-handler-search-cards.php) had a hardcoded $settings array missing every key introduced in v1.3.6–v1.3.11: quickview_visibility, show_vendor, vendor_position, vendor_display, vendor_link, vendor_avatar_size, price_position, show_rating, show_sold_count, sold_count_format, meta_layout. All keys are now declared with correct search-page defaults. Quick view is set to "all" devices on the search page (visible on mobile, tablet, and desktop). Vendor profile remains off by default (Dokan dependency — enable by changing show_vendor to "yes" in the handler). The Option B POST override escape hatch is preserved so the search page JS can still pass custom settings without a code change.

= 1.3.11 =
* Fix: Quick view CSS audit — two bugs corrected. (1) Conflict guard was a single @media (max-width:1024px) block covering both tablet and mobile together, meaning "mobile only" mode incorrectly moved the wishlist button on tablet too. Guards are now split into separate tablet and mobile @media blocks so each breakpoint is handled independently. (2) Two separate rules for .zymarg-wcpg__icon-btn--quickview with same specificity (position then display:none) were consolidated into a single rule eliminating the specificity race condition.

= 1.3.10 =
* Fix: Added missing "Below price" option to vendor position control. When price is set to "Above rating", vendor renders between the price block and the rating row. When price is set to "Below rating" (default), vendor renders after the entire bottom row (price + ATC). Total vendor position options now: Below title, Above price, Below price, Above rating & sold count, Below rating & sold count.

= 1.3.9 =
* Feature: Vendor profile position control. New "Position" select under Content > Vendor profile with four options: Below title (default), Above price, Above rating & sold count, Below rating & sold count. The card template now uses four named slots — vendor renders in exactly one slot based on the setting. Fully compatible with the price position setting added in v1.3.7.

= 1.3.8 =
* Feature: Quick View CTA visibility control. New "Visible on" select under Content > Quick View CTA with six options: Desktop only (default), Tablet only, Mobile only, Desktop & Tablet, Tablet & Mobile, All devices. Implemented via data-qv-visibility CSS attribute — no JS, no layout reflow. Conflict guard auto-moves wishlist to bottom-right when quickview is also visible on tablet/mobile so both icons never overlap.

= 1.3.7 =
* Feature (Task 1): Price position control added under Content > Price. Choose "Above rating & sold count" to move the price between the vendor row and the rating row, or keep the default "Below rating & sold count" where price sits in the bottom row alongside the ATC button.
* Feature (Task 2): Rating & Sold Count layout control added under Content > Rating & sold count. Three options: Inline (stars | divider | sold count, default), Stacked (stars on first line, sold count on second line), Count first (sold count | divider | stars).

= 1.3.6 =
* Feature: Vendor profile row on product card. Toggle on/off per widget in Elementor > Content > Vendor profile. Three display styles: Name only, Avatar + Name, Avatar + Name + Location. Optional store link. Avatar size slider (16–48px). Requires Dokan Lite or Pro 3.10+; silently hides when Dokan is absent, vendor unresolvable, or vendor suspended. Uses existing Vendor_Resolver and Vendor_Cache — no extra DB queries per card.

= 1.3.5 =
* Performance: All plugin JS (frontend, quickview, slider) now registered with `strategy=>'defer'` on WordPress 6.3+, falling back to in-footer on 6.2. Defers script execution until after HTML parse — safe because all handlers use $(document).on() delegation.
* Performance: Algolia/WP search page CSS is now enqueued in wp_head (priority 15) instead of wp_footer, eliminating flash of unstyled product cards.
* Performance: Swiper fallback now prefers a local bundle (assets/js/swiper-bundle.min.js) over the jsDelivr CDN, removing an external DNS lookup when Elementor Pro's Swiper is unavailable. CDN remains as last-resort if local file absent.
* Compatibility: WordPress version check for defer strategy is runtime-evaluated — no behaviour change on WP 6.2.

= 1.0.0 =
* Initial public release.
* Phase 1: plugin foundation, autoloader, HPOS + Blocks compatibility, asset registration, Elementor widget category.
* Phase 2: grid widget MVP with all 11 card elements, three responsive breakpoints, Astra-isolated CSS namespace.
* Phase 3A: 5 query sources (Dynamic, Featured, Similar, Recently Viewed, Wishlist) plus storage layer.
* Phase 3B: Trending subsystem (Action Scheduler, engagement store, calculator, seeder) and Dokan-aware More From Seller source. Editor-preview diagnostic buttons replace traditional admin pages.
* Phase 4: AJAX layer (router, rate limiter, 5 user-facing handlers), cache-safe wishlist heart hydration, optimistic UI with rollback, toast notifications, Load More pagination.
* Phase 5: Quick View modal with auto-detected colour swatches and Buy Now flow with 15-min cart-stash + abandon-restore state machine.
* Phase 6: ZYMARG Product Slider layout on Swiper 11 with full responsive controls, autoplay, loop, navigation arrows, multiple pagination styles.
* Phase 7: Server-side wishlist heart state on first render (no FOUC on uncached pages).
* Phase 9: a11y hardening (focus trap, ARIA on modal, keyboard navigation, escape-to-close).
* Phase 10: Polish, readme, version locked to 1.0.0.
