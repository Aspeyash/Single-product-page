/**
 * ZYMARG Single Product — Admin JS v1.0.0
 * JS-powered tab switching (no page reload) · AJAX save · toggle-text reveal
 */
(function ($) {
	'use strict';

	const Admin = window.zymargSPAdmin || {};

	/* ── Tab switching ───────────────────────────────────────────────────── */

	function initTabs() {
		const $nav    = $('.zymarg-sp-admin__tabs-nav');
		const $panels = $('.zymarg-sp-admin__panel');
		const $btns   = $nav.find('.zymarg-sp-admin__tab-btn');

		function activateTab(id) {
			$btns.attr('aria-selected', 'false');
			$panels.removeClass('is-active');
			const $btn   = $nav.find('[data-tab="' + id + '"]');
			const $panel = $('#zymarg-sp-tab-' + id);
			$btn.attr('aria-selected', 'true');
			$panel.addClass('is-active');
			// Persist active tab in sessionStorage so refresh restores it.
			try { sessionStorage.setItem('zymargSPTab', id); } catch (e) {}
		}

		$btns.on('click', function () {
			activateTab($(this).data('tab'));
		});

		// Keyboard nav within tablist.
		$btns.on('keydown', function (e) {
			const $all = $btns.toArray();
			const idx  = $all.indexOf(this);
			if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
				e.preventDefault();
				const next = $all[(idx + 1) % $all.length];
				$(next).focus().trigger('click');
			}
			if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
				e.preventDefault();
				const prev = $all[(idx - 1 + $all.length) % $all.length];
				$(prev).focus().trigger('click');
			}
			if (e.key === 'Home') { e.preventDefault(); $($all[0]).focus().trigger('click'); }
			if (e.key === 'End')  { e.preventDefault(); $($all[$all.length - 1]).focus().trigger('click'); }
		});

		// Restore saved tab or default to first.
		let saved = '';
		try { saved = sessionStorage.getItem('zymargSPTab') || ''; } catch (e) {}
		const firstId = $btns.first().data('tab');
		activateTab(saved && $nav.find('[data-tab="' + saved + '"]').length ? saved : firstId);
	}

	/* ── Toggle-text reveal ──────────────────────────────────────────────── */

	function initToggleTextReveal() {
		// When a toggle that controls a sibling text-row changes, show/hide the row.
		$(document).on('change', '.zymarg-sp-toggle input[type="checkbox"]', function () {
			const key     = $(this).data('key');
			const $parent = $(this).closest('.zymarg-sp-field--toggle-text');
			if (!$parent.length) return;
			const $textRow = $parent.find('[data-controlled-by="' + key + '"]');
			if ($textRow.length) {
				$textRow.toggleClass('is-hidden', !this.checked);
			}
		});
	}

	/* ── Collect settings ────────────────────────────────────────────────── */

	function collectSettings() {
		const settings = {};

		// Text inputs and textareas.
		$('[data-key]').filter('input[type="text"], input[type="number"], textarea').each(function () {
			settings[$(this).data('key')] = $(this).val();
		});

		// Checkboxes — all known toggle keys default to false, then set true if checked.
		$('[data-key]').filter('input[type="checkbox"]').each(function () {
			const key = $(this).data('key');
			settings[key] = this.checked ? 'true' : 'false';
		});

		// Radios — only the checked one.
		$('[data-key]').filter('input[type="radio"]:checked').each(function () {
			settings[$(this).data('key')] = $(this).val();
		});

		return settings;
	}

	/* ── Status bar ──────────────────────────────────────────────────────── */

	function showStatus(msg, isError) {
		const $s = $('#zymarg-sp-status');
		$s.text(msg)
			.removeClass('is-success is-error')
			.addClass(isError ? 'is-error' : 'is-success');
		clearTimeout($s.data('timer'));
		$s.data('timer', setTimeout(function () {
			$s.removeClass('is-success is-error').text('');
		}, 4000));
	}

	/* ── AJAX Save ───────────────────────────────────────────────────────── */

	function initSave() {
		$('#zymarg-sp-save-btn').on('click', function () {
			const $btn = $(this);
			$btn.addClass('is-saving').find('svg').css('animation', 'spin .7s linear infinite');

			const settings = collectSettings();

			$.ajax({
				url:  Admin.ajax_url,
				type: 'POST',
				data: {
					action:   'zymarg_sp_save',
					nonce:    Admin.nonce,
					settings: settings,
				},
				success: function (res) {
					$btn.removeClass('is-saving').find('svg').css('animation', '');
					if (res.success) {
						showStatus(Admin.saved_text || 'Settings saved!', false);
					} else {
						showStatus((res.data && res.data.message) || Admin.error_text || 'Error saving.', true);
					}
				},
				error: function () {
					$btn.removeClass('is-saving').find('svg').css('animation', '');
					showStatus(Admin.error_text || 'Error saving. Please try again.', true);
				},
			});
		});

		// Ctrl/Cmd + S shortcut.
		$(document).on('keydown', function (e) {
			if ((e.ctrlKey || e.metaKey) && e.key === 's') {
				e.preventDefault();
				$('#zymarg-sp-save-btn').trigger('click');
			}
		});
	}

	/* ── Init ────────────────────────────────────────────────────────────── */

	$(function () {
		initTabs();
		initToggleTextReveal();
		initSave();
	});

})(jQuery);
