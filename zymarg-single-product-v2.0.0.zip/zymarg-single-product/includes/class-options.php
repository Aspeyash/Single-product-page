<?php
/**
 * Options — single serialised array storage for all plugin settings.
 *
 * All reads go through Options::get( 'key', $default ).
 * All writes go through Options::set( [ 'key' => value ] ).
 *
 * @version 1.1.2
 * @package ZymargSingleProduct
 */

namespace ZymargSP;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Options {

	const OPTION_KEY = 'zymarg_sp_settings';

	/** @var array|null In-memory cache after first DB read. */
	private static $cache = null;

	// ── Defaults ────────────────────────────────────────────────────────────

	public static function defaults(): array {
		return [

			// ── General ─────────────────────────────────────────────────────
			'template_override_enabled' => true,
			'override_priority'         => 1,

			// Breadcrumbs
			'show_breadcrumbs'          => true,
			'breadcrumb_separator'      => '›',

			// Seller card
			'show_seller_card'          => true,
			'show_visit_store'          => true,
			'show_chat_btn'             => true,
			'chat_url'                  => '',

			// Tabs / accordions
			'show_description_tab'      => true,
			'show_reviews_tab'          => true,
			'description_open_default'  => true,
			'reviews_open_default'      => false,
			'description_label'         => 'Description',
			'reviews_label'             => 'Reviews ({count})',

			// Product grid sections
			'show_seller_products'      => true,
			'show_similar_products'     => true,
			'show_recommended'          => true,
			'seller_products_title'     => 'More from this Seller',
			'similar_products_title'    => 'Similar Products',
			'recommended_title'         => 'Recommended for You',

			// ── Gallery ─────────────────────────────────────────────────────
			'gallery_desktop_layout'    => 'vertical-left',
			'gallery_tablet_layout'     => 'vertical-left',
			'gallery_show_thumbs_desktop' => true,
			'gallery_show_thumbs_tablet'  => true,
			'gallery_show_thumbs_mobile'  => true,
			'gallery_mobile_layout'     => 'carousel',
			'gallery_show_counter'      => true,
			'gallery_counter_format'    => '{current} / {total}',
			'gallery_thumb_size'        => 'medium',
			'gallery_max_thumbs'        => 6,
			'gallery_hover_zoom'        => true,
			'gallery_lightbox'          => true,
			'gallery_lazy_thumbs'       => true,
			'gallery_show_sale_badge'   => true,
			'gallery_sale_badge_text'   => '-{percent}%',
			'gallery_badge_position'    => 'top-left',
			'gallery_show_wishlist'     => true,
			'product_video_enabled'     => true,

			// ── Swatches ────────────────────────────────────────────────────
			'swatch_shape'              => 'rounded',
			'swatch_color_size'         => '44px',
			'swatch_label_padding'      => '8px 14px',
			'swatch_oos_behavior'       => 'blur',
			'swatch_tooltip'            => true,
			'swatch_tooltip_position'   => 'top',
			'swatch_auto_select'        => true,
			'swatch_show_clear'         => true,
			'swatch_clear_label'        => 'Clear',
			'swatch_show_attr_label'    => true,
			'swatch_show_selected_val'  => true,
			'swatch_mobile_position'    => 'current',

			// ── Price ────────────────────────────────────────────────────────
			'price_variable_display'    => 'lowest',
			'price_from_prefix'         => 'From',
			'price_regular_position'    => 'inline',
			'price_old_style'           => 'strikethrough',
			'price_heading_on_sale'     => true,
			'price_heading_sale_text'   => 'Limited Time Offer',
			'price_heading_ending_soon' => true,
			'price_heading_ending_text' => 'Ends in {hours} hours!',
			'price_heading_regular'     => false,
			'price_heading_regular_text'=> 'Price',
			'price_heading_oos'         => true,
			'price_heading_oos_text'    => 'Currently Unavailable',
			'price_show_savings'        => true,
			'price_savings_format'      => 'both',
			'price_savings_prefix'      => 'Save',
			'price_show_free_hint'      => false,
			'price_free_threshold'      => 2000,
			'price_free_hint_text'      => 'Free shipping over {amount}',
			'price_change_animation'    => 'fade',
			'price_loading_skeleton'    => false,

			// ── Add to Cart ──────────────────────────────────────────────────
			'qty_show_stepper'          => true,
			'qty_default'               => 1,
			'qty_min'                   => 1,
			'qty_max'                   => 0,
			'qty_sync_sticky'           => true,
			'atc_btn_text'              => 'Add to Cart',
			'atc_btn_text_loading'      => 'Adding…',
			'atc_btn_text_done'         => 'Added!',
			'atc_show_toast'            => true,
			'atc_toast_text'            => 'Item added to cart',
			'atc_show_view_cart'        => false,
			'buynow_show'               => true,
			'buynow_text'               => 'Buy Now',
			'buynow_position'           => 'below',
			'buynow_session_ttl'        => 15,
			'sticky_bar_enabled'        => true,
			'sticky_bar_content'        => 'qty-atc-buynow',

			// ── Trust & Shipping ─────────────────────────────────────────────
			'show_sold_by'              => true,
			'trust_badge_1_enabled'     => true,
			'trust_badge_1_text'        => 'Free shipping on orders over ৳500',
			'trust_badge_2_enabled'     => true,
			'trust_badge_2_text'        => '30-day hassle-free returns',
			'trust_badge_3_enabled'     => true,
			'trust_badge_3_text'        => '1-year official warranty',
			'trust_badge_4_enabled'     => true,
			'trust_badge_4_text'        => 'Secure checkout — SSL encrypted',
			'trust_badge_5_enabled'     => false,
			'trust_badge_5_text'        => '',
			'show_stock_status'         => true,
			'show_low_stock_warning'    => true,
			'low_stock_threshold'       => 5,
			'show_delivery_info'        => true,
			'delivery_icon'             => '🚚',
			'delivery_window_text'      => 'Delivery in 3–5 business days',
			'ships_from_text'           => 'Ships from seller warehouse',
			'show_shipping_returns'     => true,
			'shipping_text'             => 'Free standard shipping over ৳500. Express available at checkout.',
			'returns_text'              => '30-day free returns. Item must be in original condition.',
			'show_secure_note'          => true,
			'secure_note_text'          => '🔒 100% Secure Payment · Buyer Protection',

			// ── Reviews (legacy — owned by ZYMARG Reviews Engine since v2.0.0) ──
			// These keys are no longer read or rendered by this plugin. They stay in
			// storage only so the engine's one-time migration can still pick up a
			// site's existing preferences. Do not add UI for them here.
			// Display
			'reviews_show_summary'          => true,
			'reviews_show_breakdown_bars'   => true,
			'reviews_show_filters'          => true,
			'reviews_show_verified_badge'   => true,
			'reviews_show_media'            => true,
			'reviews_show_load_more'        => true,
			'reviews_show_bg_gradient'      => true,
			'reviews_enable_schema'         => true,
			// Feed
			'reviews_default_sort'          => 'recent',
			'reviews_per_page'              => 5,
			'reviews_summary_heading'       => 'Customer Reviews',
			'reviews_filter_all_label'      => 'All Reviews',
			'reviews_filter_media_label'    => 'With Photos',
			'reviews_load_more_label'       => 'Load more reviews',
			// Form
			'reviews_form_visibility'       => 'gated',
			'reviews_form_heading'          => 'Write a Review',
			'reviews_form_subheading'       => 'Share your experience with other shoppers',
			'reviews_form_title_placeholder'=> 'Summarize your review',
			'reviews_form_body_placeholder' => 'What did you like or dislike?',
			'reviews_form_submit_label'     => 'Submit Review',
			'reviews_form_success_message'  => 'Thank you for your review!',
			// Submission behavior
			'reviews_allow_media_upload'    => true,
			'reviews_max_media_files'       => 4,
			'reviews_max_media_size_kb'     => 2048,
			'reviews_allow_video_upload'    => true,
			'reviews_max_video_size_kb'     => 20480,
			'reviews_window_days'           => 15,
			'reviews_auto_approve_verified' => false,
			// Report moderation
			'reviews_reports_auto_unapprove' => false,
			'reviews_reports_threshold'      => 3,
			'reviews_reports_notify_email'   => true,
			'reviews_reports_notify_address' => '',
		];
	}

	// ── Public API ───────────────────────────────────────────────────────────

	/**
	 * Get one setting value.
	 *
	 * @param string $key     Setting key.
	 * @param mixed  $default Override default (uses built-in defaults if null).
	 * @return mixed
	 */
	public static function get( string $key, $default = null ) {
		$all      = self::all();
		$defaults = self::defaults();

		if ( array_key_exists( $key, $all ) ) {
			return $all[ $key ];
		}

		if ( null !== $default ) {
			return $default;
		}

		return $defaults[ $key ] ?? null;
	}

	/**
	 * Get all settings (merged with defaults so new keys always exist).
	 *
	 * @return array
	 */
	public static function all(): array {
		if ( null === self::$cache ) {
			$saved       = get_option( self::OPTION_KEY, [] );
			self::$cache = wp_parse_args( is_array( $saved ) ? $saved : [], self::defaults() );
		}
		return self::$cache;
	}

	/**
	 * Merge and save an array of changed settings.
	 *
	 * @param array $data Key→value pairs to update.
	 * @return bool
	 */
	public static function set( array $data ): bool {
		$current     = self::all();
		$updated     = array_merge( $current, $data );
		self::$cache = $updated;
		return update_option( self::OPTION_KEY, $updated );
	}

	/**
	 * Write defaults to DB on first activation (does not overwrite existing).
	 */
	public static function set_defaults(): void {
		if ( false === get_option( self::OPTION_KEY ) ) {
			add_option( self::OPTION_KEY, self::defaults(), '', 'no' );
		}
	}

	/** Bust the in-memory cache (useful after save). */
	public static function flush(): void {
		self::$cache = null;
	}
}
