<?php
/**
 * Admin settings page — 7 JS-powered tabs, no page reload on tab switch.
 * v2.0.0: the Reviews tab only keeps accordion presentation; the engine owns the rest.
 * AJAX save so the page never needs to reload at all.
 *
 * @version 1.1.2
 * @package ZymargSingleProduct
 */

namespace ZymargSP;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Admin {

	/** @var self|null */
	private static $instance = null;

	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	public function init(): void {
		add_action( 'admin_menu',              [ $this, 'register_menu' ] );
		add_action( 'wp_ajax_zymarg_sp_save',  [ $this, 'ajax_save' ] );
	}

	// ── Menu ──────────────────────────────────────────────────────────────────

	public function register_menu(): void {
		add_menu_page(
			__( 'ZYMARG Single Product', 'zymarg-single-product' ),
			__( 'Single Product', 'zymarg-single-product' ),
			'manage_options',
			'zymarg-single-product',
			[ $this, 'render_page' ],
			'dashicons-store',
			58
		);
	}

	// ── AJAX save ─────────────────────────────────────────────────────────────

	public function ajax_save(): void {
		check_ajax_referer( 'zymarg_sp_admin_save', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'zymarg-single-product' ) ] );
		}

		$raw      = $_POST['settings'] ?? [];
		$defaults = Options::defaults();
		$clean    = [];

		$textarea_keys = [ 'shipping_text', 'returns_text' ];
		$email_keys    = [ 'reviews_reports_notify_address' ];

		// v2.0.0 — review settings are owned by the ZYMARG Reviews Engine plugin.
		// They are no longer rendered on this screen, so they are never present in
		// the POST body. Carry the stored values through untouched instead of
		// letting the "missing checkbox means false" rule wipe them, so the engine
		// can still migrate them whenever it is activated.
		$sp_owned_review_keys = [ 'reviews_open_default', 'reviews_label' ];

		foreach ( $defaults as $key => $default ) {
			if ( str_starts_with( $key, 'reviews_' ) && ! in_array( $key, $sp_owned_review_keys, true ) ) {
				$clean[ $key ] = Options::get( $key, $default );
				continue;
			}
			if ( ! array_key_exists( $key, $raw ) ) {
				// Unchecked checkboxes won't be in POST — treat as false.
				$clean[ $key ] = is_bool( $default ) ? false : $default;
				continue;
			}

			$val = $raw[ $key ];

			if ( is_bool( $default ) ) {
				$clean[ $key ] = ( 'true' === $val || '1' === $val || true === $val );
			} elseif ( is_int( $default ) ) {
				$clean[ $key ] = absint( $val );
			} elseif ( is_float( $default ) ) {
				$clean[ $key ] = (float) $val;
			} elseif ( in_array( $key, $textarea_keys, true ) ) {
				$clean[ $key ] = sanitize_textarea_field( wp_unslash( $val ) );
			} elseif ( in_array( $key, $email_keys, true ) ) {
				$clean[ $key ] = sanitize_email( wp_unslash( $val ) );
			} else {
				$clean[ $key ] = sanitize_text_field( wp_unslash( $val ) );
			}
		}

		Options::set( $clean );
		Options::flush();

		wp_send_json_success( [ 'message' => __( 'Settings saved!', 'zymarg-single-product' ) ] );
	}

	// ── Page render ───────────────────────────────────────────────────────────

	public function render_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$opts = Options::all();
		?>
		<div class="wrap zymarg-sp-admin">

			<!-- Header -->
			<div class="zymarg-sp-admin__header">
				<div class="zymarg-sp-admin__header-inner">
					<div class="zymarg-sp-admin__logo">
						<span class="zymarg-sp-admin__logo-icon">🛍</span>
						<div>
							<h1 class="zymarg-sp-admin__title">ZYMARG Single Product</h1>
							<p class="zymarg-sp-admin__version">v<?php echo esc_html( ZYMARG_SP_VERSION ); ?></p>
						</div>
					</div>
					<button type="button" id="zymarg-sp-save-btn" class="zymarg-sp-admin__save-btn">
						<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
							<path d="M17 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V7l-4-4zm-5 16c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3zm3-10H5V5h10v4z"/>
						</svg>
						<?php esc_html_e( 'Save Settings', 'zymarg-single-product' ); ?>
					</button>
				</div>
			</div>

			<!-- Status bar -->
			<div id="zymarg-sp-status" class="zymarg-sp-admin__status" role="status" aria-live="polite"></div>

			<!-- Tab Navigation -->
			<div class="zymarg-sp-admin__tabs-nav" role="tablist" aria-label="<?php esc_attr_e( 'Settings tabs', 'zymarg-single-product' ); ?>">
				<?php
				$tabs = [
					'gallery'     => [ 'icon' => '🖼', 'label' => __( 'Gallery', 'zymarg-single-product' ) ],
					'swatches'    => [ 'icon' => '🎨', 'label' => __( 'Swatches', 'zymarg-single-product' ) ],
					'price'       => [ 'icon' => '💰', 'label' => __( 'Price', 'zymarg-single-product' ) ],
					'addtocart'   => [ 'icon' => '🛒', 'label' => __( 'Add to Cart', 'zymarg-single-product' ) ],
					'trust'       => [ 'icon' => '🛡', 'label' => __( 'Trust & Shipping', 'zymarg-single-product' ) ],
					'reviews'     => [ 'icon' => '⭐', 'label' => __( 'Reviews', 'zymarg-single-product' ) ],
					'general'     => [ 'icon' => '⚙', 'label' => __( 'General', 'zymarg-single-product' ) ],
				];
				foreach ( $tabs as $id => $tab ) :
					?>
					<button type="button"
						class="zymarg-sp-admin__tab-btn"
						role="tab"
						data-tab="<?php echo esc_attr( $id ); ?>"
						aria-controls="zymarg-sp-tab-<?php echo esc_attr( $id ); ?>"
						aria-selected="false"
						id="zymarg-sp-tabnav-<?php echo esc_attr( $id ); ?>">
						<span class="zymarg-sp-admin__tab-icon"><?php echo esc_html( $tab['icon'] ); ?></span>
						<?php echo esc_html( $tab['label'] ); ?>
					</button>
				<?php endforeach; ?>
			</div>

			<!-- Tab Panels -->
			<div class="zymarg-sp-admin__panels">

				<?php $this->render_tab_gallery( $opts ); ?>
				<?php $this->render_tab_swatches( $opts ); ?>
				<?php $this->render_tab_price( $opts ); ?>
				<?php $this->render_tab_addtocart( $opts ); ?>
				<?php $this->render_tab_trust( $opts ); ?>
				<?php $this->render_tab_reviews( $opts ); ?>
				<?php $this->render_tab_general( $opts ); ?>

			</div><!-- /.panels -->

		</div><!-- /.wrap -->
		<?php
	}

	// ── Tab: Gallery ──────────────────────────────────────────────────────────

	private function render_tab_gallery( array $o ): void {
		?>
		<div class="zymarg-sp-admin__panel" id="zymarg-sp-tab-gallery" role="tabpanel" aria-labelledby="zymarg-sp-tabnav-gallery">
			<div class="zymarg-sp-admin__panel-inner">

				<div class="zymarg-sp-admin__section">
					<h2 class="zymarg-sp-admin__section-title"><?php esc_html_e( 'Layout', 'zymarg-single-product' ); ?></h2>
					<?php
					$this->field_radio( 'gallery_desktop_layout', __( 'Desktop layout', 'zymarg-single-product' ), $o, [
						'vertical-left'  => __( 'Vertical Left (thumbs left)', 'zymarg-single-product' ),
						'vertical-right' => __( 'Vertical Right (thumbs right)', 'zymarg-single-product' ),
						'stacked'        => __( 'Stacked (thumbs below)', 'zymarg-single-product' ),
						'grid'           => __( 'Grid', 'zymarg-single-product' ),
					] );
					$this->field_radio( 'gallery_tablet_layout', __( 'Tablet layout', 'zymarg-single-product' ), $o, [
						'vertical-left'  => __( 'Vertical Left (thumbs left)', 'zymarg-single-product' ),
						'vertical-right' => __( 'Vertical Right (thumbs right)', 'zymarg-single-product' ),
						'stacked'        => __( 'Stacked (thumbs below)', 'zymarg-single-product' ),
						'grid'           => __( 'Grid', 'zymarg-single-product' ),
					] );
					$this->field_radio( 'gallery_mobile_layout', __( 'Mobile layout', 'zymarg-single-product' ), $o, [
						'carousel' => __( 'Carousel', 'zymarg-single-product' ),
						'stacked'  => __( 'Stacked', 'zymarg-single-product' ),
						'grid'     => __( 'Grid', 'zymarg-single-product' ),
					] );
					$this->field_toggle( 'gallery_show_thumbs_desktop', __( 'Show thumbnails on desktop', 'zymarg-single-product' ), $o );
					$this->field_toggle( 'gallery_show_thumbs_tablet',  __( 'Show thumbnails on tablet', 'zymarg-single-product' ), $o );
					$this->field_toggle( 'gallery_show_thumbs_mobile',  __( 'Show thumbnails on mobile', 'zymarg-single-product' ), $o );
					$this->field_toggle( 'gallery_show_counter',    __( 'Show image counter overlay', 'zymarg-single-product' ), $o );
					$this->field_text(   'gallery_counter_format',  __( 'Counter format', 'zymarg-single-product' ), $o, __( 'Tokens: {current} {total}', 'zymarg-single-product' ) );
					$this->field_radio( 'gallery_thumb_size', __( 'Thumbnail size', 'zymarg-single-product' ), $o, [
						'small'  => __( 'Small (56px)', 'zymarg-single-product' ),
						'medium' => __( 'Medium (72px)', 'zymarg-single-product' ),
						'large'  => __( 'Large (88px)', 'zymarg-single-product' ),
					] );
					$this->field_number( 'gallery_max_thumbs', __( 'Max visible thumbnails before scroll', 'zymarg-single-product' ), $o, 1, 20 );
					?>
				</div>

				<div class="zymarg-sp-admin__section">
					<h2 class="zymarg-sp-admin__section-title"><?php esc_html_e( 'Interaction', 'zymarg-single-product' ); ?></h2>
					<?php
					$this->field_toggle( 'gallery_hover_zoom',   __( 'Enable hover zoom on desktop', 'zymarg-single-product' ), $o );
					$this->field_toggle( 'gallery_lightbox',     __( 'Enable lightbox on click', 'zymarg-single-product' ), $o );
					$this->field_toggle( 'gallery_lazy_thumbs',  __( 'Lazy load thumbnails', 'zymarg-single-product' ), $o );
					?>
				</div>

				<div class="zymarg-sp-admin__section">
					<h2 class="zymarg-sp-admin__section-title"><?php esc_html_e( 'Sale Badge', 'zymarg-single-product' ); ?></h2>
					<?php
					$this->field_toggle( 'gallery_show_sale_badge', __( 'Show sale badge', 'zymarg-single-product' ), $o );
					$this->field_text(   'gallery_sale_badge_text', __( 'Sale badge text', 'zymarg-single-product' ), $o, __( 'Token: {percent}', 'zymarg-single-product' ) );
					$this->field_radio( 'gallery_badge_position', __( 'Badge position', 'zymarg-single-product' ), $o, [
						'top-left'  => __( 'Top Left', 'zymarg-single-product' ),
						'top-right' => __( 'Top Right', 'zymarg-single-product' ),
					] );
					?>
				</div>

				<div class="zymarg-sp-admin__section">
					<h2 class="zymarg-sp-admin__section-title"><?php esc_html_e( 'Wishlist', 'zymarg-single-product' ); ?></h2>
					<?php $this->field_toggle( 'gallery_show_wishlist', __( 'Show wishlist button', 'zymarg-single-product' ), $o ); ?>
				</div>

				<div class="zymarg-sp-admin__section">
					<h2 class="zymarg-sp-admin__section-title"><?php esc_html_e( 'Product Video', 'zymarg-single-product' ); ?></h2>
					<p class="zymarg-sp-admin__hint"><?php esc_html_e( 'Adds a “Watch video” button to the gallery that opens an overlay player. Set each product’s video URL in the product editor (Product data → General → Product Video URL). Supports YouTube, Vimeo, and direct MP4/WebM/OGG.', 'zymarg-single-product' ); ?></p>
					<?php $this->field_toggle( 'product_video_enabled', __( 'Enable product video in gallery', 'zymarg-single-product' ), $o ); ?>
				</div>

			</div>
		</div>
		<?php
	}

	// ── Tab: Swatches ─────────────────────────────────────────────────────────

	private function render_tab_swatches( array $o ): void {
		?>
		<div class="zymarg-sp-admin__panel" id="zymarg-sp-tab-swatches" role="tabpanel" aria-labelledby="zymarg-sp-tabnav-swatches">
			<div class="zymarg-sp-admin__panel-inner">

				<div class="zymarg-sp-admin__section">
					<h2 class="zymarg-sp-admin__section-title"><?php esc_html_e( 'Native Attribute Swatches', 'zymarg-single-product' ); ?></h2>
					<p class="zymarg-sp-admin__hint">
						<?php esc_html_e( 'Swatch type (Color, Image, Label, Button) is set per attribute under Products → Attributes. Edit an attribute, choose its Type, then open “Configure terms” to set each term’s color or image. The styles below control how those swatches appear on the product page.', 'zymarg-single-product' ); ?>
					</p>
				</div>

				<div class="zymarg-sp-admin__section">
					<h2 class="zymarg-sp-admin__section-title"><?php esc_html_e( 'Shape & Size', 'zymarg-single-product' ); ?></h2>
					<?php
					$this->field_radio( 'swatch_shape', __( 'Swatch shape', 'zymarg-single-product' ), $o, [
						'rounded' => __( 'Rounded', 'zymarg-single-product' ),
						'circle'  => __( 'Circle', 'zymarg-single-product' ),
						'square'  => __( 'Square', 'zymarg-single-product' ),
					] );
					$this->field_radio( 'swatch_color_size', __( 'Color swatch size', 'zymarg-single-product' ), $o, [
						'44px' => '44px',
						'56px' => '56px',
						'64px' => '64px',
					] );
					$this->field_radio( 'swatch_label_padding', __( 'Label swatch padding', 'zymarg-single-product' ), $o, [
						'8px 14px'  => __( 'Compact', 'zymarg-single-product' ),
						'10px 18px' => __( 'Normal', 'zymarg-single-product' ),
						'12px 22px' => __( 'Spacious', 'zymarg-single-product' ),
					] );
					?>
				</div>

				<div class="zymarg-sp-admin__section">
					<h2 class="zymarg-sp-admin__section-title"><?php esc_html_e( 'Out-of-Stock Behavior', 'zymarg-single-product' ); ?></h2>
					<?php
					$this->field_radio( 'swatch_oos_behavior', __( 'Out of stock display', 'zymarg-single-product' ), $o, [
						'blur'      => __( 'Blur', 'zymarg-single-product' ),
						'crossout'  => __( 'Cross out', 'zymarg-single-product' ),
						'hide'      => __( 'Hide', 'zymarg-single-product' ),
					] );
					?>
				</div>

				<div class="zymarg-sp-admin__section">
					<h2 class="zymarg-sp-admin__section-title"><?php esc_html_e( 'Tooltip', 'zymarg-single-product' ); ?></h2>
					<?php
					$this->field_toggle( 'swatch_tooltip', __( 'Show tooltip on hover', 'zymarg-single-product' ), $o );
					$this->field_radio( 'swatch_tooltip_position', __( 'Tooltip position', 'zymarg-single-product' ), $o, [
						'top'    => __( 'Top', 'zymarg-single-product' ),
						'bottom' => __( 'Bottom', 'zymarg-single-product' ),
					] );
					?>
				</div>

				<div class="zymarg-sp-admin__section">
					<h2 class="zymarg-sp-admin__section-title"><?php esc_html_e( 'Selection Behavior', 'zymarg-single-product' ); ?></h2>
					<?php
					$this->field_toggle( 'swatch_auto_select',     __( 'Auto-select default variation', 'zymarg-single-product' ), $o );
					$this->field_toggle( 'swatch_show_clear',       __( 'Show "Clear selection" link', 'zymarg-single-product' ), $o );
					$this->field_text(   'swatch_clear_label',      __( 'Clear link label', 'zymarg-single-product' ), $o );
					$this->field_toggle( 'swatch_show_attr_label',  __( 'Show attribute label above swatches', 'zymarg-single-product' ), $o );
					$this->field_toggle( 'swatch_show_selected_val', __( 'Show selected value next to label', 'zymarg-single-product' ), $o );
					?>
				</div>

				<div class="zymarg-sp-admin__section">
					<h2 class="zymarg-sp-admin__section-title"><?php esc_html_e( 'Mobile Layout', 'zymarg-single-product' ); ?></h2>
					<?php
					$this->field_radio( 'swatch_mobile_position', __( 'Swatch position on mobile', 'zymarg-single-product' ), $o, [
						'current'       => __( 'Current position (in product info)', 'zymarg-single-product' ),
						'after-gallery' => __( 'After gallery (below images, above title)', 'zymarg-single-product' ),
					] );
					?>
				</div>

			</div>
		</div>
		<?php
	}

	// ── Tab: Price ───────────────────────────────────────────────────────────

	private function render_tab_price( array $o ): void {
		?>
		<div class="zymarg-sp-admin__panel" id="zymarg-sp-tab-price" role="tabpanel" aria-labelledby="zymarg-sp-tabnav-price">
			<div class="zymarg-sp-admin__panel-inner">

				<div class="zymarg-sp-admin__section">
					<h2 class="zymarg-sp-admin__section-title"><?php esc_html_e( 'Display', 'zymarg-single-product' ); ?></h2>
					<?php
					$this->field_radio( 'price_variable_display', __( 'Variable product price display', 'zymarg-single-product' ), $o, [
						'lowest' => __( 'Lowest price only', 'zymarg-single-product' ),
						'from'   => __( 'Lowest with "From" prefix', 'zymarg-single-product' ),
						'range'  => __( 'Price range (low – high)', 'zymarg-single-product' ),
					] );
					$this->field_text( 'price_from_prefix', __( '"From" prefix text', 'zymarg-single-product' ), $o );
					$this->field_radio( 'price_regular_position', __( 'Regular price position (on sale)', 'zymarg-single-product' ), $o, [
						'inline' => __( 'Inline subscript', 'zymarg-single-product' ),
						'beside' => __( 'Beside', 'zymarg-single-product' ),
						'below'  => __( 'Below', 'zymarg-single-product' ),
						'hide'   => __( 'Hide', 'zymarg-single-product' ),
					] );
					$this->field_radio( 'price_old_style', __( 'Old price style', 'zymarg-single-product' ), $o, [
						'strikethrough' => __( 'Strikethrough', 'zymarg-single-product' ),
						'underline'     => __( 'Underline', 'zymarg-single-product' ),
					] );
					?>
				</div>

				<div class="zymarg-sp-admin__section">
					<h2 class="zymarg-sp-admin__section-title"><?php esc_html_e( 'Smart Heading', 'zymarg-single-product' ); ?></h2>
					<p class="zymarg-sp-admin__hint"><?php esc_html_e( 'A small label shown above the price that adapts to product state.', 'zymarg-single-product' ); ?></p>
					<?php
					$this->field_toggle_text( 'price_heading_on_sale',     'price_heading_sale_text',    __( 'When on sale', 'zymarg-single-product' ), $o );
					$this->field_toggle_text( 'price_heading_ending_soon', 'price_heading_ending_text',  __( 'Sale ends within 24h', 'zymarg-single-product' ), $o, '{hours}' );
					$this->field_toggle_text( 'price_heading_regular',     'price_heading_regular_text', __( 'Regular price', 'zymarg-single-product' ), $o );
					$this->field_toggle_text( 'price_heading_oos',         'price_heading_oos_text',     __( 'Out of stock', 'zymarg-single-product' ), $o );
					?>
				</div>

				<div class="zymarg-sp-admin__section">
					<h2 class="zymarg-sp-admin__section-title"><?php esc_html_e( 'You-Save Indicator', 'zymarg-single-product' ); ?></h2>
					<?php
					$this->field_toggle( 'price_show_savings', __( 'Show savings badge on sale', 'zymarg-single-product' ), $o );
					$this->field_radio( 'price_savings_format', __( 'Format', 'zymarg-single-product' ), $o, [
						'both'    => __( 'Save {amount} ({percent}%)', 'zymarg-single-product' ),
						'amount'  => __( 'Save {amount}', 'zymarg-single-product' ),
						'percent' => __( 'Save {percent}%', 'zymarg-single-product' ),
					] );
					$this->field_text( 'price_savings_prefix', __( 'Prefix word', 'zymarg-single-product' ), $o );
					?>
				</div>

				<div class="zymarg-sp-admin__section">
					<h2 class="zymarg-sp-admin__section-title"><?php esc_html_e( 'Free Shipping Hint', 'zymarg-single-product' ); ?></h2>
					<?php
					$this->field_toggle( 'price_show_free_hint',  __( 'Show free shipping hint below price', 'zymarg-single-product' ), $o );
					$this->field_number( 'price_free_threshold',  __( 'Threshold amount', 'zymarg-single-product' ), $o, 0, 999999 );
					$this->field_text(   'price_free_hint_text',  __( 'Hint text', 'zymarg-single-product' ), $o, __( 'Token: {amount}', 'zymarg-single-product' ) );
					?>
				</div>

				<div class="zymarg-sp-admin__section">
					<h2 class="zymarg-sp-admin__section-title"><?php esc_html_e( 'Animation & Loading', 'zymarg-single-product' ); ?></h2>
					<?php
					$this->field_radio( 'price_change_animation', __( 'Price change animation (on variation select)', 'zymarg-single-product' ), $o, [
						'fade'  => __( 'Fade in', 'zymarg-single-product' ),
						'slide' => __( 'Slide up + fade', 'zymarg-single-product' ),
						'none'  => __( 'No animation', 'zymarg-single-product' ),
					] );
					$this->field_toggle( 'price_loading_skeleton', __( 'Show shimmer skeleton during variation lookup', 'zymarg-single-product' ), $o );
					?>
				</div>

			</div>
		</div>
		<?php
	}

	// ── Tab: Add to Cart ─────────────────────────────────────────────────────

	private function render_tab_addtocart( array $o ): void {
		?>
		<div class="zymarg-sp-admin__panel" id="zymarg-sp-tab-addtocart" role="tabpanel" aria-labelledby="zymarg-sp-tabnav-addtocart">
			<div class="zymarg-sp-admin__panel-inner">

				<div class="zymarg-sp-admin__section">
					<h2 class="zymarg-sp-admin__section-title"><?php esc_html_e( 'Quantity Stepper', 'zymarg-single-product' ); ?></h2>
					<?php
					$this->field_toggle( 'qty_show_stepper',  __( 'Show quantity stepper', 'zymarg-single-product' ), $o );
					$this->field_number( 'qty_default',       __( 'Default quantity', 'zymarg-single-product' ), $o, 1, 999 );
					$this->field_number( 'qty_min',           __( 'Min quantity', 'zymarg-single-product' ), $o, 1, 999 );
					$this->field_number( 'qty_max',           __( 'Max quantity (0 = no limit)', 'zymarg-single-product' ), $o, 0, 9999 );
					$this->field_toggle( 'qty_sync_sticky',   __( 'Sync sticky bar stepper with main stepper', 'zymarg-single-product' ), $o );
					?>
				</div>

				<div class="zymarg-sp-admin__section">
					<h2 class="zymarg-sp-admin__section-title"><?php esc_html_e( 'Add to Cart Button', 'zymarg-single-product' ); ?></h2>
					<?php
					$this->field_text( 'atc_btn_text',          __( 'Button text', 'zymarg-single-product' ), $o );
					$this->field_text( 'atc_btn_text_loading',  __( 'Text while adding', 'zymarg-single-product' ), $o );
					$this->field_text( 'atc_btn_text_done',     __( 'Text when added', 'zymarg-single-product' ), $o );
					$this->field_toggle( 'atc_show_toast',      __( 'Show added-to-cart toast notification', 'zymarg-single-product' ), $o );
					$this->field_text(   'atc_toast_text',      __( 'Toast message', 'zymarg-single-product' ), $o );
					$this->field_toggle( 'atc_show_view_cart',  __( 'Show "View Cart" link in toast', 'zymarg-single-product' ), $o );
					?>
				</div>

				<div class="zymarg-sp-admin__section">
					<h2 class="zymarg-sp-admin__section-title"><?php esc_html_e( 'Buy Now', 'zymarg-single-product' ); ?></h2>
					<?php
					$this->field_toggle( 'buynow_show',        __( 'Show Buy Now button', 'zymarg-single-product' ), $o );
					$this->field_text(   'buynow_text',        __( 'Button text', 'zymarg-single-product' ), $o );
					$this->field_radio( 'buynow_position', __( 'Position', 'zymarg-single-product' ), $o, [
						'below' => __( 'Below Add to Cart', 'zymarg-single-product' ),
						'above' => __( 'Above Add to Cart', 'zymarg-single-product' ),
					] );
					$this->field_number( 'buynow_session_ttl', __( 'Session TTL (minutes)', 'zymarg-single-product' ), $o, 1, 120 );
					?>
				</div>

				<div class="zymarg-sp-admin__section">
					<h2 class="zymarg-sp-admin__section-title"><?php esc_html_e( 'Mobile Sticky Bar', 'zymarg-single-product' ); ?></h2>
					<?php
					$this->field_toggle( 'sticky_bar_enabled', __( 'Enable sticky bar on mobile', 'zymarg-single-product' ), $o );
					$this->field_radio( 'sticky_bar_content', __( 'Sticky bar content', 'zymarg-single-product' ), $o, [
						'atc-only'       => __( 'Add to Cart only', 'zymarg-single-product' ),
						'atc-buynow'     => __( 'Add to Cart + Buy Now', 'zymarg-single-product' ),
						'qty-atc-buynow' => __( 'Qty + Add to Cart + Buy Now', 'zymarg-single-product' ),
					] );
					?>
				</div>

			</div>
		</div>
		<?php
	}

	// ── Tab: Trust & Shipping ─────────────────────────────────────────────────

	private function render_tab_trust( array $o ): void {
		?>
		<div class="zymarg-sp-admin__panel" id="zymarg-sp-tab-trust" role="tabpanel" aria-labelledby="zymarg-sp-tabnav-trust">
			<div class="zymarg-sp-admin__panel-inner">

				<div class="zymarg-sp-admin__section">
					<h2 class="zymarg-sp-admin__section-title"><?php esc_html_e( 'Trust Badges', 'zymarg-single-product' ); ?></h2>
					<p class="zymarg-sp-admin__hint"><?php esc_html_e( 'Toggle each badge and customise its text.', 'zymarg-single-product' ); ?></p>
					<?php for ( $i = 1; $i <= 5; $i++ ) :
						$this->field_toggle_text(
							"trust_badge_{$i}_enabled",
							"trust_badge_{$i}_text",
							sprintf( __( 'Badge %d', 'zymarg-single-product' ), $i ),
							$o
						);
					endfor; ?>
				</div>

				<div class="zymarg-sp-admin__section">
					<h2 class="zymarg-sp-admin__section-title"><?php esc_html_e( 'Stock Status', 'zymarg-single-product' ); ?></h2>
					<?php
					$this->field_toggle( 'show_stock_status',       __( 'Show stock status', 'zymarg-single-product' ), $o );
					$this->field_toggle( 'show_low_stock_warning',  __( 'Show "Only X left!" low-stock warning', 'zymarg-single-product' ), $o );
					$this->field_number( 'low_stock_threshold',     __( 'Low-stock threshold', 'zymarg-single-product' ), $o, 1, 100 );
					?>
				</div>

				<div class="zymarg-sp-admin__section">
					<h2 class="zymarg-sp-admin__section-title"><?php esc_html_e( 'Delivery Info', 'zymarg-single-product' ); ?></h2>
					<?php
					$this->field_toggle( 'show_delivery_info',   __( 'Show delivery info block', 'zymarg-single-product' ), $o );
					$this->field_text(   'delivery_icon',        __( 'Icon (emoji)', 'zymarg-single-product' ), $o );
					$this->field_text(   'delivery_window_text', __( 'Delivery window text', 'zymarg-single-product' ), $o );
					$this->field_text(   'ships_from_text',      __( 'Ships from text', 'zymarg-single-product' ), $o );
					?>
				</div>

				<div class="zymarg-sp-admin__section">
					<h2 class="zymarg-sp-admin__section-title"><?php esc_html_e( 'Shipping & Returns', 'zymarg-single-product' ); ?></h2>
					<?php
					$this->field_toggle(   'show_shipping_returns', __( 'Show Shipping & Returns block', 'zymarg-single-product' ), $o );
					$this->field_textarea( 'shipping_text',         __( 'Shipping text', 'zymarg-single-product' ), $o );
					$this->field_textarea( 'returns_text',          __( 'Returns text', 'zymarg-single-product' ), $o );
					?>
				</div>

				<div class="zymarg-sp-admin__section">
					<h2 class="zymarg-sp-admin__section-title"><?php esc_html_e( 'Secure Payment Note', 'zymarg-single-product' ); ?></h2>
					<?php
					$this->field_toggle( 'show_secure_note', __( 'Show secure payment note', 'zymarg-single-product' ), $o );
					$this->field_text(   'secure_note_text', __( 'Note text', 'zymarg-single-product' ), $o );
					?>
				</div>

				<div class="zymarg-sp-admin__section">
					<h2 class="zymarg-sp-admin__section-title"><?php esc_html_e( 'Sold By Row', 'zymarg-single-product' ); ?></h2>
					<?php $this->field_toggle( 'show_sold_by', __( 'Show "Sold by" row in buy box', 'zymarg-single-product' ), $o ); ?>
				</div>

			</div>
		</div>
		<?php
	}

	// ── Tab: General ──────────────────────────────────────────────────────────

	private function render_tab_general( array $o ): void {
		?>
		<div class="zymarg-sp-admin__panel" id="zymarg-sp-tab-general" role="tabpanel" aria-labelledby="zymarg-sp-tabnav-general">
			<div class="zymarg-sp-admin__panel-inner">

				<div class="zymarg-sp-admin__section">
					<h2 class="zymarg-sp-admin__section-title"><?php esc_html_e( 'Template Override', 'zymarg-single-product' ); ?></h2>
					<?php
					$this->field_toggle( 'template_override_enabled', __( 'Enable template override (emergency kill switch)', 'zymarg-single-product' ), $o );
					$this->field_number( 'override_priority', __( 'Override priority (lower = higher priority)', 'zymarg-single-product' ), $o, 1, 99 );
					?>
				</div>

				<div class="zymarg-sp-admin__section">
					<h2 class="zymarg-sp-admin__section-title"><?php esc_html_e( 'Breadcrumbs', 'zymarg-single-product' ); ?></h2>
					<?php
					$this->field_toggle( 'show_breadcrumbs',      __( 'Show breadcrumbs', 'zymarg-single-product' ), $o );
					$this->field_text(   'breadcrumb_separator',  __( 'Breadcrumb separator', 'zymarg-single-product' ), $o );
					?>
				</div>

				<div class="zymarg-sp-admin__section">
					<h2 class="zymarg-sp-admin__section-title"><?php esc_html_e( 'Seller Card', 'zymarg-single-product' ); ?></h2>
					<?php
					$this->field_toggle( 'show_seller_card',  __( 'Show seller card section', 'zymarg-single-product' ), $o );
					$this->field_toggle( 'show_visit_store',  __( 'Show "Visit Store" button', 'zymarg-single-product' ), $o );
					$this->field_toggle( 'show_chat_btn',     __( 'Show "Chat" button', 'zymarg-single-product' ), $o );
					$this->field_text(   'chat_url',          __( 'Chat URL (leave blank for Dokan auto)', 'zymarg-single-product' ), $o );
					?>
				</div>

				<div class="zymarg-sp-admin__section">
					<h2 class="zymarg-sp-admin__section-title"><?php esc_html_e( 'Product Accordions', 'zymarg-single-product' ); ?></h2>
					<?php
					$this->field_toggle( 'show_description_tab',     __( 'Show Description accordion', 'zymarg-single-product' ), $o );
					$this->field_toggle( 'show_reviews_tab',         __( 'Show Reviews accordion', 'zymarg-single-product' ), $o );
					$this->field_toggle( 'description_open_default', __( 'Description open by default', 'zymarg-single-product' ), $o );
					$this->field_toggle( 'reviews_open_default',     __( 'Reviews open by default', 'zymarg-single-product' ), $o );
					$this->field_text(   'description_label',        __( 'Description accordion label', 'zymarg-single-product' ), $o );
					$this->field_text(   'reviews_label',            __( 'Reviews accordion label', 'zymarg-single-product' ), $o, __( 'Token: {count}', 'zymarg-single-product' ) );
					?>
				</div>

				<div class="zymarg-sp-admin__section">
					<h2 class="zymarg-sp-admin__section-title"><?php esc_html_e( 'Product Grid Sections', 'zymarg-single-product' ); ?></h2>
					<?php
					$this->field_toggle_text( 'show_seller_products',   'seller_products_title',  __( 'More from this Seller', 'zymarg-single-product' ), $o );
					$this->field_toggle_text( 'show_similar_products',  'similar_products_title', __( 'Similar Products', 'zymarg-single-product' ), $o );
					$this->field_toggle_text( 'show_recommended',       'recommended_title',      __( 'Recommended for You', 'zymarg-single-product' ), $o );
					?>
				</div>

			</div>
		</div>
		<?php
	}

	// ── Tab: Reviews ───────────────────────────────────────────────────

	/**
	 * v2.0.0 — every review setting moved to the ZYMARG Reviews Engine plugin.
	 * What stays here is only how the single product page presents the reviews
	 * accordion: whether to show it, whether it starts open, and its label.
	 */
	private function render_tab_reviews( array $o ): void {
		$engine_active = function_exists( 'zymarg_reviews_render' );
		$engine_url    = admin_url( 'admin.php?page=zymarg-reviews-engine' );
		?>
		<div class="zymarg-sp-admin__panel" id="zymarg-sp-tab-reviews" role="tabpanel" aria-labelledby="zymarg-sp-tabnav-reviews">
			<div class="zymarg-sp-admin__panel-inner">

				<div class="zymarg-sp-admin__section">
					<h2 class="zymarg-sp-admin__section-title"><?php esc_html_e( 'Reviews Accordion', 'zymarg-single-product' ); ?></h2>
					<?php
					$this->field_toggle( 'show_reviews_tab',     __( 'Show Reviews accordion', 'zymarg-single-product' ), $o );
					$this->field_toggle( 'reviews_open_default', __( 'Reviews open by default', 'zymarg-single-product' ), $o );
					$this->field_text(   'reviews_label',        __( 'Reviews accordion label', 'zymarg-single-product' ), $o, __( 'Token: {count}', 'zymarg-single-product' ) );
					?>
				</div>

				<div class="zymarg-sp-admin__section">
					<h2 class="zymarg-sp-admin__section-title"><?php esc_html_e( 'Reviews Engine', 'zymarg-single-product' ); ?></h2>
					<?php if ( $engine_active ) : ?>
						<p class="zymarg-sp-admin__note">
							<?php esc_html_e( 'Layout, feed, form, media, moderation and email settings for reviews live in the ZYMARG Reviews Engine plugin. Changes there apply everywhere reviews are shown.', 'zymarg-single-product' ); ?>
						</p>
						<p><a class="button button-secondary" href="<?php echo esc_url( $engine_url ); ?>"><?php esc_html_e( 'Open Reviews Engine settings', 'zymarg-single-product' ); ?></a></p>
					<?php else : ?>
						<p class="zymarg-sp-admin__note zymarg-sp-admin__note--warn">
							<?php esc_html_e( 'ZYMARG Reviews Engine is not active. The Reviews accordion stays hidden until you install and activate it. Your reviews and their settings are safe in the meantime.', 'zymarg-single-product' ); ?>
						</p>
					<?php endif; ?>
				</div>

			</div>
		</div>
		<?php
	}

	// ── Field helpers ─────────────────────────────────────────────────────────

	private function field_toggle( string $key, string $label, array $o ): void {
		$checked = ! empty( $o[ $key ] );
		?>
		<div class="zymarg-sp-field zymarg-sp-field--toggle">
			<label class="zymarg-sp-toggle">
				<input type="checkbox"
					name="<?php echo esc_attr( $key ); ?>"
					data-key="<?php echo esc_attr( $key ); ?>"
					value="1"
					<?php checked( $checked ); ?>>
				<span class="zymarg-sp-toggle__track"></span>
				<span class="zymarg-sp-toggle__label"><?php echo esc_html( $label ); ?></span>
			</label>
		</div>
		<?php
	}

	private function field_toggle_text( string $toggle_key, string $text_key, string $label, array $o, string $hint = '' ): void {
		$checked = ! empty( $o[ $toggle_key ] );
		$val     = esc_attr( $o[ $text_key ] ?? '' );
		?>
		<div class="zymarg-sp-field zymarg-sp-field--toggle-text">
			<div class="zymarg-sp-field__toggle-row">
				<label class="zymarg-sp-toggle">
					<input type="checkbox"
						name="<?php echo esc_attr( $toggle_key ); ?>"
						data-key="<?php echo esc_attr( $toggle_key ); ?>"
						value="1"
						<?php checked( $checked ); ?>>
					<span class="zymarg-sp-toggle__track"></span>
					<span class="zymarg-sp-toggle__label"><?php echo esc_html( $label ); ?></span>
				</label>
			</div>
			<div class="zymarg-sp-field__text-row <?php echo $checked ? '' : 'is-hidden'; ?>" data-controlled-by="<?php echo esc_attr( $toggle_key ); ?>">
				<input type="text"
					name="<?php echo esc_attr( $text_key ); ?>"
					data-key="<?php echo esc_attr( $text_key ); ?>"
					value="<?php echo $val; // phpcs:ignore ?>"
					class="zymarg-sp-input">
				<?php if ( $hint ) : ?>
					<span class="zymarg-sp-field__hint"><?php echo esc_html( $hint ); ?></span>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	private function field_text( string $key, string $label, array $o, string $hint = '' ): void {
		$val = esc_attr( $o[ $key ] ?? '' );
		?>
		<div class="zymarg-sp-field">
			<label class="zymarg-sp-field__label" for="zsp-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label>
			<input type="text"
				id="zsp-<?php echo esc_attr( $key ); ?>"
				name="<?php echo esc_attr( $key ); ?>"
				data-key="<?php echo esc_attr( $key ); ?>"
				value="<?php echo $val; // phpcs:ignore ?>"
				class="zymarg-sp-input">
			<?php if ( $hint ) : ?>
				<span class="zymarg-sp-field__hint"><?php echo esc_html( $hint ); ?></span>
			<?php endif; ?>
		</div>
		<?php
	}

	private function field_textarea( string $key, string $label, array $o ): void {
		$val = esc_textarea( $o[ $key ] ?? '' );
		?>
		<div class="zymarg-sp-field">
			<label class="zymarg-sp-field__label" for="zsp-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label>
			<textarea
				id="zsp-<?php echo esc_attr( $key ); ?>"
				name="<?php echo esc_attr( $key ); ?>"
				data-key="<?php echo esc_attr( $key ); ?>"
				class="zymarg-sp-input zymarg-sp-textarea"
				rows="3"><?php echo $val; // phpcs:ignore ?></textarea>
		</div>
		<?php
	}

	private function field_number( string $key, string $label, array $o, int $min = 0, int $max = 9999 ): void {
		$val = (int) ( $o[ $key ] ?? 0 );
		?>
		<div class="zymarg-sp-field zymarg-sp-field--number">
			<label class="zymarg-sp-field__label" for="zsp-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label>
			<input type="number"
				id="zsp-<?php echo esc_attr( $key ); ?>"
				name="<?php echo esc_attr( $key ); ?>"
				data-key="<?php echo esc_attr( $key ); ?>"
				value="<?php echo esc_attr( $val ); ?>"
				min="<?php echo esc_attr( $min ); ?>"
				max="<?php echo esc_attr( $max ); ?>"
				class="zymarg-sp-input zymarg-sp-input--number">
		</div>
		<?php
	}

	private function field_radio( string $key, string $label, array $o, array $options ): void {
		$current = $o[ $key ] ?? array_key_first( $options );
		?>
		<div class="zymarg-sp-field zymarg-sp-field--radio">
			<span class="zymarg-sp-field__label"><?php echo esc_html( $label ); ?></span>
			<div class="zymarg-sp-radio-group">
				<?php foreach ( $options as $val => $opt_label ) : ?>
					<label class="zymarg-sp-radio">
						<input type="radio"
							name="<?php echo esc_attr( $key ); ?>"
							data-key="<?php echo esc_attr( $key ); ?>"
							value="<?php echo esc_attr( $val ); ?>"
							<?php checked( $current, $val ); ?>>
						<span class="zymarg-sp-radio__label"><?php echo esc_html( $opt_label ); ?></span>
					</label>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}
}
