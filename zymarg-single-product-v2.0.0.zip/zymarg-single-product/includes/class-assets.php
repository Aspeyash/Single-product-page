<?php
/**
 * Assets — enqueue CSS and JS for the front-end template and admin panel.
 *
 * @version 1.0.11
 * @package ZymargSingleProduct
 */

namespace ZymargSP;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Assets {

	const HANDLE_CSS   = 'zymarg-sp-style';
	const HANDLE_JS    = 'zymarg-sp-script';
	const HANDLE_ADMIN = 'zymarg-sp-admin';

	/** @var self|null */
	private static $instance = null;

	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	public function init(): void {
		add_action( 'wp_enqueue_scripts',    [ $this, 'enqueue_frontend' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin' ] );
	}

	// ── Front-end ─────────────────────────────────────────────────────────────

	public function enqueue_frontend(): void {
		if ( ! is_product() ) {
			return;
		}

		// ── CSS ──────────────────────────────────────────────────────────────
		wp_enqueue_style(
			self::HANDLE_CSS,
			ZYMARG_SP_ASSETS . 'css/zymarg-sp.css',
			[],
			ZYMARG_SP_VERSION
		);

		// ── JS ───────────────────────────────────────────────────────────────
		// We depend on WooCommerce's variation JS so it binds data-product_variations.
		wp_enqueue_script( 'wc-add-to-cart-variation' );

		wp_enqueue_script(
			self::HANDLE_JS,
			ZYMARG_SP_ASSETS . 'js/zymarg-sp.js',
			[ 'jquery', 'wc-add-to-cart-variation' ],
			ZYMARG_SP_VERSION,
			true
		);

		// Native swatch interaction (WSE port) — selection, keyboard, availability.
		wp_enqueue_script(
			'zymarg-sp-swatches',
			ZYMARG_SP_ASSETS . 'js/zymarg-sp-swatches.js',
			[ 'jquery', 'wc-add-to-cart-variation', self::HANDLE_JS ],
			ZYMARG_SP_VERSION,
			true
		);

		// Live price updates for variable products (WSE port).
		wp_enqueue_script(
			'zymarg-sp-price',
			ZYMARG_SP_ASSETS . 'js/zymarg-sp-price.js',
			[ 'jquery', 'wc-add-to-cart-variation', self::HANDLE_JS ],
			ZYMARG_SP_VERSION,
			true
		);

		// ── Localise ─────────────────────────────────────────────────────────
		global $product;
		$wc_product = ( $product instanceof \WC_Product ) ? $product : wc_get_product( get_the_ID() );

		$js_opts = Options::all();

		wp_localize_script( self::HANDLE_JS, 'zymargSP', [
			'ajax_url'           => admin_url( 'admin-ajax.php' ),
			// v1.0.11 #3 — WC-AJAX endpoint for WooCommerce's native add-to-cart
			// handler. The front-end JS swaps %%endpoint%% for 'add_to_cart'.
			'wc_ajax_url'        => class_exists( '\\WC_AJAX' ) ? \WC_AJAX::get_endpoint( '%%endpoint%%' ) : '',
			'buy_now'            => Buy_Now::js_data(),
			'nonce_atc'          => wp_create_nonce( 'zymarg_sp_atc' ),
			'product_id'         => $wc_product ? $wc_product->get_id() : 0,
			'is_variable'        => $wc_product ? $wc_product->is_type( 'variable' ) : false,
			'currency_symbol'    => get_woocommerce_currency_symbol(),
			'atc_text'           => $js_opts['atc_btn_text'],
			'atc_text_loading'   => $js_opts['atc_btn_text_loading'],
			'atc_text_done'      => $js_opts['atc_btn_text_done'],
			'show_toast'         => $js_opts['atc_show_toast'],
			'toast_text'         => $js_opts['atc_toast_text'],
			'show_view_cart'     => $js_opts['atc_show_view_cart'],
			'cart_url'           => wc_get_cart_url(),
			'view_cart_text'     => __( 'View Cart', 'zymarg-single-product' ),
			'swatch_shape'       => $js_opts['swatch_shape'],
			'swatch_oos'         => $js_opts['swatch_oos_behavior'],
			'swatch_tooltip'     => $js_opts['swatch_tooltip'],
			'swatch_tooltip_pos' => $js_opts['swatch_tooltip_position'],
			'swatch_auto_select' => $js_opts['swatch_auto_select'],
			'gallery_zoom'       => $js_opts['gallery_hover_zoom'],
			'gallery_lightbox'   => $js_opts['gallery_lightbox'],
			'price_anim'         => $js_opts['price_change_animation'],
			'sticky_enabled'     => $js_opts['sticky_bar_enabled'],
			'qty_min'            => max( 1, (int) $js_opts['qty_min'] ),
			'qty_max'            => (int) $js_opts['qty_max'],
			'qty_default'        => max( 1, (int) $js_opts['qty_default'] ),
			'qty_sync_sticky'    => $js_opts['qty_sync_sticky'],
			'price'              => [
				'decimals'     => wc_get_price_decimals(),
				'decimal_sep'  => wc_get_price_decimal_separator(),
				'thousand_sep' => wc_get_price_thousand_separator(),
				'symbol'       => get_woocommerce_currency_symbol(),
				'format'       => get_woocommerce_price_format(),
			],
			'i18n'               => [
				'sold_out'         => __( 'Sold Out',    'zymarg-single-product' ),
				'unavailable'      => __( 'Unavailable', 'zymarg-single-product' ),
				'select_options'   => __( 'Select options', 'zymarg-single-product' ),
				'clear'            => $js_opts['swatch_clear_label'],
				'buynow_text'      => $js_opts['buynow_text'],
			],
		] );

		// v2.0.0 — review markup, styles and scripts now belong to the standalone
		// ZYMARG Reviews Engine plugin. It registers and localises its own assets;
		// we only ask it to load them on this product page.
		if ( function_exists( 'zymarg_reviews_enqueue' ) ) {
			zymarg_reviews_enqueue( $wc_product ? $wc_product->get_id() : (int) get_the_ID() );
		}
	}

	// ── Admin ─────────────────────────────────────────────────────────────────

	public function enqueue_admin( string $hook ): void {
		// Only load on our settings page.
		if ( ! str_contains( $hook, 'zymarg-single-product' ) ) {
			return;
		}

		wp_enqueue_style(
			self::HANDLE_ADMIN,
			ZYMARG_SP_ASSETS . 'css/zymarg-sp-admin.css',
			[],
			ZYMARG_SP_VERSION
		);

		wp_enqueue_script(
			self::HANDLE_ADMIN,
			ZYMARG_SP_ASSETS . 'js/zymarg-sp-admin.js',
			[ 'jquery' ],
			ZYMARG_SP_VERSION,
			true
		);

		wp_localize_script( self::HANDLE_ADMIN, 'zymargSPAdmin', [
			'ajax_url'    => admin_url( 'admin-ajax.php' ),
			'nonce'       => wp_create_nonce( 'zymarg_sp_admin_save' ),
			'saved_text'  => __( 'Settings saved!', 'zymarg-single-product' ),
			'error_text'  => __( 'Error saving. Please try again.', 'zymarg-single-product' ),
			'settings'    => Options::all(),
		] );
	}
}
