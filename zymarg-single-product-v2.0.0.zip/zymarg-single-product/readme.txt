=== ZYMARG Single Product ===
Contributors: aspeyash
Tags: woocommerce, single product, template, swatches, buy now, reviews
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 8.0
Stable tag: 2.0.0
WC requires at least: 8.0
WC tested up to: 9.9
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Standalone single product page template for the ZYMARG Marketplace.

== Description ==

ZYMARG Single Product overrides the WooCommerce default single product template with a
fully custom layout featuring a 3-column desktop design with gallery, product info,
and a buy box.

Key features:
* Template override that beats Elementor, Divi, and all page builders (dual-hook strategy)
* Product gallery with vertical/horizontal/grid layout, lightbox, hover zoom, thumbnails
* Variation swatches rendered on top of WooCommerce native selects (shape, size, OOS behaviour)
* Smart price display with variable product options, savings badge, free shipping hint
* Quantity stepper synced between desktop buy box and mobile sticky bar
* Add to Cart via WooCommerce AJAX (no page reload)
* Buy Now with own session management — saves current cart, restores on abandonment or TTL expiry
* Dokan Pro seller card with fallback to WP user
* Collapsible accordions: Description (with spec table) + Reviews
* Fully embedded ZYMARG Reviews subsystem (no dependency on the standalone Reviews plugin)
* Product grid section hooks for ZYMARG WC Product Grid plugin
* Sticky mobile action bar with qty, ATC, Buy Now
* 6-tab admin panel (Gallery / Swatches / Price / Add to Cart / Trust & Shipping / General)
* AJAX save — settings panel never reloads the page
* HPOS (High-Performance Order Storage) compatible
* Zero dependency on WSE (Woo Swatches Elementor)

== Installation ==

1. Upload the `zymarg-single-product` folder to `/wp-content/plugins/`
2. Activate the plugin in WP Admin → Plugins
3. Go to Single Product in the WordPress admin menu to configure settings

== Changelog ==

= 2.0.0 =
* Reviews are now powered by the separate ZYMARG Reviews Engine plugin.
* Removed the bundled reviews module, its styles, scripts, AJAX handlers and settings UI from this plugin.
* The Reviews accordion renders through zymarg_reviews_render() and is skipped when the engine is not active.
* Soft dependency: every other section keeps working without the engine; administrators see a dismissible notice.
* Admin Reviews tab now only controls the accordion (show, open by default, label) and links to the engine settings.
* Existing review settings stay in storage untouched so the engine can migrate them.

= 1.1.21 =
* Reverted the attribute heading row to its original layout (attribute label and selected value only).
* Removed the variation stock readout from the attribute row. Out-of-stock state is still communicated by disabled swatches and the disabled Add to Cart / Buy Now buttons.

= 1.1.20 =
* Attribute heading is now a strict two-column row: label column flexes, stock column is auto width and never wraps to a second line.
* Stock readout shows only when a variation is out of stock; in-stock variations leave the column empty so the label uses the full row.
* Removed the duplicate stock status block from the buy box. The "Show stock status" setting now controls the attribute-row readout.

= 1.1.19 =
* Variable products: the variation stock status now sits in the attribute heading row, right aligned, at the attribute label size, instead of below the swatches.
* Multi-attribute products show the stock readout on the last attribute row; products with the attribute label disabled get a stock-only row.
* Mobile: smaller product title and tighter spacing between the title, rating, category and price rows.
* Removed the tick glyph after the vendor name in the buy box.

= 1.1.18 =
* Mobile: the review filter bar (All Reviews / With Photos / sort) now stays on a single line instead of wrapping onto two rows.
* New: product category row displayed directly under the rating and sold-count row, with links to each category archive.

= 1.1.17 =
* Swatches: arrow keys now switch the variation as focus moves (selection follows focus); Enter/Space still toggles, Home/End jump to the first/last swatch.
* New: review media gallery. Clicking a review photo or video opens a full-screen viewer spanning all customer media for the product, with the reviewer, rating, variation and review text alongside.
* New: "Customer photos & videos" strip above the review feed.
* New: review video uploads (mp4/webm/mov) with their own size limit, plus two new settings under Reviews - Submission Behavior.
* Gallery filters: by variation, by star rating, and sort by newest or most helpful.

= 1.1.16 =
* Seller card chat icon now matches the design mockup (emoji glyph instead of the tinted inline SVG).
* Removed theme hover/focus underlines on the review-count link and the seller card buttons.
* Description and Reviews accordions now slide open and closed instead of snapping.
* Accordion animation respects prefers-reduced-motion and falls back to native toggling.

= 1.1.15 =
* Fix: variation attribute label was hardcoded dark grey and unreadable in dark mode.
* Fix: seller card star rating never rendered (selector targeted a child svg instead of the svg itself).
* Seller card: removed the "Sold by" label.
* Seller card: rating and product count now share a single line.
* Seller card: averaged 5-star rating on desktop and tablet, single filled star on mobile.
* Seller card: compact mobile layout - smaller avatar, 2-line store name, tighter button padding, wider middle column.

= 1.1.14 =
* New: Reports column in WP Admin > Comments, sortable by report count.
* New: "Reported" filter view beside Pending / Approved / Spam.
* New: optional auto-unapprove once a review reaches the report threshold (off by default, threshold 3).
* New: admin email on the first report of a review, and when a review is auto-unapproved.
* New: "Clear reports" row action to dismiss false reports.
* New: Report Moderation settings section in the Reviews tab.

= 1.1.13 =
* Reviews section now inherits the ZYMARG brand palette instead of the migrated plugin colours.
* Reviews section now follows dark mode automatically.
* Report Abuse modal restyled with the brand palette and a dark-mode variant.

= 1.1.12 =
* Mobile only: reviews summary and form gaps raised from 4px to 8px.

= 1.1.11 =
* Mobile only: slightly increased padding around the reviews accordion body.
* Mobile only: summary and form gaps raised from 0 to 4px.

= 1.1.10 =
* Restored the brand purple price colour; price text is no longer invisible in dark mode.
* Save badge now legible on both light and dark surfaces.
* Swatch hover, selected swatch and tooltip colours now follow the theme tokens.
* Mobile only: removed the empty gap between the site header and the product content.
* Mobile only: minimal padding on accordion bodies, no container padding and no gaps in the reviews block.

= 1.1.9 =
* Price heading now stays on its own line above the price.
* Current price, old price and save badge align on one baseline row.
* Old price strikethrough now runs through the middle of the digits.
* Reduced the gap between the old price and its underline.

= 1.1.8 =
* Reduced visual weight of current, old and savings price text.
* Save badge is now smaller and displays inline with the price.
* Old price strikethrough/underline now uses a precisely positioned line.
* Quantity stepper buttons now match the quantity input background; hover and active colours retained.
* Mobile only: removed the product section grid gap.

= 1.1.7 =
* Updated PHP requirement metadata to 8.0.
* Fixed textarea setting sanitization for shipping and returns text.

= 1.0.0 =
* Initial release
