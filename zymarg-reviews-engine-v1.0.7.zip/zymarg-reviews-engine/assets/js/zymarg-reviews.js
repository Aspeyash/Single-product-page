/*!
 * ZYMARG Reviews — Front-end script
 * Version: 1.0.6
 * License: GPL-2.0-or-later
 *
 * Vanilla JS, no dependencies. Handles:
 *   - Star rating input
 *   - Form submission via fetch + FormData (with media upload)
 *   - Show form on URL trigger and scroll into view
 *   - Filter / sort / load-more for review feed
 *   - Pagination count ("Showing X of Y reviews")
 *   - Manual mode Load More (JSON-encoded review list)
 *   - Store owner reply forms (toggle, submit, cancel)
 *   - Media file count display + client-side validation
 */
(function () {
	'use strict';

	var CFG = window.ZymargReviews || {};

	function ready(fn) {
		if (document.readyState !== 'loading') { fn(); return; }
		document.addEventListener('DOMContentLoaded', fn);
	}

	ready(function () {
		var widgets = document.querySelectorAll('.zymarg-reviews-widget');
		widgets.forEach(initWidget);
	});

	function initWidget(root) {
		initStarInput(root);
		initForm(root);
		initFilters(root);
		initSort(root);
		initLoadMore(root);
		initMediaCounter(root);
		initReplyForms(root);
		initVoteButtons(root);
		initDotsMenus(root);
		initReportModal(root);
		// v1.1.17 - review media gallery (defined at the foot of this file).
		if (window.zymargInitGallery) { window.zymargInitGallery(root); }
		maybeRevealAndScroll(root);
	}

	/* ------------------------------------------------------------------
	 * Star rating input
	 * ---------------------------------------------------------------- */
	function initStarInput(root) {
		var group = root.querySelector('.zymarg-rating-input');
		if (!group) return;
		var hidden = root.querySelector('.zymarg-rating-value');
		var stars  = group.querySelectorAll('.zymarg-rate-star');

		function paint(n) {
			stars.forEach(function (s, i) {
				if (i < n) { s.classList.remove('is-empty'); s.classList.add('is-filled'); }
				else       { s.classList.remove('is-filled'); s.classList.add('is-empty'); }
			});
		}

		stars.forEach(function (s) {
			s.addEventListener('mouseenter', function () { paint(parseInt(s.dataset.value, 10) || 0); });
			s.addEventListener('focus',      function () { paint(parseInt(s.dataset.value, 10) || 0); });
			s.addEventListener('click', function () {
				var v = parseInt(s.dataset.value, 10) || 0;
				if (hidden) hidden.value = String(v);
				group.dataset.value = String(v);
				paint(v);
			});
		});
		group.addEventListener('mouseleave', function () {
			paint(parseInt(group.dataset.value || '0', 10));
		});
	}

	/* ------------------------------------------------------------------
	 * Review form submit
	 * ---------------------------------------------------------------- */
	function initForm(root) {
		var form = root.querySelector('.zymarg-review-form');
		if (!form) return;

		var submitBtn = form.querySelector('.zymarg-btn-submit');
		var msg       = form.querySelector('.zymarg-form-message');

		form.addEventListener('submit', function (ev) {
			ev.preventDefault();
			if (!CFG.ajaxUrl) {
				setMessage(msg, (CFG.i18n && CFG.i18n.genericErr) || 'Error', 'error');
				return;
			}

			var ratingInput = form.querySelector('.zymarg-rating-value');
			var rating      = ratingInput ? parseInt(ratingInput.value || '0', 10) : 0;
			if (!rating) {
				setMessage(msg, 'Please choose a rating.', 'error');
				return;
			}
			var bodyEl = form.querySelector('textarea[name="review_body"]');
			if (bodyEl && !bodyEl.value.trim()) {
				setMessage(msg, 'Please write your review.', 'error');
				bodyEl.focus();
				return;
			}

			var fileInput = form.querySelector('input[type="file"][name="media[]"]');
			if (fileInput && fileInput.files && fileInput.files.length) {
				var maxFiles = CFG.maxFiles || 4;
				var maxSize  = CFG.maxFileSize || (2048 * 1024);
				if (fileInput.files.length > maxFiles) {
					setMessage(msg, 'Too many files. Max: ' + maxFiles, 'error');
					return;
				}
				for (var i = 0; i < fileInput.files.length; i++) {
					if (fileInput.files[i].size > maxSize) {
						setMessage(msg, 'File too large: ' + fileInput.files[i].name, 'error');
						return;
					}
				}
			}

			submitBtn.disabled = true;
			var originalLabel  = submitBtn.textContent;
			submitBtn.textContent = (CFG.i18n && CFG.i18n.submitting) || 'Submitting…';
			setMessage(msg, '', '');

			var data = new FormData(form);
			data.set('action', 'zymarg_submit_review');
			if (CFG.submitNonce) data.set('_ajax_nonce', CFG.submitNonce);

			fetch(CFG.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: data })
				.then(function (r) { return r.json(); })
				.then(function (res) {
					if (res && res.success) {
						var success = (form.querySelector('.zymarg-form-message')
							&& form.querySelector('.zymarg-form-message').dataset.success) || res.message || 'Thanks!';
						setMessage(msg, res.message || success, 'success');
						form.reset();
						setTimeout(function () {
							var section = root.querySelector('#zymarg-write-review');
							if (section) section.style.display = 'none';
						}, 1800);
					} else {
						setMessage(msg, (res && res.message) || ((CFG.i18n && CFG.i18n.genericErr) || 'Error'), 'error');
						submitBtn.disabled = false;
						submitBtn.textContent = originalLabel;
					}
				})
				.catch(function () {
					setMessage(msg, (CFG.i18n && CFG.i18n.genericErr) || 'Error', 'error');
					submitBtn.disabled = false;
					submitBtn.textContent = originalLabel;
				});
		});
	}

	function setMessage(el, text, kind) {
		if (!el) return;
		el.textContent = text || '';
		el.classList.remove('is-error', 'is-success');
		if (kind === 'error')   el.classList.add('is-error');
		if (kind === 'success') el.classList.add('is-success');
	}

	/* ------------------------------------------------------------------
	 * Filters (All / Media)
	 * ---------------------------------------------------------------- */
	function initFilters(root) {
		var pills = root.querySelectorAll('.zymarg-filter-pill');
		if (!pills.length) return;

		pills.forEach(function (pill) {
			pill.addEventListener('click', function () {
				pills.forEach(function (p) { p.classList.remove('is-active'); });
				pill.classList.add('is-active');

				var filter = pill.dataset.filter || 'all';
				var feed   = root.querySelector('.zymarg-feed');
				if (!feed) return;

				if (filter === 'all') {
					feed.querySelectorAll('.zymarg-review-card').forEach(function (c) {
						c.style.display = '';
					});
				} else if (filter === 'media') {
					feed.querySelectorAll('.zymarg-review-card').forEach(function (c) {
						c.style.display = c.classList.contains('has-media') ? '' : 'none';
					});
				}
			});
		});
	}

	/* ------------------------------------------------------------------
	 * Sort
	 *
	 * For WooCommerce mode (product_id > 0): reload the feed via AJAX
	 * so ordering is applied by MySQL, not just on the loaded subset.
	 *
	 * For Manual mode (product_id === 0): sort the already-rendered cards
	 * in the DOM (same as before — there's no server to call).
	 * ---------------------------------------------------------------- */
	function initSort(root) {
		var sel  = root.querySelector('.zymarg-sort-select');
		var feed = root.querySelector('.zymarg-feed');
		if (!sel || !feed) return;

		sel.addEventListener('change', function () {
			var mode      = sel.value;
			var productId = parseInt(feed.dataset.productId || '0', 10);

			if (productId && CFG.ajaxUrl) {
				// WooCommerce mode — reload page 1 from the server with new sort.
				var btn     = root.querySelector('.zymarg-btn-load-more');
				var perPage = btn ? parseInt(btn.dataset.perPage || '5', 10) : 5;

				var data = new FormData();
				data.set('action',      'zymarg_load_reviews');
				data.set('_ajax_nonce', CFG.loadNonce || '');
				data.set('product_id',  String(productId));
				data.set('page',        '1');
				data.set('per_page',    String(perPage));
				data.set('filter',      currentFilter(root));
				data.set('sort',        mode);

				if (btn) { btn.disabled = true; }

				fetch(CFG.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: data })
					.then(function (r) { return r.json(); })
					.then(function (res) {
						if (res && res.success) {
							feed.innerHTML = res.html || '';
							// Re-init reply forms on freshly injected cards.
							initReplyForms(root);
							initVoteButtons(root);
							initDotsMenus(root);
							// Reset load-more state.
							if (btn) {
								btn.dataset.page = '2';
								btn.dataset.sort = mode;
								btn.style.display = res.has_more ? '' : 'none';
								btn.disabled = false;
							}
							// Update pagination count.
							updatePaginationCount(root, res.loaded_count || perPage, res.total_count || 0);
						} else {
							if (btn) btn.disabled = false;
						}
					})
					.catch(function () {
						if (btn) btn.disabled = false;
					});

			} else {
				// Manual mode — DOM sort only.
				var cards = Array.prototype.slice.call(feed.querySelectorAll('.zymarg-review-card'));
				cards.sort(function (a, b) {
					var ar = ratingFromCard(a);
					var br = ratingFromCard(b);
					var ad = dateFromCard(a);
					var bd = dateFromCard(b);
					if (mode === 'highest') return br - ar;
					if (mode === 'lowest')  return ar - br;
					return bd - ad;
				});
				cards.forEach(function (c) { feed.appendChild(c); });
			}
		});
	}

	function currentFilter(root) {
		var active = root.querySelector('.zymarg-filter-pill.is-active');
		return active ? (active.dataset.filter || 'all') : 'all';
	}

	function ratingFromCard(card) {
		return card.querySelectorAll('.zymarg-stars .zymarg-star.is-filled').length;
	}
	function dateFromCard(card) {
		var d = card.querySelector('.zymarg-review-date');
		if (!d) return 0;
		var t = Date.parse(d.textContent.trim());
		return isNaN(t) ? 0 : t;
	}

	/* ------------------------------------------------------------------
	 * Pagination count helper
	 * ---------------------------------------------------------------- */
	function updatePaginationCount(root, loaded, total) {
		var counter = root.querySelector('.zymarg-pagination-count');
		if (!counter || !total) return;
		counter.textContent = 'Showing ' + loaded + ' of ' + total + ' reviews';
	}

	/* ------------------------------------------------------------------
	 * Load more
	 * ---------------------------------------------------------------- */
	function initLoadMore(root) {
		var btn = root.querySelector('.zymarg-btn-load-more');
		if (!btn) return;

		btn.addEventListener('click', function () {
			var feed       = root.querySelector('.zymarg-feed');
			var productId  = feed ? parseInt(feed.dataset.productId || '0', 10) : 0;
			if (!CFG.ajaxUrl) return;

			var page       = parseInt(btn.dataset.page     || '2', 10);
			var perPage    = parseInt(btn.dataset.perPage  || '5', 10);
			var sort       = btn.dataset.sort              || feed.dataset.sort || 'recent';
			var filter     = currentFilter(root);

			btn.disabled    = true;
			var originalTxt = btn.textContent;
			btn.textContent = (CFG.i18n && CFG.i18n.loading) || 'Loading…';

			var data = new FormData();
			data.set('action',      'zymarg_load_reviews');
			data.set('_ajax_nonce', CFG.loadNonce || '');
			data.set('product_id',  String(productId));
			data.set('page',        String(page));
			data.set('per_page',    String(perPage));
			data.set('filter',      filter);
			data.set('sort',        sort);

			// Manual mode: pass all reviews as JSON so server can paginate.
			if (!productId && feed && feed.dataset.manualReviews) {
				data.set('manual_reviews', feed.dataset.manualReviews);
			}

			fetch(CFG.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: data })
				.then(function (r) { return r.json(); })
				.then(function (res) {
					if (res && res.success) {
						if (res.html) {
							feed.insertAdjacentHTML('beforeend', res.html);
							// Re-init reply forms on newly injected cards.
							initReplyForms(root);
							initVoteButtons(root);
							initDotsMenus(root);
						}
						// Update pagination count.
						if (res.loaded_count && res.total_count) {
							updatePaginationCount(root, res.loaded_count, res.total_count);
						}
						if (res.has_more) {
							btn.dataset.page = String(res.next_page);
							btn.disabled = false;
							btn.textContent = originalTxt;
						} else {
							btn.style.display = 'none';
						}
					} else {
						btn.disabled = false;
						btn.textContent = originalTxt;
					}
				})
				.catch(function () {
					btn.disabled = false;
					btn.textContent = originalTxt;
				});
		});
	}

	/* ------------------------------------------------------------------
	 * Store owner reply forms
	 *
	 * Toggle open/close reply form per card. Submit via AJAX.
	 * Only rendered for users with manage_woocommerce capability (PHP-gated),
	 * so no capability check needed in JS.
	 * ---------------------------------------------------------------- */
	function initReplyForms(root) {
		// Toggle buttons — open/close the reply textarea.
		var toggleBtns = root.querySelectorAll('.zymarg-btn-reply-toggle');
		toggleBtns.forEach(function (btn) {
			// Avoid double-binding if initReplyForms is called again after Load More.
			if (btn.dataset.replyBound) return;
			btn.dataset.replyBound = '1';

			btn.addEventListener('click', function () {
				var commentId = btn.dataset.commentId;
				var wrap      = document.getElementById('zymarg-reply-form-' + commentId);
				if (!wrap) return;
				var isOpen = wrap.classList.contains('is-open');
				wrap.classList.toggle('is-open', !isOpen);
				if (!isOpen) {
					var ta = wrap.querySelector('.zymarg-reply-textarea');
					if (ta) ta.focus();
				}
			});
		});

		// Cancel buttons.
		var cancelBtns = root.querySelectorAll('.zymarg-btn-reply-cancel');
		cancelBtns.forEach(function (btn) {
			if (btn.dataset.replyBound) return;
			btn.dataset.replyBound = '1';

			btn.addEventListener('click', function () {
				var wrap = btn.closest('.zymarg-reply-form-wrap');
				if (wrap) {
					wrap.classList.remove('is-open');
					var ta = wrap.querySelector('.zymarg-reply-textarea');
					if (ta) ta.value = '';
					var msg = wrap.querySelector('.zymarg-reply-msg');
					if (msg) { msg.textContent = ''; msg.className = 'zymarg-reply-msg'; }
				}
			});
		});

		// Reply forms — submit.
		var replyForms = root.querySelectorAll('.zymarg-reply-form');
		replyForms.forEach(function (form) {
			if (form.dataset.replyBound) return;
			form.dataset.replyBound = '1';

			form.addEventListener('submit', function (ev) {
				ev.preventDefault();
				if (!CFG.ajaxUrl) return;

				var submitBtn   = form.querySelector('.zymarg-btn-reply-submit');
				var msg         = form.querySelector('.zymarg-reply-msg');
				var bodyEl      = form.querySelector('.zymarg-reply-textarea');
				var commentIdEl = form.querySelector('input[name="comment_id"]');
				var nonceEl     = form.querySelector('input[name="_ajax_nonce"]');

				if (!bodyEl || !bodyEl.value.trim()) {
					setMessage(msg, 'Please write a reply.', 'error');
					return;
				}

				submitBtn.disabled   = true;
				var origLabel        = submitBtn.textContent;
				submitBtn.textContent = (CFG.i18n && CFG.i18n.submitting) || 'Posting…';
				setMessage(msg, '', '');

				var data = new FormData();
				data.set('action',      'zymarg_reply_review');
				data.set('_ajax_nonce', nonceEl ? nonceEl.value : (CFG.replyNonce || ''));
				data.set('comment_id',  commentIdEl ? commentIdEl.value : '');
				data.set('reply_body',  bodyEl.value.trim());

				fetch(CFG.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: data })
					.then(function (r) { return r.json(); })
					.then(function (res) {
						if (res && res.success) {
							// Inject the new reply HTML into the card's replies container.
							var card     = form.closest('.zymarg-review-card');
							var repliesWrap = card && card.querySelector('.zymarg-replies');
							// A held reply is not public yet, so the server sends no
							// markup and there is nothing to inject.
							if (res.html) {
								if (!repliesWrap) {
									// Create replies container if none existed.
									repliesWrap = document.createElement('div');
									repliesWrap.className = 'zymarg-replies';
									var mediaDiv = card.querySelector('.zymarg-review-photos');
									var anchor   = mediaDiv || card.querySelector('.zymarg-review-body');
									if (anchor && anchor.nextSibling) {
										card.insertBefore(repliesWrap, anchor.nextSibling);
									} else if (anchor) {
										card.appendChild(repliesWrap);
									}
								}

								// Match the server-side ordering: a seller reply joins the
								// pinned group at the top, ahead of the first customer
								// reply. Everything else appends.
								var firstCustomer = (res.is_owner && CFG.sellerReplyFirst)
									? repliesWrap.querySelector('.zymarg-reply:not(.zymarg-reply--owner)')
									: null;

								if (firstCustomer) {
									firstCustomer.insertAdjacentHTML('beforebegin', res.html);
								} else {
									repliesWrap.insertAdjacentHTML('beforeend', res.html);
								}
							}
							setMessage(msg, res.message || 'Reply posted.', 'success');
							bodyEl.value = '';
							setTimeout(function () {
								var wrap = form.closest('.zymarg-reply-form-wrap');
								if (wrap) wrap.classList.remove('is-open');
								setMessage(msg, '', '');
							}, 1600);
						} else {
							setMessage(msg, (res && res.message) || ((CFG.i18n && CFG.i18n.genericErr) || 'Error'), 'error');
						}
						submitBtn.disabled    = false;
						submitBtn.textContent = origLabel;
					})
					.catch(function () {
						setMessage(msg, (CFG.i18n && CFG.i18n.genericErr) || 'Error', 'error');
						submitBtn.disabled    = false;
						submitBtn.textContent = origLabel;
					});
			});
		});
	}

	/* ------------------------------------------------------------------
	 * Media file counter (UX feedback)
	 * ---------------------------------------------------------------- */
	function initMediaCounter(root) {
		var input  = root.querySelector('input[type="file"][name="media[]"]');
		var label  = root.querySelector('.zymarg-media-count');
		if (!input || !label) return;

		var defaultText = label.textContent;
		input.addEventListener('change', function () {
			var n = input.files ? input.files.length : 0;
			if (n === 0)      { label.textContent = defaultText; }
			else if (n === 1) { label.textContent = '1 file selected'; }
			else              { label.textContent = n + ' files selected'; }
		});
	}

	/* ------------------------------------------------------------------
	 * Reveal-form-on-URL + smooth scroll
	 * ---------------------------------------------------------------- */
	function maybeRevealAndScroll(root) {
		var qs = window.location.search || '';
		if (qs.indexOf('zymarg_review=1') === -1) return;

		var section = root.querySelector('#zymarg-write-review');
		if (!section) return;

		section.style.display = '';

		setTimeout(function () {
			try {
				section.scrollIntoView({ behavior: 'smooth', block: 'start' });
			} catch (e) {
				section.scrollIntoView();
			}
		}, 200);
	}

	/* ------------------------------------------------------------------
	 * Like / Dislike vote buttons
	 * ---------------------------------------------------------------- */
	function initVoteButtons(root) {
		var btns = root.querySelectorAll('.zymarg-btn-vote');
		btns.forEach(function (btn) {
			if (btn.dataset.voteBound) return;
			btn.dataset.voteBound = '1';

			btn.addEventListener('click', function () {
				if (!CFG.ajaxUrl) return;

				// Guests have nowhere to store a vote. Rather than fire a request
				// that is guaranteed to come back "Unauthorized", say so.
				var bar = btn.closest('.zymarg-interaction-bar');
				if (bar && bar.dataset.requiresLogin === '1') {
					var note = bar.querySelector('.zymarg-vote-note');
					if (!note) {
						note = document.createElement('span');
						note.className = 'zymarg-vote-note';
						bar.appendChild(note);
					}
					note.textContent = (CFG.i18n && CFG.i18n.login_to_react) || 'Please log in to react.';
					return;
				}

				var commentId = btn.dataset.commentId || '';
				var voteType  = btn.dataset.vote || '';     // 'like' | 'dislike'
				var nonce     = btn.dataset.nonce  || '';
				var card      = btn.closest('.zymarg-review-card');
				if (!card) return;

				var likeBtn    = card.querySelector('.zymarg-btn-like');
				var dislikeBtn = card.querySelector('.zymarg-btn-dislike');
				var countEl    = card.querySelector('.zymarg-like-count');

				// Determine current state.
				var wasActive = btn.classList.contains('is-active');

				var data = new FormData();
				data.set('action',      'zymarg_review_vote');
				data.set('_ajax_nonce', nonce);
				data.set('comment_id',  commentId);
				data.set('vote',        wasActive ? 'remove' : voteType); // toggle off if already active

				fetch(CFG.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: data })
					.then(function (r) { return r.json(); })
					.then(function (res) {
						if (!res || !res.success) return;

						var newVote   = res.vote || '';   // '' | 'like' | 'dislike'
						var likeCount = parseInt(res.likes || '0', 10);

						// Update like button state.
						if (likeBtn) {
							var likeActive = newVote === 'like';
							likeBtn.classList.toggle('is-active', likeActive);
							likeBtn.setAttribute('aria-pressed', likeActive ? 'true' : 'false');
							likeBtn.innerHTML = likeActive
								? '<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-2z"/></svg>'
								: '<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M9 21h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-2c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2zM9 9l4.34-4.34L12 10h9v2l-3 7H9V9zM1 9h4v12H1z"/></svg>';
						}

						// Update dislike button state.
						if (dislikeBtn) {
							var dislikeActive = newVote === 'dislike';
							dislikeBtn.classList.toggle('is-active', dislikeActive);
							dislikeBtn.setAttribute('aria-pressed', dislikeActive ? 'true' : 'false');
							dislikeBtn.innerHTML = dislikeActive
								? '<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M15 3H6c-.83 0-1.54.5-1.84 1.22l-3.02 7.05c-.09.23-.14.47-.14.73v2c0 1.1.9 2 2 2h6.31l-.95 4.57-.03.32c0 .41.17.79.44 1.06L9.83 23l6.59-6.59c.36-.36.58-.86.58-1.41V5c0-1.1-.9-2-2-2zm4 0v12h4V3h-4z"/></svg>'
								: '<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M15 3H6c-.83 0-1.54.5-1.84 1.22l-3.02 7.05c-.09.23-.14.47-.14.73v2c0 1.1.9 2 2 2h6.31l-.95 4.57-.03.32c0 .41.17.79.44 1.06L9.83 23l6.59-6.59c.36-.36.58-.86.58-1.41V5c0-1.1-.9-2-2-2zm0 12l-4.34 4.34L12 14H3v-2l3-7h9v10zm4-12h2v12h-2V3z"/></svg>';
						}

						// Update helpful count text.
						if (countEl) {
							if (likeCount > 0 || newVote === 'like') {
								countEl.textContent = 'Helpful (' + likeCount + ')';
								countEl.style.display = '';
							} else {
								countEl.textContent = '';
								countEl.style.display = 'none';
							}
						}

						// Update dislike count text.
						var dislikeCount = parseInt(res.dislikes || '0', 10);
						var dislikeCountEl = card.querySelector('.zymarg-dislike-count');
						if (dislikeCountEl) {
							if (dislikeCount > 0 || newVote === 'dislike') {
								dislikeCountEl.textContent = String(dislikeCount);
								dislikeCountEl.style.display = '';
							} else {
								dislikeCountEl.textContent = '';
								dislikeCountEl.style.display = 'none';
							}
						}
					})
					.catch(function () {});
			});
		});
	}

	/* ------------------------------------------------------------------
	 * Three dot menus — open/close dropdown
	 * ---------------------------------------------------------------- */
	function initDotsMenus(root) {
		var dotsBtns = root.querySelectorAll('.zymarg-btn-dots');
		dotsBtns.forEach(function (btn) {
			if (btn.dataset.dotsBound) return;
			btn.dataset.dotsBound = '1';

			btn.addEventListener('click', function (e) {
				e.stopPropagation();
				var dropdown = btn.nextElementSibling;
				if (!dropdown) return;
				var isOpen = dropdown.classList.contains('is-open');

				// Close all other open dropdowns first.
				root.querySelectorAll('.zymarg-dots-dropdown.is-open').forEach(function (d) {
					d.classList.remove('is-open');
					var b = d.previousElementSibling;
					if (b) b.setAttribute('aria-expanded', 'false');
				});

				if (!isOpen) {
					dropdown.classList.add('is-open');
					btn.setAttribute('aria-expanded', 'true');
				}
			});
		});

		// Close dropdowns when clicking outside.
		document.addEventListener('click', function () {
			root.querySelectorAll('.zymarg-dots-dropdown.is-open').forEach(function (d) {
				d.classList.remove('is-open');
				var b = d.previousElementSibling;
				if (b) b.setAttribute('aria-expanded', 'false');
			});
		});

		// Close on ESC key.
		document.addEventListener('keydown', function (e) {
			if (e.key === 'Escape') {
				root.querySelectorAll('.zymarg-dots-dropdown.is-open').forEach(function (d) {
					d.classList.remove('is-open');
					var b = d.previousElementSibling;
					if (b) { b.setAttribute('aria-expanded', 'false'); b.focus(); }
				});
			}
		});
	}

	/* ------------------------------------------------------------------
	 * Report Abuse modal
	 *
	 * The modal is built in JS and appended to document.body — NOT
	 * inside the widget div. This is critical because Elementor applies
	 * CSS transforms to sections/columns which create new stacking
	 * contexts, breaking position:fixed on any descendant element.
	 * By appending to body we guarantee position:fixed is relative to
	 * the viewport as intended.
	 * ---------------------------------------------------------------- */
	function initReportModal(root) {
		// Build modal once per page (shared across all widget instances).
		var modal = document.getElementById('zymarg-report-modal-global');
		if (!modal) {
			modal = document.createElement('div');
			modal.id        = 'zymarg-report-modal-global';
			modal.className = 'zymarg-report-modal-overlay';
			modal.setAttribute('role',       'dialog');
			modal.setAttribute('aria-modal', 'true');
			modal.setAttribute('aria-labelledby', 'zymarg-report-modal-title-global');
			modal.setAttribute('hidden', '');
			modal.innerHTML =
				'<div class="zymarg-report-modal">' +
					'<div class="zymarg-report-modal-icon" aria-hidden="true">' +
						'<svg width="40" height="40" viewBox="0 0 24 24" fill="currentColor"><path d="M1 21L12 2l11 19H1zm11-3h2v-2h-2v2zm0-4h2v-4h-2v4z"/></svg>' +
					'</div>' +
					'<h3 class="zymarg-report-modal-title" id="zymarg-report-modal-title-global">Report this review?</h3>' +
					'<p class="zymarg-report-modal-body">This review will be flagged for moderation. False reports may result in account restrictions.</p>' +
					'<div class="zymarg-report-modal-actions">' +
						'<button type="button" class="zymarg-report-modal-btn zymarg-report-modal-btn--danger zymarg-report-modal-confirm">Report Abuse</button>' +
						'<button type="button" class="zymarg-report-modal-btn zymarg-report-modal-btn--outline zymarg-report-modal-cancel">Cancel</button>' +
					'</div>' +
					'<div class="zymarg-report-modal-msg" role="status" aria-live="polite"></div>' +
				'</div>';
			document.body.appendChild(modal);

			// Wire cancel + outside-click + ESC once globally.
			modal.querySelector('.zymarg-report-modal-cancel').addEventListener('click', closeModal);
			modal.addEventListener('click', function (e) {
				if (e.target === modal) closeModal();
			});
			document.addEventListener('keydown', function (e) {
				if (e.key === 'Escape' && !modal.hasAttribute('hidden')) closeModal();
			});
		}

		var confirmBtn = modal.querySelector('.zymarg-report-modal-confirm');
		var modalMsg   = modal.querySelector('.zymarg-report-modal-msg');

		var pendingCommentId = null;
		var pendingNonce     = null;
		var pendingDotsItem  = null;

		function openModal(commentId, nonce, dotsItem) {
			pendingCommentId = commentId;
			pendingNonce     = nonce;
			pendingDotsItem  = dotsItem;
			if (modalMsg) { modalMsg.textContent = ''; modalMsg.className = 'zymarg-modal-msg'; }
			confirmBtn.disabled = false;
			confirmBtn.textContent = 'Report Abuse';
			modal.removeAttribute('hidden');
			document.body.style.overflow = 'hidden';
			setTimeout(function () { confirmBtn.focus(); }, 50);
		}

		function closeModal() {
			modal.setAttribute('hidden', '');
			document.body.style.overflow = '';
			pendingCommentId = null;
			pendingNonce     = null;
			pendingDotsItem  = null;
		}

		// Wire report buttons — including ones injected after Load More.
		function bindReportBtns() {
			root.querySelectorAll('.zymarg-dots-item--report').forEach(function (btn) {
				if (btn.dataset.reportBound) return;
				btn.dataset.reportBound = '1';

				btn.addEventListener('click', function (e) {
					e.stopPropagation();
					var dropdown = btn.closest('.zymarg-dots-dropdown');
					if (dropdown) {
						dropdown.classList.remove('is-open');
						var dotsBtn = dropdown.previousElementSibling;
						if (dotsBtn) dotsBtn.setAttribute('aria-expanded', 'false');
					}
					openModal(btn.dataset.commentId, btn.dataset.nonce, btn);
				});
			});
		}
		bindReportBtns();

		// Re-bind after Load More injects new cards.
		var feed = root.querySelector('.zymarg-feed');
		if (feed && window.MutationObserver) {
			var obs = new MutationObserver(function () { bindReportBtns(); });
			obs.observe(feed, { childList: true });
		}

		// Confirm — fire AJAX report.
		// We use a named handler so we can remove and re-add cleanly per widget.
		if (confirmBtn._zymargHandler) {
			confirmBtn.removeEventListener('click', confirmBtn._zymargHandler);
		}
		confirmBtn._zymargHandler = function () {
			if (!pendingCommentId || !CFG.ajaxUrl) return;

			confirmBtn.disabled      = true;
			confirmBtn.textContent   = (CFG.i18n && CFG.i18n.submitting) || 'Submitting…';
			if (modalMsg) { modalMsg.textContent = ''; modalMsg.className = 'zymarg-modal-msg'; }

			var data = new FormData();
			data.set('action',      'zymarg_report_review');
			data.set('_ajax_nonce', pendingNonce || '');
			data.set('comment_id',  pendingCommentId);

			fetch(CFG.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: data })
				.then(function (r) { return r.json(); })
				.then(function (res) {
					if (res && res.success) {
						if (pendingDotsItem) {
							var reported = document.createElement('span');
							reported.className = 'zymarg-dots-item zymarg-dots-item--reported';
							reported.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M4 6V20h2v-6h12l-2-4 2-4H6V6H4z"/></svg> Reported';
							pendingDotsItem.replaceWith(reported);
						}
						closeModal();
					} else {
						confirmBtn.disabled      = false;
						confirmBtn.textContent   = 'Report Abuse';
						if (modalMsg) {
							modalMsg.textContent = (res && res.message) || 'Something went wrong.';
							modalMsg.className   = 'zymarg-modal-msg is-error';
						}
					}
				})
				.catch(function () {
					confirmBtn.disabled    = false;
					confirmBtn.textContent = 'Report Abuse';
					if (modalMsg) {
						modalMsg.textContent = (CFG.i18n && CFG.i18n.genericErr) || 'Something went wrong.';
						modalMsg.className   = 'zymarg-modal-msg is-error';
					}
				});
		};
		confirmBtn.addEventListener('click', confirmBtn._zymargHandler);
	}
})();

/* --------------------------------------------------------------------------
   v1.1.17 - Review media gallery.

   Review photos used to be inert <img> tags with a cursor:pointer lie. They are
   now buttons that open a shared full-screen viewer spanning every photo and
   video attached to any approved review of the product, with the reviewer's
   context alongside each item.

   One overlay is built per page and shared by every widget instance, the same
   pattern the Report Abuse modal uses.
   -------------------------------------------------------------------------- */
(function () {
	'use strict';

	var overlay   = null;
	var items     = [];   // active (filtered) list
	var allItems  = [];   // full list for the current widget
	var index     = 0;
	var lastFocus = null;

	function el(tag, cls, html) {
		var n = document.createElement(tag);
		if (cls) n.className = cls;
		if (html !== undefined) n.innerHTML = html;
		return n;
	}

	function esc(str) {
		return String(str === undefined || str === null ? '' : str)
			.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
			.replace(/"/g, '&quot;');
	}

	function starsHtml(rating) {
		var out = '';
		for (var i = 1; i <= 5; i++) {
			out += '<svg class="zymarg-gallery__star--' + (i <= rating ? 'on' : 'off') + '" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">' +
				'<path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.81 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>';
		}
		return out;
	}

	function buildOverlay() {
		if (overlay) return overlay;

		overlay = el('div', 'zymarg-gallery-overlay');
		overlay.id = 'zymarg-gallery-overlay-global';
		overlay.setAttribute('role', 'dialog');
		overlay.setAttribute('aria-modal', 'true');
		overlay.setAttribute('aria-label', 'Customer photos and videos');
		overlay.hidden = true;
		overlay.innerHTML =
			'<div class="zymarg-gallery">' +
				'<div class="zymarg-gallery__head">' +
					'<h3 class="zymarg-gallery__title">Customer photos &amp; videos <span class="zymarg-gallery__count"></span></h3>' +
					'<select class="zymarg-gallery__select zymarg-gallery__filter" aria-label="Filter media"></select>' +
					'<select class="zymarg-gallery__select zymarg-gallery__sort" aria-label="Sort media">' +
						'<option value="recent">Newest first</option>' +
						'<option value="helpful">Most helpful</option>' +
					'</select>' +
					'<button type="button" class="zymarg-gallery__close" aria-label="Close gallery">' +
						'<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M19 6.41 17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>' +
					'</button>' +
				'</div>' +
				'<div class="zymarg-gallery__body">' +
					'<div class="zymarg-gallery__stage">' +
						'<button type="button" class="zymarg-gallery__nav zymarg-gallery__nav--prev" aria-label="Previous">' +
							'<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M15.41 7.41 14 6l-6 6 6 6 1.41-1.41L10.83 12z"/></svg></button>' +
						'<div class="zymarg-gallery__media"></div>' +
						'<button type="button" class="zymarg-gallery__nav zymarg-gallery__nav--next" aria-label="Next">' +
							'<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M10 6 8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"/></svg></button>' +
					'</div>' +
					'<aside class="zymarg-gallery__side"></aside>' +
				'</div>' +
				'<div class="zymarg-gallery__strip"></div>' +
			'</div>';

		document.body.appendChild(overlay);

		overlay.querySelector('.zymarg-gallery__close').addEventListener('click', close);
		overlay.querySelector('.zymarg-gallery__nav--prev').addEventListener('click', function () { step(-1); });
		overlay.querySelector('.zymarg-gallery__nav--next').addEventListener('click', function () { step(1); });
		overlay.addEventListener('click', function (e) { if (e.target === overlay) close(); });
		overlay.querySelector('.zymarg-gallery__filter').addEventListener('change', applyQuery);
		overlay.querySelector('.zymarg-gallery__sort').addEventListener('change', applyQuery);

		document.addEventListener('keydown', function (e) {
			if (overlay.hidden) return;
			if (e.key === 'Escape')     { e.preventDefault(); close(); }
			if (e.key === 'ArrowLeft')  { e.preventDefault(); step(-1); }
			if (e.key === 'ArrowRight') { e.preventDefault(); step(1); }
		});

		// Swipe on touch devices.
		var startX = null;
		var stage  = overlay.querySelector('.zymarg-gallery__stage');
		stage.addEventListener('touchstart', function (e) { startX = e.touches[0].clientX; }, { passive: true });
		stage.addEventListener('touchend', function (e) {
			if (startX === null) return;
			var dx = e.changedTouches[0].clientX - startX;
			if (Math.abs(dx) > 45) step(dx < 0 ? 1 : -1);
			startX = null;
		}, { passive: true });

		return overlay;
	}

	/* Build the filter dropdown from what the product actually has. */
	function buildFilterOptions() {
		var sel  = overlay.querySelector('.zymarg-gallery__filter');
		var vars = [];
		var rate = {};

		allItems.forEach(function (it) {
			if (it.variation && vars.indexOf(it.variation) === -1) vars.push(it.variation);
			rate[it.rating] = true;
		});

		var html = '<option value="all">All media</option>';

		if (vars.length) {
			html += '<optgroup label="Variation">';
			vars.forEach(function (v) { html += '<option value="var:' + esc(v) + '">' + esc(v) + '</option>'; });
			html += '</optgroup>';
		}

		var ratings = Object.keys(rate).sort(function (a, b) { return b - a; });
		if (ratings.length > 1) {
			html += '<optgroup label="Rating">';
			ratings.forEach(function (r) { html += '<option value="rate:' + r + '">' + r + ' star' + (r === '1' ? '' : 's') + '</option>'; });
			html += '</optgroup>';
		}

		sel.innerHTML = html;
		sel.value = 'all';
		overlay.querySelector('.zymarg-gallery__sort').value = 'recent';
	}

	function applyQuery(keepId) {
		var filter = overlay.querySelector('.zymarg-gallery__filter').value;
		var sort   = overlay.querySelector('.zymarg-gallery__sort').value;
		var currentId = typeof keepId === 'number' ? keepId : (items[index] ? items[index].id : null);

		items = allItems.filter(function (it) {
			if (filter.indexOf('var:')  === 0) return it.variation === filter.slice(4);
			if (filter.indexOf('rate:') === 0) return String(it.rating) === filter.slice(5);
			return true;
		});

		if (sort === 'helpful') {
			items = items.slice().sort(function (a, b) { return (b.likes || 0) - (a.likes || 0); });
		}

		// Stay on the same item across a filter change when it survives the filter.
		index = 0;
		if (currentId !== null) {
			for (var i = 0; i < items.length; i++) {
				if (items[i].id === currentId) { index = i; break; }
			}
		}
		render();
	}

	function stopVideo() {
		var v = overlay.querySelector('.zymarg-gallery__media video');
		if (v) { try { v.pause(); } catch (err) {} }
	}

	function render() {
		var media = overlay.querySelector('.zymarg-gallery__media');
		var side  = overlay.querySelector('.zymarg-gallery__side');
		var strip = overlay.querySelector('.zymarg-gallery__strip');
		var count = overlay.querySelector('.zymarg-gallery__count');

		stopVideo();

		if (!items.length) {
			media.innerHTML = '<p class="zymarg-gallery__empty">No media matches this filter.</p>';
			side.innerHTML  = '';
			strip.innerHTML = '';
			count.textContent = '(0)';
			return;
		}

		if (index < 0) index = items.length - 1;
		if (index >= items.length) index = 0;

		var it = items[index];
		count.textContent = '(' + (index + 1) + ' / ' + items.length + ')';

		media.innerHTML = it.type === 'video'
			? '<video src="' + esc(it.url) + '" controls playsinline preload="metadata"' + (it.thumb ? ' poster="' + esc(it.thumb) + '"' : '') + '></video>'
			: '<img src="' + esc(it.url) + '" alt="Review media from ' + esc(it.name) + '">';

		side.innerHTML =
			'<div class="zymarg-gallery__author">' +
				'<span class="zymarg-gallery__avatar">' + esc(it.initials || 'U') + '</span>' +
				'<span><span class="zymarg-gallery__name">' + esc(it.name) + '</span><br>' +
				'<span class="zymarg-gallery__date">' + esc(it.date) + '</span></span>' +
			'</div>' +
			'<div class="zymarg-gallery__stars" aria-label="Rated ' + esc(it.rating) + ' out of 5">' + starsHtml(it.rating) + '</div>' +
			(it.variation ? '<span class="zymarg-gallery__variation">' + esc(it.variation) + '</span>' : '') +
			(it.title ? '<h4 class="zymarg-gallery__reviewtitle">' + esc(it.title) + '</h4>' : '') +
			(it.body ? '<p class="zymarg-gallery__body-text">' + esc(it.body) + '</p>' : '') +
			'<div class="zymarg-gallery__meta">' +
				(it.verified ? '<span class="zymarg-gallery__verified">Verified buyer</span>' : '') +
				(it.likes ? '<span>' + esc(it.likes) + ' found helpful</span>' : '') +
			'</div>';

		var thumbs = '';
		items.forEach(function (item, i) {
			thumbs += '<button type="button" class="zymarg-gallery__thumb' + (i === index ? ' is-active' : '') + '" data-i="' + i + '" aria-label="Item ' + (i + 1) + '">' +
				(item.thumb ? '<img src="' + esc(item.thumb) + '" alt="">' : '<span class="zymarg-review-photo--blank"></span>') +
				(item.type === 'video' ? '<span class="zymarg-media-play"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg></span>' : '') +
				'</button>';
		});
		strip.innerHTML = thumbs;

		var active = strip.querySelector('.is-active');
		if (active && active.scrollIntoView) {
			active.scrollIntoView({ block: 'nearest', inline: 'center' });
		}
	}

	function step(dir) {
		if (!items.length) return;
		index += dir;
		render();
	}

	function open(data, startIndex, startId) {
		buildOverlay();
		lastFocus = document.activeElement;
		allItems  = data;
		buildFilterOptions();
		items = allItems.slice();

		index = 0;
		if (typeof startId === 'number') {
			for (var i = 0; i < items.length; i++) {
				if (items[i].id === startId) { index = i; break; }
			}
		} else if (typeof startIndex === 'number') {
			index = startIndex;
		}

		render();
		overlay.hidden = false;
		document.body.style.overflow = 'hidden';
		overlay.querySelector('.zymarg-gallery__close').focus();
	}

	function close() {
		if (!overlay || overlay.hidden) return;
		stopVideo();
		overlay.hidden = true;
		document.body.style.overflow = '';
		if (lastFocus && lastFocus.focus) lastFocus.focus();
	}

	// Thumbnail strip inside the viewer (delegated - the strip is re-rendered).
	document.addEventListener('click', function (e) {
		if (!overlay || overlay.hidden) return;
		var thumb = e.target.closest ? e.target.closest('.zymarg-gallery__thumb') : null;
		if (!thumb || !overlay.contains(thumb)) return;
		index = parseInt(thumb.getAttribute('data-i'), 10) || 0;
		render();
	});

	/* Public per-widget wiring, called from initWidget(). */
	window.zymargInitGallery = function (root) {
		var payload = root.querySelector('.zymarg-gallery-data');
		if (!payload) return;

		var data;
		try { data = JSON.parse(payload.textContent || '[]'); }
		catch (err) { return; }
		if (!data || !data.length) return;

		root.addEventListener('click', function (e) {
			if (!e.target.closest) return;

			// Strip tiles and the "see all" button carry an explicit index.
			var byIndex = e.target.closest('[data-gallery-index]');
			if (byIndex && root.contains(byIndex)) {
				e.preventDefault();
				open(data, parseInt(byIndex.getAttribute('data-gallery-index'), 10) || 0);
				return;
			}

			// Tiles inside review cards resolve by attachment id.
			var tile = e.target.closest('.zymarg-review-media');
			if (tile && root.contains(tile)) {
				e.preventDefault();
				open(data, 0, parseInt(tile.getAttribute('data-media-id'), 10) || 0);
			}
		});
	};
})();
