<?php
/**
 * Plugin Name: ZYMARG Template Pack
 * Plugin URI:  https://zymarg.com
 * Description: Registers the ZYMARG branded card template for use with ZYMARG WC Product Grid.
 * Version:     1.7.2
 * Author:      ZYMARG
 * Author URI:  https://zymarg.com
 * License:     GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: zymarg-template-pack
 *
 * Requires Plugins: woocommerce, zymarg-wc-product-grid
 *
 * @package Zymarg\TemplatePack
 */

defined( 'ABSPATH' ) || exit;

require_once plugin_dir_path( __FILE__ ) . 'includes/class-badge-resolver.php';
Zymarg_Template_Pack_Badge_Resolver::init();

/**
 * Register the ZYMARG card template with the Product Grid engine.
 *
 * Hooks into zymarg_wcpg_init — fires at the end of Plugin::init() after all
 * core subsystems are ready. This is the official hook for template registration. Template_Manager validates the slug and path —
 * any error is emitted as E_USER_WARNING to debug.log.
 *
 * Usage — shortcode:
 *   [zymarg_products card_template="zymarg" source="similar"]
 *
 * Usage — PHP / standalone plugin:
 *   \Zymarg\WCPG\Api\Public_API::render( [
 *       'config' => [
 *           'card'  => [ 'template' => 'zymarg' ],
 *           'query' => [ 'source'   => 'similar' ],
 *       ],
 *   ] );
 */
add_action(
	'zymarg_wcpg_init',
	static function () {

		if ( ! class_exists( '\Zymarg\WCPG\Templates\Template_Manager' ) ) {
			return;
		}

		\Zymarg\WCPG\Templates\Template_Manager::register_card(
			'zymarg',
			plugin_dir_path( __FILE__ ) . 'templates/product-card.php'
		);

		// Flash Sales card. Lives in its own directory because the engine
		// discovers a template's CSS and JS by looking beside its PHP file --
		// sharing templates/ would make both cards load the same assets.
		\Zymarg\WCPG\Templates\Template_Manager::register_card(
			'flash',
			plugin_dir_path( __FILE__ ) . 'templates/flash/product-card.php'
		);

	}
);

/**
 * ZYMARG card — sensible visibility defaults for every consumer.
 *
 * The ZYMARG card design is built around the sold-count and vendor rows, so
 * they should appear by default for all consumers (shortcode, direct PHP /
 * standalone plugins, page consumers) — matching what the Elementor widget
 * shows when its toggles are on. Consumers can still turn them off; explicit
 * intent always wins.
 *
 * Why the two-hook dance: after Config_Normalizer runs, every canonical card
 * key is present, so at the 'zymarg_product_grid_config' filter we can no
 * longer tell an explicit `false` from the framework default. We therefore
 * capture the RAW request config at 'zymarg_product_grid_render_request'
 * (fired before any merge) and consult it inside the config filter. Rendering
 * is synchronous and non-nested, so a request-scoped flag is safe.
 */
final class Zymarg_Template_Pack_Defaults {

	/**
	 * Which optional card flags the current consumer set explicitly.
	 *
	 * @var array<string,bool>
	 */
	private static $explicit = array();

	/**
	 * Wire up the capture action and the defaults filter.
	 */
	public static function init() {
		add_action( 'zymarg_product_grid_render_request', array( __CLASS__, 'capture_explicit' ), 10, 1 );
		add_filter( 'zymarg_product_grid_config', array( __CLASS__, 'apply_defaults' ), 10, 1 );
	}

	/**
	 * Record whether the consumer explicitly provided the optional card flags.
	 *
	 * @param array $args Raw render request arguments (pre-normalization).
	 */
	public static function capture_explicit( $args ) {
		$card = ( is_array( $args ) && isset( $args['config']['card'] ) && is_array( $args['config']['card'] ) )
			? $args['config']['card']
			: array();

		$slider = ( is_array( $args ) && isset( $args['config']['layout']['slider'] ) && is_array( $args['config']['layout']['slider'] ) )
			? $args['config']['layout']['slider']
			: array();

		$layout = ( is_array( $args ) && isset( $args['config']['layout'] ) && is_array( $args['config']['layout'] ) )
			? $args['config']['layout']
			: array();

		self::$explicit = array(
			'show_sold_count'        => array_key_exists( 'show_sold_count', $card ),
			'show_vendor'            => array_key_exists( 'show_vendor', $card ),
			'show_countdown'         => array_key_exists( 'show_countdown', $card ),
			'show_status_badge'      => array_key_exists( 'show_status_badge', $card ),
			'slider_pagination_type' => array_key_exists( 'pagination_type', $slider ),
			'slider_show_arrows'     => array_key_exists( 'show_arrows', $slider ),
			'layout_gap'             => array_key_exists( 'gap', $layout ),
		);
	}

	/**
	 * Default sold-count + vendor ON for the ZYMARG card unless set explicitly.
	 *
	 * @param array $config Fully-merged, validated config.
	 * @return array
	 */
	public static function apply_defaults( $config ) {
		if ( ! is_array( $config ) ) {
			return $config;
		}

		$template = isset( $config['card']['template'] ) ? (string) $config['card']['template'] : '';

		// v1.6.1: the flash card now shares the ZYMARG defaults for sold count,
		// status badge, countdown suppression and grid gap. Everything below that
		// is ZYMARG-only stays behind an explicit template check.
		if ( ! in_array( $template, array( 'zymarg', 'flash' ), true ) ) {
			return $config;
		}

		if ( empty( self::$explicit['show_sold_count'] ) ) {
			$config['card']['show_sold_count'] = true;
		}
		if ( 'zymarg' === $template && empty( self::$explicit['show_vendor'] ) ) {
			$config['card']['show_vendor'] = true;
		}

		// The ZYMARG card carries its own "Limited Offer" status badge, which
		// already communicates a time-limited sale. The engine countdown is
		// therefore suppressed here so the two never appear on the same card;
		// a dedicated flash-deals template renders the countdown instead.
		// v1.6.1: the same suppression now applies to the flash card, which
		// renders its own HH:MM:SS timer in the card footer. Without this, the
		// engine countdown and the card timer both appeared on flash cards.
		// Explicit intent still wins: show_countdown="yes" re-enables it.
		if ( empty( self::$explicit['show_countdown'] ) ) {
			$config['card']['show_countdown'] = 'no';
		}

		// Dynamic status badge ON by default for the ZYMARG card. It occupies
		// the leading slot of the rating/sold row and is what keeps that row
		// at a constant height for products with no rating and no sales.
		if ( empty( self::$explicit['show_status_badge'] ) ) {
			$config['card']['show_status_badge'] = true;
		}

		// v1.7.2: brand slider defaults, now shared by BOTH pack cards.
		// Progress-bar pagination + no arrows, unless
		// the consumer explicitly set them. Still fully overridable per instance
		// (e.g. in Elementor). The engine already provides a layout.slider
		// sub-array, so we only flip the two brand defaults here.
		if ( ! isset( $config['layout'] ) || ! is_array( $config['layout'] ) ) {
			$config['layout'] = array();
		}
		if ( ! isset( $config['layout']['slider'] ) || ! is_array( $config['layout']['slider'] ) ) {
			$config['layout']['slider'] = array();
		}
		// The flash card paints the progress bar with its own gradient; see
		// templates/flash/style.css. The ZYMARG card keeps the engine's
		// neutral bar. Loop needs no handling here: the engine forces it off
		// whenever free-scroll is on, which is its default.
		if ( empty( self::$explicit['slider_pagination_type'] ) ) {
			$config['layout']['slider']['pagination_type'] = 'progress';
		}
		if ( empty( self::$explicit['slider_show_arrows'] ) ) {
			$config['layout']['slider']['show_arrows'] = false;
		}

		// ZYMARG and flash grids use a slightly looser 8px gap (vs the engine's
		// 6px global default) for BOTH grid and slider layouts, unless the
		// consumer set gap explicitly. v1.6.1 extends this to the flash card so
		// the two templates space identically. Setting layout.gap drives the grid CSS (--grid-gap) and the
		// slider spaceBetween, which inherits layout.gap in engine v2.4.4+.
		if ( empty( self::$explicit['layout_gap'] ) ) {
			$config['layout']['gap'] = 8;
		}

		// Reset so a later grid on the same request re-evaluates from scratch.
		self::$explicit = array();

		return $config;
	}
}

Zymarg_Template_Pack_Defaults::init();
