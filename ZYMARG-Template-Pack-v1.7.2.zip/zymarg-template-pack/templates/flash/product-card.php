<?php
/**
 * ZYMARG Flash Sales card template.
 *
 * Part of the ZYMARG Template Pack standalone plugin.
 * Registered with the Product Grid engine via:
 *   Template_Manager::register_card( 'flash', __FILE__ )
 *
 * Built to match the approved Flash Sales Card mockup exactly. Its style.css
 * and script.js sit in this same directory and are picked up automatically by
 * the engine's Asset_Manager, which is why this card lives in its own folder
 * rather than beside the ZYMARG card.
 *
 * Layout:
 *
 *  Image container (1:1 ratio)
 *    - Flash badge:  top-left, bolt + "FLASH SALE - N% OFF"
 *    - Quick view:   top-right, desktop only
 *    - Wishlist:     bottom-right
 *
 *  Content box
 *    - Row 1: Title (2-line clamp)
 *    - Row 2: Status badge - rating - sold count
 *    - Row 3: Price (gradient) + old price
 *    - Row 4: Scarcity bar + inline circular ATC
 *    - Row 5: "Ends in HH:MM:SS" countdown
 *
 * Data contract
 * -------------
 * Every product reaching this template has passed Flash_Deals_Validator, so
 * the sale end date, managed stock and stock quantity are all guaranteed to
 * exist. That guarantee is what allows the scarcity bar and countdown to be
 * unconditional: the card's geometry never shifts between products, which was
 * the whole point of gating the source.
 *
 * The bar reports units sold *inside the current sale window*, not lifetime
 * sales, so a long-running product does not open its flash sale already
 * looking sold out. On day one the bar is genuinely empty - no invented
 * starting fill.
 *
 * Theme override: copy to theme/zymarg-wcpg/cards/flash/product-card.php
 *
 * @package Zymarg\TemplatePack
 *
 * @var \WC_Product $product
 * @var array       $settings
 * @var array       $config
 * @var int|string  $widget_id
 */

defined( 'ABSPATH' ) || exit;

if ( ! ( $product instanceof \WC_Product ) ) {
	return;
}

// -- Helper: truthy check for settings flags ---------------------------
$enabled = static function ( $value ): bool {
	return in_array( (string) $value, array( '1', 'yes', 'true' ), true );
};

// -- Visibility flags --------------------------------------------------
$show_image     = ! isset( $settings['show_image'] )        || $enabled( $settings['show_image'] );
$show_wishlist  = ! isset( $settings['show_wishlist'] )     || $enabled( $settings['show_wishlist'] );
$show_quickview = ! isset( $settings['show_quickview'] )    || $enabled( $settings['show_quickview'] );
$show_atc       = ! isset( $settings['show_atc'] )          || $enabled( $settings['show_atc'] );
$show_title     = ! isset( $settings['show_title'] )        || $enabled( $settings['show_title'] );
$show_rating    = ! isset( $settings['show_rating'] )       || $enabled( $settings['show_rating'] );
$show_sold      = ! isset( $settings['show_sold_count'] )   || $enabled( $settings['show_sold_count'] );
$show_price     = ! isset( $settings['show_price'] )        || $enabled( $settings['show_price'] );
$show_badge     = ! isset( $settings['show_status_badge'] ) || $enabled( $settings['show_status_badge'] );
$image_full     = isset( $settings['image_full_resolution'] ) && $enabled( $settings['image_full_resolution'] );

// -- Product data ------------------------------------------------------
$product_id = (int) $product->get_id();
$permalink  = $product->get_permalink();
$title      = $product->get_name();

$rating_count  = (int) $product->get_rating_count();
$rating_avg    = (float) $product->get_average_rating();
$render_rating = $show_rating && $rating_count > 0 && $rating_avg > 0;

// v1.6.1: the meta-row sold count is LIFETIME sales, identical to the ZYMARG
// card. The scarcity bar below still reports window sales - the two answer
// different questions and are deliberately not the same number.
$total_sales = (int) $product->get_total_sales();
$render_sold = $show_sold && $total_sales > 0;

// -- Discount percentage for the flash badge ---------------------------
$regular_price = (float) $product->get_regular_price();
$active_price  = (float) $product->get_price();
if ( $product->is_type( 'variable' ) ) {
	$regular_price = (float) $product->get_variation_regular_price( 'min', true );
	$active_price  = (float) $product->get_variation_price( 'min', true );
}
$discount_pct = ( $regular_price > 0 && $active_price < $regular_price )
	? (int) round( ( ( $regular_price - $active_price ) / $regular_price ) * 100 )
	: 0;

// -- Scarcity data -----------------------------------------------------
// Remaining stock aggregates every on-sale variation, because the bar
// represents the parent product as a single unit of scarcity.
$remaining = 0;
if ( $product->is_type( 'variable' ) ) {
	foreach ( $product->get_children() as $child_id ) {
		$variation = wc_get_product( $child_id );
		if ( $variation instanceof \WC_Product && $variation->is_on_sale() ) {
			$remaining += max( 0, (int) $variation->get_stock_quantity() );
		}
	}
} else {
	$remaining = max( 0, (int) $product->get_stock_quantity() );
}

$window_start = 0;
if ( class_exists( '\Zymarg\WCPG\Trending\Flash_Sales_Counter' ) ) {
	$window_start = (int) \Zymarg\WCPG\Trending\Flash_Sales_Counter::window_start_for( $product );
}

/**
 * Filter the start of the sale window the scarcity bar measures "sold" against.
 *
 * The engine resolves this from WooCommerce's sale-from date, which is correct
 * for engine-sourced flash deals. A plugin running its own flash-sale feature
 * on its own meta — the Vendor Dashboard's Premium Flash Sale, for one — stores
 * the window elsewhere and can supply it here.
 *
 * This matters more than it looks. Flash_Sales_Counter::window_start_for()
 * falls back to the product's CREATED date when no sale-from date exists, so a
 * product whose window lives outside WooCommerce would have its entire lifetime
 * of sales counted as "sold in this sale". An older product would open its
 * flash sale with the bar already near full. An empty bar is honest; a full one
 * is a fabrication, and this card exists partly to avoid exactly that.
 *
 * Return 0 to leave the bar empty.
 *
 * @since 1.7.0
 *
 * @param int         $window_start UNIX timestamp, 0 when unknown.
 * @param \WC_Product $product      Product being rendered.
 */
$window_start = (int) apply_filters( 'zymarg_pack_flash_window_start', $window_start, $product );

$window_sold = 0;
if ( $window_start > 0 && class_exists( '\Zymarg\WCPG\Trending\Flash_Sales_Counter' ) ) {
	$window_sold = (int) \Zymarg\WCPG\Trending\Flash_Sales_Counter::get_sold( $product_id, $window_start );
}

$stock_total = $window_sold + $remaining;
$stock_pct   = $stock_total > 0 ? ( $window_sold / $stock_total ) * 100 : 0;
$stock_pct   = max( 0, min( 100, $stock_pct ) );

// -- Countdown ---------------------------------------------------------
$end_ts = 0;
if ( class_exists( '\Zymarg\WCPG\Query\Source_Flash_Deals' ) ) {
	$end_ts = (int) \Zymarg\WCPG\Query\Source_Flash_Deals::end_ts_for( $product );
}

/**
 * Filter the sale end timestamp the countdown counts down to.
 *
 * Source_Flash_Deals resolves this through WooCommerce's on-sale state and
 * sale-to date. A plugin that runs its own flash sale on its own meta — the
 * Vendor Dashboard's Premium Flash Sale applies its price at runtime and
 * deliberately never writes _sale_price — returns 0 from that lookup, and can
 * supply its own end date here instead.
 *
 * Return 0 to hide the countdown entirely rather than show a wrong one.
 *
 * @since 1.7.0
 *
 * @param int         $end_ts  UNIX timestamp, 0 when there is no known end.
 * @param \WC_Product $product Product being rendered.
 */
$end_ts = (int) apply_filters( 'zymarg_pack_flash_end_ts', $end_ts, $product );

$now_ts = time();

// -- Status badge ------------------------------------------------------
// 'limited_offer' is skipped here: it would win on every flash product and
// simply restate the countdown sitting directly below it.
$status_badge = null;
if ( $show_badge && class_exists( 'Zymarg_Template_Pack_Badge_Resolver' ) ) {
	$status_badge = Zymarg_Template_Pack_Badge_Resolver::resolve( $product, $settings, array( 'limited_offer' ) );
}

// -- Wishlist state ----------------------------------------------------
$is_wished = false;
if ( class_exists( '\Zymarg\WCPG\Wishlist\Wishlist_Store' ) && method_exists( '\Zymarg\WCPG\Wishlist\Wishlist_Store', 'has' ) ) {
	$is_wished = (bool) \Zymarg\WCPG\Wishlist\Wishlist_Store::has( $product_id );
}

// -- ATC label ---------------------------------------------------------
$is_simple_purchasable = $product->is_type( 'simple' ) && $product->is_purchasable() && $product->is_in_stock();
$atc_label             = $is_simple_purchasable
	? __( 'Add to cart', 'zymarg-template-pack' )
	: ( $product->is_type( 'variable' )
		? __( 'Select options', 'zymarg-template-pack' )
		: __( 'Read more', 'zymarg-template-pack' ) );

// -- Card classes ------------------------------------------------------
$card_classes = array( 'zymarg-wcpg__card', 'zymarg-wcpg__card--flash', 'zymarg-wcpg__card--' . $product->get_type() );
if ( ! $product->is_in_stock() ) {
	$card_classes[] = 'is-oos';
}
$card_classes = (array) apply_filters( 'zymarg_card_classes', $card_classes, $product, $settings );

$extra_attrs      = (array) apply_filters( 'zymarg_card_attributes', array(), $product, $settings );
$extra_attrs_html = '';
foreach ( $extra_attrs as $attr_name => $attr_value ) {
	$extra_attrs_html .= ' ' . esc_attr( $attr_name ) . '="' . esc_attr( $attr_value ) . '"';
}

// v1.6.1: capture the card markup so the zymarg_card_html filter runs here too.
// The ZYMARG card has always exposed this filter; the flash card did not, so any
// theme or plugin that decorates cards through it (toasts, badges, tracking
// attributes) silently skipped flash cards.
ob_start();

do_action( 'zymarg_before_card', $product, $settings );
?>

<div class="<?php echo esc_attr( implode( ' ', $card_classes ) ); ?>"
	data-product-id="<?php echo esc_attr( $product_id ); ?>"
	<?php // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo $extra_attrs_html; ?>>

	<div class="zymarg-zc__inner">

		<?php do_action( 'zymarg_before_card_image', $product, $settings ); ?>

		<?php if ( $show_image ) : ?>
			<div class="zymarg-zc__image-wrap">

				<?php // Flash badge - bolt inlined because the engine icon map has no fa-bolt and the pack enqueues no Font Awesome. ?>
				<span class="zymarg-zc__badge--flash">
					<svg class="zymarg-zc__badge-bolt" viewBox="0 0 320 512" aria-hidden="true" focusable="false"><path d="M296 160H180.6l42.6-129.8C227.2 15 215.7 0 200 0H56C44 0 33.8 8.9 32.2 20.8l-32 240C-1.7 275.2 9.5 288 24 288h118.7L96.6 482.5c-3.6 15.2 8 29.5 23.3 29.5 8.4 0 16.4-4.4 20.8-12l176-304c9.3-15.9-2.2-36-20.7-36z"/></svg>
					<?php
					if ( $discount_pct > 0 ) {
						echo esc_html(
							sprintf(
								/* translators: %d: discount percentage */
								__( 'Flash Sale - %d%% Off', 'zymarg-template-pack' ),
								$discount_pct
							)
						);
					} else {
						echo esc_html__( 'Flash Sale', 'zymarg-template-pack' );
					}
					?>
				</span>

				<?php if ( $show_quickview ) : ?>
					<?php
					// v1.6.1: honour the widget's Quick View visibility / display
					// settings, mirroring the ZYMARG card contract. The stylesheet
					// reads these two attributes.
					$qv_visibility = isset( $settings['quickview_visibility'] ) ? (string) $settings['quickview_visibility'] : 'desktop';
					if ( ! in_array( $qv_visibility, array( 'desktop', 'tablet', 'mobile', 'desktop_tablet', 'tablet_mobile', 'all' ), true ) ) {
						$qv_visibility = 'desktop';
					}
					$qv_display = isset( $settings['quickview_display'] ) ? (string) $settings['quickview_display'] : 'hover_only';
					if ( ! in_array( $qv_display, array( 'hover_only', 'always' ), true ) ) {
						$qv_display = 'hover_only';
					}
					?>
					<button type="button"
						class="zymarg-zc__icon-btn zymarg-zc__icon-btn--qv"
						data-action="quickview"
						data-product-id="<?php echo esc_attr( $product_id ); ?>"
						data-qv-visibility="<?php echo esc_attr( $qv_visibility ); ?>"
						data-qv-display="<?php echo esc_attr( $qv_display ); ?>"
						aria-label="<?php esc_attr_e( 'Quick view', 'zymarg-template-pack' ); ?>">
						<i class="far fa-eye" aria-hidden="true"></i>
					</button>
				<?php endif; ?>

				<a class="zymarg-zc__image-link"
					href="<?php echo esc_url( $permalink ); ?>"
					aria-label="<?php echo esc_attr( $title ); ?>">
					<?php
					$image_size = $image_full ? 'full' : 'woocommerce_thumbnail';
					$image_id   = (int) $product->get_image_id();
					if ( $image_id ) {
						echo wp_get_attachment_image(
							$image_id,
							$image_size,
							false,
							array(
								'class'    => 'zymarg-zc__image',
								'loading'  => 'lazy',
								'decoding' => 'async',
								'alt'      => esc_attr( $title ),
							)
						);
					} else {
						echo wc_placeholder_img( $image_size, array( 'class' => 'zymarg-zc__image' ) );
					}
					?>
				</a>

				<?php if ( $show_wishlist ) : ?>
					<button type="button"
						class="zymarg-zc__icon-btn zymarg-zc__icon-btn--wishlist"
						data-action="wishlist-toggle"
						data-product-id="<?php echo esc_attr( $product_id ); ?>"
						aria-label="<?php echo esc_attr( $is_wished
							? __( 'Remove from wishlist', 'zymarg-template-pack' )
							: __( 'Add to wishlist', 'zymarg-template-pack' )
						); ?>"
						aria-pressed="<?php echo $is_wished ? 'true' : 'false'; ?>">
						<span class="zymarg-wcpg__icon-idle">
							<i class="far fa-heart" aria-hidden="true"></i>
						</span>
						<span class="zymarg-wcpg__icon-active">
							<i class="fas fa-heart" aria-hidden="true"></i>
						</span>
					</button>
				<?php endif; ?>

			</div>
		<?php endif; ?>

		<?php do_action( 'zymarg_after_card_image', $product, $settings ); ?>

		<div class="zymarg-zc__body">

			<?php do_action( 'zymarg_before_card_title', $product, $settings ); ?>
			<?php if ( $show_title ) : ?>
				<div class="zymarg-zc__row zymarg-zc__row--title">
					<a class="zymarg-zc__title-link" href="<?php echo esc_url( $permalink ); ?>">
						<h3 class="zymarg-zc__title"><?php echo esc_html( $title ); ?></h3>
					</a>
				</div>
			<?php endif; ?>
			<?php do_action( 'zymarg_after_card_title', $product, $settings ); ?>

			<?php // Row 2: badge - rating - sold. The badge guarantees this row is never empty. ?>
			<?php if ( $status_badge || $render_rating || $render_sold ) : ?>
				<div class="zymarg-zc__row zymarg-zc__row--meta">

					<?php if ( $status_badge ) : ?>
						<span class="zymarg-zc__status-badge" data-badge="<?php echo esc_attr( $status_badge['key'] ); ?>" data-tier="<?php echo esc_attr( $status_badge['tier'] ); ?>"><?php echo esc_html( $status_badge['label'] ); ?></span>
					<?php endif; ?>

					<?php if ( $status_badge && ( $render_rating || $render_sold ) ) : ?>
						<span class="zymarg-zc__divider" aria-hidden="true"></span>
					<?php endif; ?>

					<?php if ( $render_rating ) :
						$fill_pct   = min( 100, max( 0, ( $rating_avg / 5 ) * 100 ) );
						$aria_label = sprintf(
							/* translators: %s: numeric rating average */
							__( 'Rated %s out of 5', 'zymarg-template-pack' ),
							number_format_i18n( $rating_avg, 1 )
						);
						?>
						<?php // v1.6.2: desktop shows the five-star bar + numeric average, like ZYMARG. ?>
						<div class="zymarg-zc__rating zymarg-zc__rating--full" aria-label="<?php echo esc_attr( $aria_label ); ?>">
							<span class="zymarg-zc__stars" aria-hidden="true">
								<span class="zymarg-zc__stars-fill" style="width:<?php echo esc_attr( $fill_pct ); ?>%;"></span>
							</span>
							<span class="zymarg-zc__rating-avg"><?php echo esc_html( number_format_i18n( $rating_avg, 1 ) ); ?></span>
						</div>
						<?php // Tablet / mobile keep the single-star compact form. ?>
						<div class="zymarg-zc__rating zymarg-zc__rating--compact" aria-label="<?php echo esc_attr( $aria_label ); ?>">
							<span class="zymarg-zc__star-icon" aria-hidden="true">&#9733;</span>
							<span class="zymarg-zc__rating-avg"><?php echo esc_html( number_format_i18n( $rating_avg, 1 ) ); ?></span>
						</div>
					<?php endif; ?>

					<?php if ( $render_rating && $render_sold ) : ?>
						<span class="zymarg-zc__divider" aria-hidden="true"></span>
					<?php endif; ?>

					<?php if ( $render_sold ) : ?>
						<span class="zymarg-zc__sold">
							<?php echo esc_html( sprintf(
								/* translators: %s: number of units sold */
								__( 'Sold %s', 'zymarg-template-pack' ),
								number_format_i18n( $total_sales )
							) ); ?>
						</span>
					<?php endif; ?>

				</div>
			<?php endif; ?>

			<?php do_action( 'zymarg_before_card_price', $product, $settings ); ?>
			<?php if ( $show_price ) : ?>
				<div class="zymarg-zc__row zymarg-zc__row--price">
					<?php \Zymarg\WCPG\Product_Data::render_price( $product ); ?>
				</div>
			<?php endif; ?>
			<?php do_action( 'zymarg_after_card_price', $product, $settings ); ?>

			<?php // Row 4: scarcity bar + inline ATC. ?>
			<div class="zymarg-zc__row4-atc-wrap">

				<div class="zymarg-zc__stock-wrap">
					<div class="zymarg-zc__stock-track"
						role="progressbar"
						aria-valuemin="0"
						aria-valuemax="100"
						aria-valuenow="<?php echo esc_attr( (int) round( $stock_pct ) ); ?>">
						<div class="zymarg-zc__stock-fill" style="width:<?php echo esc_attr( round( $stock_pct, 2 ) ); ?>%;"></div>
					</div>
					<div class="zymarg-zc__stock-labels">
						<span><?php echo esc_html( sprintf(
							/* translators: %s: number of units sold in this sale */
							__( '%s Sold', 'zymarg-template-pack' ),
							number_format_i18n( $window_sold )
						) ); ?></span>
						<span class="zymarg-zc__stock-urgent"><?php echo esc_html( sprintf(
							/* translators: %s: number of units remaining */
							__( '%s Left', 'zymarg-template-pack' ),
							number_format_i18n( $remaining )
						) ); ?></span>
					</div>
				</div>

				<?php if ( $show_atc ) : ?>
					<?php do_action( 'zymarg_before_add_to_cart', $product, $settings ); ?>
					<a class="zymarg-zc__atc-btn-inline"
						href="<?php echo esc_url( $permalink ); ?>"
						data-action="add-to-cart"
						data-product-id="<?php echo esc_attr( $product_id ); ?>"
						data-product-type="<?php echo esc_attr( $product->get_type() ); ?>"
						aria-label="<?php echo esc_attr( $atc_label ); ?>">
						<svg viewBox="0 0 448 512" aria-hidden="true" focusable="false"><path d="M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32v144H48c-17.7 0-32 14.3-32 32s14.3 32 32 32h144v144c0 17.7 14.3 32 32 32s32-14.3 32-32V288h144c17.7 0 32-14.3 32-32s-14.3-32-32-32H256V80z"/></svg>
					</a>
					<?php do_action( 'zymarg_after_add_to_cart', $product, $settings ); ?>
				<?php endif; ?>

			</div>

			<?php // Row 5: countdown. Fixed HH:MM:SS, ticked by this card's own script.js. ?>
			<?php if ( $end_ts > $now_ts ) : ?>
				<div class="zymarg-zc__row zymarg-zc__row--footer">
					<span class="zymarg-zc__timer-inline">
						<svg class="zymarg-zc__timer-icon" viewBox="0 0 320 512" aria-hidden="true" focusable="false"><path d="M296 160H180.6l42.6-129.8C227.2 15 215.7 0 200 0H56C44 0 33.8 8.9 32.2 20.8l-32 240C-1.7 275.2 9.5 288 24 288h118.7L96.6 482.5c-3.6 15.2 8 29.5 23.3 29.5 8.4 0 16.4-4.4 20.8-12l176-304c9.3-15.9-2.2-36-20.7-36z"/></svg>
						<span class="zymarg-zc__timer-text-shimmer">
							<?php esc_html_e( 'Ends in', 'zymarg-template-pack' ); ?>
							<strong class="zymarg-zc__timer-val"
								data-ends="<?php echo esc_attr( $end_ts ); ?>"
								data-now="<?php echo esc_attr( $now_ts ); ?>">--:--:--</strong>
						</span>
					</span>
				</div>
			<?php endif; ?>

		</div>

	</div>
</div>

<?php
do_action( 'zymarg_after_card', $product, $settings );

$_zymarg_flash_card_html = ob_get_clean();

// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
echo apply_filters( 'zymarg_card_html', $_zymarg_flash_card_html, $product, $settings );
?>
