=== ZYMARG Reviews Engine ===
Contributors: zymarg
Requires at least: 6.0
Tested up to: 6.6
Requires PHP: 8.0
Stable tag: 1.0.8
License: GPLv2 or later

The review engine behind the ZYMARG plugins: data, settings, submission, media, moderation and rendering, in one place.

== Description ==

ZYMARG Reviews Engine owns everything about product reviews. Other plugins — ZYMARG Single Product, ZYMARG Single Store, or your own — simply place the section and the engine renders it.

**What the engine owns**

* Review data: ratings, breakdowns, verified-purchase state, helpful votes, store replies
* Submission: the form, validation, eligibility rules, the review window
* Media: photo and video uploads, the customer media strip and the full-screen gallery
* Moderation: reported reviews, report reasons, auto-unapprove threshold, notifications
* Presentation: the markup, the stylesheet and the front-end script
* Settings: one control page with eight tabs, saved over AJAX with no page reload

**How consumers place it**

Shortcode, for pages, page builders and widget areas:

`[zymarg_reviews]`
`[zymarg_reviews product_id="13" layout="compact" limit="5" show_form="no"]`

PHP, for plugins and templates:

`if ( function_exists( 'zymarg_reviews_render' ) ) { zymarg_reviews_render( array( 'product_id' => $product_id ) ); }`

Data only, if you want to build your own presentation:

`$data = zymarg_reviews_get_data( array( 'product_id' => $product_id ) );`

**Restyling without forking**

The stylesheet is built on CSS custom properties. Redefine the tokens in your own theme or consumer plugin and the whole section follows. For full markup control, filter `zymarg_reviews_template_path`.

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/` and activate it.
2. On activation the engine copies any existing review settings out of ZYMARG Single Product.
3. Open **ZYMARG Reviews** in the admin menu to review the settings.

While ZYMARG Single Product 1.x is active it keeps rendering reviews with its own embedded copy and the engine stays in settings-only mode, so nothing is ever registered twice. Update to Single Product 2.0 to hand rendering over to the engine.

== Frequently Asked Questions ==

= Will I lose existing reviews? =

No. Reviews are WordPress comments with meta; the engine reads exactly the same data. Only settings are migrated.

= Can two plugins show reviews on the same page? =

Yes. Assets and nonces are registered once per request no matter how many placements there are.

= Does uninstalling delete my reviews? =

Never. Uninstall can remove this plugin's own settings only, and only if you opt in under Advanced.

== Roadmap ==

The full build plan for the next release (v1.1.0 - vendor scoping and the Dokan
store-page consumer) ships inside this plugin at:

    docs/PHASE-3-PLAN.md

It is parked until explicitly called for. Three decisions listed in section 10
of that document must be answered before any code is written.

== Changelog ==

= 1.0.8 =
* Fixed: after successfully submitting a gated "Write a Review" link, the review form could reappear if the page was reloaded, because the URL still carried its zymarg_review / order_id / item_id / _nonce query params and #zymarg-write-review hash. The form now strips those from the address bar (via history.replaceState, no reload) right after a successful submission, so reloading or revisiting that same link can never re-reveal the form.

= 1.0.6 — The engine can place itself =
* New: Placement tab. The engine can now print the review section itself instead of waiting for a consumer plugin's template to call zymarg_reviews_render(). Pick an anchor hook, a priority, and whether to wrap the section in an accordion.
* Why: a consumer such as ZYMARG Single Product can be frozen permanently. With placement set to Hook, a new review feature ships with an engine update and needs no consumer release.
* New: Anchor hooks are an allowlist, offered as a dropdown, covering the ZYMARG Single Product hooks plus two WooCommerce hooks so placement also works on themes that do not use Single Product. Themes can add their own through the zymarg_reviews_placement_hooks filter, which extends the dropdown and the save allowlist together.
* New: Shortcode placement mode, for sites that want to change the section's arguments without any code. Only the zymarg_reviews tag is accepted and an unusable value falls back to the normal renderer, so a typo in the field cannot take reviews off the site.
* New: The engine now enqueues its own front-end assets on product pages when it is placing the section. Previously the stylesheet reached wp_head only because ZYMARG Single Product enqueued it, so a site without that plugin got a flash of unstyled reviews.
* New: zymarg_reviews_available(), zymarg_reviews_version() and zymarg_reviews_is_placing_itself(). Consumers should prefer the first over function_exists( 'zymarg_reviews_render' ), which stays true even when the engine is running in settings-only mode behind a legacy embedded copy and will deliberately render nothing.
* Fix: The renderer now refuses to print the same scope twice in one request. A site with both a consumer template call and an engine placement active previously produced two review sections, with duplicate DOM ids, two Load More buttons paginating the same feed and doubled schema. Override with the zymarg_reviews_allow_duplicate filter.
* New: Admin warning when the engine is placing the section while ZYMARG Single Product is still set to render its own accordion, because in that case the surviving section is the consumer's.
* Note: Placement defaults to Off. Updating the engine changes nothing about what an existing site prints until an administrator picks a mode.
* Note: The accordion label counts approved top-level reviews only. Since 1.0.4 replies are stored as child comments, so the WordPress comment count would report a product with 12 reviews and 19 replies as "Reviews (31)".

= 1.0.5 — Reply limits are admin settings =
* New: "Customer replies per review" and "Seller replies per review". How many times one user may reply to the same review. 0 means unlimited. Set the seller value to 1 for exactly one official answer per review.
* New: The flood guard is now configurable — replies per window, window length in minutes, and whether it applies to sellers as well as customers. 0 replies turns it off.
* Fix: 1.0.4 hardcoded the guard at five replies per ten minutes, reachable only through a PHP filter. There was no way to change it from the admin screen, and it was a rate limit rather than a per-review cap, so it did not answer "how many times can someone reply".
* Fix: 1.0.4 exempted sellers and shop managers from any limit at all. They now have their own per-review cap, and can optionally be included in the flood guard.
* New: Replies awaiting approval count towards a user's allowance, so a moderated account cannot queue an unlimited number.
* New: The reply form disappears once a user has used up their allowance on a review, instead of offering a form the handler would reject.
* Note: Both limits default to unlimited, matching how replies behaved in 1.0.4, so upgrading imposes no new cap. The caps are enforced in the AJAX handler as well as in the templates.

= 1.0.4 — Interactions, each behind its own toggle =
* New: Interactions tab in the settings screen. Every behaviour below has its own switch, so the whole layer can be turned off again without touching markup or losing data.
* New: Review visibility — everyone (default) or logged-in users only. The Load More endpoint honours it too, so a guest cannot page through reviews the first paint refused to show.
* New: Reactions toggle for the helpful / not helpful buttons.
* Fix: A guest who clicked a reaction button got a bare "Unauthorized." Reactions are stored per user account, so a guest could never record one. Guests are now either asked to log in (default) or the buttons are hidden from them.
* New: Customers can reply to reviews, off by default. Replies are plain text, limited to five per user per ten minutes, and either publish immediately or wait for approval.
* New: Sellers can reply toggle. Seller replies now also work for the vendor who owns the product being reviewed — previously the check required manage_woocommerce or moderate_comments, which a marketplace vendor does not normally hold, so actual sellers were excluded from their own reviews.
* New: Seller replies are pinned above customer replies, on first paint, after Load More, and when one is posted without a reload. Toggleable.
* New: Replies are one level deep by design. A reply can only attach to a review, never to another reply.
* New: The "Write a Review" button in My Account, on completed orders within the review window, per line item, plus a matching action on the orders list. Review_Tracker already built and validated the signed per-item review URL, but nothing handed it to the buyer, so `get_review_url()` had no callers and the button label settings had no readers. Toggleable.
* Change: Reply bodies are sanitised to plain text on save, for sellers as well as customers. Replies stored before 1.0.4 keep rendering exactly as they did, so no existing content changes appearance.
* Note: Every toggle is enforced in the AJAX handlers as well as the templates. Hiding a button does not close an endpoint.
* Note: Defaults reproduce 1.0.3 behaviour. Upgrading changes nothing on the front end except the new My Account button and the guest reaction message.

= 1.0.3 — Store-wide reviews work from the shortcode =
* Fix: [zymarg_reviews vendor_id="42"] rendered nothing at all. The data layer has supported store-wide scope since 1.0.2, but the renderer and the shortcode did not, so a documented attribute failed silently. It now renders that vendor's reviews.
* New: The renderer accepts vendor_id and page, so any theme or plugin can show a store-wide feed without duplicating the query.
* Note: Store-wide scope is deliberately read only. A feed spanning many products has no single product to review, so no form is shown there. Writing a review stays on the product page, where the purchase check is meaningful.
* Fix: The template read product brand, title, price, image, average rating and review count without checking they exist. Under store-wide scope those keys are absent, which would have produced PHP notices on PHP 8.

= 1.0.2 — Store-wide (vendor) scope =
* New: `zymarg_reviews_get_data()` now accepts a `vendor_id`, returning a read-only, store-wide data set aggregated across every published product that vendor owns. It takes precedence over `product_id`, and carries no form state — a store page displays reviews, it does not collect them.
* New: `Data_Builder::vendor_aggregate()` computes the average, the review count and the full star distribution in a single grouped query, cached for six hours per vendor.
* New: `Data_Builder::build_vendor()` returns a paginated review feed. Each entry adds the product it was written about (`product_id`, `product_title`, `product_url`, `product_image`), since a store feed spans the whole catalogue.
* New: `page` argument for paging the vendor feed, plus `total_pages` and `has_more` in the payload.
* New: `zymarg_reviews_vendor_product_ids` filter, for marketplaces where product ownership is not `post_author`.
* New: The cached vendor aggregate is flushed when a review is inserted, edited, approved, unapproved or deleted, so a store's score never lags the reviews printed beneath it.
* Note: `review_count` counts rated reviews only, so it always matches the denominator of the average. `total_reviews` is the size of the feed, which also includes reviews left without a star rating.

= 1.0.1 =
* Fix: A review whose `rating` meta was missing or zero was rendered as a five-star review. The fallback in `Data_Builder` read `$rating > 0 ? $rating : 5`, which silently invented a perfect score and inflated every aggregate built on top of it. A missing rating is now reported as `0` and rendered as unrated.
* Change: `reviews_form_visibility` now offers only "Verified buyers only". The submission handler has always required a valid order, order item and URL nonce, so the "Always visible" and "Any logged-in customer" options rendered a form that could never be submitted. Sites that had either value stored fall back to the gated default on next save.

= 1.0.0 =
* First release. Extracted from the ZYMARG Single Product reviews module into a standalone engine.
* New: own settings store with an eight-tab AJAX control page (General, Display, Review Form, Media, Submission, Moderation, Emails, Advanced).
* New: public API — `zymarg_reviews_render()`, `zymarg_reviews_get_data()`, `zymarg_reviews_get_setting()`, `zymarg_reviews_enqueue()`.
* New: `[zymarg_reviews]` shortcode with per-placement layout, limit and component arguments.
* New: one-time settings migration from `zymarg_sp_settings`.
* New: settings export/import and reset.
* Compatibility: stands down automatically while an older embedded copy of the reviews code is active.
