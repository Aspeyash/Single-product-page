# ZYMARG WC Product Grid — Architecture Plan

> **Last updated:** v2.2.0
> **Status as of this version:** Milestones 1–6 complete + Template Registry API complete and **verified working end-to-end** (v2.0.5–v2.1.0)
>
> **v2.1.0 note on Milestones 7 and 10.** Both were previously marked complete,
> but an audit found the external template path was never functional: card
> templates registered by a standalone plugin resolved to a mangled path and
> silently rendered as empty strings, and their stylesheets were never
> enqueued. The API existed and validated correctly; only rendering was
> broken. v2.1.0 fixes the resolution path and asset lookup, so
> "Independent Template Plugins" is now demonstrated rather than assumed.
> **Purpose:** Permanent reference for architectural decisions, progress tracking,
> and implementation order. Update the status markers and "Last updated" line
> when a milestone or step is completed.

---

## Why This Architecture Exists

The entire point of this plan is to build **one consistent product grid engine that every part of the ZYMARG site can use — without duplicating logic anywhere**.

Before this architecture, every place that displayed products (Elementor widget, search results, store pages, category pages, etc.) had its own query logic, its own rendering logic, and its own template loading. That meant bugs had to be fixed in multiple places, behaviour was inconsistent across the site, and adding a new feature (like a new card component or a new query source) required touching many files.

This architecture solves that by routing everything through a single Public API:

- **Queries** — one Query Engine, one set of sources
- **Rendering** — one Render Engine, one set of templates
- **Configuration** — one canonical config schema, one normalizer
- **Assets** — one Asset Manager (Milestone 5)
- **Templates** — one Template Registry

So whether the product grid is rendered by Elementor, a shortcode, a REST call, a future Single Product Template plugin, or a Store Template plugin — they all call the same engine:

```php
Public_API::render([
    'slot'    => 'related-products',
    'context' => [ 'product_id' => 123 ],
]);
```

Nothing else. No duplicated queries. No duplicated rendering. No inconsistent output.

**The result:** consistent behaviour across the entire marketplace, bugs fixed in one place, new features added once and available everywhere, and long-term maintenance that stays sane as the ZYMARG ecosystem grows.

---

## What the Elementor_Settings_Adapter Changes (v1.6.5)

This is the biggest architectural change in Milestone 4. Before v1.6.5, Elementor
was inside the rendering pipeline — the widget's `render()` method called
`Query_Builder::get_products($settings)` directly using raw Elementor control
keys, and passed those same keys into `Template_Loader`. Elementor was not a
consumer of the engine; it was tangled into it.

After v1.6.5, the rendering pipeline looks like this:

```
Elementor Widget Settings
          ↓
Elementor_Settings_Adapter
          ↓
Canonical Config
          ↓
Public_API::render()
```

The adapter is **the only class in the entire codebase that knows Elementor
control key names**. Everything below it — Public_API, Query_Adapter,
Render_Engine, all templates — sees only the canonical config schema. Elementor
is now just another consumer of the engine, identical in status to a shortcode
or a PHP API call.

Step 3 (refactoring `Widget_Product_Grid::render()` to a thin wrapper) is the
immediate next task. Once it lands, the removal of Elementor from the rendering
pipeline is complete.

---

## Progress Summary

| Milestone | Status | Version completed |
|-----------|--------|-------------------|
| 1 — Engine Foundation          | ✅ Complete | v1.6.0 |
| 2 — Compatibility Verification | ✅ Complete | v1.6.1 |
| 3 — Diagnostics & Observability| ✅ Complete | v1.6.3 |
| 4 — Consumer Migration         | ✅ Complete (v1.6.5) | All Steps 1–6 done |
| 5 — Asset Manager              | ✅ Complete | v1.7.0 |
| 6 — Template Infrastructure    | ✅ Complete | v1.7.0 |
| 7 — Template Registry API      | ✅ Complete | v2.0.5–v2.0.8 |
| 8 — Context Engine             | ⬜ Not started | — |
| 9 — Extension Platform         | ⬜ Not started | — |
| 10 — Independent Template Plugins | ✅ Architecture proven | v2.0.8 |

---

## Milestone 4 — Consumer Migration (current)

| Step | Status | Description |
|------|--------|-------------|
| Step 1: Freeze canonical schema      | ✅ Complete (v1.6.4) | Config_Defaults + Config_Normalizer + Render_Engine shim |
| Step 2: Elementor_Settings_Adapter   | ✅ Complete (v1.6.5) | includes/Elementor/class-elementor-settings-adapter.php |
| Step 3: Refactor Elementor widget render() | ✅ Complete (v1.6.5) | Widget is now a thin adapter; engine has zero Elementor knowledge |
| Step 4: PHP API consumer             | ✅ Working | zymarg_render_grid([...]) |
| Step 5: Shortcode consumer           | ✅ Complete (v1.6.5) | [zymarg_products] — thin translator → Public_API::render() |
| Step 6: Page plugin consumers        | ✅ Complete (v1.6.5) | Related Products, Store, Category, Search → Public_API::render() |

---

## Canonical Config Schema (locked v1.6.4)

```php
$config = [
    'query'      => [
        'source'   => 'all',      // all | dynamic | trending | featured |
                                   // best_selling | similar | vendor |
                                   // current_vendor | recommended | recent |
                                   // wishlist | category | algolia
        'limit'    => 8,
        'orderby'  => 'date',
        'order'    => 'DESC',
        'show_oos' => false,
        // + all source-specific keys pass through unchanged via 'source_args'
    ],
    'layout'     => [
        'type'    => 'grid',      // 'grid' | 'slider'
        'columns' => 4,
        'gap'     => 24,          // px
    ],
    'card'       => [
        // 'template' — card template slug (v2.0.5+).
        // Resolved by Template_Manager::get_registered_cards().
        // Core ships 'classic'. Standalone template plugins register additional
        // slugs via Template_Manager::register_card() on zymarg_wcpg_init.
        'template'            => 'classic',
        'style'               => 'default',
        // Visibility
        'show_image'          => true,
        'show_title'          => true,
        'show_price'          => true,
        'show_rating'         => true,
        'show_sold_count'     => false,
        'show_vendor'         => false,
        'show_atc'            => true,
        'show_wishlist'       => true,
        'show_quickview'      => true,
        'show_discount_badge' => true,
        'show_stock_badge'    => true,
        'show_sold_text'      => true,
        'show_stock_in'       => false,
        'show_stock_out'      => true,
        // Positioning
        'price_position'      => 'below_rating',  // above_title | above_rating | below_rating
        'vendor_position'     => 'below_price',   // above_title | below_meta | below_price
        'atc_position'        => 'with_price',    // standalone | with_meta | with_price | with_vendor
        'meta_layout'         => 'stacked',       // stacked | inline
        // Display
        'title_lines'         => 2,
        'sold_count_format'   => 'short',         // short | full
        'discount_badge_mode' => 'percentage',    // percentage | amount
        'image_full_resolution' => false,
        'image_hover_zoom'    => true,
    ],
    'heading'    => [
        // Default OFF — engine is neutral; consumers opt in
        'show'                 => false,
        'text'                 => '',
        'subtext'              => '',
        'tag'                  => 'h2',    // h1–h6 | div | span
        'alignment'            => 'left',  // left | center | right
        'show_view_all'        => false,
        'view_all_text'        => '',
        'view_all_url'         => '',
        'view_all_auto_vendor' => false,
    ],
    'pagination' => [
        // NOT responsive — register a separate template for different behaviour
        'mode'           => 'none',  // none | load_more
        'load_more_text' => '',
    ],
    'responsive' => [
        // Only layout + card participate in responsive inheritance
        // heading and pagination are intentionally excluded
        'tablet' => [
            'layout' => [],  // inherits desktop layout, override specific keys
            'card'   => [],  // inherits desktop card, override specific keys
        ],
        'mobile' => [
            'layout' => [],  // inherits tablet layout
            'card'   => [],  // inherits tablet card
        ],
    ],
];
```

---

## Elementor_Settings_Adapter — Key Mapping Reference

This section documents every Elementor control key and how it maps to the
canonical config. Future developers maintaining the adapter should read this
alongside the trait files in `includes/Elementor/traits/`.

### Control → Config mapping rules

| Rule | Description |
|------|-------------|
| **1:1** | Key name is identical in Elementor and canonical config |
| **Renamed** | Elementor key differs from canonical key |
| **Normalised** | Type or value is transformed (switcher → bool, slider → int, enum remapped) |
| **Composed** | Multiple Elementor keys → one config key, or vice versa |
| **Passthrough** | Value is passed unchanged (ICONS array, URL array) |
| **Derived** | No Elementor control — value derived from context or hardcoded |

### query section

| Elementor key | Config key | Rule | Notes |
|---------------|-----------|------|-------|
| `source` | `query.source` | 1:1 | |
| `total_products` | `query.limit` | Renamed | NUMBER control |
| `orderby` | `query.orderby` | 1:1 | |
| `order` | `query.order` | 1:1 | |
| `show_oos` | `query.show_oos` | Normalised | SWITCHER → bool |
| `include_products` | `query.include_products` | Normalised | TEXT (CSV) → int[] |
| `exclude_products` | `query.exclude_products` | Normalised | TEXT (CSV) → int[] |
| `include_categories` | `query.include_categories` | Normalised | SELECT2 multiple → int[] |
| `exclude_categories` | `query.exclude_categories` | Normalised | SELECT2 multiple → int[] |
| `filter_group_id` | `query.filter_group_id` | 1:1 | current_vendor only |
| *(all source-specific keys)* | `query.source_args` | Composed | See source_args table below |

### query.source_args — by source

| Source | Elementor key | Type | Default |
|--------|--------------|------|---------|
| `category` | `cat_include_subcategories` | SWITCHER→bool | true |
| `category` | `cat_shop_behavior` | SELECT | `'all'` |
| `category` | `cat_orderby` | SELECT | `'popularity'` |
| `trending` | `trending_window` | SELECT→int | `7` |
| `trending` | `trending_w_sales` | SLIDER size | `50` |
| `trending` | `trending_w_engagement` | SLIDER size | `30` |
| `trending` | `trending_w_recency` | SLIDER size | `20` |
| `trending` | `trending_sampling` | SWITCHER→bool | false |
| `trending` | `trending_sampling_n` | NUMBER | `10` |
| `dynamic` | `dynamic_w_recency` | SLIDER size | `60` |
| `dynamic` | `dynamic_w_rating` | SLIDER size | `30` |
| `dynamic` | `dynamic_w_sales` | SLIDER size | `10` |
| `dynamic` | `dynamic_refresh` | SELECT | `'hour'` |
| `recommended` | `recommended_w_category` | SLIDER size | `40` |
| `recommended` | `recommended_w_purchase` | SLIDER size | `30` |
| `recommended` | `recommended_w_brand` | SLIDER size | `15` |
| `recommended` | `recommended_w_seller` | SLIDER size | `10` |
| `recommended` | `recommended_w_trending` | SLIDER size | `5` |
| `recommended` | `recommended_recency_penalty` | SWITCHER→bool | true |
| `recommended` | `recommended_vendor_cap` | NUMBER | `3` |
| `recommended` | `recommended_exclude_purchased` | SWITCHER→bool | true |
| `recommended` | `recommended_cold_start` | SELECT | `'hybrid'` |
| `similar` | `similar_strictness` | SELECT | `'balanced'` |
| `similar` | `similar_price_tolerance` | SELECT | `'25'` |
| `similar` | `similar_prefer_in_stock` | SWITCHER→bool | true |
| `similar` | `similar_prefer_recent` | SWITCHER→bool | true |
| `similar` | `similar_auto_detect` | SWITCHER→bool | true |
| `similar` | `similar_product_id` | NUMBER | `0` |
| `vendor` | `vendor_order_by` | SELECT | `'rating'` |
| `vendor` | `vendor_in_stock` | SWITCHER→bool | true |
| `vendor` | `vendor_auto_detect` | SWITCHER→bool | true |
| `vendor` | `vendor_product_id` | NUMBER | `0` |
| `current_vendor` | `current_vendor_subset` | SELECT | `'all'` |
| `current_vendor` | `current_vendor_include_staff` | SWITCHER→bool | true |
| `recent` | `recent_empty_mode` | SELECT | `'message'` |
| `wishlist` | `wishlist_empty_mode` | SELECT | `'message'` |

### layout section

| Elementor key | Config key | Rule | Notes |
|---------------|-----------|------|-------|
| `layout_type` | `layout.type` | Renamed | `'grid'` or `'slider'` |
| `card_template` | `card.template` | 1:1 | Control lives in the Layout section but maps to the card config; see card section |
| `columns` | `layout.columns` | 1:1 | Desktop; tablet/mobile → responsive |
| *(none)* | `layout.gap` | Derived | Hardcoded 24; no Elementor control |
| `slider_autoplay` | `layout.slider.autoplay` | Normalised | SWITCHER→bool |
| `slider_autoplay_delay` | `layout.slider.autoplay_delay` | 1:1 | NUMBER |
| `slider_loop` | `layout.slider.loop` | Normalised | SWITCHER→bool |
| `slider_speed` | `layout.slider.speed` | 1:1 | NUMBER |
| `slider_show_arrows` | `layout.slider.show_arrows` | Normalised | SWITCHER→bool |
| `slider_arrow_prev` | `layout.slider.arrow_prev` | Passthrough | ICONS array |
| `slider_arrow_next` | `layout.slider.arrow_next` | Passthrough | ICONS array |
| `slider_pagination_type` | `layout.slider.pagination_type` | 1:1 | |
| `slider_space_between` | `layout.slider.space_between` | 1:1 | NUMBER |

### card section

| Elementor key | Config key | Rule | Notes |
|---------------|-----------|------|-------|
| `card_template` | `card.template` | 1:1 | SELECT, options from `Template_Manager::get_registered_cards()`; added v2.2.0 |
| `show_image` | `card.show_image` | Normalised | SWITCHER→bool |
| `image_full_resolution` | `card.image_full_resolution` | Normalised | SWITCHER→bool |
| `image_hover_zoom` | `card.image_hover_zoom` | Normalised | SWITCHER→bool |
| `show_discount_badge` | `card.show_discount_badge` | Normalised | SWITCHER→bool |
| `discount_badge_mode` | `card.discount_badge_mode` | Normalised | `'percent'`→`'percentage'` |
| `show_stock_badge` | `card.show_stock_badge` | Normalised | SWITCHER→bool |
| `show_stock_in` | `card.show_stock_in` | Normalised | SWITCHER→bool |
| `show_stock_out` | `card.show_stock_out` | Normalised | SWITCHER→bool |
| `show_wishlist` | `card.show_wishlist` | Normalised | SWITCHER→bool |
| `wishlist_icon` | `card.wishlist_icon` | Passthrough | ICONS array |
| `wishlist_icon_active` | `card.wishlist_icon_active` | Passthrough | ICONS array |
| `show_quickview` | `card.show_quickview` | Normalised | SWITCHER→bool |
| `quickview_visibility` | `card.quickview_visibility` | 1:1 | |
| `quickview_display` | `card.quickview_display` | 1:1 | |
| `quickview_icon` | `card.quickview_icon` | Passthrough | ICONS array |
| `show_title` | `card.show_title` | Normalised | SWITCHER→bool |
| `title_lines` | `card.title_lines` | 1:1 | SELECT→int |
| `show_vendor` | `card.show_vendor` | Normalised | SWITCHER→bool |
| `vendor_position` | `card.vendor_position` | 1:1 | |
| `vendor_display` | `card.vendor_display` | 1:1 | |
| `vendor_link` | `card.vendor_link` | Normalised | SWITCHER→bool |
| `vendor_avatar_shape` | `card.vendor_avatar_shape` | 1:1 | |
| `vendor_avatar_side` | `card.vendor_avatar_side` | 1:1 | |
| `vendor_avatar_border` | `card.vendor_avatar_border` | Normalised | SWITCHER→bool |
| `show_rating` | `card.show_rating` | Normalised | SWITCHER→bool |
| `show_sold_count` | `card.show_sold_count` | Normalised | SWITCHER→bool |
| `sold_count_format` | `card.sold_count_format` | Normalised | `sold_n`/`sold_n_plus`→`short`, `n_sold`→`full` |
| `show_sold_text` | `card.show_sold_text` | Normalised | SWITCHER→bool; responsive |
| `meta_layout` | `card.meta_layout` | 1:1 | Responsive |
| `show_price` | `card.show_price` | Normalised | SWITCHER→bool |
| `price_position` | `card.price_position` | 1:1 | |
| `show_atc` | `card.show_atc` | Normalised | SWITCHER→bool |
| `atc_icon` | `card.atc_icon` | Passthrough | ICONS array |
| `show_view_cart_link` | `card.show_view_cart_link` | Normalised | SWITCHER→bool |
| `atc_position` | `card.atc_position` | 1:1 | |
| `atc_transform` | `card.atc_transform` | 1:1 | |
| `empty_message` | `card.empty_message` | 1:1 | TEXTAREA |
| *(none)* | `card.style` | Derived | Hardcoded `'default'`; Milestone 6 |

*Note: ATC static/hover transform slider controls (`atc_static_*`, `atc_custom_*`) are pure CSS via Elementor's selectors pipeline. They are NOT in the canonical config — Elementor generates the CSS automatically.*

*Note: Vendor avatar size (`vendor_avatar_size`) and border color (`vendor_avatar_border_color`) are also pure CSS via selectors. Not in config.*

### heading section

| Elementor key | Config key | Rule | Notes |
|---------------|-----------|------|-------|
| `show_heading` | `heading.show` | Normalised | SWITCHER→bool |
| `heading_text` | `heading.text` | Renamed | |
| `subheading_text` | `heading.subtext` | Renamed | |
| `heading_tag` | `heading.tag` | Renamed | |
| `heading_alignment` | `heading.alignment` | Renamed | Desktop; responsive CHOOSE |
| `heading_alignment_tablet` | `heading.alignment_tablet` | Renamed | |
| `heading_alignment_mobile` | `heading.alignment_mobile` | Renamed | |
| `show_view_all` | `heading.show_view_all` | Normalised | SWITCHER→bool |
| `view_all_text` | `heading.view_all_text` | Renamed | |
| `view_all_url` | `heading.view_all_url` | Passthrough | URL control array |
| `view_all_auto_vendor` | `heading.view_all_auto_vendor` | Normalised | SWITCHER→bool |

*Note: Heading style controls (typography groups, colors, spacing slider) are pure CSS via Elementor's selectors pipeline. Not in config.*

### pagination section

| Elementor key | Config key | Rule | Notes |
|---------------|-----------|------|-------|
| `pagination_mode` | `pagination.mode` | Renamed | was in layout section |
| `load_more_text` | `pagination.load_more_text` | Renamed | was in layout section |

### responsive section

| Elementor key | Config path | Notes |
|---------------|------------|-------|
| `columns_tablet` | `responsive.tablet.layout.columns` | |
| `columns_mobile` | `responsive.mobile.layout.columns` | |
| `meta_layout_tablet` | `responsive.tablet.card.meta_layout` | |
| `meta_layout_mobile` | `responsive.mobile.card.meta_layout` | |
| `show_sold_text_tablet` | `responsive.tablet.card.show_sold_text` | SWITCHER→bool |
| `show_sold_text_mobile` | `responsive.mobile.card.show_sold_text` | SWITCHER→bool |

---

## Full Pipeline

```
Consumer
(PHP API / Elementor / Shortcode / Page Plugin / REST / Block)
        │
        ▼
zymarg_render_grid($args)           ← global convenience function
        │
        ▼
Zymarg_Product_Grid::render($args)  ← stable global facade
        │
        ▼
Public_API::render($args)           ← orchestrator only (VERSION = '1.0.0')
        │
        ├── resolve input priority: config > template > slot
        │
        ▼
Context_Resolver::resolve($context)
        │
        ▼
Slot_Registry → Template_Registry
        │
        ▼
Config_Normalizer::normalize()
        │
        ├── Config_Defaults        (framework defaults)
        ├── Card style defaults    (reserved for Milestone 6)
        ├── Template config
        ├── Caller overrides
        ├── Responsive inheritance (layout + card only)
        └── Validation + sanitization
        │
        ▼
Products supplied? ──Yes──→ Render_Engine directly
        │ No
        ▼
Query_Adapter::to_settings($query, $context)
        │
        ▼
Query_Builder::get_products($settings)   ← NEVER modified
        │
        ▼
Render_Engine::render($config, $products)
        │
        ├── Asset_Manager::enqueue_for_render( array $config ): void            // v1.7.0
Template_Manager::render_layout( array $config, array $ctx ): string  // v1.8.0
Template_Manager::render_card( string $template, array $args ): string // v1.8.0
Cache_Manager::build_key( array $config, array $context ): string      // v2.0.0
Cache_Manager::get( string $key )                                       // v2.0.0
Cache_Manager::set( string $key, string $html, int $ttl ): void        // v2.0.0
Cache_Manager::invalidate_all(): void                                   // v2.0.0  ← Milestone 5 complete
        │
        ▼
config_to_settings()   ← compatibility shim; removed when templates migrate to $config
        │
        ▼
Template_Loader::get_template()   ← NEVER modified
        │
        ▼
grid-wrapper.php / slider-wrapper.php
        │
        ▼
Template_Manager::render()         ← Milestone 6 complete
        │
        ▼
cards/classic/product-card.php
        │
        ▼
HTML string returned to caller
```

### Elementor consumer path (after Step 3)

```
Widget_Product_Grid::render()
        │
        ├── [Elementor layer — stays here, never moves into engine]
        │     HIDE_WIDGET guard
        │     Editor-mode notices
        │     Preview placeholders
        │     maybe_apply_auto_vendor_view_all()
        │
        │  get_settings_for_display()
        ▼
Elementor_Settings_Adapter::to_config($settings)
        │  THE ONLY PLACE THAT KNOWS ELEMENTOR KEY NAMES
        ▼
Canonical Config
        │
        ▼
Public_API::render([ 'config' => $config ])
        │
        └── [Engine — consumer-agnostic, knows nothing about Elementor]
              render products, normalize config, resolve templates/slots
```

---

## File Structure

```
zymarg-wc-product-grid/
│
├── ARCHITECTURE.md                    ← you are here
│
├── includes/
│   │
│   ├── Api/
│   │   ├── class-public-api.php              ✅ built — VERSION = '1.0.0' v1.6.4; HIDE_WIDGET + widget_id/is_preview v1.6.5
│   │   └── class-zymarg-product-grid.php     ✅ built
│   │
│   ├── Admin/
│   │   ├── class-admin.php                   ✅ built
│   │   └── class-engine-diagnostics.php      ✅ built — ZYMARG branded, v1–v7
│   │
│   ├── Bootstrap/
│   │   └── class-api-bootstrap.php           ✅ built
│   │
│   ├── Registry/
│   │   ├── class-slot-registry.php           ✅ built — 5 default slots
│   │   └── class-template-registry.php       ✅ built — 5 default templates
│   │
│   ├── Context/
│   │   └── class-context-resolver.php        ✅ built
│   │
│   ├── Adapters/
│   │   └── class-query-adapter.php           ✅ built
│   │   (framework-wide adapters only)
│   │
│   ├── Render/
│   │   ├── class-config-defaults.php         ✅ updated v1.6.4 — heading + pagination added
│   │   ├── class-config-normalizer.php       ✅ updated v1.6.4 — heading + pagination in DEEP_MERGE_KEYS
│   │   └── class-render-engine.php           ✅ updated v1.6.4 — shim maps heading + pagination
│   │
│   ├── Assets/
│   │   └── (folder reserved for future asset-related classes)
│   │
│   ├── Services/
│   │   ├── class-asset-manager.php           ✅ built v1.7.0 — stateless; enqueue_for_render() + enqueue_for_search_page()
│   │   └── class-cache-manager.php            ✅ built v2.0.0 — HTML render cache; version-bump invalidation; object cache + transient backends
│   │
│   ├── Templates/
│   │   └── class-template-manager.php        ✅ built v1.7.0 — single public method render(); resolves slug → file; fallback to classic
│   │
│   ├── Components/
│   │   └── (reserved — future milestone)
│   │
│   ├── Shortcodes/
│   │   ├── class-wishlist-shortcode.php          ✅ existing — calls Template_Loader directly (pre-engine)
│   │   ├── class-recently-viewed-shortcode.php   ✅ existing — calls Template_Loader directly (pre-engine)
│   │   └── class-product-grid-shortcode.php      ✅ built v1.6.5 — [zymarg_products]; thin translator → Public_API::render()
│   │
│   ├── PageConsumers/
│   │   ├── class-related-products-consumer.php   ✅ built v1.6.5 — single product page → slot 'related-products'
│   │   ├── class-store-products-consumer.php     ✅ built v1.6.5 — Dokan store page → slot 'store-products'
│   │   ├── class-category-products-consumer.php  ✅ built v1.6.5 — category archive → slot 'category-products'
│   │   └── class-search-results-consumer.php     ✅ built v1.6.5 — product search → slot 'search-results'
│   │
│   └── Elementor/
│       ├── class-elementor-loader.php              ✅ untouched
│       ├── class-widget-wishlist-button.php        ✅ untouched
│       ├── class-widget-product-grid.php           ✅ refactored v1.6.5 — thin Elementor adapter; all render/query logic removed
│       ├── class-elementor-settings-adapter.php   ✅ built v1.6.5 — THE ONLY CLASS THAT KNOWS ELEMENTOR KEY NAMES
│       └── traits/
│           ├── trait-controls-heading.php          ✅ untouched
│           ├── trait-controls-layout.php           ✅ untouched
│           ├── trait-controls-settings.php         ✅ untouched
│           ├── trait-controls-slider.php           ✅ untouched
│           ├── trait-controls-source.php           ✅ untouched
│           ├── trait-controls-style.php            ✅ untouched
│           └── trait-editor-diagnostics.php        ✅ untouched
```

---

## Milestone Roadmap

### ✅ Milestone 1 — Engine Foundation (v1.6.0)
Api_Bootstrap, Public_API, Slot_Registry, Template_Registry,
Context_Resolver, Query_Adapter, Config_Defaults, Config_Normalizer,
Render_Engine, zymarg_render_grid()

### ✅ Milestone 2 — Compatibility Verification (v1.6.1)
CSS, wrapper classes, existing templates, product cards, grid layout,
slider, Quick View, Wishlist, ATC, Load More, all JS behaviours
verified unchanged. Backward compatibility confirmed.

### ✅ Milestone 3 — Diagnostics & Observability (v1.6.2 → v1.6.3)
ZYMARG admin menu at position 3, Engine Diagnostics page v1–v7,
ZYMARG brand design applied, per-section timing (Public API / Render
Engine / Query Builder independently), metric card dashboard,
checks passed N/N, memory tracking (used + peak).

### 🔄 Milestone 4 — Consumer Migration (current)

**Goal:** Every place that renders a product grid uses Public_API::render().
Nothing else builds or renders a product grid.

- ✅ Step 1: Freeze canonical schema (v1.6.4)
  - Config_Defaults: heading + pagination sections added,
    pagination_mode + load_more_text moved out of layout
  - Config_Normalizer: heading + pagination added to DEEP_MERGE_KEYS,
    enum validation updated
  - Render_Engine: config_to_settings() shim updated for
    pagination.* and heading.* → flat $settings keys
  - Public_API: VERSION = '1.0.0' constant added
  - Assets/ and Components/ folders reserved

- ✅ Step 2: Elementor_Settings_Adapter (v1.6.5)
  - includes/Elementor/class-elementor-settings-adapter.php
  - Single static method: Elementor_Settings_Adapter::to_config($settings)
  - Maps ALL 6 trait files' control keys to canonical config
  - SWITCHER → bool, SLIDER → int (size field), ICONS passthrough, URL passthrough
  - CSV TEXT → int[] for include/exclude product IDs
  - SELECT2 multiple → int[] for include/exclude categories
  - Responsive controls (columns, meta_layout, show_sold_text) → responsive section
  - Source-specific args isolated per source in source_args sub-array
  - Enum remaps: discount_badge_mode 'percent'→'percentage'; sold_count_format mapped to schema values
  - Style-only controls (typography groups, colors, CSS sliders) deliberately excluded — Elementor CSS pipeline handles them

- ✅ Step 3: Refactor Elementor widget render() (v1.6.5)
  - Widget is now a thin Elementor adapter — ~30 lines of orchestration
  - Architectural boundary enforced: ONE hand-off point to Public_API::render()
  - Everything above the hand-off is the Elementor layer (stays permanently):
      - WooCommerce hard guard + editor notice
      - get_settings_for_display()
      - Editor-preview diagnostics (trending, vendor, similar notices)
      - maybe_apply_auto_vendor_view_all() — pre-adapter settings enrichment
      - HIDE_WIDGET presentation (editor notice vs. front-end HTML comment)
  - Everything below the hand-off belongs to the engine (removed from widget):
      - Query_Builder::get_products() — now inside engine via Query_Adapter
      - Template selection (slider vs. grid) — now inside Render_Engine
      - Slider asset enqueuing — now inside Render_Engine (Milestone 5: Asset_Manager)
      - Template_Loader::get_template() — now inside Render_Engine
  - Dead imports removed: Query_Builder, Source_Base, Template_Loader
  - New import added: Public_API
  - Public_API changes (v1.6.5):
      - HIDE_WIDGET = '__ZYMARG_HIDE_WIDGET__' constant added — callers detect
        the sentinel; the engine never emits markup for this case
      - widget_id and is_preview accepted in $args, passed to Render_Engine
  - Render_Engine::render() signature updated:
      render(array $config, array $products, string $widget_id = '', bool $is_preview = false)
      - widget_id available in render_context for templates (unique DOM IDs)
      - is_preview available in render_context but engine never branches on it —
        that is the caller's responsibility (Rule #15)

- ✅ Step 4: PHP API consumer (working since v1.6.0)
  - zymarg_render_grid([...]) is first-class consumer

- ✅ Step 5: Shortcode consumer (v1.6.5)
  - includes/Shortcodes/class-product-grid-shortcode.php
  - Tag: [zymarg_products] — registered in Plugin::init() after Api_Bootstrap
  - Thin translator only — consumer responsibility principle:
      Read input → Translate input → Public_API::render(). Done.
  - Must not and does not: call Query_Builder, Render_Engine, Template_Loader,
    enqueue assets, select templates, or know about wrappers
  - Supports: slot, template, source, limit, orderby, order, layout, columns,
    columns_tablet, columns_mobile, include/exclude categories/products,
    show_heading, heading_text, heading_tag, all card visibility flags,
    pagination, empty_message
  - Card visibility flags use empty-string sentinel: '' means "not set by
    author — Config_Defaults decides". Only explicitly provided flags are
    set in the config, so templates default correctly
  - HIDE_WIDGET sentinel → returns '' (no editor layer in shortcodes)
  - slot + template passed alongside config so Public_API priority resolution
    (config > template > slot) applies without the shortcode knowing the logic

- ✅ Milestone 4 compatibility audit (v1.6.5)
  - Root cause: all legacy templates were written for Elementor's 'yes'/'no'
    string format; the new engine passes canonical PHP booleans (true/false)
  - Fix applied to ALL templates — project-wide, not file-by-file:
      grid/grid-wrapper.php   — show_heading, show_view_all, show_view_cart_link
      slider/slider-wrapper.php — show_heading, show_view_all, slider_loop,
                                  slider_autoplay, slider_show_arrows (×2),
                                  show_view_cart_link
      grid/rating-soldcount.php — show_rating, show_sold_count,
                                  show_sold_text, show_sold_text_tablet,
                                  show_sold_text_mobile
      grid/badges.php           — show_discount_badge, show_stock_badge,
                                  show_stock_in, show_stock_out
      grid/vendor.php           — vendor_link
  - Every fix uses the same $enabled() helper already in product-card.php:
      $enabled = static fn($v) => in_array((string)$v, ['1','yes','true'], true)
  - Render_Engine::config_to_settings() — responsive section added:
      responsive.tablet.layout.columns → columns_tablet
      responsive.mobile.layout.columns → columns_mobile
      responsive.tablet.card.meta_layout → meta_layout_tablet
      responsive.mobile.card.meta_layout → meta_layout_mobile
      responsive.tablet.card.show_sold_text → show_sold_text_tablet
      responsive.mobile.card.show_sold_text → show_sold_text_mobile
  - After this fix: zero 'yes' === occurrences remain in any template
  - Elementor continues to work unchanged (its 'yes' strings pass $enabled())
  - Rule added: see Rule 17 below

- ✅ Senior developer audit fixes (v1.6.5)
  - Responsive CSS — root cause found and fixed: templates were emitting only
    a static --cols-N class; no CSS acted on columns_tablet/columns_mobile.
    Fix: grid-wrapper.php now emits data-columns-tablet / data-columns-mobile
    attributes; frontend.css adds @media (max-width: 1024px/767px) attribute
    selector rules for all 6 column counts. PHP + CSS now work together.
  - Heading alignment responsive — config_to_settings() now maps:
      heading.alignment_tablet → heading_alignment_tablet
      heading.alignment_mobile → heading_alignment_mobile
    grid-wrapper.php resolves per-device alignment with Elementor-style
    cascade (mobile falls back to tablet, tablet falls back to desktop).
    HTML: --align-{left|center|right} modifier class (desktop) +
          data-align-tablet / data-align-mobile attributes (devices).
    CSS: modifier class rules + @media attribute selector overrides added.
  - config_to_settings() shim — TEMPORARY COMPATIBILITY LAYER comment added.
    Future developers will not mistake this for the permanent API.

- ✅ Step 6: Page plugin consumers (v1.6.5)
  - includes/PageConsumers/ — new directory, 4 new classes
  - All registered in Plugin::init() after shortcodes, before Api_Bootstrap
  - Every consumer follows Rule #16: Read context → Translate → Public_API::render()
  - Zero imports of Query_Builder, Render_Engine, Template_Loader, Config_Normalizer
  - Context detection (page type, IDs, query strings) stays in the consumer

  Related_Products_Consumer:
    - Hook: woocommerce_after_single_product_summary (priority 20)
    - Removes woocommerce_output_related_products, replaces with engine
    - Context: product_id from get_queried_object_id()
    - Slot: 'related-products' → template 'related-grid' → source 'similar'
    - Context_Resolver auto-derives vendor_id and category_id from product_id

  Store_Products_Consumer:
    - Hook: dokan_after_store_products (Dokan-only — guarded by function_exists)
    - Context: vendor_id resolved via get_query_var('author'), WP_User, or slug
    - Slot: 'store-products' → template 'store-grid' → source 'current_vendor'

  Category_Products_Consumer:
    - Hooks: woocommerce_before_shop_loop (×2 — suppress default loop + render)
    - Context: category_id from get_queried_object() WP_Term
    - Slot: 'category-products' → template 'category-grid' → source 'category'
    - Default WooCommerce product loop hooks removed on category pages only

  Search_Results_Consumer:
    - Hooks: woocommerce_before_shop_loop (×2 — suppress default loop + render)
    - Context: search string from get_search_query()
    - Slot: 'search-results' → template 'search-grid' → source 'algolia'
    - Only fires on is_search() + post_type=product requests
    - Default WooCommerce product loop hooks removed on search pages only

- ✅ Asset loading fix (v1.6.5) — post-Step-6 regression fix
  - Root cause: assets were only enqueued by Elementor widget lifecycle
    (get_style_depends / get_script_depends) and the Algolia search hook.
    Page consumers have no Elementor lifecycle, so frontend.css / frontend.js
    were never enqueued — producing correct HTML with no CSS applied.
  - Fix: Render_Engine::enqueue_assets() — private static method called at
    the top of every render(). Enqueues HANDLE_FRONTEND + HANDLE_QUICKVIEW
    unconditionally; HANDLE_SLIDER only when layout type is 'slider'.
    Also calls QuickView_Modal::flag_mount() so the modal shell is printed
    in wp_footer regardless of which consumer triggered the render.
  - wp_enqueue_style/script are idempotent — safe for multiple grids per page.
  - QuickView_Modal::flag_mount() uses add_filter(__return_true) — idempotent.
  - Elementor widget's get_style_depends / get_script_depends unchanged —
    Elementor still owns its own asset pipeline; Render_Engine is additive.
  - This is the INTERIM solution. Milestone 5 (Asset Manager) will replace
    Render_Engine::enqueue_assets() with a dedicated class.

### ✅ Milestone 5 — Asset Manager (v1.7.0)

**Goal:** Render_Engine never calls wp_enqueue_* directly. All asset decisions live in one place.

- `includes/Services/class-asset-manager.php` — new stateless static class
- `Asset_Manager::enqueue_for_render(array $config)` — called by Render_Engine at the start of every render
  - `enqueue_core()` — always: frontend CSS+JS, quickview CSS+JS, QuickView_Modal::flag_mount()
  - `maybe_enqueue_slider()` — Swiper CSS+JS only when config layout.type === 'slider'
  - `maybe_enqueue_quickview()` — documented hook point; covered by core today; future home for lightbox handle
- `Asset_Manager::enqueue_for_search_page()` — hooked unconditionally in Plugin::init() at priority 15; guards with own is_search_page() check for FOUC prevention
- `Assets` — registration-only; enqueue_search_page_assets() and is_search_page() removed
- `Render_Engine` — enqueue_assets() removed; replaced with single call to Asset_Manager::enqueue_for_render($config)
- Elementor widget get_style_depends() / get_script_depends() — unchanged; Elementor's own pipeline handles the editor

**Why Elementor still uses get_style_depends():**
Elementor calls those methods before render() fires as part of its own dependency resolution (editor, cached pages). Asset_Manager::enqueue_for_render( array $config ): void            // v1.7.0
Template_Manager::render_layout( array $config, array $ctx ): string  // v1.8.0
Template_Manager::render_card( string $template, array $args ): string // v1.8.0
Cache_Manager::build_key( array $config, array $context ): string      // v2.0.0
Cache_Manager::get( string $key )                                       // v2.0.0
Cache_Manager::set( string $key, string $html, int $ttl ): void        // v2.0.0
Cache_Manager::invalidate_all(): void                                   // v2.0.0 is additive — it runs alongside Elementor without replacing it. On page-consumer renders (Related Products, Category, Store, Search) there is no Elementor widget lifecycle at all, so Asset_Manager is the only enqueue path.

### ✅ Milestone 6 — Template Infrastructure (v1.7.0)

**Goal:** Render_Engine never touches a template filename. A new Template_Manager is the only class that knows where card template files live.

**What changed:**

- `includes/Templates/class-template-manager.php` — new stateless static class
  - `Template_Manager::render(string $template, array $args): string` — single public method
  - `resolve_path(string $template): ?string` — maps slug to relative path; falls back to 'classic' on unknown slugs; never fatal error
  - Delegates to `Template_Loader::get_template_html()` so theme override support (zymarg-wcpg/ in active theme) is inherited automatically
  - `CARD_TEMPLATES` constant: `['classic' => 'cards/classic/product-card.php']`

- `templates/cards/classic/product-card.php` — canonical location for the classic card template. The copy at `templates/grid/product-card.php` is retained for backward compatibility (theme overrides that reference the old path continue to work via Template_Loader).

- `templates/grid/grid-wrapper.php` — replaces `Template_Loader::get_template('grid/product-card.php', ...)` with `Template_Manager::render($config['template'] ?? 'classic', ...)`. Now passes `$config` alongside `$settings` so future templates can consume the canonical config directly.

- `templates/slider/slider-wrapper.php` — same change as grid-wrapper.php.

**Render_Engine is unchanged.** It still calls `Template_Loader::get_template_html()` for the layout wrapper (grid-wrapper / slider-wrapper). The wrapper then calls `Template_Manager::render()` for each card. Render_Engine never sees a card filename.

**Adding a second template (future):**
  1. Add `'minimal' => 'cards/minimal/product-card.php'` to `Template_Manager::CARD_TEMPLATES`.
  2. Create the template file.
  3. Nothing else changes — Render_Engine, Public_API, consumers untouched.

**Architecture after Milestone 6:**
```
Render_Engine
      │
      ▼
Template_Loader          ← layout wrapper (grid-wrapper / slider-wrapper)
      │
      ▼
Template_Manager         ← resolves card template slug → file path
      │
      ▼
cards/classic/product-card.php   ← the only card template today
```

### ⬜ Milestone 7 — Template Objects
Templates become objects, not config arrays.
Template { slug, label, description, config }
Behaviour methods (supports_slider() etc.) added only when needed.
Template_Registry returns Template objects.
Public_API is unchanged — it does not notice.

### ⬜ Milestone 8 — Context Engine
Richer context: user, language, currency, device, page type,
search query, vendor, category, product,
current template, current slot,
request type (AJAX vs normal), preview/editor mode.

### ⬜ Milestone 9 — Extension Platform
External plugins register without modifying Product Grid:
templates, slots, layouts, sources, components, adapters.
Filterable at every registry level.

### ⬜ Milestone 10 — Independent Template Plugins
Single Product Template, Store Template, Header Builder,
Footer Builder, Checkout Template.
None contain render logic — all call Public_API::render().
Product Grid plugin is the single owner of all product UI.
Consumers: Elementor, Gutenberg, REST, GraphQL,
Mobile app, AJAX, Shortcodes, Custom themes — all same API.

---

## Slot → Template Map

A slot resolves only to a **template**. It does **not** carry a source.

Since v2.0.3 no template config contains `query.source` — choosing the source
is the consumer's responsibility (Rule #16). The "Source passed by consumer"
column below therefore documents what each **consumer** sends alongside the
slot, not something the slot or template supplies.

| Slot | Template slug | Source passed by consumer |
|------|--------------|----------------------------|
| `related-products`  | `related-grid`  | `similar`         |
| `store-products`    | `store-grid`    | `current_vendor`  |
| `homepage-featured` | `homepage-grid` | `trending`        |
| `category-products` | `category-grid` | `category`        |
| `search-results`    | `search-grid`   | `algolia`         |

> **v2.1.0 correction.** This table previously read "Default source" and
> implied the template supplied it. It did not, and the four page consumers
> were never updated to pass one when v2.0.3 removed sources from templates,
> so every consumer silently fell through to the `all` default: related
> products showed the newest products site-wide, store pages showed every
> vendor's products, category archives ignored the category, and search
> ignored the query. All four consumers now declare their source explicitly.

---

## Consumer Migration Checklist

| Consumer | Status | Method |
|----------|--------|--------|
| PHP API | ✅ Working | `zymarg_render_grid([...])` |
| Elementor Widget | ✅ Complete (v1.6.5) | Thin adapter — Elementor_Settings_Adapter → Public_API::render() |
| Shortcode | ✅ Complete (v1.6.5) | `[zymarg_products]` → `Public_API::render()` |
| Single Product Template | ✅ Complete (v1.6.5) | Related_Products_Consumer → slot `related-products` |
| Store Template | ✅ Complete (v1.6.5) | Store_Products_Consumer → slot `store-products` |
| Category pages | ✅ Complete (v1.6.5) | Category_Products_Consumer → slot `category-products` |
| Search Results | ✅ Complete (v1.6.5) | Search_Results_Consumer → slot `search-results` |
| REST API | ⬜ Future (M10) | `Public_API::render()` |
| Gutenberg Block | ⬜ Future (M10) | `Public_API::render()` |

---

## Stable Interfaces (frozen — do not change without major version bump)

```php
Public_API::render( array $args ): string
Public_API::VERSION                          // '1.0.0'
Context_Resolver::resolve( array $ctx ): array
Config_Normalizer::normalize( array $template, array $overrides ): array
Render_Engine::render( array $config, array $products, string $widget_id = '', bool $is_preview = false ): string
Public_API::HIDE_WIDGET                      // '__ZYMARG_HIDE_WIDGET__' sentinel, added v1.6.5
Template_Registry::get( string $slug ): array
Template_Registry::register( string $slug, array $config, array $meta ): void
Slot_Registry::get( string $slot ): ?string
Slot_Registry::register( string $slot, string $template, array $meta ): void
zymarg_render_grid( array $args ): string
Elementor_Settings_Adapter::to_config( array $settings ): array  // added v1.6.5
```

---

## Locked Architectural Rules

1. **`Query_Builder` is never modified** — adapters translate to its format
2. **`Template_Loader` is never modified** — shim translates config to its format
3. **Elementor widget controls are never removed** — only `render()` changes
4. **`Public_API::render()` is the only external entry point** — no direct class instantiation by consumers
5. **`Render_Engine` owns rendering concerns** — including assets (Milestone 5); `Public_API` stays as orchestrator only
6. **`heading` is not currently part of the responsive schema** — door left open for future
7. **`pagination` is never responsive** — register a separate template for different pagination behaviour
8. **`Api_Bootstrap` knows nothing about admin** — `Admin::init()` is always separate
9. **Every registry is filterable** — external plugins extend without forking
10. **Exceptions never escape `Public_API::render()`** — always returns a string
11. **`Elementor_Settings_Adapter` lives in `includes/Elementor/`** — Elementor-specific, not a framework-wide adapter
12. **`includes/Adapters/` is for framework-wide adapters only** — currently `Query_Adapter`
13. **Product Grid plugin is the single owner of all product UI** — no other plugin renders product cards
14. **`Elementor_Settings_Adapter` is the only class that knows Elementor control key names** — no other class in the codebase imports or reads raw Elementor `$settings` keys
15. **The engine is consumer-agnostic** — editor notices, preview placeholders, HIDE_WIDGET, and any behaviour that only exists because Elementor exists stay in the Elementor integration layer (`includes/Elementor/`), never in the engine
16. **Consumer Responsibility principle** — every consumer (Elementor widget, shortcode, page plugin, REST, block) follows exactly this pattern and stops there:
    ```
    Read input  →  Translate input  →  Public_API::render()
    ```
    The engine owns everything below that hand-off. A consumer that calls Query_Builder, Render_Engine, Template_Loader, or enqueues assets directly has violated this boundary.
17. **Legacy template boolean compatibility** — all templates must use the `$enabled()` helper for boolean settings checks, never bare `'yes' ===` string comparisons. The helper accepts both Elementor's `'yes'` strings and canonical PHP `true`/`1`/`'true'` values. Any new template or template edit must use this pattern. Zero `'yes' ===` occurrences should exist in the templates directory.

---

## Milestone 7 — Template Registry API (v2.0.5–v2.0.8)

### Goal

Turn the Product Grid plugin into a pure rendering engine. Card templates are no longer bundled in the core — they live in standalone template plugins that register themselves via a public API.

### Architecture

```
Product Grid Core (engine only)
        │
        │  fires: zymarg_wcpg_init
        │
        ▼
Template Pack Plugin (e.g. ZYMARG Template Pack)
        │
        │  Template_Manager::register_card( 'zymarg', __DIR__ . '/templates/product-card.php' )
        │
        ▼
Template_Manager runtime registry
        │
        ▼
Any consumer (shortcode, standalone plugin, Public_API)
        │
        │  config['card']['template'] = 'zymarg'
        │
        ▼
grid-wrapper / slider-wrapper
        │
        ▼
Template_Manager::render_card( 'zymarg', $args )
        │
        ▼
template-pack/templates/product-card.php
        │
        ▼
Asset_Manager auto-loads style.css + script.js from same folder
```

### Key classes

| Class | Responsibility |
|---|---|
| `Template_Manager::register_card( $slug, $path )` | Public API — external plugins call this to add templates |
| `Template_Manager::unregister_card( $slug )` | Remove a runtime registration (testing, future admin) |
| `Template_Manager::get_registered_cards()` | Returns merged map: core CARD_TEMPLATES + runtime registry |
| `Template_Manager::is_registered_card( $slug )` | Used by Config_Normalizer to validate before rendering |
| `Config_Defaults` | `card.template = 'classic'` — the default seed |
| `Config_Normalizer` | Validates slug via `is_registered_card()`, falls back to `classic` |

### Bootstrap hook

`zymarg_wcpg_init` fires at the end of `Plugin::init()` after all core subsystems are ready. Template packs register on this hook:

```php
add_action( 'zymarg_wcpg_init', function () {
    Template_Manager::register_card(
        'zymarg',
        plugin_dir_path( __FILE__ ) . 'templates/product-card.php'
    );
} );
```

`zymarg_wcpg_loaded` fires immediately after `zymarg_wcpg_init` and is also safe for registration.

### Rules

1. `CARD_TEMPLATES` constant is immutable — only `classic` lives there, forever.
2. External templates never touch the constant — `register_card()` only.
3. Core templates always win — `get_registered_cards()` places CARD_TEMPLATES last in `array_merge` so they override runtime entries.
4. `register_card()` validates: slug must match `[a-z0-9_-]+`, path must be non-empty, no duplicates, no overriding core templates. All violations emit `E_USER_WARNING`.
5. Template and source are completely independent. The same template renders any source; the same source renders with any template.

### Shortcode

```
[zymarg_products card_template="zymarg" source="similar" limit="6"]
```

`card_template` was added in v2.0.7.

### Per-template assets

`Asset_Manager::maybe_enqueue_card_template_assets()` checks for `style.css` and `script.js` alongside the registered PHP file path and enqueues them automatically. Template packs need no manual handle registration.

`Template_Manager::get_card_assets( $slug )` performs the lookup and returns
the path, public URL and cache-busting version for each asset found.
Asset_Manager consumes that result and only decides how to enqueue it, so
Rule #6 holds — Template_Manager remains the only class that knows where
template files live.

Resolution is relative to the template's own directory:

| Template kind | PHP file | Stylesheet |
|---|---|---|
| Bundled | `templates/cards/classic/product-card.php` | `templates/cards/classic/style.css` |
| External | `{plugin}/templates/product-card.php` | `{plugin}/templates/style.css` |

External assets are versioned by file modification time, because a template
plugin ships updates independently of this engine's version number.

> **v2.1.0 correction.** This section described the intended behaviour, not the
> actual behaviour. Asset lookup was hardcoded to this plugin's own
> `templates/cards/{slug}/` directory and read the slug from the nonexistent
> `$config['template']` key (canonical: `$config['card']['template']`), so it
> always resolved to `classic` and searched only inside the engine. An
> externally registered template could never load its own stylesheet. Both
> faults are fixed.


---

## Template Path Contract (v2.1.0)

`Template_Loader` accepts two path forms. Understanding the difference matters
for anyone registering templates.

| Form | Example | Used by |
|---|---|---|
| Relative to `/templates/` | `cards/classic/product-card.php` | Bundled core templates |
| Absolute filesystem path | `/…/plugins/my-pack/templates/product-card.php` | `register_card()` from external plugins |

Resolution order:

```
Absolute path                          Relative path
─────────────                          ─────────────
theme/zymarg-wcpg/{override key}       theme/zymarg-wcpg/{relative path}
        ↓ (if absent)                          ↓ (if absent)
the absolute path itself               {plugin}/templates/{relative path}
        ↓ (if unreadable)                      ↓ (if unreadable)
'' → logged when WP_DEBUG              '' → logged when WP_DEBUG
```

Because an absolute path outside this plugin carries no meaningful override
key, `render_card()` supplies one derived from the slug, giving themes a single
predictable override location that works identically for core and external
templates:

```
theme/zymarg-wcpg/cards/{slug}/product-card.php
```

A template that cannot be located now returns an empty string **and** logs a
diagnostic under `WP_DEBUG`. Previously it returned an empty string silently,
which is why the broken external path went unnoticed.

---

## Known Gaps and Next Steps

Recorded honestly so the next person does not have to rediscover them.

### 1. Layout templates are still hardcoded

```php
private const LAYOUT_TEMPLATES = [
    'grid'   => 'grid/grid-wrapper.php',
    'slider' => 'slider/slider-wrapper.php',
];
```

Card templates are registry-driven; layouts are not. The core therefore still
knows the name of every layout that exists. The intended end state mirrors the
card registry:

```php
Template_Manager::register_layout( 'masonry',  __DIR__ . '/templates/masonry-wrapper.php' );
Template_Manager::register_layout( 'carousel', __DIR__ . '/templates/carousel-wrapper.php' );
```

The v2.1.0 path work is the prerequisite for this: absolute paths now resolve,
so `register_layout()` becomes a thin mirror of `register_card()` rather than
new infrastructure. Not implemented in v2.1.0.

### 2. Context Engine (Milestone 8) is not started

The design states that sources never inspect global WordPress state and read
everything through `Context_Resolver`. That is not yet true. Six source classes
still reach into globals directly:

| Class | Global state read |
|---|---|
| `Source_Base` | `is_product()`, `get_queried_object_id()`, `global $post` |
| `Source_Category` | `get_queried_object()`, `$_GET['orderby']` |
| `Source_Current_Vendor` | `get_query_var('author')`, `get_query_var('author_name')`, `get_queried_object()` |
| `Source_Vendor` | `is_product()`, `get_queried_object_id()`, `global $post` |
| `Source_Recent` | `is_product()`, `get_queried_object_id()` |
| `Source_Algolia` | `get_query_var('paged')` |

Consequence: sources are harder to unit test and behave differently in AJAX
contexts, which is why several already carry AJAX-specific fallbacks. Treat
the "sources are context-pure" rule as the target, not the current state.

### 3. Native search has no source

`Source_Algolia` degrades to `Source_All` when Algolia credentials are absent,
but `Source_All` has no search-term support at all. On a site without Algolia
configured, a search results page therefore renders products unfiltered by the
search term.

This predates v2.1.0 and is unchanged by it — the search consumer previously
resolved to `all` for a different reason, so the outcome was already the same.
Fixing it properly means either teaching `Source_All` to honour
`context['search']`, or adding a dedicated native `Source_Search` for the
fallback. Not addressed in v2.1.0.
