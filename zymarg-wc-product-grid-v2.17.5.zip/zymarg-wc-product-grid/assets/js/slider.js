/* global jQuery, Swiper */
/**
 * ZYMARG WC Product Grid - Slider Runtime
 *
 * Initialises Swiper on each .zymarg-wcpg--slider on the page using
 * the JSON config attached to the wrapper element. Re-initialises when
 * Elementor renders or re-renders the widget in the editor.
 */
( function ( $ ) {
	'use strict';

	function initOne( el ) {
		if ( typeof Swiper === 'undefined' ) {
			return;
		}
		var $el = $( el );
		if ( $el.data( 'zymargSwiperInited' ) ) {
			return;
		}
		var raw = $el.attr( 'data-swiper-config' );
		var config = {};
		try {
			config = raw ? JSON.parse( raw ) : {};
		} catch ( err ) {
			config = {};
		}

		var $swiperEl = $el.find( '.swiper' ).first();
		if ( ! $swiperEl.length ) { return; }

		// Resolve nav/pagination element references.
		if ( config.navigation === true ) {
			config.navigation = {
				nextEl: $el.find( '.swiper-button-next' )[ 0 ],
				prevEl: $el.find( '.swiper-button-prev' )[ 0 ]
			};
		}
		// v2.17.5: bullets/fraction/progress (Swiper's own pagination module) are
		// gone -- the "X more" chip is a custom element, not a Swiper feature --
		// but this stays as a safety net for any config object built by an older
		// integration that still sets config.pagination directly.
		if ( config.pagination && typeof config.pagination === 'object' ) {
			config.pagination.el = $el.find( '.swiper-pagination' )[ 0 ];
		}

		// v2.13.1: keep loop inside Swiper's slide budget.
		//
		// Swiper disables looping when
		//   slides.length < ceil( slidesPerView ) + slidesPerGroup + loopAdditionalSlides
		// and only warns in the console. PHP sizes the runway from the desktop
		// column count, but Load More can change the slide count after render, so
		// re-check against the real DOM and trim the runway instead of letting
		// Swiper silently drop the loop.
		if ( config.loop ) {
			var slideCount = $swiperEl.find( '.swiper-slide' ).length;
			var maxSpv = parseFloat( config.slidesPerView ) || 1;
			if ( config.breakpoints ) {
				for ( var bp in config.breakpoints ) {
					if ( ! Object.prototype.hasOwnProperty.call( config.breakpoints, bp ) ) { continue; }
					var spv = parseFloat( config.breakpoints[ bp ].slidesPerView );
					if ( spv > maxSpv ) { maxSpv = spv; }
				}
			}
			var budget = slideCount - Math.ceil( maxSpv ) - ( parseFloat( config.slidesPerGroup ) || 1 );
			// v2.16.1: leave one slide unspent. Spending the whole budget passes
			// Swiper's check but empties the clone pool, and loopFix() then does
			// nothing at all -- see the note in slider-wrapper.php.
			var runway = Math.max( 0, budget - 1 );
			if ( budget < 0 ) {
				config.loop = false;
				delete config.loopAdditionalSlides;
			} else if ( ( parseFloat( config.loopAdditionalSlides ) || 0 ) > runway ) {
				config.loopAdditionalSlides = runway;
			}
		}

		try {
			var instance = new Swiper( $swiperEl[ 0 ], config );
			$el.data( 'zymargSwiperInited', true );
			$el.data( 'zymargSwiperInstance', instance );

			if ( $el.attr( 'data-zymarg-marquee' ) === '1' ) {
				startMarquee( $el, instance );
			}

			initChip( $el, instance );

			// v2.13.0: free scroll + loop.
			//
			// Swiper re-runs loopFix() after a free-mode fling only when
			// centeredSlides is on, so with left-aligned slides a fling that
			// reaches the end of the cloned track clamps there and the slider
			// dead-ends. Re-running loopFix() once the momentum transition
			// finishes moves the active slide back into the middle of the
			// clones, so the next fling always has runway. loopFix()
			// compensates the translate, so nothing moves on screen.
			if ( config.loop && config.freeMode && config.freeMode.enabled ) {
				var fixing = false;
				instance.on( 'transitionEnd', function () {
					if ( fixing || instance.destroyed || ! instance.params.loop ) { return; }
					fixing = true;
					try { instance.loopFix(); } catch ( err ) {}
					fixing = false;
				} );
			}
		} catch ( e ) {
			if ( window.console ) { console.error( '[ZYMARG WCPG] Swiper init failed', e ); }
		}
	}

	/**
	 * Continuous marquee drift (v2.16.0).
	 *
	 * Swiper autoplay cannot do this properly: it moves in slide-sized
	 * transitions and can only be paused between them, so hovering appeared to
	 * do nothing until the current advance finished. Instead we advance the
	 * translate ourselves once per animation frame. Because every frame is an
	 * independent write, stopping is instant and resuming continues from the
	 * exact pixel we stopped at -- no snapping, no rewinding.
	 *
	 * This also coexists with free mode. While the user drags, Swiper owns the
	 * translate and we simply stand down; when the momentum transition ends we
	 * pick the drift back up from wherever it came to rest.
	 */
	function startMarquee( $el, instance ) {
		var msPerSlide = parseInt( $el.attr( 'data-zymarg-marquee-speed' ), 10 );
		if ( ! msPerSlide || msPerSlide < 100 ) {
			msPerSlide = 4000;
		}

		// A perpetually moving track is precisely what this media query asks us
		// to suppress. The slider stays fully draggable, just not self-propelled.
		if ( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ) {
			return;
		}

		var hovering = false;
		var holding  = false;
		var coasting = false;
		var coastAt  = 0;
		var stalled  = 0;
		var last     = 0;

		// Pixels per second, derived from the configured ms-per-slide so the
		// speed stays consistent when the breakpoint changes the card width.
		function pxPerSecond() {
			var sizes = instance.slidesSizesGrid;
			if ( ! sizes || ! sizes.length ) {
				return 0;
			}
			var idx   = Math.min( instance.activeIndex || 0, sizes.length - 1 );
			var width = sizes[ idx ] + ( instance.params.spaceBetween || 0 );
			return width / ( msPerSlide / 1000 );
		}

		// Mirrors Swiper's own touchMove wrap test. Once the translate passes an
		// edge, loopFix() shifts the clones and rewrites the translate so the
		// track keeps going without a visible jump.
		function wrap() {
			var spv = instance.params.slidesPerView;
			var perView = ( 'auto' === spv )
				? instance.slidesPerViewDynamic()
				: Math.ceil( parseFloat( spv, 10 ) );
			var before = instance.translate;

			if ( instance.translate < instance.maxTranslate() ) {
				instance.loopFix( {
					direction: 'next',
					setTranslate: true,
					activeSlideIndex: instance.slides.length - perView
				} );
			} else if ( instance.translate > instance.minTranslate() ) {
				instance.loopFix( {
					direction: 'prev',
					setTranslate: true,
					activeSlideIndex: 0
				} );
			} else {
				stalled = 0;
				return;
			}

			// loopFix() does nothing when the clone pool on that side is empty,
			// which leaves the track parked past the edge forever. The runway
			// headroom above should prevent it, but a Load More or a filter can
			// change the slide count after init, so re-seat rather than freeze.
			if ( instance.translate === before ) {
				stalled++;
				if ( stalled > 5 ) {
					stalled = 0;
					try {
						instance.slideToLoop( instance.realIndex, 0, false );
					} catch ( err ) {}
				}
			} else {
				stalled = 0;
			}
		}

		function tick( now ) {
			if ( instance.destroyed ) {
				return;
			}
			window.requestAnimationFrame( tick );

			// Any of these means someone else owns the translate right now.
			// Clearing `last` stops the idle time counting as drift, which is
			// what keeps resume seamless instead of jumping forward.
			// A zero-duration transition emits transitionStart but never fires
			// transitionend, so the coast flag could latch on and freeze the
			// drift permanently. Time it out rather than trust the pairing.
			if ( coasting && coastAt && ( now - coastAt ) > 3000 ) {
				coasting = false;
			}

			if ( hovering || holding || coasting || instance.animating ||
				( document.hidden === true ) ) {
				last = 0;
				return;
			}
			if ( ! last ) {
				last = now;
				return;
			}

			var delta = now - last;
			last = now;
			// A backgrounded tab can hand us a huge delta on return.
			if ( delta <= 0 || delta > 200 ) {
				return;
			}

			var step = pxPerSecond() * ( delta / 1000 );
			if ( ! step ) {
				return;
			}

			try {
				instance.setTransition( 0 );
				instance.setTranslate( instance.translate - step );
				wrap();
			} catch ( err ) {
				hovering = true; // Stop drifting rather than throw every frame.
				console.error( '[ZYMARG WCPG] Marquee halted', err );
			}
		}

		// Hover pause, pointer devices only. On touch, pointerenter fires on tap
		// and pointerleave may never follow, which would strand the track.
		// Holding already covers the touch case.
		if ( ! window.matchMedia || window.matchMedia( '(hover: hover)' ).matches ) {
			$el.on( 'pointerenter.zymargMarquee mouseenter.zymargMarquee', function () {
				hovering = true;
			} );
			$el.on( 'pointerleave.zymargMarquee mouseleave.zymargMarquee', function () {
				hovering = false;
			} );
		}

		// Touch/drag hold. touchEnd fires on release; any free-mode momentum
		// then runs as a transition, which `coasting` waits out.
		instance.on( 'touchStart', function () {
			holding = true;
		} );
		instance.on( 'touchEnd', function () {
			holding = false;
		} );
		instance.on( 'transitionStart', function () {
			coasting = true;
			coastAt  = ( window.performance && window.performance.now )
				? window.performance.now()
				: 0;
		} );
		instance.on( 'transitionEnd', function () {
			coasting = false;
		} );

		window.requestAnimationFrame( tick );
	}

	/**
	 * "X more" pagination chip (v2.17.5).
	 *
	 * Replaces the old bullets/fraction/progress-bar pagination with a single
	 * pill that counts down the products not yet visible and announces
	 * completion once the last one has scrolled into view. Not a Swiper
	 * pagination module -- there is no Swiper type that reports "N items not
	 * yet seen" -- so this reads position straight off the Swiper instance
	 * instead (realIndex survives both loop and free-mode dragging).
	 */
	function initChip( $el, instance ) {
		var $chip = $el.find( '[data-zymarg-chip]' ).first();
		if ( ! $chip.length ) {
			return;
		}

		var total = parseInt( $el.attr( 'data-total-products' ), 10 ) || 0;
		if ( total < 1 ) {
			return;
		}

		var labelMore = $chip.attr( 'data-chip-more' ) || 'more';
		var labelDone = $chip.attr( 'data-chip-done' ) || 'All shown';
		var goneTimer = null;

		function update() {
			if ( instance.destroyed ) {
				return;
			}
			var cols = Math.max( 1, Math.ceil( parseFloat( instance.params.slidesPerView ) || 1 ) );
			var first = ( ( instance.realIndex % total ) + total ) % total;
			var remaining = Math.max( 0, total - first - cols );

			clearTimeout( goneTimer );
			$chip.removeClass( 'zymarg-wcpg__chip--gone' );

			if ( remaining > 0 ) {
				$chip.text( remaining + ' ' + labelMore );
			} else {
				$chip.text( '\u2713 ' + labelDone );
				goneTimer = setTimeout( function () {
					$chip.addClass( 'zymarg-wcpg__chip--gone' );
				}, 1000 );
			}
		}

		// 'progress' and 'setTranslate' both fire continuously during a free-mode
		// drag/momentum coast, which is what keeps the count live rather than
		// only updating on discrete slide snaps.
		instance.on( 'init slideChange setTranslate progress resize', update );
		update();
	}

	function initAll( $scope ) {
		$scope = $scope || $( document );
		$scope.find( '.zymarg-wcpg--slider' ).each( function () {
			initOne( this );
		} );
	}

	$( function () { initAll(); } );

	// v2.11.0: sliders that arrive after page load.
	//
	// initAll() previously ran on jQuery ready and on the Elementor widget
	// hook only, so a slider injected by another page builder, a popup, an
	// AJAX filter or a tab panel never initialised -- it rendered as a static
	// column of full-width slides. A MutationObserver covers every injection
	// route without the injecting code needing to know about us.
	if ( window.MutationObserver ) {
		var pending = null;
		var observer = new MutationObserver( function ( mutations ) {
			var found = false;
			for ( var i = 0; i < mutations.length && ! found; i++ ) {
				var added = mutations[ i ].addedNodes || [];
				for ( var j = 0; j < added.length; j++ ) {
					var node = added[ j ];
					if ( 1 !== node.nodeType ) { continue; }
					if ( node.matches && node.matches( '.zymarg-wcpg--slider' ) ) { found = true; break; }
					if ( node.querySelector && node.querySelector( '.zymarg-wcpg--slider' ) ) { found = true; break; }
				}
			}
			if ( ! found ) { return; }
			// Coalesce bursts of mutations into a single init pass.
			if ( pending ) { clearTimeout( pending ); }
			pending = setTimeout( function () { pending = null; initAll(); }, 50 );
		} );
		$( function () {
			observer.observe( document.body, { childList: true, subtree: true } );
		} );
	}

	// Load More / infinite scroll can append slides to a live slider.
	$( document ).on( 'zymarg_wcpg:products:appended', function () { initAll(); } );

	// Elementor editor + frontend lifecycle.
	$( window ).on( 'elementor/frontend/init', function () {
		if ( window.elementorFrontend && elementorFrontend.hooks ) {
			elementorFrontend.hooks.addAction(
				'frontend/element_ready/zymarg_product_grid.default',
				function ( $scope ) { initAll( $scope ); }
			);
		}
	} );

} )( jQuery );
