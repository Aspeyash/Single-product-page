<?php
/**
 * Uninstall handler.
 *
 * Runs when the user deletes the plugin from the WordPress Plugins screen.
 *
 * Data-persistence policy
 * -----------------------
 * Non-destructive by default. User data — wishlists, recently-viewed lists,
 * trending engagement counters — survives `Delete`, so you can safely
 * uninstall, upgrade, or reinstall without losing anything your customers
 * have saved. Only short-lived infrastructure (rate-limit transients) is
 * always cleared because it has no value beyond the current request window.
 *
 * Opt-in to a full destructive wipe (the legacy ≤1.4.5 behaviour) — choose
 * either:
 *
 *   1. Filter (runtime):
 *
 *      add_filter( 'zymarg_wcpg_wipe_all_data_on_uninstall', '__return_true' );
 *
 *   2. Constant in wp-config.php (admin-side, no plugin loaded needed):
 *
 *      define( 'ZYMARG_WCPG_WIPE_ON_UNINSTALL', true );
 *
 * Either one tells this handler to remove every option, transient and
 * meta row the plugin ever wrote.
 *
 * @package Zymarg\WCPG
 * @since   1.4.7  Default behaviour changed from destructive → preserve.
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

global $wpdb;

/* -------------------------------------------------------------------------
 * Always cleared: rate-limit transients.
 *
 * These are short-lived (≤120s) infrastructure, with no value past the
 * current request window. Safe to clear unconditionally.
 * ------------------------------------------------------------------------- */

$wpdb->query(
	"DELETE FROM {$wpdb->options}
	 WHERE option_name LIKE '\\_transient\\_zymarg\\_rl\\_%'
	    OR option_name LIKE '\\_transient\\_timeout\\_zymarg\\_rl\\_%'"
);

/* -------------------------------------------------------------------------
 * Should we do the FULL destructive cleanup?
 * Default: no. The user has to explicitly opt in.
 * ------------------------------------------------------------------------- */

$wipe_all = false;

if ( defined( 'ZYMARG_WCPG_WIPE_ON_UNINSTALL' ) && ZYMARG_WCPG_WIPE_ON_UNINSTALL ) {
	$wipe_all = true;
}

/**
 * Filter: should uninstall wipe ALL plugin data (including user wishlists
 * and recently-viewed lists)?
 *
 * @since 1.4.7
 *
 * @param bool $wipe_all Default false. Return true to perform a full
 *                       destructive cleanup (the legacy ≤1.4.5 behaviour).
 */
$wipe_all = (bool) apply_filters( 'zymarg_wcpg_wipe_all_data_on_uninstall', $wipe_all );

if ( ! $wipe_all ) {
	// Preserve user data. Stop here.
	return;
}

/* -------------------------------------------------------------------------
 * Destructive path — opt-in only.
 * ------------------------------------------------------------------------- */

// Plugin-owned options.
$options = array(
	'zymarg_wcpg_version',
	'zymarg_wcpg_settings',
	'zymarg_wcpg_engagement',
	'zymarg_wcpg_engagement_pruned',
	'zymarg_wcpg_trending_cache',
	'zymarg_wcpg_trending_meta',
	'zymarg_wcpg_seed_done',
);

foreach ( $options as $option ) {
	delete_option( $option );
	delete_site_option( $option );
}

// All zymarg-prefixed transients (trending cache, vendor cache, etc.).
$wpdb->query(
	"DELETE FROM {$wpdb->options}
	 WHERE option_name LIKE '\\_transient\\_zymarg\\_%'
	    OR option_name LIKE '\\_transient\\_timeout\\_zymarg\\_%'"
);

if ( is_multisite() ) {
	$wpdb->query(
		"DELETE FROM {$wpdb->sitemeta}
		 WHERE meta_key LIKE '\\_site\\_transient\\_zymarg\\_%'
		    OR meta_key LIKE '\\_site\\_transient\\_timeout\\_zymarg\\_%'"
	);
}

// User meta (wishlist, recently-viewed mirror, vendor cache age key).
$wpdb->query(
	"DELETE FROM {$wpdb->usermeta}
	 WHERE meta_key IN (
	     '_zymarg_wishlist',
	     '_zymarg_recently_viewed',
	     '_zymarg_vendor_cache_at'
	 )"
);

// Post meta (engagement counters).
$wpdb->query(
	"DELETE FROM {$wpdb->postmeta}
	 WHERE meta_key IN ('_zymarg_clicks_7d')"
);
