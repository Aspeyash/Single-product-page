<?php
/**
 * Public API — the stable facade every ZYMARG plugin depends on.
 *
 * This class is a thin orchestrator. It accepts a render request, delegates
 * each step to the appropriate specialist class, and returns HTML.
 *
 * CONTRACT: render(array $args): string
 *
 * This contract must not change. Internal implementations may evolve freely
 * as long as this signature and its behaviour remain stable.
 *
 * Responsibility:
 *   Accept a render request, orchestrate the pipeline, return HTML.
 *
 * This class must not:
 *   - Contain business logic.
 *   - Query products directly.
 *   - Build configuration.
 *   - Render templates.
 *   - Know about Elementor.
 *   - Let exceptions escape to the caller.
 *
 * Input priority (permanent — do not change):
 *   1. 'config'   — caller supplies a complete canonical config array.
 *   2. 'template' — caller names a template slug; registry loads its config.
 *   3. 'slot'     — caller names a slot; registry resolves slot → template.
 *
 * Accepted $args keys:
 *   slot      string        Named position (e.g. 'related-products').
 *   template  string        Template slug  (e.g. 'related-grid').
 *   config    array         Complete or partial canonical config override.
 *   query     array         Query override merged into config['query'].
 *   products  WC_Product[]  Pre-fetched products; skips Query Engine when supplied.
 *   context   array         Partial context passed to Context_Resolver.
 *
 * @package Zymarg\WCPG\Api
 * @since   1.6.0
 */

namespace Zymarg\WCPG\Api;

use Zymarg\WCPG\Bootstrap\Api_Bootstrap;
use Zymarg\WCPG\Context\Context_Resolver;
use Zymarg\WCPG\Services\Cache_Manager;
use Zymarg\WCPG\Registry\Slot_Registry;
use Zymarg\WCPG\Registry\Template_Registry;
use Zymarg\WCPG\Render\Config_Normalizer;
use Zymarg\WCPG\Render\Render_Engine;
use Zymarg\WCPG\Adapters\Query_Adapter;
use Zymarg\WCPG\Query\Query_Builder;
use Zymarg\WCPG\Query\Source_Base;

defined( 'ABSPATH' ) || exit;

/**
 * Class Public_API
 */
final class Public_API {

	/**
	 * Public API version — stable contract identifier.
	 *
	 * Template plugins and consumers can use this to confirm the API
	 * version before calling render():
	 *
	 *   if ( version_compare( Public_API::VERSION, '1.0.0', '>=' ) ) { ... }
	 *
	 * Increment this only on breaking interface changes.
	 *
	 * @since 1.6.4
	 */
	public const VERSION = '1.0.0';

	/**
	 * Sentinel returned by render() when a source determines no markup
	 * should be emitted (e.g. Similar / More From Seller with no matches).
	 *
	 * The CALLING LAYER decides what to show when this is returned.
	 * The engine never outputs anything in this case — it is not an error.
	 *
	 * Usage (Elementor widget):
	 *   $output = Public_API::render([...]);
	 *   if ( Public_API::HIDE_WIDGET === $output ) {
	 *       // show editor notice or suppress entirely
	 *   }
	 *
	 * @since 1.6.5
	 */
	public const HIDE_WIDGET = '__ZYMARG_HIDE_WIDGET__';

	/**
	 * Render a product grid and return the HTML string.
	 *
	 * This is the single entry point for all external callers. Every future
	 * ZYMARG plugin should call this method (or the zymarg_render_grid()
	 * convenience wrapper) and nothing else.
	 *
	 * Examples:
	 *
	 *   // Most common — slot drives everything.
	 *   Public_API::render([
	 *       'slot'    => 'related-products',
	 *       'context' => [ 'product_id' => 123 ],
	 *   ]);
	 *
	 *   // Template override — bypass slot resolution.
	 *   Public_API::render([
	 *       'template' => 'homepage-grid',
	 *   ]);
	 *
	 *   // Pre-fetched products — bypass Query Engine.
	 *   Public_API::render([
	 *       'slot'     => 'flash-sale',
	 *       'products' => $my_products,
	 *   ]);
	 *
	 *   // Custom query — override the template's default query.
	 *   Public_API::render([
	 *       'slot'  => 'homepage-featured',
	 *       'query' => [ 'source' => 'category', 'category_id' => 25, 'limit' => 12 ],
	 *   ]);
	 *
	 * @param array $args Render request arguments (see class docblock).
	 * @return string Rendered HTML, or empty string on failure.
	 */
	public static function render( array $args = [] ): string {
		if ( ! Api_Bootstrap::is_initialized() ) {
			return '';
		}

		try {
			return self::execute( $args );
		} catch ( \Throwable $e ) {
			// A render must never take down the page, so the empty string
			// stands. Before v2.1.0 the throwable was discarded entirely,
			// which meant any failure inside the pipeline was indistinguishable
			// from "no products found" and effectively undebuggable. Log it
			// when WP_DEBUG is on; stay silent in production.
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				error_log( // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- debug-only diagnostic.
					sprintf(
						'[ZYMARG WCPG] Render failed: %s in %s:%d',
						$e->getMessage(),
						$e->getFile(),
						$e->getLine()
					)
				);
			}

			/**
			 * Fires when a render request throws.
			 *
			 * Lets monitoring or logging extensions observe render failures
			 * without changing the engine's fail-soft behaviour.
			 *
			 * @since 2.1.0
			 * @param \Throwable $e    The caught throwable.
			 * @param array      $args The original render arguments.
			 */
			do_action( 'zymarg_render_failed', $e, $args );

			return '';
		}
	}

	/**
	 * Fetch products for a source WITHOUT rendering anything.
	 *
	 * render() is the right entry point for anything that wants this plugin's
	 * markup. It is the wrong one for a consumer that has its own layout, its
	 * own filters and its own card loop, and only wants to borrow the query
	 * layer -- until now such a consumer had to either duplicate the source
	 * logic or reach into Query_Builder directly, which is internal and free
	 * to change.
	 *
	 * Return contract, in three cases:
	 *   - array         Zero or more WC_Product objects. An empty array means
	 *                   the source ran and legitimately matched nothing.
	 *   - HIDE_WIDGET   The source asked for no output at all, or the source
	 *                   key is not available. Distinct from an empty array:
	 *                   the caller should render nothing rather than an
	 *                   "no products found" state.
	 *   - array         On internal failure. Like render(), this never throws.
	 *
	 * Callers must gate on has_source() or check for HIDE_WIDGET. Passing an
	 * unrecognised key here does NOT silently fall back to the full catalogue
	 * the way Query_Builder::resolve_source() does.
	 *
	 * Example:
	 *
	 *   $products = Public_API::query([
	 *       'query'  => [ 'source' => 'trending' ],
	 *       'limit'  => 24,
	 *       'offset' => 48,
	 *   ]);
	 *
	 * @since 2.12.0
	 *
	 * @param array $args {
	 *     @type array $query   Query settings. Must include 'source'.
	 *     @type int   $limit   Products to return. Capped by the source.
	 *     @type int   $offset  Products to skip, for pagination.
	 *     @type array $context Context values merged beneath the query settings.
	 * }
	 * @return \WC_Product[]|string Products, or HIDE_WIDGET.
	 */
	public static function query( array $args = [] ) {
		if ( ! Api_Bootstrap::is_initialized() ) {
			return [];
		}

		$offset_filter = null;

		try {
			$query_args = isset( $args['query'] )   && is_array( $args['query'] )   ? $args['query']   : [];
			$context    = isset( $args['context'] ) && is_array( $args['context'] ) ? $args['context'] : [];

			$source_key = isset( $query_args['source'] ) ? sanitize_key( (string) $query_args['source'] ) : 'all';

			if ( ! self::has_source( $source_key ) ) {
				return self::HIDE_WIDGET;
			}

			$limit  = isset( $args['limit'] )  ? (int) $args['limit']            : 0;
			$offset = isset( $args['offset'] ) ? max( 0, (int) $args['offset'] ) : 0;

			// Query settings win over context, so a caller cannot accidentally
			// have a stale context key override the source it just asked for.
			$settings           = array_merge( $context, $query_args );
			$settings['source'] = $source_key;

			if ( $limit > 0 ) {
				$settings['total_products'] = $limit;
			}

			$per_page = $limit > 0 ? $limit : 8;

			// Mirrors what Handler_Load_More passes, so sources that already
			// understand paging behave identically whether they were reached
			// through Load More or through this method.
			$settings['_offset'] = $offset;
			$settings['_paged']  = (int) floor( $offset / max( 1, $per_page ) ) + 1;

			if ( $offset > 0 ) {
				$offset_filter = static function ( $query_args_in ) use ( $offset ) {
					if ( is_array( $query_args_in ) ) {
						$query_args_in['offset'] = $offset;
					}
					return $query_args_in;
				};

				add_filter( 'zymarg_wcpg_query_args', $offset_filter );
			}

			$result = Query_Builder::get_products( $settings );

			if ( Source_Base::HIDE_WIDGET === $result ) {
				return self::HIDE_WIDGET;
			}

			if ( ! is_array( $result ) ) {
				return [];
			}

			// A source is free to return whatever it likes. Consumers are
			// promised WC_Product objects, so anything else is dropped here
			// rather than becoming a fatal in the caller's card loop.
			return array_values(
				array_filter(
					$result,
					static function ( $product ) {
						return $product instanceof \WC_Product;
					}
				)
			);
		} catch ( \Throwable $e ) {
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				error_log( // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- debug-only diagnostic.
					sprintf(
						'[ZYMARG WCPG] Query failed: %s in %s:%d',
						$e->getMessage(),
						$e->getFile(),
						$e->getLine()
					)
				);
			}

			/**
			 * Fires when a query request throws.
			 *
			 * @since 2.12.0
			 * @param \Throwable $e    The caught throwable.
			 * @param array      $args The original query arguments.
			 */
			do_action( 'zymarg_query_failed', $e, $args );

			return [];
		} finally {
			if ( null !== $offset_filter ) {
				remove_filter( 'zymarg_wcpg_query_args', $offset_filter );
			}
		}
	}

	/**
	 * Whether a source key is available on this installation.
	 *
	 * Consumers previously kept their own hardcoded copy of the source list to
	 * answer this, which goes stale silently: the list keeps reporting a
	 * source that was removed, or omits one that was added, and either way the
	 * consumer's behaviour diverges from the engine's with no error anywhere.
	 *
	 * Returns false for a key that is registered but whose class has not
	 * shipped, which is the case this check exists for.
	 *
	 * @since 2.12.0
	 * @param string $key Source key, e.g. 'trending'.
	 * @return bool
	 */
	public static function has_source( string $key ): bool {
		if ( ! Api_Bootstrap::is_initialized() ) {
			return false;
		}

		try {
			return Query_Builder::has_source( $key );
		} catch ( \Throwable $e ) {
			return false;
		}
	}

	// -------------------------------------------------------------------------
	// Pipeline
	// -------------------------------------------------------------------------

	/**
	 * Execute the render pipeline.
	 *
	 * Separated from render() so exception handling is isolated in one place.
	 *
	 * Pipeline stages:
	 *   1. Extract and validate top-level args.
	 *   2. Resolve input: config > template > slot.
	 *   3. Merge any caller query override into the config.
	 *   4. Resolve context.
	 *   5. Normalize configuration.
	 *   6. Fetch products (skip if pre-supplied).
	 *   7. Render and return HTML.
	 *
	 * @param array $args Raw render request arguments.
	 * @return string Rendered HTML.
	 */
	private static function execute( array $args ): string {
		// ── Stage 1: Extract args ────────────────────────────────────────────
		$slot             = isset( $args['slot'] )     ? (string) $args['slot']     : '';
		$template_slug    = isset( $args['template'] ) ? (string) $args['template'] : '';
		$config_override  = isset( $args['config'] )   && is_array( $args['config'] )   ? $args['config']   : [];
		$query_override   = isset( $args['query'] )    && is_array( $args['query'] )    ? $args['query']    : [];
		$products_arg     = isset( $args['products'] ) && is_array( $args['products'] ) ? $args['products'] : null;
		$context_arg      = isset( $args['context'] )  && is_array( $args['context'] )  ? $args['context']  : [];

		// Consumer-supplied render context — passed through to Render_Engine.
		// The engine uses these for output but never interprets them as
		// Elementor concepts; they are generic enough to apply to any consumer.
		$widget_id  = isset( $args['widget_id'] )  ? (string) $args['widget_id']  : '';
		$is_preview = isset( $args['is_preview'] ) ? (bool)   $args['is_preview'] : false;

	    

		/**
		 * Fires at the start of a render request, before any pipeline work.
		 *
		 * Use for request profiling, logging, or cache-hit checks.
		 * Return early from the hook is not supported — use the html filter
		 * on Render_Engine if you need to short-circuit rendering.
		 *
		 * @since 1.6.0
		 * @param array $args Raw render request arguments.
		 */
		do_action( 'zymarg_product_grid_render_request', $args );

		// ── Stage 2: Resolve input (config > template > slot) ───────────────
		$template_config = self::resolve_template_config(
			$config_override,
			$template_slug,
			$slot
		);

		

		// ── Stage 3: Merge caller query override into template config ────────
		if ( ! empty( $query_override ) ) {
			$existing_query              = $template_config['query'] ?? [];
			$template_config['query']    = array_merge( $existing_query, $query_override );
		}

		

		// ── Stage 4: Resolve context ─────────────────────────────────────────
		$context = Context_Resolver::resolve( $context_arg );

		

		// ── Stage 5: Normalize configuration ────────────────────────────────
		// Caller overrides (config_override) are already folded into
		// template_config at stage 2; pass empty array for the second
		// parameter to avoid double-applying them.
		// Context is forwarded so the zymarg_render_config filter receives it
		// (v2.1.0). Caller overrides are already folded into $template_config
		// at stage 2, so the second argument stays empty by design.
		$config = Config_Normalizer::normalize( $template_config, [], $context );

		// Stage 5a: Auto-resolve vendor "View All" storefront URL.
		// Moved out of the Elementor widget (v2.4.0) so EVERY consumer --
		// including the standalone single-product page plugin -- gets the
		// vendor storefront link. Gated entirely on config; non-vendor grids
		// and grids with a manual URL are untouched.
		$config = self::maybe_apply_auto_vendor_view_all( $config );

		

		// ── Stage 5b: Cache lookup ──────────────────────────────────────────
		// Only attempt cache when products were NOT pre-supplied by the caller
		// (pre-supplied products bypass the query, so cache is irrelevant),
		// and only when the request qualifies for caching.
		$cache_key     = null;
		$use_cache     = null === $products_arg && Cache_Manager::should_cache( $config, $context );

		if ( $use_cache ) {
			$cache_key = Cache_Manager::build_key( $config, $context );
			$cached    = Cache_Manager::get( $cache_key );

			if ( false !== $cached ) {
				// v2.11.0: a cached hide-decision is returned as the sentinel,
				// not as markup, so callers keep their existing contract.
				if ( self::HIDE_WIDGET === $cached ) {
					return self::HIDE_WIDGET;
				}

				// Cache hit — skip query and render entirely.
				do_action( 'zymarg_product_grid_render_complete', $cached, $args );
				return $cached;
			}
		}

		// ── Stage 6: Fetch products ──────────────────────────────────────────
		if ( null !== $products_arg ) {
			// Caller pre-supplied products — skip Query Engine entirely.
			$products = $products_arg;
		} else {
			$query_config = $config['query'] ?? [];
			$settings     = Query_Adapter::to_settings( $query_config, $context );
			$result       = Query_Builder::get_products( $settings );

			// HIDE_WIDGET sentinel: a source determined nothing should render.
			// Return the public sentinel constant so the calling layer
			// (e.g. the Elementor widget) can decide what to display.
			// The engine itself never emits markup for this case.
			if ( Source_Base::HIDE_WIDGET === $result ) {
				// v2.11.0: cache the hide decision too.
				//
				// Nine sources can return this sentinel, and reaching it is not
				// cheap -- Similar runs its scoring pass, Current_Vendor resolves
				// the vendor and queries, Algolia makes a network round trip. The
				// early return skipped stage 8 entirely, so the most expensive
				// possible outcome -- render nothing -- was the only one repeated
				// in full on every single page load.
				if ( $use_cache && null !== $cache_key ) {
					Cache_Manager::set( $cache_key, self::HIDE_WIDGET );
				}

				return self::HIDE_WIDGET;
			}

			$products = is_array( $result ) ? $result : [];
		}

		/**
		 * Filter the product collection after fetching, before rendering.
		 *
		 * Use to reorder (featured first, trending first, AI ranking),
		 * exclude products, or inject additional products without replacing
		 * the query logic. Return value must be an array of WC_Product objects.
		 *
		 * @since 1.9.0
		 * @param \WC_Product[] $products Fetched product collection.
		 * @param array         $config   Normalized render config.
		 * @param array         $context  Resolved context.
		 */
		// Passes the real resolved context as of v2.1.0. An empty array was
		// passed previously, so extensions could not tell which product,
		// vendor, category or search term the collection belonged to — the
		// filter's most likely use cases were impossible to implement.
		$products = (array) apply_filters( 'zymarg_products', $products, $config, $context );

		// ── Stage 7: Render ──────────────────────────────────────────────────
		// Build debug metadata. Render_Engine uses this only when ZYMARG_DEBUG
		// is true and the viewer is an admin — zero cost in production because
		// render_debug_overlay() is never called. Public_API is the only layer
		// with visibility into cache state and consumer identity, so it passes
		// that context down rather than Render_Engine reaching back up.
		$debug_meta = [
			'cache_status'  => ! $use_cache ? 'DISABLED' : 'MISS', // HIT never reaches here (returned early).
			'consumer'      => '' !== $slot ? "slot:{$slot}" : ( '' !== $template_slug ? "template:{$template_slug}" : 'config' ),
			'context_type'  => $context['page_type'] ?? 'unknown',
			'slot'          => '' !== $slot ? $slot : '—',
			'template_slug' => '' !== $template_slug ? $template_slug : '—',
		];

		$html = Render_Engine::render( $config, $products, $widget_id, $is_preview, $debug_meta );

		// ── Stage 8: Store in cache ──────────────────────────────────────────
		if ( $use_cache && null !== $cache_key && '' !== $html ) {
			Cache_Manager::set( $cache_key, $html );
		}

		/**
		 * Fires after the render pipeline completes and HTML has been produced.
		 *
		 * @since 1.6.0
		 * @param string $html Final HTML string.
		 * @param array  $args Original render request arguments.
		 */
		do_action( 'zymarg_product_grid_render_complete', $html, $args );

		return $html;
	}

	// -------------------------------------------------------------------------
	// Vendor "View All" auto-resolution (engine-level, v2.4.0)
	// -------------------------------------------------------------------------

	/**
	 * Auto-resolve the heading "View All" URL to the vendor storefront.
	 *
	 * Engine-level replacement for the old Elementor-only logic (before
	 * v2.4.0 this lived in the product-grid widget, so non-Elementor
	 * consumers such as the standalone single-product page plugin never got
	 * the vendor link). Runs on the fully-normalized config, so
	 * heading.view_all_url is already the canonical array shape. Only fills
	 * the URL when it is still empty -- a manual URL always wins.
	 *
	 * @param array $config Normalized configuration.
	 * @return array Configuration with the vendor URL filled when resolvable.
	 */
	private static function maybe_apply_auto_vendor_view_all( array $config ): array {
		$heading = isset( $config['heading'] ) && is_array( $config['heading'] ) ? $config['heading'] : [];

		if ( 'vendor' !== ( $config['query']['source'] ?? '' ) ) {
			return $config;
		}
		if ( empty( $heading['show_view_all'] ) ) {
			return $config;
		}
		if ( empty( $heading['view_all_auto_vendor'] ) ) {
			return $config;
		}

		// Manual URL always wins -- never overwrite a URL the consumer set.
		$current_url = '';
		if ( isset( $heading['view_all_url'] ) ) {
			$current_url = is_array( $heading['view_all_url'] )
				? (string) ( $heading['view_all_url']['url'] ?? '' )
				: (string) $heading['view_all_url'];
		}
		if ( '' !== $current_url ) {
			return $config;
		}

		if ( ! \Zymarg\WCPG\Vendor\Vendor_Resolver::is_supported() ) {
			return $config;
		}

		// Explicit product id if provided, else auto-detect the current product.
		$pid = isset( $heading['view_all_vendor_product_id'] )
			? max( 0, (int) $heading['view_all_vendor_product_id'] )
			: 0;
		if ( $pid <= 0 ) {
			$pid = self::detect_current_product_id();
		}
		if ( $pid <= 0 ) {
			return $config;
		}

		$vendor_id = (int) \Zymarg\WCPG\Vendor\Vendor_Resolver::resolve( $pid );
		if ( $vendor_id <= 0 ) {
			return $config;
		}

		$status = \Zymarg\WCPG\Vendor\Vendor_Resolver::check_vendor_status( $vendor_id );
		if ( empty( $status['ok'] ) ) {
			return $config;
		}

		$url = (string) \Zymarg\WCPG\Vendor\Vendor_Resolver::get_store_url( $vendor_id );
		if ( '' === $url ) {
			return $config;
		}

		// Write into the canonical view_all_url array shape.
		if ( ! isset( $config['heading']['view_all_url'] ) || ! is_array( $config['heading']['view_all_url'] ) ) {
			$config['heading']['view_all_url'] = [
				'url'         => '',
				'is_external' => false,
				'nofollow'    => false,
			];
		}
		$config['heading']['view_all_url']['url'] = $url;

		return $config;
	}

	/**
	 * Detect the current product id from the main query.
	 *
	 * Mirrors the detection the Elementor widget used before v2.4.0 so the
	 * "View All" link and the grid resolve the same vendor.
	 *
	 * @return int Product id, or 0 when there is no single-product context.
	 */
	private static function detect_current_product_id(): int {
		if ( function_exists( 'is_product' ) && is_product() ) {
			return (int) get_queried_object_id();
		}
		global $post;
		if ( isset( $post ) && $post instanceof \WP_Post && 'product' === $post->post_type ) {
			return (int) $post->ID;
		}
		return 0;
	}

	// -------------------------------------------------------------------------
	// Input resolution
	// -------------------------------------------------------------------------

	/**
	 * Resolve the template configuration using the locked priority order.
	 *
	 * Priority (highest → lowest):
	 *   1. Explicit $config_override array.
	 *   2. $template_slug  — loads config from Template_Registry.
	 *   3. $slot           — resolves slot → template slug → config.
	 *
	 * Returns an empty array when none can be resolved; Config_Normalizer
	 * will apply framework defaults so the render still produces valid output.
	 *
	 * @param array  $config_override Direct config from caller.
	 * @param string $template_slug   Template slug from caller.
	 * @param string $slot            Slot name from caller.
	 * @return array Partial template config (will be normalized downstream).
	 */
	private static function resolve_template_config(
		array  $config_override,
		string $template_slug,
		string $slot
	): array {
		// 1. Explicit config — use as-is (normalizer will complete it).
		if ( ! empty( $config_override ) ) {
			return $config_override;
		}

		// 2. Template slug — load directly from registry.
		if ( '' !== $template_slug ) {
			return Template_Registry::get( sanitize_key( $template_slug ) );
		}

		// 3. Slot — resolve to template slug, then load config.
		if ( '' !== $slot ) {
			$resolved_slug = Slot_Registry::get( sanitize_key( $slot ) );
			if ( null !== $resolved_slug && '' !== $resolved_slug ) {
				return Template_Registry::get( $resolved_slug );
			}

			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				_doing_it_wrong(
					__METHOD__,
					sprintf(
						/* translators: %s: slot name */
						'Zymarg_Product_Grid::render() — slot "%s" is not registered.',
						esc_html( $slot )
					),
					'1.6.0'
				);
			}
		}

		// Nothing resolved — return empty; normalizer applies full defaults.
		return [];
	}

	/**
	 * No public construction — static facade only.
	 */
	private function __construct() {}
}
