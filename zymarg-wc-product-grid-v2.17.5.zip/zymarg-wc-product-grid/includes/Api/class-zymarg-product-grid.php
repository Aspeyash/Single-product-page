<?php
/**
 * Zymarg_Product_Grid — the stable public facade for the ZYMARG Product Grid
 * rendering framework.
 *
 * This is the only class external plugins should ever reference by name.
 * Internal implementations (Public_API, Render_Engine, Query_Adapter, etc.)
 * are free to change; this facade and its render() signature are not.
 *
 * Usage:
 *   Zymarg_Product_Grid::render([
 *       'slot'    => 'related-products',
 *       'context' => [ 'product_id' => 123 ],
 *   ]);
 *
 * @package Zymarg\WCPG
 * @since   1.6.0
 */

use Zymarg\WCPG\Api\Public_API;

defined( 'ABSPATH' ) || exit;

/**
 * Class Zymarg_Product_Grid
 */
final class Zymarg_Product_Grid {

	/**
	 * Render a product grid and return the HTML string.
	 *
	 * Delegates entirely to Public_API::render(). No orchestration here.
	 *
	 * @param array $args Render request arguments.
	 *                    See Public_API::render() for accepted keys.
	 * @return string Rendered HTML, or empty string on failure.
	 */
	public static function render( array $args = [] ): string {
		return Public_API::render( $args );
	}

	/**
	 * No public construction — static facade only.
	 */
	private function __construct() {}
}


if ( ! function_exists( 'zymarg_render_grid' ) ) {
	/**
	 * Convenience wrapper for Zymarg_Product_Grid::render().
	 *
	 * This function is a pure alias — no validation, no extra processing,
	 * no hooks. There is exactly one execution path for any render call.
	 *
	 * Example (in a template file):
	 *   <?php echo zymarg_render_grid([ 'slot' => 'related-products' ]); ?>
	 *
	 * @since 1.6.0
	 * @param array $args Render request arguments.
	 * @return string Rendered HTML, or empty string on failure.
	 */
	function zymarg_render_grid( array $args = [] ): string {
		return Zymarg_Product_Grid::render( $args );
	}
}
