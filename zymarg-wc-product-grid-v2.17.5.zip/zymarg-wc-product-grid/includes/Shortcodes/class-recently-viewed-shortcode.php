<?php
/**
 * Recently-Viewed shortcode.
 *
 * Renders the current visitor's recently-viewed products using THIS plugin's
 * card template (`grid/product-card.php`) — identical to the homepage grid,
 * search results, wishlist page, and Connection Engine category pages.
 *
 *   [zymarg_wcpg_recently_viewed]                   default (4 cols)
 *   [zymarg_wcpg_recently_viewed columns="3"]       force a column count (1-6)
 *   [zymarg_wcpg_recently_viewed limit="12"]        cap visible items (1-20)
 *   [zymarg_wcpg_recently_viewed empty_message="…"] override the empty copy
 *
 * Filter: `zymarg_wcpg_recently_viewed_card_settings` (mirrors the wishlist
 * shortcode filter) lets you tweak which card features show.
 *
 * Data source: \Zymarg\WCPG\Tracking\Recently_Viewed::get_ids() — the SAME
 * store the existing tracker already maintains (user_meta '_zymarg_recently_viewed'
 * for logged-in users, cookie + WC session for guests). No new tracking,
 * no duplicate cookies, no new tables.
 *
 * @package Zymarg\WCPG
 * @since 1.5.2
 */

namespace Zymarg\WCPG\Shortcodes;

defined( 'ABSPATH' ) || exit;

use Zymarg\WCPG\Assets;
use Zymarg\WCPG\Template_Loader;
use Zymarg\WCPG\Tracking\Recently_Viewed;
use Zymarg\WCPG\QuickView\QuickView_Modal;

/**
 * Class Recently_Viewed_Shortcode
 */
class Recently_Viewed_Shortcode {

	const SHORTCODE = 'zymarg_wcpg_recently_viewed';

	/**
	 * Register the shortcode.
	 *
	 * @return void
	 */
	public function register() {
		add_shortcode( self::SHORTCODE, array( $this, 'render' ) );
	}

	/**
	 * Render the visitor's recently-viewed grid.
	 *
	 * @param array|string $atts Optional shortcode attributes.
	 * @return string HTML.
	 */
	public function render( $atts ) {
		$atts = shortcode_atts(
			array(
				'columns'       => '4',
				'limit'         => (string) Recently_Viewed::MAX_IDS,
				'empty_message' => '',
			),
			(array) $atts,
			self::SHORTCODE
		);

		// Hard dependencies.
		if (
			! class_exists( 'WooCommerce' )
			|| ! class_exists( '\Zymarg\WCPG\Tracking\Recently_Viewed' )
			|| ! class_exists( '\Zymarg\WCPG\Template_Loader' )
		) {
			return '';
		}

		// Ensure CSS/JS are present on this page (defense-in-depth; the
		// asset preloader also enqueues these early when this shortcode is
		// detected in post content or when on My Account).
		$this->enqueue_runtime();

		$limit = max( 1, min( (int) Recently_Viewed::MAX_IDS, (int) $atts['limit'] ) );
		$ids   = array_slice( Recently_Viewed::get_ids(), 0, $limit );

		/* ---- Resolve products (skip deleted / unpublished) ---- */
		$products = array();
		foreach ( $ids as $id ) {
			$product = wc_get_product( (int) $id );
			if ( ! $product ) {
				continue;
			}
			$post = get_post( (int) $id );
			if ( ! $post || 'publish' !== $post->post_status ) {
				continue;
			}
			$products[] = $product;
		}

		/* ---- Empty state ---- */
		if ( empty( $products ) ) {
			$msg = '' !== $atts['empty_message']
				? $atts['empty_message']
				: __( 'You\'re new here. The products you look at will live in this space — across all your devices.', 'zymarg-wcpg' );

			$shop_url = function_exists( 'wc_get_page_permalink' )
				? wc_get_page_permalink( 'shop' )
				: home_url( '/' );

			return '<div class="zymarg-wcpg zymarg-wcpg-recently-viewed zymarg-wcpg-recently-viewed--empty">'
				. '<div class="zymarg-wcpg__empty-state">'
				. '<p>' . esc_html( $msg ) . '</p>'
				. '<a class="button zymarg-wcpg__empty-cta" href="' . esc_url( $shop_url ) . '">'
				. esc_html__( 'Start exploring', 'zymarg-wcpg' )
				. '</a>'
				. '</div>'
				. '</div>';
		}

		/* ---- Grid ---- */
		$columns  = max( 1, min( 6, (int) $atts['columns'] ) );
		$settings = $this->default_card_settings();

		$payload = array(
			'source'              => 'recently_viewed',
			'columns'             => $columns,
			'show_image'          => $settings['show_image'],
			'show_discount_badge' => $settings['show_discount_badge'],
			'show_stock_badge'    => $settings['show_stock_badge'],
			'show_wishlist'       => $settings['show_wishlist'],
			'show_quickview'      => $settings['show_quickview'],
			'show_atc'            => $settings['show_atc'],
			'show_title'          => $settings['show_title'],
			'show_rating'         => $settings['show_rating'],
			'show_sold_count'     => $settings['show_sold_count'],
			'show_price'          => $settings['show_price'],
		);

		$widget_id = 'zymarg-wcpg-recently-viewed';

		ob_start();
		?>
		<div class="zymarg-wcpg zymarg-wcpg-recently-viewed"
			data-widget-id="<?php echo esc_attr( $widget_id ); ?>"
			data-zymarg-hydrate="1"
			data-show-view-cart="1"
			data-settings="<?php echo esc_attr( wp_json_encode( $payload ) ); ?>">
			<div class="zymarg-wcpg__grid zymarg-wcpg__grid--cols-<?php echo (int) $columns; ?>">
				<?php
				foreach ( $products as $product ) {
					Template_Loader::get_template(
						'grid/product-card.php',
						array(
							'product'   => $product,
							'settings'  => $settings,
							'widget_id' => $widget_id,
						)
					);
				}
				?>
			</div>
		</div>
		<?php

		if ( class_exists( '\Zymarg\WCPG\QuickView\QuickView_Modal' ) && method_exists( '\Zymarg\WCPG\QuickView\QuickView_Modal', 'flag_mount' ) ) {
			QuickView_Modal::flag_mount();
		}

		return (string) ob_get_clean();
	}

	/**
	 * Default card display settings — same recipe as the Wishlist shortcode
	 * and the Connection Engine, so the card looks identical everywhere.
	 *
	 * @return array
	 */
	private function default_card_settings() {
		$settings = array(
			// Image.
			'show_image'            => 'yes',
			'image_hover_zoom'      => 'yes',
			'image_full_resolution' => 'no',

			// Badges.
			'show_discount_badge'   => 'yes',
			'show_stock_badge'      => 'yes',

			// Wishlist heart (lets the customer save items straight from the
			// recently-viewed grid).
			'show_wishlist'         => 'yes',
			'wishlist_icon'         => null,
			'wishlist_icon_active'  => null,

			// Quick View.
			'show_quickview'        => 'yes',
			'quickview_visibility'  => 'all',
			'quickview_icon'        => null,

			// Add to Cart.
			'show_atc'              => 'yes',
			'atc_icon'              => null,

			// Title.
			'show_title'            => 'yes',

			// Vendor profile.
			'show_vendor'           => 'yes',
			'vendor_position'       => 'below_title',
			'vendor_display'        => 'avatar_name',
			'vendor_link'           => 'yes',
			'vendor_avatar_size'    => array(
				'size' => 24,
				'unit' => 'px',
			),
			'vendor_avatar_side'    => 'left',
			'vendor_avatar_shape'   => 'circle',
			'vendor_avatar_border'  => '',

			// Price.
			'show_price'            => 'yes',
			'price_position'        => 'below_rating',

			// Rating & sold count.
			'show_rating'           => 'yes',
			'show_sold_count'       => 'yes',
			'sold_count_format'     => 'sold_n',
			'meta_layout'           => 'inline',
		);

		/**
		 * Filter the recently-viewed card display settings.
		 *
		 * @since 1.5.2
		 *
		 * @param array $settings Settings passed to `grid/product-card.php`.
		 */
		return (array) apply_filters( 'zymarg_wcpg_recently_viewed_card_settings', $settings );
	}

	/**
	 * Ensure the storefront card runtime is present (idempotent). Note that
	 * the asset preloader (Shortcode_Asset_Preloader) also enqueues these
	 * early at wp_enqueue_scripts priority 5 — before <head> output — when
	 * this shortcode is detected in the queried post, preventing FOUC.
	 *
	 * @return void
	 */
	private function enqueue_runtime() {
		if ( ! class_exists( '\Zymarg\WCPG\Assets' ) ) {
			return;
		}
		wp_enqueue_style( Assets::HANDLE_FRONTEND );
		wp_enqueue_style( Assets::HANDLE_QUICKVIEW );
		wp_enqueue_script( Assets::HANDLE_FRONTEND );
		wp_enqueue_script( Assets::HANDLE_QUICKVIEW );
	}
}
