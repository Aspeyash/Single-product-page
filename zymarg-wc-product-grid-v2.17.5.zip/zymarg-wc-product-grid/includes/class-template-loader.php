<?php
/**
 * Template loader with theme override support.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG;

defined( 'ABSPATH' ) || exit;

/**
 * Class Template_Loader
 *
 * Renders plugin templates with the option for themes to override them by
 * placing files at theme/zymarg-wcpg/<relative_path>.
 *
 * Usage:
 *   Template_Loader::get_template( 'grid/product-card.php', [
 *       'product'   => $product,
 *       'settings'  => $settings,
 *       'widget_id' => $widget_id,
 *   ] );
 */
class Template_Loader {

	/**
	 * Render a template with optional variables in scope.
	 *
	 * Accepts two kinds of path (see locate() for the full resolution order):
	 *
	 *   1. Bundled template — a path relative to this plugin's /templates/
	 *      directory, e.g. `grid/grid-wrapper.php`.
	 *   2. External template — an absolute filesystem path, as supplied by
	 *      Template_Manager::register_card() from a standalone template plugin.
	 *
	 * Both forms support theme overrides.
	 *
	 * @param string $template_name  Relative path under /templates/, or an absolute path.
	 * @param array  $args           Variables to make available inside the template.
	 * @param string $theme_override Optional theme-override path relative to
	 *                               `theme/zymarg-wcpg/`. Required for absolute
	 *                               paths, since a filesystem path outside this
	 *                               plugin carries no meaningful override key.
	 */
	public static function get_template( $template_name, $args = array(), $theme_override = '' ) {
		$located = self::locate( $template_name, $theme_override );

		if ( '' === $located ) {
			self::warn_missing( $template_name );
			return;
		}

		// Make $args available as a single variable AND extract its keys
		// for ergonomic template authoring. EXTR_SKIP prevents collisions
		// from overwriting reserved names ($located, $template_name).
		if ( is_array( $args ) && ! empty( $args ) ) {
			extract( $args, EXTR_SKIP ); // phpcs:ignore WordPress.PHP.DontExtract.extract_extract -- safe: we control all callers.
		}

		include $located;
	}

	/**
	 * Return rendered template as a string instead of echoing.
	 *
	 * @param string $template_name  Template path (relative or absolute).
	 * @param array  $args           Variables.
	 * @param string $theme_override Optional theme-override path.
	 * @return string
	 */
	public static function get_template_html( $template_name, $args = array(), $theme_override = '' ) {
		ob_start();
		self::get_template( $template_name, $args, $theme_override );
		return (string) ob_get_clean();
	}

	/**
	 * Resolve a template reference to a readable file path.
	 *
	 * Resolution order, absolute path (external template plugin):
	 *   1. `theme/zymarg-wcpg/{$theme_override}` — when an override key is given.
	 *   2. The absolute path itself.
	 *
	 * Resolution order, relative path (bundled template):
	 *   1. `theme/zymarg-wcpg/{$template_name}`
	 *   2. `{plugin}/templates/{$template_name}`
	 *
	 * Returns an empty string when nothing readable is found, so callers can
	 * distinguish "not found" from a path that merely looks plausible.
	 *
	 * Prior to v2.1.0 this method unconditionally prefixed every path with
	 * the plugin's own templates directory. An absolute path supplied by a
	 * standalone template plugin was therefore concatenated onto the plugin
	 * directory, producing a nonexistent path — so externally registered
	 * card templates silently rendered as empty strings.
	 *
	 * @since 2.1.0
	 * @param string $template_name  Relative or absolute template path.
	 * @param string $theme_override Optional theme-override path.
	 * @return string Readable absolute path, or '' when not found.
	 */
	private static function locate( $template_name, $theme_override = '' ) {
		$template_name = (string) $template_name;

		if ( '' === $template_name ) {
			return '';
		}

		// --- External template: absolute filesystem path. --------------------
		if ( self::is_absolute_path( $template_name ) ) {
			// Allow themes to override an external template when the caller
			// supplied a stable override key (e.g. 'cards/fashion/product-card.php').
			if ( '' !== $theme_override ) {
				$found = locate_template( array( 'zymarg-wcpg/' . ltrim( (string) $theme_override, '/' ) ) );
				if ( $found ) {
					return $found;
				}
			}

			return is_readable( $template_name ) ? $template_name : '';
		}

		// --- Bundled template: path relative to /templates/. -----------------
		$relative = ltrim( $template_name, '/' );

		$found = locate_template( array( 'zymarg-wcpg/' . $relative ) );
		if ( $found ) {
			return $found;
		}

		$bundled = ZYMARG_WCPG_DIR . 'templates/' . $relative;

		return is_readable( $bundled ) ? $bundled : '';
	}

	/**
	 * Determine whether a path is absolute.
	 *
	 * Delegates to WordPress core's path_is_absolute() when available so
	 * Windows drive letters and stream wrappers are handled consistently,
	 * with a POSIX-style fallback for safety.
	 *
	 * @since 2.1.0
	 * @param string $path Path to test.
	 * @return bool
	 */
	private static function is_absolute_path( $path ) {
		if ( function_exists( 'path_is_absolute' ) ) {
			return (bool) path_is_absolute( $path );
		}

		return ( '/' === $path[0] || '\\' === $path[0] || (bool) preg_match( '#^[a-zA-Z]:[\\\\/]#', $path ) );
	}

	/**
	 * Emit a developer warning when a template cannot be located.
	 *
	 * A missing template previously produced an empty string with no signal
	 * of any kind, which made misregistered external templates effectively
	 * undebuggable. This logs only when WP_DEBUG is on, so production output
	 * and error logs stay clean.
	 *
	 * @since 2.1.0
	 * @param string $template_name The unresolvable template reference.
	 * @return void
	 */
	private static function warn_missing( $template_name ) {
		if ( ! defined( 'WP_DEBUG' ) || ! WP_DEBUG ) {
			return;
		}

		error_log( // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- debug-only diagnostic.
			sprintf(
				'[ZYMARG WCPG] Template could not be located: %s',
				(string) $template_name
			)
		);
	}
}
