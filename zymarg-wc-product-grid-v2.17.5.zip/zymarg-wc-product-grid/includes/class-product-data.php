<?php
/**
 * Product data helpers (price rendering, discount badges, icon rendering).
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG;

defined( 'ABSPATH' ) || exit;

/**
 * Class Product_Data
 *
 * Stateless helpers for rendering individual product UI fragments.
 * All output is escaped at the boundary; callers can echo directly.
 */
class Product_Data {

	/**
	 * Render an icon picked via Elementor's icons control.
	 *
	 * Resolution order (v2.7.0):
	 *   1. An explicit Elementor icons-control value, when Elementor is active.
	 *   2. A bundled inline SVG matching the requested fallback class.
	 *   3. The raw <i class="..."> tag, for icon fonts this plugin does not ship.
	 *
	 * Step 2 is new. Previously the fallback emitted a Font Awesome <i> tag,
	 * which only rendered because Elementor happened to load Font Awesome.
	 * With Elementor removed, those tags collapse to empty boxes, so the
	 * handful of icons the core templates request are now self-contained.
	 *
	 * @param mixed  $icon_setting   Elementor icons control value (array) or null.
	 * @param string $fallback_class Icon class to use when no value is set.
	 */
	public static function render_icon( $icon_setting, $fallback_class = '' ) {
		if ( is_array( $icon_setting ) && ! empty( $icon_setting['value'] ) && class_exists( '\Elementor\Icons_Manager' ) ) {
			\Elementor\Icons_Manager::render_icon( $icon_setting, array( 'aria-hidden' => 'true' ) );
			return;
		}

		if ( ! $fallback_class ) {
			return;
		}

		$svg = self::inline_svg( $fallback_class );
		if ( '' !== $svg ) {
			// Static, self-contained markup built from an internal allow-list.
			echo $svg; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			return;
		}

		// Unknown class: emit the icon-font tag so themes that DO load an
		// icon font keep working exactly as before.
		printf( '<i class="%s" aria-hidden="true"></i>', esc_attr( $fallback_class ) );
	}

	/**
	 * Return inline SVG markup for a known icon class, or '' when unknown.
	 *
	 * @param string $fallback_class Icon class, e.g. 'far fa-heart'.
	 * @return string SVG markup or empty string.
	 */
	public static function inline_svg( $fallback_class ) {
		$key   = trim( (string) $fallback_class );
		$icons = self::icon_svg_map();

		if ( ! isset( $icons[ $key ] ) ) {
			return '';
		}

		$markup = sprintf(
			'<svg class="zymarg-wcpg__svg-icon" xmlns="http://www.w3.org/2000/svg" viewBox="%1$s" aria-hidden="true" focusable="false" role="presentation"><path fill="currentColor" d="%2$s"></path></svg>',
			esc_attr( $icons[ $key ]['view_box'] ),
			esc_attr( $icons[ $key ]['path'] )
		);

		/**
		 * Filter the inline SVG markup emitted for a fallback icon class.
		 *
		 * Lets a theme or child plugin swap in its own icon set without
		 * overriding the card templates.
		 *
		 * @since 2.7.0
		 * @param string $markup Generated SVG markup.
		 * @param string $key    Requested icon class.
		 */
		return (string) apply_filters( 'zymarg_wcpg_inline_svg_icon', $markup, $key );
	}

	/**
	 * Icon class => SVG geometry map.
	 *
	 * Covers every fallback class used by the bundled templates: add-to-cart,
	 * quick view, wishlist (idle + active) and the slider arrows. Geometry is
	 * from Font Awesome 6 Free (CC BY 4.0), so shapes are unchanged from what
	 * the site rendered while Elementor supplied the icon font.
	 *
	 * @return array<string,array{view_box:string,path:string}>
	 */
	private static function icon_svg_map() {
		$icons = array(
			// Add to cart.
			'fas fa-plus'          => array(
				'view_box' => '0 0 448 512',
				'path'     => 'M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32V224H48c-17.7 0-32 14.3-32 32s14.3 32 32 32H192V432c0 17.7 14.3 32 32 32s32-14.3 32-32V288H400c17.7 0 32-14.3 32-32s-14.3-32-32-32H256V80z',
			),
			// Quick view.
			'far fa-eye'           => array(
				'view_box' => '0 0 576 512',
				'path'     => 'M288 80c-65.2 0-118.8 29.6-159.9 67.7C89.6 183.5 63 226 49.4 256c13.6 30 40.2 72.5 78.6 108.3C169.2 402.4 222.8 432 288 432s118.8-29.6 159.9-67.7C486.4 328.5 513 286 526.6 256c-13.6-30-40.2-72.5-78.6-108.3C406.8 109.6 353.2 80 288 80zM95.4 112.6C142.5 68.8 207.2 32 288 32s145.5 36.8 192.6 80.6c46.8 43.5 78.1 95.4 93 131.1c3.3 7.9 3.3 16.7 0 24.6c-14.9 35.7-46.2 87.7-93 131.1C433.5 443.2 368.8 480 288 480s-145.5-36.8-192.6-80.6C48.6 356 17.3 304 2.5 268.3c-3.3-7.9-3.3-16.7 0-24.6C17.3 208 48.6 156 95.4 112.6zM288 336c44.2 0 80-35.8 80-80s-35.8-80-80-80c-.7 0-1.3 0-2 0c1.3 5.1 2 10.5 2 16c0 35.3-28.7 64-64 64c-5.5 0-10.9-.7-16-2c0 .7 0 1.3 0 2c0 44.2 35.8 80 80 80zm0-208a128 128 0 1 1 0 256 128 128 0 1 1 0-256z',
			),
			// Wishlist, idle (outline).
			'far fa-heart'         => array(
				'view_box' => '0 0 512 512',
				'path'     => 'M225.8 468.2l-2.5-2.3L48.1 303.2C17.4 274.7 0 234.7 0 192.8v-3.3c0-70.4 50-130.8 119.2-144C158.6 37.9 198.9 47 231 69.6c9 6.4 17.4 13.8 25 22.3c4.2-4.8 8.7-9.2 13.5-13.3c3.7-3.2 7.5-6.2 11.5-9C313.1 47 353.4 37.9 392.8 45.4C462 58.6 512 119.1 512 189.5v3.3c0 41.9-17.4 81.9-48.1 110.4L288.7 465.9l-2.5 2.3c-8.2 7.6-19 11.9-30.2 11.9s-22-4.2-30.2-11.9zM239.1 145c-.4-.3-.7-.7-1-1.1l-17.8-20c-23.1-25.9-58-37.7-92-31.2C81.6 101.5 48 142.1 48 189.5v3.3c0 28.5 11.9 55.8 32.8 75.2L256 430.7 431.2 268c20.9-19.4 32.8-46.7 32.8-75.2v-3.3c0-47.3-33.6-88-80.1-96.9c-34-6.5-69 5.4-92 31.2l-17.8 20c-.3 .4-.7 .7-1 1.1c-4.5 4.5-10.6 7-16.9 7s-12.4-2.5-16.9-7z',
			),
			// Wishlist, active (filled).
			'fas fa-heart'         => array(
				'view_box' => '0 0 512 512',
				'path'     => 'M47.6 300.4L228.3 469.1c7.5 7 17.4 10.9 27.7 10.9s20.2-3.9 27.7-10.9L464.4 300.4c30.4-28.3 47.6-68 47.6-109.5v-5.8c0-69.9-50.5-129.5-119.4-141C347 36.5 300.6 51.4 268 84L256 96 244 84c-32.6-32.6-79-47.5-124.6-39.9C50.5 55.6 0 115.2 0 185.1v5.8c0 41.5 17.2 81.2 47.6 109.5z',
			),
			// Slider arrows.
			'fas fa-chevron-left'  => array(
				'view_box' => '0 0 320 512',
				'path'     => 'M9.4 233.4c-12.5 12.5-12.5 32.8 0 45.3l192 192c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L77.3 256 246.6 86.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-192 192z',
			),
			'fas fa-chevron-right' => array(
				'view_box' => '0 0 320 512',
				'path'     => 'M310.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-192 192c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L242.7 256 73.4 86.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l192 192z',
			),
		);

		/**
		 * Filter the icon class => SVG geometry map.
		 *
		 * @since 2.7.0
		 * @param array $icons Map of icon class to view_box/path pairs.
		 */
		return (array) apply_filters( 'zymarg_wcpg_icon_svg_map', $icons );
	}

	/**
	 * Render a discount badge for a product on sale.
	 *
	 * Modes:
	 *   percent -> "-25%"
	 *   amount  -> "-$10.00"
	 *   both    -> "-25% / -$10.00"
	 *
	 * Returns empty string when the product is not on sale or pricing is invalid.
	 *
	 * @param \WC_Product $product Product instance.
	 * @param string      $mode    'percent' | 'amount' | 'both'.
	 * @return string Already-escaped HTML.
	 */
	public static function get_discount_badge_html( \WC_Product $product, $mode = 'percent' ) {
		list( $regular, $current ) = self::get_compare_prices( $product );

		if ( $regular <= 0 || $current <= 0 || $current >= $regular ) {
			return '';
		}

		$diff        = $regular - $current;
		$percent     = (int) round( ( $diff / $regular ) * 100 );
		$amount_html = wp_kses_post( wc_price( $diff ) );

		switch ( $mode ) {
			case 'amount':
				/* translators: %s: amount of discount, e.g. -$10 */
				$inner = sprintf( esc_html__( '-%s', 'zymarg-wcpg' ), $amount_html );
				break;
			case 'both':
				$inner = sprintf( '-%d%% / -%s', $percent, $amount_html );
				break;
			case 'percent':
			default:
				$inner = sprintf( '-%d%%', $percent );
				break;
		}

		return '<span class="zymarg-wcpg__badge zymarg-wcpg__badge--discount">' . $inner . '</span>';
	}

	/**
	 * Echo the price block with the locked rules:
	 *   Simple on sale       : <current bold> <small><strike>regular</strike></small>
	 *   Simple no sale       : <regular bold>
	 *   Variable on sale     : lowest sale bold + lowest regular strikethrough subscript
	 *   Variable no sale all : single price bold
	 *   Variable no sale mix : "From {min}" bold
	 *   Out-of-stock products are wrapped in .is-oos by the card, no extra logic needed here.
	 *
	 * @param \WC_Product $product Product instance.
	 */
	public static function render_price( \WC_Product $product ) {
		echo '<div class="zymarg-wcpg__price">';

		if ( $product->is_type( 'variable' ) ) {
			self::render_variable_price( $product );
		} else {
			self::render_simple_price( $product );
		}

		echo '</div>';
	}

	/**
	 * Get (regular, effective) prices in a comparable scalar form for badge math.
	 *
	 * Variable products use the minimum across variations so the discount
	 * badge reflects the cheapest savings shown on the card.
	 *
	 * @param \WC_Product $product Product instance.
	 * @return array{0:float,1:float} [regular, current]
	 */
	private static function get_compare_prices( \WC_Product $product ) {
		if ( $product->is_type( 'variable' ) ) {
			$prices  = $product->get_variation_prices( true );
			$regular = ! empty( $prices['regular_price'] ) ? (float) min( $prices['regular_price'] ) : 0.0;
			$current = ! empty( $prices['price'] ) ? (float) min( $prices['price'] ) : 0.0;
			return array( $regular, $current );
		}

		$regular = (float) $product->get_regular_price();
		$current = (float) $product->get_price();
		return array( $regular, $current );
	}

	/**
	 * Render simple-product price.
	 *
	 * @param \WC_Product $product Product instance.
	 */
	private static function render_simple_price( \WC_Product $product ) {
		$regular = (float) $product->get_regular_price();
		$current = (float) $product->get_price();
		$on_sale = $product->is_on_sale() && $current > 0 && $regular > 0 && $current < $regular;

		echo '<span class="zymarg-wcpg__price-current">' . wp_kses_post( wc_price( $current > 0 ? $current : $regular ) ) . '</span>';

		if ( $on_sale ) {
			echo '<sub class="zymarg-wcpg__price-old"><del>' . wp_kses_post( wc_price( $regular ) ) . '</del></sub>';
		}
	}

	/**
	 * Render variable-product price with left-aligned lowest-sale + lowest-regular strikethrough.
	 *
	 * @param \WC_Product $product Product instance.
	 */
	private static function render_variable_price( \WC_Product $product ) {
		$prices = $product->get_variation_prices( true );

		// Defensive fallback: empty variation prices -> use Woo's price html.
		if ( empty( $prices['price'] ) ) {
			echo '<span class="zymarg-wcpg__price-current">' . wp_kses_post( $product->get_price_html() ) . '</span>';
			return;
		}

		$min_price   = (float) min( $prices['price'] );
		$min_regular = (float) min( $prices['regular_price'] );
		$on_sale     = $min_price < $min_regular;
		$all_same    = ( count( array_unique( $prices['price'] ) ) === 1 );

		if ( $on_sale ) {
			echo '<span class="zymarg-wcpg__price-current">' . wp_kses_post( wc_price( $min_price ) ) . '</span>';
			echo '<sub class="zymarg-wcpg__price-old"><del>' . wp_kses_post( wc_price( $min_regular ) ) . '</del></sub>';
			return;
		}

		if ( $all_same ) {
			echo '<span class="zymarg-wcpg__price-current">' . wp_kses_post( wc_price( $min_price ) ) . '</span>';
			return;
		}

		echo '<span class="zymarg-wcpg__price-current">';
		printf(
			/* translators: %s: minimum variation price */
			esc_html__( 'From %s', 'zymarg-wcpg' ),
			wp_kses_post( wc_price( $min_price ) )
		);
		echo '</span>';
	}
}
