<?php
/**
 * "Best-selling products" source.
 *
 * Catalog-wide ranking by WooCommerce's `total_sales` post-meta counter
 * (DESC). This is the same field WC uses for `orderby=popularity` in its
 * own shortcodes and the WP Admin "Reports → Sales by product" view, so
 * the order here matches what the store owner sees in their reports.
 *
 * Honours all the shared widget controls (in-stock toggle via show_oos,
 * include/exclude products + categories, catalog visibility), inherited
 * from Source_All / Source_Base.
 *
 * Products that have never been sold (no `total_sales` meta row, or
 * stored as 0) are still returned by `meta_value_num` ordering — they
 * just sort last. If the store has zero sales overall the source returns
 * the newest products instead via the `meta_query` fallback below.
 *
 * @package Zymarg\WCPG
 * @since   1.5.5
 */

namespace Zymarg\WCPG\Query;

defined( 'ABSPATH' ) || exit;

/**
 * Class Source_Best_Selling
 *
 * Extends Source_All so every shared knob (stock filter, includes /
 * excludes, visibility) keeps working — we only override the ordering
 * to force `total_sales` DESC regardless of the widget's generic Order-by
 * dropdown.
 */
class Source_Best_Selling extends Source_All {

	/**
	 * @inheritDoc
	 */
	protected function build_args( array $settings ) {
		$args = parent::build_args( $settings );

		// Force best-selling ordering regardless of the generic Order-by control.
		$args['orderby']  = 'meta_value_num';
		$args['order']    = 'DESC';
		$args['meta_key'] = 'total_sales'; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key

		return $args;
	}
}
