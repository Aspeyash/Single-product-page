<?php
/**
 * "Wishlist" source.
 *
 * Implements the locked 5-step flow:
 *   1. Storage handshake (auth-aware reader)
 *   2. Collector (resolve IDs)
 *   3. Target query (post__in)
 *   4. Empty guard
 *   5. Cleanup loop (handled by template layer)
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Query;

defined( 'ABSPATH' ) || exit;

use Zymarg\WCPG\Wishlist\Wishlist_Store;

/**
 * Class Source_Wishlist
 */
class Source_Wishlist extends Source_Base {

	/**
	 * @inheritDoc
	 */
	public function get_products( array $settings ) {
		// Steps 1+2: auth-aware reader.
		$ids = Wishlist_Store::get_ids();

		// Step 4: empty guard.
		if ( empty( $ids ) ) {
			$mode = isset( $settings['wishlist_empty_mode'] ) ? (string) $settings['wishlist_empty_mode'] : 'message';
			return 'hide' === $mode ? self::HIDE_WIDGET : array();
		}

		// Step 3: target query.
		$products = $this->fetch_products_by_ids( $ids, $this->get_limit( $settings ) * 2 );
		$products = $this->apply_shared_filters( $products, $settings );

		// Step 5: render handled by template layer.
		return array_slice( $products, 0, $this->get_limit( $settings ) );
	}
}
