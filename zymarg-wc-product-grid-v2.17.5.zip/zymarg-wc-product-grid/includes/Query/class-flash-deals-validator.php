<?php
/**
 * Flash Deals eligibility validator.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Query;

defined( 'ABSPATH' ) || exit;

/**
 * Class Flash_Deals_Validator
 *
 * The single source of truth for whether a product may appear in the Flash
 * Deals source. Both the source gate and every admin surface read from this
 * class, so a product can never be silently excluded by one and reported as
 * fine by the other.
 *
 * Two distinct kinds of failure are deliberately separated:
 *
 *   Configuration errors  A seller mistake. Fixable, and worth reporting:
 *                         no stock management, no image, no sale price.
 *
 *   Lifecycle states      Entirely normal. A sale that ended on schedule or
 *                         has not started yet is not an error and must never
 *                         be reported as one, or the admin column becomes
 *                         noise that gets ignored.
 *
 * validate() returns configuration errors only. lifecycle() answers the
 * separate question of where the product sits in its sale window.
 *
 * @since 2.10.0
 */
final class Flash_Deals_Validator {

	/** Post meta flag set by the admin curation checkbox. */
	const FLAG_META = '_zymarg_flash_deal';

	/* Configuration error codes. */
	const REASON_NOT_PUBLISHED     = 'not_published';
	const REASON_NOT_VISIBLE       = 'not_visible';
	const REASON_MISSING_IMAGE     = 'missing_image';
	const REASON_NO_REGULAR_PRICE  = 'no_regular_price';
	const REASON_NO_SALE_PRICE     = 'no_sale_price';
	const REASON_NO_SALE_END_DATE  = 'no_sale_end_date';
	const REASON_STOCK_NOT_MANAGED = 'stock_not_managed';
	const REASON_NO_STOCK_QTY      = 'no_stock_quantity';
	const REASON_BACKORDERS        = 'backorders_allowed';
	const REASON_VARIATION_STOCK   = 'variation_stock_not_managed';

	/* Lifecycle states. */
	const STATE_LIVE      = 'live';
	const STATE_SCHEDULED = 'scheduled';
	const STATE_ENDED     = 'ended';

	/**
	 * Request-scoped memo of validate() results, keyed by product id.
	 *
	 * Deliberately not persisted: a stale "not eligible" verdict cached across
	 * requests would keep a product dark after the admin had already fixed it.
	 *
	 * @var array<int, array<int, string>>
	 */
	private static $cache = array();

	/**
	 * Whether an admin has flagged this product for Flash Deals.
	 *
	 * @param int $product_id Product id.
	 * @return bool
	 */
	public static function is_flagged( $product_id ) {
		return 'yes' === get_post_meta( (int) $product_id, self::FLAG_META, true );
	}

	/**
	 * Configuration errors preventing this product from rendering correctly.
	 *
	 * An empty array means the product satisfies the full data contract and
	 * will render a complete flash card.
	 *
	 * @param \WC_Product $product Product to inspect.
	 * @return array<int, string> Reason codes, empty when compliant.
	 */
	public static function validate( \WC_Product $product ) {
		$id = (int) $product->get_id();

		if ( isset( self::$cache[ $id ] ) ) {
			return self::$cache[ $id ];
		}

		$reasons = array();

		if ( 'publish' !== get_post_status( $id ) ) {
			$reasons[] = self::REASON_NOT_PUBLISHED;
		} elseif ( ! $product->is_visible() ) {
			$reasons[] = self::REASON_NOT_VISIBLE;
		}

		// The mockup card is built around a 1:1 image. A placeholder is exactly
		// the inconsistency this contract exists to eliminate.
		if ( ! $product->get_image_id() ) {
			$reasons[] = self::REASON_MISSING_IMAGE;
		}

		if ( $product->is_type( 'variable' ) ) {
			$reasons = array_merge( $reasons, self::validate_variable( $product ) );
		} else {
			$reasons = array_merge( $reasons, self::validate_simple( $product ) );
		}

		$reasons = array_values( array_unique( $reasons ) );

		/**
		 * Filter the configuration errors found for a product.
		 *
		 * @since 2.10.0
		 *
		 * @param array<int, string> $reasons Reason codes.
		 * @param \WC_Product         $product Product inspected.
		 */
		$reasons = (array) apply_filters( 'zymarg_wcpg_flash_deals_validation', $reasons, $product );

		self::$cache[ $id ] = $reasons;

		return $reasons;
	}

	/**
	 * Whether the product satisfies the full data contract.
	 *
	 * @param \WC_Product $product Product to inspect.
	 * @return bool
	 */
	public static function is_eligible( \WC_Product $product ) {
		return array() === self::validate( $product );
	}

	/**
	 * Where the product sits in its sale window.
	 *
	 * Never a configuration error -- see the class docblock.
	 *
	 * @param \WC_Product $product Product to inspect.
	 * @param int         $now     Optional timestamp override.
	 * @return string One of the STATE_* constants.
	 */
	public static function lifecycle( \WC_Product $product, $now = 0 ) {
		$now = $now > 0 ? (int) $now : time();

		$target = $product->is_type( 'variable' ) ? self::first_on_sale_variation( $product ) : $product;
		if ( ! $target instanceof \WC_Product ) {
			return self::STATE_ENDED;
		}

		$from = $target->get_date_on_sale_from();
		$to   = $target->get_date_on_sale_to();

		if ( $from && method_exists( $from, 'getTimestamp' ) && $from->getTimestamp() > $now ) {
			return self::STATE_SCHEDULED;
		}

		if ( ! $to || ! method_exists( $to, 'getTimestamp' ) || $to->getTimestamp() <= $now ) {
			return self::STATE_ENDED;
		}

		return self::STATE_LIVE;
	}

	/**
	 * Human-readable labels for every configuration error code.
	 *
	 * @return array<string, string>
	 */
	public static function reason_labels() {
		return array(
			self::REASON_NOT_PUBLISHED     => __( 'Product is not published', 'zymarg-wcpg' ),
			self::REASON_NOT_VISIBLE       => __( 'Product is hidden from the catalog', 'zymarg-wcpg' ),
			self::REASON_MISSING_IMAGE     => __( 'No featured image set', 'zymarg-wcpg' ),
			self::REASON_NO_REGULAR_PRICE  => __( 'No regular price set', 'zymarg-wcpg' ),
			self::REASON_NO_SALE_PRICE     => __( 'No sale price lower than the regular price', 'zymarg-wcpg' ),
			self::REASON_NO_SALE_END_DATE  => __( 'Sale has no end date', 'zymarg-wcpg' ),
			self::REASON_STOCK_NOT_MANAGED => __( 'Stock management is turned off', 'zymarg-wcpg' ),
			self::REASON_NO_STOCK_QTY      => __( 'Stock quantity is zero or unset', 'zymarg-wcpg' ),
			self::REASON_BACKORDERS        => __( 'Backorders are allowed', 'zymarg-wcpg' ),
			self::REASON_VARIATION_STOCK   => __( 'One or more on-sale variations do not manage stock', 'zymarg-wcpg' ),
		);
	}

	/**
	 * Translate reason codes into readable strings.
	 *
	 * @param array<int, string> $reasons Reason codes.
	 * @return array<int, string>
	 */
	public static function describe( array $reasons ) {
		$labels = self::reason_labels();
		$out    = array();

		foreach ( $reasons as $code ) {
			$out[] = isset( $labels[ $code ] ) ? $labels[ $code ] : $code;
		}

		return $out;
	}

	/**
	 * Drop the memoized verdict for a product.
	 *
	 * @param int $product_id Product id, or 0 to flush everything.
	 * @return void
	 */
	public static function flush_cache( $product_id = 0 ) {
		$product_id = (int) $product_id;

		if ( $product_id > 0 ) {
			unset( self::$cache[ $product_id ] );
			return;
		}

		self::$cache = array();
	}

	// -------------------------------------------------------------------------
	// Private helpers
	// -------------------------------------------------------------------------

	/**
	 * Validate a simple (non-variable) product.
	 *
	 * @param \WC_Product $product Product.
	 * @return array<int, string>
	 */
	private static function validate_simple( \WC_Product $product ) {
		$reasons = array();

		$regular = (float) $product->get_regular_price();
		$sale    = $product->get_sale_price();

		if ( $regular <= 0 ) {
			$reasons[] = self::REASON_NO_REGULAR_PRICE;
		}

		if ( '' === $sale || null === $sale || (float) $sale <= 0 || (float) $sale >= $regular ) {
			$reasons[] = self::REASON_NO_SALE_PRICE;
		}

		$to = $product->get_date_on_sale_to();
		if ( ! $to || ! method_exists( $to, 'getTimestamp' ) ) {
			$reasons[] = self::REASON_NO_SALE_END_DATE;
		}

		return array_merge( $reasons, self::validate_stock( $product ) );
	}

	/**
	 * Validate a variable product.
	 *
	 * Every on-sale variation must independently satisfy the stock contract,
	 * because the card renders a single aggregate bar for the parent. One
	 * unmanaged variation makes that bar unrepresentable.
	 *
	 * @param \WC_Product $product Variable product.
	 * @return array<int, string>
	 */
	private static function validate_variable( \WC_Product $product ) {
		$reasons   = array();
		$on_sale   = 0;
		$no_end    = false;
		$bad_stock = false;

		foreach ( $product->get_children() as $child_id ) {
			$variation = wc_get_product( $child_id );
			if ( ! $variation instanceof \WC_Product || ! $variation->is_on_sale() ) {
				continue;
			}

			++$on_sale;

			$to = $variation->get_date_on_sale_to();
			if ( ! $to || ! method_exists( $to, 'getTimestamp' ) ) {
				$no_end = true;
			}

			if ( array() !== self::validate_stock( $variation ) ) {
				$bad_stock = true;
			}
		}

		if ( 0 === $on_sale ) {
			$reasons[] = self::REASON_NO_SALE_PRICE;
			return $reasons;
		}

		if ( $no_end ) {
			$reasons[] = self::REASON_NO_SALE_END_DATE;
		}

		if ( $bad_stock ) {
			$reasons[] = self::REASON_VARIATION_STOCK;
		}

		return $reasons;
	}

	/**
	 * Validate the stock contract for a product or variation.
	 *
	 * Backorders are excluded because a backorderable product reports itself
	 * as in stock at quantity zero, which would render a full scarcity bar
	 * reading "0 Left".
	 *
	 * @param \WC_Product $object Product or variation.
	 * @return array<int, string>
	 */
	private static function validate_stock( \WC_Product $object ) {
		$reasons = array();

		if ( ! $object->managing_stock() ) {
			$reasons[] = self::REASON_STOCK_NOT_MANAGED;
			return $reasons;
		}

		if ( (int) $object->get_stock_quantity() <= 0 ) {
			$reasons[] = self::REASON_NO_STOCK_QTY;
		}

		if ( 'no' !== $object->get_backorders() ) {
			$reasons[] = self::REASON_BACKORDERS;
		}

		return $reasons;
	}

	/**
	 * First on-sale variation of a variable product.
	 *
	 * @param \WC_Product $product Variable product.
	 * @return \WC_Product|null
	 */
	private static function first_on_sale_variation( \WC_Product $product ) {
		foreach ( $product->get_children() as $child_id ) {
			$variation = wc_get_product( $child_id );
			if ( $variation instanceof \WC_Product && $variation->is_on_sale() ) {
				return $variation;
			}
		}

		return null;
	}
}
