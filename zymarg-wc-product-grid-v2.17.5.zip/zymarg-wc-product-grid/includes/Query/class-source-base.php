<?php
/**
 * Abstract base class for product sources.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Query;

defined( 'ABSPATH' ) || exit;

/**
 * Class Source_Base
 *
 * Sources return:
 *   - An array of \WC_Product objects, OR
 *   - The constant Source_Base::HIDE_WIDGET when the entire widget should
 *     suppress all output (used by Similar and More From Seller per spec).
 *
 * Subclasses implement get_products(); the base provides shared filter
 * application (include/exclude products + categories), caching helpers,
 * and a uniform ID-list-to-product-list resolver.
 */
abstract class Source_Base {

	/** Sentinel return value meaning "render nothing for the entire widget". */
	const HIDE_WIDGET = '__zymarg_wcpg_hide_widget__';

	/** Hard upper bound on products per render (when an explicit limit is set). */
	const MAX_PRODUCTS = 100;

	/** Soft safety ceiling applied when the user picks "unlimited" (0). */
	const UNLIMITED_DEFAULT_CAP = 500;

	/**
	 * Get products for this source.
	 *
	 * @param array $settings Sanitized widget settings.
	 * @return \WC_Product[]|string Array of products, or HIDE_WIDGET sentinel.
	 */
	abstract public function get_products( array $settings );

	/**
	 * Resolve the desired number of products from settings.
	 *
	 * Behaviour:
	 *   - Positive integer 1-100: capped to MAX_PRODUCTS, used as-is
	 *   - 0 or empty: "unlimited" mode; returns the soft safety ceiling
	 *     (UNLIMITED_DEFAULT_CAP, 500 by default), filterable via
	 *     `zymarg_wcpg_unlimited_safety_cap`. Internally the widget
	 *     still fetches a bounded number to prevent catastrophic queries
	 *     on very large catalogs; the ceiling is intentionally generous.
	 *
	 * @param array $settings Widget settings.
	 * @return int
	 */
	protected function get_limit( array $settings ) {
		$raw = isset( $settings['total_products'] ) ? (int) $settings['total_products'] : 8;
		if ( $raw <= 0 ) {
			/**
			 * Filter the safety ceiling applied when "Total products" is set
			 * to 0 (unlimited).
			 *
			 * @param int $ceiling Default 500.
			 */
			$ceiling = (int) apply_filters( 'zymarg_wcpg_unlimited_safety_cap', self::UNLIMITED_DEFAULT_CAP );
			return max( 1, $ceiling );
		}
		return max( 1, min( self::MAX_PRODUCTS, $raw ) );
	}

	/**
	 * Whether the widget is in "unlimited" mode (Total products = 0).
	 *
	 * @param array $settings Widget settings.
	 * @return bool
	 */
	protected function is_unlimited( array $settings ) {
		$raw = isset( $settings['total_products'] ) ? (int) $settings['total_products'] : 8;
		return $raw <= 0;
	}

	/**
	 * Run a WP_Query for products and return WC_Product objects (visible only).
	 *
	 * @param array $args WP_Query args.
	 * @return \WC_Product[]
	 */
	protected function fetch_products_by_query( array $args ) {
		if ( ! function_exists( 'wc_get_product' ) ) {
			return array();
		}
		$args = array_merge(
			array(
				'post_type'           => 'product',
				'post_status'         => 'publish',
				'ignore_sticky_posts' => true,
				'no_found_rows'       => true,
				'fields'              => 'all',
			),
			$args
		);

		$query    = new \WP_Query( $args );
		$products = array();
		if ( $query->have_posts() ) {
			foreach ( $query->posts as $post ) {
				$product = wc_get_product( $post );
				if ( $product && $product->is_visible() ) {
					$products[] = $product;
				}
			}
		}
		return $products;
	}

	/**
	 * Resolve a list of product IDs to WC_Product objects, preserving order.
	 *
	 * @param int[] $ids   Product IDs.
	 * @param int   $limit Maximum products to return.
	 * @return \WC_Product[]
	 */
	protected function fetch_products_by_ids( array $ids, $limit = 0 ) {
		$ids = array_filter( array_map( 'intval', $ids ) );
		$ids = array_values( array_unique( $ids ) );
		if ( empty( $ids ) ) {
			return array();
		}
		if ( $limit > 0 ) {
			$ids = array_slice( $ids, 0, $limit );
		}
		return $this->fetch_products_by_query(
			array(
				'post__in'       => $ids,
				'orderby'        => 'post__in',
				'posts_per_page' => count( $ids ),
			)
		);
	}

	/**
	 * Apply include/exclude filters to a product list.
	 *
	 * @param \WC_Product[] $products Source product list.
	 * @param array         $settings Widget settings.
	 * @return \WC_Product[]
	 */
	protected function apply_shared_filters( array $products, array $settings ) {
		if ( empty( $products ) ) {
			return $products;
		}

		$include_ids = self::parse_id_list( $settings['include_products'] ?? '' );
		$exclude_ids = self::parse_id_list( $settings['exclude_products'] ?? '' );
		$include_cat = isset( $settings['include_categories'] ) ? array_filter( array_map( 'intval', (array) $settings['include_categories'] ) ) : array();
		$exclude_cat = isset( $settings['exclude_categories'] ) ? array_filter( array_map( 'intval', (array) $settings['exclude_categories'] ) ) : array();

		$category_cache = array();
		$get_cats       = static function ( $product_id ) use ( &$category_cache ) {
			if ( ! isset( $category_cache[ $product_id ] ) ) {
				$terms                         = wp_get_post_terms( $product_id, 'product_cat', array( 'fields' => 'ids' ) );
				$category_cache[ $product_id ] = is_array( $terms ) ? array_map( 'intval', $terms ) : array();
			}
			return $category_cache[ $product_id ];
		};

		$filtered = array();
		foreach ( $products as $product ) {
			if ( ! $product instanceof \WC_Product ) {
				continue;
			}
			$pid = (int) $product->get_id();

			if ( $exclude_ids && in_array( $pid, $exclude_ids, true ) ) {
				continue;
			}
			if ( $include_ids && ! in_array( $pid, $include_ids, true ) ) {
				continue;
			}
			if ( $exclude_cat ) {
				$cats = $get_cats( $pid );
				if ( array_intersect( $exclude_cat, $cats ) ) {
					continue;
				}
			}
			if ( $include_cat ) {
				$cats = $get_cats( $pid );
				if ( ! array_intersect( $include_cat, $cats ) ) {
					continue;
				}
			}

			$filtered[] = $product;
		}
		return $filtered;
	}

	/**
	 * Parse a comma-separated ID list from a textual control value.
	 *
	 * @param mixed $raw Raw setting value.
	 * @return int[]
	 */
	protected static function parse_id_list( $raw ) {
		if ( is_array( $raw ) ) {
			return array_values( array_filter( array_map( 'intval', $raw ) ) );
		}
		$raw = (string) $raw;
		if ( '' === trim( $raw ) ) {
			return array();
		}
		$parts = array_map( 'trim', explode( ',', $raw ) );
		return array_values( array_unique( array_filter( array_map( 'intval', $parts ) ) ) );
	}

	/**
	 * Visibility-term tax_query clause that hides "exclude-from-catalog" products.
	 *
	 * @return array<int,array> Empty array when not applicable.
	 */
	protected function get_visibility_tax_clause() {
		if ( ! function_exists( 'wc_get_product_visibility_term_ids' ) ) {
			return array();
		}
		$visibility_terms = wc_get_product_visibility_term_ids();
		if ( empty( $visibility_terms['exclude-from-catalog'] ) ) {
			return array();
		}
		return array(
			array(
				'taxonomy' => 'product_visibility',
				'field'    => 'term_taxonomy_id',
				'terms'    => array( (int) $visibility_terms['exclude-from-catalog'] ),
				'operator' => 'NOT IN',
			),
		);
	}

	/**
	 * Detect the "current" product ID from a single-product context.
	 *
	 * @param array $settings Widget settings.
	 * @return int
	 */
	protected function detect_current_product_id( array $settings ) {
		$auto = ! isset( $settings['similar_auto_detect'] ) || 'yes' === $settings['similar_auto_detect'];
		if ( ! $auto ) {
			return isset( $settings['similar_product_id'] ) ? max( 0, (int) $settings['similar_product_id'] ) : 0;
		}
		if ( function_exists( 'is_product' ) && is_product() ) {
			$current = get_queried_object_id();
			return $current ? (int) $current : 0;
		}
		global $post;
		if ( $post instanceof \WP_Post && 'product' === $post->post_type ) {
			return (int) $post->ID;
		}
		return 0;
	}

	/**
	 * Auto-detect the vendor user ID from the current page context.
	 *
	 * Moved up from Source_Current_Vendor in v2.8.0 so that any source needing
	 * vendor awareness (Flash Deals, and anything added later) shares one
	 * resolution path instead of duplicating it.
	 *
	 * Resolution order:
	 *   1. `author` query var — Dokan store pages and Theme Builder Single
	 *      Store templates are author archives keyed by the vendor.
	 *   2. `dokan_is_store_page()` + queried WP_User.
	 *   3. `author_name` slug resolved via `get_user_by( 'slug' )`.
	 *
	 * No dokan_enable_selling gating — that excluded admin / site-owner
	 * vendors. Callers apply their own "is this a real vendor?" gate.
	 *
	 * @since 2.8.0
	 *
	 * @return int Vendor user ID, or 0 when not on a recognisable store page.
	 */
	protected function detect_current_vendor_id() {
		// Primary: author query var.
		$author_id = (int) get_query_var( 'author' );
		if ( $author_id > 0 ) {
			return $author_id;
		}

		// Secondary: Dokan's own store-page conditional + queried WP_User.
		if ( function_exists( 'dokan_is_store_page' ) ) {
			try {
				if ( dokan_is_store_page() ) {
					$queried = get_queried_object();
					if ( $queried instanceof \WP_User && (int) $queried->ID > 0 ) {
						return (int) $queried->ID;
					}
				}
			} catch ( \Throwable $e ) {
				unset( $e );
			}
		}

		// Tertiary: author_name slug fallback.
		$author_slug = (string) get_query_var( 'author_name' );
		if ( '' !== $author_slug ) {
			$user = get_user_by( 'slug', $author_slug );
			if ( $user instanceof \WP_User && (int) $user->ID > 0 ) {
				return (int) $user->ID;
			}
		}

		return 0;
	}
}
