<?php
/**
 * "All products" source.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Query;

defined( 'ABSPATH' ) || exit;

/**
 * Class Source_All
 *
 * Returns published products honouring catalog visibility, stock toggle,
 * include/exclude filters, and the chosen orderby/order. Also serves as
 * the default fallback when an unknown source is requested.
 */
class Source_All extends Source_Base {

	/**
	 * @inheritDoc
	 */
	public function get_products( array $settings ) {
		$args = $this->build_args( $settings );

		/**
		 * Filter the WP_Query args before running the products query.
		 *
		 * @param array $args     WP_Query args.
		 * @param array $settings Widget settings.
		 */
		// Legacy hook name — kept for backward compatibility.
		$args = apply_filters( 'zymarg_wcpg_query_args', $args, $settings );

		/**
		 * Filter the WP_Query arguments before the query runs.
		 *
		 * Canonical Extension API name (Milestone 7). Use this hook to
		 * exclude products, change ordering, modify tax_query, add meta_query,
		 * or any other WP_Query modification without editing core files.
		 *
		 * @since 1.9.0
		 * @param array $args     WP_Query arguments.
		 * @param array $settings Flattened render settings.
		 */
		$args = apply_filters( 'zymarg_query_args', $args, $settings );
		return $this->fetch_products_by_query( $args );
	}

	/**
	 * Build WP_Query args from settings.
	 *
	 * @param array $settings Widget settings.
	 * @return array
	 */
	protected function build_args( array $settings ) {
		$limit   = $this->get_limit( $settings );
		$orderby = isset( $settings['orderby'] ) ? sanitize_key( $settings['orderby'] ) : 'date';
		$order   = isset( $settings['order'] ) && 'ASC' === strtoupper( $settings['order'] ) ? 'ASC' : 'DESC';

		$args = array(
			'posts_per_page' => $limit,
			'order'          => $order,
		);

		switch ( $orderby ) {
			case 'price':
				$args['orderby']  = 'meta_value_num';
				$args['meta_key'] = '_price'; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				break;
			case 'popularity':
				$args['orderby']  = 'meta_value_num';
				$args['meta_key'] = 'total_sales'; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				break;
			case 'rating':
				$args['orderby']  = 'meta_value_num';
				$args['meta_key'] = '_wc_average_rating'; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				break;
			case 'rand':
				$args['orderby'] = 'rand';
				unset( $args['order'] );
				break;
			case 'menu_order':
				$args['orderby'] = array(
					'menu_order' => 'ASC',
					'date'       => 'DESC',
				);
				unset( $args['order'] );
				break;
			case 'title':
				$args['orderby'] = 'title';
				break;
			case 'date':
			default:
				$args['orderby'] = 'date';
				break;
		}

		// Stock filter (default: in-stock only).
		$show_oos   = isset( $settings['show_oos'] ) && 'yes' === $settings['show_oos'];
		$meta_query = array(); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
		if ( ! $show_oos ) {
			$meta_query[] = array(
				'key'   => '_stock_status',
				'value' => 'instock',
			);
		}
		if ( $meta_query ) {
			$args['meta_query'] = $meta_query; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
		}

		// Include / exclude products by ID.
		$include_ids = self::parse_id_list( $settings['include_products'] ?? '' );
		$exclude_ids = self::parse_id_list( $settings['exclude_products'] ?? '' );
		if ( $include_ids ) {
			$args['post__in'] = $include_ids;
		}
		if ( $exclude_ids ) {
			$args['post__not_in'] = $exclude_ids;
		}

		// Categories include / exclude + visibility.
		$tax_query    = array(); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
		$include_cats = isset( $settings['include_categories'] ) ? array_filter( array_map( 'intval', (array) $settings['include_categories'] ) ) : array();
		$exclude_cats = isset( $settings['exclude_categories'] ) ? array_filter( array_map( 'intval', (array) $settings['exclude_categories'] ) ) : array();

		if ( $include_cats ) {
			$tax_query[] = array(
				'taxonomy' => 'product_cat',
				'field'    => 'term_id',
				'terms'    => $include_cats,
				'operator' => 'IN',
			);
		}
		if ( $exclude_cats ) {
			$tax_query[] = array(
				'taxonomy' => 'product_cat',
				'field'    => 'term_id',
				'terms'    => $exclude_cats,
				'operator' => 'NOT IN',
			);
		}
		foreach ( $this->get_visibility_tax_clause() as $clause ) {
			$tax_query[] = $clause;
		}

		if ( $tax_query ) {
			if ( count( $tax_query ) > 1 ) {
				$tax_query['relation'] = 'AND';
			}
			$args['tax_query'] = $tax_query; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
		}

		return $args;
	}
}
