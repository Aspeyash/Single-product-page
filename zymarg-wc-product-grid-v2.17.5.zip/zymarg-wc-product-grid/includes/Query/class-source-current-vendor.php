<?php
/**
 * Current Vendor source — Dokan store-page-aware product listing.
 *
 * Designed to be dropped onto a ZYMARG Theme Builder "Single Store"
 * template (or Elementor Pro Loop template) so the widget renders ONLY
 * the products belonging to the vendor whose storefront the visitor is
 * currently browsing.
 *
 * Auto-detect only — no manual vendor ID override is exposed by this
 * source. Editors who want to render a specific vendor's products
 * elsewhere can use the existing "More From Seller" source instead,
 * which supports a manual product / vendor selection.
 *
 * Since v1.5.5 the source supports four subsets via the
 * `current_vendor_subset` setting:
 *
 *   - 'all'          (default)  → vendor's full inventory, newest first
 *   - 'featured'                → vendor's WooCommerce-featured products
 *   - 'trending'                → vendor's products ranked by their OWN
 *                                 30-day engagement score (per-vendor
 *                                 trending, not catalog-wide). Cold-start
 *                                 fallback to best-selling, then newest.
 *   - 'best_selling'            → vendor's products ranked by total_sales
 *                                 DESC (WooCommerce's lifetime counter)
 *
 * @package Zymarg\WCPG
 * @since   1.5.4
 */

namespace Zymarg\WCPG\Query;

defined( 'ABSPATH' ) || exit;

use Zymarg\WCPG\Trending\Engagement_Store;
use Zymarg\WCPG\Vendor\Vendor_Cache;
use Zymarg\WCPG\Vendor\Vendor_Resolver;

/**
 * Class Source_Current_Vendor
 *
 * Renders only the current vendor's products when the widget is placed
 * on a Dokan store page (or any store sub-tab — biography, reviews,
 * policies, custom endpoints, etc). HIDE_WIDGET is returned cleanly
 * when:
 *   - Dokan is missing or older than the minimum supported version,
 *   - the page is not a Dokan store page,
 *   - the resolved user is not a Dokan-enabled vendor,
 *   - the vendor is suspended (`dokan_publishing` = `no`),
 *   - the vendor has no products matching the chosen subset.
 *
 * Auto-detection waterfall:
 *   1. `dokan_is_store_page()` true → queried WP_User → vendor ID
 *   2. `author` query var validated against `dokan_enable_selling`
 *   3. `author_name` query var resolved via `get_user_by( 'slug' )`
 *   4. → HIDE_WIDGET
 *
 * Filter `zymarg_wcpg_current_vendor_id` is provided so themes / Theme
 * Builder loop templates can inject a vendor ID from a custom context
 * (a popup bound to a vendor, a custom dynamic tag, etc).
 */
class Source_Current_Vendor extends Source_Base {

	/** 30-day window for per-vendor trending engagement ranking. */
	const TRENDING_WINDOW_DAYS = 30;

	/** Recognised subset keys (also used to sanitise widget input). */
	const SUBSETS = array( 'all', 'featured', 'trending', 'best_selling' );

	/**
	 * @inheritDoc
	 */
	public function get_products( array $settings ) {
		if ( ! Vendor_Resolver::is_supported() ) {
			return self::HIDE_WIDGET;
		}

		$vendor_id = $this->detect_current_vendor_id();

		/**
		 * Filter the resolved vendor ID for the Current Vendor source.
		 *
		 * Returning 0 hides the widget. Use this hook to inject a vendor
		 * ID from a custom page context (a popup, a CPT bound to a
		 * vendor, a dynamic-content tag) where Dokan's own store-page
		 * conditionals don't apply.
		 *
		 * @since 1.5.4
		 *
		 * @param int   $vendor_id Auto-detected vendor user ID, or 0 when unresolved.
		 * @param array $settings  Widget settings.
		 */
		$vendor_id = (int) apply_filters( 'zymarg_wcpg_current_vendor_id', $vendor_id, $settings );

		// v1.5.23: AJAX context override — when the VCF widget injects a vendor ID
		// via _current_vendor_id (because get_query_var is empty in AJAX), use it.
		if ( $vendor_id <= 0 && ! empty( $settings['_current_vendor_id'] ) ) {
			$vendor_id = (int) $settings['_current_vendor_id'];
		}

		if ( $vendor_id <= 0 ) {
			return self::HIDE_WIDGET;
		}

		// v1.5.16: trust Dokan as the single source of truth. If Dokan can
		// hydrate a vendor object for this id, render — no dokan_enable_selling
		// / dokan_publishing gating (which excluded administrator / site-owner
		// vendor accounts, whose selling rights come from their role rather
		// than that user meta). Mirrors the Theme Builder Store Hero / Seller
		// Card behaviour, which renders this same vendor correctly.
		if ( ! $this->vendor_object_is_valid( $vendor_id ) ) {
			return self::HIDE_WIDGET;
		}

		$include_staff = ! isset( $settings['current_vendor_include_staff'] )
			|| 'yes' === $settings['current_vendor_include_staff'];

		$subset = $this->sanitize_subset( $settings['current_vendor_subset'] ?? 'all' );

		// v1.5.22: runtime-injected category term ID from the Vendor Category
		// Filter widget (ZYMARG Theme Builder). Underscore prefix = NOT a saved
		// Elementor setting — injected at AJAX time by Handler_Load_More.
		$category_term_id = isset( $settings['_category_term_id'] )
			? absint( $settings['_category_term_id'] )
			: 0;

		$variant = wp_json_encode(
			array(
				'source'          => 'current_vendor',
				'subset'          => $subset,
				'include_staff'   => $include_staff ? 1 : 0,
				'limit'           => $this->get_limit( $settings ),
				'category_term'   => $category_term_id,
				// v1.5.15: include the plugin version so a plugin upgrade
				// automatically orphans any stale cached result sets from a
				// previous version (e.g. an empty array cached before the
				// v1.5.14 / v1.5.15 vendor-resolution fixes). Without this,
				// a stale empty cache could keep the widget hidden for up to
				// the full 30-minute TTL after upgrading.
				'v'               => defined( 'ZYMARG_WCPG_VERSION' ) ? ZYMARG_WCPG_VERSION : '',
			)
		);

		$cached_ids = Vendor_Cache::get( $vendor_id, $variant );
		if ( false === $cached_ids ) {
			$cached_ids = $this->query_vendor_product_ids( $vendor_id, $include_staff, $subset, $category_term_id );
			Vendor_Cache::set( $vendor_id, $cached_ids, $variant );
		}

		if ( empty( $cached_ids ) ) {
			return self::HIDE_WIDGET;
		}

		$products = $this->fetch_products_by_ids( $cached_ids, $this->get_limit( $settings ) * 2 );
		$products = $this->apply_shared_filters( $products, $settings );
		$products = array_slice( $products, 0, $this->get_limit( $settings ) );

		return $products ? $products : self::HIDE_WIDGET;
	}

	/**
	 * Coerce an arbitrary subset string into a recognised key.
	 *
	 * @param mixed $raw Raw setting value.
	 * @return string One of self::SUBSETS.
	 */
	private function sanitize_subset( $raw ) {
		$raw = is_string( $raw ) ? trim( $raw ) : '';
		return in_array( $raw, self::SUBSETS, true ) ? $raw : 'all';
	}

	/*
	 * detect_current_vendor_id() lived here until v2.8.0. It now lives on
	 * Source_Base as a protected method (identical resolution order and
	 * behaviour) so the Flash Deals source can share it rather than keeping a
	 * second copy in sync. This class inherits it unchanged.
	 */

	/**
	 * Whether Dokan can hydrate a valid vendor object for this user id.
	 *
	 * This is the single "is this a real vendor?" gate as of v1.5.16 —
	 * replacing the previous dokan_enable_selling / dokan_publishing meta
	 * gating that excluded administrator / site-owner vendor accounts. It
	 * mirrors how the Theme Builder Store Hero / Seller Card widgets decide
	 * whether to render (they simply call dokan_get_vendor() and render when
	 * it returns a usable object).
	 *
	 * @since 1.5.16
	 *
	 * @param int $vendor_id Candidate vendor user id.
	 * @return bool
	 */
	private function vendor_object_is_valid( $vendor_id ) {
		$vendor_id = (int) $vendor_id;
		if ( $vendor_id <= 0 || ! function_exists( 'dokan_get_vendor' ) ) {
			return false;
		}
		$vendor = dokan_get_vendor( $vendor_id );
		return is_object( $vendor )
			&& method_exists( $vendor, 'get_id' )
			&& (int) $vendor->get_id() > 0;
	}

	/**
	 * Resolve the vendor's author ID set (staff-aware when enabled).
	 *
	 * @param int  $vendor_id     Vendor user ID.
	 * @param bool $include_staff Whether to also include staff-authored products.
	 * @return int[]
	 */
	private function get_author_ids( $vendor_id, $include_staff ) {
		$author_ids = $include_staff
			? Vendor_Resolver::get_vendor_author_ids( $vendor_id )
			: array( (int) $vendor_id );

		return array_values( array_filter( array_map( 'intval', $author_ids ) ) );
	}

	/**
	 * Dispatch to the right subset-specific query helper.
	 *
	 * v1.5.22: accepts $category_term_id — when > 0, an additional
	 * product_cat tax_query clause is injected to filter results to that
	 * specific category. Passes through to run_vendor_query() via
	 * $extra_tax so all subset variants support category filtering with
	 * zero code duplication.
	 *
	 * @param int    $vendor_id         Vendor user ID.
	 * @param bool   $include_staff     Whether to include staff-authored products.
	 * @param string $subset            One of self::SUBSETS.
	 * @param int    $category_term_id  Optional product_cat term ID to filter by (0 = all).
	 * @return int[] Subset-appropriate product IDs in display order.
	 */
	private function query_vendor_product_ids( $vendor_id, $include_staff, $subset, $category_term_id = 0 ) {
		$author_ids = $this->get_author_ids( $vendor_id, $include_staff );
		if ( empty( $author_ids ) ) {
			return array();
		}

		// v1.5.22: build category tax clause when a specific term is requested.
		$extra_cat_tax = array();
		$cat_term_id   = (int) $category_term_id;
		if ( $cat_term_id > 0 ) {
			$extra_cat_tax[] = array(
				'taxonomy' => 'product_cat',
				'field'    => 'term_id',
				'terms'    => array( $cat_term_id ),
				'operator' => 'IN',
			);
		}

		switch ( $subset ) {
			case 'featured':
				return $this->query_featured( $author_ids, $extra_cat_tax );
			case 'trending':
				return $this->query_trending( $author_ids, $extra_cat_tax );
			case 'best_selling':
				return $this->query_best_selling( $author_ids, $extra_cat_tax );
			case 'all':
			default:
				return $this->query_all_newest( $author_ids, $extra_cat_tax );
		}
	}

	/**
	 * Subset 'all' — vendor's full inventory ordered by publish date DESC.
	 *
	 * @param int[]  $author_ids    Vendor + staff author IDs.
	 * @param array  $extra_cat_tax Additional tax_query clauses (e.g. category filter).
	 * @return int[]
	 */
	private function query_all_newest( array $author_ids, array $extra_cat_tax = array() ) {
		return $this->run_vendor_query(
			$author_ids,
			array(
				'orderby' => 'date',
				'order'   => 'DESC',
			),
			$extra_cat_tax
		);
	}

	/**
	 * Subset 'featured' — vendor's WooCommerce-featured products only.
	 *
	 * @param int[]  $author_ids    Vendor + staff author IDs.
	 * @param array  $extra_cat_tax Additional tax_query clauses (e.g. category filter).
	 * @return int[]
	 */
	private function query_featured( array $author_ids, array $extra_cat_tax = array() ) {
		$featured_term_id = 0;
		if ( function_exists( 'wc_get_product_visibility_term_ids' ) ) {
			$visibility       = wc_get_product_visibility_term_ids();
			$featured_term_id = isset( $visibility['featured'] ) ? (int) $visibility['featured'] : 0;
		}

		if ( $featured_term_id <= 0 ) {
			return array();
		}

		$extra_tax = array(
			array(
				'taxonomy' => 'product_visibility',
				'field'    => 'term_taxonomy_id',
				'terms'    => array( $featured_term_id ),
				'operator' => 'IN',
			),
		);

		// Merge any additional clauses (e.g. category filter).
		$extra_tax = array_merge( $extra_tax, $extra_cat_tax );

		return $this->run_vendor_query(
			$author_ids,
			array(
				'orderby' => 'date',
				'order'   => 'DESC',
			),
			$extra_tax
		);
	}

	/**
	 * Subset 'best_selling' — vendor's products ranked by total_sales DESC.
	 *
	 * @param int[]  $author_ids    Vendor + staff author IDs.
	 * @param array  $extra_cat_tax Additional tax_query clauses (e.g. category filter).
	 * @return int[]
	 */
	private function query_best_selling( array $author_ids, array $extra_cat_tax = array() ) {
		return $this->run_vendor_query(
			$author_ids,
			array(
				'orderby'  => 'meta_value_num',
				'order'    => 'DESC',
				'meta_key' => 'total_sales', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			),
			$extra_cat_tax
		);
	}

	/**
	 * Subset 'trending' — per-vendor trending via the plugin's engagement store.
	 *
	 * @param int[]  $author_ids    Vendor + staff author IDs.
	 * @param array  $extra_cat_tax Additional tax_query clauses (e.g. category filter).
	 * @return int[]
	 */
	private function query_trending( array $author_ids, array $extra_cat_tax = array() ) {
		$vendor_ids = $this->run_vendor_query(
			$author_ids,
			array(
				'orderby' => 'date',
				'order'   => 'DESC',
			),
			$extra_cat_tax
		);

		if ( empty( $vendor_ids ) ) {
			return array();
		}

		$totals    = Engagement_Store::get_window_totals( self::TRENDING_WINDOW_DAYS );
		$scored    = array();
		$any_score = false;

		foreach ( $vendor_ids as $pid ) {
			$score = isset( $totals[ $pid ]['score'] ) ? (int) $totals[ $pid ]['score'] : 0;
			if ( $score > 0 ) {
				$any_score = true;
			}
			$scored[ $pid ] = $score;
		}

		if ( $any_score ) {
			arsort( $scored, SORT_NUMERIC );
			return array_keys( $scored );
		}

		// Cold-start: fall back to best-selling order.
		$best = $this->query_best_selling( $author_ids, $extra_cat_tax );
		if ( ! empty( $best ) ) {
			return $best;
		}

		// Ultimate fallback: newest-first (the list we already queried).
		return $vendor_ids;
	}

	/**
	 * Run a WP_Query against the vendor's author set with shared boilerplate.
	 *
	 * Applies catalog-visibility exclusion via tax_query and post-validates
	 * via WC_Product::is_visible() so password-protected, scheduled, or
	 * draft products don't sneak through.
	 *
	 * v1.5.22: accepts a `_category_term_id` key in $overrides_ext (a
	 * supplementary settings array) to filter by a specific product_cat
	 * term ID at AJAX time. This is injected by Handler_Load_More when the
	 * Vendor Category Filter widget (ZYMARG Theme Builder) sends a
	 * current_vendor_category_term_id in its POST payload.
	 *
	 * @param int[] $author_ids  Vendor + staff author IDs.
	 * @param array $overrides   WP_Query arg overrides (orderby/order/meta_key).
	 * @param array $extra_tax   Additional tax_query clauses to AND together.
	 * @return int[] Visible product IDs.
	 */
	private function run_vendor_query( array $author_ids, array $overrides = array(), array $extra_tax = array() ) {
		if ( empty( $author_ids ) ) {
			return array();
		}

		// v1.5.14: resolve the vendor's products by BOTH post_author AND
		// `_dokan_vendor_id` meta so admin-created-then-assigned products
		// appear on the store page. author__in alone missed them.
		$vendor_product_ids = Vendor_Resolver::get_vendor_product_ids( $author_ids );
		if ( empty( $vendor_product_ids ) ) {
			return array();
		}

		$args = array(
			'post_type'      => 'product',
			'post_status'    => 'publish',
			'post__in'       => $vendor_product_ids,
			// v1.5.23: use -1 (no limit) so ALL vendor products in a category
			// are returned, not just the first 100. The hard cap of 100 was
			// silently excluding products at position 101+ from category filter
			// results — products with multiple categories that happened to be
			// outside the first 100 never appeared when filtering.
			'posts_per_page' => -1,
			'no_found_rows'  => true,
			'fields'         => 'ids',
		);

		foreach ( $overrides as $key => $value ) {
			$args[ $key ] = $value;
		}

		$tax_query = $this->get_visibility_tax_clause();
		foreach ( $extra_tax as $clause ) {
			$tax_query[] = $clause;
		}
		if ( $tax_query ) {
			if ( count( $tax_query ) > 1 ) {
				$tax_query['relation'] = 'AND';
			}
			$args['tax_query'] = $tax_query; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
		}

		$query = new \WP_Query( $args );
		$ids   = is_array( $query->posts ) ? array_map( 'intval', $query->posts ) : array();

		// Final visibility filter using each product's is_visible() method.
		$visible = array();
		foreach ( $ids as $pid ) {
			$product = wc_get_product( $pid );
			if ( $product && $product->is_visible() ) {
				$visible[] = (int) $pid;
			}
		}
		return $visible;
	}
}
