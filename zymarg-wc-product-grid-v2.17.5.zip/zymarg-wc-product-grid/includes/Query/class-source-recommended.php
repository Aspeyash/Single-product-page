<?php
/**
 * "Recommended For You" personalised product source.
 *
 * Implements a content-based recommender with optional behavioural and
 * popularity signals. The visitor's affinity profile is built by
 * Affinity_Profile and then used to score a bounded candidate pool of
 * products. Final results are selected greedily under a vendor diversity
 * cap and a recency penalty so the widget never feels stale or
 * single-seller-dominated.
 *
 * Score formula (all factors normalised 0..1, weights normalised to 1.0):
 *
 *   score(p) =  W_category * category_affinity(profile, p)
 *             + W_purchase * purchase_affinity(profile, p)
 *             + W_brand    * brand_affinity(profile, p)
 *             + W_seller   * seller_affinity(profile, p)
 *             + W_trending * trending_score(p)
 *             + price_band_bonus(profile, p)   // small flat bonus when in band
 *             - recency_penalty(profile, p)    // 0 .. 1.0, decays over 24h
 *
 * Auto-redistribution:
 *   - If the store has no brand taxonomy, W_brand is redistributed evenly
 *     between W_category and W_purchase before normalisation, so a value
 *     of "15%" doesn't silently disappear.
 *   - If Dokan is not active, W_seller is redistributed to W_category.
 *
 * Cold-start path:
 *   When Affinity_Profile reports is_empty, we delegate to
 *   Cold_Start_Fallback (hybrid by default). This guarantees the widget
 *   shows something coherent for brand-new visitors and during launch
 *   when there's no engagement data yet.
 *
 * Caching:
 *   Final scored ID list is cached per visitor via Affinity_Cache. Salt
 *   rotation in that class invalidates all of a visitor's cached
 *   variants atomically on wishlist / cart / order events.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Query;

defined( 'ABSPATH' ) || exit;

use Zymarg\WCPG\Recommendations\Affinity_Cache;
use Zymarg\WCPG\Recommendations\Affinity_Profile;
use Zymarg\WCPG\Recommendations\Cold_Start_Fallback;
use Zymarg\WCPG\Trending\Trending_Calculator;
use Zymarg\WCPG\Vendor\Vendor_Resolver;

/**
 * Class Source_Recommended
 */
class Source_Recommended extends Source_Base {

	/** Maximum candidate pool size to score per request. */
	const POOL_SIZE = 200;

	/** Recency penalty: products viewed within this many hours get penalised. */
	const RECENCY_WINDOW_HOURS = 24;

	/** Recency penalty magnitude at zero seconds (decays linearly to 0 at the window edge). */
	const RECENCY_PENALTY_MAX = 0.40;

	/** Default vendor diversity cap (max products per vendor in result set). */
	const DEFAULT_VENDOR_CAP = 3;

	/**
	 * @inheritDoc
	 */
	public function get_products( array $settings ) {
		// 1. Build the visitor's affinity profile.
		$profile = Affinity_Profile::build();

		// 2. Cold-start: empty profile -> delegate to fallback.
		if ( ! empty( $profile['is_empty'] ) ) {
			$ids = Cold_Start_Fallback::get_ids( $settings, $this->get_limit( $settings ) * 3 );
			return $this->finalize( $ids, $settings );
		}

		// 3. Check the per-visitor result cache.
		$cache_key = Affinity_Cache::make_key( $settings );
		$cached    = Affinity_Cache::get( $cache_key );
		if ( false !== $cached && ! empty( $cached ) ) {
			return $this->finalize( $cached, $settings );
		}

		// 4. Resolve weights (admin-tunable, auto-redistributed).
		$weights = $this->resolve_weights( $settings, $profile );

		// 5. Build candidate pool.
		$candidates = $this->build_candidate_pool( $profile );
		if ( empty( $candidates ) ) {
			// Profile exists but produced no candidates (very narrow store).
			// Fall back to cold-start hybrid for safety.
			$ids = Cold_Start_Fallback::get_ids( $settings, $this->get_limit( $settings ) * 3 );
			return $this->finalize( $ids, $settings );
		}

		// 6. Pre-fetch trending scores (normalised 0..1) for the pool.
		$trending_norm = $this->trending_lookup( $candidates );

		// 7. Score every candidate.
		$exclude_purchased = ! isset( $settings['recommended_exclude_purchased'] ) || 'yes' === $settings['recommended_exclude_purchased'];
		$purchased         = $exclude_purchased ? array_flip( $profile['purchased_ids'] ) : array();
		$recency_enabled   = ! isset( $settings['recommended_recency_penalty'] ) || 'yes' === $settings['recommended_recency_penalty'];
		$now               = time();

		$scored = array();
		foreach ( $candidates as $pid ) {
			$pid = (int) $pid;
			if ( $pid <= 0 ) {
				continue;
			}
			if ( $exclude_purchased && isset( $purchased[ $pid ] ) ) {
				continue;
			}

			$cat_aff  = $this->category_affinity( $pid, $profile );
			$pur_aff  = $this->purchase_affinity_proxy( $pid, $profile );
			$brn_aff  = $weights['brand'] > 0 ? $this->brand_affinity( $pid, $profile ) : 0;
			$ven_aff  = $weights['seller'] > 0 ? $this->seller_affinity( $pid, $profile ) : 0;
			$trend    = isset( $trending_norm[ $pid ] ) ? $trending_norm[ $pid ] : 0;
			$pb_bonus = $this->price_band_bonus( $pid, $profile );

			$score = ( $weights['category'] * $cat_aff )
				+ ( $weights['purchase'] * $pur_aff )
				+ ( $weights['brand'] * $brn_aff )
				+ ( $weights['seller'] * $ven_aff )
				+ ( $weights['trending'] * $trend )
				+ $pb_bonus;

			if ( $recency_enabled ) {
				$score -= $this->recency_penalty( $pid, $profile, $now );
			}

			if ( $score > 0 ) {
				$scored[ $pid ] = $score;
			}
		}

		if ( empty( $scored ) ) {
			$ids = Cold_Start_Fallback::get_ids( $settings, $this->get_limit( $settings ) * 3 );
			return $this->finalize( $ids, $settings );
		}

		arsort( $scored, SORT_NUMERIC );

		// 8. Apply vendor diversity cap greedily.
		$vendor_cap = max( 1, (int) ( $settings['recommended_vendor_cap'] ?? self::DEFAULT_VENDOR_CAP ) );
		$picked     = $this->apply_vendor_diversity( array_keys( $scored ), $vendor_cap, $this->get_limit( $settings ) * 3 );

		// 9. Cache and finalise.
		Affinity_Cache::set( $cache_key, $picked, ! empty( $profile['is_guest'] ) );

		return $this->finalize( $picked, $settings );
	}

	/* ---------------------------------------------------------------------
	 * Weight resolution
	 * ------------------------------------------------------------------ */

	/**
	 * Resolve scoring weights from settings with auto-redistribution.
	 *
	 * @param array $settings Widget settings.
	 * @param array $profile  Affinity profile.
	 * @return array{category:float,purchase:float,brand:float,seller:float,trending:float}
	 */
	private function resolve_weights( array $settings, array $profile ) {
		$w_cat   = max( 0, (int) ( $settings['recommended_w_category'] ?? 40 ) );
		$w_pur   = max( 0, (int) ( $settings['recommended_w_purchase'] ?? 30 ) );
		$w_brn   = max( 0, (int) ( $settings['recommended_w_brand'] ?? 15 ) );
		$w_sel   = max( 0, (int) ( $settings['recommended_w_seller'] ?? 10 ) );
		$w_trend = max( 0, (int) ( $settings['recommended_w_trending'] ?? 5 ) );

		// Auto-redistribute if brand or vendor signals aren't available.
		if ( empty( $profile['brand_taxonomy'] ) ) {
			$half  = (int) floor( $w_brn / 2 );
			$w_cat += $half;
			$w_pur += $w_brn - $half;
			$w_brn  = 0;
		}
		if ( ! Vendor_Resolver::is_supported() ) {
			$w_cat += $w_sel;
			$w_sel  = 0;
		}

		$total = $w_cat + $w_pur + $w_brn + $w_sel + $w_trend;
		if ( $total <= 0 ) {
			return array(
				'category' => 0.4,
				'purchase' => 0.3,
				'brand'    => 0.15,
				'seller'   => 0.1,
				'trending' => 0.05,
			);
		}
		return array(
			'category' => $w_cat / $total,
			'purchase' => $w_pur / $total,
			'brand'    => $w_brn / $total,
			'seller'   => $w_sel / $total,
			'trending' => $w_trend / $total,
		);
	}

	/* ---------------------------------------------------------------------
	 * Candidate pool construction
	 * ------------------------------------------------------------------ */

	/**
	 * Build the candidate pool the scoring loop will iterate over.
	 *
	 * Strategy:
	 *   - Up to 80 products from the profile's top categories.
	 *   - Up to 60 products from the profile's top vendors.
	 *   - Up to 40 products from the profile's top brands.
	 *   - Up to 60 products from trending top-N.
	 *
	 *   Total pool capped at POOL_SIZE.
	 *
	 * @param array $profile Affinity profile.
	 * @return int[]
	 */
	private function build_candidate_pool( array $profile ) {
		$pool = array();

		$cat_ids = array_keys( $profile['category_ids'] ?? array() );
		if ( $cat_ids ) {
			$pool = array_merge( $pool, $this->query_by_terms( 'product_cat', array_slice( $cat_ids, 0, 5 ), 80 ) );
		}

		$ven_ids = array_keys( $profile['vendor_ids'] ?? array() );
		if ( $ven_ids ) {
			$pool = array_merge( $pool, $this->query_by_authors( array_slice( $ven_ids, 0, 5 ), 60 ) );
		}

		if ( ! empty( $profile['brand_taxonomy'] ) ) {
			$brn_ids = array_keys( $profile['brand_ids'] ?? array() );
			if ( $brn_ids ) {
				$pool = array_merge( $pool, $this->query_by_terms( $profile['brand_taxonomy'], array_slice( $brn_ids, 0, 5 ), 40 ) );
			}
		}

		$trending = Trending_Calculator::get_cached_ids();
		if ( ! empty( $trending ) ) {
			$pool = array_merge( $pool, array_slice( $trending, 0, 60 ) );
		}

		$pool = array_values( array_unique( array_map( 'intval', $pool ) ) );
		// Drop products that are in the visitor's recently-viewed list:
		// they don't need to be REshown right away. The recency penalty
		// would handle this softly anyway, but excluding them entirely
		// makes the grid feel fresher for the most-recent few items.
		$seen = array_keys( $profile['seen_ids'] ?? array() );
		if ( $seen ) {
			$pool = array_values( array_diff( $pool, array_slice( $seen, 0, 5 ) ) );
		}

		return array_slice( $pool, 0, self::POOL_SIZE );
	}

	/**
	 * Get product IDs matching any of the supplied taxonomy terms.
	 *
	 * @param string $taxonomy Taxonomy slug.
	 * @param int[]  $term_ids Term IDs.
	 * @param int    $limit    Max products to return.
	 * @return int[]
	 */
	private function query_by_terms( $taxonomy, array $term_ids, $limit ) {
		$term_ids = array_values( array_filter( array_map( 'intval', $term_ids ) ) );
		if ( empty( $term_ids ) || ! taxonomy_exists( $taxonomy ) ) {
			return array();
		}
		$args = array(
			'post_type'      => 'product',
			'post_status'    => 'publish',
			'posts_per_page' => max( 1, (int) $limit ),
			'fields'         => 'ids',
			'no_found_rows'  => true,
			'orderby'        => 'date',
			'order'          => 'DESC',
			'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
				array(
					'taxonomy' => $taxonomy,
					'field'    => 'term_id',
					'terms'    => $term_ids,
					'operator' => 'IN',
				),
			),
		);
		$query = new \WP_Query( $args );
		return is_array( $query->posts ) ? array_map( 'intval', $query->posts ) : array();
	}

	/**
	 * Get product IDs authored by any of the supplied user IDs (vendors + staff).
	 *
	 * @param int[] $vendor_ids Vendor user IDs.
	 * @param int   $limit      Max products to return.
	 * @return int[]
	 */
	private function query_by_authors( array $vendor_ids, $limit ) {
		$author_ids = array();
		foreach ( $vendor_ids as $vid ) {
			$author_ids = array_merge( $author_ids, Vendor_Resolver::get_vendor_author_ids( (int) $vid ) );
		}
		$author_ids = array_values( array_unique( array_filter( array_map( 'intval', $author_ids ) ) ) );
		if ( empty( $author_ids ) ) {
			return array();
		}
		$query = new \WP_Query(
			array(
				'post_type'      => 'product',
				'post_status'    => 'publish',
				'author__in'     => $author_ids,
				'posts_per_page' => max( 1, (int) $limit ),
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'orderby'        => 'date',
				'order'          => 'DESC',
			)
		);
		return is_array( $query->posts ) ? array_map( 'intval', $query->posts ) : array();
	}

	/* ---------------------------------------------------------------------
	 * Affinity sub-scores
	 * ------------------------------------------------------------------ */

	/**
	 * Category affinity: sum of profile category weights for categories
	 * the product belongs to. Output normalised to 0..1.
	 *
	 * @param int   $pid     Product ID.
	 * @param array $profile Profile.
	 * @return float
	 */
	private function category_affinity( $pid, array $profile ) {
		$cats = wp_get_post_terms( $pid, 'product_cat', array( 'fields' => 'ids' ) );
		if ( ! is_array( $cats ) || empty( $cats ) ) {
			return 0;
		}
		$sum = 0.0;
		foreach ( $cats as $cat_id ) {
			$cat_id = (int) $cat_id;
			if ( isset( $profile['category_ids'][ $cat_id ] ) ) {
				$sum += (float) $profile['category_ids'][ $cat_id ];
			}
		}
		// Profile category weights are already 0..1; sum can exceed 1 across
		// multiple matches. Cap at 1.
		return (float) min( 1.0, $sum );
	}

	/**
	 * Brand affinity: same shape as category_affinity but on the brand taxonomy.
	 *
	 * @param int   $pid     Product ID.
	 * @param array $profile Profile.
	 * @return float
	 */
	private function brand_affinity( $pid, array $profile ) {
		$tax = $profile['brand_taxonomy'] ?? '';
		if ( ! $tax ) {
			return 0;
		}
		$brands = wp_get_post_terms( $pid, $tax, array( 'fields' => 'ids' ) );
		if ( ! is_array( $brands ) || empty( $brands ) ) {
			return 0;
		}
		$sum = 0.0;
		foreach ( $brands as $brand_id ) {
			$brand_id = (int) $brand_id;
			if ( isset( $profile['brand_ids'][ $brand_id ] ) ) {
				$sum += (float) $profile['brand_ids'][ $brand_id ];
			}
		}
		return (float) min( 1.0, $sum );
	}

	/**
	 * Seller (Dokan vendor) affinity.
	 *
	 * @param int   $pid     Product ID.
	 * @param array $profile Profile.
	 * @return float
	 */
	private function seller_affinity( $pid, array $profile ) {
		if ( ! Vendor_Resolver::is_supported() || empty( $profile['vendor_ids'] ) ) {
			return 0;
		}
		$vendor_id = Vendor_Resolver::resolve( $pid );
		if ( $vendor_id <= 0 ) {
			return 0;
		}
		return isset( $profile['vendor_ids'][ $vendor_id ] ) ? (float) $profile['vendor_ids'][ $vendor_id ] : 0;
	}

	/**
	 * Purchase affinity proxy.
	 *
	 * The profile already weights purchased items higher (x5) in the
	 * category/brand/vendor scores. To give the "purchase" weight slot
	 * its own meaning, we measure how strongly the candidate's category
	 * set overlaps with the categories the visitor has *purchased* from
	 * specifically (vs merely browsed). Computed at profile build time
	 * is not directly exposed, so we approximate by treating any product
	 * the visitor has bought as a category-affinity multiplier of 1.5x.
	 *
	 * For v1 we use a simpler approach: the category_affinity sub-score
	 * doubled when the visitor has any purchase history at all. This
	 * gives "purchases" an outsized effect on category-driven scoring
	 * without needing a second pass through orders.
	 *
	 * @param int   $pid     Product ID.
	 * @param array $profile Profile.
	 * @return float
	 */
	private function purchase_affinity_proxy( $pid, array $profile ) {
		$has_purchases = ! empty( $profile['purchased_ids'] );
		if ( ! $has_purchases ) {
			// Purchase weight collapses to category affinity for guests.
			return $this->category_affinity( $pid, $profile );
		}
		return min( 1.0, $this->category_affinity( $pid, $profile ) * 1.5 );
	}

	/**
	 * Small flat bonus when the product price falls inside the visitor's
	 * comfort price band. Maxes out at 0.05 contribution so it nudges
	 * ranking without ever flipping a low-scoring product to first place.
	 *
	 * @param int   $pid     Product ID.
	 * @param array $profile Profile.
	 * @return float
	 */
	private function price_band_bonus( $pid, array $profile ) {
		if ( empty( $profile['price_band'] ) ) {
			return 0;
		}
		if ( ! function_exists( 'wc_get_product' ) ) {
			return 0;
		}
		$product = wc_get_product( $pid );
		if ( ! $product instanceof \WC_Product ) {
			return 0;
		}
		$price = (float) $product->get_price();
		if ( $price <= 0 ) {
			return 0;
		}
		$min = (float) $profile['price_band']['min'];
		$max = (float) $profile['price_band']['max'];
		if ( $price >= $min && $price <= $max ) {
			return 0.05;
		}
		return 0;
	}

	/**
	 * Linearly-decaying penalty for products the visitor saw very recently.
	 *
	 * Penalty = max * (1 - hours_since_seen / window). Clamped to [0..max].
	 *
	 * @param int   $pid     Product ID.
	 * @param array $profile Profile.
	 * @param int   $now     Current unix ts.
	 * @return float
	 */
	private function recency_penalty( $pid, array $profile, $now ) {
		if ( empty( $profile['seen_ids'][ $pid ] ) ) {
			return 0;
		}
		$ts            = (int) $profile['seen_ids'][ $pid ];
		$hours_seen    = max( 0, ( $now - $ts ) / HOUR_IN_SECONDS );
		$window        = self::RECENCY_WINDOW_HOURS;
		if ( $hours_seen >= $window ) {
			return 0;
		}
		$decay = 1 - ( $hours_seen / $window );
		return (float) min( self::RECENCY_PENALTY_MAX, self::RECENCY_PENALTY_MAX * $decay );
	}

	/* ---------------------------------------------------------------------
	 * Trending lookup
	 * ------------------------------------------------------------------ */

	/**
	 * Build a normalised trending score map for the candidate pool.
	 *
	 * Higher rank in the cached trending top-N = higher score (1.0 at
	 * position 0, decaying linearly to 0 at the end of the list).
	 *
	 * @param int[] $candidates Candidate IDs.
	 * @return array<int,float>
	 */
	private function trending_lookup( array $candidates ) {
		$top = Trending_Calculator::get_cached_ids();
		if ( empty( $top ) ) {
			return array();
		}
		$total = max( 1, count( $top ) );
		$map   = array();
		foreach ( $top as $rank => $pid ) {
			$pid         = (int) $pid;
			$map[ $pid ] = 1.0 - ( $rank / $total );
		}
		// Restrict the map to candidates we care about so the score loop
		// stays O(|candidates|).
		$want = array_flip( array_map( 'intval', $candidates ) );
		return array_intersect_key( $map, $want );
	}

	/* ---------------------------------------------------------------------
	 * Selection helpers
	 * ------------------------------------------------------------------ */

	/**
	 * Greedy pick honouring vendor diversity cap.
	 *
	 * Walks the score-sorted ID list, taking each ID unless its vendor
	 * has already filled its cap. Stops at $hard_limit picks. When
	 * Dokan isn't active (no resolvable vendor) the cap is bypassed.
	 *
	 * @param int[] $sorted_ids ID list in score-desc order.
	 * @param int   $cap_per    Max products per vendor in result.
	 * @param int   $hard_limit Maximum total picks.
	 * @return int[]
	 */
	private function apply_vendor_diversity( array $sorted_ids, $cap_per, $hard_limit ) {
		if ( ! Vendor_Resolver::is_supported() ) {
			return array_slice( $sorted_ids, 0, $hard_limit );
		}
		$picked    = array();
		$deferred  = array();
		$by_vendor = array();
		foreach ( $sorted_ids as $pid ) {
			$pid       = (int) $pid;
			$vendor_id = Vendor_Resolver::resolve( $pid );
			if ( $vendor_id <= 0 ) {
				$picked[] = $pid;
			} else {
				$by_vendor[ $vendor_id ] = ( $by_vendor[ $vendor_id ] ?? 0 );
				if ( $by_vendor[ $vendor_id ] < $cap_per ) {
					$picked[]                  = $pid;
					$by_vendor[ $vendor_id ] += 1;
				} else {
					$deferred[] = $pid;
				}
			}
			if ( count( $picked ) >= $hard_limit ) {
				break;
			}
		}
		// If we couldn't fill the slate due to the cap (small store with
		// few vendors), fall back to the deferred list to top up.
		if ( count( $picked ) < $hard_limit && ! empty( $deferred ) ) {
			$picked = array_merge( $picked, array_slice( $deferred, 0, $hard_limit - count( $picked ) ) );
		}
		return array_slice( $picked, 0, $hard_limit );
	}

	/* ---------------------------------------------------------------------
	 * Finalisation
	 * ------------------------------------------------------------------ */

	/**
	 * Resolve final WC_Product list and apply shared filters.
	 *
	 * @param int[] $ids      Selected IDs in order.
	 * @param array $settings Widget settings.
	 * @return \WC_Product[]
	 */
	private function finalize( array $ids, array $settings ) {
		if ( empty( $ids ) ) {
			return array();
		}
		$products = $this->fetch_products_by_ids( $ids, $this->get_limit( $settings ) * 2 );

		$show_oos = isset( $settings['show_oos'] ) && 'yes' === $settings['show_oos'];
		if ( ! $show_oos ) {
			$products = array_values(
				array_filter(
					$products,
					static function ( $p ) {
						return $p instanceof \WC_Product && $p->is_in_stock();
					}
				)
			);
		}

		$products = $this->apply_shared_filters( $products, $settings );
		return array_slice( $products, 0, $this->get_limit( $settings ) );
	}
}
