<?php
/**
 * Category page product source.
 *
 * Detects the current product category from the URL and returns products
 * scoped to that term. Falls back to Source_All on non-category pages so
 * the widget is safe to place anywhere.
 *
 * Contexts handled:
 *   1. Product category archive (/product-category/footwear/)
 *      is_tax('product_cat') = true - reads get_queried_object()
 *   2. Main shop page (/shop/)
 *      is_shop() = true - shows all products (configurable)
 *   3. AJAX load-more
 *      reads _category_term_id from POST payload
 *   4. Any other page - falls back to Source_All
 *
 * Addition 1: Respects WooCommerce URL orderby parameter when present.
 * Addition 2: Exposes term_id, term_name, term_slug via filters.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Query;

defined( 'ABSPATH' ) || exit;

/**
 * Class Source_Category
 */
class Source_Category extends Source_Base {

	// ----------------------------------------------------------------
	// Constants
	// ----------------------------------------------------------------

	/** Maximum subcategory recursion depth. */
	const MAX_DEPTH = 5;

	// ----------------------------------------------------------------
	// Runtime state
	// ----------------------------------------------------------------

	/** @var int|null Resolved term ID. Null = not on a category page. */
	private $term_id = null;

	/** @var string Resolved term name. */
	private $term_name = '';

	/** @var string Resolved term slug. */
	private $term_slug = '';

	// ----------------------------------------------------------------
	// Public API
	// ----------------------------------------------------------------

	/**
	 * Return products for this source.
	 *
	 * @param array $settings Sanitized widget settings.
	 * @return \WC_Product[]|string
	 */
	public function get_products( array $settings ) {

		// -- 1. Resolve context ----------------------------------------
		$context = $this->resolve_context( $settings );

		// -- 2. Fallback -----------------------------------------------
		if ( 'fallback' === $context ) {
			return ( new Source_All() )->get_products( $settings );
		}

		// -- 3. Expose metadata via filters ----------------------------
		$this->register_metadata_filters();

		// -- 4. Build query args ---------------------------------------
		$args = $this->build_args( $settings, $context );

		// -- 5. Apply shared query_args filter -------------------------
		// Legacy hook name — kept for backward compatibility.
		$args = apply_filters( 'zymarg_wcpg_query_args', $args, $settings );

		/**
		 * Filter the WP_Query arguments before the query runs.
		 *
		 * Canonical Extension API name (Milestone 7). Use this hook to
		 * exclude products, change ordering, modify tax_query, add meta_query,
		 * or any other WP_Query modification without editing core files.
		 *
		 * @since 1.9.0
		 * @param array $args     WP_Query arguments.
		 * @param array $settings Flattened render settings.
		 */
		$args = apply_filters( 'zymarg_query_args', $args, $settings );

		// -- 6. Fetch and return ---------------------------------------
		return $this->fetch_products_by_query( $args );
	}

	// ----------------------------------------------------------------
	// Private - context resolution
	// ----------------------------------------------------------------

	/**
	 * Determine which page context we are in and populate term properties.
	 *
	 * Returns one of:
	 *   'category' - on a product_cat archive, term_id populated
	 *   'shop'     - on the main shop page, no term
	 *   'fallback' - any other page
	 *
	 * @param array $settings Widget settings.
	 * @return string
	 */
	private function resolve_context( array $settings ) {

		// AJAX load-more: term ID passed explicitly from button data attr.
		if ( ! empty( $settings['_category_term_id'] ) ) {
			$term_id = (int) $settings['_category_term_id'];
			if ( $term_id > 0 ) {
				$term = get_term( $term_id, 'product_cat' );
				if ( $term && ! is_wp_error( $term ) ) {
					$this->term_id   = $term_id;
					$this->term_name = $term->name;
					$this->term_slug = $term->slug;
					return 'category';
				}
			}
			return 'fallback';
		}

		// Standard category archive page.
		if ( function_exists( 'is_tax' ) && is_tax( 'product_cat' ) ) {
			$term = get_queried_object();
			if ( $term instanceof \WP_Term ) {
				$this->term_id   = (int) $term->term_id;
				$this->term_name = $term->name;
				$this->term_slug = $term->slug;
				return 'category';
			}
		}

		// Main shop page.
		if ( function_exists( 'is_shop' ) && is_shop() ) {
			$shop_behavior = isset( $settings['cat_shop_behavior'] )
				? $settings['cat_shop_behavior']
				: 'all';
			return 'fallback' === $shop_behavior ? 'fallback' : 'shop';
		}

		// Editor preview - show all products as safe fallback.
		if (
			class_exists( '\Elementor\Plugin' )
			&& isset( \Elementor\Plugin::$instance )
			&& \Elementor\Plugin::$instance->editor
			&& \Elementor\Plugin::$instance->editor->is_edit_mode()
		) {
			return 'fallback';
		}

		return 'fallback';
	}

	// ----------------------------------------------------------------
	// Private - query builder
	// ----------------------------------------------------------------

	/**
	 * Build WP_Query args for the resolved context.
	 *
	 * @param array  $settings Widget settings.
	 * @param string $context  'category' or 'shop'.
	 * @return array
	 */
	private function build_args( array $settings, $context ) {
		$limit  = $this->get_limit( $settings );
		$offset = isset( $settings['_offset'] ) ? (int) $settings['_offset'] : 0;

		// -- Orderby ---------------------------------------------------
		// Addition 1: respect WooCommerce URL orderby when present,
		// fall back to widget setting, then default to popularity.
		$orderby = $this->resolve_orderby( $settings );

		$args = array(
			'posts_per_page' => $limit,
			'offset'         => $offset,
		);

		// Map orderby string to WP_Query args.
		switch ( $orderby ) {
			case 'price':
				$args['orderby']  = 'meta_value_num';
				$args['meta_key'] = '_price'; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				$args['order']    = 'ASC';
				break;
			case 'price-desc':
				$args['orderby']  = 'meta_value_num';
				$args['meta_key'] = '_price'; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				$args['order']    = 'DESC';
				break;
			case 'rating':
				$args['orderby']  = 'meta_value_num';
				$args['meta_key'] = '_wc_average_rating'; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				$args['order']    = 'DESC';
				break;
			case 'date':
				$args['orderby'] = 'date';
				$args['order']   = 'DESC';
				break;
			case 'menu_order':
				$args['orderby'] = array(
					'menu_order' => 'ASC',
					'date'       => 'DESC',
				);
				break;
			case 'rand':
				$args['orderby'] = 'rand';
				break;
			case 'popularity':
			default:
				$args['orderby']  = 'meta_value_num';
				$args['meta_key'] = 'total_sales'; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				$args['order']    = 'DESC';
				break;
		}

		// -- Stock filter ----------------------------------------------
		$show_oos   = isset( $settings['show_oos'] ) && 'yes' === $settings['show_oos'];
		$meta_query = array(); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
		if ( ! $show_oos ) {
			$meta_query[] = array(
				'key'   => '_stock_status',
				'value' => 'instock',
			);
		}

		// Merge with existing meta_key for orderby (avoid overwriting).
		if ( $meta_query ) {
			if ( isset( $args['meta_key'] ) ) {
				$meta_query[] = array(
					'key'     => $args['meta_key'],
					'compare' => 'EXISTS',
				);
				$meta_query['relation'] = 'AND';
			}
			$args['meta_query'] = $meta_query; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
		}

		// -- Tax query ------------------------------------------------
		$tax_query = array(); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query

		if ( 'category' === $context && null !== $this->term_id ) {
			$include_subs = ! isset( $settings['cat_include_subcategories'] )
				|| 'yes' === $settings['cat_include_subcategories'];

			$term_ids = array( $this->term_id );
			if ( $include_subs ) {
				$term_ids = array_merge(
					$term_ids,
					$this->get_all_child_term_ids( $this->term_id )
				);
				$term_ids = array_values( array_unique( $term_ids ) );
			}

			$tax_query[] = array(
				'taxonomy' => 'product_cat',
				'field'    => 'term_id',
				'terms'    => $term_ids,
				'operator' => 'IN',
			);
		}
		// 'shop' context: no category filter - show all products.

		// Visibility clause - hides exclude-from-catalog products.
		foreach ( $this->get_visibility_tax_clause() as $clause ) {
			$tax_query[] = $clause;
		}

		if ( $tax_query ) {
			if ( count( $tax_query ) > 1 ) {
				$tax_query['relation'] = 'AND';
			}
			$args['tax_query'] = $tax_query; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
		}

		return $args;
	}

	/**
	 * Resolve the effective orderby.
	 *
	 * Addition 1: WooCommerce URL parameter takes priority over the widget
	 * setting. Widget setting takes priority over the default (popularity).
	 *
	 * WooCommerce URL values -> internal keys:
	 *   popularity  -> popularity
	 *   rating      -> rating
	 *   date        -> date
	 *   price       -> price (ASC)
	 *   price-desc  -> price-desc
	 *
	 * @param array $settings Widget settings.
	 * @return string Internal orderby key.
	 */
	private function resolve_orderby( array $settings ) {
		// WooCommerce sort URL parameter (e.g. ?orderby=price).
		$url_map = array(
			'popularity' => 'popularity',
			'rating'     => 'rating',
			'date'       => 'date',
			'price'      => 'price',
			'price-desc' => 'price-desc',
		);

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$url_orderby = isset( $_GET['orderby'] )
			? sanitize_key( wp_unslash( $_GET['orderby'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			: '';

		if ( $url_orderby && isset( $url_map[ $url_orderby ] ) ) {
			return $url_map[ $url_orderby ];
		}

		// Widget setting.
		$widget_orderby = isset( $settings['cat_orderby'] )
			? sanitize_key( $settings['cat_orderby'] )
			: '';
		if ( $widget_orderby && isset( $url_map[ $widget_orderby ] ) ) {
			return $widget_orderby;
		}

		// Decision 3 default: popularity.
		return 'popularity';
	}

	/**
	 * Recursively collect all descendant term IDs up to MAX_DEPTH levels.
	 *
	 * @param int $parent_id Parent term ID.
	 * @param int $depth     Current recursion depth.
	 * @return int[]
	 */
	private function get_all_child_term_ids( $parent_id, $depth = 0 ) {
		if ( $depth >= self::MAX_DEPTH ) {
			return array();
		}

		$children = get_term_children( (int) $parent_id, 'product_cat' );
		if ( is_wp_error( $children ) || empty( $children ) ) {
			return array();
		}

		$all = array_map( 'intval', $children );
		foreach ( $all as $child_id ) {
			$grandchildren = $this->get_all_child_term_ids( $child_id, $depth + 1 );
			if ( ! empty( $grandchildren ) ) {
				$all = array_merge( $all, $grandchildren );
			}
		}

		return array_values( array_unique( $all ) );
	}

	/**
	 * Register one-time filters exposing term metadata.
	 *
	 * Addition 2: exposes term_id, term_name, and term_slug so templates,
	 * the load-more button, and analytics code can read them without
	 * calling get_queried_object() again.
	 */
	private function register_metadata_filters() {
		$term_id   = $this->term_id;
		$term_name = $this->term_name;
		$term_slug = $this->term_slug;

		/**
		 * Current category term ID.
		 * Used by the load-more button (data-category-term-id).
		 *
		 * @param int|null $term_id
		 */
		add_filter(
			'zymarg_wcpg_category_term_id',
			static function () use ( $term_id ) {
				return $term_id;
			}
		);

		/**
		 * Current category term name.
		 * Useful for dynamic headings and analytics events.
		 *
		 * @param string $term_name
		 */
		add_filter(
			'zymarg_wcpg_category_term_name',
			static function () use ( $term_name ) {
				return $term_name;
			}
		);

		/**
		 * Current category term slug.
		 * Useful for Algolia scoping and URL construction.
		 *
		 * @param string $term_slug
		 */
		add_filter(
			'zymarg_wcpg_category_term_slug',
			static function () use ( $term_slug ) {
				return $term_slug;
			}
		);
	}
}
