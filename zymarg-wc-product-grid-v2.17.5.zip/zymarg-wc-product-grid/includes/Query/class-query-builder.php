<?php
/**
 * Centralised product query builder / source dispatcher.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Query;

defined( 'ABSPATH' ) || exit;

/**
 * Class Query_Builder
 *
 * Resolves the configured "source" setting to a Source_Base instance and
 * delegates the query. Registered sources:
 *   all            -> Source_All
 *   dynamic        -> Source_Dynamic
 *   featured       -> Source_Featured
 *   best_selling   -> Source_Best_Selling (catalog-wide, ranked by total_sales DESC)
 *   similar        -> Source_Similar
 *   recent         -> Source_Recent
 *   wishlist       -> Source_Wishlist
 *   trending       -> Source_Trending
 *   vendor         -> Source_Vendor ("More From Seller" — Elementor label only; canonical key is vendor)
 *   current_vendor -> Source_Current_Vendor (auto-scoped to Dokan store page)
 *   algolia        -> Source_Algolia  (Algolia-powered search results page)
 *   category       -> Source_Category (auto-detected category/shop page)
 *   recommended    -> Source_Recommended (per-visitor personalised feed)
 *
 * Naming convention (v2.0.2):
 *   The registry key IS the canonical source identifier used everywhere —
 *   in PHP (Public_API::render), shortcodes ([zymarg_products source="vendor"]),
 *   and Elementor control values. Human-readable labels ("More From Seller")
 *   are UI-only and live only in the Elementor widget control definition.
 *   There are no aliases — one key, one source.
 *
 * Source classes return either an array of \WC_Product OR the
 * Source_Base::HIDE_WIDGET sentinel. Callers (the widget) interpret
 * HIDE_WIDGET as "render no markup at all".
 */
class Query_Builder {

	/**
	 * Hard upper bound mirrors the widget control cap.
	 */
	const MAX_PRODUCTS = 100;

	/**
	 * Get products for a widget instance.
	 *
	 * @param array $settings Sanitized widget settings.
	 * @return \WC_Product[]|string Array of products, or Source_Base::HIDE_WIDGET.
	 */
	public static function get_products( array $settings ) {
		if ( ! function_exists( 'wc_get_product' ) ) {
			return array();
		}

		$source_key = isset( $settings['source'] ) ? sanitize_key( $settings['source'] ) : 'all';
		$source     = self::resolve_source( $source_key );

		return $source->get_products( $settings );
	}

	/**
	 * Resolve a source key to a Source_Base instance.
	 *
	 * Unknown keys (and Phase 3B sources before they ship) fall back to
	 * Source_All so the widget always renders something sensible.
	 *
	 * @param string $key Source key from settings.
	 * @return Source_Base
	 */
	public static function resolve_source( $key ) {
		$registry = self::get_registry();

		$class = isset( $registry[ $key ] ) ? $registry[ $key ] : Source_All::class;
		if ( ! class_exists( $class ) ) {
			$class = Source_All::class;
		}
		return new $class();
	}

	/**
	 * The source-key -> class-name registry, after filtering.
	 *
	 * Extracted from resolve_source() in v2.12.0 so that callers can ask what
	 * sources exist WITHOUT instantiating one. resolve_source() deliberately
	 * falls back to Source_All for an unknown key, which is the right
	 * behaviour for a widget that must always render something -- but it makes
	 * "is this source real?" unanswerable from the outside. Consumers were
	 * therefore hardcoding their own copy of this list, which rots the moment
	 * a source is added here.
	 *
	 * @since 2.12.0
	 * @return array<string,string> Map of source key -> fully-qualified class name.
	 */
	public static function get_registry() {
		/**
		 * Filter the source-key -> class-name registry.
		 *
		 * Plugins / Phase 3B can plug in by adding additional entries.
		 *
		 * @param array<string,string> $registry Map of source key -> FQCN.
		 */
		return (array) apply_filters(
			'zymarg_wcpg_source_registry',
			array(
				'all'            => Source_All::class,
				'dynamic'        => Source_Dynamic::class,
				'featured'       => Source_Featured::class,
				'best_selling'   => Source_Best_Selling::class,
				'similar'        => Source_Similar::class,
				'recent'         => Source_Recent::class,
				'wishlist'       => Source_Wishlist::class,
				'trending'       => Source_Trending::class,
				'vendor'         => Source_Vendor::class,
				'current_vendor' => Source_Current_Vendor::class,
				'algolia'        => Source_Algolia::class,
				'category'       => Source_Category::class,
				'recommended'    => Source_Recommended::class,
				'flash_deals'    => Source_Flash_Deals::class,
			)
		);
	}

	/**
	 * Whether a source key is registered AND its class is actually loadable.
	 *
	 * The class_exists() half matters as much as the registry half: a key can
	 * be registered while the class that implements it ships in a later
	 * release. resolve_source() silently substitutes Source_All in that case,
	 * so a caller that skipped this check would render a "Flash Deals" page
	 * full of unrelated products and never know.
	 *
	 * @since 2.12.0
	 * @param string $key Source key.
	 * @return bool
	 */
	public static function has_source( $key ) {
		$key = sanitize_key( (string) $key );

		if ( '' === $key ) {
			return false;
		}

		$registry = self::get_registry();

		if ( ! isset( $registry[ $key ] ) ) {
			return false;
		}

		return class_exists( $registry[ $key ] );
	}
}
