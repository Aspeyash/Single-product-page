<?php
/**
 * "Flash Deals" source.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Query;

defined( 'ABSPATH' ) || exit;

/**
 * Class Source_Flash_Deals
 *
 * Returns products whose discount is genuinely time-limited: on sale right
 * now AND carrying a sale end date that is still in the future.
 *
 * A permanent discount (a sale price with no end date) is deliberately NOT a
 * flash deal and is excluded. That hard exclusion is what separates this
 * source from a plain "on sale" grid.
 *
 * Variable products are resolved through their variations, because
 * WooCommerce stores sale windows on the variation and never on the parent.
 * The soonest-ending qualifying variation represents the product.
 *
 * Ordering defaults to `sale_end` (ending soonest first). When nothing
 * qualifies the source returns HIDE_WIDGET so the entire widget disappears
 * instead of rendering an empty row.
 *
 * @since 2.8.0
 */
class Source_Flash_Deals extends Source_Base {

	/** Recognised vendor scoping modes. */
	const SCOPES = array( 'auto', 'site', 'vendor' );

	/** Recognised ordering modes for this source. */
	const ORDERBY = array( 'sale_end', 'discount', 'price', 'title', 'date', 'popularity', 'rating', 'rand' );

	/**
	 * Soonest sale-end timestamp across the products returned this request.
	 *
	 * @var int
	 */
	private static $soonest_end_ts = 0;

	/**
	 * Whether the cache-TTL clamp filter has already been attached.
	 *
	 * @var bool
	 */
	private static $ttl_filter_added = false;

	/**
	 * Sale end timestamps for the products returned this request.
	 *
	 * Published so Countdown_Renderer can print a per-card end date without
	 * repeating the variation walk this source has already performed.
	 *
	 * @var array<int, int>
	 */
	private static $end_map = array();

	/**
	 * @inheritDoc
	 */
	public function get_products( array $settings ) {
		if ( ! function_exists( 'wc_get_product_ids_on_sale' ) || ! function_exists( 'wc_get_product' ) ) {
			return self::HIDE_WIDGET;
		}

		$on_sale_ids = wc_get_product_ids_on_sale();
		if ( empty( $on_sale_ids ) ) {
			return self::HIDE_WIDGET;
		}

		// Vendor scoping: 'site' is always site-wide, 'vendor' demands a
		// resolvable vendor, 'auto' scopes only when a vendor context exists.
		$scope     = $this->resolve_scope( $settings );
		$vendor_id = 0;
		if ( 'site' !== $scope ) {
			$vendor_id = $this->resolve_scope_vendor_id( $settings );
			if ( 'vendor' === $scope && $vendor_id <= 0 ) {
				return self::HIDE_WIDGET;
			}
		}

		$now          = time();
		$min_discount = isset( $settings['flash_min_discount'] ) ? max( 0, min( 100, (int) $settings['flash_min_discount'] ) ) : 0;
		$show_oos     = ! empty( $settings['show_oos'] ) && 'no' !== $settings['show_oos'];

		$candidates = array();
		foreach ( $on_sale_ids as $raw_id ) {
			$pid = (int) $raw_id;
			if ( $pid <= 0 ) {
				continue;
			}

			// Flash Deals is curated: an admin must have flagged the product.
			// Checked first because it is both the cheapest test and the most
			// selective, so most on-sale products never reach hydration.
			if ( ! Flash_Deals_Validator::is_flagged( $pid ) ) {
				continue;
			}

			// Cheap author check before hydrating the product object.
			if ( $vendor_id > 0 && (int) get_post_field( 'post_author', $pid ) !== $vendor_id ) {
				continue;
			}

			$product = wc_get_product( $pid );
			if ( ! $product instanceof \WC_Product || ! $product->is_visible() ) {
				continue;
			}
			if ( ! $show_oos && ! $product->is_in_stock() ) {
				continue;
			}

			// Enforce the flash-card data contract. Every card in this grid
			// renders a stock bar and a countdown, so a product missing the
			// data behind them would break the row's visual consistency.
			// The admin products list reports exactly why anything is excluded.
			if ( ! Flash_Deals_Validator::is_eligible( $product ) ) {
				continue;
			}

			$window = self::resolve_sale_window( $product, $now );
			if ( null === $window ) {
				continue;
			}
			if ( $min_discount > 0 && $window['discount'] < $min_discount ) {
				continue;
			}

			$candidates[] = array(
				'product'  => $product,
				'end_ts'   => $window['end_ts'],
				'discount' => $window['discount'],
			);
		}

		if ( empty( $candidates ) ) {
			return self::HIDE_WIDGET;
		}

		$candidates = $this->sort_candidates( $candidates, $settings );

		$products = array();
		foreach ( $candidates as $entry ) {
			$products[] = $entry['product'];
		}

		$products = $this->apply_shared_filters( $products, $settings );
		if ( empty( $products ) ) {
			return self::HIDE_WIDGET;
		}

		$products = array_slice( $products, 0, $this->get_limit( $settings ) );

		$this->clamp_cache_ttl( $products, $candidates, $now );

		return $products;
	}

	/**
	 * Sale end timestamp for a product resolved during this request.
	 *
	 * @since 2.9.0
	 *
	 * @param int $product_id Product id.
	 * @return int UNIX timestamp, or 0 when unknown.
	 */
	public static function get_end_ts( $product_id ) {
		$product_id = (int) $product_id;

		return isset( self::$end_map[ $product_id ] ) ? (int) self::$end_map[ $product_id ] : 0;
	}

	/**
	 * Resolve a product's qualifying sale end timestamp on demand.
	 *
	 * Exposed so consumers outside this source -- the countdown renderer, and
	 * any card template -- can resolve an end date using exactly the same
	 * rules, including the variation walk. Reading parent meta instead would
	 * silently drop every variable product.
	 *
	 * @since 2.9.0
	 *
	 * @param \WC_Product $product Product to inspect.
	 * @return int UNIX timestamp, or 0 when there is no future sale end.
	 */
	public static function end_ts_for( \WC_Product $product ) {
		$window = self::resolve_sale_window( $product, time() );

		return ( null === $window ) ? 0 : (int) $window['end_ts'];
	}

	/**
	 * Resolve the vendor scoping mode.
	 *
	 * @param array $settings Widget settings.
	 * @return string One of self::SCOPES.
	 */
	private function resolve_scope( array $settings ) {
		$raw = isset( $settings['flash_vendor_scope'] ) ? sanitize_key( (string) $settings['flash_vendor_scope'] ) : 'auto';
		return in_array( $raw, self::SCOPES, true ) ? $raw : 'auto';
	}

	/**
	 * Resolve the vendor id used for scoping.
	 *
	 * @param array $settings Widget settings.
	 * @return int Vendor user id, or 0 for site-wide.
	 */
	private function resolve_scope_vendor_id( array $settings ) {
		$vendor_id = 0;

		// AJAX (load more / infinite scroll) has no page context at all, so the
		// handler injects the vendor id resolved during the first render.
		if ( ! empty( $settings['_current_vendor_id'] ) ) {
			$vendor_id = (int) $settings['_current_vendor_id'];
		}

		if ( $vendor_id <= 0 ) {
			$vendor_id = $this->detect_current_vendor_id();
		}

		/**
		 * Filter the vendor id used to scope the Flash Deals source.
		 *
		 * Return 0 to force site-wide behaviour.
		 *
		 * @since 2.8.0
		 *
		 * @param int   $vendor_id Resolved vendor user id, 0 when site-wide.
		 * @param array $settings  Widget settings.
		 */
		$vendor_id = (int) apply_filters( 'zymarg_wcpg_flash_deals_vendor_id', $vendor_id, $settings );

		return max( 0, $vendor_id );
	}

	/**
	 * Resolve the effective sale window for a product.
	 *
	 * Variable products delegate to their variations, since sale dates live
	 * on the variation. The soonest-ending qualifying variation wins.
	 *
	 * @param \WC_Product $product Product to inspect.
	 * @param int         $now     Current UNIX timestamp.
	 * @return array{end_ts:int,discount:float}|null Null when not a flash deal.
	 */
	private static function resolve_sale_window( \WC_Product $product, $now ) {
		$windows = array();

		if ( $product->is_type( 'variable' ) ) {
			foreach ( $product->get_children() as $child_id ) {
				$variation = wc_get_product( (int) $child_id );
				if ( ! $variation instanceof \WC_Product ) {
					continue;
				}
				$window = self::extract_window( $variation, $now );
				if ( null !== $window ) {
					$windows[] = $window;
				}
			}
		} else {
			$window = self::extract_window( $product, $now );
			if ( null !== $window ) {
				$windows[] = $window;
			}
		}

		if ( empty( $windows ) ) {
			return null;
		}

		usort(
			$windows,
			static function ( $a, $b ) {
				return $a['end_ts'] <=> $b['end_ts'];
			}
		);

		return $windows[0];
	}

	/**
	 * Extract a qualifying sale window from a single product or variation.
	 *
	 * @param \WC_Product $product Product or variation.
	 * @param int         $now     Current UNIX timestamp.
	 * @return array{end_ts:int,discount:float}|null
	 */
	private static function extract_window( \WC_Product $product, $now ) {
		if ( ! $product->is_on_sale() ) {
			return null;
		}

		$end = $product->get_date_on_sale_to();
		if ( ! $end || ! method_exists( $end, 'getTimestamp' ) ) {
			// No end date means a permanent discount, not a flash deal.
			return null;
		}

		$end_ts = (int) $end->getTimestamp();
		if ( $end_ts <= $now ) {
			return null;
		}

		$regular  = (float) $product->get_regular_price();
		$active   = (float) $product->get_price();
		$discount = ( $regular > 0 && $active < $regular ) ? ( ( $regular - $active ) / $regular ) * 100 : 0.0;

		return array(
			'end_ts'   => $end_ts,
			'discount' => $discount,
		);
	}

	/**
	 * Sort candidates according to the source's own ordering setting.
	 *
	 * This source intentionally reads `flash_orderby` rather than the global
	 * `orderby`, because the global control defaults to "date" and would
	 * otherwise silently defeat the ending-soonest default.
	 *
	 * @param array $candidates Candidate rows.
	 * @param array $settings   Widget settings.
	 * @return array
	 */
	private function sort_candidates( array $candidates, array $settings ) {
		$orderby = isset( $settings['flash_orderby'] ) ? sanitize_key( (string) $settings['flash_orderby'] ) : '';
		if ( ! in_array( $orderby, self::ORDERBY, true ) ) {
			// Allow an explicit global orderby of sale_end / discount through.
			$global  = isset( $settings['orderby'] ) ? sanitize_key( (string) $settings['orderby'] ) : '';
			$orderby = in_array( $global, array( 'sale_end', 'discount' ), true ) ? $global : 'sale_end';
		}

		$descending = ! ( isset( $settings['order'] ) && 'ASC' === strtoupper( (string) $settings['order'] ) );

		if ( 'rand' === $orderby ) {
			shuffle( $candidates );
			return $candidates;
		}

		if ( 'sale_end' === $orderby ) {
			// Ending soonest first. The natural order for a flash deal, and the
			// one ordering where DESC is not a sensible default, so `order` is
			// deliberately ignored here.
			usort(
				$candidates,
				static function ( $a, $b ) {
					return $a['end_ts'] <=> $b['end_ts'];
				}
			);
			return $candidates;
		}

		$value = static function ( array $entry ) use ( $orderby ) {
			$product = $entry['product'];
			switch ( $orderby ) {
				case 'discount':
					return (float) $entry['discount'];
				case 'price':
					return (float) $product->get_price();
				case 'popularity':
					return (float) $product->get_total_sales();
				case 'rating':
					return (float) $product->get_average_rating();
				case 'title':
					return (string) $product->get_name();
				case 'date':
				default:
					$created = $product->get_date_created();
					return ( $created && method_exists( $created, 'getTimestamp' ) ) ? (int) $created->getTimestamp() : 0;
			}
		};

		usort(
			$candidates,
			static function ( $a, $b ) use ( $value, $orderby ) {
				$va = $value( $a );
				$vb = $value( $b );
				return ( 'title' === $orderby ) ? strcasecmp( (string) $va, (string) $vb ) : ( $va <=> $vb );
			}
		);

		return $descending ? array_reverse( $candidates ) : $candidates;
	}

	/**
	 * Clamp the render cache TTL so a finished flash deal cannot outlive its
	 * own sale window in the page cache.
	 *
	 * @param \WC_Product[] $products   Products actually returned.
	 * @param array         $candidates Candidate rows carrying end timestamps.
	 * @param int           $now        Current UNIX timestamp.
	 * @return void
	 */
	private function clamp_cache_ttl( array $products, array $candidates, $now ) {
		$returned = array();
		foreach ( $products as $product ) {
			if ( $product instanceof \WC_Product ) {
				$returned[ (int) $product->get_id() ] = true;
			}
		}

		$soonest = 0;
		foreach ( $candidates as $entry ) {
			$pid = (int) $entry['product']->get_id();
			if ( ! isset( $returned[ $pid ] ) ) {
				continue;
			}

			// Publish for the countdown renderer (v2.9.0).
			self::$end_map[ $pid ] = (int) $entry['end_ts'];
			if ( 0 === $soonest || (int) $entry['end_ts'] < $soonest ) {
				$soonest = (int) $entry['end_ts'];
			}
		}

		if ( $soonest <= $now ) {
			return;
		}

		self::$soonest_end_ts = ( self::$soonest_end_ts > 0 ) ? min( self::$soonest_end_ts, $soonest ) : $soonest;

		if ( self::$ttl_filter_added ) {
			return;
		}
		self::$ttl_filter_added = true;

		add_filter(
			'zymarg_cache_ttl',
			static function ( $ttl ) {
				$remaining = self::$soonest_end_ts - time();
				if ( $remaining <= 0 ) {
					return 0;
				}
				return max( 1, min( (int) $ttl, $remaining ) );
			}
		);
	}
}
