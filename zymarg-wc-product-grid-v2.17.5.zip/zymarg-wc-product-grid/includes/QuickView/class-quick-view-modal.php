<?php
/**
 * Quick View modal mounting.
 *
 * Renders an empty modal shell into the page footer when at least one
 * widget on the page enables Quick View. Content is injected client-side
 * after the AJAX response.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\QuickView;

defined( 'ABSPATH' ) || exit;

/**
 * Class QuickView_Modal
 */
class QuickView_Modal {

	/**
	 * Whether we have already mounted (one shell per page).
	 *
	 * @var bool
	 */
	private static $mounted = false;

	/**
	 * Hook the footer renderer.
	 */
	public function register() {
		add_action( 'wp_footer', array( $this, 'maybe_render_shell' ), 50 );
	}

	/**
	 * Mark mount as required (called from widgets that include Quick View).
	 */
	public static function flag_mount() {
		add_filter( 'zymarg_wcpg_mount_quickview', '__return_true' );
	}

	/**
	 * Render the modal shell once per page.
	 */
	public function maybe_render_shell() {
		if ( self::$mounted ) {
			return;
		}
		if ( ! apply_filters( 'zymarg_wcpg_mount_quickview', false ) ) {
			return;
		}
		self::$mounted = true;
		?>
<div class="zymarg-wcpg__qv-overlay"
	role="dialog"
	aria-modal="true"
	aria-labelledby="zymarg-wcpg-qv-title"
	aria-hidden="true"
	hidden>
	<div class="zymarg-wcpg__qv">
		<button type="button"
			class="zymarg-wcpg__qv-close"
			aria-label="<?php esc_attr_e( 'Close', 'zymarg-wcpg' ); ?>">&times;</button>
		<div class="zymarg-wcpg__qv-body" aria-busy="true">
			<div class="zymarg-wcpg__qv-spinner" aria-hidden="true"></div>
			<div class="zymarg-wcpg__qv-content"></div>
		</div>
	</div>
</div>
		<?php
	}
}
