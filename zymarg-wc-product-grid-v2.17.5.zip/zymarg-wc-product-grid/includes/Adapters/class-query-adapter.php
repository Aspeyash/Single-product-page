<?php
/**
 * Query Adapter — translates a canonical query array and resolved context
 * into the legacy settings array expected by Query_Builder::get_products().
 *
 * This class is the bridge between the new rendering framework and the
 * existing, proven Query Engine. It is the only class in the codebase that
 * knows the legacy settings key names. Nothing else should.
 *
 * Responsibilities (and only these):
 *   - Map canonical query keys to legacy Query_Builder settings keys.
 *   - Merge relevant context values into the settings array.
 *   - Expose a filter before returning so external plugins can adjust settings
 *     without replacing this class.
 *
 * This class must not:
 *   - Execute queries.
 *   - Validate or transform products.
 *   - Render anything.
 *   - Load templates.
 *   - Know about Elementor.
 *   - Invent values not present in the canonical query or context.
 *
 * Canonical → legacy key mapping:
 *   limit     → total_products
 *   sort      → orderby
 *   direction → order
 *   show_oos  → show_oos   (same key, kept for clarity)
 *   source    → source     (same key, kept for clarity)
 *
 * All other canonical query keys are passed through unchanged if they have
 * no mapping entry — Query_Builder ignores unknown keys safely.
 *
 * @package Zymarg\WCPG\Adapters
 * @since   1.6.0
 */

namespace Zymarg\WCPG\Adapters;

defined( 'ABSPATH' ) || exit;

/**
 * Class Query_Adapter
 *
 * Stateless — no constructor, no properties.
 */
final class Query_Adapter {

	/**
	 * Canonical query key → legacy Query_Builder settings key.
	 *
	 * Only keys that differ between the two formats are listed.
	 * Keys that are identical in both formats are passed through automatically.
	 *
	 * @var array<string, string>
	 */
	private const KEY_MAP = [
		'limit'     => 'total_products',
		'sort'      => 'orderby',
		'direction' => 'order',
	];

	/**
	 * Context keys that Query_Builder sources read directly from $settings.
	 *
	 * These are merged from the resolved context into the settings array.
	 * Only context keys that at least one Source_* class actually reads are
	 * listed — we don't flood settings with unused values.
	 *
	 * @var array<string>
	 */
	private const CONTEXT_KEYS = [
		'product_id',
		'vendor_id',
		'category_id',
		'tag_id',
		'search',
		'current_user_id',
	];

	/**
	 * Translate a canonical query + resolved context into a Query_Builder
	 * settings array.
	 *
	 * Only keys present in $query or in $context (for CONTEXT_KEYS) are
	 * included in the output. The adapter never invents values.
	 *
	 * Example:
	 *
	 *   $query   = [ 'source' => 'similar', 'limit' => 8 ];
	 *   $context = [ 'product_id' => 123, 'vendor_id' => 45, ... ];
	 *
	 *   Result:
	 *   [
	 *     'source'         => 'similar',
	 *     'total_products' => 8,
	 *     'product_id'     => 123,
	 *     'vendor_id'      => 45,
	 *   ]
	 *
	 * @param array $query   Canonical query array (from template or caller).
	 * @param array $context Fully resolved context from Context_Resolver.
	 * @return array Settings array ready for Query_Builder::get_products().
	 */
	public static function to_settings( array $query, array $context = [] ): array {
		$settings = [];

		// 1. Translate canonical query keys → legacy settings keys.
		foreach ( $query as $canonical_key => $value ) {
			$legacy_key              = self::KEY_MAP[ $canonical_key ] ?? $canonical_key;
			$settings[ $legacy_key ] = $value;
		}

		// 2. Merge relevant context keys into settings.
		//    Context values do not overwrite query values — the query is more
		//    specific than the context.
		foreach ( self::CONTEXT_KEYS as $ctx_key ) {
			if ( ! isset( $settings[ $ctx_key ] ) && isset( $context[ $ctx_key ] ) ) {
				$settings[ $ctx_key ] = $context[ $ctx_key ];
			}
		}

		/**
		 * Filter the translated settings array before it is passed to
		 * Query_Builder::get_products().
		 *
		 * Use this to adjust settings for specific sources or conditions
		 * without replacing the adapter.
		 *
		 * Example — force show_oos for wishlist queries:
		 *   add_filter( 'zymarg_product_grid_query_settings', function( $settings, $query, $context ) {
		 *       if ( isset( $settings['source'] ) && 'wishlist' === $settings['source'] ) {
		 *           $settings['show_oos'] = true;
		 *       }
		 *       return $settings;
		 *   }, 10, 3 );
		 *
		 * @since 1.6.0
		 * @param array $settings Translated settings array.
		 * @param array $query    Original canonical query array.
		 * @param array $context  Resolved context array.
		 */
		return (array) apply_filters(
			'zymarg_product_grid_query_settings',
			$settings,
			$query,
			$context
		);
	}

	/**
	 * No public construction — stateless class.
	 */
	private function __construct() {}
}
