<?php
/**
 * Asset Manager.
 *
 * Decides which frontend assets are required for a given render and enqueues
 * them. This is the only class in the plugin that answers the question
 * "what assets does this render need?" — no other class makes that decision.
 *
 * Responsibilities (and only these):
 *   - Read a normalized config and enqueue the assets it requires.
 *   - Detect the search page and enqueue core assets early (FOUC prevention).
 *   - Flag the QuickView modal shell for output in wp_footer.
 *
 * This class must not:
 *   - Register asset handles (that is Assets::register_frontend()'s job).
 *   - Know about consumers (Related Products, Category, Store, Search).
 *   - Know about products, queries, slots, templates, or vendors.
 *   - Store state, cache config, or track what has been enqueued
 *     (WordPress handles idempotency via wp_enqueue_style/script).
 *   - Echo output or return HTML.
 *
 * Design notes:
 *   - Fully stateless. No properties, no singleton, no stored config.
 *   - Every method is static so callers need no instance.
 *   - wp_enqueue_style() and wp_enqueue_script() are idempotent; calling
 *     them multiple times per page (e.g. two shortcodes + a page consumer)
 *     has no negative effect. No custom deduplication is needed here.
 *   - Elementor widget pages are NOT handled here. Elementor calls
 *     get_style_depends() / get_script_depends() automatically before
 *     render() fires, which is Elementor's own dependency resolution
 *     pipeline. Asset_Manager::enqueue_for_render() is additive — safe
 *     to run alongside Elementor but not a replacement for it.
 *
 * @package Zymarg\WCPG\Services
 * @since   1.7.0
 */

namespace Zymarg\WCPG\Services;

use Zymarg\WCPG\Assets;
use Zymarg\WCPG\QuickView\QuickView_Modal;
use Zymarg\WCPG\Templates\Template_Manager;

defined( 'ABSPATH' ) || exit;

/**
 * Class Asset_Manager
 */
final class Asset_Manager {

	// -------------------------------------------------------------------------
	// Public API
	// -------------------------------------------------------------------------

	/**
	 * Enqueue all frontend assets required for a product grid render.
	 *
	 * Called by Render_Engine::render() at the start of every render
	 * invocation, regardless of which consumer triggered it. This ensures
	 * assets load on page-consumer renders (Related Products, Category,
	 * Store, Search) where no Elementor widget lifecycle is present.
	 *
	 * @param array $config Complete normalized config from Config_Normalizer.
	 * @return void
	 */
	public static function enqueue_for_render( array $config ): void {
		self::enqueue_core();
		self::maybe_enqueue_slider( $config );
		self::maybe_enqueue_quickview( $config );
		self::maybe_enqueue_card_template_assets( $config );
	}

	/**
	 * Enqueue core frontend assets for the search results page.
	 *
	 * Hooked at wp_enqueue_scripts priority 15 (after registration at
	 * priority 5) so CSS lands in <head> before Algolia injects cards,
	 * preventing FOUC. Returns early on non-search pages so the hook
	 * registration in Plugin::init() can be unconditional.
	 *
	 * @return void
	 */
	public static function enqueue_for_search_page(): void {
		if ( ! self::is_search_page() ) {
			return;
		}

		self::enqueue_core();
	}

	// -------------------------------------------------------------------------
	// Private feature helpers
	// -------------------------------------------------------------------------

	/**
	 * Enqueue core assets required by every product grid render.
	 *
	 * "Core" means: any page that shows a product grid needs these.
	 * They are never conditional on config values.
	 *
	 * Also flags the QuickView modal shell for output in wp_footer.
	 * Without flag_mount() the modal overlay is never injected into the
	 * DOM and Quick View clicks silently fail on page-consumer renders.
	 *
	 * @return void
	 */
	private static function enqueue_core(): void {
		wp_enqueue_style( Assets::HANDLE_FRONTEND );
		wp_enqueue_style( Assets::HANDLE_QUICKVIEW );
		wp_enqueue_script( Assets::HANDLE_FRONTEND );
		wp_enqueue_script( Assets::HANDLE_QUICKVIEW );

		QuickView_Modal::flag_mount();
	}

	/**
	 * Enqueue a card template's own CSS and JS assets if they exist.
	 *
	 * Each card template folder may ship its own stylesheet and optional
	 * script alongside its PHP template file. When present, these are loaded
	 * automatically whenever that template is rendered — no manual handle
	 * registration is needed.
	 *
	 * File convention — assets sit alongside the template's PHP file:
	 *   {template_dir}/style.css   — always loaded when found
	 *   {template_dir}/script.js   — loaded when found (deps: frontend JS)
	 *
	 * For bundled templates that resolves to templates/cards/{slug}/style.css.
	 * For templates registered by a standalone plugin it resolves inside that
	 * plugin's own directory, which is what makes each template a genuinely
	 * self-contained package: PHP, CSS, and optional JS shipped together.
	 * A standalone plugin never needs to know about a template's CSS — it just
	 * calls Public_API::render() and the right assets load automatically.
	 *
	 * Fixed in v2.1.0: this method previously read the slug from the
	 * nonexistent $config['template'] key (the canonical location is
	 * $config['card']['template']), so it always resolved to 'classic'; and it
	 * only ever searched this plugin's own directory, so externally registered
	 * templates could never load their stylesheet.
	 *
	 * @param array $config Normalized config.
	 * @return void
	 */
	private static function maybe_enqueue_card_template_assets( array $config ): void {
		$slug = sanitize_key( $config['card']['template'] ?? 'classic' );

		if ( '' === $slug ) {
			return;
		}

		// Template_Manager owns file locations; we only enqueue what it reports.
		$assets = Template_Manager::get_card_assets( $slug );

		if ( ! empty( $assets['css'] ) ) {
			$handle = 'zymarg-wcpg-card-' . $slug;

			if ( ! wp_style_is( $handle, 'registered' ) ) {
				wp_register_style(
					$handle,
					$assets['css']['url'],
					[ Assets::HANDLE_FRONTEND ],
					$assets['css']['version']
				);
			}
			wp_enqueue_style( $handle );
		}

		if ( ! empty( $assets['js'] ) ) {
			$handle = 'zymarg-wcpg-card-' . $slug . '-js';

			if ( ! wp_script_is( $handle, 'registered' ) ) {
				wp_register_script(
					$handle,
					$assets['js']['url'],
					[ Assets::HANDLE_FRONTEND ],
					$assets['js']['version'],
					true
				);
			}
			wp_enqueue_script( $handle );
		}
	}

	/**
	 *
	 * The "maybe" prefix signals that this method contains its own
	 * condition check and is a no-op when the condition is not met.
	 *
	 * @param array $config Normalized config.
	 * @return void
	 */
	private static function maybe_enqueue_slider( array $config ): void {
		if ( ( $config['layout']['type'] ?? 'grid' ) !== 'slider' ) {
			return;
		}

		wp_enqueue_style( Assets::HANDLE_SLIDER );
		wp_enqueue_script( Assets::HANDLE_SLIDER );
	}

	/**
	 * Enqueue Quick View assets if Quick View is enabled on the card.
	 *
	 * The "maybe" prefix signals that this method contains its own
	 * condition check and is a no-op when the condition is not met.
	 *
	 * Note: quickview CSS/JS are also enqueued by enqueue_core() above.
	 * This method is reserved for any additional quickview-specific assets
	 * that may be introduced in future milestones (e.g. a lightbox bundle).
	 * For now it is a documented hook point; enqueue_core() covers the
	 * current quickview.css + quickview.js handles unconditionally because
	 * quickview markup may be present in any grid card.
	 *
	 * @param array $config Normalized config.
	 * @return void
	 */
	private static function maybe_enqueue_quickview( array $config ): void {
		// Quickview assets are currently covered by enqueue_core().
		// This method exists as the correct future home for conditional
		// quickview asset loading (e.g. a separate lightbox handle) once
		// dedicated quickview-only assets are introduced.
		// Nothing to do here until then.
		//
		// Example future usage:
		//   if ( ! ( $config['card']['show_quickview'] ?? true ) ) { return; }
		//   wp_enqueue_script( Assets::HANDLE_QUICKVIEW_LIGHTBOX );
	}

	// -------------------------------------------------------------------------
	// Private detection helpers
	// -------------------------------------------------------------------------

	/**
	 * Whether the current request is an Algolia / WP search page.
	 *
	 * Detects three URL patterns:
	 *   1. /search/query      — clean URL rewrite (primary ZYMARG format).
	 *   2. ?s=query           — standard WordPress search.
	 *   3. ?q=query           — legacy / alternate query string format.
	 *
	 * This logic was previously in Assets::is_search_page(). It lives here
	 * because the decision "should we early-enqueue for search?" is an
	 * asset-coordination concern, not an asset-registration concern.
	 *
	 * @return bool
	 */
	private static function is_search_page(): bool {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended

		// Pattern 1: clean URL /search/{term}.
		$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) $_SERVER['REQUEST_URI'] : '';
		if ( preg_match( '#^/search(/|$)#i', parse_url( $request_uri, PHP_URL_PATH ) ) ) {
			return true;
		}

		// Pattern 2: ?s= (standard WP search).
		if ( isset( $_GET['s'] ) && '' !== $_GET['s'] ) {
			return true;
		}

		// Pattern 3: ?q= (alternate).
		if ( isset( $_GET['q'] ) && '' !== $_GET['q'] ) {
			return true;
		}

		return false;

		// phpcs:enable
	}

	/**
	 * No public construction — static class only.
	 */
	private function __construct() {}
}
