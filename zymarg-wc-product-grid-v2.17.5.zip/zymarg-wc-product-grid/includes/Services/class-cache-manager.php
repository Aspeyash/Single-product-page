<?php
/**
 * Cache Manager.
 *
 * Provides a single caching layer for rendered product grid HTML. The entire
 * rendering pipeline (query + template) is expensive; this class lets
 * subsequent identical requests skip it entirely.
 *
 * Responsibilities (and only these):
 *   - Build a deterministic cache key from config + context.
 *   - Get, set, and delete cached HTML strings.
 *   - Decide whether a given request should be cached at all.
 *   - Register WooCommerce/WordPress hooks that invalidate stale cache.
 *
 * This class must not:
 *   - Execute product queries.
 *   - Render templates.
 *   - Build or normalize configuration.
 *   - Know about consumers, Elementor, or shortcodes.
 *   - Know about which product is being rendered (only the config + context).
 *
 * Cache backend:
 *   Uses WordPress Object Cache (wp_cache_*) as the primary backend — this
 *   takes advantage of Redis/Memcached when available. Falls back to
 *   transients (set_transient / get_transient) on sites without a persistent
 *   object cache. Callers never know which backend is active.
 *
 * Cache invalidation strategy — version bump:
 *   A single integer option (`zymarg_cache_version`) is stored in wp_options.
 *   Every cache key includes this version number. When any product is updated,
 *   the version is incremented — instantly invalidating all cached grids
 *   without needing to track which products appear in which grids.
 *   This is O(1) invalidation regardless of how many grids are cached.
 *
 * Design notes:
 *   - Fully stateless. No properties, no singleton.
 *   - All methods are static — callers need no instance.
 *   - Calling set() multiple times for the same key is safe (idempotent).
 *   - Cache is bypassed for administrators in preview mode, Elementor editor,
 *     Customizer, and when WP_DEBUG_DISPLAY is true.
 *
 * @package Zymarg\WCPG\Services
 * @since   2.0.0
 */

namespace Zymarg\WCPG\Services;

defined( 'ABSPATH' ) || exit;

/**
 * Class Cache_Manager
 */
final class Cache_Manager {

	/**
	 * WordPress object cache group for all plugin cache entries.
	 *
	 * @var string
	 */
	private const CACHE_GROUP = 'zymarg_wcpg';

	/**
	 * wp_options key that stores the current cache version integer.
	 *
	 * @var string
	 */
	private const VERSION_OPTION = 'zymarg_cache_version';

	/**
	 * Default cache lifetime in seconds (5 minutes).
	 *
	 * @var int
	 */
	private const DEFAULT_TTL = 300;

	// -------------------------------------------------------------------------
	// Public API
	// -------------------------------------------------------------------------

	/**
	 * Build a deterministic cache key for a render request.
	 *
	 * The key captures every value that affects rendered output:
	 * layout, template, query source, context identifiers, language,
	 * plugin version, and the current cache version. It excludes values
	 * that do not affect output (nonces, request IDs, timestamps, URLs).
	 *
	 * The result is a short MD5 hex string prefixed with the plugin slug
	 * so it is identifiable in cache inspection tools.
	 *
	 * @param array $config  Normalized render config.
	 * @param array $context Resolved context array.
	 * @return string Cache key string.
	 */
	public static function build_key( array $config, array $context ): string {
		// Both 'template' and 'total' read canonical config keys as of v2.1.0.
		// Previously they read $config['template'] and
		// $config['query']['total_products'], neither of which exists in a
		// normalized config — the canonical locations are
		// $config['card']['template'] and $config['query']['limit']. Both
		// silently fell back to their defaults, so two renders differing only
		// by card template, or only by limit, produced an identical cache key
		// and served each other's HTML for the lifetime of the entry.
		$parts = [
			'v'        => self::get_version(),
			'pv'       => ZYMARG_WCPG_VERSION,
			'lang'     => defined( 'ICL_LANGUAGE_CODE' ) ? ICL_LANGUAGE_CODE : get_locale(),
			'layout'   => $config['layout']['type']      ?? 'grid',
			'template' => $config['card']['template']    ?? 'classic',
			'source'   => $config['query']['source']     ?? 'all',
			'columns'  => $config['layout']['columns']   ?? 4,
			'total'    => $config['query']['limit']      ?? 8,
			'orderby'  => $config['query']['orderby']    ?? 'date',
			'order'    => $config['query']['order']      ?? 'DESC',
			// v2.11.0: full-config fingerprint.
			//
			// The named parts above cover layout type, card template, source,
			// columns, limit and ordering -- but NOT the 17 card show_* flags,
			// layout.gap, the slider sub-array, pagination mode/batches, the
			// responsive column overrides or the heading block. Two grids that
			// ran the same query but displayed it differently therefore hashed
			// to the SAME key and served each other's markup for the lifetime of
			// the entry. Hashing the config blocks wholesale means any key that
			// can change rendered output changes the cache key, including keys
			// added by future versions or injected by the
			// zymarg_product_grid_config filter (e.g. the Template Pack).
			'cfg'      => md5(
				(string) wp_json_encode(
					[
						$config['query']      ?? [],
						$config['layout']     ?? [],
						$config['card']       ?? [],
						$config['heading']    ?? [],
						$config['pagination'] ?? [],
						$config['responsive'] ?? [],
					]
				)
			),
			'ctx'      => self::extract_context_fingerprint( $context ),
		];

		/**
		 * Filter the components that make up the cache key.
		 *
		 * Use to add extra dimensions (e.g. membership level, currency,
		 * A/B test variant) that affect rendered output for your site.
		 * All values are serialized together before hashing.
		 *
		 * @since 2.0.0
		 * @param array $parts   Key component array.
		 * @param array $config  Normalized render config.
		 * @param array $context Resolved context.
		 */
		$parts = (array) apply_filters( 'zymarg_cache_key', $parts, $config, $context );

		return 'zymarg_' . md5( serialize( $parts ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.serialize_serialize
	}

	/**
	 * Retrieve cached HTML for a given key.
	 *
	 * Returns false when there is no valid cache entry.
	 *
	 * @param string $key Cache key from build_key().
	 * @return string|false Cached HTML string, or false on miss.
	 */
	public static function get( string $key ) {
		/**
		 * Fires immediately before a cache lookup.
		 *
		 * @since 2.0.0
		 * @param string $key Cache key.
		 */
		do_action( 'zymarg_before_cache_lookup', $key );

		$html = self::read( $key );

		if ( false !== $html ) {
			/**
			 * Fires on a cache hit.
			 *
			 * @since 2.0.0
			 * @param string $key  Cache key.
			 * @param string $html Cached HTML string.
			 */
			do_action( 'zymarg_cache_hit', $key, $html );

			return $html;
		}

		/**
		 * Fires on a cache miss.
		 *
		 * @since 2.0.0
		 * @param string $key Cache key.
		 */
		do_action( 'zymarg_cache_miss', $key );

		return false;
	}

	/**
	 * Store rendered HTML under the given key.
	 *
	 * @param string $key  Cache key from build_key().
	 * @param string $html Rendered HTML to store.
	 * @param int    $ttl  Time-to-live in seconds. 0 = use plugin default.
	 * @return void
	 */
	public static function set( string $key, string $html, int $ttl = 0 ): void {
		$ttl = $ttl > 0 ? $ttl : self::DEFAULT_TTL;

		/**
		 * Filter the cache TTL (time-to-live) in seconds.
		 *
		 * Return 0 to disable caching for this request.
		 *
		 * @since 2.0.0
		 * @param int    $ttl  TTL in seconds.
		 * @param string $key  Cache key.
		 * @param string $html HTML about to be stored.
		 */
		$ttl = (int) apply_filters( 'zymarg_cache_ttl', $ttl, $key, $html );

		if ( $ttl <= 0 ) {
			return;
		}

		/**
		 * Filter the HTML string immediately before it is stored in cache.
		 *
		 * @since 2.0.0
		 * @param string $html HTML string.
		 * @param string $key  Cache key.
		 */
		$html = (string) apply_filters( 'zymarg_cache_html', $html, $key );

		self::write( $key, $html, $ttl );

		/**
		 * Fires after HTML has been stored in the cache.
		 *
		 * @since 2.0.0
		 * @param string $key  Cache key.
		 * @param string $html HTML stored.
		 * @param int    $ttl  TTL used.
		 */
		do_action( 'zymarg_after_cache_store', $key, $html, $ttl );
	}

	/**
	 * Delete a specific cache entry.
	 *
	 * @param string $key Cache key to delete.
	 * @return void
	 */
	public static function delete( string $key ): void {
		if ( wp_using_ext_object_cache() ) {
			wp_cache_delete( $key, self::CACHE_GROUP );
		} else {
			delete_transient( $key );
		}
	}

	/**
	 * Bump the global cache version, effectively invalidating all cached grids.
	 *
	 * Called automatically by WooCommerce/WordPress hooks when products are
	 * updated. Can also be called manually to flush all plugin cache.
	 *
	 * @return void
	 */
	public static function invalidate_all(): void {
		$current = (int) get_option( self::VERSION_OPTION, 0 );
		update_option( self::VERSION_OPTION, $current + 1, false );
	}

	/**
	 * Whether the current request should use the cache.
	 *
	 * Returns false (bypass) for:
	 *   - Logged-in administrators in preview/editor context.
	 *   - Elementor editor iframe.
	 *   - WordPress Customizer preview.
	 *   - WP_DEBUG_DISPLAY enabled.
	 *   - Preview mode (is_preview()).
	 *   - When the zymarg_cache_enabled filter returns false.
	 *
	 * @param array $config  Normalized render config.
	 * @param array $context Resolved context.
	 * @return bool True if caching should be used, false to bypass.
	 */
	public static function should_cache( array $config, array $context ): bool {
		// Never cache in debug output mode.
		if ( defined( 'WP_DEBUG_DISPLAY' ) && WP_DEBUG_DISPLAY ) {
			return false;
		}

		// v2.11.0: never cache a render that will carry the debug overlay.
		//
		// Render_Engine appends the overlay when ZYMARG_DEBUG is on AND the
		// viewer can manage_options. That HTML was then written to the shared
		// cache under a key with no viewer dimension, so the next visitor --
		// logged out, on the same page -- was served the admin's diagnostic
		// panel, complete with cache status, consumer identity and template
		// internals. Debug renders now bypass the cache in both directions.
		if ( defined( 'ZYMARG_DEBUG' ) && ZYMARG_DEBUG && current_user_can( 'manage_options' ) ) {
			return false;
		}

		// Never cache in Customizer preview.
		if ( is_customize_preview() ) {
			return false;
		}

		// Never cache in WordPress preview.
		if ( is_preview() ) {
			return false;
		}

		// Never cache in Elementor editor.
		if ( isset( $_GET['elementor-preview'] ) || // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			 ( defined( '\Elementor\Plugin' ) && \Elementor\Plugin::$instance->editor->is_edit_mode() ) ) {
			return false;
		}

		// Never cache for admins viewing a render preview (is_preview flag).
		if ( ! empty( $context['is_preview'] ) && current_user_can( 'manage_options' ) ) {
			return false;
		}

		/**
		 * Filter whether caching is enabled for this render request.
		 *
		 * Return false to bypass the cache entirely for a specific config
		 * or context (e.g. logged-in users, specific pages, AJAX requests).
		 *
		 * @since 2.0.0
		 * @param bool  $enabled Whether to use cache. Default true.
		 * @param array $config  Normalized render config.
		 * @param array $context Resolved context.
		 */
		return (bool) apply_filters( 'zymarg_cache_enabled', true, $config, $context );
	}

	/**
	 * Register WooCommerce and WordPress hooks that trigger cache invalidation.
	 *
	 * Called once from Plugin::init(). Every hook here calls invalidate_all()
	 * which bumps the version number — instantly making all existing cache
	 * keys stale with zero per-product tracking.
	 *
	 * @return void
	 */
	public static function register_invalidation_hooks(): void {
		$hooks = [
			'save_post_product',
			'deleted_post',
			'woocommerce_product_set_stock',
			'woocommerce_product_set_stock_status',
			'woocommerce_update_product',
			'clean_post_cache',
			'switch_theme',
		];

		foreach ( $hooks as $hook ) {
			add_action( $hook, [ self::class, 'invalidate_all' ] );
		}
	}

	// -------------------------------------------------------------------------
	// Private backend helpers
	// -------------------------------------------------------------------------

	/**
	 * Read from the active cache backend.
	 *
	 * @param string $key Cache key.
	 * @return string|false Cached value or false.
	 */
	private static function read( string $key ) {
		if ( wp_using_ext_object_cache() ) {
			$value = wp_cache_get( $key, self::CACHE_GROUP );
			return false === $value ? false : (string) $value;
		}

		$value = get_transient( $key );
		return false === $value ? false : (string) $value;
	}

	/**
	 * Write to the active cache backend.
	 *
	 * @param string $key  Cache key.
	 * @param string $html HTML to store.
	 * @param int    $ttl  TTL in seconds.
	 * @return void
	 */
	private static function write( string $key, string $html, int $ttl ): void {
		if ( wp_using_ext_object_cache() ) {
			wp_cache_set( $key, $html, self::CACHE_GROUP, $ttl );
		} else {
			set_transient( $key, $html, $ttl );
		}
	}

	/**
	 * Get the current cache version integer.
	 *
	 * @return int
	 */
	private static function get_version(): int {
		static $version = null;

		if ( null === $version ) {
			$version = (int) get_option( self::VERSION_OPTION, 0 );
		}

		return $version;
	}

	/**
	 * Extract a short fingerprint string from the context array.
	 *
	 * Only values that affect rendered output are included.
	 *
	 * @param array $context Resolved context.
	 * @return string Fingerprint string.
	 */
	private static function extract_context_fingerprint( array $context ): string {
		$relevant = array_filter( [
			'product_id'  => $context['product_id']  ?? null,
			'term_id'     => $context['term_id']     ?? null,
			'vendor_id'   => $context['vendor_id']   ?? null,
			'page_type'   => $context['page_type']   ?? null,
			'is_search'   => $context['is_search']   ?? null,
		] );

		return empty( $relevant ) ? 'global' : implode( '|', $relevant );
	}

	/**
	 * No public construction — static class only.
	 */
	private function __construct() {}
}
