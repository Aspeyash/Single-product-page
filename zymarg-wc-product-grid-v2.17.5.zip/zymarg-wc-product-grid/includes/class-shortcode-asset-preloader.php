<?php
/**
 * Shortcode asset preloader — fixes the wishlist / recently-viewed FOUC.
 *
 * Background
 * ──────────
 * The Elementor Product Grid widget enqueues its CSS/JS during widget render,
 * which still hits wp_head in time. Shortcodes, however, render INSIDE
 * the_content() — i.e. AFTER wp_head has already been output. So even though
 * the shortcode's render() method calls wp_enqueue_style(), WordPress prints
 * the <link> tag in the footer, and the cards paint unstyled for a moment
 * before snapping into place. That's the "layout shift on first load" the
 * Wishlist page shows today.
 *
 * Fix
 * ───
 * Hook in at wp_enqueue_scripts (priority 5 — well before wp_head fires at
 * priority 10) and, ONLY if either the wishlist or recently-viewed shortcode
 * is going to render on this request, enqueue the frontend stylesheet
 * eagerly so it lands in <head>.
 *
 * Detection rules (any one is enough):
 *   1. The queried post's content contains [zymarg_wcpg_wishlist] or
 *      [zymarg_wcpg_recently_viewed].
 *   2. We're on a WooCommerce My Account page (this is where those
 *      shortcodes are most commonly placed, often via template parts that
 *      don't appear in $post->post_content).
 *
 * Safety
 * ──────
 *   - Adds enqueue calls ONLY when one of the above triggers fires. On every
 *     other page (homepage, single product, shop, etc.) this class does
 *     literally nothing — homepage / widget behaviour is unchanged.
 *   - Idempotent. WordPress merges duplicate enqueues.
 *   - No new scripts/styles. Reuses the already-registered Assets handles.
 *
 * @package Zymarg\WCPG
 * @since 1.5.2
 *
 * v2.10.2 -- extended to the main [zymarg_products] shortcode. Previously this
 * class only knew about the wishlist and recently-viewed shortcodes, so a page
 * using [zymarg_products] still had frontend.css, slider.css, Swiper's CSS and
 * the card template stylesheet printed in the footer: the grid painted fully
 * unstyled, and a slider painted as one full-width card, before snapping into
 * place. That is the same FOUC described above, on the plugin's primary
 * shortcode.
 */

namespace Zymarg\WCPG;

defined( 'ABSPATH' ) || exit;

class Shortcode_Asset_Preloader {

	/**
	 * Wire the early enqueue hook.
	 *
	 * @return void
	 */
	public function register() {
		// Priority 6 fires before wp_head() (priority 10) prints the page
		// head, so any enqueues here land in <head> and prevent FOUC. It is
		// 6 rather than 5 so that Assets::register_frontend() -- which runs
		// at 5 -- has definitely registered every handle we enqueue here,
		// instead of relying on class instantiation order to break the tie.
		add_action( 'wp_enqueue_scripts', array( $this, 'maybe_preload' ), 6 );
	}

	/**
	 * Decide if we need to enqueue early, and do so.
	 *
	 * @return void
	 */
	public function maybe_preload() {
		if ( is_admin() ) {
			return;
		}

		// Product grid shortcodes need more than the core stylesheet: the
		// slider CSS, Swiper's own CSS, and the card template's stylesheet all
		// have to be in <head> too. This runs independently of the wishlist /
		// recently-viewed triggers below.
		$this->preload_grid_shortcodes();

		if ( ! $this->should_preload() ) {
			return;
		}
		$this->enqueue_runtime();
	}

	/**
	 * Enqueue assets for every [zymarg_products] shortcode in the content.
	 *
	 * Delegates to Asset_Manager::enqueue_for_render(), the one class that
	 * decides what a render needs, rather than duplicating that decision. It
	 * is given a minimal config carrying only the two attributes that change
	 * which assets are required -- the layout type and the card template --
	 * which is enough for it to resolve the slider bundle, Swiper, and the
	 * card template's own stylesheet. Every enqueue is idempotent, so the
	 * real render enqueueing the same handles again later is a no-op.
	 *
	 * @return void
	 */
	protected function preload_grid_shortcodes() {
		foreach ( $this->grid_shortcode_configs() as $config ) {
			Services\Asset_Manager::enqueue_for_render( $config );
		}
	}

	/**
	 * Build a minimal asset-resolution config for each grid shortcode found.
	 *
	 * Only post_content is scanned. Shortcodes inside widgets, popups,
	 * reusable blocks, or template parts are invisible here -- for those the
	 * inline critical CSS in slider-wrapper.php keeps the layout correct, and
	 * the zymarg_wcpg_force_shortcode_asset_preload filter can force the full
	 * head enqueue.
	 *
	 * @return array List of partial configs.
	 */
	protected function grid_shortcode_configs() {
		$post = get_post();

		if ( ! $post instanceof \WP_Post || ! isset( $post->post_content ) ) {
			return array();
		}

		$content = (string) $post->post_content;
		$tag     = Shortcodes\Product_Grid_Shortcode::SHORTCODE;

		if ( ! has_shortcode( $content, $tag ) ) {
			return array();
		}

		$pattern = get_shortcode_regex( array( $tag ) );

		if ( ! preg_match_all( '/' . $pattern . '/', $content, $matches, PREG_SET_ORDER ) ) {
			return array();
		}

		$configs = array();

		foreach ( $matches as $match ) {
			$atts = shortcode_parse_atts( isset( $match[3] ) ? $match[3] : '' );

			if ( ! is_array( $atts ) ) {
				$atts = array();
			}

			$layout = isset( $atts['layout'] ) && 'slider' === strtolower( trim( (string) $atts['layout'] ) )
				? 'slider'
				: 'grid';

			$template = isset( $atts['card_template'] ) ? sanitize_key( $atts['card_template'] ) : '';

			$configs[] = array(
				'layout' => array( 'type' => $layout ),
				'card'   => array( 'template' => '' !== $template ? $template : 'classic' ),
			);
		}

		return $configs;
	}

	/**
	 * Should we eagerly enqueue assets for this request?
	 *
	 * @return bool
	 */
	protected function should_preload() {
		// Trigger 1: WooCommerce My Account context (wishlist and
		// recently-viewed are most commonly displayed there).
		if ( function_exists( 'is_account_page' ) && is_account_page() ) {
			return true;
		}

		// Trigger 2: shortcode found in the queried post's content.
		$post = get_post();
		if ( $post instanceof \WP_Post && isset( $post->post_content ) ) {
			$content = (string) $post->post_content;
			if (
				has_shortcode( $content, Shortcodes\Wishlist_Shortcode::SHORTCODE )
				|| has_shortcode( $content, Shortcodes\Recently_Viewed_Shortcode::SHORTCODE )
			) {
				return true;
			}
		}

		/**
		 * Let integrations force early enqueue (e.g. when these shortcodes
		 * are placed inside reusable blocks, popups, or template parts that
		 * don't appear in $post->post_content).
		 *
		 * @since 1.5.2
		 *
		 * @param bool $force Default false.
		 */
		return (bool) apply_filters( 'zymarg_wcpg_force_shortcode_asset_preload', false );
	}

	/**
	 * Enqueue the same handles the shortcodes use — registered earlier at
	 * wp_enqueue_scripts priority 5 in Assets::register_frontend(), so they're
	 * guaranteed to exist by the time this runs (priority 5 too, registered
	 * first by class instantiation order).
	 *
	 * @return void
	 */
	protected function enqueue_runtime() {
		// Styles first — these are the ones that fix the FOUC.
		if ( wp_style_is( Assets::HANDLE_FRONTEND, 'registered' ) ) {
			wp_enqueue_style( Assets::HANDLE_FRONTEND );
		}
		if ( wp_style_is( Assets::HANDLE_QUICKVIEW, 'registered' ) ) {
			wp_enqueue_style( Assets::HANDLE_QUICKVIEW );
		}
		// JS too, so wishlist heart toggles + quick view modal work without
		// extra enqueues inside the shortcode render path (defense in depth).
		if ( wp_script_is( Assets::HANDLE_FRONTEND, 'registered' ) ) {
			wp_enqueue_script( Assets::HANDLE_FRONTEND );
		}
		if ( wp_script_is( Assets::HANDLE_QUICKVIEW, 'registered' ) ) {
			wp_enqueue_script( Assets::HANDLE_QUICKVIEW );
		}
	}
}
