<?php
/**
 * API Bootstrap — orchestrates the ZYMARG Product Grid rendering framework.
 *
 * Responsibilities (and only these):
 *   1. Initialize registries in dependency order.
 *   2. Fire the `zymarg_wcpg_api_loaded` action so external plugins know
 *      the Public API is ready to receive calls.
 *
 * Registration logic lives in each registry, not here.
 * This class is intentionally thin; it is an orchestrator, not an owner.
 *
 * Usage (called once from Plugin::init()):
 *   Api_Bootstrap::init();
 *
 * @package Zymarg\WCPG\Bootstrap
 * @since   1.6.0
 */

namespace Zymarg\WCPG\Bootstrap;

use Zymarg\WCPG\Registry\Slot_Registry;
use Zymarg\WCPG\Registry\Template_Registry;

defined( 'ABSPATH' ) || exit;

/**
 * Class Api_Bootstrap
 */
final class Api_Bootstrap {

	/**
	 * Guards against double-initialisation.
	 *
	 * @var bool
	 */
	private static $initialized = false;

	/**
	 * Boot the rendering framework.
	 *
	 * Safe to call multiple times; subsequent calls are no-ops.
	 *
	 * Boot order:
	 *   1. Slot_Registry   — must be ready before Template_Registry consumers
	 *                        resolve slots.
	 *   2. Template_Registry — must be ready before any render call.
	 *   3. zymarg_wcpg_api_loaded — fires only after both registries are fully
	 *                        initialised so hooked callbacks can safely call
	 *                        Zymarg_Product_Grid::render() or register
	 *                        additional slots/templates immediately.
	 *
	 * @return void
	 */
	public static function init(): void {
		if ( self::$initialized ) {
			return;
		}

		self::$initialized = true;

		// 1. Registries — each owns its own defaults and filters.
		Slot_Registry::init();
		Template_Registry::init();

		/**
		 * Fires when the ZYMARG Product Grid rendering API is fully booted.
		 *
		 * External plugins should hook here before calling the Public API or
		 * registering additional slots / templates.
		 *
		 * Example:
		 *   add_action( 'zymarg_wcpg_api_loaded', function() {
		 *       Slot_Registry::register( 'my-slot', 'my-template' );
		 *   } );
		 *
		 * @since 1.6.0
		 */
		do_action( 'zymarg_wcpg_api_loaded' );
	}

	/**
	 * Whether the API has been initialised.
	 *
	 * Useful for defensive checks in the Public API facade.
	 *
	 * @return bool
	 */
	public static function is_initialized(): bool {
		return self::$initialized;
	}

	/**
	 * No public construction — static class only.
	 */
	private function __construct() {}
}
