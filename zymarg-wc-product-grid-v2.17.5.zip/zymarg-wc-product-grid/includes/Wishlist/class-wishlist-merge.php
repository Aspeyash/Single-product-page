<?php
/**
 * Login-time wishlist merge.
 *
 * On wp_login, take the guest cookie wishlist (if any), union it with the
 * user's stored wishlist, persist the result to user_meta, and clear the
 * guest cookie. Idempotent - re-running with no cookie is a no-op.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Wishlist;

defined( 'ABSPATH' ) || exit;

/**
 * Class Wishlist_Merge
 */
class Wishlist_Merge {

	/**
	 * Hook the merge.
	 */
	public function register() {
		add_action( 'wp_login', array( $this, 'merge_guest_into_user' ), 10, 2 );
	}

	/**
	 * Merge the guest cookie wishlist into the freshly-logged-in user's wishlist.
	 *
	 * @param string   $user_login Login name.
	 * @param \WP_User $user       Authenticated user.
	 */
	public function merge_guest_into_user( $user_login, $user ) {
		if ( ! ( $user instanceof \WP_User ) || ! $user->ID ) {
			return;
		}

		$guest_ids = $this->read_guest_cookie();
		if ( empty( $guest_ids ) ) {
			return;
		}

		$existing = get_user_meta( $user->ID, Wishlist_Store::USER_META_KEY, true );
		$existing = is_array( $existing ) ? array_map( 'intval', $existing ) : array();

		$merged = array_values( array_unique( array_filter( array_merge( $existing, $guest_ids ) ) ) );
		update_user_meta( $user->ID, Wishlist_Store::USER_META_KEY, $merged );

		$this->clear_guest_cookie();
	}

	/**
	 * Read the guest cookie value.
	 *
	 * @return int[]
	 */
	private function read_guest_cookie() {
		if ( empty( $_COOKIE[ Wishlist_Store::COOKIE_NAME ] ) ) {
			return array();
		}
		$decoded = json_decode( wp_unslash( $_COOKIE[ Wishlist_Store::COOKIE_NAME ] ), true );
		if ( ! is_array( $decoded ) ) {
			return array();
		}
		$ids = array_map( 'intval', $decoded );
		return array_values(
			array_unique(
				array_filter(
					$ids,
					static function ( $i ) {
						return $i > 0;
					}
				)
			)
		);
	}

	/**
	 * Expire the guest cookie.
	 */
	private function clear_guest_cookie() {
		if ( headers_sent() ) {
			return;
		}
		setcookie(
			Wishlist_Store::COOKIE_NAME,
			'',
			array(
				'expires'  => time() - HOUR_IN_SECONDS,
				'path'     => COOKIEPATH ? COOKIEPATH : '/',
				'domain'   => COOKIE_DOMAIN ? COOKIE_DOMAIN : '',
				'secure'   => is_ssl(),
				'httponly' => false,
				'samesite' => 'Lax',
			)
		);
		unset( $_COOKIE[ Wishlist_Store::COOKIE_NAME ] );
	}
}
