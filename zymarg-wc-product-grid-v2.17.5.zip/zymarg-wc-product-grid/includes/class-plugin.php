<?php
/**
 * Main plugin bootstrap class.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG;

defined( 'ABSPATH' ) || exit;

/**
 * Class Plugin
 *
 * Singleton that wires up all subsystems once dependencies are confirmed.
 */
final class Plugin {

	/**
	 * Singleton instance.
	 *
	 * @var Plugin|null
	 */
	private static $instance = null;

	/**
	 * Compatibility checker.
	 *
	 * @var Compatibility|null
	 */
	private $compatibility = null;

	/**
	 * Whether init() has already run.
	 *
	 * @var bool
	 */
	private $booted = false;

	/**
	 * Get the singleton instance.
	 *
	 * @return Plugin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * No public construction.
	 */
	private function __construct() {}

	/**
	 * Disallow cloning.
	 */
	public function __clone() {
		_doing_it_wrong( __FUNCTION__, 'Cloning is forbidden.', '0.1.0' );
	}

	/**
	 * Disallow unserialization.
	 */
	public function __wakeup() {
		_doing_it_wrong( __FUNCTION__, 'Unserialization is forbidden.', '0.1.0' );
	}

	/**
	 * Boot the plugin. Safe to call multiple times.
	 */
	public function init() {
		if ( $this->booted ) {
			return;
		}
		$this->booted = true;

		// Load translations as early as possible.
		( new I18n() )->register();

		// Compatibility must be evaluated before we wire up anything else.
		$this->compatibility = new Compatibility();
		$this->compatibility->register();

		if ( ! $this->compatibility->is_environment_ready() ) {
			// Hard requirements missing; admin notices will explain.
			return;
		}

		// Register asset handles (does not enqueue yet).
		( new Assets() )->register();

		// v2.9.0: Flash Deals countdown. Renders through the shared card action
		// hooks, so every registered card template picks it up with no template
		// edit -- including cards shipped by the Template Pack.
		( new Render\Countdown_Renderer() )->register();

		// Search page FOUC prevention — enqueue core assets early so CSS
		// lands in <head> before Algolia injects product cards.
		// Registered unconditionally; Asset_Manager::enqueue_for_search_page()
		// guards with its own is_search_page() check and returns early on
		// non-search pages. Priority 15 = after registration (priority 5),
		// before most theme enqueues.
		add_action( 'wp_enqueue_scripts', [ Services\Asset_Manager::class, 'enqueue_for_search_page' ], 15 );

		// Register WooCommerce/WordPress hooks that bust the render cache
		// when products are updated. Uses the version-bump strategy —
		// O(1) invalidation regardless of grid count.
		Services\Cache_Manager::register_invalidation_hooks();

		// Tracker and wishlist merge run on every page load (front-end only).
		( new Tracking\Recently_Viewed() )->register();
		( new Wishlist\Wishlist_Merge() )->register();

		// Register public shortcodes (e.g. [zymarg_wcpg_wishlist] for dropping
		// the visitor's wishlist into My Account or any other page, and
		// [zymarg_wcpg_recently_viewed] for the matching recently-viewed grid).
		( new Shortcodes\Wishlist_Shortcode() )->register();
		( new Shortcodes\Recently_Viewed_Shortcode() )->register();

		// [zymarg_products] — the first shortcode consumer to route through
		// Public_API::render(). Registered here (not inside Api_Bootstrap)
		// because shortcode registration is a WordPress concern, not an
		// engine concern. The actual render() call fires later on the front
		// end, by which point Api_Bootstrap::init() has already run.
		( new Shortcodes\Product_Grid_Shortcode() )->register();

		// Step 6 — Page consumers (Milestone 4).
		// Each consumer detects its page context and calls Public_API::render().
		// None of them know about Query_Builder, Render_Engine, or templates.
		// Registration order matches page priority — related last so it
		// doesn't interfere with the single-product summary above the fold.
		( new PageConsumers\Related_Products_Consumer() )->register();
		( new PageConsumers\Store_Products_Consumer() )->register();
		( new PageConsumers\Category_Products_Consumer() )->register();
		( new PageConsumers\Search_Results_Consumer() )->register();

		// FOUC fix (v1.5.2): when the wishlist or recently-viewed shortcode
		// will render on this request, enqueue the frontend CSS into <head>
		// so cards never paint unstyled. No-op everywhere else, so the
		// homepage / Elementor widget paths are unchanged.
		( new Shortcode_Asset_Preloader() )->register();

		// Trending subsystem: scheduled jobs.
		( new Trending\Trending_Scheduler() )->register();

		// Flash Deals: per-window sales counter feeding the flash card's
		// stock bar. Lifetime total_sales is the wrong number there.
		( new Trending\Flash_Sales_Counter() )->register();

		// Recommendations: per-visitor result-cache invalidation hooks
		// (wishlist / cart / order events).
		( new Recommendations\Affinity_Cache() )->register();

		// Vendor cache: invalidation hooks (Dokan-aware).
		( new Vendor\Vendor_Cache() )->register();

		// Admin-only AJAX endpoints used by the Elementor editor preview buttons.
		if ( is_admin() || wp_doing_ajax() ) {
			( new Admin\Editor_Ajax() )->register();
		}

		// User-facing AJAX router (wishlist, ATC, track-click, hydrate, load-more,
		// quick view, buy now).
		( new Ajax\Ajax_Router() )->register();

		// Quick View modal mount + Buy Now state machine.
		( new QuickView\QuickView_Modal() )->register();
		( new QuickView\BuyNow_Handler() )->register();

		// Register Elementor category + widget hooks.
		//
		// v2.7.0: guarded. The loader only attaches to Elementor's own action
		// hooks, so it is inert without Elementor, but instantiating it would
		// still autoload a class that references Elementor namespaces. Skipping
		// it entirely keeps the boot path clean once Elementor is removed.
		if ( $this->compatibility->is_elementor_active() ) {
			( new Elementor\ElementorLoader() )->register();
		}

		// Boot the standalone rendering framework (v1.6.0).
		// All core subsystems are initialized at this point, so the API
		// starts against a fully loaded plugin. External plugins that hook
		// into `zymarg_wcpg_loaded` below can immediately call
		// Zymarg_Product_Grid::render() or register custom slots/templates.
		Bootstrap\Api_Bootstrap::init();

		// Boot admin modules (v1.6.2).
		// Runs after the engine so diagnostics can safely call engine classes.
		// Admin::init() is internally guarded by is_admin() — no-op on frontend.
		Admin\Admin::init();

		/**
		 * Fires when the plugin has fully booted and the template registry is ready.
		 *
		 * Use this hook to register card templates from standalone template plugins:
		 *
		 *   add_action( 'zymarg_wcpg_init', function () {
		 *       Template_Manager::register_card( 'fashion', __DIR__ . '/templates/product-card.php' );
		 *   } );
		 *
		 * This fires before zymarg_wcpg_loaded — both hooks are safe for registration,
		 * but zymarg_wcpg_init is the preferred and documented hook for template packs.
		 *
		 * @since 2.0.7
		 */
		do_action( 'zymarg_wcpg_init' );

		/**
		 * Fires when the plugin has fully booted with all dependencies satisfied.
		 *
		 * @since 0.1.0
		 */
		do_action( 'zymarg_wcpg_loaded' );
	}

	/**
	 * Get the compatibility service.
	 *
	 * @return Compatibility|null
	 */
	public function compatibility() {
		return $this->compatibility;
	}
}
