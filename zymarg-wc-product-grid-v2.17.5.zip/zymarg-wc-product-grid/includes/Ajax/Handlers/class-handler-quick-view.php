<?php
/**
 * Quick View payload handler.
 *
 * Returns the rich product payload (gallery, attributes, variation
 * matrix, price html) plus rendered HTML for the modal content.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Ajax\Handlers;

defined( 'ABSPATH' ) || exit;

use Zymarg\WCPG\Ajax\Handler_Base;
use Zymarg\WCPG\QuickView\QuickView_Data;
use Zymarg\WCPG\Template_Loader;
use Zymarg\WCPG\Trending\Event_Buffer;

/**
 * Class Handler_QuickView
 */
class Handler_QuickView extends Handler_Base {

	/** @inheritDoc */
	public function action_key() {
		return 'quick_view';
	}

	/** @inheritDoc */
	protected function handle() {
		$product_id = $this->post_int( 'product_id' );
		$product    = wc_get_product( $product_id );
		if ( ! $product || ! $product->is_visible() ) {
			$this->send_error( __( 'Product not found.', 'zymarg-wcpg' ), 404 );
		}

		Event_Buffer::push( $product_id, 'quickview', self::ip_hash() );

		do_action( 'zymarg_wcpg_quick_view_opened', $product_id );

		$data = QuickView_Data::build( $product );
		$html = Template_Loader::get_template_html(
			'quickview/product-content.php',
			array(
				'product' => $product,
				'data'    => $data,
			)
		);

		$this->send_success(
			array(
				'product' => $data,
				'html'    => $html,
			)
		);
	}
}
