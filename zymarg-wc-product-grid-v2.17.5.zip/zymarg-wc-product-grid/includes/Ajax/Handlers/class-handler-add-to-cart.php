<?php
/**
 * AJAX add-to-cart handler.
 *
 * Phase 4: simple products only.
 * Phase 5: extended to accept variation_id + variation attributes
 *          (used by the Quick View modal).
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Ajax\Handlers;

defined( 'ABSPATH' ) || exit;

use Zymarg\WCPG\Ajax\Handler_Base;
use Zymarg\WCPG\Trending\Event_Buffer;

/**
 * Class Handler_Add_To_Cart
 */
class Handler_Add_To_Cart extends Handler_Base {

	/** @inheritDoc */
	public function action_key() {
		return 'add_to_cart';
	}

	/** @inheritDoc */
	protected function handle() {
		$product_id   = $this->post_int( 'product_id' );
		$variation_id = $this->post_int( 'variation_id' );
		$quantity     = max( 1, $this->post_int( 'quantity' ) );
		$variation    = isset( $_POST['variation'] ) && is_array( $_POST['variation'] ) // phpcs:ignore WordPress.Security.NonceVerification.Missing
			? array_map( 'sanitize_text_field', wp_unslash( $_POST['variation'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Missing
			: array();

		// v1.5.8: Per-user session mutex to prevent the concurrent-write race.
		// Without this, back-to-back Add to Cart clicks on different products
		// can both read the cart, modify their own in-memory copies, and save
		// back — with the LAST save overwriting the earlier one. Result:
		// customer sees only the 2nd product in cart, not both.
		//
		// The lock is scoped per-user (or per-session for guests) so it
		// doesn't affect other customers. Poll interval 100ms, max wait 3s.
		// v2.11.0: the lock is now acquired atomically.
		//
		// get_transient() followed by set_transient() is a check-then-act race:
		// two concurrent requests could both read "no lock" before either wrote
		// one, and both would proceed -- exactly the cart overwrite the mutex
		// exists to prevent. add_option() inserts against a UNIQUE index on
		// option_name, so precisely one caller can win.
		$lock_key = self::mutex_key();
		$acquired = false;
		for ( $i = 0; $i < 30; $i++ ) {
			if ( add_option( $lock_key, (string) time(), '', 'no' ) ) {
				$acquired = true;
				break;
			}

			// Reclaim a lock orphaned by a request that died before shutdown.
			$held = (int) get_option( $lock_key, 0 );
			if ( $held > 0 && ( time() - $held ) > 10 ) {
				delete_option( $lock_key );
				continue;
			}

			usleep( 100000 );
		}
		if ( ! $acquired ) {
			$this->send_error( __( 'Cart is busy, please try again.', 'zymarg-wcpg' ), 503 );
		}

		// Register a shutdown callback so the lock is ALWAYS released even
		// if a fatal error / uncaught exception aborts the request.
		register_shutdown_function( function () use ( $lock_key ) {
			delete_option( $lock_key );
		} );

		// WooCommerce does not load the cart/session automatically for
		// AJAX requests in WC 7.0+ (especially with HPOS enabled).
		// wc_load_cart() initialises WC()->cart, WC()->customer, and
		// WC()->session so add_to_cart() works correctly outside of a
		// standard page load. Safe to call multiple times - WC guards it.
		if ( function_exists( 'wc_load_cart' ) ) {
			wc_load_cart();
		}

		if ( ! function_exists( 'WC' ) || ! WC() || ! WC()->cart ) {
			$this->send_error( __( 'Cart is not available.', 'zymarg-wcpg' ), 503 );
		}

		$product = wc_get_product( $product_id );
		if ( ! $product || ! $product->is_visible() ) {
			$this->send_error( __( 'Product not found.', 'zymarg-wcpg' ), 404 );
		}

		// Variable product: require a variation_id + attributes (from Quick View).
		if ( $product->is_type( 'variable' ) ) {
			if ( $variation_id <= 0 ) {
				$this->send_error( __( 'Please select all options.', 'zymarg-wcpg' ), 400 );
			}
			$variation_product = wc_get_product( $variation_id );
			if ( ! $variation_product || ! $variation_product->is_purchasable() || ! $variation_product->is_in_stock() ) {
				$this->send_error( __( 'Variation is not available.', 'zymarg-wcpg' ), 400 );
			}
		} else {
			if ( ! $product->is_type( 'simple' ) ) {
				$this->send_error( __( 'Please choose options on the product page.', 'zymarg-wcpg' ), 400 );
			}
			if ( ! $product->is_purchasable() ) {
				$this->send_error( __( 'This product cannot be purchased.', 'zymarg-wcpg' ), 400 );
			}
			if ( ! $product->is_in_stock() ) {
				$this->send_error( __( 'Out of stock.', 'zymarg-wcpg' ), 400 );
			}
		}

		$key = WC()->cart->add_to_cart( $product_id, $quantity, $variation_id, $variation );
		if ( ! $key ) {
			$this->send_error( __( 'Could not add to cart.', 'zymarg-wcpg' ), 400 );
		}

		Event_Buffer::push( $product_id, 'cart_add', self::ip_hash() );

		do_action( 'zymarg_wcpg_added_to_cart', $product_id, $quantity );

		ob_start();
		woocommerce_mini_cart();
		$mini_cart = ob_get_clean();

		$fragments = apply_filters(
			'woocommerce_add_to_cart_fragments',
			array(
				'div.widget_shopping_cart_content' => '<div class="widget_shopping_cart_content">' . $mini_cart . '</div>',
			)
		);

		// v1.5.8: Release the mutex before sending response so the next
		// queued ATC request can proceed immediately (shutdown handler is
		// the safety net, this is the fast path).
		delete_transient( $lock_key );

		$this->send_success(
			array(
				'product_id' => $product_id,
				'cart_count' => WC()->cart->get_cart_contents_count(),
				'cart_total' => wp_kses_post( WC()->cart->get_cart_total() ),
				'cart_hash'  => WC()->cart->get_cart_hash(),
				'fragments'  => $fragments,
				'message'    => __( 'Added to cart', 'zymarg-wcpg' ),
			)
		);
	}

	/**
	 * Build the per-user (or per-session for guests) transient key used
	 * as an Add to Cart mutex.
	 *
	 * Serializing per-user (not globally) means the mutex has zero effect
	 * on other customers — only the same customer's own back-to-back ATC
	 * clicks are queued.
	 *
	 * @since 1.5.8
	 * @return string
	 */
	private static function mutex_key() {
		$user_id = get_current_user_id();
		if ( $user_id > 0 ) {
			return 'zymarg_wcpg_atc_u' . $user_id;
		}
		// Guest: use the WC customer id (which is a session token, stable
		// across guest requests in the same browser). Fall back to IP hash
		// on the rare occasion WC's session isn't wired up yet.
		if ( function_exists( 'WC' ) && WC() && WC()->session ) {
			$cid = WC()->session->get_customer_id();
			if ( ! empty( $cid ) ) {
				return 'zymarg_wcpg_atc_g' . substr( md5( (string) $cid ), 0, 16 );
			}
		}
		return 'zymarg_wcpg_atc_ip' . substr( self::ip_hash(), 0, 16 );
	}
}
