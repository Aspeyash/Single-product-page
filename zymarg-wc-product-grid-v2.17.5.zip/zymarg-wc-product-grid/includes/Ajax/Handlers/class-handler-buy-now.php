<?php
/**
 * Buy Now AJAX handler.
 *
 * Snapshots the cart, replaces with the chosen product, returns a
 * checkout redirect URL with a 15-min token.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Ajax\Handlers;

defined( 'ABSPATH' ) || exit;

use Zymarg\WCPG\Ajax\Handler_Base;
use Zymarg\WCPG\QuickView\BuyNow_Handler;
use Zymarg\WCPG\Trending\Event_Buffer;

/**
 * Class Handler_Buy_Now
 */
class Handler_Buy_Now extends Handler_Base {

	/** @inheritDoc */
	public function action_key() {
		return 'buy_now';
	}

	/** @inheritDoc */
	protected function handle() {
		$product_id      = $this->post_int( 'product_id' );
		$variation_id    = $this->post_int( 'variation_id' );
		$quantity        = max( 1, $this->post_int( 'quantity' ) );
		$variation_attrs = isset( $_POST['variation'] ) && is_array( $_POST['variation'] ) // phpcs:ignore WordPress.Security.NonceVerification.Missing
			? array_map( 'sanitize_text_field', wp_unslash( $_POST['variation'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Missing
			: array();

		// Ensure cart + session are loaded for AJAX context (WC 7.0+ HPOS).
		if ( function_exists( 'wc_load_cart' ) ) {
			wc_load_cart();
		}

		$buynow = new BuyNow_Handler();
		$result = $buynow->initiate( $product_id, $variation_id, $variation_attrs, $quantity );

		if ( is_wp_error( $result ) ) {
			$this->send_error( $result->get_error_message(), 400 );
		}

		Event_Buffer::push( $product_id, 'cart_add', self::ip_hash() );

		$this->send_success(
			array(
				'redirect' => esc_url_raw( $result['redirect'] ),
				'message'  => __( 'Redirecting to checkout...', 'zymarg-wcpg' ),
			)
		);
	}
}
