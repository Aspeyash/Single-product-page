<?php
/**
 * Load More pagination handler.
 *
 * Returns rendered card markup for the next page of a widget instance.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Ajax\Handlers;

defined( 'ABSPATH' ) || exit;

use Zymarg\WCPG\Ajax\Handler_Base;
use Zymarg\WCPG\Query\Query_Builder;
use Zymarg\WCPG\Query\Source_Base;
use Zymarg\WCPG\Template_Loader;
use Zymarg\WCPG\Templates\Template_Manager;

/**
 * Class Handler_Load_More
 */
class Handler_Load_More extends Handler_Base {

	/** @inheritDoc */
	public function action_key() {
		return 'load_more';
	}

	/** @inheritDoc */
	protected function handle() {
		$page     = max( 2, $this->post_int( 'page' ) );
		$settings = $this->read_settings();

		$raw_total = isset( $settings['total_products'] ) ? (int) $settings['total_products'] : 8;

		// Unlimited mode (0) renders everything in one shot, so there is
		// nothing left to paginate. Return an empty payload so the JS
		// removes the Load More button cleanly.
		if ( $raw_total <= 0 ) {
			$this->send_success(
				array(
					'html'     => '',
					'page'     => $page,
					'has_more' => false,
				)
			);
		}

		// v2.6.0: Infinite scroll sends an explicit offset and batch size.
		// Its batch can differ from the first-page size, and page-number math
		// ( ( page - 1 ) * per_page ) would then skip or duplicate products.
		// The batch is clamped so a tampered payload cannot request an
		// unbounded number of products in a single call.
		$batch    = $this->post_int( 'batch' );
		$per_page = $batch > 0 ? max( 1, min( 48, $batch ) ) : max( 1, $raw_total );

		$has_offset = isset( $_POST['offset'] ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$offset     = $has_offset
			? max( 0, $this->post_int( 'offset' ) )
			: ( $page - 1 ) * $per_page;

		// Keep _paged consistent with the offset for sources that paginate by
		// page number (Algolia) rather than by offset.
		if ( $has_offset ) {
			$page = (int) floor( $offset / $per_page ) + 1;
		}

		// Sources read total_products as the per-query limit, so it must
		// reflect the batch actually being requested.
		if ( $batch > 0 ) {
			$settings['total_products'] = $per_page;
		}

		$settings['_offset'] = $offset;
		$settings['_paged']  = $page;

		// For Algolia source: pass the search query explicitly so Source_Algolia
		// can resolve it without relying on get_search_query() (which returns
		// empty in an AJAX context). The query is read from the POST payload
		// that the load-more button emits via data-algolia-query.
		if ( 'algolia' === ( $settings['source'] ?? '' ) ) {
			$algolia_query = isset( $_POST['algolia_query'] ) // phpcs:ignore WordPress.Security.NonceVerification.Missing
				? sanitize_text_field( wp_unslash( $_POST['algolia_query'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Missing
				: '';
			$settings['_algolia_query'] = $algolia_query;
		}

		// For Category source: pass the term ID explicitly so Source_Category
		// can resolve it without relying on get_queried_object() (which returns
		// nothing in an AJAX context). The term ID is read from the POST
		// payload that the load-more button emits via data-category-term-id.
		if ( 'category' === ( $settings['source'] ?? '' ) ) {
			$category_term_id = isset( $_POST['category_term_id'] ) // phpcs:ignore WordPress.Security.NonceVerification.Missing
				? absint( wp_unslash( $_POST['category_term_id'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Missing
				: 0;
			$settings['_category_term_id'] = $category_term_id;
		}

		// v1.5.22: For Current Vendor source — pass the category term ID
		// injected by the ZYMARG Theme Builder Vendor Category Filter widget
		// so Source_Current_Vendor can filter by that category at AJAX time.
		// Uses the underscore-prefix convention (_category_term_id) to
		// distinguish runtime injection from saved Elementor settings.
		if ( 'current_vendor' === ( $settings['source'] ?? '' ) ) {
			$vcf_term_id = isset( $_POST['current_vendor_category_term_id'] ) // phpcs:ignore WordPress.Security.NonceVerification.Missing
				? absint( wp_unslash( $_POST['current_vendor_category_term_id'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Missing
				: 0;
			$settings['_category_term_id'] = $vcf_term_id;

			// v1.5.23: pass vendor ID explicitly so Source_Current_Vendor can
			// resolve the vendor in AJAX context where get_query_var('author')
			// and dokan_is_store_page() both return empty/false.
			$vcf_vendor_id = isset( $_POST['current_vendor_id'] ) // phpcs:ignore WordPress.Security.NonceVerification.Missing
				? absint( wp_unslash( $_POST['current_vendor_id'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Missing
				: 0;
			if ( $vcf_vendor_id > 0 ) {
				$settings['_current_vendor_id'] = $vcf_vendor_id;
			}
		}

		// Add a transient filter so any source built on Source_All / WP_Query
		// honours the offset.
		$offset_filter = static function ( $args ) use ( $settings ) {
			$args['offset'] = (int) $settings['_offset'];
			return $args;
		};
		add_filter( 'zymarg_wcpg_query_args', $offset_filter );

		$result = Query_Builder::get_products( $settings );

		remove_filter( 'zymarg_wcpg_query_args', $offset_filter );

		// HIDE_WIDGET sentinel from sources like Similar/Vendor.
		if ( Source_Base::HIDE_WIDGET === $result || empty( $result ) ) {
			$this->send_success(
				array(
					'html'     => '',
					'page'     => $page,
					'has_more' => false,
				)
			);
		}

		$widget_id = (string) $this->post( 'widget_id' );

		// v2.3.0: Re-render using the same card template the initial grid used
		// so Load More results match the first page instead of falling back to
		// the classic card. Unknown/empty slugs fall back to 'classic' inside
		// Template_Manager::render_card (also when the template pack is inactive).
		$card_template = isset( $settings['card_template'] )
			? sanitize_key( (string) $settings['card_template'] )
			: 'classic';

		// v2.11.0: restore the countdown's source context.
		//
		// Countdown_Renderer resolves show_countdown='auto' by comparing the
		// active query source against its auto-enable list, and it learns that
		// source from zymarg_product_grid_before_render -- an action only
		// Render_Engine fires. This handler renders cards directly, so in AJAX
		// the source stayed empty, 'auto' always resolved to off, and a Flash
		// Deals grid had countdowns on page one and none on every page after.
		if ( class_exists( '\\Zymarg\\WCPG\\Render\\Countdown_Renderer' ) ) {
			\Zymarg\WCPG\Render\Countdown_Renderer::capture_source(
				array( 'query' => array( 'source' => (string) ( $settings['source'] ?? '' ) ) )
			);
		}

		ob_start();
		foreach ( $result as $product ) {
			if ( ! ( $product instanceof \WC_Product ) ) {
				continue;
			}
			echo Template_Manager::render_card( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- trusted plugin HTML.
				$card_template,
				array(
					'product'   => $product,
					'settings'  => $settings,
					'config'    => [],
					'widget_id' => $widget_id,
				)
			);
		}
		$html = (string) ob_get_clean();

		$this->send_success(
			array(
				'html'     => $html,
				'page'     => $page,
				'has_more' => $this->resolve_has_more( $settings, $result, $per_page, $page ),
			)
		);
	}

	/**
	 * Determine whether more pages exist.
	 *
	 * For Algolia source, use nb_hits from the filter rather than comparing
	 * the count of returned products (which would always equal per_page until
	 * the last page, hiding whether there really is a next page).
	 *
	 * @param array  $settings Widget settings.
	 * @param array  $result   Products returned by the source.
	 * @param int    $per_page Products per page.
	 * @param int    $page     Current (1-based) page number.
	 * @return bool
	 */
	private function resolve_has_more( array $settings, array $result, $per_page, $page ) {
		if ( 'algolia' === ( $settings['source'] ?? '' ) ) {
			$nb_hits = (int) apply_filters( 'zymarg_wcpg_algolia_nb_hits', 0 );
			if ( $nb_hits > 0 ) {
				return ( $page * $per_page ) < $nb_hits;
			}
		}
		return count( $result ) >= $per_page;
	}

	/**
	 * Read whitelisted settings keys from POST.
	 *
	 * Only keys that affect query shape and card rendering are accepted.
	 *
	 * @return array
	 */
	private function read_settings() {
		$allowed = array(
			'source',
			'total_products',
			'orderby',
			'order',
			'show_oos',
			'columns',
			'show_image',
			'show_discount_badge',
			'show_stock_badge',
			'show_wishlist',
			'show_quickview',
			'show_atc',
			'show_title',
			'show_rating',
			'show_sold_count',
			'show_price',
			'discount_badge_mode',
			'image_full_resolution',
			'image_hover_zoom',
			'show_stock_in',
			'show_stock_out',
			'title_lines',
			'sold_count_format',
			'algolia_query',       // passed by load-more button for Algolia source.
			'category_term_id',    // passed by load-more button for Category source.
			'current_vendor_category_term_id', // v1.5.22: injected by Vendor Category Filter widget (Theme Builder).
			'current_vendor_id',               // v1.5.23: injected by VCF widget so AJAX context can resolve vendor.
			'current_vendor_subset',           // v1.5.23: preserved so AJAX query uses the same subset as initial render.
			'current_vendor_include_staff',    // v1.5.23: preserved for AJAX.
			'filter_group_id',     // v1.5.22: paired group ID for the Vendor Category Filter widget.
			'card_template',        // v2.3.0: card design slug so Load More re-renders the same template.
			'show_vendor',          // v2.3.0: ZYMARG card vendor row visibility preserved across Load More.
			'quickview_visibility', // v2.3.0: Quick View responsive visibility preserved across Load More.
			'quickview_display',    // v2.3.0: Quick View hover/always display preserved across Load More.
			// v2.11.0: keys the card templates read but Load More never sent, so
			// appended cards quietly fell back to built-in defaults and no longer
			// matched the first page.
			'show_countdown',
			'countdown_position',
			'show_status_badge',
			'meta_layout',
			'price_position',
			'vendor_position',
			'atc_position',
			'atc_transform',
			'atc_icon',
			'quickview_icon',
			'wishlist_icon',
			'wishlist_icon_active',
		);

		$settings = array();
		foreach ( $allowed as $key ) {
			if ( ! isset( $_POST[ $key ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
				continue;
			}
			$value            = wp_unslash( $_POST[ $key ] ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
			$settings[ $key ] = is_array( $value )
				? array_map( 'sanitize_text_field', $value )
				: sanitize_text_field( $value );
		}

		// Allow 0 (= unlimited) to pass through; positive values capped at 100.
		if ( isset( $settings['total_products'] ) ) {
			$tp = (int) $settings['total_products'];
			$settings['total_products'] = $tp <= 0 ? 0 : min( 100, max( 1, $tp ) );
		} else {
			$settings['total_products'] = 8;
		}

		return $settings;
	}
}
