<?php
/**
 * Click + quick-view tracking handler.
 *
 * Pushes events into the trending Event_Buffer. Honours an optional
 * sample-rate so very high-traffic stores can opt into 1-in-N tracking.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Ajax\Handlers;

defined( 'ABSPATH' ) || exit;

use Zymarg\WCPG\Ajax\Handler_Base;
use Zymarg\WCPG\Trending\Engagement_Store;
use Zymarg\WCPG\Trending\Event_Buffer;

/**
 * Class Handler_Track_Click
 */
class Handler_Track_Click extends Handler_Base {

	/** @inheritDoc */
	public function action_key() {
		return 'track_click';
	}

	/** @inheritDoc */
	protected function handle() {
		$product_id = $this->post_int( 'product_id' );
		$type       = $this->post( 'event' );
		$valid      = array_keys( Engagement_Store::event_weights() );

		if ( $product_id <= 0 || ! in_array( $type, $valid, true ) ) {
			$this->send_error( __( 'Invalid request.', 'zymarg-wcpg' ), 400 );
		}

		if ( ! wc_get_product( $product_id ) ) {
			$this->send_error( __( 'Product not found.', 'zymarg-wcpg' ), 404 );
		}

		// Sampling: deterministic per-IP-per-day, off by default.
		if ( ! self::passes_sampling( $type ) ) {
			$this->send_success( array( 'sampled' => true ) );
		}

		Event_Buffer::push( $product_id, $type, self::ip_hash() );

		$this->send_success(
			array(
				'sampled'    => false,
				'product_id' => $product_id,
				'event'      => $type,
			)
		);
	}

	/**
	 * Apply sampling: default 1 (no sampling).
	 *
	 * @param string $event_type Event type.
	 * @return bool True when the event should be recorded.
	 */
	private static function passes_sampling( $event_type ) {
		/**
		 * Sample 1-in-N for the given event type. Default 1 = no sampling.
		 *
		 * @param int    $rate       1 = no sampling.
		 * @param string $event_type Event type.
		 */
		$rate = (int) apply_filters( 'zymarg_wcpg_track_click_sample_rate', 1, $event_type );
		if ( $rate <= 1 ) {
			return true;
		}
		$bucket = hexdec( substr( self::ip_hash(), 0, 8 ) );
		return ( $bucket % $rate ) === 0;
	}
}
