<?php
/**
 * Per-IP rate limiter using WordPress transients.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Ajax;

defined( 'ABSPATH' ) || exit;

/**
 * Class Rate_Limiter
 */
class Rate_Limiter {

	const PREFIX = 'zymarg_rl_';

	/**
	 * Default per-action limits. Overridable via filter.
	 *
	 * v1.5.8 — rate limiting is now applied ONLY to actions that create
	 * expensive database writes or query cost, or that are common abuse
	 * targets (order creation, search DoS, analytics spam). Read-only or
	 * cart-only actions are NOT rate-limited so they don't hurt legitimate
	 * fast-browsing customers.
	 *
	 * Kept in v1.5.8:
	 *   • buy_now      — creates orders → real cost if abused
	 *   • search_cards — DB-heavy query, common bot magnet
	 *   • track_click  — analytics spam vector
	 *
	 * Removed in v1.5.8:
	 *   • add_to_cart  — WC handles concurrency (see mutex in Handler_Add_To_Cart)
	 *   • wishlist     — low-value target, moderate rate limits caused legit-user friction
	 *   • quick_view   — read-only, cheap
	 *   • hydrate      — read-only, cheap
	 *
	 * Re-added in v2.7.0:
	 *   • load_more    — still read-only, but infinite scroll (v2.6.0) fires
	 *     this action from a scroll observer instead of a deliberate button
	 *     click. A stuck sentinel, a runaway resize loop or a scripted scroll
	 *     can now issue product queries far faster than a human ever clicked.
	 *     The ceiling is set well above real usage: the largest configured
	 *     desktop run is a 100-product cap in 20-product batches, i.e. 5
	 *     auto-requests, so 120/minute cannot affect a legitimate shopper
	 *     while still capping a scraper walking the whole catalogue.
	 *
	 * Admins can add rate limits back for any action via the
	 * `zymarg_wcpg_rate_limits` filter.
	 *
	 * @return array<string,array{window:int,max:int}>
	 */
	public static function defaults() {
		return array(
			'buy_now'      => array(
				'window' => 60,
				'max'    => 10,
			),
			'search_cards' => array(
				'window' => 60,
				'max'    => 60,
			),
			'track_click'  => array(
				'window' => 60,
				'max'    => 120,
			),
			// v2.7.0: covers the Load More button AND infinite scroll, which
			// share this action key.
			'load_more'    => array(
				'window' => 60,
				'max'    => 120,
			),
		);
	}

	/**
	 * Resolve the (window, max) tuple for an action, or null if unlimited.
	 *
	 * v1.5.8: Returns null when the action has no configured limit so
	 * consume() can bypass the transient hit entirely. Previously this
	 * returned a default 30/min for any unlisted action.
	 *
	 * @param string $action Action key.
	 * @return array{window:int,max:int}|null
	 */
	public static function get_limit( $action ) {
		$defaults = self::defaults();
		$config   = apply_filters( 'zymarg_wcpg_rate_limits', $defaults, $action );
		if ( isset( $config[ $action ] ) && is_array( $config[ $action ] ) ) {
			return array_merge(
				array(
					'window' => 60,
					'max'    => 30,
				),
				$config[ $action ]
			);
		}
		// v1.5.8: no configured limit for this action → return null so
		// consume() returns true immediately (unlimited).
		return null;
	}

	/**
	 * Check whether a request is allowed; if so, increment the counter.
	 *
	 * @param string $action Action key.
	 * @param string $ip     Client IP.
	 * @return bool True when allowed.
	 */
	public static function consume( $action, $ip ) {
		$limit = self::get_limit( $action );
		// v1.5.8: null = unlimited action → skip the transient hit entirely.
		if ( null === $limit ) {
			return true;
		}
		$key   = self::PREFIX . $action . '_' . sha1( (string) $ip . self::daily_salt() );
		$count = (int) get_transient( $key );

		if ( $count >= (int) $limit['max'] ) {
			return false;
		}

		set_transient( $key, $count + 1, (int) $limit['window'] );
		return true;
	}

	/**
	 * Daily-rotating salt so day boundaries naturally roll the buckets.
	 *
	 * @return string
	 */
	private static function daily_salt() {
		$today = wp_date( 'Y-m-d' );
		$salt  = (string) get_option( 'zymarg_wcpg_daily_salt', '' );
		if ( '' === $salt || strpos( $salt, $today ) !== 0 ) {
			$salt = $today . '|' . wp_generate_password( 16, false, false );
			update_option( 'zymarg_wcpg_daily_salt', $salt, false );
		}
		return $salt;
	}
}
