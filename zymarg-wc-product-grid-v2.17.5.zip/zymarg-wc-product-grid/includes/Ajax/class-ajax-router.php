<?php
/**
 * AJAX router - registers all user-facing handlers.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Ajax;

defined( 'ABSPATH' ) || exit;

use Zymarg\WCPG\Ajax\Handlers\Handler_Add_To_Cart;
use Zymarg\WCPG\Ajax\Handlers\Handler_Buy_Now;
use Zymarg\WCPG\Ajax\Handlers\Handler_Search_Cards;
use Zymarg\WCPG\Ajax\Handlers\Handler_Hydrate;
use Zymarg\WCPG\Ajax\Handlers\Handler_Load_More;
use Zymarg\WCPG\Ajax\Handlers\Handler_QuickView;
use Zymarg\WCPG\Ajax\Handlers\Handler_Track_Click;
use Zymarg\WCPG\Ajax\Handlers\Handler_Wishlist;

/**
 * Class Ajax_Router
 *
 * Phase 4 ships:
 *   wishlist     - add / remove / toggle, returns updated wishlist count
 *   add_to_cart  - simple-product AJAX add, returns cart fragments
 *   track_click  - push event into Event_Buffer
 *   hydrate      - returns visitor-specific wishlist IDs for cache-safe state
 *   load_more    - returns next page of rendered cards
 */
class Ajax_Router {

	/**
	 * Handler classes to register.
	 *
	 * @return string[]
	 */
	public static function handlers() {
		return array(
			Handler_Wishlist::class,
			Handler_Add_To_Cart::class,
			Handler_Track_Click::class,
			Handler_Hydrate::class,
			Handler_Load_More::class,
			Handler_QuickView::class,
			Handler_Buy_Now::class,
			Handler_Search_Cards::class,
		);
	}

	/**
	 * Wire all handlers.
	 */
	public function register() {
		foreach ( self::handlers() as $class ) {
			if ( class_exists( $class ) ) {
				( new $class() )->register();
			}
		}
	}
}
