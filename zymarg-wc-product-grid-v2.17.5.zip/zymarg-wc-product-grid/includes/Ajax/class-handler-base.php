<?php
/**
 * Abstract base for user-facing AJAX handlers.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Ajax;

defined( 'ABSPATH' ) || exit;

/**
 * Class Handler_Base
 */
abstract class Handler_Base {

	const NONCE_ACTION = 'zymarg_wcpg';

	/**
	 * Action name (without the 'zymarg_wcpg_' prefix).
	 *
	 * @return string
	 */
	abstract public function action_key();

	/**
	 * Whether to register the nopriv variant (allow guests).
	 *
	 * @return bool
	 */
	public function allows_guests() {
		return true;
	}

	/**
	 * Wire the handler to admin-ajax.
	 */
	public function register() {
		$action = 'zymarg_wcpg_' . $this->action_key();
		add_action( 'wp_ajax_' . $action, array( $this, 'dispatch' ) );
		if ( $this->allows_guests() ) {
			add_action( 'wp_ajax_nopriv_' . $action, array( $this, 'dispatch' ) );
		}
	}

	/**
	 * Common entry point: run guards, then delegate.
	 */
	public function dispatch() {
		header( 'X-Content-Type-Options: nosniff' );

		if ( ! check_ajax_referer( self::NONCE_ACTION, 'nonce', false ) ) {
			$this->send_error( __( 'Invalid request.', 'zymarg-wcpg' ), 403 );
		}

		$ip = self::get_client_ip();
		if ( ! Rate_Limiter::consume( $this->action_key(), $ip ) ) {
			$this->send_error( __( 'Too many requests. Please slow down.', 'zymarg-wcpg' ), 429 );
		}

		try {
			$this->handle();
		} catch ( \Throwable $e ) {
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				$this->send_error( $e->getMessage(), 500 );
			}
			$this->send_error( __( 'Something went wrong. Please try again.', 'zymarg-wcpg' ), 500 );
		}
	}

	/**
	 * Handler body.
	 */
	abstract protected function handle();

	/**
	 * Send a successful JSON response and exit.
	 *
	 * @param array $data Payload.
	 */
	protected function send_success( array $data = array() ) {
		wp_send_json_success( $data );
	}

	/**
	 * Send an error JSON response and exit.
	 *
	 * @param string $message User-facing message.
	 * @param int    $status  HTTP status code.
	 */
	protected function send_error( $message, $status = 400 ) {
		wp_send_json_error(
			array( 'message' => (string) $message ),
			(int) $status
		);
	}

	/**
	 * Read a sanitized POST scalar.
	 *
	 * @param string $key      Key.
	 * @param string $sanitize Sanitizer fn name.
	 * @param mixed  $default  Default value.
	 * @return mixed
	 */
	protected function post( $key, $sanitize = 'sanitize_text_field', $default = '' ) {
		if ( ! isset( $_POST[ $key ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			return $default;
		}
		$raw = wp_unslash( $_POST[ $key ] ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		return is_callable( $sanitize ) ? call_user_func( $sanitize, $raw ) : $raw;
	}

	/**
	 * Read a sanitized POST integer.
	 *
	 * @param string $key Key.
	 * @return int
	 */
	protected function post_int( $key ) {
		return isset( $_POST[ $key ] ) ? (int) wp_unslash( $_POST[ $key ] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing
	}

	/**
	 * Best-effort client IP.
	 *
	 * v2.11.0: proxy headers are no longer trusted by default.
	 *
	 * HTTP_X_FORWARDED_FOR and HTTP_CF_CONNECTING_IP are supplied by the
	 * client. Reading them unconditionally meant every per-IP rate limit
	 * in the plugin could be bypassed by rotating one request header, and
	 * the daily analytics de-dup hash could be poisoned the same way. They
	 * are only consulted when the site explicitly declares that it sits
	 * behind a proxy that overwrites them:
	 *
	 *   define( 'ZYMARG_WCPG_TRUST_PROXY', true );
	 *   add_filter( 'zymarg_wcpg_trust_proxy_headers', '__return_true' );
	 *
	 * @return string
	 */
	public static function get_client_ip() {
		$remote = isset( $_SERVER['REMOTE_ADDR'] ) && ! is_array( $_SERVER['REMOTE_ADDR'] )
			? trim( (string) wp_unslash( $_SERVER['REMOTE_ADDR'] ) )
			: '';
		$remote = filter_var( $remote, FILTER_VALIDATE_IP ) ? $remote : '0.0.0.0';

		$trust = defined( 'ZYMARG_WCPG_TRUST_PROXY' ) && ZYMARG_WCPG_TRUST_PROXY;

		/**
		 * Filter whether forwarded-for style headers may be trusted.
		 *
		 * @since 2.11.0
		 * @param bool   $trust  Whether to read proxy headers.
		 * @param string $remote The raw REMOTE_ADDR value.
		 */
		if ( ! (bool) apply_filters( 'zymarg_wcpg_trust_proxy_headers', $trust, $remote ) ) {
			return $remote;
		}

		foreach ( array( 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR' ) as $key ) {
			if ( empty( $_SERVER[ $key ] ) || is_array( $_SERVER[ $key ] ) ) {
				continue;
			}
			$first = trim( explode( ',', (string) wp_unslash( $_SERVER[ $key ] ) )[0] );
			if ( filter_var( $first, FILTER_VALIDATE_IP ) ) {
				return $first;
			}
		}

		return $remote;
	}

	/**
	 * Daily-salted hash of IP+UA, used by Event_Buffer for de-dup.
	 *
	 * @return string
	 */
	public static function ip_hash() {
		$ip   = self::get_client_ip();
		$ua   = isset( $_SERVER['HTTP_USER_AGENT'] ) ? wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) : '';
		$salt = wp_date( 'Y-m-d' );
		return hash( 'sha256', $ip . '|' . $ua . '|' . $salt );
	}
}
