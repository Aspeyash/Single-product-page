<?php
/**
 * Compatibility checks and environment status.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG;

defined( 'ABSPATH' ) || exit;

/**
 * Class Compatibility
 *
 * Determines whether required dependencies (WooCommerce, Elementor) are
 * present and active at sufficient versions. Surfaces actionable admin
 * notices when something is missing.
 *
 * Optional integrations (Astra, Astra Pro, Dokan) are detected so other
 * subsystems can branch on them, but are never required.
 */
class Compatibility {

	/**
	 * Cached environment-ready flag.
	 *
	 * @var bool|null
	 */
	private $ready = null;

	/**
	 * Reasons the environment is not ready (already-translated strings).
	 *
	 * @var string[]
	 */
	private $blockers = array();

	/**
	 * Hook admin notices.
	 */
	public function register() {
		// Evaluate once now so blockers are populated.
		$this->is_environment_ready();

		if ( ! empty( $this->blockers ) ) {
			add_action( 'admin_notices', array( $this, 'render_blocker_notices' ) );
		}

		add_action( 'admin_notices', array( $this, 'render_optional_notices' ) );
	}

	/**
	 * Whether all hard dependencies are satisfied.
	 *
	 * @return bool
	 */
	public function is_environment_ready() {
		if ( null !== $this->ready ) {
			return $this->ready;
		}

		$this->blockers = array();

		// WooCommerce.
		if ( ! $this->is_woocommerce_active() ) {
			$this->blockers[] = esc_html__( 'WooCommerce is not active. Please install and activate WooCommerce.', 'zymarg-wcpg' );
		} elseif ( defined( 'WC_VERSION' ) && version_compare( WC_VERSION, ZYMARG_WCPG_MIN_WC, '<' ) ) {
			$this->blockers[] = sprintf(
				/* translators: 1: required WC version, 2: current WC version */
				esc_html__( 'WooCommerce %1$s or higher is required. You are running %2$s.', 'zymarg-wcpg' ),
				ZYMARG_WCPG_MIN_WC,
				WC_VERSION
			);
		}

		// Elementor (v2.7.0: OPTIONAL, no longer a hard dependency).
		//
		// The plugin is a standalone rendering engine. Elementor is just one
		// consumer alongside the shortcode, the PHP API and the page consumers,
		// so its absence must never stop the engine from booting. Only the
		// version check remains, and only when Elementor is actually active --
		// an outdated Elementor would break the widgets, but a missing one
		// simply means the widgets are not registered.
		if ( $this->is_elementor_active() && defined( 'ELEMENTOR_VERSION' ) && version_compare( ELEMENTOR_VERSION, ZYMARG_WCPG_MIN_ELEMENTOR, '<' ) ) {
			$this->blockers[] = sprintf(
				/* translators: 1: required Elementor version, 2: current Elementor version */
				esc_html__( 'Elementor %1$s or higher is required. You are running %2$s.', 'zymarg-wcpg' ),
				ZYMARG_WCPG_MIN_ELEMENTOR,
				ELEMENTOR_VERSION
			);
		}

		$this->ready = empty( $this->blockers );
		return $this->ready;
	}

	/**
	 * Render admin notices for hard blockers.
	 */
	public function render_blocker_notices() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		foreach ( $this->blockers as $message ) {
			printf(
				'<div class="notice notice-error"><p><strong>%s</strong> %s</p></div>',
				esc_html__( 'ZYMARG WC Product Grid:', 'zymarg-wcpg' ),
				wp_kses_post( $message )
			);
		}
	}

	/**
	 * Render admin notices for known soft conflicts (Astra Pro Quick View, etc.).
	 *
	 * Dismissable, low-priority, only shown to admins.
	 */
	public function render_optional_notices() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}

		// Astra Pro Quick View conflict awareness. We only flag if Astra Pro
		// is active AND its Quick View module is enabled.
		if ( $this->is_astra_pro_active() && $this->astra_pro_quickview_enabled() ) {
			printf(
				'<div class="notice notice-warning is-dismissible"><p><strong>%s</strong> %s</p></div>',
				esc_html__( 'ZYMARG WC Product Grid:', 'zymarg-wcpg' ),
				esc_html__( 'Astra Pro Quick View is enabled. To avoid conflicts, disable it under Astra Options or our Quick View toggle will be ignored.', 'zymarg-wcpg' )
			);
		}
	}

	/* -------------------------------------------------------------------- */
	/* Detectors                                                            */
	/* -------------------------------------------------------------------- */

	/**
	 * Whether WooCommerce is active.
	 *
	 * @return bool
	 */
	public function is_woocommerce_active() {
		return class_exists( 'WooCommerce' ) && function_exists( 'WC' );
	}

	/**
	 * Whether Elementor is active.
	 *
	 * @return bool
	 */
	public function is_elementor_active() {
		return did_action( 'elementor/loaded' ) || class_exists( '\Elementor\Plugin' );
	}

	/**
	 * Whether the active theme is Astra (parent or child).
	 *
	 * @return bool
	 */
	public function is_astra_active() {
		$theme = wp_get_theme();
		if ( 'astra' === $theme->get_template() ) {
			return true;
		}
		return defined( 'ASTRA_THEME_VERSION' );
	}

	/**
	 * Whether Astra Pro addon plugin is active.
	 *
	 * @return bool
	 */
	public function is_astra_pro_active() {
		return defined( 'ASTRA_EXT_VER' );
	}

	/**
	 * Whether Astra Pro's Quick View module is enabled.
	 *
	 * @return bool
	 */
	public function astra_pro_quickview_enabled() {
		if ( ! $this->is_astra_pro_active() ) {
			return false;
		}
		// Astra stores enabled extensions in this option.
		$enabled = get_option( 'astra-addon-extensions', array() );
		if ( ! is_array( $enabled ) ) {
			return false;
		}
		return ! empty( $enabled['woocommerce-quick-view'] );
	}

	/**
	 * Whether Dokan (free or pro) is active.
	 *
	 * @return bool
	 */
	public function is_dokan_active() {
		return class_exists( 'WeDevs_Dokan' ) || function_exists( 'dokan_get_vendor_by_product' );
	}
}
