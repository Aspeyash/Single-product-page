<?php
/**
 * Recently-viewed tracker.
 *
 * Per locked decision: every product page view is tracked automatically.
 *
 * Storage:
 *   Logged-in: user_meta '_zymarg_recently_viewed' (cookie kept in sync
 *              so cached HTML for the session can still hydrate correctly).
 *   Guest:     cookie 'zymarg_rv' (1-year TTL, refreshed each view) plus
 *              a WC session mirror for redundancy across cookie loss.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Tracking;

defined( 'ABSPATH' ) || exit;

/**
 * Class Recently_Viewed
 */
class Recently_Viewed {

	const COOKIE_NAME   = 'zymarg_rv';
	const SESSION_KEY   = 'zymarg_rv';
	const USER_META_KEY = '_zymarg_recently_viewed';
	const MAX_IDS       = 20;
	const COOKIE_TTL    = YEAR_IN_SECONDS;

	/**
	 * Wire the tracker hook.
	 */
	public function register() {
		add_action( 'template_redirect', array( $this, 'maybe_track' ), 20 );
	}

	/**
	 * Track the current product if we are on a single-product page.
	 */
	public function maybe_track() {
		if ( is_admin() || wp_doing_ajax() || wp_doing_cron() ) {
			return;
		}
		if ( ! function_exists( 'is_product' ) || ! is_product() ) {
			return;
		}
		$product_id = (int) get_queried_object_id();
		if ( ! $product_id ) {
			return;
		}
		self::record( $product_id );
	}

	/**
	 * Record a product ID at the top of the recently-viewed list.
	 *
	 * @param int $product_id Product ID.
	 */
	public static function record( $product_id ) {
		$product_id = (int) $product_id;
		if ( $product_id <= 0 ) {
			return;
		}

		$current = self::get_ids();
		$current = array_values( array_diff( $current, array( $product_id ) ) );
		array_unshift( $current, $product_id );
		$current = array_slice( $current, 0, self::MAX_IDS );

		self::write( $current );

		do_action( 'zymarg_wcpg_product_viewed', $product_id );
	}

	/**
	 * Read the recently-viewed list, auth-aware, with cookie + session fallbacks.
	 *
	 * @return int[]
	 */
	public static function get_ids() {
		if ( is_user_logged_in() ) {
			$ids = get_user_meta( get_current_user_id(), self::USER_META_KEY, true );
			if ( is_array( $ids ) && $ids ) {
				return self::sanitize_ids( $ids );
			}
		}

		if ( ! empty( $_COOKIE[ self::COOKIE_NAME ] ) ) {
			$decoded = json_decode( wp_unslash( $_COOKIE[ self::COOKIE_NAME ] ), true );
			if ( is_array( $decoded ) ) {
				return self::sanitize_ids( $decoded );
			}
		}

		if ( function_exists( 'WC' ) && WC() && WC()->session ) {
			$session_ids = WC()->session->get( self::SESSION_KEY );
			if ( is_array( $session_ids ) ) {
				return self::sanitize_ids( $session_ids );
			}
		}

		return array();
	}

	/**
	 * Persist the list to all relevant stores.
	 *
	 * @param int[] $ids Sanitized product IDs.
	 */
	private static function write( array $ids ) {
		$ids = self::sanitize_ids( $ids );

		if ( is_user_logged_in() ) {
			update_user_meta( get_current_user_id(), self::USER_META_KEY, $ids );
		}

		if ( ! headers_sent() ) {
			$value = wp_json_encode( $ids );
			setcookie(
				self::COOKIE_NAME,
				(string) $value,
				array(
					'expires'  => time() + self::COOKIE_TTL,
					'path'     => COOKIEPATH ? COOKIEPATH : '/',
					'domain'   => COOKIE_DOMAIN ? COOKIE_DOMAIN : '',
					'secure'   => is_ssl(),
					'httponly' => false,
					'samesite' => 'Lax',
				)
			);
			$_COOKIE[ self::COOKIE_NAME ] = $value;
		}

		if ( function_exists( 'WC' ) && WC() && WC()->session ) {
			WC()->session->set( self::SESSION_KEY, $ids );
		}
	}

	/**
	 * Sanitize a list of IDs.
	 *
	 * @param array $ids Raw IDs.
	 * @return int[]
	 */
	private static function sanitize_ids( $ids ) {
		$ids = array_map( 'intval', (array) $ids );
		$ids = array_filter(
			$ids,
			static function ( $i ) {
				return $i > 0;
			}
		);
		return array_values( array_slice( array_unique( $ids ), 0, self::MAX_IDS ) );
	}
}
