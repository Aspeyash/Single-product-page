<?php
/**
 * Store Products Consumer.
 *
 * Step 6 of Milestone 4 — Consumer Migration.
 *
 * Renders the product grid on a Dokan vendor storefront page using the
 * 'store-products' slot, which resolves to the 'store-grid' template
 * with source 'current_vendor'.
 *
 * Consumer responsibility (Rule #16):
 *   Read context  →  Translate  →  Public_API::render()  →  Done.
 *
 * This class knows:
 *   - How to detect a Dokan store page.
 *   - How to resolve the current vendor user ID from the URL/query.
 *   - Which slot to pass to the engine ('store-products').
 *
 * This class must never know:
 *   - Query_Builder, Render_Engine, Template_Loader.
 *   - How 'current_vendor' source fetches products.
 *
 * @package Zymarg\WCPG\PageConsumers
 * @since   1.6.5
 */

namespace Zymarg\WCPG\PageConsumers;

use Zymarg\WCPG\Api\Public_API;

defined( 'ABSPATH' ) || exit;

/**
 * Class Store_Products_Consumer
 */
class Store_Products_Consumer {

	/**
	 * Register hooks.
	 *
	 * Only hooks in when Dokan is active — guarded by function_exists
	 * so the class loads safely even without Dokan.
	 *
	 * @return void
	 */
	public function register(): void {
		if ( ! function_exists( 'dokan_is_store_page' ) ) {
			return;
		}

		// dokan_after_store_products fires inside the Dokan store template
		// after the store header. This is the canonical position for the
		// product grid on a vendor store page.
		add_action( 'dokan_after_store_products', [ $this, 'render' ] );
	}

	/**
	 * Detect the current vendor and hand off to the engine.
	 *
	 * @return void
	 */
	public function render(): void {
		if ( ! function_exists( 'dokan_is_store_page' ) || ! dokan_is_store_page() ) {
			return;
		}

		// Read page context — vendor detection is the consumer's responsibility.
		$vendor_id = $this->resolve_vendor_id();
		if ( $vendor_id <= 0 ) {
			return;
		}

		// Hand off to the engine.
		// The 'store-products' slot resolves to the 'store-grid' template.
		// Choosing the source is the consumer's responsibility (Rule #16) —
		// template configs deliberately carry no query.source — so it is
		// declared explicitly here. vendor_id in context tells the source
		// which vendor's products to fetch.
		echo Public_API::render( [  // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			'slot'    => 'store-products',
			'query'   => [
				'source' => 'current_vendor',
			],
			'context' => [
				'vendor_id' => $vendor_id,
			],
		] );
	}

	// -------------------------------------------------------------------------
	// Context detection — vendor resolution is a consumer concern.
	// -------------------------------------------------------------------------

	/**
	 * Resolve the current vendor user ID from the request.
	 *
	 * Tries three resolution methods in order:
	 *   1. Dokan's store page query var (most reliable).
	 *   2. Queried WP_User object (works when the store is user-based).
	 *   3. Author slug query var (fallback for custom Dokan URL structures).
	 *
	 * Returns 0 if no vendor can be resolved.
	 *
	 * @return int Vendor user ID, or 0.
	 */
	private function resolve_vendor_id(): int {
		// Method 1 — Dokan resolves the store slug to a user ID via query var.
		$vendor_id = (int) get_query_var( 'author' );
		if ( $vendor_id > 0 ) {
			return $vendor_id;
		}

		// Method 2 — The queried object is a WP_User on store archive pages.
		$queried = get_queried_object();
		if ( $queried instanceof \WP_User ) {
			return (int) $queried->ID;
		}

		// Method 3 — Resolve from the author_name slug.
		$slug = (string) get_query_var( 'author_name' );
		if ( '' !== $slug ) {
			$user = get_user_by( 'slug', $slug );
			if ( $user instanceof \WP_User ) {
				return (int) $user->ID;
			}
		}

		return 0;
	}
}
