<?php
/**
 * Category Products Consumer.
 *
 * Step 6 of Milestone 4 — Consumer Migration.
 *
 * Renders the product grid on WooCommerce product category archive pages
 * using the 'category-products' slot, which resolves to the 'category-grid'
 * template with source 'category'.
 *
 * Consumer responsibility (Rule #16):
 *   Read context  →  Translate  →  Public_API::render()  →  Done.
 *
 * This class knows:
 *   - How to detect a product category archive page.
 *   - How to read the current category term ID.
 *   - Which slot to pass to the engine ('category-products').
 *
 * This class must never know:
 *   - Query_Builder, Render_Engine, Template_Loader.
 *   - How 'category' source builds or executes the query.
 *
 * @package Zymarg\WCPG\PageConsumers
 * @since   1.6.5
 */

namespace Zymarg\WCPG\PageConsumers;

use Zymarg\WCPG\Api\Public_API;

defined( 'ABSPATH' ) || exit;

/**
 * Class Category_Products_Consumer
 */
class Category_Products_Consumer {

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register(): void {
		// woocommerce_before_shop_loop fires inside WooCommerce's
		// archive-product.php before the product loop begins. We hook here
		// to replace the default loop output with the engine's grid.
		// The default WooCommerce product loop must be suppressed separately
		// (see suppress_default_loop()) to avoid double output.
		add_action( 'woocommerce_before_shop_loop', [ $this, 'suppress_default_loop' ], 1 );
		add_action( 'woocommerce_before_shop_loop', [ $this, 'render' ], 20 );
	}

	/**
	 * Suppress WooCommerce's default product loop output.
	 *
	 * WooCommerce renders the product loop in woocommerce_product_loop_start /
	 * woocommerce_product_loop_end. Setting woocommerce_loop['is_paginated']
	 * to false and removing the loop hooks prevents it from outputting its
	 * own grid, leaving the slot free for our engine.
	 *
	 * Only acts on product category archives — no effect elsewhere.
	 *
	 * @return void
	 */
	public function suppress_default_loop(): void {
		if ( ! is_product_category() ) {
			return;
		}

		// Remove WooCommerce's own product loop actions so only our engine
		// output is rendered. These are the hooks that drive the default loop.
		remove_action( 'woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_link_open', 10 );
		remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_show_product_loop_sale_flash', 10 );
		remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10 );
		remove_action( 'woocommerce_shop_loop_item_title', 'woocommerce_template_loop_product_title', 10 );
		remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5 );
		remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10 );
		remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_product_link_close', 5 );
		remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10 );

		// v2.11.0: the removals above strip every piece of card content but
		// the loop itself still ran, emitting the <ul class="products"> wrapper
		// and one empty <li class="product"> per result underneath our grid.
		// Returning an empty template part suppresses the item markup at source,
		// and emptying the loop wrappers removes the leftover list container.
		add_filter( 'woocommerce_product_loop_start', '__return_empty_string', 99 );
		add_filter( 'woocommerce_product_loop_end', '__return_empty_string', 99 );
		add_filter( 'wc_get_template_part', array( $this, 'suppress_loop_item_template' ), 99, 3 );
	}

	/**
	 * Detect the current category and hand off to the engine.
	 *
	 * @return void
	 */
	/**
	 * Suppress WooCommerce's per-product loop template.
	 *
	 * wc_get_template_part() loads nothing when the path is empty, so this
	 * removes the <li class="product"> shells the default loop would emit
	 * alongside our grid. Every other template part is passed through.
	 *
	 * @since 2.11.0
	 * @param string $template Resolved template path.
	 * @param string $slug     Template slug.
	 * @param string $name     Template name.
	 * @return string
	 */
	public function suppress_loop_item_template( $template, $slug, $name ) {
		if ( 'content' === $slug && 'product' === $name ) {
			return '';
		}

		return $template;
	}

	public function render(): void {
		if ( ! is_product_category() ) {
			return;
		}

		// Read page context — category detection is the consumer's responsibility.
		$term = get_queried_object();
		if ( ! ( $term instanceof \WP_Term ) || 'product_cat' !== $term->taxonomy ) {
			return;
		}

		$category_id = (int) $term->term_id;
		if ( $category_id <= 0 ) {
			return;
		}

		// Hand off to the engine.
		// The 'category-products' slot resolves to the 'category-grid' template.
		// Choosing the source is the consumer's responsibility (Rule #16) —
		// template configs deliberately carry no query.source — so it is
		// declared explicitly here. category_id in context tells the source
		// which category to fetch products from.
		echo Public_API::render( [  // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			'slot'    => 'category-products',
			'query'   => [
				'source' => 'category',
			],
			'context' => [
				'category_id' => $category_id,
			],
		] );
	}
}
