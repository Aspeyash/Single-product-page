<?php
/**
 * Related Products Consumer.
 *
 * Step 6 of Milestone 4 — Consumer Migration.
 *
 * Replaces WooCommerce's default related products output on single product
 * pages with the ZYMARG product grid engine.
 *
 * Consumer responsibility (Rule #16):
 *   Read context  →  Translate  →  Public_API::render()  →  Done.
 *
 * This class knows:
 *   - How to detect a single product page (WordPress/WooCommerce context).
 *   - Which slot to pass to the engine ('related-products').
 *
 * This class must never know:
 *   - Query_Builder, Render_Engine, Template_Loader.
 *   - How the engine resolves slots or builds queries.
 *   - Config_Normalizer or card settings.
 *
 * @package Zymarg\WCPG\PageConsumers
 * @since   1.6.5
 */

namespace Zymarg\WCPG\PageConsumers;

use Zymarg\WCPG\Api\Public_API;

defined( 'ABSPATH' ) || exit;

/**
 * Class Related_Products_Consumer
 */
class Related_Products_Consumer {

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register(): void {
		// Remove WooCommerce's default related products section.
		// Priority 20 matches WooCommerce's own hook registration.
		remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );

		// Replace with our engine output at the same priority so theme
		// templates that re-call woocommerce_after_single_product_summary
		// get the ZYMARG grid in the right position.
		add_action( 'woocommerce_after_single_product_summary', [ $this, 'render' ], 20 );
	}

	/**
	 * Detect context and hand off to the engine.
	 *
	 * @return void
	 */
	public function render(): void {
		if ( ! is_product() ) {
			return;
		}

		// Read page context — this is the consumer's responsibility.
		$product_id = (int) get_queried_object_id();
		if ( $product_id <= 0 ) {
			return;
		}

		// Hand off to the engine.
		// The 'related-products' slot resolves to the 'related-grid' template.
		// Choosing the source is the consumer's responsibility (Rule #16) —
		// template configs deliberately carry no query.source — so it is
		// declared explicitly here. Context_Resolver derives vendor_id and
		// category_id from product_id automatically.
		echo Public_API::render( [  // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			'slot'    => 'related-products',
			'query'   => [
				'source' => 'similar',
			],
			'context' => [
				'product_id' => $product_id,
			],
		] );
	}
}
