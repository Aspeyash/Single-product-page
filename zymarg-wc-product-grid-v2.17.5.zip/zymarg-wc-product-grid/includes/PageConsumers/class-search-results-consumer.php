<?php
/**
 * Search Results Consumer.
 *
 * Step 6 of Milestone 4 — Consumer Migration.
 *
 * Renders the product grid on WooCommerce search results pages using the
 * 'search-results' slot, which resolves to the 'search-grid' template with
 * source 'algolia' (falling back to WooCommerce native search when Algolia
 * is not configured).
 *
 * Consumer responsibility (Rule #16):
 *   Read context  →  Translate  →  Public_API::render()  →  Done.
 *
 * This class knows:
 *   - How to detect a WooCommerce search results page.
 *   - How to read the current search query string.
 *   - Which slot to pass to the engine ('search-results').
 *
 * This class must never know:
 *   - Query_Builder, Render_Engine, Template_Loader.
 *   - Whether Algolia or WooCommerce native search executes the query —
 *     that is the engine's concern via the source classes.
 *
 * @package Zymarg\WCPG\PageConsumers
 * @since   1.6.5
 */

namespace Zymarg\WCPG\PageConsumers;

use Zymarg\WCPG\Api\Public_API;

defined( 'ABSPATH' ) || exit;

/**
 * Class Search_Results_Consumer
 */
class Search_Results_Consumer {

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register(): void {
		// woocommerce_before_shop_loop fires inside WooCommerce's shop/search
		// template before the product loop. We suppress the default loop and
		// render our engine output in its place, exactly as we do on category
		// archive pages.
		add_action( 'woocommerce_before_shop_loop', [ $this, 'suppress_default_loop' ], 1 );
		add_action( 'woocommerce_before_shop_loop', [ $this, 'render' ], 20 );
	}

	/**
	 * Suppress WooCommerce's default search result loop output.
	 *
	 * Only acts on WooCommerce product search pages — no effect elsewhere.
	 *
	 * @return void
	 */
	public function suppress_default_loop(): void {
		if ( ! $this->is_product_search() ) {
			return;
		}

		remove_action( 'woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_link_open', 10 );
		remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_show_product_loop_sale_flash', 10 );
		remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10 );
		remove_action( 'woocommerce_shop_loop_item_title', 'woocommerce_template_loop_product_title', 10 );
		remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5 );
		remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10 );
		remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_product_link_close', 5 );
		remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10 );

		// v2.11.0: the removals above strip every piece of card content but
		// the loop itself still ran, emitting the <ul class="products"> wrapper
		// and one empty <li class="product"> per result underneath our grid.
		// Returning an empty template part suppresses the item markup at source,
		// and emptying the loop wrappers removes the leftover list container.
		add_filter( 'woocommerce_product_loop_start', '__return_empty_string', 99 );
		add_filter( 'woocommerce_product_loop_end', '__return_empty_string', 99 );
		add_filter( 'wc_get_template_part', array( $this, 'suppress_loop_item_template' ), 99, 3 );
	}

	/**
	 * Detect the search query and hand off to the engine.
	 *
	 * @return void
	 */
	/**
	 * Suppress WooCommerce's per-product loop template.
	 *
	 * wc_get_template_part() loads nothing when the path is empty, so this
	 * removes the <li class="product"> shells the default loop would emit
	 * alongside our grid. Every other template part is passed through.
	 *
	 * @since 2.11.0
	 * @param string $template Resolved template path.
	 * @param string $slug     Template slug.
	 * @param string $name     Template name.
	 * @return string
	 */
	public function suppress_loop_item_template( $template, $slug, $name ) {
		if ( 'content' === $slug && 'product' === $name ) {
			return '';
		}

		return $template;
	}

	public function render(): void {
		if ( ! $this->is_product_search() ) {
			return;
		}

		// Read page context — search query detection is the consumer's responsibility.
		$search_query = (string) get_search_query();

		// Hand off to the engine.
		// The 'search-results' slot resolves to the 'search-grid' template.
		// Choosing the source is the consumer's responsibility (Rule #16) —
		// template configs deliberately carry no query.source — so it is
		// declared explicitly here. The search string in context is passed
		// through to the Algolia source, which degrades to Source_All when
		// Algolia credentials are absent.
		echo Public_API::render( [  // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			'slot'    => 'search-results',
			'query'   => [
				'source' => 'algolia',
			],
			'context' => [
				'search' => $search_query,
			],
		] );
	}

	// -------------------------------------------------------------------------
	// Context detection helper
	// -------------------------------------------------------------------------

	/**
	 * Whether the current page is a WooCommerce product search results page.
	 *
	 * WooCommerce sets post_type=product on its search requests.
	 * We check both is_search() and the post_type query var to avoid
	 * firing on non-product WordPress searches.
	 *
	 * @return bool
	 */
	private function is_product_search(): bool {
		return is_search()
			&& isset( $_GET['post_type'] )  // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			&& 'product' === $_GET['post_type'];  // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	}
}
