<?php
/**
 * Layout tab controls (Tab 1).
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Elementor\Traits;

defined( 'ABSPATH' ) || exit;

/**
 * Trait Controls_Layout
 *
 * Registers the Layout section in the Content tab. The Heading section is
 * provided by Controls_Heading and is registered before this section in the
 * widget's register_controls() to honour the locked control order.
 */
trait Controls_Layout {

	/**
	 * Register the Layout section.
	 */
	protected function register_layout_section() {
		$this->start_controls_section(
			'section_layout',
			array(
				'label' => __( 'Layout', 'zymarg-wcpg' ),
			)
		);

		$this->add_control(
			'layout_type',
			array(
				'label'       => __( 'Layout type', 'zymarg-wcpg' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'grid',
				'options'     => array(
					'grid'   => __( 'Grid', 'zymarg-wcpg' ),
					'slider' => __( 'Slider (Swiper carousel)', 'zymarg-wcpg' ),
				),
				'description' => __( 'Choose how products are displayed. Slider mode reveals additional controls (autoplay, arrows, pagination, etc.).', 'zymarg-wcpg' ),
			)
		);

		$this->add_control(
			'card_template',
			array(
				'label'       => __( 'Card template', 'zymarg-wcpg' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'classic',
				'options'     => self::get_card_template_options(),
				'description' => __( 'The design used for each individual product card. Additional templates appear here automatically when a template plugin registers one.', 'zymarg-wcpg' ),
			)
		);

		$this->add_responsive_control(
			'columns',
			array(
				'label'          => __( 'Columns', 'zymarg-wcpg' ),
				'type'           => \Elementor\Controls_Manager::SELECT,
				'default'        => '4',
				'tablet_default' => '3',
				'mobile_default' => '2',
				'options'        => array(
					'1' => '1',
					'2' => '2',
					'3' => '3',
					'4' => '4',
					'5' => '5',
					'6' => '6',
				),
				'selectors'      => array(
					'{{WRAPPER}} .zymarg-wcpg__grid' => 'grid-template-columns: repeat({{VALUE}}, minmax(0, 1fr));',
				),
			)
		);

		$this->add_control(
			'total_products',
			array(
				'label'       => __( 'Total products', 'zymarg-wcpg' ),
				'type'        => \Elementor\Controls_Manager::NUMBER,
				'default'     => 8,
				'min'         => 0,
				'max'         => 100,
				'step'        => 1,
				'description' => __( 'Number of products to show. Set to 0 for no limit (subject to a 500-product safety ceiling).', 'zymarg-wcpg' ),
			)
		);

		$this->add_control(
			'large_grid_notice',
			array(
				'type'      => \Elementor\Controls_Manager::RAW_HTML,
				'raw'       => '<div class="elementor-panel-alert elementor-panel-alert-info">'
					. esc_html__( 'Tip: For grids over 30 products, keep "Use full resolution" off in the Image settings for better performance.', 'zymarg-wcpg' )
					. '</div>',
				'condition' => array( 'total_products' => array( 31, 100 ) ),
			)
		);

		$this->add_control(
			'source',
			array(
				'label'   => __( 'Source', 'zymarg-wcpg' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'all',
				'options' => array(
					'all'            => __( 'All products', 'zymarg-wcpg' ),
					'dynamic'        => __( 'Dynamic products', 'zymarg-wcpg' ),
					'featured'       => __( 'Featured products', 'zymarg-wcpg' ),
					'best_selling'   => __( 'Best-selling products', 'zymarg-wcpg' ),
					'trending'       => __( 'Trending products', 'zymarg-wcpg' ),
					'recommended'    => __( 'Recommended For You (personalized)', 'zymarg-wcpg' ),
					'similar'        => __( 'Similar products', 'zymarg-wcpg' ),
					'vendor'         => __( 'More From Seller (Dokan)', 'zymarg-wcpg' ),
					'current_vendor' => __( "Current Vendor's Products (Dokan Store Page)", 'zymarg-wcpg' ),
					'recent'         => __( 'Recently viewed', 'zymarg-wcpg' ),
					'wishlist'       => __( 'Wishlist', 'zymarg-wcpg' ),
					'algolia'        => __( 'Algolia Search Results (search pages only)', 'zymarg-wcpg' ),
					'category'       => __( 'Category Page (auto-detected)', 'zymarg-wcpg' ),
					'flash_deals'    => __( 'Flash Deals (time-limited sales)', 'zymarg-wcpg' ),
				),
			)
		);

		$this->add_control(
			'orderby',
			array(
				'label'   => __( 'Order by', 'zymarg-wcpg' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'date',
				'options' => array(
					'date'       => __( 'Date', 'zymarg-wcpg' ),
					'title'      => __( 'Title', 'zymarg-wcpg' ),
					'price'      => __( 'Price', 'zymarg-wcpg' ),
					'popularity' => __( 'Popularity (sales)', 'zymarg-wcpg' ),
					'rating'     => __( 'Rating', 'zymarg-wcpg' ),
					'rand'       => __( 'Random', 'zymarg-wcpg' ),
					'menu_order' => __( 'Menu order', 'zymarg-wcpg' ),
				),
			)
		);

		$this->add_control(
			'order',
			array(
				'label'     => __( 'Order', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'default'   => 'DESC',
				'options'   => array(
					'ASC'  => __( 'Ascending', 'zymarg-wcpg' ),
					'DESC' => __( 'Descending', 'zymarg-wcpg' ),
				),
				'condition' => array(
					'orderby!' => array( 'rand', 'menu_order' ),
				),
			)
		);

		$this->add_control(
			'show_oos',
			array(
				'label'        => __( 'Show out-of-stock products', 'zymarg-wcpg' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => '',
			)
		);

		$this->add_control(
			'include_products',
			array(
				'label'       => __( 'Include product IDs', 'zymarg-wcpg' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'placeholder' => '12, 34, 56',
				'description' => __( 'Comma-separated product IDs. The async picker ships in Phase 4.', 'zymarg-wcpg' ),
			)
		);

		$this->add_control(
			'exclude_products',
			array(
				'label'       => __( 'Exclude product IDs', 'zymarg-wcpg' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'placeholder' => '12, 34, 56',
				'description' => __( 'Comma-separated product IDs.', 'zymarg-wcpg' ),
			)
		);

		$this->add_control(
			'include_categories',
			array(
				'label'       => __( 'Include categories', 'zymarg-wcpg' ),
				'type'        => \Elementor\Controls_Manager::SELECT2,
				'multiple'    => true,
				'options'     => self::get_category_options(),
				'label_block' => true,
			)
		);

		$this->add_control(
			'exclude_categories',
			array(
				'label'       => __( 'Exclude categories', 'zymarg-wcpg' ),
				'type'        => \Elementor\Controls_Manager::SELECT2,
				'multiple'    => true,
				'options'     => self::get_category_options(),
				'label_block' => true,
			)
		);

		$this->add_control(
			'pagination_mode',
			array(
				'label'   => __( 'Pagination', 'zymarg-wcpg' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'none',
				'options' => array(
					'none'      => __( 'None', 'zymarg-wcpg' ),
					'load_more' => __( 'Load more button', 'zymarg-wcpg' ),
					'infinite'  => __( 'Infinite scroll', 'zymarg-wcpg' ),
				),
				'description' => __( 'Numbered pagination ships in Phase 9 polish.', 'zymarg-wcpg' ),
			)
		);

		$this->add_control(
			'load_more_text',
			array(
				'label'     => __( 'Load more button text', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::TEXT,
				'default'   => __( 'Load more', 'zymarg-wcpg' ),
				'condition' => array( 'pagination_mode' => array( 'load_more', 'infinite' ) ),
			)
		);

		// -----------------------------------------------------------------
		// v2.6.0: Infinite scroll batch sizes and auto-load caps.
		// Device values are resolved in the browser from viewport width
		// (768 / 1025 breakpoints) so page caching cannot bake one
		// device's numbers into the cached HTML.
		// -----------------------------------------------------------------
		$this->add_control(
			'infinite_batch_size',
			array(
				'label'       => __( 'Products per auto-load (desktop)', 'zymarg-wcpg' ),
				'type'        => \Elementor\Controls_Manager::NUMBER,
				'default'     => 20,
				'min'         => 1,
				'max'         => 48,
				'condition'   => array( 'pagination_mode' => 'infinite' ),
				'description' => __( 'How many products each automatic load adds. This is separate from the first-page count set by Number of products.', 'zymarg-wcpg' ),
			)
		);

		$this->add_control(
			'infinite_batch_size_tablet',
			array(
				'label'     => __( 'Products per auto-load (tablet)', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::NUMBER,
				'default'   => 20,
				'min'       => 1,
				'max'       => 48,
				'condition' => array( 'pagination_mode' => 'infinite' ),
			)
		);

		$this->add_control(
			'infinite_batch_size_mobile',
			array(
				'label'     => __( 'Products per auto-load (mobile)', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::NUMBER,
				'default'   => 10,
				'min'       => 1,
				'max'       => 48,
				'condition' => array( 'pagination_mode' => 'infinite' ),
			)
		);

		$this->add_control(
			'infinite_max_products',
			array(
				'label'       => __( 'Max auto-loaded products (desktop)', 'zymarg-wcpg' ),
				'type'        => \Elementor\Controls_Manager::NUMBER,
				'default'     => 100,
				'min'         => 1,
				'max'         => 500,
				'condition'   => array( 'pagination_mode' => 'infinite' ),
				'description' => __( 'Automatic loading stops once this many products have been added, then the Load more button appears. The first page is not counted.', 'zymarg-wcpg' ),
			)
		);

		$this->add_control(
			'infinite_max_products_tablet',
			array(
				'label'     => __( 'Max auto-loaded products (tablet)', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::NUMBER,
				'default'   => 100,
				'min'       => 1,
				'max'       => 500,
				'condition' => array( 'pagination_mode' => 'infinite' ),
			)
		);

		$this->add_control(
			'infinite_max_products_mobile',
			array(
				'label'     => __( 'Max auto-loaded products (mobile)', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::NUMBER,
				'default'   => 50,
				'min'       => 1,
				'max'       => 500,
				'condition' => array( 'pagination_mode' => 'infinite' ),
			)
		);

		$this->add_control(
			'empty_message',
			array(
				'label'   => __( 'Empty state message', 'zymarg-wcpg' ),
				'type'    => \Elementor\Controls_Manager::TEXTAREA,
				'default' => __( 'No products found.', 'zymarg-wcpg' ),
				'rows'    => 2,
			)
		);

		// v1.5.22: Vendor Category Filter pairing.
		$this->add_control(
			'vcf_heading',
			array(
				'label'     => __( 'Vendor Category Filter', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => array( 'source' => 'current_vendor' ),
			)
		);

		$this->add_control(
			'filter_group_id',
			array(
				'label'       => __( 'Filter Group ID', 'zymarg-wcpg' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => '',
				'placeholder' => 'store-main',
				'description' => __( 'Set the same ID on this grid AND the ZYMARG Vendor Category Filter widget (Theme Builder) you want to pair with it. Leave empty to ignore all filter events.', 'zymarg-wcpg' ),
				'label_block' => true,
				'condition'   => array( 'source' => 'current_vendor' ),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Build the Card template dropdown options from the template registry.
	 *
	 * Options are read from Template_Manager at control-registration time.
	 * Elementor registers controls on `elementor/widgets/register`, which runs
	 * long after `plugins_loaded`, so every template plugin has already called
	 * register_card() by this point — a newly activated template pack appears
	 * in this dropdown with no change to this widget.
	 *
	 * The registry stores slug => path and carries no human-readable label, so
	 * labels are derived from the slug and can be overridden by the plugin that
	 * owns the template:
	 *
	 *     add_filter( 'zymarg_card_template_labels', function ( array $labels ) {
	 *         $labels['zymarg'] = 'ZYMARG Branded';
	 *         return $labels;
	 *     } );
	 *
	 * @since 2.2.0
	 * @return array<string,string> Slug => display label.
	 */
	private static function get_card_template_options() {
		$slugs = array_keys( \Zymarg\WCPG\Templates\Template_Manager::get_registered_cards() );

		// 'classic' is the core default and always leads the list; everything
		// else follows alphabetically so ordering does not depend on the order
		// plugins happened to load in.
		sort( $slugs );
		$slugs = array_values( array_unique( array_merge( array( 'classic' ), $slugs ) ) );

		$options = array();

		foreach ( $slugs as $slug ) {
			$options[ $slug ] = 'classic' === $slug
				? __( 'Classic (default)', 'zymarg-wcpg' )
				: ucwords( str_replace( array( '-', '_' ), ' ', $slug ) );
		}

		/**
		 * Filter the card template labels shown in the Elementor dropdown.
		 *
		 * Lets a template plugin present a proper display name instead of the
		 * label derived from its slug. Unknown keys are ignored, so a filter
		 * cannot introduce an unregistered template.
		 *
		 * @since 2.2.0
		 * @param array<string,string> $options Slug => display label.
		 */
		$labels = (array) apply_filters( 'zymarg_card_template_labels', $options );

		// Re-assert the registry as the source of truth: a label filter may
		// rename an option but must not add or remove one.
		foreach ( $options as $slug => $default_label ) {
			if ( isset( $labels[ $slug ] ) && is_string( $labels[ $slug ] ) && '' !== $labels[ $slug ] ) {
				$options[ $slug ] = $labels[ $slug ];
			}
		}

		return $options;
	}

	/**
	 * Fetch product category options for the SELECT2 controls.
	 *
	 * Capped at 200 terms to avoid bloating the editor UI on large catalogs.
	 * If a store has more than 200 categories, the remainder are still
	 * available via include/exclude category IDs in Phase 4 controls.
	 *
	 * @return array<int,string>
	 */
	private static function get_category_options() {
		$options = array();

		if ( ! taxonomy_exists( 'product_cat' ) ) {
			return $options;
		}

		$terms = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'hide_empty' => false,
				'number'     => 200,
				'orderby'    => 'name',
			)
		);

		if ( is_array( $terms ) ) {
			foreach ( $terms as $term ) {
				$options[ (int) $term->term_id ] = $term->name;
			}
		}

		return $options;
	}
}
