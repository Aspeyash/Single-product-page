<?php
/**
 * Slider-specific layout + style controls.
 *
 * All controls in both sections are conditioned on `layout_type === slider`
 * so they only appear when the editor switches the widget into slider mode.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Elementor\Traits;

defined( 'ABSPATH' ) || exit;

/**
 * Trait Controls_Slider
 */
trait Controls_Slider {

	/**
	 * Slider settings - Content tab.
	 */
	protected function register_slider_section() {
		$this->start_controls_section(
			'section_slider',
			array(
				'label'     => __( 'Slider', 'zymarg-wcpg' ),
				'condition' => array( 'layout_type' => 'slider' ),
			)
		);

		$this->add_control(
			'slider_free_scroll',
			array(
				'label'        => __( 'Smooth free scroll', 'zymarg-wcpg' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
				'description'  => __( 'Continuous momentum scrolling instead of snapping one product at a time. Looping is disabled while this is on.', 'zymarg-wcpg' ),
			)
		);

		$this->add_control(
			'slider_mousewheel',
			array(
				'label'        => __( 'Mouse wheel scroll', 'zymarg-wcpg' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
				'description'  => __( 'Scroll the slider horizontally with a trackpad or mouse wheel.', 'zymarg-wcpg' ),
			)
		);

		$this->add_control(
			'slider_autoplay',
			array(
				'label'        => __( 'Autoplay', 'zymarg-wcpg' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => '',
			)
		);

		$this->add_control(
			'slider_autoplay_delay',
			array(
				'label'     => __( 'Autoplay delay (ms)', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::NUMBER,
				'default'   => 4000,
				'min'       => 1000,
				'max'       => 20000,
				'step'      => 500,
				'condition' => array( 'slider_autoplay' => 'yes' ),
			)
		);

		$this->add_control(
			'slider_loop',
			array(
				'label'        => __( 'Loop', 'zymarg-wcpg' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
				'description'  => __( 'Only applies when Smooth free scroll is off.', 'zymarg-wcpg' ),
				'condition'    => array( 'slider_free_scroll!' => 'yes' ),
			)
		);

		$this->add_control(
			'slider_speed',
			array(
				'label'   => __( 'Transition speed (ms)', 'zymarg-wcpg' ),
				'type'    => \Elementor\Controls_Manager::NUMBER,
				'default' => 500,
				'min'     => 100,
				'max'     => 3000,
				'step'    => 50,
			)
		);

		$this->add_control(
			'slider_show_arrows',
			array(
				'label'        => __( 'Show arrows', 'zymarg-wcpg' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'slider_arrow_prev',
			array(
				'label'     => __( 'Previous arrow icon', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::ICONS,
				'default'   => array(
					'value'   => 'fas fa-chevron-left',
					'library' => 'fa-solid',
				),
				'condition' => array( 'slider_show_arrows' => 'yes' ),
			)
		);

		$this->add_control(
			'slider_arrow_next',
			array(
				'label'     => __( 'Next arrow icon', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::ICONS,
				'default'   => array(
					'value'   => 'fas fa-chevron-right',
					'library' => 'fa-solid',
				),
				'condition' => array( 'slider_show_arrows' => 'yes' ),
			)
		);

		$this->add_control(
			'slider_pagination_type',
			array(
				'label'       => __( 'Pagination', 'zymarg-wcpg' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				// v2.17.5: bullets, fraction, and progress bar were removed in favour of
				// the "X more" chip -- it communicates remaining products directly
				// instead of an abstract position indicator, which suits free-scroll
				// loop sliders better than a dot/bar ever could. Any widget saved with
				// the old 'bullets' / 'fraction' / 'progress' value falls through to
				// this new default the next time it renders, since those values no
				// longer exist in the option list.
				'default'     => 'chip',
				'options'     => array(
					''      => __( 'Hidden', 'zymarg-wcpg' ),
					'chip'  => __( 'X more chip', 'zymarg-wcpg' ),
				),
			)
		);

		$this->add_control(
			'slider_space_between',
			array(
				'label'       => __( 'Slide spacing (px)', 'zymarg-wcpg' ),
				'type'        => \Elementor\Controls_Manager::NUMBER,
				'description' => __( 'Leave empty to match the grid gap.', 'zymarg-wcpg' ),
				'default'     => '',
				'min'     => 0,
				'max'     => 60,
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Slider settings - Style tab.
	 */
	protected function register_slider_style_section() {
		$this->start_controls_section(
			'section_slider_style',
			array(
				'label'     => __( 'Slider arrows & chip', 'zymarg-wcpg' ),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => array( 'layout_type' => 'slider' ),
			)
		);

		$this->add_control(
			'slider_arrow_size',
			array(
				'label'     => __( 'Arrow size', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'min' => 24,
						'max' => 64,
					),
				),
				'default'   => array(
					'size' => 40,
					'unit' => 'px',
				),
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__slider-arrow' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'slider_arrow_color',
			array(
				'label'     => __( 'Arrow color', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#1a1a1a',
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__slider-arrow' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'slider_arrow_bg',
			array(
				'label'     => __( 'Arrow background', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__slider-arrow' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'slider_chip_bg',
			array(
				'label'     => __( 'Chip background', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#9500a5',
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__chip' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'slider_chip_text',
			array(
				'label'     => __( 'Chip text color', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__chip' => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}
}
