<?php
/**
 * Heading section controls (layout + style).
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Elementor\Traits;

defined( 'ABSPATH' ) || exit;

/**
 * Trait Controls_Heading
 *
 * Provides two registration methods:
 *   - register_heading_layout_section() : Tab CONTENT
 *   - register_heading_style_section()  : Tab STYLE
 *
 * Both sections are conditionally hidden based on the `show_heading` switcher.
 */
trait Controls_Heading {

	/**
	 * Register the Heading section under the Layout tab.
	 */
	protected function register_heading_layout_section() {
		$this->start_controls_section(
			'section_heading',
			array(
				'label' => __( 'Heading', 'zymarg-wcpg' ),
			)
		);

		$this->add_control(
			'show_heading',
			array(
				'label'        => __( 'Show heading', 'zymarg-wcpg' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'zymarg-wcpg' ),
				'label_off'    => __( 'Hide', 'zymarg-wcpg' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'heading_text',
			array(
				'label'       => __( 'Heading text', 'zymarg-wcpg' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => __( 'Featured Products', 'zymarg-wcpg' ),
				'label_block' => true,
				'condition'   => array( 'show_heading' => 'yes' ),
			)
		);

		$this->add_control(
			'subheading_text',
			array(
				'label'       => __( 'Subheading text', 'zymarg-wcpg' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => '',
				'label_block' => true,
				'condition'   => array( 'show_heading' => 'yes' ),
			)
		);

		$this->add_control(
			'heading_tag',
			array(
				'label'     => __( 'Heading HTML tag', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'default'   => 'h2',
				'options'   => array(
					'h1'   => 'H1',
					'h2'   => 'H2',
					'h3'   => 'H3',
					'h4'   => 'H4',
					'h5'   => 'H5',
					'h6'   => 'H6',
					'div'  => 'div',
					'span' => 'span',
				),
				'condition' => array( 'show_heading' => 'yes' ),
			)
		);

		$this->add_responsive_control(
			'heading_alignment',
			array(
				'label'     => __( 'Alignment', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::CHOOSE,
				'options'   => array(
					'left'   => array(
						'title' => __( 'Left', 'zymarg-wcpg' ),
						'icon'  => 'eicon-text-align-left',
					),
					'center' => array(
						'title' => __( 'Center', 'zymarg-wcpg' ),
						'icon'  => 'eicon-text-align-center',
					),
					'right'  => array(
						'title' => __( 'Right', 'zymarg-wcpg' ),
						'icon'  => 'eicon-text-align-right',
					),
				),
				'default'   => 'left',
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__heading' => 'text-align: {{VALUE}};',
				),
				'condition' => array( 'show_heading' => 'yes' ),
			)
		);

		$this->add_control(
			'show_view_all',
			array(
				'label'        => __( 'Show "View All" link', 'zymarg-wcpg' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => '',
				'condition'    => array( 'show_heading' => 'yes' ),
			)
		);

		$this->add_control(
			'view_all_text',
			array(
				'label'     => __( 'View All text', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::TEXT,
				'default'   => __( 'View All', 'zymarg-wcpg' ),
				'condition' => array(
					'show_heading'  => 'yes',
					'show_view_all' => 'yes',
				),
			)
		);

		$this->add_control(
			'view_all_auto_vendor',
			array(
				'label'        => __( 'Auto-link to vendor store', 'zymarg-wcpg' ),
				'description'  => __( 'When on, the View All button automatically links to the resolved vendor\'s Dokan storefront. Falls back to the manual URL below when no vendor can be resolved (e.g. on non-product pages). Only applies when Source = More From Seller (Dokan).', 'zymarg-wcpg' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Auto', 'zymarg-wcpg' ),
				'label_off'    => __( 'Manual', 'zymarg-wcpg' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => array(
					'show_heading'  => 'yes',
					'show_view_all' => 'yes',
					'source'        => 'vendor',
				),
			)
		);

		$this->add_control(
			'view_all_auto_vendor_notice',
			array(
				'type'      => \Elementor\Controls_Manager::RAW_HTML,
				'raw'       => '<div class="elementor-panel-alert elementor-panel-alert-info">'
					. esc_html__( 'The View All button now links to the same vendor that this widget resolves. Target / nofollow settings below still apply.', 'zymarg-wcpg' )
					. '</div>',
				'condition' => array(
					'show_heading'         => 'yes',
					'show_view_all'        => 'yes',
					'source'               => 'vendor',
					'view_all_auto_vendor' => 'yes',
				),
			)
		);

		$this->add_control(
			'view_all_url',
			array(
				'label'       => __( 'View All URL', 'zymarg-wcpg' ),
				'type'        => \Elementor\Controls_Manager::URL,
				'placeholder' => 'https://example.com/shop',
				'default'     => array(
					'url'         => '',
					'is_external' => false,
					'nofollow'    => false,
				),
				'conditions'  => array(
					'relation' => 'and',
					'terms'    => array(
						array(
							'name'     => 'show_heading',
							'operator' => '==',
							'value'    => 'yes',
						),
						array(
							'name'     => 'show_view_all',
							'operator' => '==',
							'value'    => 'yes',
						),
						array(
							'relation' => 'or',
							'terms'    => array(
								array(
									'name'     => 'source',
									'operator' => '!==',
									'value'    => 'vendor',
								),
								array(
									'name'     => 'view_all_auto_vendor',
									'operator' => '!==',
									'value'    => 'yes',
								),
							),
						),
					),
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Register the Heading section under the Style tab.
	 */
	protected function register_heading_style_section() {
		$this->start_controls_section(
			'section_heading_style',
			array(
				'label'     => __( 'Heading', 'zymarg-wcpg' ),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => array( 'show_heading' => 'yes' ),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'heading_typography',
				'selector' => '{{WRAPPER}} .zymarg-wcpg__heading-title',
			)
		);

		$this->add_control(
			'heading_color',
			array(
				'label'     => __( 'Heading color', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__heading-title' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'subheading_typography',
				'selector' => '{{WRAPPER}} .zymarg-wcpg__heading-subtitle',
			)
		);

		$this->add_control(
			'subheading_color',
			array(
				'label'     => __( 'Subheading color', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__heading-subtitle' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'      => 'view_all_typography',
				'selector'  => '{{WRAPPER}} .zymarg-wcpg__heading-link',
				'condition' => array( 'show_view_all' => 'yes' ),
			)
		);

		$this->add_control(
			'view_all_color',
			array(
				'label'     => __( 'View All color', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__heading-link' => 'color: {{VALUE}};',
				),
				'condition' => array( 'show_view_all' => 'yes' ),
			)
		);

		$this->add_responsive_control(
			'heading_spacing',
			array(
				'label'      => __( 'Spacing below heading', 'zymarg-wcpg' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 100,
					),
				),
				'default'    => array(
					'size' => 24,
					'unit' => 'px',
				),
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg__heading' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}
}
