<?php
/**
 * ZYMARG WC Wishlist Button — Elementor widget.
 *
 * A header-friendly, fully customizable wishlist button. Drop it into an
 * Elementor header, the customer clicks it, and they land on the My Account
 * → Wishlist tab (which renders the wishlist via the
 * [zymarg_wcpg_wishlist] shortcode shipped in 1.4.6).
 *
 * Customisable: any icon (Elementor's full icon library + custom SVG upload),
 * optional label, live count badge, separate styles for normal/hover and for
 * empty/with-items, hide-when-empty, custom target URL, open in new tab.
 *
 * Live count updates: the widget listens for the
 * `zymarg_wcpg:wishlist:changed` jQuery event broadcast by frontend.js
 * whenever a heart toggle is performed, so the badge stays in sync without
 * a page refresh.
 *
 * @package Zymarg\WCPG
 * @since   1.5.0
 */

namespace Zymarg\WCPG\Elementor;

defined( 'ABSPATH' ) || exit;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Zymarg\WCPG\Assets;
use Zymarg\WCPG\Wishlist\Wishlist_Store;

/**
 * Class Widget_Wishlist_Button
 */
class Widget_Wishlist_Button extends \Elementor\Widget_Base {

	/**
	 * Widget machine name.
	 */
	public function get_name() {
		return 'zymarg_wishlist_button';
	}

	/**
	 * Widget display name.
	 */
	public function get_title() {
		return __( 'ZYMARG Wishlist Button', 'zymarg-wcpg' );
	}

	/**
	 * Panel icon.
	 */
	public function get_icon() {
		return 'eicon-heart-o';
	}

	/**
	 * Categories.
	 */
	public function get_categories() {
		return array( ElementorLoader::CATEGORY_SLUG );
	}

	/**
	 * Search keywords.
	 */
	public function get_keywords() {
		return array( 'wishlist', 'heart', 'favourite', 'favorite', 'header', 'button', 'icon', 'zymarg' );
	}

	/**
	 * Style handle deps.
	 */
	public function get_style_depends() {
		return array( Assets::HANDLE_FRONTEND, Assets::HANDLE_WISHLIST_BUTTON );
	}

	/**
	 * Script handle deps.
	 */
	public function get_script_depends() {
		return array( Assets::HANDLE_FRONTEND, Assets::HANDLE_WISHLIST_BUTTON );
	}

	/**
	 * Widget controls.
	 */
	protected function register_controls() {
		$this->register_content_controls();
		$this->register_style_controls_container();
		$this->register_style_controls_icon();
		$this->register_style_controls_label();
		$this->register_style_controls_badge();
	}

	/* ====================================================================== *
	 * CONTENT TAB
	 * ====================================================================== */

	private function register_content_controls() {

		/* ----- Button ------------------------------------------------- */
		$this->start_controls_section(
			'section_button',
			array(
				'label' => __( 'Button', 'zymarg-wcpg' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'icon',
			array(
				'label'            => __( 'Icon', 'zymarg-wcpg' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon_fa4',
				'default'          => array(
					'value'   => 'fas fa-heart',
					'library' => 'fa-solid',
				),
				'recommended'      => array(
					'fa-solid'   => array( 'heart', 'star', 'bookmark', 'gift', 'bag-shopping' ),
					'fa-regular' => array( 'heart', 'star', 'bookmark' ),
				),
			)
		);

		$this->add_responsive_control(
			'layout',
			array(
				'label'          => __( 'Layout', 'zymarg-wcpg' ),
				'type'           => Controls_Manager::SELECT,
				'default'        => 'icon',
				'tablet_default' => 'icon',
				'mobile_default' => 'icon',
				'options'        => array(
					'icon'       => __( 'Icon only', 'zymarg-wcpg' ),
					'icon-label' => __( 'Icon + Label', 'zymarg-wcpg' ),
					'label-icon' => __( 'Label + Icon', 'zymarg-wcpg' ),
					'label'      => __( 'Label only', 'zymarg-wcpg' ),
				),
				'description'    => __( 'Set a different layout for each device. On mobile, "Icon only" saves space.', 'zymarg-wcpg' ),
			)
		);

		$this->add_control(
			'label_text',
			array(
				'label'       => __( 'Label', 'zymarg-wcpg' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Wishlist', 'zymarg-wcpg' ),
				'description' => __( 'Used when any device layout includes a label.', 'zymarg-wcpg' ),
				'dynamic'     => array( 'active' => true ),
			)
		);

		$this->end_controls_section();

		/* ----- Count badge -------------------------------------------- */
		$this->start_controls_section(
			'section_badge',
			array(
				'label' => __( 'Count badge', 'zymarg-wcpg' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'show_badge',
			array(
				'label'        => __( 'Show count badge', 'zymarg-wcpg' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'label_on'     => __( 'Show', 'zymarg-wcpg' ),
				'label_off'    => __( 'Hide', 'zymarg-wcpg' ),
				'return_value' => 'yes',
			)
		);

		$this->add_control(
			'hide_badge_when_empty',
			array(
				'label'        => __( 'Hide badge when wishlist is empty', 'zymarg-wcpg' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'label_on'     => __( 'Yes', 'zymarg-wcpg' ),
				'label_off'    => __( 'No', 'zymarg-wcpg' ),
				'return_value' => 'yes',
				'condition'    => array( 'show_badge' => 'yes' ),
			)
		);

		$this->add_control(
			'badge_position',
			array(
				'label'     => __( 'Badge position', 'zymarg-wcpg' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'top-right',
				'options'   => array(
					'top-right'    => __( 'Top right', 'zymarg-wcpg' ),
					'top-left'     => __( 'Top left', 'zymarg-wcpg' ),
					'bottom-right' => __( 'Bottom right', 'zymarg-wcpg' ),
					'bottom-left'  => __( 'Bottom left', 'zymarg-wcpg' ),
					'inline-after' => __( 'Inline (after)', 'zymarg-wcpg' ),
				),
				'condition' => array( 'show_badge' => 'yes' ),
			)
		);

		$this->end_controls_section();

		/* ----- Link --------------------------------------------------- */
		$this->start_controls_section(
			'section_link',
			array(
				'label' => __( 'Link', 'zymarg-wcpg' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'link_note',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => __( 'Leave the URL empty to auto-detect the My Account → Wishlist tab.', 'zymarg-wcpg' ),
				'content_classes' => 'elementor-descriptor',
			)
		);

		$this->add_control(
			'custom_url',
			array(
				'label'         => __( 'Custom URL', 'zymarg-wcpg' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-site.com/my-account/wishlist/', 'zymarg-wcpg' ),
				'show_external' => true,
				'default'       => array(
					'url'         => '',
					'is_external' => false,
					'nofollow'    => false,
				),
				'dynamic'       => array( 'active' => true ),
			)
		);

		$this->end_controls_section();

		/* ----- Visibility --------------------------------------------- */
		$this->start_controls_section(
			'section_visibility',
			array(
				'label' => __( 'Visibility', 'zymarg-wcpg' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'hide_when_empty',
			array(
				'label'        => __( 'Hide widget when wishlist is empty', 'zymarg-wcpg' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => '',
				'label_on'     => __( 'Yes', 'zymarg-wcpg' ),
				'label_off'    => __( 'No', 'zymarg-wcpg' ),
				'return_value' => 'yes',
			)
		);

		$this->add_control(
			'hide_for_guests',
			array(
				'label'        => __( 'Hide for guest (logged-out) visitors', 'zymarg-wcpg' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => '',
				'label_on'     => __( 'Yes', 'zymarg-wcpg' ),
				'label_off'    => __( 'No', 'zymarg-wcpg' ),
				'return_value' => 'yes',
			)
		);

		$this->end_controls_section();
	}

	/* ====================================================================== *
	 * STYLE TAB — Container
	 * ====================================================================== */

	private function register_style_controls_container() {
		$this->start_controls_section(
			'section_style_container',
			array(
				'label' => __( 'Container', 'zymarg-wcpg' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->start_controls_tabs( 'tabs_container' );

		$this->start_controls_tab( 'tab_container_normal', array( 'label' => __( 'Normal', 'zymarg-wcpg' ) ) );

		$this->add_control(
			'container_bg',
			array(
				'label'     => __( 'Background', 'zymarg-wcpg' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg-wlb__btn' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab( 'tab_container_hover', array( 'label' => __( 'Hover', 'zymarg-wcpg' ) ) );

		$this->add_control(
			'container_bg_hover',
			array(
				'label'     => __( 'Background', 'zymarg-wcpg' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg-wlb__btn:hover' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_responsive_control(
			'container_padding',
			array(
				'label'      => __( 'Padding', 'zymarg-wcpg' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', 'rem' ),
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg-wlb__btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => 'container_border',
				'selector' => '{{WRAPPER}} .zymarg-wcpg-wlb__btn',
			)
		);

		$this->add_control(
			'container_radius',
			array(
				'label'      => __( 'Border radius', 'zymarg-wcpg' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg-wlb__btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'container_shadow',
				'selector' => '{{WRAPPER}} .zymarg-wcpg-wlb__btn',
			)
		);

		$this->add_control(
			'transition',
			array(
				'label'      => __( 'Transition duration (ms)', 'zymarg-wcpg' ),
				'type'       => Controls_Manager::NUMBER,
				'min'        => 0,
				'max'        => 2000,
				'step'       => 10,
				'default'    => 200,
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg-wlb__btn, {{WRAPPER}} .zymarg-wcpg-wlb__icon' => 'transition-duration: {{VALUE}}ms;',
				),
			)
		);

		$this->end_controls_section();
	}

	/* ====================================================================== *
	 * STYLE TAB — Icon
	 * ====================================================================== */

	private function register_style_controls_icon() {
		$this->start_controls_section(
			'section_style_icon',
			array(
				'label' => __( 'Icon', 'zymarg-wcpg' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'icon_size',
			array(
				'label'      => __( 'Size', 'zymarg-wcpg' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', 'em' ),
				'range'      => array(
					'px' => array( 'min' => 8, 'max' => 100 ),
					'em' => array( 'min' => 0.5, 'max' => 6, 'step' => 0.1 ),
				),
				'default'    => array( 'unit' => 'px', 'size' => 22 ),
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg-wlb__icon' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .zymarg-wcpg-wlb__icon svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->start_controls_tabs( 'tabs_icon' );

		$this->start_controls_tab( 'tab_icon_normal', array( 'label' => __( 'Normal', 'zymarg-wcpg' ) ) );

		$this->add_control(
			'icon_color',
			array(
				'label'     => __( 'Color', 'zymarg-wcpg' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#131b2e',
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg-wlb__icon, {{WRAPPER}} .zymarg-wcpg-wlb__icon svg' => 'color: {{VALUE}}; fill: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab( 'tab_icon_hover', array( 'label' => __( 'Hover', 'zymarg-wcpg' ) ) );

		$this->add_control(
			'icon_color_hover',
			array(
				'label'     => __( 'Color', 'zymarg-wcpg' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#9500a5',
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg-wlb__btn:hover .zymarg-wcpg-wlb__icon, {{WRAPPER}} .zymarg-wcpg-wlb__btn:hover .zymarg-wcpg-wlb__icon svg' => 'color: {{VALUE}}; fill: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'icon_gap',
			array(
				'label'      => __( 'Gap (icon ↔ label)', 'zymarg-wcpg' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 0, 'max' => 40 ) ),
				'default'    => array( 'unit' => 'px', 'size' => 8 ),
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg-wlb__btn' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/* ====================================================================== *
	 * STYLE TAB — Label
	 * ====================================================================== */

	private function register_style_controls_label() {
		$this->start_controls_section(
			'section_style_label',
			array(
				'label' => __( 'Label', 'zymarg-wcpg' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'label_typography',
				'selector' => '{{WRAPPER}} .zymarg-wcpg-wlb__label',
			)
		);

		$this->start_controls_tabs( 'tabs_label' );

		$this->start_controls_tab( 'tab_label_normal', array( 'label' => __( 'Normal', 'zymarg-wcpg' ) ) );

		$this->add_control(
			'label_color',
			array(
				'label'     => __( 'Color', 'zymarg-wcpg' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#131b2e',
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg-wlb__label' => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab( 'tab_label_hover', array( 'label' => __( 'Hover', 'zymarg-wcpg' ) ) );

		$this->add_control(
			'label_color_hover',
			array(
				'label'     => __( 'Color', 'zymarg-wcpg' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#9500a5',
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg-wlb__btn:hover .zymarg-wcpg-wlb__label' => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/* ====================================================================== *
	 * STYLE TAB — Count badge
	 * ====================================================================== */

	private function register_style_controls_badge() {
		$this->start_controls_section(
			'section_style_badge',
			array(
				'label'     => __( 'Count badge', 'zymarg-wcpg' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array( 'show_badge' => 'yes' ),
			)
		);

		$this->add_responsive_control(
			'badge_offset_x',
			array(
				'label'      => __( 'Horizontal offset', 'zymarg-wcpg' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => -50, 'max' => 50 ) ),
				'default'    => array( 'unit' => 'px', 'size' => 0 ),
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg-wlb__badge--corner' => '--zwlb-offset-x: {{SIZE}}{{UNIT}};',
				),
				'condition'  => array( 'badge_position!' => 'inline-after' ),
			)
		);

		$this->add_responsive_control(
			'badge_offset_y',
			array(
				'label'      => __( 'Vertical offset', 'zymarg-wcpg' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => -50, 'max' => 50 ) ),
				'default'    => array( 'unit' => 'px', 'size' => 0 ),
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg-wlb__badge--corner' => '--zwlb-offset-y: {{SIZE}}{{UNIT}};',
				),
				'condition'  => array( 'badge_position!' => 'inline-after' ),
			)
		);

		$this->add_control(
			'badge_min_size',
			array(
				'label'      => __( 'Min size', 'zymarg-wcpg' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 12, 'max' => 40 ) ),
				'default'    => array( 'unit' => 'px', 'size' => 18 ),
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg-wlb__badge' => 'min-width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'badge_radius',
			array(
				'label'      => __( 'Border radius', 'zymarg-wcpg' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'default'    => array( 'top' => '999', 'right' => '999', 'bottom' => '999', 'left' => '999', 'unit' => 'px', 'isLinked' => true ),
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg-wlb__badge' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'badge_padding',
			array(
				'label'      => __( 'Padding', 'zymarg-wcpg' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px' ),
				'default'    => array( 'top' => '0', 'right' => '6', 'bottom' => '0', 'left' => '6', 'unit' => 'px', 'isLinked' => false ),
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg-wlb__badge' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'badge_typography',
				'selector' => '{{WRAPPER}} .zymarg-wcpg-wlb__badge',
			)
		);

		$this->add_control(
			'badge_bg',
			array(
				'label'     => __( 'Background (with items)', 'zymarg-wcpg' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#9500a5',
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg-wlb__badge' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'badge_color',
			array(
				'label'     => __( 'Text color', 'zymarg-wcpg' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg-wlb__badge' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => 'badge_border',
				'selector' => '{{WRAPPER}} .zymarg-wcpg-wlb__badge',
			)
		);

		$this->add_control(
			'badge_animate',
			array(
				'label'        => __( 'Pulse animation on count change', 'zymarg-wcpg' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'label_on'     => __( 'On', 'zymarg-wcpg' ),
				'label_off'    => __( 'Off', 'zymarg-wcpg' ),
				'return_value' => 'yes',
			)
		);

		$this->end_controls_section();
	}

	/* ====================================================================== *
	 * RENDER
	 * ====================================================================== */

	/**
	 * Resolve the link URL. Empty custom URL → auto-detect My Account → Wishlist.
	 *
	 * @param array $settings Widget settings.
	 * @return string
	 */
	private function resolve_url( array $settings ) {
		$custom = isset( $settings['custom_url']['url'] ) ? (string) $settings['custom_url']['url'] : '';
		if ( '' !== trim( $custom ) ) {
			return esc_url( $custom );
		}

		if ( function_exists( 'wc_get_account_endpoint_url' ) ) {
			$url = wc_get_account_endpoint_url( 'wishlist' );
			if ( $url ) {
				return esc_url( $url );
			}
			$url = wc_get_page_permalink( 'myaccount' );
			if ( $url ) {
				return esc_url( trailingslashit( $url ) . 'wishlist/' );
			}
		}

		return esc_url( home_url( '/my-account/wishlist/' ) );
	}

	/**
	 * Current visitor's wishlist count. 0 when WC / Wishlist_Store missing.
	 *
	 * @return int
	 */
	private function current_count() {
		if ( ! class_exists( '\Zymarg\WCPG\Wishlist\Wishlist_Store' ) ) {
			return 0;
		}
		$ids = Wishlist_Store::get_ids();
		return is_array( $ids ) ? count( $ids ) : 0;
	}

	/**
	 * Render the widget.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		// Visibility guards.
		if ( 'yes' === ( $settings['hide_for_guests'] ?? '' ) && ! is_user_logged_in() ) {
			return;
		}

		$count = $this->current_count();

		if ( 'yes' === ( $settings['hide_when_empty'] ?? '' ) && 0 === $count ) {
			return;
		}

		// v1.5.20: layout is now responsive — resolve per-device values.
		$layout_d = isset( $settings['layout'] ) && '' !== $settings['layout'] ? $settings['layout'] : 'icon';
		$layout_t = isset( $settings['layout_tablet'] ) && '' !== $settings['layout_tablet'] ? $settings['layout_tablet'] : $layout_d;
		$layout_m = isset( $settings['layout_mobile'] ) && '' !== $settings['layout_mobile'] ? $settings['layout_mobile'] : $layout_t;
		// Use desktop layout for the base render; CSS classes handle per-device visibility.
		$layout   = $layout_d;
		$show_badge     = 'yes' === ( $settings['show_badge'] ?? '' );
		$hide_badge_0   = 'yes' === ( $settings['hide_badge_when_empty'] ?? '' );
		$badge_position = isset( $settings['badge_position'] ) ? $settings['badge_position'] : 'top-right';
		$badge_animate  = 'yes' === ( $settings['badge_animate'] ?? '' );

		$url      = $this->resolve_url( $settings );
		$external = ! empty( $settings['custom_url']['is_external'] );
		$nofollow = ! empty( $settings['custom_url']['nofollow'] );
		$label    = isset( $settings['label_text'] ) ? $settings['label_text'] : '';

		$wrap_classes = array(
			'zymarg-wcpg-wlb',
			// Desktop layout (base).
			'zymarg-wcpg-wlb--layout-' . sanitize_html_class( $layout_d ),
			// Tablet layout class (used by CSS @media).
			'zymarg-wcpg-wlb--layout-tablet-' . sanitize_html_class( $layout_t ),
			// Mobile layout class (used by CSS @media).
			'zymarg-wcpg-wlb--layout-mobile-' . sanitize_html_class( $layout_m ),
			'zymarg-wcpg-wlb--badge-' . sanitize_html_class( $badge_position ),
		);
		if ( $badge_animate ) {
			$wrap_classes[] = 'zymarg-wcpg-wlb--animate';
		}
		if ( 0 === $count ) {
			$wrap_classes[] = 'zymarg-wcpg-wlb--empty';
		}

		$rel        = $external ? 'noopener' . ( $nofollow ? ' nofollow' : '' ) : ( $nofollow ? 'nofollow' : '' );
		$target_att = $external ? ' target="_blank"' : '';
		$rel_att    = $rel ? ' rel="' . esc_attr( trim( $rel ) ) . '"' : '';

		/* ---- Build inner parts ---- */
		ob_start();
		\Elementor\Icons_Manager::render_icon( $settings['icon'], array( 'aria-hidden' => 'true' ) );
		$icon_inner_html = ob_get_clean();
		// v1.5.20: badge is built here and injected INSIDE the icon span
		// so it always positions relative to the icon, regardless of layout.
		// Corner badge goes inside icon span; inline badge stays after all parts.
		$icon_html = '<span class="zymarg-wcpg-wlb__icon">' . $icon_inner_html . '</span>';

		$label_html = '';
		if ( 'icon' !== $layout && '' !== $label ) {
			$label_html = '<span class="zymarg-wcpg-wlb__label">' . esc_html( $label ) . '</span>';
		}

		$badge_html = '';
		if ( $show_badge ) {
			$badge_classes = array( 'zymarg-wcpg-wlb__badge' );
			if ( 'inline-after' === $badge_position ) {
				$badge_classes[] = 'zymarg-wcpg-wlb__badge--inline';
			} else {
				$badge_classes[] = 'zymarg-wcpg-wlb__badge--corner';
			}
			$badge_html_inner = '<span class="' . esc_attr( implode( ' ', $badge_classes ) ) . '" data-zymarg-wcpg-wishlist-count'
				. ( $hide_badge_0 ? ' data-hide-when-zero="1"' : '' )
				. '>' . (int) $count . '</span>';

			$badge_html = $badge_html_inner;
		}

		// v1.5.20: corner badge anchors to the icon span (position:relative),
		// not the whole button container. Inject it inside the icon span.
		if ( $show_badge && 'inline-after' !== $badge_position ) {
			// Inject corner badge inside the icon span.
			$icon_html = '<span class="zymarg-wcpg-wlb__icon zymarg-wcpg-wlb__icon--has-badge">'
				. $icon_inner_html
				. $badge_html
				. '</span>';
			$badge_html = ''; // already placed inside icon span
		}
		$corner_badge_html = ''; // no longer used at button level

		// v1.5.20: always render both icon and label in the DOM.
		// CSS classes on the wrapper control visibility per device.
		// Label is always wrapped in its span; CSS hides it when layout is icon-only.
		// Order follows desktop layout; label-icon reverses via CSS flex-direction.
		$label_html_full = '<span class="zymarg-wcpg-wlb__label">' . esc_html( $label ) . '</span>';
		if ( 'label-icon' === $layout_d ) {
			$inner_parts = array( $label_html_full, $icon_html );
		} else {
			$inner_parts = array( $icon_html, $label_html_full );
		}

		?>
		<div class="<?php echo esc_attr( implode( ' ', $wrap_classes ) ); ?>"
			data-zymarg-wcpg-wlb
			data-empty="<?php echo (int) ( 0 === $count ); ?>">
			<a class="zymarg-wcpg-wlb__btn" href="<?php echo esc_url( $url ); ?>"<?php echo $target_att . $rel_att; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				aria-label="<?php echo esc_attr( '' !== $label ? $label : __( 'Wishlist', 'zymarg-wcpg' ) ); ?>">
				<?php echo implode( '', $inner_parts ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<?php echo $badge_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- inline badge only; corner badge is inside icon span ?>
			</a>
		</div>
		<?php
	}
}
