<?php
/**
 * Config Defaults — single source of truth for framework-level defaults.
 *
 * Every render call that does not explicitly specify a value inherits from
 * here. Templates override only what makes them unique. Caller overrides
 * take final priority.
 *
 * Merge order (lowest → highest priority):
 *   1. Config_Defaults::get()          (framework defaults)
 *   2. Template config                 (template overrides)
 *   3. Caller overrides                (per-call overrides)
 *
 * Responsibilities (and only these):
 *   - Provide the complete default configuration tree.
 *   - Expose a filter so the defaults themselves are extensible.
 *
 * This class knows nothing about:
 *   - Rendering
 *   - Querying
 *   - Specific templates
 *
 * @package Zymarg\WCPG\Render
 * @since   1.6.0
 */

namespace Zymarg\WCPG\Render;

defined( 'ABSPATH' ) || exit;

/**
 * Class Config_Defaults
 */
final class Config_Defaults {

	/**
	 * Return the complete framework default configuration.
	 *
	 * Callers receive a filtered copy — the internal array is never mutated.
	 *
	 * Canonical sections (locked — v1.6.4):
	 *   query, layout, card, heading, pagination, responsive
	 *
	 * @return array{
	 *   query: array,
	 *   layout: array,
	 *   card: array,
	 *   heading: array,
	 *   pagination: array,
	 *   responsive: array,
	 * }
	 */
	public static function get(): array {
		$defaults = [

			// -----------------------------------------------------------------
			// Query defaults
			// Source classes (Source_All, Source_Trending, etc.) may apply
			// their own additional defaults when they execute, but these values
			// are what the Query_Adapter uses when no override is provided.
			// -----------------------------------------------------------------
			'query' => [
				'source'   => 'all',
				'limit'    => 8,
				'orderby'  => 'date',
				'order'    => 'DESC',
				'show_oos' => false, // exclude out-of-stock by default

				// Flash Deals source (v2.8.0). Ignored by every other source.
				// 'auto' = site-wide, but auto-scopes to the vendor on a Dokan
				// store page. 'site' = always site-wide. 'vendor' = vendor only,
				// hiding the widget when no vendor can be resolved.
				'flash_vendor_scope' => 'auto',
				'flash_min_discount' => 0,       // 0 = no minimum discount filter
				'flash_orderby'      => 'sale_end', // ending soonest first
			],

			// -----------------------------------------------------------------
			// Layout defaults
			// Pagination concerns moved to the 'pagination' section (v1.6.4).
			// -----------------------------------------------------------------
			'layout' => [
				'type'    => 'grid',  // 'grid' | 'slider'
				'columns' => 4,
				'gap'     => 6,       // px

				// Slider sub-config. Flattened by Render_Engine::config_to_settings()
				// into the flat slider_* keys the slider template reads. Global
				// defaults are visually unchanged: arrows on, chip pagination,
				// no autoplay. Templates/consumers override only what differs.
				'slider' => [
					'show_arrows'     => true,
					'pagination_type' => 'chip', // v2.17.5: 'chip' | '' (off) -- 'bullets'/'fraction'/'progress' removed
					'loop'            => true,
					'autoplay'        => false,
					'autoplay_delay'  => 4000,
					'speed'           => 500,
					'space_between'   => null, // v2.4.4: null = inherit layout.gap so slider spacing matches the grid gap unless overridden.
					'free_scroll'     => true,  // v2.5.0: smooth momentum scroll (both templates). Loop auto-off in free mode.
					'mousewheel'      => true,  // v2.5.0: horizontal wheel/trackpad scroll.
					'marquee'         => false, // v2.15.0: continuous drift. Requires loop; forces free_scroll off.
					'marquee_speed'   => 4000,  // v2.15.0: ms per slide advance while drifting.
				],
			],

			// -----------------------------------------------------------------
			// Card defaults
			// These mirror the existing $settings keys used by the card
			// template so the Render Engine can pass them through unchanged.
			// Only override in a template when the template intentionally
			// differs from the marketplace-wide default.
			// -----------------------------------------------------------------
			'card' => [
				// Card template slug. Resolved by Template_Manager::is_registered_card()
				// inside Config_Normalizer — falls back to 'classic' if the slug is
				// unknown. Set this via Public_API config or standalone plugin.
				'template'           => 'classic',

				'style'              => 'default',

				// Flash Deals countdown (v2.9.0).
				// 'auto' = on for the flash_deals source, off everywhere else.
				// 'yes' / 'no' force it regardless of source. The countdown
				// self-suppresses on any product without a future sale end date,
				// so switching it on globally is harmless.
				'show_countdown'     => 'auto',
				'countdown_position' => 'below_price', // 'below_price' | 'over_image' | 'before_title'

				// Visibility
				'show_image'         => true,
				'show_title'         => true,
				'show_price'         => true,
				'show_rating'        => true,
				'show_sold_count'    => false,
				'show_vendor'        => false,
				'show_atc'           => true,
				'show_wishlist'      => true,
				'show_quickview'     => true,
				'show_discount_badge' => true,
				'show_stock_badge'   => true,

				// Positioning
				'price_position'     => 'below_rating',  // 'above_title' | 'above_rating' | 'below_rating'
				'vendor_position'    => 'below_price',   // 'above_title' | 'below_meta' | 'below_price'
				'atc_position'       => 'with_price',    // 'standalone' | 'with_meta' | 'with_price' | 'with_vendor'

				// Typography / display
				'title_lines'        => 2,
				'sold_count_format'  => 'short',         // 'short' | 'full'
				'show_sold_text'     => true,
				'discount_badge_mode' => 'percentage',   // 'percentage' | 'amount'

				// Image
				'image_full_resolution' => false,
				'image_hover_zoom'      => true,

				// Stock display
				'show_stock_in'      => false,
				'show_stock_out'     => true,

				// Meta layout (matches Elementor control key)
				'meta_layout'        => 'stacked',       // 'stacked' | 'inline'
			],

			// -----------------------------------------------------------------
			// Heading defaults
			// Default is OFF — the engine is neutral. Consumers (templates,
			// page plugins, shortcodes) opt in when they need a heading.
			// Heading is NOT part of the responsive schema; use CSS to
			// control heading visibility across breakpoints.
			// -----------------------------------------------------------------
			'heading' => [
				'show'                 => false,
				'text'                 => '',
				'subtext'              => '',
				'tag'                  => 'h2',       // h1–h6
				'alignment'            => 'left',     // 'left' | 'center' | 'right'
				'show_view_all'        => false,
				'view_all_text'        => '',
				'view_all_url'         => '',
				'view_all_auto_vendor' => false,
				'view_all_vendor_product_id' => 0, // explicit product id for auto-vendor "View All"; 0 = auto-detect current product
			],

			// -----------------------------------------------------------------
			// Pagination defaults
			// Moved out of 'layout' (v1.6.4) — pagination is its own concern.
			// Pagination is NOT responsive — register a separate template for
			// different pagination behaviour across breakpoints.
			// -----------------------------------------------------------------
			'pagination' => [
				'mode'           => 'none',  // 'none' | 'load_more' | 'infinite'
				'load_more_text' => '',      // empty = use translated default

				// v2.6.0: Infinite scroll batch sizes and auto-load caps.
				// These are stored as flat siblings (not via the responsive
				// pipeline, which excludes pagination by design) and are
				// resolved in the BROWSER from viewport width. Resolving them
				// in PHP would bake one device's numbers into cached HTML.
				// The cap counts auto-loaded products only, not the first page.
				'batch_size'          => 20,
				'batch_size_tablet'   => 20,
				'batch_size_mobile'   => 10,
				'max_products'        => 100,
				'max_products_tablet' => 100,
				'max_products_mobile' => 50,
			],

			// -----------------------------------------------------------------
			// Responsive defaults
			// Only 'layout' and 'card' participate in responsive inheritance.
			// heading and pagination are intentionally excluded.
			// -----------------------------------------------------------------
			'responsive' => [
				'tablet' => [
					'layout' => [],
					'card'   => [],
				],
				'mobile' => [
					'layout' => [],
					'card'   => [],
				],
			],
		];

		/**
		 * Filter the framework-level configuration defaults.
		 *
		 * Use this to change marketplace-wide defaults without touching
		 * individual templates.
		 *
		 * Example — change the default column count:
		 *   add_filter( 'zymarg_product_grid_defaults', function( $defaults ) {
		 *       $defaults['layout']['columns'] = 5;
		 *       return $defaults;
		 *   } );
		 *
		 * @since 1.6.0
		 * @param array $defaults The full default configuration tree.
		 */
		return (array) apply_filters( 'zymarg_product_grid_defaults', $defaults );
	}

	/**
	 * No public construction — static class only.
	 */
	private function __construct() {}
}
