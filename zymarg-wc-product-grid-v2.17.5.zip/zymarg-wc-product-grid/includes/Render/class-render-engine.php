<?php
/**
 * Render Engine — produces HTML from a normalized configuration and a
 * product collection.
 *
 * This is intentionally the simplest class in the framework. All complexity
 * has been pushed into the appropriate upstream layers:
 *   - Context_Resolver   resolved context.
 *   - Query_Adapter      translated queries.
 *   - Config_Normalizer  built a complete configuration.
 *   - Template_Loader    handles template lookup and theme overrides.
 *
 * This class only orchestrates the final render step.
 *
 * Responsibilities (and only these):
 *   - Build a render context array and delegate to Template_Manager.
 *   - Fire before/after lifecycle hooks.
 *   - Return the rendered HTML string.
 *
 * This class must not:
 *   - Resolve slots, templates, or configuration.
 *   - Build or execute queries.
 *   - Reorder, filter, or deduplicate products.
 *   - Fetch additional products.
 *   - Resolve context.
 *   - Know about Elementor.
 *   - Echo output directly (always returns a string).
 *   - Call wp_enqueue_style(), wp_enqueue_script(), or any asset handle
 *     directly — that is Asset_Manager's responsibility.
 *   - Know any template filenames or paths — that is Template_Manager's
 *     responsibility.
 *
 * @package Zymarg\WCPG\Render
 * @since   1.6.0 (updated 1.8.0 — Template_Manager integration; 2.0.2 — single filter call, debug overlay)
 */

namespace Zymarg\WCPG\Render;

use Zymarg\WCPG\Services\Asset_Manager;
use Zymarg\WCPG\Templates\Template_Manager;

defined( 'ABSPATH' ) || exit;

/**
 * Class Render_Engine
 */
final class Render_Engine {

	/**
	 * Render a product collection using a normalized configuration.
	 *
	 * The method is deterministic: given the same $config and $products it
	 * always returns the same HTML. This makes future output caching
	 * straightforward — cache keyed on config + product IDs.
	 *
	 * The optional $debug_meta parameter is populated by Public_API with
	 * cache status, consumer identity, and context type. It is used only
	 * when ZYMARG_DEBUG is true and the current user is an admin — it is
	 * ignored entirely in production. Render_Engine never reads cache state
	 * itself; Public_API passes it in so the layers stay clean.
	 *
	 * @param array        $config     Complete normalized config from Config_Normalizer.
	 * @param \WC_Product[] $products  Product collection from the Query Engine
	 *                                 (may be empty — empty state is handled by
	 *                                 the template, not here).
	 * @param string       $widget_id  Consumer-supplied widget/instance identifier.
	 * @param bool         $is_preview Whether this render is inside a page-builder preview.
	 * @param array        $debug_meta Optional debug metadata from Public_API:
	 *                                 cache_status, consumer, context_type, slot, template.
	 * @return string Rendered HTML. Never echoes directly.
	 */
	public static function render(
		array $config,
		array $products,
		string $widget_id = '',
		bool $is_preview = false,
		array $debug_meta = []
	): string {
		// Delegate all asset loading decisions to Asset_Manager.
		// Render_Engine never calls wp_enqueue_* directly — that is
		// Asset_Manager's sole responsibility (Milestone 5).
		Asset_Manager::enqueue_for_render( $config );

		// Resolve the layout path once via Template_Manager so the same
		// path is passed to hooks AND used by the renderer. Previously
		// render_layout() re-resolved independently, meaning the
		// zymarg_layout_template filter affected hooks but not the actual
		// file loaded — a contract violation fixed in v2.0.2.
		$template_file = Template_Manager::resolve_layout_path( $config );

		// Build a single render context passed to the template.
		// Extend this array (never its signature) when new data is needed.
		$render_context = [
			'config'     => $config,
			'products'   => $products,
			// Backward-compatible aliases so existing templates still work
			// when consumed through the new pipeline. The grid-wrapper and
			// slider-wrapper templates read $settings and $products today.
			'settings'   => self::config_to_settings( $config ),
			// widget_id and is_preview are consumer-supplied context.
			// Templates may use widget_id for unique DOM IDs (slider init,
			// AJAX targets). is_preview is available if templates ever need
			// to alter output in a page-builder preview context, but the
			// engine itself never branches on it — that is the caller's job.
			'widget_id'  => $widget_id,
			'is_preview' => $is_preview,
		];

		/**
		 * Fires immediately before the product grid is rendered.
		 *
		 * Use for analytics, cache-warm checks, or diagnostic output.
		 * Do not echo here — use the filter below to modify the final HTML.
		 *
		 * @since 1.6.0
		 * @param array         $config         Normalized configuration.
		 * @param \WC_Product[] $products        Product collection.
		 * @param string        $template_file   Layout wrapper path (relative to /templates/).
		 * @param array         $render_context  Full render context passed to template.
		 */
		do_action(
			'zymarg_product_grid_before_render',
			$config,
			$products,
			$template_file,
			$render_context
		);

		// Template_Manager is the single owner of all template file knowledge.
		// It resolves the layout type to the correct wrapper file and delegates
		// to Template_Loader for theme override support. Render_Engine never
		// references a filename or path directly (Milestone 6).
		//
		// Pass the already-resolved $template_file so the zymarg_layout_template
		// filter fires exactly once — hooks and renderer use the same path. (v2.0.2)
		$html = Template_Manager::render_layout( $config, $render_context, $template_file );

		/**
		 * Filter the rendered HTML before it is returned to the caller.
		 *
		 * Use for output caching write-through, A/B testing wrappers,
		 * or post-render transformations.
		 *
		 * @since 1.6.0
		 * @param string        $html           Rendered HTML string.
		 * @param array         $config         Normalized configuration.
		 * @param \WC_Product[] $products        Product collection.
		 * @param string        $template_file   Layout wrapper path used.
		 */
		$html = (string) apply_filters(
			'zymarg_product_grid_html',
			$html,
			$config,
			$products,
			$template_file
		);

		// Append debug overlay when ZYMARG_DEBUG is enabled.
		// Only admins ever see this — regular visitors are unaffected.
		if ( defined( 'ZYMARG_DEBUG' ) && ZYMARG_DEBUG && current_user_can( 'manage_options' ) ) {
			$html .= self::render_debug_overlay( $config, $products, $template_file, $debug_meta );
		}

		/**
		 * Fires immediately after the product grid HTML has been produced.
		 *
		 * Use for analytics events, cache population, or logging.
		 *
		 * @since 1.6.0
		 * @param string        $html     Final HTML string.
		 * @param array         $config   Normalized configuration.
		 * @param \WC_Product[] $products  Product collection.
		 */
		do_action( 'zymarg_product_grid_after_render', $html, $config, $products );

		return $html;
	}

	// -------------------------------------------------------------------------
	// Private helpers
	// -------------------------------------------------------------------------

	/**
	 * Flatten the normalized config into the legacy $settings shape that the
	 * existing grid-wrapper.php and slider-wrapper.php templates read.
	 *
	 * TEMPORARY COMPATIBILITY LAYER.
	 *
	 * This method exists only while legacy templates still consume the flat
	 * $settings array. Once every template has been migrated to consume
	 * $config directly, this method is removed entirely and the $config
	 * key is passed straight to the template instead of $settings.
	 *
	 * Do not add business logic here. Only add mappings:
	 *   canonical config key → legacy settings key.
	 *
	 * @param array $config Normalized configuration.
	 * @return array Legacy $settings array.
	 */
	private static function config_to_settings( array $config ): array {
		$settings = [];

		// Layout section.
		if ( isset( $config['layout'] ) && is_array( $config['layout'] ) ) {
			$layout_map = [
				'columns' => 'columns',
				'type'    => 'layout_type',
				'gap'     => 'gap',
			];
			foreach ( $layout_map as $config_key => $settings_key ) {
				if ( array_key_exists( $config_key, $config['layout'] ) ) {
					$settings[ $settings_key ] = $config['layout'][ $config_key ];
				}
			}

			// Slider sub-config -> flat slider_* keys the slider template reads.
			// Before v2.4.0 the entire layout.slider sub-array was dropped here,
			// so every slider control (arrows, pagination, autoplay, loop, speed,
			// spacing) was ignored and the template used its own hardcoded
			// defaults. Mapping them restores full config-driven slider control.
			if ( isset( $config['layout']['slider'] ) && is_array( $config['layout']['slider'] ) ) {
				$slider_map = [
					'show_arrows'     => 'slider_show_arrows',
					'pagination_type' => 'slider_pagination_type',
					'loop'            => 'slider_loop',
					'autoplay'        => 'slider_autoplay',
					'autoplay_delay'  => 'slider_autoplay_delay',
					'speed'           => 'slider_speed',
					'space_between'   => 'slider_space_between',
					'free_scroll'     => 'slider_free_scroll',
					'mousewheel'      => 'slider_mousewheel',
					'marquee'         => 'slider_marquee',
					'marquee_speed'   => 'slider_marquee_speed',
				];
				foreach ( $slider_map as $config_key => $settings_key ) {
					if ( array_key_exists( $config_key, $config['layout']['slider'] ) ) {
						$settings[ $settings_key ] = $config['layout']['slider'][ $config_key ];
					}
				}
			}
		}

		// Pagination section (moved from layout in v1.6.4).
		// Maps back to flat $settings keys that existing templates expect.
		if ( isset( $config['pagination'] ) && is_array( $config['pagination'] ) ) {
			$pagination_map = [
				'mode'           => 'pagination_mode',
				'load_more_text' => 'load_more_text',
				// v2.6.0: Infinite scroll batch sizes and auto-load caps.
				'batch_size'          => 'infinite_batch_size',
				'batch_size_tablet'   => 'infinite_batch_size_tablet',
				'batch_size_mobile'   => 'infinite_batch_size_mobile',
				'max_products'        => 'infinite_max_products',
				'max_products_tablet' => 'infinite_max_products_tablet',
				'max_products_mobile' => 'infinite_max_products_mobile',
			];
			foreach ( $pagination_map as $config_key => $settings_key ) {
				if ( array_key_exists( $config_key, $config['pagination'] ) ) {
					$settings[ $settings_key ] = $config['pagination'][ $config_key ];
				}
			}
		}

		// Heading section — maps to flat $settings keys existing templates expect.
		if ( isset( $config['heading'] ) && is_array( $config['heading'] ) ) {
			$heading_map = [
				'show'                 => 'show_heading',
				'text'                 => 'heading_text',
				'subtext'              => 'subheading_text',
				'tag'                  => 'heading_tag',
				'alignment'            => 'heading_alignment',
				'alignment_tablet'     => 'heading_alignment_tablet',
				'alignment_mobile'     => 'heading_alignment_mobile',
				'show_view_all'        => 'show_view_all',
				'view_all_text'        => 'view_all_text',
				'view_all_url'         => 'view_all_url',
				'view_all_auto_vendor' => 'view_all_auto_vendor',
			];
			foreach ( $heading_map as $config_key => $settings_key ) {
				if ( array_key_exists( $config_key, $config['heading'] ) ) {
					$settings[ $settings_key ] = $config['heading'][ $config_key ];
				}
			}
		}

		// Query section.
		if ( isset( $config['query'] ) && is_array( $config['query'] ) ) {
			$query_map = [
				'source'  => 'source',
				'limit'   => 'total_products',
				'orderby' => 'orderby',
				'order'   => 'order',
				'show_oos' => 'show_oos',
			];
			foreach ( $query_map as $config_key => $settings_key ) {
				if ( array_key_exists( $config_key, $config['query'] ) ) {
					$settings[ $settings_key ] = $config['query'][ $config_key ];
				}
			}
		}

		// Card section — keys are identical between config and settings.
		if ( isset( $config['card'] ) && is_array( $config['card'] ) ) {
			foreach ( $config['card'] as $key => $value ) {
				$settings[ $key ] = $value;
			}
		}

		// Responsive section — flatten per-device layout overrides into the
		// flat $settings keys that legacy templates and the slider wrapper read.
		// Only layout.columns is currently a responsive control; expand this
		// list as other responsive controls are introduced to the schema.
		if ( isset( $config['responsive']['tablet']['layout']['columns'] ) ) {
			$settings['columns_tablet'] = (int) $config['responsive']['tablet']['layout']['columns'];
		}
		if ( isset( $config['responsive']['mobile']['layout']['columns'] ) ) {
			$settings['columns_mobile'] = (int) $config['responsive']['mobile']['layout']['columns'];
		}

		// Responsive card keys — meta_layout and show_sold_text per device.
		// These are read by rating-soldcount.php using the _tablet/_mobile suffix pattern.
		if ( isset( $config['responsive']['tablet']['card']['meta_layout'] ) ) {
			$settings['meta_layout_tablet'] = (string) $config['responsive']['tablet']['card']['meta_layout'];
		}
		if ( isset( $config['responsive']['mobile']['card']['meta_layout'] ) ) {
			$settings['meta_layout_mobile'] = (string) $config['responsive']['mobile']['card']['meta_layout'];
		}
		if ( isset( $config['responsive']['tablet']['card']['show_sold_text'] ) ) {
			$settings['show_sold_text_tablet'] = $config['responsive']['tablet']['card']['show_sold_text'];
		}
		if ( isset( $config['responsive']['mobile']['card']['show_sold_text'] ) ) {
			$settings['show_sold_text_mobile'] = $config['responsive']['mobile']['card']['show_sold_text'];
		}

		return $settings;
	}

	/**
	 * Render the ZYMARG_DEBUG overlay appended under the product grid.
	 *
	 * Only called when ZYMARG_DEBUG is true and the current user is an admin.
	 * Never called in production. Outputs a compact bordered box showing
	 * exactly what the engine did for this render: source, template, product
	 * count, layout, cache status, consumer identity, and context type.
	 *
	 * The overlay is intentionally unstyled beyond a minimal bordered box so
	 * it never conflicts with theme CSS. No plugin stylesheet is required.
	 *
	 * @param array  $config        Normalized configuration.
	 * @param array  $products      Fetched product collection.
	 * @param string $template_file Resolved layout wrapper path.
	 * @param array  $debug_meta    Optional metadata from Public_API:
	 *                              cache_status, consumer, context_type, slot, template_slug.
	 * @return string Debug overlay HTML string.
	 */
	private static function render_debug_overlay(
		array $config,
		array $products,
		string $template_file,
		array $debug_meta = []
	): string {
		// ── Gather values ────────────────────────────────────────────────────

		$source        = esc_html( $config['query']['source'] ?? 'unknown' );
		$layout        = esc_html( $config['layout']['type'] ?? 'grid' );
		// Canonical location is card.template. Reading $config['template']
		// (as this did before v2.1.0) always yielded the 'classic' fallback,
		// so the one tool for diagnosing template problems misreported the
		// template actually in use.
		$card_template = esc_html( $config['card']['template'] ?? 'classic' );
		$columns       = esc_html( (string) ( $config['layout']['columns'] ?? '?' ) );
		$limit         = esc_html( (string) ( $config['query']['limit'] ?? '?' ) );
		$product_count = count( $products );

		$cache_status  = esc_html( $debug_meta['cache_status']  ?? 'unknown' );
		$consumer      = esc_html( $debug_meta['consumer']      ?? 'unknown' );
		$context_type  = esc_html( $debug_meta['context_type']  ?? 'unknown' );
		$slot          = esc_html( $debug_meta['slot']          ?? '—' );
		$template_slug = esc_html( $debug_meta['template_slug'] ?? '—' );
		$layout_file   = esc_html( $template_file );

		// Cache status pill colour.
		$cache_color = 'unknown' === $cache_status ? '#888' :
			( 'HIT' === $cache_status ? '#28a745' : '#ffc107' );

		// ── Build HTML ───────────────────────────────────────────────────────

		$rows = [
			[ 'Source',        $source ],
			[ 'Card Template', $card_template ],
			[ 'Layout',        "{$layout} · {$columns} cols · limit {$limit}" ],
			[ 'Products',      (string) $product_count ],
			[ 'Cache',         $cache_status ],
			[ 'Consumer',      $consumer ],
			[ 'Slot',          $slot ],
			[ 'Template Slug', $template_slug ],
			[ 'Context',       $context_type ],
			[ 'Layout File',   $layout_file ],
		];

		$rows_html = '';
		foreach ( $rows as [ $label, $value ] ) {
			$label_html = '<span style="color:#9500a5;font-weight:600;min-width:110px;display:inline-block;">'
				. esc_html( $label ) . '</span>';

			// Cache value gets a coloured pill.
			if ( 'Cache' === $label ) {
				$value_html = '<span style="background:' . $cache_color . ';color:#fff;'
					. 'padding:1px 8px;border-radius:10px;font-size:11px;font-weight:700;">'
					. esc_html( $value ) . '</span>';
			} else {
				$value_html = '<code style="background:#f0e6ff;padding:1px 5px;border-radius:3px;font-size:12px;">'
					. esc_html( $value ) . '</code>';
			}

			$rows_html .= '<div style="padding:3px 0;border-bottom:1px solid #f0e6ff;">'
				. $label_html . ' ' . $value_html
				. '</div>';
		}

		return '<div style="'
			. 'font-family:monospace;font-size:12px;line-height:1.6;'
			. 'border:2px solid #9500a5;border-radius:8px;'
			. 'padding:10px 14px;margin:8px 0 0;'
			. 'background:#faf8ff;color:#1a1a2e;'
			. 'box-shadow:0 2px 8px rgba(149,0,165,0.12);'
			. '">'
			. '<div style="font-weight:700;font-size:11px;letter-spacing:.08em;'
			. 'text-transform:uppercase;color:#9500a5;margin-bottom:6px;">'
			. '⬡ ZYMARG DEBUG</div>'
			. $rows_html
			. '</div>';
	}

	/**
	 * No public construction — static class only.
	 */
	private function __construct() {}
}
