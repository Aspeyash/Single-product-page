<?php
/**
 * Flash Deals countdown renderer.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Render;

use Zymarg\WCPG\Query\Source_Flash_Deals;

defined( 'ABSPATH' ) || exit;

/**
 * Class Countdown_Renderer
 *
 * Prints a live "ends in" countdown on product cards whose sale window carries
 * a real end date.
 *
 * Design notes
 * ------------
 * 1. Rendering happens through the shared card action hooks rather than by
 *    editing card templates. Every card that fires those hooks -- the bundled
 *    `classic` card, the ZYMARG Template Pack card, and any future card such
 *    as a dedicated flash-sales template -- gets the countdown with no engine
 *    change. Nothing in this class keys off a template slug.
 *
 * 2. The markup carries only an absolute UTC timestamp. Rendered HTML is
 *    cached by Cache_Manager, so server-formatted digits would freeze at
 *    whatever the clock read when the cache entry was written. Every visible
 *    digit is therefore produced client-side.
 *
 * 3. `data-now` publishes the server clock so the browser can correct for a
 *    skewed device clock instead of showing a wrong or pre-expired timer.
 *
 * @since 2.9.0
 */
class Countdown_Renderer {

	/**
	 * Supported positions mapped to the card hook that renders them.
	 *
	 * @var array<string, string>
	 */
	const POSITION_HOOKS = array(
		'below_price'  => 'zymarg_after_card_price',
		'over_image'   => 'zymarg_after_card_image',
		'before_title' => 'zymarg_before_card_title',
	);

	/**
	 * Query source of the render currently in progress.
	 *
	 * Used only to decide the 'auto' default, which enables the countdown for
	 * the Flash Deals source and leaves it off everywhere else.
	 *
	 * @var string
	 */
	private static $current_source = '';

	/**
	 * Product ids already rendered for the card currently being output.
	 *
	 * The bundled classic card fires `zymarg_after_card_price` from three
	 * separate meta-layout branches. Only one branch executes per render, but
	 * this guard makes a duplicate structurally impossible.
	 *
	 * @var array<int, bool>
	 */
	private static $rendered = array();

	/**
	 * Attach hooks.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'zymarg_product_grid_before_render', array( __CLASS__, 'capture_source' ), 5, 1 );
		add_action( 'zymarg_before_card', array( __CLASS__, 'reset_card_guard' ), 5, 1 );

		foreach ( self::POSITION_HOOKS as $position => $hook ) {
			add_action(
				$hook,
				static function ( $product = null, $settings = array() ) use ( $position ) {
					self::maybe_render( $product, (array) $settings, $position );
				},
				10,
				2
			);
		}
	}

	/**
	 * Record the query source for the render about to run.
	 *
	 * @param array $config Normalized configuration.
	 * @return void
	 */
	public static function capture_source( $config = array() ) {
		$config               = is_array( $config ) ? $config : array();
		self::$current_source = isset( $config['query']['source'] )
			? sanitize_key( (string) $config['query']['source'] )
			: '';
	}

	/**
	 * Clear the per-card duplicate guard at the start of each card.
	 *
	 * @param mixed $product Product being rendered.
	 * @return void
	 */
	public static function reset_card_guard( $product = null ) {
		if ( $product instanceof \WC_Product ) {
			unset( self::$rendered[ (int) $product->get_id() ] );
		}
	}

	/**
	 * Render the countdown when this position is the configured one.
	 *
	 * @param mixed  $product  Product being rendered.
	 * @param array  $settings Flattened card settings.
	 * @param string $position Position this hook represents.
	 * @return void
	 */
	private static function maybe_render( $product, array $settings, $position ) {
		if ( ! $product instanceof \WC_Product ) {
			return;
		}

		$product_id = (int) $product->get_id();
		if ( isset( self::$rendered[ $product_id ] ) ) {
			return;
		}

		if ( ! self::is_enabled( $settings ) ) {
			return;
		}

		if ( self::resolve_position( $settings ) !== $position ) {
			return;
		}

		$end_ts = self::resolve_end_ts( $product );
		$now    = time();
		if ( $end_ts <= $now ) {
			// No scheduled sale, or already finished. The countdown simply does
			// not render, which is what makes it safe to enable on any source.
			return;
		}

		self::$rendered[ $product_id ] = true;

		echo self::build_html( $end_ts, $now, $position, $product ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fully escaped in build_html().
	}

	/**
	 * Decide whether the countdown is switched on for this render.
	 *
	 * 'auto' (the default) means: on for the Flash Deals source, off elsewhere.
	 *
	 * @param array $settings Flattened card settings.
	 * @return bool
	 */
	private static function is_enabled( array $settings ) {
		$mode = isset( $settings['show_countdown'] ) ? $settings['show_countdown'] : 'auto';

		if ( is_bool( $mode ) ) {
			return $mode;
		}

		$mode = strtolower( trim( (string) $mode ) );

		if ( in_array( $mode, array( 'no', 'false', '0', '' ), true ) ) {
			return '' === $mode ? self::auto_enabled() : false;
		}
		if ( in_array( $mode, array( 'yes', 'true', '1' ), true ) ) {
			return true;
		}

		return self::auto_enabled();
	}

	/**
	 * Whether the 'auto' mode resolves to on for the current render.
	 *
	 * @return bool
	 */
	private static function auto_enabled() {
		/**
		 * Filter which query sources enable the countdown under 'auto'.
		 *
		 * @since 2.9.0
		 *
		 * @param array  $sources Source keys that auto-enable the countdown.
		 * @param string $current Source of the render in progress.
		 */
		$sources = (array) apply_filters(
			'zymarg_wcpg_countdown_auto_sources',
			array( 'flash_deals' ),
			self::$current_source
		);

		return in_array( self::$current_source, $sources, true );
	}

	/**
	 * Resolve the configured position, falling back to below-price.
	 *
	 * @param array $settings Flattened card settings.
	 * @return string
	 */
	private static function resolve_position( array $settings ) {
		$position = isset( $settings['countdown_position'] )
			? sanitize_key( (string) $settings['countdown_position'] )
			: 'below_price';

		return isset( self::POSITION_HOOKS[ $position ] ) ? $position : 'below_price';
	}

	/**
	 * Resolve the sale end timestamp for a product.
	 *
	 * Prefers the map published by the Flash Deals source, which already did
	 * the variation walk while querying. Falls back to resolving directly so
	 * the countdown also works on other sources.
	 *
	 * @param \WC_Product $product Product being rendered.
	 * @return int UNIX timestamp, or 0 when there is no future sale end.
	 */
	private static function resolve_end_ts( \WC_Product $product ) {
		$product_id = (int) $product->get_id();
		$end_ts     = 0;

		if ( class_exists( Source_Flash_Deals::class ) ) {
			$end_ts = (int) Source_Flash_Deals::get_end_ts( $product_id );
			if ( $end_ts <= 0 ) {
				$end_ts = (int) Source_Flash_Deals::end_ts_for( $product );
			}
		}

		/**
		 * Filter the sale end timestamp used for a card's countdown.
		 *
		 * Return 0 to suppress the countdown for this product.
		 *
		 * @since 2.9.0
		 *
		 * @param int         $end_ts  Resolved end timestamp, 0 when none.
		 * @param \WC_Product $product Product being rendered.
		 */
		return (int) apply_filters( 'zymarg_wcpg_countdown_end_ts', $end_ts, $product );
	}

	/**
	 * Build the countdown markup.
	 *
	 * Digits are deliberately left empty for the client to fill; see the class
	 * docblock on why nothing time-dependent may be printed here.
	 *
	 * @param int         $end_ts   Sale end timestamp.
	 * @param int         $now      Server timestamp.
	 * @param string      $position Resolved position.
	 * @param \WC_Product $product  Product being rendered.
	 * @return string
	 */
	private static function build_html( $end_ts, $now, $position, \WC_Product $product ) {
		$html = sprintf(
			'<div class="zymarg-wcpg__countdown zymarg-wcpg__countdown--%1$s" role="timer" data-ends="%2$s" data-now="%3$s">'
				. '<span class="zymarg-wcpg__countdown-time" aria-hidden="true"></span>'
				. '<span class="zymarg-wcpg__countdown-sr"></span>'
				. '</div>',
			esc_attr( $position ),
			esc_attr( (string) (int) $end_ts ),
			esc_attr( (string) (int) $now )
		);

		/**
		 * Filter the countdown markup.
		 *
		 * @since 2.9.0
		 *
		 * @param string      $html     Countdown markup.
		 * @param int         $end_ts   Sale end timestamp.
		 * @param \WC_Product $product  Product being rendered.
		 * @param string      $position Resolved position.
		 */
		return (string) apply_filters( 'zymarg_wcpg_countdown_html', $html, $end_ts, $product, $position );
	}
}
