<?php
/**
 * Visitor affinity profile builder.
 *
 * Aggregates a visitor's signals (wishlist, recently viewed, purchases,
 * engagement events) into a normalised taste profile used by
 * Source_Recommended. The profile is the "user vector" portion of a
 * content-based recommender:
 *
 *   profile = [
 *     'category_ids' => [ term_id => weight (0..1) ],
 *     'brand_ids'    => [ term_id => weight (0..1) ],
 *     'vendor_ids'   => [ user_id  => weight (0..1) ],
 *     'price_band'   => [ 'min' => float, 'max' => float ] | null,
 *     'seen_ids'     => [ pid => unix_ts_last_seen ],     // for recency penalty
 *     'purchased_ids'=> int[],                            // exclude list
 *     'is_empty'     => bool,                             // triggers cold-start
 *     'is_guest'     => bool,
 *     'event_weight' => int,                              // total signal strength
 *   ]
 *
 * Signal weights (per source product) used when building the profile:
 *   purchase       x5
 *   cart_add       x4
 *   wishlist       x3
 *   wishlist_add   x3 (engagement event mirror)
 *   quickview      x2
 *   recently_viewed x1
 *   click          x1
 *
 * Profiles are not cached here. Source_Recommended caches the final
 * scored result IDs via Affinity_Cache, which already amortises the
 * profile build cost.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Recommendations;

defined( 'ABSPATH' ) || exit;

use Zymarg\WCPG\Tracking\Recently_Viewed;
use Zymarg\WCPG\Trending\Engagement_Store;
use Zymarg\WCPG\Vendor\Vendor_Resolver;
use Zymarg\WCPG\Wishlist\Wishlist_Store;

/**
 * Class Affinity_Profile
 */
class Affinity_Profile {

	/** Minimum total event weight before a profile is considered "real". */
	const EMPTY_THRESHOLD = 3;

	/** Hard cap on orders inspected for purchase signals (oldest pruned). */
	const ORDER_LOOKBACK = 25;

	/** Hard cap on order lookback days. */
	const ORDER_LOOKBACK_DAYS = 180;

	/** Soft cap on top-N taxonomy terms kept per dimension. */
	const TOP_TERMS = 10;

	/**
	 * Build the current visitor's profile.
	 *
	 * @return array Profile structure (see class docblock).
	 */
	public static function build() {
		$signals = self::collect_signals();

		$category_scores = array();
		$brand_scores    = array();
		$vendor_scores   = array();
		$prices          = array();
		$seen_ids        = array();
		$total_weight    = 0;

		$brand_tax = self::detect_brand_taxonomy();

		foreach ( $signals as $entry ) {
			$pid    = (int) $entry['pid'];
			$weight = (int) $entry['weight'];
			$ts     = (int) $entry['ts'];
			if ( $pid <= 0 || $weight <= 0 ) {
				continue;
			}

			// Track seen-ness for recency penalty (keep most recent ts).
			if ( ! isset( $seen_ids[ $pid ] ) || $seen_ids[ $pid ] < $ts ) {
				$seen_ids[ $pid ] = $ts;
			}

			$total_weight += $weight;

			// Categories.
			$cats = wp_get_post_terms( $pid, 'product_cat', array( 'fields' => 'ids' ) );
			if ( is_array( $cats ) ) {
				foreach ( $cats as $cat_id ) {
					$cat_id = (int) $cat_id;
					if ( $cat_id > 0 ) {
						$category_scores[ $cat_id ] = ( $category_scores[ $cat_id ] ?? 0 ) + $weight;
					}
				}
			}

			// Brands (only if a brand taxonomy is available).
			if ( $brand_tax ) {
				$brands = wp_get_post_terms( $pid, $brand_tax, array( 'fields' => 'ids' ) );
				if ( is_array( $brands ) ) {
					foreach ( $brands as $brand_id ) {
						$brand_id = (int) $brand_id;
						if ( $brand_id > 0 ) {
							$brand_scores[ $brand_id ] = ( $brand_scores[ $brand_id ] ?? 0 ) + $weight;
						}
					}
				}
			}

			// Vendors (Dokan).
			if ( Vendor_Resolver::is_supported() ) {
				$vendor_id = Vendor_Resolver::resolve( $pid );
				if ( $vendor_id > 0 ) {
					$vendor_scores[ $vendor_id ] = ( $vendor_scores[ $vendor_id ] ?? 0 ) + $weight;
				}
			}

			// Price band (we'll IQR-style trim outliers at the end).
			if ( function_exists( 'wc_get_product' ) ) {
				$product = wc_get_product( $pid );
				if ( $product instanceof \WC_Product ) {
					$price = (float) $product->get_price();
					if ( $price > 0 ) {
						$prices[] = $price;
					}
				}
			}
		}

		$category_scores = self::normalize_and_truncate( $category_scores, self::TOP_TERMS );
		$brand_scores    = self::normalize_and_truncate( $brand_scores, self::TOP_TERMS );
		$vendor_scores   = self::normalize_and_truncate( $vendor_scores, self::TOP_TERMS );
		$price_band      = self::compute_price_band( $prices );

		return array(
			'is_empty'         => $total_weight < self::EMPTY_THRESHOLD,
			'is_guest'         => ! is_user_logged_in(),
			'category_ids'     => $category_scores,
			'brand_ids'        => $brand_scores,
			'vendor_ids'       => $vendor_scores,
			'price_band'       => $price_band,
			'seen_ids'         => $seen_ids,
			'purchased_ids'    => self::collect_purchased_ids(),
			'event_weight'     => (int) $total_weight,
			'brand_taxonomy'   => $brand_tax,
			'has_brand_data'   => ! empty( $brand_scores ),
			'has_vendor_data'  => ! empty( $vendor_scores ),
		);
	}

	/**
	 * Detect the active "brand" taxonomy on this install.
	 *
	 * Order of preference:
	 *   1. WooCommerce 9.x+ native        product_brand
	 *   2. Perfect Brands for WooCommerce pwb-brand
	 *   3. YITH WooCommerce Brands        yith_product_brand
	 *   4. Filter override                zymarg_wcpg_brand_taxonomy
	 *   5. None (returns empty string)
	 *
	 * @return string Taxonomy slug, or '' when unavailable.
	 */
	public static function detect_brand_taxonomy() {
		/**
		 * Filter the detected brand taxonomy slug.
		 *
		 * Return an empty string to disable brand affinity (its weight
		 * is redistributed to category + purchase by Source_Recommended).
		 *
		 * @param string|null $taxonomy Detected taxonomy, or null to auto-detect.
		 */
		$override = apply_filters( 'zymarg_wcpg_brand_taxonomy', null );
		if ( is_string( $override ) ) {
			return $override && taxonomy_exists( $override ) ? $override : '';
		}

		foreach ( array( 'product_brand', 'pwb-brand', 'yith_product_brand' ) as $candidate ) {
			if ( taxonomy_exists( $candidate ) ) {
				return $candidate;
			}
		}
		return '';
	}

	/**
	 * Collect all engagement signals for the current visitor.
	 *
	 * @return array<int,array{pid:int,weight:int,ts:int}>
	 */
	private static function collect_signals() {
		$signals = array();
		$now     = time();

		// Recently viewed: weight 1 (most recent first; we synthesise descending ts).
		$recent_ids = Recently_Viewed::get_ids();
		$rv_index   = 0;
		foreach ( $recent_ids as $pid ) {
			$signals[] = array(
				'pid'    => (int) $pid,
				'weight' => 1,
				// Synthetic timestamps: most recent gets "now", oldest gets ~20h ago.
				'ts'     => $now - ( $rv_index * HOUR_IN_SECONDS ),
			);
			++$rv_index;
		}

		// Wishlist: weight 3 (current intent).
		foreach ( Wishlist_Store::get_ids() as $pid ) {
			$signals[] = array(
				'pid'    => (int) $pid,
				'weight' => 3,
				'ts'     => $now - DAY_IN_SECONDS, // assume "recent intent" but not "right now".
			);
		}

		// Purchase history (logged-in only): weight 5 per line item.
		if ( is_user_logged_in() && function_exists( 'wc_get_orders' ) ) {
			$after  = gmdate( 'Y-m-d H:i:s', $now - ( self::ORDER_LOOKBACK_DAYS * DAY_IN_SECONDS ) );
			$orders = wc_get_orders(
				array(
					'limit'        => self::ORDER_LOOKBACK,
					'customer_id'  => get_current_user_id(),
					'status'       => array( 'wc-completed', 'wc-processing' ),
					'date_created' => '>=' . $after,
					'return'       => 'objects',
					'orderby'      => 'date',
					'order'        => 'DESC',
					'type'         => 'shop_order',
				)
			);
			if ( is_array( $orders ) ) {
				foreach ( $orders as $order ) {
					if ( ! $order instanceof \WC_Order ) {
						continue;
					}
					$order_ts = $order->get_date_created() ? $order->get_date_created()->getTimestamp() : $now;
					foreach ( $order->get_items() as $item ) {
						$pid = (int) $item->get_product_id();
						if ( $pid > 0 ) {
							$signals[] = array(
								'pid'    => $pid,
								'weight' => 5,
								'ts'     => (int) $order_ts,
							);
						}
					}
				}
			}
		}

		// Engagement events from the Trending store (last 30 days = full retention).
		$totals = Engagement_Store::get_window_totals( 30 );
		// The Engagement_Store is GLOBAL, not per-user. We only treat its data
		// as a signal when the current visitor also has it in their wishlist /
		// recent / purchase history, to avoid every visitor sharing the same
		// global engagement profile. This intersection turns the global
		// engagement score into "how strongly engaged were *you* with this
		// product" via the products you've already touched.
		$visitor_pids = array();
		foreach ( $signals as $s ) {
			$visitor_pids[ (int) $s['pid'] ] = true;
		}
		foreach ( $totals as $pid => $row ) {
			$pid = (int) $pid;
			if ( ! isset( $visitor_pids[ $pid ] ) ) {
				continue;
			}
			$signals[] = array(
				'pid'    => $pid,
				// Engagement score is already a small int; cap at +5 contribution.
				'weight' => min( 5, max( 1, (int) ( ( $row['score'] ?? 0 ) / 5 ) ) ),
				'ts'     => $now - HOUR_IN_SECONDS,
			);
		}

		/**
		 * Filter the raw signal list before normalisation.
		 *
		 * Useful for integrations that have their own engagement sources
		 * (e.g. a separate review-posted hook).
		 *
		 * @param array $signals Each entry has keys: pid, weight, ts.
		 */
		return (array) apply_filters( 'zymarg_wcpg_affinity_signals', $signals );
	}

	/**
	 * IDs the visitor has already purchased (used as exclude list when
	 * the widget option `recommended_exclude_purchased` is on).
	 *
	 * @return int[]
	 */
	private static function collect_purchased_ids() {
		if ( ! is_user_logged_in() || ! function_exists( 'wc_get_orders' ) ) {
			return array();
		}
		$ids   = array();
		$after = gmdate( 'Y-m-d H:i:s', time() - ( self::ORDER_LOOKBACK_DAYS * DAY_IN_SECONDS ) );

		$orders = wc_get_orders(
			array(
				'limit'        => self::ORDER_LOOKBACK,
				'customer_id'  => get_current_user_id(),
				'status'       => array( 'wc-completed', 'wc-processing' ),
				'date_created' => '>=' . $after,
				'return'       => 'objects',
				'type'         => 'shop_order',
			)
		);
		if ( is_array( $orders ) ) {
			foreach ( $orders as $order ) {
				if ( ! $order instanceof \WC_Order ) {
					continue;
				}
				foreach ( $order->get_items() as $item ) {
					$pid = (int) $item->get_product_id();
					if ( $pid > 0 ) {
						$ids[] = $pid;
					}
				}
			}
		}
		return array_values( array_unique( $ids ) );
	}

	/**
	 * Normalise a raw score map to 0..1 and keep only the top N.
	 *
	 * @param array<int,int|float> $map Raw scores.
	 * @param int                  $n   Top-N to keep.
	 * @return array<int,float>
	 */
	private static function normalize_and_truncate( array $map, $n ) {
		if ( empty( $map ) ) {
			return array();
		}
		arsort( $map, SORT_NUMERIC );
		$map = array_slice( $map, 0, max( 1, (int) $n ), true );
		$max = max( $map );
		if ( $max <= 0 ) {
			return array();
		}
		$out = array();
		foreach ( $map as $key => $score ) {
			$out[ (int) $key ] = (float) min( 1, $score / $max );
		}
		return $out;
	}

	/**
	 * Compute a "comfort" price band from the visitor's price history.
	 *
	 * Uses 10th / 90th percentile to ignore the cheapest and priciest
	 * outliers (a single splurge or a single tiny accessory shouldn't
	 * peg the band).
	 *
	 * @param float[] $prices Prices.
	 * @return array{min:float,max:float}|null
	 */
	private static function compute_price_band( array $prices ) {
		$prices = array_values( array_filter( $prices, static function ( $p ) {
			return $p > 0;
		} ) );
		if ( count( $prices ) < 3 ) {
			return null;
		}
		sort( $prices, SORT_NUMERIC );
		$n     = count( $prices );
		$p10   = $prices[ (int) floor( $n * 0.1 ) ];
		$p90   = $prices[ (int) min( $n - 1, floor( $n * 0.9 ) ) ];
		// Widen the band by 25% in each direction so we don't exclude
		// slightly-above-band items the user might love.
		$lower = max( 0.0, $p10 * 0.75 );
		$upper = $p90 * 1.25;
		return array(
			'min' => (float) $lower,
			'max' => (float) $upper,
		);
	}
}
