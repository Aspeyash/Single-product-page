<?php
/**
 * Cold-start fallback for the "Recommended For You" source.
 *
 * Used when the visitor's affinity profile is too thin for personalised
 * scoring (logged-out guest with no history, brand-new user, store with
 * fewer than EMPTY_THRESHOLD engagement events). Returns a "generally
 * appealing" product set so the widget never renders empty.
 *
 * Strategies (admin-tunable):
 *   - hybrid       : 50% similar-to-recently-viewed (if any RV exists)
 *                    + 30% trending top-N
 *                    + 20% lifetime best-sellers.
 *                    Falls back to plain trending when no RV available.
 *   - trending     : Pure trending top-N (uses Source_Trending cache).
 *   - featured     : WooCommerce featured products.
 *   - bestsellers  : Highest lifetime total_sales.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Recommendations;

defined( 'ABSPATH' ) || exit;

use Zymarg\WCPG\Tracking\Recently_Viewed;
use Zymarg\WCPG\Trending\Trending_Calculator;

/**
 * Class Cold_Start_Fallback
 */
class Cold_Start_Fallback {

	/**
	 * Get a list of product IDs to display when the affinity profile is empty.
	 *
	 * @param array $settings Widget settings.
	 * @param int   $limit    Maximum products requested.
	 * @return int[]
	 */
	public static function get_ids( array $settings, $limit ) {
		$strategy = isset( $settings['recommended_cold_start'] ) ? sanitize_key( $settings['recommended_cold_start'] ) : 'hybrid';
		$limit    = max( 1, (int) $limit );

		switch ( $strategy ) {
			case 'trending':
				return self::trending_ids( $limit );
			case 'featured':
				return self::featured_ids( $limit );
			case 'bestsellers':
				return self::bestseller_ids( $limit );
			case 'hybrid':
			default:
				return self::hybrid_ids( $limit );
		}
	}

	/**
	 * Hybrid: similar-to-RV + trending + best-sellers.
	 *
	 * @param int $limit Limit.
	 * @return int[]
	 */
	private static function hybrid_ids( $limit ) {
		$rv          = Recently_Viewed::get_ids();
		$similar_ids = array();

		if ( ! empty( $rv ) ) {
			// Take similar products to the most recent 3 viewed items.
			$seeds = array_slice( $rv, 0, 3 );
			foreach ( $seeds as $seed_id ) {
				$similar_ids = array_merge( $similar_ids, self::related_ids( (int) $seed_id, max( 1, (int) ceil( $limit / 2 ) ) ) );
			}
			$similar_ids = array_values( array_unique( $similar_ids ) );
			// Don't recommend back what they just viewed.
			$similar_ids = array_values( array_diff( $similar_ids, $rv ) );
		}

		$trending = self::trending_ids( $limit );
		$best     = self::bestseller_ids( $limit );

		// Splice: 50% similar, 30% trending, 20% bestsellers (proportional to limit).
		$want_similar  = (int) ceil( $limit * 0.5 );
		$want_trending = (int) ceil( $limit * 0.3 );
		$want_best     = $limit; // remainder filler.

		$out = array();
		$out = array_merge( $out, array_slice( $similar_ids, 0, $want_similar ) );
		$out = self::dedupe( array_merge( $out, array_slice( $trending, 0, $want_trending ) ) );
		$out = self::dedupe( array_merge( $out, array_slice( $best, 0, $want_best ) ) );

		if ( count( $out ) < $limit ) {
			// Top up with any remaining trending then bestsellers.
			$out = self::dedupe( array_merge( $out, $trending, $best ) );
		}

		return array_slice( $out, 0, $limit );
	}

	/**
	 * Trending top-N (uses precomputed cache; recomputes once if missing).
	 *
	 * @param int $limit Limit.
	 * @return int[]
	 */
	private static function trending_ids( $limit ) {
		$ids = Trending_Calculator::get_cached_ids();
		if ( empty( $ids ) ) {
			Trending_Calculator::recompute();
			$ids = Trending_Calculator::get_cached_ids();
		}
		return array_slice( $ids, 0, max( 1, $limit * 2 ) );
	}

	/**
	 * Featured products IDs.
	 *
	 * @param int $limit Limit.
	 * @return int[]
	 */
	private static function featured_ids( $limit ) {
		if ( ! function_exists( 'wc_get_product_visibility_term_ids' ) ) {
			return array();
		}
		$visibility = wc_get_product_visibility_term_ids();
		if ( empty( $visibility['featured'] ) ) {
			return array();
		}
		$query = new \WP_Query(
			array(
				'post_type'      => 'product',
				'post_status'    => 'publish',
				'posts_per_page' => max( 1, $limit * 2 ),
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
					array(
						'taxonomy' => 'product_visibility',
						'field'    => 'term_taxonomy_id',
						'terms'    => array( (int) $visibility['featured'] ),
						'operator' => 'IN',
					),
				),
			)
		);
		return is_array( $query->posts ) ? array_map( 'intval', $query->posts ) : array();
	}

	/**
	 * Lifetime best-sellers by total_sales meta.
	 *
	 * @param int $limit Limit.
	 * @return int[]
	 */
	private static function bestseller_ids( $limit ) {
		$query = new \WP_Query(
			array(
				'post_type'      => 'product',
				'post_status'    => 'publish',
				'posts_per_page' => max( 1, $limit * 2 ),
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'meta_key'       => 'total_sales', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'orderby'        => 'meta_value_num',
				'order'          => 'DESC',
			)
		);
		return is_array( $query->posts ) ? array_map( 'intval', $query->posts ) : array();
	}

	/**
	 * Products related to a seed product (shared category/tag).
	 *
	 * @param int $seed_id Seed product ID.
	 * @param int $limit   Limit.
	 * @return int[]
	 */
	private static function related_ids( $seed_id, $limit ) {
		if ( $seed_id <= 0 ) {
			return array();
		}
		$cats = wp_get_post_terms( $seed_id, 'product_cat', array( 'fields' => 'ids' ) );
		$tags = wp_get_post_terms( $seed_id, 'product_tag', array( 'fields' => 'ids' ) );
		$cats = is_array( $cats ) ? array_map( 'intval', $cats ) : array();
		$tags = is_array( $tags ) ? array_map( 'intval', $tags ) : array();

		if ( empty( $cats ) && empty( $tags ) ) {
			return array();
		}

		$tax_query = array( 'relation' => 'OR' ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
		if ( $cats ) {
			$tax_query[] = array(
				'taxonomy' => 'product_cat',
				'field'    => 'term_id',
				'terms'    => $cats,
				'operator' => 'IN',
			);
		}
		if ( $tags ) {
			$tax_query[] = array(
				'taxonomy' => 'product_tag',
				'field'    => 'term_id',
				'terms'    => $tags,
				'operator' => 'IN',
			);
		}

		$query = new \WP_Query(
			array(
				'post_type'      => 'product',
				'post_status'    => 'publish',
				'posts_per_page' => max( 1, $limit * 2 ),
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'post__not_in'   => array( $seed_id ),
				'tax_query'      => $tax_query, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
			)
		);
		return is_array( $query->posts ) ? array_map( 'intval', $query->posts ) : array();
	}

	/**
	 * Dedupe + reindex an int list.
	 *
	 * @param int[] $ids IDs.
	 * @return int[]
	 */
	private static function dedupe( array $ids ) {
		return array_values( array_unique( array_map( 'intval', $ids ) ) );
	}
}
