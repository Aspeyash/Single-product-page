<?php
/**
 * Per-window sales counter for Flash Deals.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Trending;

defined( 'ABSPATH' ) || exit;

/**
 * Class Flash_Sales_Counter
 *
 * WooCommerce tracks lifetime sales only, via the total_sales meta. A flash
 * card needs something different: units sold inside the current sale window.
 * Showing lifetime sales on a scarcity bar would be wrong -- a product that
 * sold 900 units last year and 3 today would render as almost sold out.
 *
 * This class keeps one counter per product, stamped with the window it
 * belongs to. When a new sale window starts the counter resets automatically
 * on first read, so each run of a sale counts from zero.
 *
 * Storage is a single meta row per product holding "windowStart:count", which
 * keeps the meta table bounded no matter how many sales a product runs.
 *
 * @since 2.10.0
 */
final class Flash_Sales_Counter {

	/** Meta key holding "windowStartTimestamp:unitsSold". */
	const META_KEY = '_zymarg_flash_window_sales';

	/**
	 * Attach the order hooks.
	 *
	 * Both statuses are used because stores differ in which one they treat as
	 * the point of sale, and WooCommerce fires each only once per transition.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'woocommerce_order_status_processing', array( __CLASS__, 'record_order' ), 10, 1 );
		add_action( 'woocommerce_order_status_completed', array( __CLASS__, 'record_order' ), 10, 1 );
	}

	/**
	 * Increment the window counter for every flash-flagged line item.
	 *
	 * @param int $order_id Order id.
	 * @return void
	 */
	public static function record_order( $order_id ) {
		if ( ! function_exists( 'wc_get_order' ) ) {
			return;
		}

		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}

		// Guard against double counting when an order moves processing ->
		// completed, which fires both hooks for the same sale.
		if ( $order->get_meta( '_zymarg_flash_counted' ) ) {
			return;
		}

		foreach ( $order->get_items() as $item ) {
			if ( ! method_exists( $item, 'get_product_id' ) ) {
				continue;
			}

			$product_id = (int) $item->get_product_id();
			if ( $product_id <= 0 ) {
				continue;
			}

			$qty = method_exists( $item, 'get_quantity' ) ? (int) $item->get_quantity() : 0;
			if ( $qty <= 0 ) {
				continue;
			}

			self::increment( $product_id, $qty );
		}

		$order->update_meta_data( '_zymarg_flash_counted', 1 );
		$order->save();
	}

	/**
	 * Units sold inside the given sale window.
	 *
	 * Returns 0 when the stored counter belongs to an older window, which is
	 * the correct answer for a sale that has just started.
	 *
	 * @param int $product_id   Product id.
	 * @param int $window_start Window start timestamp.
	 * @return int
	 */
	public static function get_sold( $product_id, $window_start ) {
		$stored = get_post_meta( (int) $product_id, self::META_KEY, true );
		if ( ! is_string( $stored ) || false === strpos( $stored, ':' ) ) {
			return 0;
		}

		list( $window, $count ) = array_map( 'intval', explode( ':', $stored, 2 ) );

		return ( $window === (int) $window_start ) ? max( 0, $count ) : 0;
	}

	/**
	 * Add units to the current window counter for a product.
	 *
	 * @param int $product_id Product id.
	 * @param int $qty        Units to add.
	 * @return void
	 */
	private static function increment( $product_id, $qty ) {
		if ( ! function_exists( 'wc_get_product' ) ) {
			return;
		}

		$product = wc_get_product( $product_id );
		if ( ! $product instanceof \WC_Product ) {
			return;
		}

		$window_start = self::window_start_for( $product );

		/**
		 * Filter the sale-window start used when RECORDING a sale.
		 *
		 * The read side already allows the window to be filtered. Without the
		 * same hook on the write side, any site that shifted the window pushed
		 * reads and writes onto different keys and the sold count silently
		 * reset to zero.
		 *
		 * @since 2.11.0
		 * @param int         $window_start Window start timestamp.
		 * @param \WC_Product $product      Product being recorded.
		 */
		$window_start = (int) apply_filters( 'zymarg_wcpg_flash_window_start', $window_start, $product );

		if ( $window_start <= 0 ) {
			return;
		}

		$current = self::get_sold( $product_id, $window_start );

		update_post_meta(
			(int) $product_id,
			self::META_KEY,
			$window_start . ':' . ( $current + (int) $qty )
		);
	}

	/**
	 * Start timestamp of a product's active sale window.
	 *
	 * A sale with no explicit start date began when it was saved, so the
	 * product's own creation date is used as a stable stand-in: it never
	 * changes, which is what makes it usable as a window key.
	 *
	 * @param \WC_Product $product Product.
	 * @return int Timestamp, or 0 when there is no usable window.
	 */
	public static function window_start_for( \WC_Product $product ) {
		$target = $product;

		if ( $product->is_type( 'variable' ) ) {
			$target = null;
			foreach ( $product->get_children() as $child_id ) {
				$variation = wc_get_product( $child_id );
				if ( $variation instanceof \WC_Product && $variation->is_on_sale() ) {
					$target = $variation;
					break;
				}
			}
		}

		if ( ! $target instanceof \WC_Product ) {
			return 0;
		}

		$from = $target->get_date_on_sale_from();
		if ( $from && method_exists( $from, 'getTimestamp' ) ) {
			return (int) $from->getTimestamp();
		}

		$created = $product->get_date_created();
		if ( $created && method_exists( $created, 'getTimestamp' ) ) {
			return (int) $created->getTimestamp();
		}

		return 0;
	}
}
