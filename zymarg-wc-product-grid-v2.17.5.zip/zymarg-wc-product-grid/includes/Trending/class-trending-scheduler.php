<?php
/**
 * Action Scheduler integration for trending jobs.
 *
 * Three recurring actions:
 *   zymarg_wcpg_flush_event_buffer  - every 5 min
 *   zymarg_wcpg_recompute_trending  - every 30 min
 *   zymarg_wcpg_prune_engagement    - daily
 * Plus one one-shot:
 *   zymarg_wcpg_seed_trending       - on activation
 *
 * Action Scheduler ships with WooCommerce 4.0+; we depend on WC anyway,
 * so it's always available.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Trending;

defined( 'ABSPATH' ) || exit;

/**
 * Class Trending_Scheduler
 */
class Trending_Scheduler {

	const HOOK_FLUSH     = 'zymarg_wcpg_flush_event_buffer';
	const HOOK_RECOMPUTE = 'zymarg_wcpg_recompute_trending';
	const HOOK_PRUNE     = 'zymarg_wcpg_prune_engagement';
	const HOOK_SEED      = 'zymarg_wcpg_seed_trending';
	const GROUP          = 'zymarg-wcpg';

	/**
	 * Wire callbacks. Schedule on WC ready (so Action Scheduler is loaded).
	 */
	public function register() {
		add_action( self::HOOK_FLUSH, array( __CLASS__, 'run_flush' ) );
		add_action( self::HOOK_RECOMPUTE, array( __CLASS__, 'run_recompute' ) );
		add_action( self::HOOK_PRUNE, array( __CLASS__, 'run_prune' ) );
		add_action( self::HOOK_SEED, array( __CLASS__, 'run_seed' ) );

		add_action( 'init', array( $this, 'maybe_schedule' ), 20 );
	}

	/**
	 * Schedule recurring actions if missing.
	 */
	public function maybe_schedule() {
		if ( ! function_exists( 'as_has_scheduled_action' ) ) {
			return; // Action Scheduler not loaded yet.
		}

		if ( ! as_has_scheduled_action( self::HOOK_FLUSH, array(), self::GROUP ) ) {
			as_schedule_recurring_action(
				time() + 300,
				5 * MINUTE_IN_SECONDS,
				self::HOOK_FLUSH,
				array(),
				self::GROUP
			);
		}
		if ( ! as_has_scheduled_action( self::HOOK_RECOMPUTE, array(), self::GROUP ) ) {
			as_schedule_recurring_action(
				time() + 60,
				30 * MINUTE_IN_SECONDS,
				self::HOOK_RECOMPUTE,
				array(),
				self::GROUP
			);
		}
		if ( ! as_has_scheduled_action( self::HOOK_PRUNE, array(), self::GROUP ) ) {
			$tomorrow_3am = strtotime( 'tomorrow 03:00:00', current_time( 'timestamp' ) );
			as_schedule_recurring_action(
				$tomorrow_3am ? $tomorrow_3am : time() + DAY_IN_SECONDS,
				DAY_IN_SECONDS,
				self::HOOK_PRUNE,
				array(),
				self::GROUP
			);
		}
	}

	/**
	 * Schedule a one-shot cold-start seed.
	 */
	public static function schedule_seed() {
		if ( ! function_exists( 'as_schedule_single_action' ) ) {
			return;
		}
		if ( get_option( 'zymarg_wcpg_seed_done' ) ) {
			return;
		}
		if ( as_has_scheduled_action( self::HOOK_SEED, array(), self::GROUP ) ) {
			return;
		}
		as_schedule_single_action( time() + 30, self::HOOK_SEED, array(), self::GROUP );
	}

	/**
	 * Unschedule everything (deactivation hook).
	 */
	public static function unschedule_all() {
		if ( ! function_exists( 'as_unschedule_all_actions' ) ) {
			return;
		}
		as_unschedule_all_actions( self::HOOK_FLUSH, array(), self::GROUP );
		as_unschedule_all_actions( self::HOOK_RECOMPUTE, array(), self::GROUP );
		as_unschedule_all_actions( self::HOOK_PRUNE, array(), self::GROUP );
		as_unschedule_all_actions( self::HOOK_SEED, array(), self::GROUP );
	}

	/* ------------------------------------------------------------------
	 * Job handlers
	 * ------------------------------------------------------------------ */

	/** Flush the event buffer into the aggregate store. */
	public static function run_flush() {
		Event_Buffer::flush();
	}

	/** Recompute the trending top-N. */
	public static function run_recompute() {
		Trending_Calculator::recompute();
	}

	/** Prune old date buckets and mirror to post_meta. */
	public static function run_prune() {
		Engagement_Store::prune();
	}

	/** Cold-start: seed engagement from historical orders. */
	public static function run_seed() {
		Trending_Seeder::run();
		update_option( 'zymarg_wcpg_seed_done', time(), false );
		// Recompute immediately so the first render benefits from seed.
		Trending_Calculator::recompute();
	}
}
