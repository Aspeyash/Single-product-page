<?php
/**
 * Aggregate engagement store.
 *
 * Stores per-product, per-day engagement counts in a single non-autoloaded
 * option. Exposes APIs to record events (used by the buffer flusher) and
 * to compute window aggregates (used by the trending calculator).
 *
 * Layout:
 *   {
 *     <product_id>: {
 *       'YYYY-MM-DD': { 'click': N, 'quickview': N, 'wishlist_add': N, 'cart_add': N }
 *     },
 *     ...
 *   }
 *
 * Hard cap of 4 MB serialized; over the cap, lowest-engagement products
 * are pruned silently and a flag is set so the editor preview can warn.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Trending;

defined( 'ABSPATH' ) || exit;

/**
 * Class Engagement_Store
 */
class Engagement_Store {

	const OPTION_KEY  = 'zymarg_wcpg_engagement';
	const PRUNE_FLAG  = 'zymarg_wcpg_engagement_pruned';
	const RETENTION   = 30; // days
	const MAX_BYTES   = 4194304; // 4 MB
	const META_MIRROR = '_zymarg_clicks_7d';

	/**
	 * Recognised event types and their score weights.
	 *
	 * @return array<string,int>
	 */
	public static function event_weights() {
		return array(
			'click'        => 1,
			'quickview'    => 2,
			'wishlist_add' => 3,
			'cart_add'     => 5,
		);
	}

	/**
	 * Read the full aggregate option.
	 *
	 * @return array
	 */
	public static function get_all() {
		$value = get_option( self::OPTION_KEY, array() );
		return is_array( $value ) ? $value : array();
	}

	/**
	 * Persist the full aggregate option (autoload=no, idempotent).
	 *
	 * @param array $data Aggregate.
	 */
	public static function save_all( array $data ) {
		// First-time or after delete: ensure autoload=no.
		if ( false === get_option( self::OPTION_KEY, false ) ) {
			add_option( self::OPTION_KEY, $data, '', 'no' );
			return;
		}
		update_option( self::OPTION_KEY, $data, false );
	}

	/**
	 * Record a batch of events into the aggregate.
	 *
	 * @param array $events List of [pid, event, ts] tuples.
	 */
	public static function record_events( array $events ) {
		if ( empty( $events ) ) {
			return;
		}
		$valid_types = array_keys( self::event_weights() );
		$data        = self::get_all();
		$tz          = wp_timezone();

		foreach ( $events as $event ) {
			$pid  = isset( $event['pid'] ) ? (int) $event['pid'] : 0;
			$type = isset( $event['event'] ) ? (string) $event['event'] : '';
			$ts   = isset( $event['ts'] ) ? (int) $event['ts'] : time();
			if ( $pid <= 0 || ! in_array( $type, $valid_types, true ) ) {
				continue;
			}
			$dt   = new \DateTimeImmutable( '@' . $ts );
			$date = $dt->setTimezone( $tz )->format( 'Y-m-d' );

			if ( ! isset( $data[ $pid ] ) ) {
				$data[ $pid ] = array();
			}
			if ( ! isset( $data[ $pid ][ $date ] ) ) {
				$data[ $pid ][ $date ] = array(
					'click'        => 0,
					'quickview'    => 0,
					'wishlist_add' => 0,
					'cart_add'     => 0,
				);
			}
			++$data[ $pid ][ $date ][ $type ];
		}

		$data = self::enforce_cap( $data );
		self::save_all( $data );
	}

	/**
	 * Sum events for each product within a sliding window.
	 *
	 * @param int $window_days Number of days to include (>=1).
	 * @return array<int,array{events:int,score:int}> Map pid -> totals.
	 */
	public static function get_window_totals( $window_days = 7 ) {
		$window_days = max( 1, (int) $window_days );
		$cutoff      = ( new \DateTimeImmutable( 'now', wp_timezone() ) )->modify( '-' . ( $window_days - 1 ) . ' days' )->format( 'Y-m-d' );
		$weights     = self::event_weights();
		$totals      = array();

		foreach ( self::get_all() as $pid => $by_date ) {
			$pid    = (int) $pid;
			$events = 0;
			$score  = 0;
			if ( ! is_array( $by_date ) ) {
				continue;
			}
			foreach ( $by_date as $date => $counts ) {
				if ( $date < $cutoff ) {
					continue;
				}
				if ( ! is_array( $counts ) ) {
					continue;
				}
				foreach ( $weights as $type => $weight ) {
					$n       = isset( $counts[ $type ] ) ? (int) $counts[ $type ] : 0;
					$events += $n;
					$score  += $n * $weight;
				}
			}
			if ( $events > 0 ) {
				$totals[ $pid ] = array(
					'events' => $events,
					'score'  => $score,
				);
			}
		}
		return $totals;
	}

	/**
	 * Drop date buckets older than retention. Mirror 7-day click totals
	 * to per-product post meta.
	 */
	public static function prune() {
		$cutoff = ( new \DateTimeImmutable( 'now', wp_timezone() ) )->modify( '-' . self::RETENTION . ' days' )->format( 'Y-m-d' );
		$data   = self::get_all();
		$mirror = self::get_window_totals( 7 );

		foreach ( $data as $pid => $by_date ) {
			if ( ! is_array( $by_date ) ) {
				unset( $data[ $pid ] );
				continue;
			}
			foreach ( array_keys( $by_date ) as $date ) {
				if ( $date < $cutoff ) {
					unset( $data[ $pid ][ $date ] );
				}
			}
			if ( empty( $data[ $pid ] ) ) {
				unset( $data[ $pid ] );
			}
		}

		$data = self::enforce_cap( $data );
		self::save_all( $data );

		// Mirror 7-day score to post_meta on engaged products only.
		foreach ( $mirror as $pid => $totals ) {
			update_post_meta( (int) $pid, self::META_MIRROR, (int) $totals['score'] );
		}
	}

	/**
	 * Enforce the 4 MB size cap by silently pruning the lowest-engagement
	 * products until under cap. Sets PRUNE_FLAG so editors can be warned.
	 *
	 * @param array $data Aggregate to enforce.
	 * @return array Enforced aggregate.
	 */
	public static function enforce_cap( array $data ) {
		$serialized = maybe_serialize( $data );
		if ( strlen( $serialized ) <= self::MAX_BYTES ) {
			return $data;
		}

		// Compute lifetime score per product.
		$weights = self::event_weights();
		$score   = array();
		foreach ( $data as $pid => $by_date ) {
			$total = 0;
			foreach ( $by_date as $counts ) {
				if ( ! is_array( $counts ) ) {
					continue;
				}
				foreach ( $weights as $type => $weight ) {
					if ( isset( $counts[ $type ] ) ) {
						$total += (int) $counts[ $type ] * $weight;
					}
				}
			}
			$score[ $pid ] = $total;
		}
		asort( $score, SORT_NUMERIC ); // lowest first

		// Drop lowest-score products until size is under cap.
		foreach ( array_keys( $score ) as $pid ) {
			unset( $data[ $pid ] );
			if ( strlen( maybe_serialize( $data ) ) <= self::MAX_BYTES ) {
				break;
			}
		}

		update_option( self::PRUNE_FLAG, time(), false );
		return $data;
	}

	/**
	 * Whether the store recently auto-pruned. Used by editor diagnostics.
	 *
	 * @return bool
	 */
	public static function was_recently_pruned() {
		$ts = (int) get_option( self::PRUNE_FLAG, 0 );
		return $ts > 0 && ( time() - $ts ) < DAY_IN_SECONDS;
	}

	/**
	 * Wipe all engagement data. Used by the "Reset trending data" button.
	 */
	public static function reset() {
		delete_option( self::OPTION_KEY );
		delete_option( self::PRUNE_FLAG );
		// Clear per-product mirror.
		global $wpdb;
		$wpdb->delete( $wpdb->postmeta, array( 'meta_key' => self::META_MIRROR ) );
	}
}
