<?php
/**
 * Slot Registry — owns the slot → template mapping.
 *
 * A "slot" is a named position in the ZYMARG UI (e.g. 'related-products').
 * Each slot is assigned to a template slug. The Render Engine resolves the
 * slot to a template, then loads the template's configuration.
 *
 * Responsibilities (and only these):
 *   - Register slots.
 *   - Resolve a slot to a template slug.
 *   - Return all registered slots.
 *   - Seed default slots.
 *   - Expose a filter so external plugins can add, modify, or remove slots.
 *
 * This class knows nothing about:
 *   - Rendering
 *   - Queries
 *   - Whether the assigned template actually exists (Template_Registry's job)
 *
 * @package Zymarg\WCPG\Registry
 * @since   1.6.0
 */

namespace Zymarg\WCPG\Registry;

defined( 'ABSPATH' ) || exit;

/**
 * Class Slot_Registry
 */
final class Slot_Registry {

	/**
	 * Internal slot store.
	 *
	 * Structure:
	 *   [
	 *     'slot-slug' => [
	 *       'template'    => 'template-slug',
	 *       'label'       => 'Human Readable Label',
	 *       'description' => 'Where this slot appears.',
	 *       'enabled'     => true,
	 *     ],
	 *     ...
	 *   ]
	 *
	 * Stored as structured records — not bare strings — so metadata can be
	 * added later without changing the storage schema or the public API.
	 *
	 * @var array<string, array>
	 */
	private static array $slots = [];

	/**
	 * Guards against double-initialisation.
	 *
	 * @var bool
	 */
	private static bool $initialized = false;

	/**
	 * Initialise the registry.
	 *
	 * Called once by Api_Bootstrap::init(). Safe to call multiple times;
	 * subsequent calls are no-ops.
	 *
	 * @return void
	 */
	public static function init(): void {
		if ( self::$initialized ) {
			return;
		}

		self::$initialized = true;

		self::register_defaults();

		/**
		 * Filter the complete slot registry after defaults are seeded.
		 *
		 * Receives and must return the full structured slots array.
		 * External plugins can add, replace, or remove entries here.
		 *
		 * Each slot record must contain at minimum:
		 *   'template' (string) — the template slug to assign.
		 *
		 * Example — add a custom slot:
		 *   add_filter( 'zymarg_product_grid_slots', function( $slots ) {
		 *       $slots['flash-sale'] = [
		 *           'template'    => 'flash-sale-grid',
		 *           'label'       => 'Flash Sale',
		 *           'description' => 'Limited-time sale products.',
		 *           'enabled'     => true,
		 *       ];
		 *       return $slots;
		 *   } );
		 *
		 * Example — reassign an existing slot:
		 *   add_filter( 'zymarg_product_grid_slots', function( $slots ) {
		 *       $slots['related-products']['template'] = 'premium-slider';
		 *       return $slots;
		 *   } );
		 *
		 * @since 1.6.0
		 * @param array<string, array> $slots Structured slot records.
		 */
		self::$slots = (array) apply_filters( 'zymarg_product_grid_slots', self::$slots );
	}

	/**
	 * Register (or overwrite) a slot assignment.
	 *
	 * Overwriting is intentional — it is the mechanism for reassigning a slot
	 * to a different template. The latest call wins.
	 *
	 * @param string $slot     Slot slug (e.g. 'related-products').
	 * @param string $template Template slug to assign (e.g. 'related-grid').
	 * @param array  $meta     Optional metadata: label, description, enabled.
	 * @return void
	 */
	public static function register( string $slot, string $template, array $meta = [] ): void {
		$slot     = sanitize_key( $slot );
		$template = sanitize_key( $template );

		if ( '' === $slot || '' === $template ) {
			return;
		}

		// Merge with existing record so partial updates don't wipe metadata.
		$existing = self::$slots[ $slot ] ?? [];

		self::$slots[ $slot ] = array_merge(
			$existing,
			$meta,
			[ 'template' => $template ] // template always wins.
		);
	}

	/**
	 * Resolve a slot to its assigned template slug.
	 *
	 * Returns null when the slot is not registered, allowing callers to decide
	 * how to handle an unknown slot (error, fallback, or silence).
	 *
	 * @param string $slot Slot slug.
	 * @return string|null Template slug, or null if slot is not registered.
	 */
	public static function get( string $slot ): ?string {
		$slot = sanitize_key( $slot );

		if ( ! isset( self::$slots[ $slot ] ) ) {
			return null;
		}

		return self::$slots[ $slot ]['template'] ?? null;
	}

	/**
	 * Return the full structured registry.
	 *
	 * Useful for admin UI, debug tools, import/export, and REST API.
	 *
	 * @return array<string, array>
	 */
	public static function all(): array {
		return self::$slots;
	}

	/**
	 * Seed the five built-in slots.
	 *
	 * Add only what's needed to prove the architecture. More slots can be
	 * added later — either here or via the `zymarg_product_grid_slots` filter.
	 *
	 * @return void
	 */
	private static function register_defaults(): void {
		$defaults = [
			'related-products' => [
				'template'    => 'related-grid',
				'label'       => __( 'Related Products', 'zymarg-wcpg' ),
				'description' => __( 'Products shown below the single product summary.', 'zymarg-wcpg' ),
				'enabled'     => true,
			],
			'store-products'   => [
				'template'    => 'store-grid',
				'label'       => __( 'Store Products', 'zymarg-wcpg' ),
				'description' => __( 'Product grid on a vendor store page.', 'zymarg-wcpg' ),
				'enabled'     => true,
			],
			'homepage-featured' => [
				'template'    => 'homepage-grid',
				'label'       => __( 'Homepage Featured', 'zymarg-wcpg' ),
				'description' => __( 'Featured products on the homepage.', 'zymarg-wcpg' ),
				'enabled'     => true,
			],
			'category-products' => [
				'template'    => 'category-grid',
				'label'       => __( 'Category Products', 'zymarg-wcpg' ),
				'description' => __( 'Products on a category archive page.', 'zymarg-wcpg' ),
				'enabled'     => true,
			],
			'search-results'   => [
				'template'    => 'search-grid',
				'label'       => __( 'Search Results', 'zymarg-wcpg' ),
				'description' => __( 'Products shown on a search results page.', 'zymarg-wcpg' ),
				'enabled'     => true,
			],
		];

		foreach ( $defaults as $slot => $record ) {
			self::$slots[ $slot ] = $record;
		}
	}

	/**
	 * No public construction — static class only.
	 */
	private function __construct() {}
}
