<?php
/**
 * Template Registry — owns the template slug → configuration mapping.
 *
 * A "template" is a named product presentation definition. Each template
 * stores only the properties that make it unique. Framework-level defaults
 * are supplied by Config_Defaults and merged by Config_Normalizer — not here.
 *
 * Responsibilities (and only these):
 *   - Register templates.
 *   - Retrieve a template config by slug.
 *   - Return all registered templates.
 *   - Seed the five built-in templates.
 *   - Expose a filter so external plugins can add, modify, or remove templates.
 *
 * This class knows nothing about:
 *   - Rendering
 *   - Querying
 *   - Slots (Slot_Registry's job)
 *   - Default values (Config_Defaults' job)
 *   - Merging (Config_Normalizer's job)
 *
 * @package Zymarg\WCPG\Registry
 * @since   1.6.0
 */

namespace Zymarg\WCPG\Registry;

defined( 'ABSPATH' ) || exit;

/**
 * Class Template_Registry
 */
final class Template_Registry {

	/**
	 * Internal template store.
	 *
	 * Structure:
	 *   [
	 *     'template-slug' => [
	 *       'label'       => 'Human Readable Label',
	 *       'description' => 'What this template is for.',
	 *       'config'      => [
	 *         'query'      => [...],
	 *         'layout'     => [...],
	 *         'card'       => [...],
	 *         'responsive' => [...],
	 *       ],
	 *     ],
	 *     ...
	 *   ]
	 *
	 * Config arrays are intentionally minimal — only what makes each template
	 * unique. Config_Defaults fills in everything else at normalize time.
	 *
	 * @var array<string, array>
	 */
	private static array $templates = [];

	/**
	 * Guards against double-initialisation.
	 *
	 * @var bool
	 */
	private static bool $initialized = false;

	/**
	 * Initialise the registry.
	 *
	 * Called once by Api_Bootstrap::init(). Safe to call multiple times;
	 * subsequent calls are no-ops.
	 *
	 * @return void
	 */
	public static function init(): void {
		if ( self::$initialized ) {
			return;
		}

		self::$initialized = true;

		self::register_defaults();

		/**
		 * Filter the complete template registry after defaults are seeded.
		 *
		 * Receives and must return the full structured templates array.
		 * External plugins can add, replace, or remove entries here.
		 *
		 * Each template record must contain at minimum:
		 *   'config' (array) — the partial configuration for this template.
		 *
		 * Example — register a custom template:
		 *   add_filter( 'zymarg_product_grid_templates', function( $templates ) {
		 *       $templates['flash-sale-grid'] = [
		 *           'label'       => 'Flash Sale Grid',
		 *           'description' => 'Compact grid for time-limited sales.',
		 *           'config'      => [
		 *               'query'  => [ 'source' => 'featured', 'limit' => 6 ],
		 *               'layout' => [ 'columns' => 6 ],
		 *               'card'   => [ 'show_vendor' => false ],
		 *           ],
		 *       ];
		 *       return $templates;
		 *   } );
		 *
		 * Example — override an existing template's column count:
		 *   add_filter( 'zymarg_product_grid_templates', function( $templates ) {
		 *       $templates['homepage-grid']['config']['layout']['columns'] = 5;
		 *       return $templates;
		 *   } );
		 *
		 * @since 1.6.0
		 * @param array<string, array> $templates Structured template records.
		 */
		self::$templates = (array) apply_filters( 'zymarg_product_grid_templates', self::$templates );
	}

	/**
	 * Register (or overwrite) a template.
	 *
	 * Overwriting is intentional. The latest registration wins, allowing
	 * plugins loaded after the defaults to replace built-in templates.
	 *
	 * @param string $slug   Template slug (e.g. 'related-grid').
	 * @param array  $config Partial config array (query / layout / card / responsive).
	 * @param array  $meta   Optional metadata: label, description.
	 * @return void
	 */
	public static function register( string $slug, array $config, array $meta = [] ): void {
		$slug = sanitize_key( $slug );

		if ( '' === $slug ) {
			return;
		}

		$existing = self::$templates[ $slug ] ?? [];

		self::$templates[ $slug ] = array_merge(
			$existing,
			$meta,
			[ 'config' => $config ] // config always wins.
		);
	}

	/**
	 * Retrieve the raw (partial) config for a template slug.
	 *
	 * Returns an empty array when the slug is not registered so callers can
	 * decide how to handle a missing template (log, fallback, error).
	 * Merging with defaults is Config_Normalizer's responsibility.
	 *
	 * @param string $slug Template slug.
	 * @return array Partial config array, or empty array if not found.
	 */
	public static function get( string $slug ): array {
		$slug = sanitize_key( $slug );

		return self::$templates[ $slug ]['config'] ?? [];
	}

	/**
	 * Check whether a template slug is registered.
	 *
	 * @param string $slug Template slug.
	 * @return bool
	 */
	public static function exists( string $slug ): bool {
		return isset( self::$templates[ sanitize_key( $slug ) ] );
	}

	/**
	 * Return the full structured registry.
	 *
	 * Useful for admin UI, debug tools, import/export, and REST API.
	 *
	 * @return array<string, array>
	 */
	public static function all(): array {
		return self::$templates;
	}

	/**
	 * Seed the five built-in templates.
	 *
	 * Each template defines only what makes it unique. Numeric defaults
	 * (limit, columns, gap, etc.) and card visibility defaults are owned by
	 * Config_Defaults and applied during normalization.
	 *
	 * @return void
	 */
	private static function register_defaults(): void {
		// ─── Design rule (v2.0.3) ────────────────────────────────────────────
		// Templates define VISUAL properties only. They never bind to a source.
		// Sources are chosen by the consumer (standalone plugin, shortcode,
		// Elementor widget). This separation means the same template can render
		// similar products, vendor products, or recommended products — the
		// consumer decides; the template just controls how they look.
		//
		// What belongs in a template config:
		//   layout.type, layout.columns — grid shape
		//   card.*                      — which card elements are visible
		//   heading.*                   — default heading behaviour
		//   pagination.mode             — default pagination style
		//   query.limit, query.orderby  — sensible size/order defaults
		//
		// What NEVER belongs in a template config:
		//   query.source                — always the consumer's responsibility
		// ─────────────────────────────────────────────────────────────────────

		$defaults = [

			// -----------------------------------------------------------------
			// Related Grid — compact 4-column grid for "you may also like"
			// contexts. Vendor hidden because it adds noise in related-product
			// sections where the buyer is already on a product page.
			// Default limit 8 suits most below-the-fold placements.
			// -----------------------------------------------------------------
			'related-grid' => [
				'label'       => __( 'Related Grid', 'zymarg-wcpg' ),
				'description' => __( 'Compact grid for related/similar product sections.', 'zymarg-wcpg' ),
				'config'      => [
					'query'  => [ 'limit' => 8 ],
					'layout' => [ 'type' => 'grid', 'columns' => 4 ],
					'card'   => [ 'show_vendor' => false ],
				],
			],

			// -----------------------------------------------------------------
			// Store Grid — vendor storefront listing. Vendor name shown to
			// confirm seller identity. Slightly higher limit suits browse pages.
			// -----------------------------------------------------------------
			'store-grid'   => [
				'label'       => __( 'Store Grid', 'zymarg-wcpg' ),
				'description' => __( 'Product grid for vendor store pages.', 'zymarg-wcpg' ),
				'config'      => [
					'query'  => [ 'limit' => 12 ],
					'layout' => [ 'type' => 'grid', 'columns' => 4 ],
					'card'   => [ 'show_vendor' => true ],
				],
			],

			// -----------------------------------------------------------------
			// Homepage Grid — wider 5-column flagship section. Vendor visible
			// to surface marketplace depth. Higher limit fills the section.
			// -----------------------------------------------------------------
			'homepage-grid' => [
				'label'       => __( 'Homepage Grid', 'zymarg-wcpg' ),
				'description' => __( 'Wide grid for homepage featured sections.', 'zymarg-wcpg' ),
				'config'      => [
					'query'  => [ 'limit' => 10 ],
					'layout' => [ 'type' => 'grid', 'columns' => 5 ],
					'card'   => [ 'show_vendor' => true ],
				],
			],

			// -----------------------------------------------------------------
			// Category Grid — browse-page listing. Sold count visible to help
			// purchase decisions. Vendor shown for marketplace context.
			// -----------------------------------------------------------------
			'category-grid' => [
				'label'       => __( 'Category Grid', 'zymarg-wcpg' ),
				'description' => __( 'Grid for category archive pages.', 'zymarg-wcpg' ),
				'config'      => [
					'query'  => [ 'limit' => 12 ],
					'layout' => [ 'type' => 'grid', 'columns' => 4 ],
					'card'   => [
						'show_vendor'     => true,
						'show_sold_count' => true,
					],
				],
			],

			// -----------------------------------------------------------------
			// Search Grid — results page grid. Sold count aids comparison;
			// vendor shown for trust. Consumer supplies the search source
			// (e.g. algolia, WP search) — the template is source-agnostic.
			// -----------------------------------------------------------------
			'search-grid'  => [
				'label'       => __( 'Search Grid', 'zymarg-wcpg' ),
				'description' => __( 'Grid for search results pages.', 'zymarg-wcpg' ),
				'config'      => [
					'query'  => [ 'limit' => 12 ],
					'layout' => [ 'type' => 'grid', 'columns' => 4 ],
					'card'   => [
						'show_vendor'     => true,
						'show_sold_count' => true,
					],
				],
			],
		];

		foreach ( $defaults as $slug => $record ) {
			self::$templates[ $slug ] = $record;
		}
	}

	/**
	 * No public construction — static class only.
	 */
	private function __construct() {}
}
