<?php
/**
 * Template Manager.
 *
 * The single class in the plugin that knows where template files live.
 * Render_Engine calls Template_Manager::render_layout() for the layout wrapper
 * and the layout wrapper calls Template_Manager::render_card() for each card.
 * Neither Render_Engine nor the wrappers ever reference a filename directly.
 *
 * Responsibilities (and only these):
 *   - Map a layout type (grid/slider) to the correct layout wrapper file.
 *   - Map a card template slug to the correct card file.
 *   - Expose a public registration API so standalone plugins can add templates
 *     without modifying core files.
 *   - Fall back gracefully on unknown slugs — never a fatal error.
 *   - Delegate file inclusion to Template_Loader so theme overrides work
 *     automatically for both layout wrappers and card templates.
 *   - Return captured output as a string.
 *
 * This class must not:
 *   - Execute or build queries.
 *   - Normalize or validate configuration.
 *   - Enqueue assets.
 *   - Know about consumers (Elementor, shortcode, page consumers).
 *   - Scan the filesystem or auto-discover templates.
 *
 * Design notes:
 *   - All public methods are static — callers need no instance.
 *   - Unknown slugs never produce a fatal error; they fall back to defaults.
 *   - Template_Loader handles theme override support (zymarg-wcpg/ in the
 *     active theme). Both layout wrappers and card templates inherit this.
 *
 * Card template architecture (v2.0.5):
 *   CARD_TEMPLATES is the immutable core seed — only 'classic' lives here.
 *   The core plugin never adds more entries to this constant.
 *   External code (standalone plugins, extension packs) registers additional
 *   templates via register_card(). Core templates always take priority:
 *   register_card() cannot override 'classic' or any other core entry.
 *
 * How a standalone plugin registers a card template:
 *
 *   add_action( 'zymarg_wcpg_init', function () {
 *       Template_Manager::register_card(
 *           'fashion',
 *           plugin_dir_path( __FILE__ ) . 'templates/product-card.php'
 *       );
 *   } );
 *
 *   Then call it anywhere via Public_API:
 *
 *   Public_API::render( [
 *       'config' => [ 'template' => 'fashion' ],
 *       'query'  => [ 'source'   => 'trending' ],
 *   ] );
 *
 * Adding a new layout type:
 *   1. Add the type -> path entry to LAYOUT_TEMPLATES.
 *   2. Create the wrapper file.
 *   3. Nothing else changes.
 *
 * @package Zymarg\WCPG\Templates
 * @since   1.8.0
 */

namespace Zymarg\WCPG\Templates;

use Zymarg\WCPG\Template_Loader;

defined( 'ABSPATH' ) || exit;

/**
 * Class Template_Manager
 */
final class Template_Manager {

	// -------------------------------------------------------------------------
	// Layout wrapper map
	// -------------------------------------------------------------------------

	/**
	 * Map of layout types to layout wrapper paths (relative to /templates/).
	 *
	 * Render_Engine previously owned this map. It now lives here so
	 * Render_Engine has zero knowledge of filenames.
	 *
	 * @var array<string, string>
	 */
	private const LAYOUT_TEMPLATES = [
		'grid'   => 'grid/grid-wrapper.php',
		'slider' => 'slider/slider-wrapper.php',
	];

	/**
	 * Layout wrapper used when the requested type is unrecognised.
	 *
	 * @var string
	 */
	private const FALLBACK_LAYOUT = 'grid/grid-wrapper.php';

	// -------------------------------------------------------------------------
	// Card template map
	// -------------------------------------------------------------------------

	/**
	 * Immutable core card templates.
	 *
	 * This constant is the seed for get_registered_cards(). It contains only
	 * templates that ship with the core plugin. 'classic' is the only built-in
	 * template and the fallback for all unknown slugs.
	 *
	 * External templates must never be added here — use register_card() instead.
	 * Core templates always take priority: register_card() cannot override these.
	 *
	 * @var array<string, string>
	 */
	private const CARD_TEMPLATES = [
		'classic' => 'cards/classic/product-card.php',
	];

	/**
	 * Card template slug used when the requested slug is unknown.
	 *
	 * @var string
	 */
	private const FALLBACK_CARD = 'classic';

	/**
	 * Runtime-registered card templates added by external plugins.
	 *
	 * Populated by register_card(). Merged with CARD_TEMPLATES by
	 * get_registered_cards(). Core templates always win over runtime entries:
	 * an external plugin cannot override 'classic' or any other core template.
	 *
	 * @var array<string, string>
	 */
	private static array $registered_cards = [];

	// -------------------------------------------------------------------------
	// Public API
	// -------------------------------------------------------------------------

	/**
	 * Resolve the layout wrapper path for a given config without rendering.
	 *
	 * Exposed so Render_Engine can resolve the path once and pass it to both
	 * lifecycle hooks and render_layout(), guaranteeing hooks and renderer
	 * always use the same path — including any substitution made via the
	 * zymarg_layout_template filter.
	 *
	 * Previously render_layout() re-resolved the path independently from raw
	 * constants, meaning the filter affected hook arguments but not the actual
	 * file loaded — a contract violation fixed in v2.0.2.
	 *
	 * @param array $config Normalized config.
	 * @return string Path relative to /templates/.
	 */
	public static function resolve_layout_path( array $config ): string {
		$layout_type = $config['layout']['type'] ?? 'grid';

		/**
		 * Filter the layout wrapper template path.
		 *
		 * Allows third-party code to substitute a custom layout wrapper
		 * without modifying core files. Return a path relative to /templates/.
		 *
		 * @since 1.9.0
		 * @param string $path        Resolved path relative to /templates/.
		 * @param string $layout_type Layout type slug ('grid', 'slider', …).
		 * @param array  $config      Normalized render config.
		 */
		return (string) apply_filters(
			'zymarg_layout_template',
			self::LAYOUT_TEMPLATES[ $layout_type ] ?? self::FALLBACK_LAYOUT,
			$layout_type,
			$config
		);
	}

	/**
	 * Render the layout wrapper for a product grid and return the HTML string.
	 *
	 * This is the primary entry point called by Render_Engine. It replaces
	 * the direct Template_Loader::get_template_html() call that Render_Engine
	 * previously made — Render_Engine now has zero knowledge of filenames.
	 *
	 * The layout wrapper (grid-wrapper.php / slider-wrapper.php) is responsible
	 * for iterating products and calling render_card() for each one.
	 *
	 * The optional $resolved_path parameter allows the caller to pass in the
	 * path already obtained from resolve_layout_path(), so the
	 * zymarg_layout_template filter fires exactly once per render rather than
	 * independently in hooks and again in the renderer. When omitted,
	 * resolve_layout_path() is called internally as a safe fallback.
	 *
	 * @param array       $config         Normalized config.
	 * @param array       $render_context Full render context built by Render_Engine.
	 * @param string|null $resolved_path  Pre-resolved path from resolve_layout_path(),
	 *                                    or null to resolve internally.
	 * @return string Rendered HTML. Empty string if the wrapper file is missing.
	 */
	public static function render_layout( array $config, array $render_context, ?string $resolved_path = null ): string {
		$path = $resolved_path ?? self::resolve_layout_path( $config );

		return Template_Loader::get_template_html( $path, $render_context );
	}

	// -------------------------------------------------------------------------
	// Card template registry — public API for external plugins
	// -------------------------------------------------------------------------

	/**
	 * Register a card template from an external plugin.
	 *
	 * This is the official API for standalone plugins and template packs to add
	 * their own card templates without modifying core files.
	 *
	 * Registration should happen on the 'zymarg_wcpg_init' action so the core
	 * plugin is fully bootstrapped before external templates are added:
	 *
	 *   add_action( 'zymarg_wcpg_init', function () {
	 *       Template_Manager::register_card(
	 *           'fashion',
	 *           plugin_dir_path( __FILE__ ) . 'templates/product-card.php'
	 *       );
	 *   } );
	 *
	 * Validation rules:
	 *   - Slug must be non-empty and match [a-z0-9_-]+ (lowercase alphanumeric,
	 *     hyphens, underscores). Invalid slugs are rejected with E_USER_WARNING.
	 *   - Slug must not already be registered (core or runtime). First
	 *     registration wins; duplicates are rejected with E_USER_WARNING.
	 *   - Path must be non-empty. Empty paths are rejected with E_USER_WARNING.
	 *   - Core templates (CARD_TEMPLATES constant) are immutable. Any attempt
	 *     to register a slug that matches a core template is rejected.
	 *
	 * @param string $slug Unique template slug, e.g. 'fashion'. Must match [a-z0-9_-]+.
	 * @param string $path Absolute filesystem path to the product-card.php file.
	 * @return void
	 */
	public static function register_card( string $slug, string $path ): void {
		// Validate slug: non-empty, lowercase alphanumeric + hyphens/underscores.
		if ( '' === $slug || ! preg_match( '/^[a-z0-9_-]+$/', $slug ) ) {
			trigger_error(
				sprintf(
					'[ZYMARG WCPG] register_card(): Invalid slug "%s". Slugs must be non-empty and match [a-z0-9_-]+.',
					$slug
				),
				E_USER_WARNING
			);
			return;
		}

		// Validate path: non-empty.
		if ( '' === trim( $path ) ) {
			trigger_error(
				sprintf(
					'[ZYMARG WCPG] register_card(): Path for slug "%s" must not be empty.',
					$slug
				),
				E_USER_WARNING
			);
			return;
		}

		// Guard: core templates are immutable.
		if ( isset( self::CARD_TEMPLATES[ $slug ] ) ) {
			trigger_error(
				sprintf(
					'[ZYMARG WCPG] register_card(): Cannot override core template "%s". Core templates are immutable.',
					$slug
				),
				E_USER_WARNING
			);
			return;
		}

		// Guard: first registration wins — no silent overrides between plugins.
		if ( isset( self::$registered_cards[ $slug ] ) ) {
			trigger_error(
				sprintf(
					'[ZYMARG WCPG] register_card(): Card template "%s" is already registered. First registration wins.',
					$slug
				),
				E_USER_WARNING
			);
			return;
		}

		self::$registered_cards[ $slug ] = $path;
	}

	/**
	 * Unregister a runtime-registered card template.
	 *
	 * Removes a template that was previously added via register_card(). Core
	 * templates (CARD_TEMPLATES constant) cannot be unregistered.
	 *
	 * Primarily useful for automated testing — reset the registry between tests
	 * without needing to re-instantiate the class — and for future admin-level
	 * template management features.
	 *
	 * @param string $slug Template slug to remove.
	 * @return void
	 */
	public static function unregister_card( string $slug ): void {
		if ( isset( self::CARD_TEMPLATES[ $slug ] ) ) {
			trigger_error(
				sprintf(
					'[ZYMARG WCPG] unregister_card(): Cannot unregister core template "%s".',
					$slug
				),
				E_USER_WARNING
			);
			return;
		}

		unset( self::$registered_cards[ $slug ] );
	}

	/**
	 * Return the complete map of available card templates.
	 *
	 * Merges the immutable CARD_TEMPLATES constant (core, always present) with
	 * runtime-registered templates added by external plugins. Core entries take
	 * priority — array_merge order ensures they are never overwritten.
	 *
	 * This is the single source of truth for template resolution. All lookups
	 * go through this method rather than reading CARD_TEMPLATES directly.
	 *
	 * @return array<string, string> Map of slug => absolute or relative path.
	 */
	public static function get_registered_cards(): array {
		// Core templates always win: place them last in array_merge so they
		// overwrite any runtime entry that somehow shares a slug.
		return array_merge( self::$registered_cards, self::CARD_TEMPLATES );
	}

	/**
	 * Check whether a card template slug is registered (core or runtime).
	 *
	 * Used by Config_Normalizer to validate the card.template config value
	 * before it reaches the renderer. If the slug is unknown the normalizer
	 * falls back to 'classic' so the renderer never receives an invalid slug.
	 *
	 * Template_Manager owns this check because it is the only class that
	 * knows which templates exist — Config_Normalizer must not inspect
	 * CARD_TEMPLATES or $registered_cards directly.
	 *
	 * @param string $slug Template slug to test.
	 * @return bool True when the slug resolves to a known template.
	 */
	public static function is_registered_card( string $slug ): bool {
		return isset( self::get_registered_cards()[ $slug ] );
	}

	/**
	 * Render a single product card and return the HTML string.
	 *
	 * Called by layout wrapper templates (grid-wrapper.php, slider-wrapper.php)
	 * for each product in the loop. The slug comes from
	 * $config['card']['template'], defaulting to 'classic' when not set.
	 *
	 * @param string $template Card template slug (e.g. 'classic', 'minimal').
	 * @param array  $args     Variables to make available inside the template
	 *                         (product, config, settings, widget_id, etc.).
	 * @return string Rendered HTML. Empty string if the template file is missing.
	 */
	public static function render_card( string $template, array $args ): string {
		/**
		 * Filter the card template slug before it is resolved to a file path.
		 *
		 * Allows third-party code (or future multi-template support) to
		 * substitute a different card design per-product or per-context.
		 *
		 * @since 1.9.0
		 * @param string      $template Card template slug ('classic', 'minimal', …).
		 * @param array       $args     Render args: product, config, settings, widget_id.
		 */
		$template = (string) apply_filters( 'zymarg_card_template', $template, $args );

		$path = self::resolve_card_path( $template );

		if ( null === $path ) {
			// Card template missing even after fallback — return empty string
			// rather than a fatal error. The loop in the wrapper continues.
			return '';
		}

		// Give themes a single, predictable override location that works
		// identically for core templates and for templates registered by
		// standalone plugins:
		//
		//   theme/zymarg-wcpg/cards/{slug}/product-card.php
		//
		// Bundled templates already live at that relative path, so the
		// override key and the registry value coincide for core. External
		// templates register an absolute path, so the key must be derived
		// from the slug — without it a theme could not override them at all.
		$theme_override = 'cards/' . $template . '/product-card.php';

		return Template_Loader::get_template_html( $path, $args, $theme_override );
	}

	/**
	 * Resolve the companion CSS/JS assets that ship with a card template.
	 *
	 * Each card template may ship a stylesheet and an optional script in the
	 * same directory as its PHP file. This method locates them and returns
	 * both the filesystem path (for existence checks) and the public URL
	 * (for enqueueing).
	 *
	 * Template_Manager owns this lookup because it is the only class allowed
	 * to know where template files live (Rule #6). Asset_Manager consumes the
	 * result and decides how to enqueue it — it never builds template paths.
	 *
	 * The convention is "alongside the template file", which resolves to the
	 * documented core layout for bundled templates and to the plugin's own
	 * directory for externally registered ones:
	 *
	 *   core     templates/cards/classic/product-card.php
	 *            templates/cards/classic/style.css
	 *
	 *   external {plugin}/templates/product-card.php
	 *            {plugin}/templates/style.css
	 *
	 * Before v2.1.0 asset lookup was hardcoded to this plugin's own
	 * templates/cards/{slug}/ directory, so a template registered by a
	 * standalone plugin could never load its own stylesheet.
	 *
	 * @since 2.1.0
	 * @param string $slug Card template slug.
	 * @return array{css: ?array{path: string, url: string, version: string}, js: ?array{path: string, url: string, version: string}}
	 */
	public static function get_card_assets( string $slug ): array {
		$assets = [
			'css' => null,
			'js'  => null,
		];

		$path = self::resolve_card_path( $slug );
		if ( null === $path ) {
			return $assets;
		}

		// Registry values may be relative (bundled) or absolute (external).
		$absolute = self::absolutize( $path );
		$dir      = rtrim( wp_normalize_path( dirname( $absolute ) ), '/' ) . '/';

		foreach ( [ 'css' => 'style.css', 'js' => 'script.js' ] as $type => $filename ) {
			$file = $dir . $filename;

			if ( ! is_readable( $file ) ) {
				continue;
			}

			$url = self::path_to_url( $file );
			if ( '' === $url ) {
				continue;
			}

			$assets[ $type ] = [
				'path'    => $file,
				'url'     => $url,
				'version' => self::asset_version( $file ),
			];
		}

		return $assets;
	}

	// -------------------------------------------------------------------------
	// Private helpers
	// -------------------------------------------------------------------------

	/**
	 * Convert a registry template path to an absolute filesystem path.
	 *
	 * Bundled templates are stored relative to /templates/; externally
	 * registered templates are already absolute.
	 *
	 * @since 2.1.0
	 * @param string $path Relative or absolute template path.
	 * @return string Absolute, normalized path.
	 */
	private static function absolutize( string $path ): string {
		$path = wp_normalize_path( $path );

		$is_absolute = function_exists( 'path_is_absolute' )
			? path_is_absolute( $path )
			: ( '' !== $path && '/' === $path[0] );

		if ( $is_absolute ) {
			return $path;
		}

		return wp_normalize_path( ZYMARG_WCPG_DIR . 'templates/' ) . ltrim( $path, '/' );
	}

	/**
	 * Map an absolute filesystem path to its public URL.
	 *
	 * Handles assets living in this plugin, in the active theme (child or
	 * parent), in any other plugin, or anywhere else under wp-content.
	 * Returns an empty string when the path is outside all known web roots,
	 * so the caller can skip enqueueing rather than emit a broken URL.
	 *
	 * @since 2.1.0
	 * @param string $path Absolute filesystem path.
	 * @return string Public URL, or '' when not web-accessible.
	 */
	private static function path_to_url( string $path ): string {
		$path = wp_normalize_path( $path );

		$candidates = [
			wp_normalize_path( ZYMARG_WCPG_DIR )         => rtrim( ZYMARG_WCPG_URL, '/' ) . '/',
			wp_normalize_path( get_stylesheet_directory() ) => rtrim( get_stylesheet_directory_uri(), '/' ) . '/',
			wp_normalize_path( get_template_directory() )   => rtrim( get_template_directory_uri(), '/' ) . '/',
		];

		if ( defined( 'WP_PLUGIN_DIR' ) ) {
			$candidates[ wp_normalize_path( WP_PLUGIN_DIR ) ] = rtrim( plugins_url(), '/' ) . '/';
		}

		if ( defined( 'WP_CONTENT_DIR' ) ) {
			$candidates[ wp_normalize_path( WP_CONTENT_DIR ) ] = rtrim( content_url(), '/' ) . '/';
		}

		foreach ( $candidates as $base_dir => $base_url ) {
			$base_dir = rtrim( (string) $base_dir, '/' ) . '/';

			if ( '' !== $base_dir && 0 === strpos( $path, $base_dir ) ) {
				return $base_url . ltrim( substr( $path, strlen( $base_dir ) ), '/' );
			}
		}

		return '';
	}

	/**
	 * Build a cache-busting version string for a template asset.
	 *
	 * External template plugins version independently of this engine, so the
	 * engine's own version number would not change when they ship an update.
	 * File modification time is therefore the only reliable cache-buster for
	 * assets outside this plugin.
	 *
	 * @since 2.1.0
	 * @param string $file Absolute path to the asset.
	 * @return string Version string.
	 */
	private static function asset_version( string $file ): string {
		$mtime = @filemtime( $file ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- non-fatal; falls back to plugin version.

		if ( ! empty( $mtime ) ) {
			return (string) $mtime;
		}

		return defined( 'ZYMARG_WCPG_VERSION' ) ? ZYMARG_WCPG_VERSION : '1';
	}

	/**
	 * Resolve a card template slug to a file path.
	 *
	 * Reads from get_registered_cards() which merges core templates with
	 * runtime-registered templates. Core templates always take priority.
	 *
	 * Resolution order:
	 *   1. Exact slug match in get_registered_cards().
	 *   2. Fallback to FALLBACK_CARD ('classic') if the slug is unknown.
	 *   3. Return null if even the fallback is missing (should never happen).
	 *
	 * @param string $template Card template slug.
	 * @return string|null Resolved path, or null if unresolvable.
	 */
	private static function resolve_card_path( string $template ): ?string {
		$all = self::get_registered_cards();

		if ( isset( $all[ $template ] ) ) {
			return $all[ $template ];
		}

		// Unknown slug — fall back to classic silently.
		return $all[ self::FALLBACK_CARD ] ?? null;
	}

	/**
	 * No public construction — static class only.
	 */
	private function __construct() {}
}
