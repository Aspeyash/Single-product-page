<?php
/**
 * Context Resolver — converts partial caller context into a complete,
 * normalized context array.
 *
 * Every render call starts with whatever context the caller knows.
 * This class fills in the gaps, derives what can be safely inferred,
 * and always returns the same schema so every downstream class is simpler.
 *
 * Responsibilities (and only these):
 *   - Accept partial context from any caller.
 *   - Return a complete context array with every canonical key present.
 *   - Derive safe values from what was supplied (e.g. vendor from product).
 *   - Expose filters so external plugins can enrich context.
 *
 * This class must not:
 *   - Query product collections.
 *   - Load templates.
 *   - Decide layouts.
 *   - Build query arguments.
 *   - Render HTML.
 *   - Read WordPress globals (e.g. $post, get_queried_object()) unless
 *     the caller explicitly passes 'auto_detect' => true.
 *
 * Canonical context schema:
 *   product_id      int     — WooCommerce product post ID (0 = unknown)
 *   vendor_id       int     — Dokan seller user ID (0 = unknown)
 *   category_id     int     — Product category term ID (0 = unknown)
 *   tag_id          int     — Product tag term ID (0 = unknown)
 *   brand_id        int     — Brand term ID, reserved for future use (0 = unknown)
 *   search          string  — Search query string ('' = none)
 *   products        array|null — Pre-fetched WC_Product objects; null = not supplied
 *   current_user_id int     — Logged-in user ID (0 = guest)
 *   is_logged_in    bool    — Whether a user is logged in
 *   request         string  — Arbitrary request identifier for debugging ('' = none)
 *
 * @package Zymarg\WCPG\Context
 * @since   1.6.0
 */

namespace Zymarg\WCPG\Context;

defined( 'ABSPATH' ) || exit;

/**
 * Class Context_Resolver
 */
final class Context_Resolver {

	/**
	 * Resolve a partial caller context into a complete context array.
	 *
	 * Accepts anything from an empty array to a fully populated context.
	 * Always returns every canonical key, so downstream classes never need
	 * to guard against missing keys.
	 *
	 * Derivation order:
	 *   1. Start from canonical defaults.
	 *   2. Merge caller-supplied values.
	 *   3. Derive missing values from what was supplied.
	 *   4. Apply framework filter.
	 *   5. Sanitize and return.
	 *
	 * @param array $context Partial context from the caller.
	 * @return array Complete normalized context.
	 */
	public static function resolve( array $context = [] ): array {
		// 1. Start from the canonical default schema.
		$resolved = self::defaults();

		// 2. Merge caller-supplied values into the schema.
		//    Unknown keys are accepted — downstream classes and filters may
		//    use them; they won't interfere with the canonical keys.
		foreach ( $context as $key => $value ) {
			$resolved[ $key ] = $value;
		}

		// 3. Derive what we can from what was supplied.
		$resolved = self::derive( $resolved );

		// 4. Always resolve the current user — this is safe and free.
		if ( function_exists( 'get_current_user_id' ) ) {
			$user_id                  = (int) get_current_user_id();
			$resolved['current_user_id'] = $user_id;
			$resolved['is_logged_in']    = $user_id > 0;
		}

		// 5. Sanitize all canonical integer fields.
		foreach ( [ 'product_id', 'vendor_id', 'category_id', 'tag_id', 'brand_id', 'current_user_id' ] as $int_key ) {
			$resolved[ $int_key ] = max( 0, (int) ( $resolved[ $int_key ] ?? 0 ) );
		}
		$resolved['search']  = isset( $resolved['search'] ) ? sanitize_text_field( (string) $resolved['search'] ) : '';
		$resolved['request'] = isset( $resolved['request'] ) ? sanitize_key( (string) $resolved['request'] ) : '';

		// products must be array or null.
		if ( isset( $resolved['products'] ) && ! is_array( $resolved['products'] ) ) {
			$resolved['products'] = null;
		}

		/**
		 * Filter the fully resolved context before it is returned.
		 *
		 * Use this to enrich context from external sources — brand plugins,
		 * campaign systems, membership levels, geo-personalization, etc.
		 *
		 * Example:
		 *   add_filter( 'zymarg_product_grid_context', function( $ctx ) {
		 *       $ctx['brand_id'] = my_brand_plugin_get_current_brand();
		 *       return $ctx;
		 *   } );
		 *
		 * @since 1.6.0
		 * @param array $resolved Complete normalized context array.
		 */
		return (array) apply_filters( 'zymarg_product_grid_context', $resolved );
	}

	/**
	 * Return the canonical default context schema.
	 *
	 * Every key that the framework understands is present here with a safe
	 * empty value. Downstream classes can rely on these keys always existing.
	 *
	 * @return array
	 */
	public static function defaults(): array {
		return [
			'product_id'      => 0,
			'vendor_id'       => 0,
			'category_id'     => 0,
			'tag_id'          => 0,
			'brand_id'        => 0,    // reserved — not used yet
			'search'          => '',
			'products'        => null, // null = not pre-supplied
			'current_user_id' => 0,
			'is_logged_in'    => false,
			'request'         => '',   // arbitrary debug/trace identifier
		];
	}

	// -------------------------------------------------------------------------
	// Private helpers
	// -------------------------------------------------------------------------

	/**
	 * Derive missing context values from what was supplied.
	 *
	 * Derivation rules:
	 *   product_id supplied → try to derive vendor_id and category_id.
	 *   vendor_id supplied  → no further derivation today (future: store URL).
	 *   category_id supplied → no further derivation today.
	 *
	 * All derivations are best-effort. A derivation failure leaves the field
	 * at its default (0 or ''); it never throws.
	 *
	 * @param array $context Partially merged context.
	 * @return array Context with derived values filled in.
	 */
	private static function derive( array $context ): array {
		$product_id = (int) ( $context['product_id'] ?? 0 );

		if ( $product_id > 0 ) {
			// Derive vendor_id from product if not already supplied.
			if ( 0 === (int) ( $context['vendor_id'] ?? 0 ) ) {
				$context['vendor_id'] = self::derive_vendor_from_product( $product_id );
			}

			// Derive primary category_id from product if not already supplied.
			if ( 0 === (int) ( $context['category_id'] ?? 0 ) ) {
				$context['category_id'] = self::derive_category_from_product( $product_id );
			}
		}

		return $context;
	}

	/**
	 * Attempt to derive a Dokan vendor user ID from a product ID.
	 *
	 * Returns 0 if Dokan is not active or the product has no seller.
	 *
	 * @param int $product_id WooCommerce product post ID.
	 * @return int Vendor user ID, or 0.
	 */
	private static function derive_vendor_from_product( int $product_id ): int {
		if ( $product_id <= 0 ) {
			return 0;
		}

		// Use Dokan's native function when available.
		if ( function_exists( 'dokan_get_vendor_by_product' ) ) {
			$vendor = dokan_get_vendor_by_product( $product_id );
			if ( $vendor && is_object( $vendor ) && method_exists( $vendor, 'get_id' ) ) {
				return (int) $vendor->get_id();
			}
		}

		// Fallback: read the post author (works for any WooCommerce site).
		$author = (int) get_post_field( 'post_author', $product_id );
		return $author > 0 ? $author : 0;
	}

	/**
	 * Attempt to derive the primary product category term ID from a product.
	 *
	 * Returns the first assigned product_cat term ID, or 0 if none.
	 *
	 * @param int $product_id WooCommerce product post ID.
	 * @return int Category term ID, or 0.
	 */
	private static function derive_category_from_product( int $product_id ): int {
		if ( $product_id <= 0 ) {
			return 0;
		}

		$terms = get_the_terms( $product_id, 'product_cat' );

		if ( ! is_array( $terms ) || empty( $terms ) ) {
			return 0;
		}

		// Prefer the term marked as the primary category by Yoast/RankMath
		// if available, otherwise take the first term.
		$primary = (int) get_post_meta( $product_id, '_yoast_wpseo_primary_product_cat', true );
		if ( $primary > 0 ) {
			foreach ( $terms as $term ) {
				if ( (int) $term->term_id === $primary ) {
					return $primary;
				}
			}
		}

		return (int) $terms[0]->term_id;
	}

	/**
	 * No public construction — static class only.
	 */
	private function __construct() {}
}
