<?php
/**
 * Admin-only AJAX endpoints for editor-preview diagnostic buttons.
 *
 * Each endpoint requires:
 *   - Valid nonce action 'zymarg_wcpg_editor'
 *   - manage_options capability
 *   - Light per-IP rate limit so a misbehaving editor cannot spam
 *
 * Phase 4 will ship the user-facing AJAX layer separately.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Admin;

defined( 'ABSPATH' ) || exit;

use Zymarg\WCPG\Trending\Engagement_Store;
use Zymarg\WCPG\Trending\Event_Buffer;
use Zymarg\WCPG\Trending\Trending_Calculator;
use Zymarg\WCPG\Vendor\Vendor_Cache;
use Zymarg\WCPG\Vendor\Vendor_Resolver;

/**
 * Class Editor_Ajax
 */
class Editor_Ajax {

	const NONCE_ACTION = 'zymarg_wcpg_editor';
	const RL_PREFIX    = 'zymarg_wcpg_rl_editor_';
	const RL_WINDOW    = 60;
	const RL_MAX       = 30;

	/**
	 * Wire endpoints.
	 */
	public function register() {
		add_action( 'wp_ajax_zymarg_wcpg_editor_recompute_trending', array( $this, 'recompute_trending' ) );
		add_action( 'wp_ajax_zymarg_wcpg_editor_flush_buffer', array( $this, 'flush_buffer' ) );
		add_action( 'wp_ajax_zymarg_wcpg_editor_reset_trending', array( $this, 'reset_trending' ) );
		add_action( 'wp_ajax_zymarg_wcpg_editor_clear_vendor_cache', array( $this, 'clear_vendor_cache' ) );
		add_action( 'wp_ajax_zymarg_wcpg_editor_test_vendor', array( $this, 'test_vendor' ) );
	}

	/**
	 * Recompute trending top-N immediately.
	 */
	public function recompute_trending() {
		$this->guard();
		$count = Trending_Calculator::recompute();
		wp_send_json_success(
			array(
				'message' => sprintf(
					/* translators: %d: number of products cached */
					__( 'Trending recomputed. %d products cached.', 'zymarg-wcpg' ),
					$count
				),
				'meta'    => Trending_Calculator::get_meta(),
			)
		);
	}

	/**
	 * Flush event buffer.
	 */
	public function flush_buffer() {
		$this->guard();
		$flushed = Event_Buffer::flush();
		wp_send_json_success(
			array(
				'message' => sprintf(
					/* translators: %d: number of events flushed */
					__( 'Flushed %d buffered events.', 'zymarg-wcpg' ),
					$flushed
				),
				'flushed' => $flushed,
			)
		);
	}

	/**
	 * Reset trending data (engagement store + cache).
	 */
	public function reset_trending() {
		$this->guard();
		Engagement_Store::reset();
		delete_option( Trending_Calculator::CACHE_OPTION );
		delete_option( Trending_Calculator::META_KEY );
		delete_transient( Event_Buffer::TRANSIENT_KEY );
		wp_send_json_success(
			array( 'message' => __( 'Trending data reset.', 'zymarg-wcpg' ) )
		);
	}

	/**
	 * Clear cache for the vendor of a specific product.
	 */
	public function clear_vendor_cache() {
		$this->guard();
		$pid       = isset( $_POST['product_id'] ) ? absint( wp_unslash( $_POST['product_id'] ) ) : 0;
		$vendor_id = $pid ? Vendor_Resolver::resolve( $pid ) : 0;
		if ( ! $vendor_id ) {
			wp_send_json_error(
				array( 'message' => __( 'Could not resolve a vendor for that product.', 'zymarg-wcpg' ) ),
				400
			);
		}
		Vendor_Cache::flush( $vendor_id );
		wp_send_json_success(
			array(
				'message'   => __( 'Vendor cache cleared.', 'zymarg-wcpg' ),
				'vendor_id' => $vendor_id,
			)
		);
	}

	/**
	 * Run the resolution waterfall and report which step matched.
	 */
	public function test_vendor() {
		$this->guard();
		$pid = isset( $_POST['product_id'] ) ? absint( wp_unslash( $_POST['product_id'] ) ) : 0;
		if ( $pid <= 0 ) {
			wp_send_json_error(
				array( 'message' => __( 'Provide a product ID to test.', 'zymarg-wcpg' ) ),
				400
			);
		}

		$report = array(
			'product_id'      => $pid,
			'dokan_supported' => Vendor_Resolver::is_supported(),
			'dokan_version'   => Vendor_Resolver::detected_version(),
			'vendor_id'       => Vendor_Resolver::resolve( $pid ),
		);
		if ( $report['vendor_id'] ) {
			$user                     = get_user_by( 'id', $report['vendor_id'] );
			$report['vendor_name']    = $user ? $user->display_name : '';
			$report['status']         = Vendor_Resolver::check_vendor_status( $report['vendor_id'] );
			$report['product_count']  = Vendor_Resolver::count_vendor_products( $report['vendor_id'] );
			$report['author_ids']     = Vendor_Resolver::get_vendor_author_ids( $report['vendor_id'] );
			$report['cache_age_secs'] = Vendor_Cache::age_seconds( $report['vendor_id'] );
		}
		wp_send_json_success( $report );
	}

	/**
	 * Verify nonce + capability + rate limit, or terminate the request.
	 */
	private function guard() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array( 'message' => __( 'Insufficient permissions.', 'zymarg-wcpg' ) ),
				403
			);
		}
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );

		$ip   = self::get_client_ip();
		$key  = self::RL_PREFIX . sha1( $ip );
		$hits = (int) get_transient( $key );
		if ( $hits >= self::RL_MAX ) {
			wp_send_json_error(
				array( 'message' => __( 'Rate limit exceeded.', 'zymarg-wcpg' ) ),
				429
			);
		}
		set_transient( $key, $hits + 1, self::RL_WINDOW );
	}

	/**
	 * Best-effort client IP.
	 *
	 * v2.11.0: proxy headers are no longer trusted by default.
	 *
	 * HTTP_X_FORWARDED_FOR and HTTP_CF_CONNECTING_IP are supplied by the
	 * client. Reading them unconditionally meant every per-IP rate limit
	 * in the plugin could be bypassed by rotating one request header, and
	 * the daily analytics de-dup hash could be poisoned the same way. They
	 * are only consulted when the site explicitly declares that it sits
	 * behind a proxy that overwrites them:
	 *
	 *   define( 'ZYMARG_WCPG_TRUST_PROXY', true );
	 *   add_filter( 'zymarg_wcpg_trust_proxy_headers', '__return_true' );
	 *
	 * @return string
	 */
	private static function get_client_ip() {
		$remote = isset( $_SERVER['REMOTE_ADDR'] ) && ! is_array( $_SERVER['REMOTE_ADDR'] )
			? trim( (string) wp_unslash( $_SERVER['REMOTE_ADDR'] ) )
			: '';
		$remote = filter_var( $remote, FILTER_VALIDATE_IP ) ? $remote : '0.0.0.0';

		$trust = defined( 'ZYMARG_WCPG_TRUST_PROXY' ) && ZYMARG_WCPG_TRUST_PROXY;

		/**
		 * Filter whether forwarded-for style headers may be trusted.
		 *
		 * @since 2.11.0
		 * @param bool   $trust  Whether to read proxy headers.
		 * @param string $remote The raw REMOTE_ADDR value.
		 */
		if ( ! (bool) apply_filters( 'zymarg_wcpg_trust_proxy_headers', $trust, $remote ) ) {
			return $remote;
		}

		foreach ( array( 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR' ) as $key ) {
			if ( empty( $_SERVER[ $key ] ) || is_array( $_SERVER[ $key ] ) ) {
				continue;
			}
			$first = trim( explode( ',', (string) wp_unslash( $_SERVER[ $key ] ) )[0] );
			if ( filter_var( $first, FILTER_VALIDATE_IP ) ) {
				return $first;
			}
		}

		return $remote;
	}
}
