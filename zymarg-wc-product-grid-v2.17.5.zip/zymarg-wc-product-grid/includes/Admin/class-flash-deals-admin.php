<?php
/**
 * Admin curation and compliance reporting for Flash Deals.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Admin;

use Zymarg\WCPG\Query\Flash_Deals_Validator;

defined( 'ABSPATH' ) || exit;

/**
 * Class Flash_Deals_Admin
 *
 * Flash Deals is a curated source: a product appears only when an admin has
 * explicitly flagged it AND it satisfies the data contract enforced by
 * Flash_Deals_Validator. Vendors never decide, and never see this control --
 * every surface here is gated on manage_woocommerce, which Dokan vendors do
 * not hold.
 *
 * Three surfaces:
 *
 *   1. A checkbox on Product data -> General.
 *   2. Bulk "Add to Flash Deals" / "Remove from Flash Deals" actions.
 *   3. A Flash Deals column on the products list showing, per product,
 *      exactly why it is or is not live.
 *
 * Reporting deliberately covers configuration errors only. A sale that ended
 * on schedule is not a problem and is shown as a neutral state, because a
 * column that cries wolf on every completed sale is one nobody reads.
 *
 * @since 2.10.0
 */
final class Flash_Deals_Admin {

	/** Bulk action key: flag products. */
	const BULK_ADD = 'zymarg_flash_add';

	/** Bulk action key: unflag products. */
	const BULK_REMOVE = 'zymarg_flash_remove';

	/**
	 * Register every admin hook.
	 *
	 * @return void
	 */
	public static function init(): void {
		if ( ! is_admin() ) {
			return;
		}

		// Product data panel.
		add_action( 'woocommerce_product_options_general_product_data', array( __CLASS__, 'render_checkbox' ) );
		add_action( 'woocommerce_process_product_meta', array( __CLASS__, 'save_checkbox' ) );

		// Products list column.
		add_filter( 'manage_edit-product_columns', array( __CLASS__, 'add_column' ), 20 );
		add_action( 'manage_product_posts_custom_column', array( __CLASS__, 'render_column' ), 10, 2 );

		// Bulk actions.
		add_filter( 'bulk_actions-edit-product', array( __CLASS__, 'add_bulk_actions' ) );
		add_filter( 'handle_bulk_actions-edit-product', array( __CLASS__, 'handle_bulk_actions' ), 10, 3 );
		add_action( 'admin_notices', array( __CLASS__, 'bulk_notice' ) );
	}

	/**
	 * Whether the current user may curate Flash Deals.
	 *
	 * @return bool
	 */
	private static function user_can_curate() {
		return current_user_can( 'manage_woocommerce' );
	}

	/**
	 * Render the curation checkbox on Product data -> General.
	 *
	 * @return void
	 */
	public static function render_checkbox() {
		if ( ! self::user_can_curate() || ! function_exists( 'woocommerce_wp_checkbox' ) ) {
			return;
		}

		echo '<div class="options_group">';

		woocommerce_wp_checkbox(
			array(
				'id'          => Flash_Deals_Validator::FLAG_META,
				'value'       => get_post_meta( get_the_ID(), Flash_Deals_Validator::FLAG_META, true ),
				'label'       => __( 'Flash Deal', 'zymarg-wcpg' ),
				'description' => __( 'Include this product in the Flash Deals grid. It also has to meet the Flash Deals requirements -- see the Flash Deals column on the products list.', 'zymarg-wcpg' ),
				'desc_tip'    => false,
			)
		);

		echo '</div>';
	}

	/**
	 * Persist the curation checkbox.
	 *
	 * @param int $post_id Product id.
	 * @return void
	 */
	public static function save_checkbox( $post_id ) {
		if ( ! self::user_can_curate() ) {
			return;
		}

		// Nonce is verified by WooCommerce before this hook fires.
		$enabled = isset( $_POST[ Flash_Deals_Validator::FLAG_META ] ); // phpcs:ignore WordPress.Security.NonceVerification.Missing

		if ( $enabled ) {
			update_post_meta( (int) $post_id, Flash_Deals_Validator::FLAG_META, 'yes' );
		} else {
			delete_post_meta( (int) $post_id, Flash_Deals_Validator::FLAG_META );
		}

		Flash_Deals_Validator::flush_cache( (int) $post_id );
	}

	/**
	 * Add the Flash Deals column to the products list.
	 *
	 * @param array $columns Existing columns.
	 * @return array
	 */
	public static function add_column( $columns ) {
		if ( ! is_array( $columns ) || ! self::user_can_curate() ) {
			return $columns;
		}

		$columns['zymarg_flash'] = __( 'Flash Deals', 'zymarg-wcpg' );

		return $columns;
	}

	/**
	 * Render one cell of the Flash Deals column.
	 *
	 * @param string $column  Column key.
	 * @param int    $post_id Product id.
	 * @return void
	 */
	public static function render_column( $column, $post_id ) {
		if ( 'zymarg_flash' !== $column ) {
			return;
		}

		$post_id = (int) $post_id;

		if ( ! Flash_Deals_Validator::is_flagged( $post_id ) ) {
			echo '<span style="color:#8c8f94;">' . esc_html__( 'Not flagged', 'zymarg-wcpg' ) . '</span>';
			return;
		}

		$product = function_exists( 'wc_get_product' ) ? wc_get_product( $post_id ) : null;
		if ( ! $product instanceof \WC_Product ) {
			return;
		}

		$reasons = Flash_Deals_Validator::validate( $product );

		if ( ! empty( $reasons ) ) {
			echo '<span style="color:#b32d2e;font-weight:600;">' . esc_html__( 'Not live', 'zymarg-wcpg' ) . '</span>';
			echo '<ul style="margin:4px 0 0;color:#b32d2e;font-size:12px;list-style:disc;padding-left:16px;">';
			foreach ( Flash_Deals_Validator::describe( $reasons ) as $label ) {
				echo '<li>' . esc_html( $label ) . '</li>';
			}
			echo '</ul>';
			return;
		}

		// Contract satisfied -- report the lifecycle state, which is never an error.
		$state = Flash_Deals_Validator::lifecycle( $product );

		if ( Flash_Deals_Validator::STATE_LIVE === $state ) {
			echo '<span style="color:#008a20;font-weight:600;">' . esc_html__( 'Live', 'zymarg-wcpg' ) . '</span>';
			return;
		}

		$label = ( Flash_Deals_Validator::STATE_SCHEDULED === $state )
			? __( 'Scheduled', 'zymarg-wcpg' )
			: __( 'Sale ended', 'zymarg-wcpg' );

		echo '<span style="color:#8c8f94;">' . esc_html( $label ) . '</span>';
	}

	/**
	 * Register the bulk actions.
	 *
	 * @param array $actions Existing bulk actions.
	 * @return array
	 */
	public static function add_bulk_actions( $actions ) {
		if ( ! is_array( $actions ) || ! self::user_can_curate() ) {
			return $actions;
		}

		$actions[ self::BULK_ADD ]    = __( 'Add to Flash Deals', 'zymarg-wcpg' );
		$actions[ self::BULK_REMOVE ] = __( 'Remove from Flash Deals', 'zymarg-wcpg' );

		return $actions;
	}

	/**
	 * Apply a bulk action.
	 *
	 * @param string $redirect Redirect url.
	 * @param string $action   Action key.
	 * @param array  $post_ids Selected product ids.
	 * @return string
	 */
	public static function handle_bulk_actions( $redirect, $action, $post_ids ) {
		if ( self::BULK_ADD !== $action && self::BULK_REMOVE !== $action ) {
			return $redirect;
		}

		if ( ! self::user_can_curate() ) {
			return $redirect;
		}

		$adding = ( self::BULK_ADD === $action );
		$count  = 0;

		foreach ( (array) $post_ids as $post_id ) {
			$post_id = (int) $post_id;
			if ( $post_id <= 0 ) {
				continue;
			}

			if ( $adding ) {
				update_post_meta( $post_id, Flash_Deals_Validator::FLAG_META, 'yes' );
			} else {
				delete_post_meta( $post_id, Flash_Deals_Validator::FLAG_META );
			}

			Flash_Deals_Validator::flush_cache( $post_id );
			++$count;
		}

		return add_query_arg(
			array(
				'zymarg_flash_bulk'  => $adding ? 'added' : 'removed',
				'zymarg_flash_count' => $count,
			),
			$redirect
		);
	}

	/**
	 * Confirmation notice after a bulk action.
	 *
	 * @return void
	 */
	public static function bulk_notice() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		if ( empty( $_GET['zymarg_flash_bulk'] ) ) {
			return;
		}

		$mode  = sanitize_key( wp_unslash( $_GET['zymarg_flash_bulk'] ) );
		$count = isset( $_GET['zymarg_flash_count'] ) ? (int) $_GET['zymarg_flash_count'] : 0;
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		if ( 'added' !== $mode && 'removed' !== $mode ) {
			return;
		}

		$message = ( 'added' === $mode )
			/* translators: %d: number of products. */
			? sprintf( _n( '%d product added to Flash Deals.', '%d products added to Flash Deals.', $count, 'zymarg-wcpg' ), $count )
			/* translators: %d: number of products. */
			: sprintf( _n( '%d product removed from Flash Deals.', '%d products removed from Flash Deals.', $count, 'zymarg-wcpg' ), $count );

		echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( $message ) . '</p></div>';
	}
}
