<?php
/**
 * Render Log -- runtime record of what the engine actually rendered.
 *
 * The diagnostics page can prove the engine is INSTALLED correctly, but it
 * cannot answer the question that actually matters day to day: on my real
 * pages, which grids ran, which source did each one use, and did it produce
 * anything? That requires observing real front-end requests, which is what
 * this class does.
 *
 * Design notes:
 *   - Zero writes during the render itself. Entries accumulate in memory and
 *     are flushed once on shutdown, and only when something changed.
 *   - Entries are keyed by page + slot + source, so a page refreshed a
 *     thousand times produces one row with a hit counter, not a thousand rows.
 *   - The option is non-autoloaded. It is admin-only data and must never ride
 *     along on every front-end request.
 *
 * @package Zymarg\WCPG\Admin
 * @since   2.17.0
 */

namespace Zymarg\WCPG\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * Class Render_Log
 */
final class Render_Log {

	/** Option holding the rolling log. Non-autoloaded. */
	const OPTION = 'zymarg_wcpg_render_log';

	/** Option holding the current unresolved issue count (menu badge). */
	const ISSUES = 'zymarg_wcpg_issue_count';

	/** Hard cap on stored rows. Oldest rows are dropped first. */
	const MAX_ENTRIES = 60;

	/** @var array|null Details captured mid-render, consumed on completion. */
	private static $pending = null;

	/** @var array Rows touched this request. */
	private static $touched = array();

	/** @var int Issues recorded this request. */
	private static $new_issues = 0;

	/** @var bool */
	private static $booted = false;

	/**
	 * Attach to the engine pipeline. Front end AND admin.
	 *
	 * @return void
	 */
	public static function init(): void {
		if ( self::$booted ) {
			return;
		}
		self::$booted = true;

		// Late priority: we want the final collection, after every other filter.
		add_filter( 'zymarg_products', array( __CLASS__, 'capture_products' ), 9999, 3 );
		add_action( 'zymarg_product_grid_render_complete', array( __CLASS__, 'capture_complete' ), 10, 2 );
		add_action( 'zymarg_render_failed', array( __CLASS__, 'capture_render_failed' ), 10, 2 );
		add_action( 'zymarg_query_failed', array( __CLASS__, 'capture_query_failed' ), 10, 2 );
		add_action( 'shutdown', array( __CLASS__, 'persist' ), 99 );
	}

	/**
	 * Capture the queried collection plus the config that produced it.
	 *
	 * Passthrough filter -- never alters the products.
	 *
	 * @param mixed $products Product collection.
	 * @param mixed $config   Normalized config.
	 * @param mixed $context  Resolved context.
	 * @return mixed
	 */
	public static function capture_products( $products, $config = array(), $context = array() ) {
		$config = is_array( $config ) ? $config : array();

		self::$pending = array(
			'source'   => isset( $config['query']['source'] ) ? (string) $config['query']['source'] : '',
			'card'     => isset( $config['card']['template'] ) ? (string) $config['card']['template'] : '',
			'layout'   => isset( $config['layout']['type'] ) ? (string) $config['layout']['type'] : '',
			'subset'   => isset( $config['query']['current_vendor_subset'] ) ? (string) $config['query']['current_vendor_subset'] : '',
			'scope'    => isset( $config['query']['flash_vendor_scope'] ) ? (string) $config['query']['flash_vendor_scope'] : '',
			'products' => is_array( $products ) ? count( $products ) : 0,
		);

		return $products;
	}

	/**
	 * Record a completed render.
	 *
	 * @param mixed $html Rendered HTML (or the HIDE_WIDGET sentinel).
	 * @param mixed $args Original render args.
	 * @return void
	 */
	public static function capture_complete( $html, $args = array() ) {
		$args    = is_array( $args ) ? $args : array();
		$pending = is_array( self::$pending ) ? self::$pending : array();
		self::$pending = null;

		$html_str = is_string( $html ) ? $html : '';
		$bytes    = strlen( $html_str );

		// No pending capture means the query stage never ran -- a cache hit.
		$cached = empty( $pending );

		$source = isset( $pending['source'] ) ? $pending['source'] : self::source_from_args( $args );
		$count  = isset( $pending['products'] ) ? (int) $pending['products'] : -1;

		if ( $cached ) {
			$status = 'cached';
		} elseif ( 0 === $count ) {
			$status = 'empty';
		} elseif ( '' === $html_str ) {
			$status = 'blank';
		} else {
			$status = 'ok';
		}

		// A grid that found products but emitted nothing is a real fault.
		if ( 'blank' === $status ) {
			self::$new_issues++;
		}

		self::touch(
			array(
				'source'   => $source,
				'slot'     => isset( $args['slot'] ) ? (string) $args['slot'] : '',
				'template' => isset( $args['template'] ) ? (string) $args['template'] : '',
				'card'     => isset( $pending['card'] ) ? $pending['card'] : '',
				'layout'   => isset( $pending['layout'] ) ? $pending['layout'] : '',
				'subset'   => isset( $pending['subset'] ) ? $pending['subset'] : '',
				'scope'    => isset( $pending['scope'] ) ? $pending['scope'] : '',
				'products' => $count,
				'bytes'    => $bytes,
				'status'   => $status,
				'note'     => '',
			)
		);
	}

	/**
	 * Record a render exception.
	 *
	 * @param mixed $e    Throwable.
	 * @param mixed $args Render args.
	 * @return void
	 */
	public static function capture_render_failed( $e, $args = array() ) {
		self::capture_failure( 'render', $e, $args );
	}

	/**
	 * Record a query exception.
	 *
	 * @param mixed $e    Throwable.
	 * @param mixed $args Query args.
	 * @return void
	 */
	public static function capture_query_failed( $e, $args = array() ) {
		self::capture_failure( 'query', $e, $args );
	}

	/**
	 * Shared failure recorder.
	 *
	 * @param string $stage 'render' or 'query'.
	 * @param mixed  $e     Throwable.
	 * @param mixed  $args  Args.
	 * @return void
	 */
	private static function capture_failure( $stage, $e, $args ) {
		$args = is_array( $args ) ? $args : array();
		self::$pending = null;
		self::$new_issues++;

		$message = ( $e instanceof \Throwable ) ? $e->getMessage() : '';

		self::touch(
			array(
				'source'   => self::source_from_args( $args ),
				'slot'     => isset( $args['slot'] ) ? (string) $args['slot'] : '',
				'template' => isset( $args['template'] ) ? (string) $args['template'] : '',
				'card'     => '',
				'layout'   => '',
				'subset'   => '',
				'scope'    => '',
				'products' => -1,
				'bytes'    => 0,
				'status'   => 'error',
				'note'     => $stage . ': ' . substr( $message, 0, 200 ),
			)
		);
	}

	/**
	 * Best-effort source extraction from raw render args.
	 *
	 * @param array $args Render args.
	 * @return string
	 */
	private static function source_from_args( array $args ) {
		if ( isset( $args['query']['source'] ) ) {
			return (string) $args['query']['source'];
		}
		if ( isset( $args['config']['query']['source'] ) ) {
			return (string) $args['config']['query']['source'];
		}
		return '';
	}

	/**
	 * Merge a row into this request's touched set.
	 *
	 * @param array $row Row data.
	 * @return void
	 */
	private static function touch( array $row ) {
		$row['page']  = self::page_label();
		$row['url']   = self::current_url();
		$row['time']  = time();

		$key = md5( $row['page'] . '|' . $row['slot'] . '|' . $row['source'] . '|' . $row['template'] );

		self::$touched[ $key ] = $row;
	}

	/**
	 * Human label for the page being rendered.
	 *
	 * @return string
	 */
	private static function page_label() {
		if ( wp_doing_ajax() ) {
			return 'AJAX request';
		}
		if ( is_admin() ) {
			return 'Admin screen';
		}
		if ( ! did_action( 'wp' ) ) {
			return 'Early / no page context';
		}
		if ( function_exists( 'dokan_is_store_page' ) && dokan_is_store_page() ) {
			return 'Dokan store page';
		}
		if ( function_exists( 'is_product' ) && is_product() ) {
			return 'Single product';
		}
		if ( function_exists( 'is_shop' ) && is_shop() ) {
			return 'Shop archive';
		}
		if ( function_exists( 'is_product_category' ) && is_product_category() ) {
			return 'Product category';
		}
		if ( is_search() ) {
			return 'Search results';
		}
		if ( is_front_page() ) {
			return 'Front page';
		}
		if ( is_home() ) {
			return 'Blog home';
		}
		if ( is_page() ) {
			$title = get_the_title();
			return 'Page: ' . ( $title ? $title : '(untitled)' );
		}
		if ( is_singular() ) {
			$title = get_the_title();
			return 'Singular: ' . ( $title ? $title : '(untitled)' );
		}
		return 'Other';
	}

	/**
	 * Current request path, trimmed.
	 *
	 * @return string
	 */
	private static function current_url() {
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		$uri = is_string( $uri ) ? $uri : '';
		return substr( sanitize_text_field( $uri ), 0, 180 );
	}

	/**
	 * Flush this request's rows into the stored log. Runs once, on shutdown.
	 *
	 * @return void
	 */
	public static function persist(): void {
		if ( empty( self::$touched ) && 0 === self::$new_issues ) {
			return;
		}

		if ( ! empty( self::$touched ) ) {
			$log = get_option( self::OPTION, array() );
			$log = is_array( $log ) ? $log : array();

			foreach ( self::$touched as $key => $row ) {
				$row['hits'] = isset( $log[ $key ]['hits'] ) ? (int) $log[ $key ]['hits'] + 1 : 1;
				$log[ $key ]  = $row;
			}

			// Newest last -- trim from the front.
			if ( count( $log ) > self::MAX_ENTRIES ) {
				$log = array_slice( $log, -self::MAX_ENTRIES, null, true );
			}

			update_option( self::OPTION, $log, false );
			self::$touched = array();
		}

		if ( self::$new_issues > 0 ) {
			$current = (int) get_option( self::ISSUES, 0 );
			update_option( self::ISSUES, $current + self::$new_issues, false );
			self::$new_issues = 0;
		}
	}

	/**
	 * Stored rows, newest first.
	 *
	 * @return array
	 */
	public static function get_entries(): array {
		$log = get_option( self::OPTION, array() );
		$log = is_array( $log ) ? $log : array();
		return array_reverse( $log, true );
	}

	/**
	 * Current issue count for the menu badge.
	 *
	 * @return int
	 */
	public static function issue_count(): int {
		return max( 0, (int) get_option( self::ISSUES, 0 ) );
	}

	/**
	 * Reset the issue counter only.
	 *
	 * @return void
	 */
	public static function clear_issues(): void {
		update_option( self::ISSUES, 0, false );
	}

	/**
	 * Reset the log and the issue counter.
	 *
	 * @return void
	 */
	public static function clear(): void {
		update_option( self::OPTION, array(), false );
		self::clear_issues();
	}

	/**
	 * No public construction.
	 */
	private function __construct() {}
}
