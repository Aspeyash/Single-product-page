<?php
/**
 * Admin — boots every ZYMARG WC Product Grid admin submodule.
 *
 * Responsibilities (and only these):
 *   - Guard against running outside the admin context.
 *   - Initialize each admin submodule in the correct order.
 *   - Register the top-level ZYMARG admin menu (first owner;
 *     future ZYMARG plugins check before re-registering).
 *
 * This class knows nothing about menus, rendering, or diagnostics.
 * It only orchestrates admin modules.
 *
 * Boot chain:
 *   Plugin::init()
 *       ↓
 *   Admin::init()
 *       ↓
 *   Guide::init() → Engine_Diagnostics::init()
 *       ↓
 *   (future: Templates::init(), Playground::init(), Settings::init() …)
 *
 * Note: Render_Log is deliberately NOT booted here. It observes front-end
 * renders, and this class returns early outside wp-admin, so Plugin::init()
 * owns that one.
 *
 * @package Zymarg\WCPG\Admin
 * @since   1.6.1
 */

namespace Zymarg\WCPG\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * Class Admin
 */
final class Admin {

	/**
	 * Boot all admin submodules.
	 *
	 * Safe to call multiple times — the is_admin() guard and WordPress's
	 * own hook deduplication prevent duplicate registration.
	 *
	 * @return void
	 */
	public static function init(): void {
		if ( ! is_admin() ) {
			return;
		}

		// Register the top-level ZYMARG menu before any submodule needs it.
		add_action( 'admin_menu', [ __CLASS__, 'register_top_level_menu' ], 5 );

		// Sidebar parent-menu branding (Design Tokens v3 section 2.16).
		// Enqueued on every admin page. Scoped to #toplevel_page_zymarg so
		// it only paints this one menu -- and since the same slug is shared
		// by every ZYMARG plugin's admin submenu, all of them benefit from
		// this single branding call.
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue_menu_branding' ] );

		// Boot submodules — each owns its own menu registration.
		Guide::init();
		Engine_Diagnostics::init();
		Flash_Deals_Admin::init();
	}

	/**
	 * Sidebar parent-menu branding (Design Tokens v3 section 2.16).
	 *
	 * Enqueues the shared brand tokens and this plugin's menu CSS on
	 * every admin page, scoped to #toplevel_page_zymarg. Because this
	 * plugin owns the top-level "ZYMARG" menu (see
	 * register_top_level_menu()), every sibling ZYMARG plugin's admin
	 * screens live under this same slug and inherit the branded item
	 * automatically.
	 *
	 * @return void
	 */
	public static function enqueue_menu_branding(): void {
		if ( ! wp_style_is( 'zymarg-tokens', 'registered' ) ) {
			wp_register_style(
				'zymarg-tokens',
				ZYMARG_WCPG_URL . 'assets/css/zymarg-tokens.css',
				[],
				ZYMARG_WCPG_VERSION
			);
		}
		wp_enqueue_style( 'zymarg-tokens' );
		wp_enqueue_style(
			'zymarg-wcpg-menu',
			ZYMARG_WCPG_URL . 'assets/css/zymarg-wcpg-menu.css',
			[ 'zymarg-tokens' ],
			ZYMARG_WCPG_VERSION
		);
	}

	/**
	 * Register the top-level ZYMARG admin menu.
	 *
	 * Uses a global flag so future ZYMARG plugins skip re-registration.
	 * Priority 5 ensures this runs before any submodule's add_submenu_page().
	 *
	 * Menu position 3 — just below Dashboard, above Posts — signals that
	 * ZYMARG is a first-class platform.
	 *
	 * @return void
	 */
	public static function register_top_level_menu(): void {
		// Guard: only the first ZYMARG plugin to load registers the menu.
		if ( defined( 'ZYMARG_ADMIN_MENU_REGISTERED' ) ) {
			return;
		}

		define( 'ZYMARG_ADMIN_MENU_REGISTERED', true );

		// Surface unresolved engine issues as a WordPress-native count bubble.
		$menu_label = __( 'ZYMARG', 'zymarg-wcpg' );
		$issues     = class_exists( __NAMESPACE__ . '\\Render_Log' ) ? Render_Log::issue_count() : 0;

		if ( $issues > 0 ) {
			$menu_label .= sprintf(
				' <span class="update-plugins count-%1$d"><span class="update-count">%2$s</span></span>',
				(int) $issues,
				esc_html( number_format_i18n( $issues ) )
			);
		}

		add_menu_page(
			__( 'ZYMARG', 'zymarg-wcpg' ),         // Page title
			$menu_label,                             // Menu label (+ issue bubble)
			'manage_options',                        // Capability
			'zymarg',                                // Menu slug
			[ __CLASS__, 'render_dashboard' ],       // Callback
			'dashicons-layout',                      // Icon (swap for SVG later)
			3                                        // Position
		);
	}

	/**
	 * Minimal dashboard landing page.
	 *
	 * Clicking the top-level "ZYMARG" menu item lands here.
	 * Will be replaced with a proper dashboard in a future milestone.
	 *
	 * @return void
	 */
	public static function render_dashboard(): void {
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'ZYMARG', 'zymarg-wcpg' ); ?></h1>
			<p><?php esc_html_e( 'Welcome to the ZYMARG platform. Use the submenu to navigate.', 'zymarg-wcpg' ); ?></p>
		</div>
		<?php
	}

	/**
	 * No public construction — static class only.
	 */
	private function __construct() {}
}
