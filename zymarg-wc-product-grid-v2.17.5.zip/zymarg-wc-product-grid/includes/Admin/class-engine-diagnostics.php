<?php
/**
 * Engine Diagnostics — permanent developer console for the Product Grid Engine.
 *
 * Styled with ZYMARG brand design system:
 *   Primary Purple #9500a5, Magenta #bd00d1, Light Pink #fea9ff
 *   border-radius: 12px cards, 20px pills, 8px inputs
 *   box-shadow: 0 4px 20px rgba(149,0,165,0.1)
 *
 * Versions on one page:
 *   v1 — Page load confirmation
 *   v2 — Autoloader / class check
 *   v3 — Bootstrap + registry inspection
 *   v4 — Public API smoke test (timed)
 *   v5 — Render Engine direct test (timed)
 *   v6 — Query Builder test (timed)
 *   v7 — Full status dashboard: version, checks passed N/N,
 *         per-section timing, memory used
 *   v8 — Live Render Log: which real pages rendered which sources, and
 *         whether they actually produced output (2.17.0)
 *   v9 — Source Test Bench: render any source/card/layout on demand (2.17.0)
 *
 * @package Zymarg\WCPG\Admin
 * @since   1.6.2
 */

namespace Zymarg\WCPG\Admin;

defined( 'ABSPATH' ) || exit;

use Zymarg\WCPG\Bootstrap\Api_Bootstrap;
use Zymarg\WCPG\Registry\Template_Registry;
use Zymarg\WCPG\Registry\Slot_Registry;
use Zymarg\WCPG\Render\Render_Engine;
use Zymarg\WCPG\Render\Config_Normalizer;
use Zymarg\WCPG\Query\Query_Builder;
use Zymarg\WCPG\Api\Public_API;

/**
 * Class Engine_Diagnostics
 */
final class Engine_Diagnostics {

	/** @var array<string,string> */
	private const ENGINE_CLASSES = [
		'Public API'        => \Zymarg\WCPG\Api\Public_API::class,
		'Api Bootstrap'     => \Zymarg\WCPG\Bootstrap\Api_Bootstrap::class,
		'Render Engine'     => \Zymarg\WCPG\Render\Render_Engine::class,
		'Config Normalizer' => \Zymarg\WCPG\Render\Config_Normalizer::class,
		'Config Defaults'   => \Zymarg\WCPG\Render\Config_Defaults::class,
		'Context Resolver'  => \Zymarg\WCPG\Context\Context_Resolver::class,
		'Query Builder'     => \Zymarg\WCPG\Query\Query_Builder::class,
		'Query Adapter'     => \Zymarg\WCPG\Adapters\Query_Adapter::class,
		'Template Registry' => \Zymarg\WCPG\Registry\Template_Registry::class,
		'Slot Registry'     => \Zymarg\WCPG\Registry\Slot_Registry::class,
	];

	public static function init(): void {
		add_action( 'admin_menu', [ __CLASS__, 'register_page' ], 10 );
		add_action( 'admin_head',  [ __CLASS__, 'inline_styles' ] );
	}

	public static function register_page(): void {
		// NOTE: the old 'zymarg-product-grid' submenu was removed in 2.17.0.
		// It pointed at this exact same callback, so it rendered a duplicate of
		// this page -- and because inline_styles() is gated to the diagnostics
		// screen ID, it rendered completely unstyled. Nothing was lost.
		add_submenu_page(
			'zymarg',
			__( 'Engine Diagnostics', 'zymarg-wcpg' ),
			__( 'Engine Diagnostics', 'zymarg-wcpg' ),
			'manage_options',
			'zymarg-engine-diagnostics',
			[ __CLASS__, 'render_page' ]
		);
	}

	// ── Page renderer ────────────────────────────────────────────────────────

	public static function render_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) return;

		$bench = self::handle_actions();

		$page_start     = microtime( true );
		$mem_before     = memory_get_usage();

		$class_results  = self::check_classes();
		$bootstrap_ok   = Api_Bootstrap::is_initialized();
		$api_result     = self::test_public_api();
		$render_result  = self::test_render_engine();
		$query_result   = self::test_query_builder();

		$page_ms        = round( ( microtime( true ) - $page_start ) * 1000, 2 );
		$mem_used_mb    = round( ( memory_get_usage() - $mem_before ) / 1048576, 2 );
		$peak_mb        = round( memory_get_peak_usage() / 1048576, 2 );

		// Total checks count
		$total_checks = count( $class_results ) + 3; // classes + bootstrap + api + render
		$passed       = count( array_filter( $class_results ) )
		              + (int) $bootstrap_ok
		              + (int) $api_result['ok']
		              + (int) $render_result['ok']
		              + (int) $query_result['ok'];

		?>
		<div class="wrap zd-wrap">

			<!-- Header -->
			<div class="zd-header">
				<div class="zd-header__left">
					<span class="zd-header__logo">⚙️</span>
					<div>
						<h1 class="zd-header__title"><?php esc_html_e( 'Engine Diagnostics', 'zymarg-wcpg' ); ?></h1>
						<p class="zd-header__sub"><?php esc_html_e( 'ZYMARG WC Product Grid', 'zymarg-wcpg' ); ?></p>
					</div>
				</div>
				<div class="zd-header__right">
					<span class="zd-pill zd-pill--version">v<?php echo esc_html( ZYMARG_WCPG_VERSION ); ?></span>
					<span class="zd-pill <?php echo $passed === $total_checks ? 'zd-pill--pass' : 'zd-pill--fail'; ?>">
						<?php echo $passed === $total_checks ? '✓ All Systems Go' : '✗ Issues Detected'; ?>
					</span>
				</div>
			</div>

			<!-- v7 Summary cards at the TOP for instant health view -->
			<?php self::render_v7( $class_results, $bootstrap_ok, $api_result, $render_result, $query_result, $passed, $total_checks, $page_ms, $mem_used_mb, $peak_mb ); ?>

			<!-- Detailed sections below -->
			<?php self::render_v1(); ?>
			<?php self::render_v2( $class_results ); ?>
			<?php self::render_v3( $bootstrap_ok ); ?>
			<?php self::render_v4( $api_result ); ?>
			<?php self::render_v5( $render_result ); ?>
			<?php self::render_v6( $query_result ); ?>
			<?php self::render_v8(); ?>
			<?php self::render_v9( $bench ); ?>

		</div>
		<?php
	}

	// ── v1 ───────────────────────────────────────────────────────────────────

	private static function render_v1(): void { ?>
		<div class="zd-section">
			<div class="zd-section__header">
				<h2 class="zd-section__title">v1 — Page Load</h2>
				<span class="zd-badge zd-badge--pass">Pass</span>
			</div>
			<table class="zd-table">
				<tbody>
					<?php self::row( 'Page loaded', true ); ?>
					<?php self::row( 'Admin module loaded', true ); ?>
					<?php self::row( 'Engine Diagnostics initialized', true ); ?>
				</tbody>
			</table>
		</div>
	<?php }

	// ── v2 ───────────────────────────────────────────────────────────────────

	private static function check_classes(): array {
		$r = [];
		foreach ( self::ENGINE_CLASSES as $label => $class ) {
			$r[ $label ] = class_exists( $class );
		}
		return $r;
	}

	private static function render_v2( array $results ): void {
		$all_ok = ! in_array( false, $results, true ); ?>
		<div class="zd-section">
			<div class="zd-section__header">
				<h2 class="zd-section__title">v2 — Autoloader &amp; Classes</h2>
				<span class="zd-badge <?php echo $all_ok ? 'zd-badge--pass' : 'zd-badge--fail'; ?>">
					<?php echo $all_ok ? 'All Loaded' : 'Missing Classes'; ?>
				</span>
			</div>
			<table class="zd-table">
				<tbody>
					<?php foreach ( $results as $label => $ok ) : ?>
						<?php self::row( $label, $ok ); ?>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	<?php }

	// ── v3 ───────────────────────────────────────────────────────────────────

	private static function render_v3( bool $ok ): void {
		$templates = Template_Registry::all();
		$slots     = Slot_Registry::all(); ?>
		<div class="zd-section">
			<div class="zd-section__header">
				<h2 class="zd-section__title">v3 — Bootstrap &amp; Registries</h2>
				<span class="zd-badge <?php echo $ok ? 'zd-badge--pass' : 'zd-badge--fail'; ?>">
					<?php echo $ok ? 'Initialized' : 'Not Initialized'; ?>
				</span>
			</div>
			<table class="zd-table">
				<tbody>
					<?php self::row( 'Api_Bootstrap initialized', $ok ); ?>
					<?php self::row( 'Templates registered', count( $templates ) > 0, (string) count( $templates ) ); ?>
					<?php self::row( 'Slots registered', count( $slots ) > 0, (string) count( $slots ) ); ?>
				</tbody>
			</table>

			<?php if ( ! empty( $templates ) ) : ?>
				<h3 class="zd-sub-title"><?php esc_html_e( 'Registered Templates', 'zymarg-wcpg' ); ?></h3>
				<table class="zd-table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Slug', 'zymarg-wcpg' ); ?></th>
							<th><?php esc_html_e( 'Label', 'zymarg-wcpg' ); ?></th>
							<th><?php esc_html_e( 'Default Source', 'zymarg-wcpg' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $templates as $slug => $record ) : ?>
						<tr>
							<td><code class="zd-code"><?php echo esc_html( $slug ); ?></code></td>
							<td><?php echo esc_html( $record['label'] ?? '—' ); ?></td>
							<td><code class="zd-code"><?php echo esc_html( $record['config']['query']['source'] ?? '—' ); ?></code></td>
						</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>

			<?php if ( ! empty( $slots ) ) : ?>
				<h3 class="zd-sub-title"><?php esc_html_e( 'Registered Slots', 'zymarg-wcpg' ); ?></h3>
				<table class="zd-table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Slot', 'zymarg-wcpg' ); ?></th>
							<th><?php esc_html_e( 'Assigned Template', 'zymarg-wcpg' ); ?></th>
							<th><?php esc_html_e( 'Label', 'zymarg-wcpg' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $slots as $slug => $record ) : ?>
						<tr>
							<td><code class="zd-code"><?php echo esc_html( $slug ); ?></code></td>
							<td><code class="zd-code"><?php echo esc_html( $record['template'] ?? '—' ); ?></code></td>
							<td><?php echo esc_html( $record['label'] ?? '—' ); ?></td>
						</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>
		</div>
	<?php }

	// ── v4 ───────────────────────────────────────────────────────────────────

	private static function test_public_api(): array {
		$start = microtime( true );
		try {
			$html = Public_API::render( [
				'config' => [
					'query'  => [ 'source' => 'all', 'limit' => 4 ],
					'layout' => [ 'type' => 'grid', 'columns' => 4 ],
					'card'   => [],
				],
			] );
			return [
				'ok'     => strlen( $html ) > 0,
				'type'   => gettype( $html ),
				'length' => strlen( $html ),
				'ms'     => round( ( microtime( true ) - $start ) * 1000, 2 ),
				'error'  => '',
			];
		} catch ( \Throwable $e ) {
			return [ 'ok' => false, 'type' => 'error', 'length' => 0, 'ms' => round( ( microtime( true ) - $start ) * 1000, 2 ), 'error' => $e->getMessage() ];
		}
	}

	private static function render_v4( array $r ): void { ?>
		<div class="zd-section">
			<div class="zd-section__header">
				<h2 class="zd-section__title">v4 — Public API Smoke Test</h2>
				<span class="zd-badge <?php echo $r['ok'] ? 'zd-badge--pass' : 'zd-badge--fail'; ?>">
					<?php echo $r['ok'] ? 'Pass' : 'Fail'; ?>
				</span>
				<span class="zd-timing">⏱ <?php echo esc_html( $r['ms'] ); ?> ms</span>
			</div>
			<table class="zd-table">
				<tbody>
					<?php self::row( 'Public_API::render() returned HTML', $r['ok'] ); ?>
					<?php self::row( 'Return type', true, esc_html( $r['type'] ) ); ?>
					<?php self::row( 'HTML length', $r['length'] > 0, number_format( $r['length'] ) . ' bytes' ); ?>
					<?php self::row( 'Execution time', true, $r['ms'] . ' ms' ); ?>
					<?php if ( $r['error'] ) self::row( 'Error', false, esc_html( $r['error'] ) ); ?>
				</tbody>
			</table>
		</div>
	<?php }

	// ── v5 ───────────────────────────────────────────────────────────────────

	private static function test_render_engine(): array {
		$start = microtime( true );
		try {
			$config = Config_Normalizer::normalize( [
				'layout' => [ 'type' => 'grid', 'columns' => 4 ],
				'query'  => [ 'source' => 'all' ],
				'card'   => [],
			] );
			$html = Render_Engine::render( $config, [] );
			return [ 'ok' => strlen( $html ) > 0, 'length' => strlen( $html ), 'ms' => round( ( microtime( true ) - $start ) * 1000, 2 ), 'error' => '' ];
		} catch ( \Throwable $e ) {
			return [ 'ok' => false, 'length' => 0, 'ms' => round( ( microtime( true ) - $start ) * 1000, 2 ), 'error' => $e->getMessage() ];
		}
	}

	private static function render_v5( array $r ): void { ?>
		<div class="zd-section">
			<div class="zd-section__header">
				<h2 class="zd-section__title">v5 — Render Engine Direct Test</h2>
				<span class="zd-badge <?php echo $r['ok'] ? 'zd-badge--pass' : 'zd-badge--fail'; ?>">
					<?php echo $r['ok'] ? 'Pass' : 'Fail'; ?>
				</span>
				<span class="zd-timing">⏱ <?php echo esc_html( $r['ms'] ); ?> ms</span>
			</div>
			<table class="zd-table">
				<tbody>
					<?php self::row( 'Render_Engine::render() returned HTML', $r['ok'] ); ?>
					<?php self::row( 'HTML length (empty products)', $r['length'] > 0, number_format( $r['length'] ) . ' bytes' ); ?>
					<?php self::row( 'Execution time', true, $r['ms'] . ' ms' ); ?>
					<?php if ( $r['error'] ) self::row( 'Error', false, esc_html( $r['error'] ) ); ?>
				</tbody>
			</table>
		</div>
	<?php }

	// ── v6 ───────────────────────────────────────────────────────────────────

	private static function test_query_builder(): array {
		$start = microtime( true );
		try {
			$result = Query_Builder::get_products( [ 'source' => 'all', 'total_products' => 4 ] );
			if ( ! is_array( $result ) ) {
				return [ 'ok' => false, 'count' => 0, 'names' => [], 'ms' => round( ( microtime( true ) - $start ) * 1000, 2 ), 'error' => 'HIDE_WIDGET or non-array' ];
			}
			$names = [];
			foreach ( $result as $p ) {
				if ( $p instanceof \WC_Product ) $names[] = $p->get_name();
			}
			return [ 'ok' => count( $result ) > 0, 'count' => count( $result ), 'names' => $names, 'ms' => round( ( microtime( true ) - $start ) * 1000, 2 ), 'error' => '' ];
		} catch ( \Throwable $e ) {
			return [ 'ok' => false, 'count' => 0, 'names' => [], 'ms' => round( ( microtime( true ) - $start ) * 1000, 2 ), 'error' => $e->getMessage() ];
		}
	}

	private static function render_v6( array $r ): void { ?>
		<div class="zd-section">
			<div class="zd-section__header">
				<h2 class="zd-section__title">v6 — Query Builder Test</h2>
				<span class="zd-badge <?php echo $r['ok'] ? 'zd-badge--pass' : 'zd-badge--fail'; ?>">
					<?php echo $r['ok'] ? 'Pass' : 'Fail'; ?>
				</span>
				<span class="zd-timing">⏱ <?php echo esc_html( $r['ms'] ); ?> ms</span>
			</div>
			<table class="zd-table">
				<tbody>
					<?php self::row( 'Query_Builder::get_products() returned results', $r['ok'] ); ?>
					<?php self::row( 'Products found', $r['count'] > 0, (string) $r['count'] ); ?>
					<?php self::row( 'Execution time', true, $r['ms'] . ' ms' ); ?>
					<?php if ( $r['error'] ) self::row( 'Error', false, esc_html( $r['error'] ) ); ?>
				</tbody>
			</table>
			<?php if ( ! empty( $r['names'] ) ) : ?>
				<div class="zd-product-list">
					<?php foreach ( $r['names'] as $name ) : ?>
						<span class="zd-product-pill"><?php echo esc_html( $name ); ?></span>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
	<?php }

	// ── v7 — Dashboard ───────────────────────────────────────────────────────

	private static function render_v7(
		array $class_results,
		bool  $bootstrap_ok,
		array $api_result,
		array $render_result,
		array $query_result,
		int   $passed,
		int   $total,
		float $page_ms,
		float $mem_mb,
		float $peak_mb
	): void {
		$classes_ok   = ! in_array( false, $class_results, true );
		$overall_pass = $classes_ok && $bootstrap_ok && $api_result['ok'] && $render_result['ok'] && $query_result['ok'];
		?>
		<div class="zd-dashboard">

			<!-- Overall status bar -->
			<div class="zd-status-bar <?php echo $overall_pass ? 'zd-status-bar--pass' : 'zd-status-bar--fail'; ?>">
				<div class="zd-status-bar__left">
					<span class="zd-status-bar__icon"><?php echo $overall_pass ? '✓' : '✗'; ?></span>
					<span class="zd-status-bar__label">
						<?php echo $overall_pass ? esc_html__( 'All Systems Healthy', 'zymarg-wcpg' ) : esc_html__( 'Issues Detected', 'zymarg-wcpg' ); ?>
					</span>
				</div>
				<div class="zd-status-bar__right">
					<span><?php echo esc_html( $passed . ' / ' . $total ); ?> <?php esc_html_e( 'checks passed', 'zymarg-wcpg' ); ?></span>
				</div>
			</div>

			<!-- Metric cards -->
			<div class="zd-cards">

				<?php self::metric_card(
					'🔖',
					__( 'Engine Version', 'zymarg-wcpg' ),
					'v' . ZYMARG_WCPG_VERSION,
					'neutral'
				); ?>

				<?php self::metric_card(
					'✅',
					__( 'Checks Passed', 'zymarg-wcpg' ),
					$passed . ' / ' . $total,
					$passed === $total ? 'pass' : 'fail'
				); ?>

				<?php self::metric_card(
					'🚀',
					__( 'Public API', 'zymarg-wcpg' ),
					$api_result['ms'] . ' ms',
					$api_result['ok'] ? 'pass' : 'fail',
					number_format( $api_result['length'] ) . ' bytes'
				); ?>

				<?php self::metric_card(
					'🖼️',
					__( 'Render Engine', 'zymarg-wcpg' ),
					$render_result['ms'] . ' ms',
					$render_result['ok'] ? 'pass' : 'fail',
					$render_result['ok'] ? 'Healthy' : 'Failed'
				); ?>

				<?php self::metric_card(
					'🔍',
					__( 'Query Builder', 'zymarg-wcpg' ),
					$query_result['ms'] . ' ms',
					$query_result['ok'] ? 'pass' : 'fail',
					$query_result['count'] . ' products'
				); ?>

				<?php self::metric_card(
					'📋',
					__( 'Templates', 'zymarg-wcpg' ),
					(string) count( Template_Registry::all() ),
					count( Template_Registry::all() ) > 0 ? 'pass' : 'fail',
					'registered'
				); ?>

				<?php self::metric_card(
					'🔗',
					__( 'Slots', 'zymarg-wcpg' ),
					(string) count( Slot_Registry::all() ),
					count( Slot_Registry::all() ) > 0 ? 'pass' : 'fail',
					'registered'
				); ?>

				<?php self::metric_card(
					'⏱',
					__( 'Page Execution', 'zymarg-wcpg' ),
					$page_ms . ' ms',
					'neutral'
				); ?>

				<?php self::metric_card(
					'💾',
					__( 'Memory Used', 'zymarg-wcpg' ),
					$mem_mb . ' MB',
					'neutral',
					'Peak ' . $peak_mb . ' MB'
				); ?>

				<?php self::metric_card(
					'🏗️',
					__( 'Bootstrap', 'zymarg-wcpg' ),
					$bootstrap_ok ? __( 'Initialized', 'zymarg-wcpg' ) : __( 'Not Ready', 'zymarg-wcpg' ),
					$bootstrap_ok ? 'pass' : 'fail'
				); ?>

			</div>
		</div>
	<?php }

	// ── Shared render helpers ─────────────────────────────────────────────────

	private static function row( string $label, bool $ok, string $value = '' ): void { ?>
		<tr class="<?php echo $ok ? '' : 'zd-row--fail'; ?>">
			<th class="zd-table__label"><?php echo esc_html( $label ); ?></th>
			<td class="zd-table__value">
				<span class="zd-icon"><?php echo $ok ? '✅' : '❌'; ?></span>
				<?php if ( $value !== '' ) : ?>
					<code class="zd-code"><?php echo esc_html( $value ); ?></code>
				<?php endif; ?>
			</td>
		</tr>
	<?php }

	private static function metric_card( string $icon, string $title, string $value, string $state, string $sub = '' ): void {
		$cls = 'zd-card zd-card--' . $state; ?>
		<div class="<?php echo esc_attr( $cls ); ?>">
			<div class="zd-card__icon"><?php echo $icon; ?></div>
			<div class="zd-card__title"><?php echo esc_html( $title ); ?></div>
			<div class="zd-card__value"><?php echo esc_html( $value ); ?></div>
			<?php if ( $sub ) : ?>
				<div class="zd-card__sub"><?php echo esc_html( $sub ); ?></div>
			<?php endif; ?>
		</div>
	<?php }

	// ── Inline styles ─────────────────────────────────────────────────────────

	public static function inline_styles(): void {
		$screen = get_current_screen();
		if ( ! $screen || strpos( $screen->id, 'zymarg-engine-diagnostics' ) === false ) return;
		?>
		<style>
		/* ── Reset & base ── */
		.zd-wrap { max-width: 1200px; padding: 20px 0 40px; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }

		/* ── Header ── */
		.zd-header { display: flex; align-items: center; justify-content: space-between; background: linear-gradient(135deg, #9500a5 0%, #bd00d1 100%); border-radius: 12px; padding: 24px 28px; margin-bottom: 24px; box-shadow: 0 4px 20px rgba(149,0,165,0.25); }
		.zd-header__left { display: flex; align-items: center; gap: 16px; }
		.zd-header__logo { font-size: 32px; }
		.zd-header__title { margin: 0; font-size: 22px; font-weight: 700; color: #fff; }
		.zd-header__sub { margin: 4px 0 0; font-size: 13px; color: rgba(255,255,255,0.75); }
		.zd-header__right { display: flex; align-items: center; gap: 10px; }

		/* ── Pills ── */
		.zd-pill { display: inline-flex; align-items: center; padding: 5px 14px; border-radius: 20px; font-size: 12px; font-weight: 600; }
		.zd-pill--version { background: rgba(255,255,255,0.2); color: #fff; }
		.zd-pill--pass { background: #28a745; color: #fff; }
		.zd-pill--fail { background: #dc3545; color: #fff; }

		/* ── Dashboard ── */
		.zd-dashboard { margin-bottom: 28px; }

		/* ── Status bar ── */
		.zd-status-bar { display: flex; align-items: center; justify-content: space-between; padding: 14px 20px; border-radius: 12px; margin-bottom: 16px; font-weight: 600; font-size: 14px; }
		.zd-status-bar--pass { background: linear-gradient(135deg, #28a745, #20c952); color: #fff; box-shadow: 0 4px 20px rgba(40,167,69,0.25); }
		.zd-status-bar--fail { background: linear-gradient(135deg, #dc3545, #e84055); color: #fff; box-shadow: 0 4px 20px rgba(220,53,69,0.25); }
		.zd-status-bar__left { display: flex; align-items: center; gap: 10px; }
		.zd-status-bar__icon { font-size: 18px; }

		/* ── Metric cards ── */
		.zd-cards { display: grid; grid-template-columns: repeat( auto-fill, minmax( 180px, 1fr ) ); gap: 14px; }
		.zd-card { background: #fff; border-radius: 12px; padding: 18px 16px; border: 1.5px solid #e8d5ff; box-shadow: 0 4px 20px rgba(149,0,165,0.07); transition: transform .15s ease; }
		.zd-card:hover { transform: translateY(-2px); box-shadow: 0 8px 28px rgba(149,0,165,0.13); }
		.zd-card--pass { border-color: #28a745; }
		.zd-card--fail { border-color: #dc3545; background: #fff8f8; }
		.zd-card--neutral { border-color: #e8d5ff; }
		.zd-card__icon { font-size: 22px; margin-bottom: 8px; }
		.zd-card__title { font-size: 11px; text-transform: uppercase; letter-spacing: .06em; color: #857183; margin-bottom: 6px; }
		.zd-card--pass .zd-card__title { color: #28a745; }
		.zd-card--fail .zd-card__title { color: #dc3545; }
		.zd-card__value { font-size: 18px; font-weight: 700; color: #1a1a2e; }
		.zd-card--pass .zd-card__value { color: #28a745; }
		.zd-card--fail .zd-card__value { color: #dc3545; }
		.zd-card__sub { font-size: 11px; color: #857183; margin-top: 4px; }

		/* ── Sections ── */
		.zd-section { background: #fff; border: 1.5px solid #e8d5ff; border-radius: 12px; padding: 20px 24px; margin-bottom: 16px; box-shadow: 0 4px 20px rgba(149,0,165,0.05); }
		.zd-section__header { display: flex; align-items: center; gap: 10px; margin-bottom: 14px; }
		.zd-section__title { margin: 0; font-size: 13px; font-weight: 700; text-transform: uppercase; letter-spacing: .05em; color: #6b0077; flex: 1; }

		/* ── Badges ── */
		.zd-badge { display: inline-flex; align-items: center; padding: 3px 12px; border-radius: 20px; font-size: 11px; font-weight: 700; }
		.zd-badge--pass { background: #e6f9ed; color: #28a745; border: 1px solid #28a745; }
		.zd-badge--fail { background: #fde8ea; color: #dc3545; border: 1px solid #dc3545; }

		/* ── Timing label ── */
		.zd-timing { font-size: 12px; color: #9500a5; font-weight: 600; background: #fea9ff22; padding: 2px 10px; border-radius: 20px; border: 1px solid #fea9ff; }

		/* ── Sub-titles ── */
		.zd-sub-title { font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: .05em; color: #9500a5; margin: 18px 0 8px; }

		/* ── Tables ── */
		.zd-table { width: 100%; border-collapse: collapse; font-size: 13px; }
		.zd-table th, .zd-table td { padding: 9px 12px; border-bottom: 1px solid #f0e6ff; text-align: left; }
		.zd-table thead th { background: linear-gradient(135deg, #9500a5 0%, #bd00d1 100%); color: #fff; font-size: 11px; text-transform: uppercase; letter-spacing: .05em; }
		.zd-table tbody tr:last-child th,
		.zd-table tbody tr:last-child td { border-bottom: none; }
		.zd-table tbody tr:hover { background: #fdf5ff; }
		.zd-row--fail td, .zd-row--fail th { background: #fff8f8 !important; }
		.zd-table__label { width: 260px; font-weight: 600; color: #1a1a2e; }
		.zd-table__value { display: flex; align-items: center; gap: 8px; }
		.zd-icon { font-size: 14px; }

		/* ── Code ── */
		.zd-code { background: #f5eeff; color: #6b0077; padding: 2px 7px; border-radius: 4px; font-family: monospace; font-size: 12px; }

		/* ── Product pills ── */
		.zd-product-list { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 12px; }
		.zd-product-pill { background: linear-gradient(135deg, #fea9ff 0%, #bd00d1 100%); color: #fff; padding: 4px 14px; border-radius: 20px; font-size: 12px; font-weight: 600; }
		</style>
		<?php
	}

	// ── Actions (clear log / clear issues / run test bench) ────────────────

	/**
	 * Handle POST actions for this screen.
	 *
	 * @return array|null Test bench result, if one was requested.
	 */
	private static function handle_actions(): ?array {
		if ( empty( $_POST['zymarg_diag_action'] ) ) {
			return null;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return null;
		}
		$nonce = isset( $_POST['zymarg_diag_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['zymarg_diag_nonce'] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, 'zymarg_diag' ) ) {
			return null;
		}

		$action = sanitize_key( wp_unslash( $_POST['zymarg_diag_action'] ) );

		if ( 'clear_log' === $action ) {
			Render_Log::clear();
			return null;
		}
		if ( 'clear_issues' === $action ) {
			Render_Log::clear_issues();
			return null;
		}
		if ( 'bench' !== $action ) {
			return null;
		}

		return self::run_bench(
			array(
				'source'  => isset( $_POST['zb_source'] ) ? sanitize_key( wp_unslash( $_POST['zb_source'] ) ) : 'all',
				'limit'   => isset( $_POST['zb_limit'] ) ? absint( wp_unslash( $_POST['zb_limit'] ) ) : 4,
				'layout'  => isset( $_POST['zb_layout'] ) ? sanitize_key( wp_unslash( $_POST['zb_layout'] ) ) : 'grid',
				'card'    => isset( $_POST['zb_card'] ) ? sanitize_key( wp_unslash( $_POST['zb_card'] ) ) : 'classic',
				'subset'  => isset( $_POST['zb_subset'] ) ? sanitize_key( wp_unslash( $_POST['zb_subset'] ) ) : 'all',
				'scope'   => isset( $_POST['zb_scope'] ) ? sanitize_key( wp_unslash( $_POST['zb_scope'] ) ) : 'auto',
				'preview' => ! empty( $_POST['zb_preview'] ),
			)
		);
	}

	/**
	 * Execute one on-demand render and report exactly what came back.
	 *
	 * @param array $req Bench request.
	 * @return array
	 */
	private static function run_bench( array $req ): array {
		$out = array(
			'req'      => $req,
			'ok'       => false,
			'status'   => 'error',
			'message'  => '',
			'products' => array(),
			'count'    => 0,
			'bytes'    => 0,
			'ms'       => 0.0,
			'html'     => '',
		);

		if ( ! Api_Bootstrap::is_initialized() ) {
			$out['message'] = __( 'Engine not initialized.', 'zymarg-wcpg' );
			return $out;
		}
		if ( ! Public_API::has_source( $req['source'] ) ) {
			$out['message'] = sprintf(
				/* translators: %s: source key */
				__( 'Unknown source "%s". The engine would silently fall back to "all".', 'zymarg-wcpg' ),
				$req['source']
			);
			return $out;
		}

		$limit = max( 1, min( 24, (int) $req['limit'] ) );

		$query = array(
			'source' => $req['source'],
			'limit'  => $limit,
		);
		if ( 'current_vendor' === $req['source'] ) {
			$query['current_vendor_subset'] = $req['subset'];
		}
		if ( 'flash_deals' === $req['source'] ) {
			$query['flash_vendor_scope'] = $req['scope'];
		}

		$args = array(
			'query'  => $query,
			'config' => array(
				'layout' => array( 'type' => $req['layout'] ),
				'card'   => array( 'template' => $req['card'] ),
			),
		);

		$start = microtime( true );

		try {
			$found = Public_API::query( array( 'query' => $query, 'limit' => $limit ) );

			if ( is_array( $found ) ) {
				$list = isset( $found['products'] ) && is_array( $found['products'] ) ? $found['products'] : $found;
				foreach ( $list as $p ) {
					if ( is_object( $p ) && method_exists( $p, 'get_name' ) ) {
						$out['products'][] = $p->get_name();
					} elseif ( is_numeric( $p ) ) {
						$out['products'][] = '#' . (int) $p;
					}
				}
			}

			$html = Public_API::render( $args );
			$out['ms'] = round( ( microtime( true ) - $start ) * 1000, 2 );

			if ( Public_API::HIDE_WIDGET === $html ) {
				$out['status']  = 'hidden';
				$out['message'] = __( 'Source returned the hide signal — no products matched, so the whole block would be hidden on the page.', 'zymarg-wcpg' );
				return $out;
			}

			$html          = is_string( $html ) ? $html : '';
			$out['bytes']  = strlen( $html );
			$out['count']  = count( $out['products'] );
			$out['html']   = $html;

			if ( '' === $html ) {
				$out['status']  = 'blank';
				$out['message'] = __( 'Rendered empty output. Products were found but nothing was drawn — this is a real fault.', 'zymarg-wcpg' );
				return $out;
			}

			$out['ok']      = true;
			$out['status']  = 'ok';
			$out['message'] = __( 'Rendered successfully.', 'zymarg-wcpg' );
			return $out;

		} catch ( \Throwable $e ) {
			$out['ms']      = round( ( microtime( true ) - $start ) * 1000, 2 );
			$out['message'] = $e->getMessage();
			return $out;
		}
	}

	// ── v8 — Live Render Log ──────────────────────────────────────

	/**
	 * What the engine actually rendered on real front-end requests.
	 *
	 * @return void
	 */
	private static function render_v8(): void {
		$entries = Render_Log::get_entries();
		$issues  = Render_Log::issue_count();
		?>
		<style>
		.zd-bench-form { display: flex; flex-wrap: wrap; gap: 14px; align-items: flex-end; margin: 4px 0 18px; }
		.zd-field { display: flex; flex-direction: column; gap: 5px; }
		.zd-field label { font-size: 11px; font-weight: 700; text-transform: uppercase;
			letter-spacing: .04em; color: #9500a5; }
		.zd-field select, .zd-field input[type=number] { border-radius: 8px; border: 1px solid #f0d6f3;
			padding: 5px 10px; min-width: 150px; }
		.zd-btn { background: linear-gradient(135deg, #9500a5 0%, #bd00d1 100%); color: #fff;
			border: none; border-radius: 20px; padding: 8px 22px; font-size: 13px; font-weight: 600;
			cursor: pointer; }
		.zd-btn:hover { opacity: .9; color: #fff; }
		.zd-btn--ghost { background: #faf0fc; color: #9500a5; border: 1px solid #f0d6f3; }
		.zd-btn--ghost:hover { color: #9500a5; }
		.zd-tag { display: inline-block; border-radius: 20px; padding: 3px 11px; font-size: 11px;
			font-weight: 700; text-transform: uppercase; letter-spacing: .03em; }
		.zd-tag--ok { background: #edfaef; color: #008a20; }
		.zd-tag--cached { background: #eef4fb; color: #2271b1; }
		.zd-tag--empty { background: #fcf7e8; color: #996800; }
		.zd-tag--hidden { background: #f4f4f5; color: #646970; }
		.zd-tag--blank, .zd-tag--error { background: #fcf0f1; color: #b32d2e; }
		.zd-preview { border: 1px dashed #f0d6f3; border-radius: 12px; padding: 18px;
			margin-top: 14px; background: #fdfdfd; }
		.zd-inline-form { display: inline-block; margin-left: 8px; }
		</style>

		<div class="zd-section">
			<div class="zd-section__header">
				<h2 class="zd-section__title"><?php esc_html_e( 'v8 — Live Render Log', 'zymarg-wcpg' ); ?></h2>
				<span class="zd-badge <?php echo $issues > 0 ? 'zd-badge--fail' : 'zd-badge--pass'; ?>">
					<?php
					echo $issues > 0
						? esc_html( sprintf( /* translators: %d: issue count */ _n( '%d issue', '%d issues', $issues, 'zymarg-wcpg' ), $issues ) )
						: esc_html__( 'No issues', 'zymarg-wcpg' );
					?>
				</span>
			</div>

			<p class="zd-sub-title">
				<?php esc_html_e( 'Every grid the engine rendered on a real request: which page it was on, which source it used, and whether it actually produced output. Repeat visits increment the hit counter rather than adding rows.', 'zymarg-wcpg' ); ?>
			</p>

			<?php if ( empty( $entries ) ) : ?>
				<div class="zd-status-bar">
					<span class="zd-status-bar__left">
						<?php esc_html_e( 'Nothing recorded yet. Visit a page on the front end that contains a grid, then reload this screen.', 'zymarg-wcpg' ); ?>
					</span>
				</div>
			<?php else : ?>
				<table class="zd-table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Page', 'zymarg-wcpg' ); ?></th>
							<th><?php esc_html_e( 'Source', 'zymarg-wcpg' ); ?></th>
							<th><?php esc_html_e( 'Layout / Card', 'zymarg-wcpg' ); ?></th>
							<th><?php esc_html_e( 'Products', 'zymarg-wcpg' ); ?></th>
							<th><?php esc_html_e( 'Output', 'zymarg-wcpg' ); ?></th>
							<th><?php esc_html_e( 'Status', 'zymarg-wcpg' ); ?></th>
							<th><?php esc_html_e( 'Hits', 'zymarg-wcpg' ); ?></th>
							<th><?php esc_html_e( 'Last seen', 'zymarg-wcpg' ); ?></th>
						</tr>
					</thead>
					<tbody>
					<?php foreach ( $entries as $e ) :
						$status = isset( $e['status'] ) ? (string) $e['status'] : 'ok';
						$bad    = in_array( $status, array( 'error', 'blank' ), true );
						$source = ! empty( $e['source'] ) ? (string) $e['source'] : '—';
						if ( ! empty( $e['subset'] ) && 'all' !== $e['subset'] ) {
							$source .= ' / ' . $e['subset'];
						}
						if ( ! empty( $e['scope'] ) && 'auto' !== $e['scope'] ) {
							$source .= ' / ' . $e['scope'];
						}
						$count = isset( $e['products'] ) ? (int) $e['products'] : -1;
						?>
						<tr<?php echo $bad ? ' class="zd-row--fail"' : ''; ?>>
							<td>
								<strong><?php echo esc_html( isset( $e['page'] ) ? $e['page'] : '' ); ?></strong>
								<?php if ( ! empty( $e['url'] ) ) : ?>
									<br><span class="zd-timing"><?php echo esc_html( $e['url'] ); ?></span>
								<?php endif; ?>
								<?php if ( ! empty( $e['slot'] ) ) : ?>
									<br><span class="zd-timing"><?php echo esc_html( 'slot: ' . $e['slot'] ); ?></span>
								<?php endif; ?>
							</td>
							<td><code class="zd-code"><?php echo esc_html( $source ); ?></code></td>
							<td><?php echo esc_html( trim( ( isset( $e['layout'] ) ? $e['layout'] : '' ) . ' / ' . ( isset( $e['card'] ) ? $e['card'] : '' ), ' /' ) ); ?></td>
							<td><?php echo $count < 0 ? '—' : esc_html( (string) $count ); ?></td>
							<td><?php echo empty( $e['bytes'] ) ? '—' : esc_html( size_format( (int) $e['bytes'] ) ); ?></td>
							<td>
								<span class="zd-tag zd-tag--<?php echo esc_attr( $status ); ?>"><?php echo esc_html( $status ); ?></span>
								<?php if ( ! empty( $e['note'] ) ) : ?>
									<br><span class="zd-timing"><?php echo esc_html( $e['note'] ); ?></span>
								<?php endif; ?>
							</td>
							<td><?php echo esc_html( (string) ( isset( $e['hits'] ) ? (int) $e['hits'] : 1 ) ); ?></td>
							<td><span class="zd-timing"><?php
								echo esc_html(
									empty( $e['time'] )
										? '—'
										: sprintf( /* translators: %s: human time diff */ __( '%s ago', 'zymarg-wcpg' ), human_time_diff( (int) $e['time'], time() ) )
								);
							?></span></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>

			<form method="post" class="zd-inline-form">
				<?php wp_nonce_field( 'zymarg_diag', 'zymarg_diag_nonce' ); ?>
				<input type="hidden" name="zymarg_diag_action" value="clear_log">
				<button type="submit" class="zd-btn zd-btn--ghost"><?php esc_html_e( 'Clear log', 'zymarg-wcpg' ); ?></button>
			</form>
			<form method="post" class="zd-inline-form">
				<?php wp_nonce_field( 'zymarg_diag', 'zymarg_diag_nonce' ); ?>
				<input type="hidden" name="zymarg_diag_action" value="clear_issues">
				<button type="submit" class="zd-btn zd-btn--ghost"><?php esc_html_e( 'Clear issue count', 'zymarg-wcpg' ); ?></button>
			</form>
		</div>
		<?php
	}

	// ── v9 — Source Test Bench ────────────────────────────────────

	/**
	 * Render any source on demand, without touching a page.
	 *
	 * @param array|null $bench Result from a submitted run.
	 * @return void
	 */
	private static function render_v9( ?array $bench ): void {
		$registry = Query_Builder::get_registry();
		$sources  = is_array( $registry ) ? array_keys( $registry ) : array( 'all' );
		$cards    = apply_filters( 'zymarg_card_template_labels', array() );
		$cards    = is_array( $cards ) && ! empty( $cards ) ? array_keys( $cards ) : array( 'classic' );
		$req      = isset( $bench['req'] ) ? $bench['req'] : array();
		$sel      = static function ( $key, $val, $fallback ) use ( $req ) {
			$current = isset( $req[ $key ] ) ? $req[ $key ] : $fallback;
			return selected( $current, $val, false );
		};
		?>
		<div class="zd-section">
			<div class="zd-section__header">
				<h2 class="zd-section__title"><?php esc_html_e( 'v9 — Source Test Bench', 'zymarg-wcpg' ); ?></h2>
			</div>
			<p class="zd-sub-title">
				<?php esc_html_e( 'Run any source through the real pipeline right here. Use it to prove a source works before you place a shortcode, and to see exactly why one returns nothing.', 'zymarg-wcpg' ); ?>
			</p>

			<form method="post" class="zd-bench-form">
				<?php wp_nonce_field( 'zymarg_diag', 'zymarg_diag_nonce' ); ?>
				<input type="hidden" name="zymarg_diag_action" value="bench">

				<span class="zd-field">
					<label for="zb_source"><?php esc_html_e( 'Source', 'zymarg-wcpg' ); ?></label>
					<select name="zb_source" id="zb_source">
						<?php foreach ( $sources as $key ) : ?>
							<option value="<?php echo esc_attr( $key ); ?>" <?php echo $sel( 'source', $key, 'all' ); ?>><?php echo esc_html( $key ); ?></option>
						<?php endforeach; ?>
					</select>
				</span>

				<span class="zd-field">
					<label for="zb_subset"><?php esc_html_e( 'Vendor subset', 'zymarg-wcpg' ); ?></label>
					<select name="zb_subset" id="zb_subset">
						<?php foreach ( array( 'all', 'featured', 'best_selling', 'trending' ) as $key ) : ?>
							<option value="<?php echo esc_attr( $key ); ?>" <?php echo $sel( 'subset', $key, 'all' ); ?>><?php echo esc_html( $key ); ?></option>
						<?php endforeach; ?>
					</select>
				</span>

				<span class="zd-field">
					<label for="zb_scope"><?php esc_html_e( 'Flash scope', 'zymarg-wcpg' ); ?></label>
					<select name="zb_scope" id="zb_scope">
						<?php foreach ( array( 'auto', 'site', 'vendor' ) as $key ) : ?>
							<option value="<?php echo esc_attr( $key ); ?>" <?php echo $sel( 'scope', $key, 'auto' ); ?>><?php echo esc_html( $key ); ?></option>
						<?php endforeach; ?>
					</select>
				</span>

				<span class="zd-field">
					<label for="zb_layout"><?php esc_html_e( 'Layout', 'zymarg-wcpg' ); ?></label>
					<select name="zb_layout" id="zb_layout">
						<?php foreach ( array( 'grid', 'slider' ) as $key ) : ?>
							<option value="<?php echo esc_attr( $key ); ?>" <?php echo $sel( 'layout', $key, 'grid' ); ?>><?php echo esc_html( $key ); ?></option>
						<?php endforeach; ?>
					</select>
				</span>

				<span class="zd-field">
					<label for="zb_card"><?php esc_html_e( 'Card', 'zymarg-wcpg' ); ?></label>
					<select name="zb_card" id="zb_card">
						<?php foreach ( $cards as $key ) : ?>
							<option value="<?php echo esc_attr( $key ); ?>" <?php echo $sel( 'card', $key, 'classic' ); ?>><?php echo esc_html( $key ); ?></option>
						<?php endforeach; ?>
					</select>
				</span>

				<span class="zd-field">
					<label for="zb_limit"><?php esc_html_e( 'Limit', 'zymarg-wcpg' ); ?></label>
					<input type="number" min="1" max="24" name="zb_limit" id="zb_limit"
						value="<?php echo esc_attr( (string) ( isset( $req['limit'] ) ? (int) $req['limit'] : 4 ) ); ?>">
				</span>

				<span class="zd-field">
					<label for="zb_preview"><?php esc_html_e( 'Preview', 'zymarg-wcpg' ); ?></label>
					<label><input type="checkbox" name="zb_preview" id="zb_preview" value="1"
						<?php checked( ! empty( $req['preview'] ) ); ?>> <?php esc_html_e( 'Show output', 'zymarg-wcpg' ); ?></label>
				</span>

				<button type="submit" class="zd-btn"><?php esc_html_e( 'Run test', 'zymarg-wcpg' ); ?></button>
			</form>

			<?php if ( is_array( $bench ) ) : ?>
				<div class="zd-status-bar <?php echo $bench['ok'] ? 'zd-status-bar--pass' : 'zd-status-bar--fail'; ?>">
					<span class="zd-status-bar__left">
						<span class="zd-tag zd-tag--<?php echo esc_attr( $bench['status'] ); ?>"><?php echo esc_html( $bench['status'] ); ?></span>
						<?php echo esc_html( $bench['message'] ); ?>
					</span>
					<span class="zd-timing"><?php echo esc_html( $bench['ms'] . ' ms' ); ?></span>
				</div>

				<table class="zd-table">
					<tbody>
						<tr><td class="zd-table__label"><?php esc_html_e( 'Products found', 'zymarg-wcpg' ); ?></td>
							<td class="zd-table__value"><?php echo esc_html( (string) count( $bench['products'] ) ); ?></td></tr>
						<tr><td class="zd-table__label"><?php esc_html_e( 'HTML produced', 'zymarg-wcpg' ); ?></td>
							<td class="zd-table__value"><?php echo esc_html( $bench['bytes'] ? size_format( $bench['bytes'] ) : '0' ); ?></td></tr>
					</tbody>
				</table>

				<?php if ( ! empty( $bench['products'] ) ) : ?>
					<div class="zd-product-list">
						<?php foreach ( $bench['products'] as $name ) : ?>
							<span class="zd-product-pill"><?php echo esc_html( $name ); ?></span>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>

				<?php if ( ! empty( $req['preview'] ) && ! empty( $bench['html'] ) ) : ?>
					<div class="zd-preview">
						<?php
						// Engine-generated markup, already escaped by the render pipeline.
						echo $bench['html']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						?>
					</div>
				<?php endif; ?>
			<?php endif; ?>
		</div>
		<?php
	}

	private function __construct() {}
}
