<?php
/**
 * Plugin Name: ZYMARG WC Product Grid — Extension Example
 * Description: Demonstrates how to extend the ZYMARG WC Product Grid plugin
 *              using the public Extension API. Zero core files are modified.
 * Version:     1.0.0
 * Requires Plugins: zymarg-wc-product-grid
 *
 * This file is NOT part of the production plugin.
 * It is provided as a reference for developers who want to extend the plugin.
 *
 * Activate this plugin to see the Extension API in action.
 * Every feature below is implemented using only public hooks — no core files
 * are modified.
 *
 * @package ZymargExtensionExample
 */

defined( 'ABSPATH' ) || exit;

// ─────────────────────────────────────────────────────────────────────────────
// 1. Add a custom CSS class to every card that is featured.
// Hook: zymarg_card_classes
// ─────────────────────────────────────────────────────────────────────────────
add_filter(
	'zymarg_card_classes',
	function ( array $classes, WC_Product $product ): array {
		if ( $product->is_featured() ) {
			$classes[] = 'is-featured';
		}

		return $classes;
	},
	10,
	2
);

// ─────────────────────────────────────────────────────────────────────────────
// 2. Add a custom data attribute to cards so JavaScript can identify them.
// Hook: zymarg_card_attributes
// ─────────────────────────────────────────────────────────────────────────────
add_filter(
	'zymarg_card_attributes',
	function ( array $attrs, WC_Product $product ): array {
		$sku = $product->get_sku();

		if ( $sku ) {
			$attrs['data-sku'] = $sku;
		}

		return $attrs;
	},
	10,
	2
);

// ─────────────────────────────────────────────────────────────────────────────
// 3. Inject a "Free Shipping" badge after the price row.
// Hook: zymarg_after_card_price
// ─────────────────────────────────────────────────────────────────────────────
add_action(
	'zymarg_after_card_price',
	function ( WC_Product $product ): void {
		// Only show for products over a threshold.
		if ( (float) $product->get_price() >= 500 ) {
			echo '<span class="zymarg-extension-free-shipping">Free Shipping</span>';
		}
	}
);

// ─────────────────────────────────────────────────────────────────────────────
// 4. Inject a "Vendor Ribbon" before the card opens (outside the card wrapper).
// Hook: zymarg_before_card
// ─────────────────────────────────────────────────────────────────────────────
add_action(
	'zymarg_before_card',
	function ( WC_Product $product ): void {
		$store_name = function_exists( 'dokan_get_store_info' )
			? ( dokan_get_store_info( get_post_field( 'post_author', $product->get_id() ) )['store_name'] ?? '' )
			: '';

		if ( $store_name ) {
			printf(
				'<span class="zymarg-extension-vendor-ribbon">%s</span>',
				esc_html( $store_name )
			);
		}
	}
);

// ─────────────────────────────────────────────────────────────────────────────
// 5. Reorder products so in-stock items appear before out-of-stock items.
// Hook: zymarg_products
// ─────────────────────────────────────────────────────────────────────────────
add_filter(
	'zymarg_products',
	function ( array $products ): array {
		usort(
			$products,
			fn( WC_Product $a, WC_Product $b ) => (int) $b->is_in_stock() - (int) $a->is_in_stock()
		);

		return $products;
	}
);

// ─────────────────────────────────────────────────────────────────────────────
// 6. Override the config to force slider layout on mobile.
// Hook: zymarg_render_config
// ─────────────────────────────────────────────────────────────────────────────
add_filter(
	'zymarg_render_config',
	function ( array $config ): array {
		if ( wp_is_mobile() ) {
			$config['layout']['type'] = 'slider';
		}

		return $config;
	}
);

// ─────────────────────────────────────────────────────────────────────────────
// 7. Exclude products tagged 'members-only' from guest users.
// Hook: zymarg_wcpg_query_args
// ─────────────────────────────────────────────────────────────────────────────
add_filter(
	'zymarg_wcpg_query_args',
	function ( array $args ): array {
		if ( ! is_user_logged_in() ) {
			$args['tax_query'][] = [
				'taxonomy' => 'product_tag',
				'field'    => 'slug',
				'terms'    => [ 'members-only' ],
				'operator' => 'NOT IN',
			];
		}

		return $args;
	}
);

// ─────────────────────────────────────────────────────────────────────────────
// 8. Log every Add to Cart event to a custom table.
// Hook: zymarg_wcpg_added_to_cart
// ─────────────────────────────────────────────────────────────────────────────
add_action(
	'zymarg_wcpg_added_to_cart',
	function ( int $product_id, int $quantity ): void {
		// Replace with your own analytics or logging logic.
		error_log( sprintf( '[ZYMARG Extension] Product %d added to cart (qty: %d)', $product_id, $quantity ) );
	},
	10,
	2
);
