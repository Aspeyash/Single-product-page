<?php
/**
 * Price block. Delegates to Product_Data so simple/variable rules stay
 * in one place.
 *
 * @package Zymarg\WCPG
 *
 * @var \WC_Product $product
 * @var array       $settings
 */

defined( 'ABSPATH' ) || exit;

if ( ! ( $product instanceof \WC_Product ) ) {
	return;
}

\Zymarg\WCPG\Product_Data::render_price( $product );
