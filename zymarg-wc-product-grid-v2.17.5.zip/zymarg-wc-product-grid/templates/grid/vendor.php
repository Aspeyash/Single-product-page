<?php
/**
 * Vendor profile row — shown on each product card in the ZYMARG WC
 * Product Grid.
 *
 * Rewritten in v1.5.10 to align with the Theme Builder Seller Card and
 * Store Hero widgets: trust `dokan_get_vendor()` as the single source of
 * truth. When Dokan returns a valid Vendor object we render the row;
 * when it returns null we output nothing.
 *
 * Rationale: the previous implementation ran two additional validation
 * gates — `Vendor_Resolver::check_vendor_status()` (strict equality on
 * `dokan_enable_selling` and `dokan_publishing` user meta) and
 * `dokan_get_store_info()[ 'store_name' ]` for the display name —
 * which both silently rejected admin / site-owner vendor accounts whose
 * meta was seeded in unexpected shapes (e.g. `dokan_enable_selling`
 * stored as `'1'` instead of `'yes'`, or `dokan_profile_settings` written
 * via `Dokan → Vendors → Edit Vendor` skipping the `store_name` key).
 * The result was every product owned by such a vendor rendered without
 * the vendor row, which in turn caused the ATC button to fall back from
 * its configured `with_vendor` pairing down to the price row.
 *
 * The Theme Builder widgets never had this problem because they used
 * `dokan_get_vendor()` + `$vendor->get_shop_name()` from day one, with
 * an author-byline fallback chain. That chain is now shared via the
 * `zymarg_tb_get_vendor_display_name()` helper introduced in Theme
 * Builder 3.19.0. This template consumes it via a soft
 * `function_exists()` dependency and falls back to an inline copy of
 * the same chain if Theme Builder is not active — the two paths are
 * intentionally byte-equivalent.
 *
 * Requires Dokan Lite or Pro 3.10+. Silently outputs nothing when Dokan
 * is not active, when the resolver returns no vendor id, when Dokan
 * itself can't hydrate a Vendor object for that id, or when no legible
 * store name can be resolved.
 *
 * Theme override: copy to theme/zymarg-wcpg/grid/vendor.php.
 *
 * @package Zymarg\WCPG
 *
 * @var \WC_Product $product
 * @var array       $settings
 */

defined( 'ABSPATH' ) || exit;

if ( ! ( $product instanceof \WC_Product ) ) {
	return;
}

// Guard: Dokan must be active at the minimum version supported by the
// resolver.
if ( ! \Zymarg\WCPG\Vendor\Vendor_Resolver::is_supported() ) {
	return;
}

$product_id = (int) $product->get_id();

// Resolve the vendor id. Simplified in v1.5.10 — see resolver docblock
// for the two-step lookup.
$vendor_id = \Zymarg\WCPG\Vendor\Vendor_Resolver::resolve( $product_id );

if ( ! $vendor_id ) {
	return;
}

// Hydrate the Dokan Vendor object — this is now our single source of
// truth for "is this a real vendor?" No custom status gating.
if ( ! function_exists( 'dokan_get_vendor' ) ) {
	return;
}

$vendor = dokan_get_vendor( $vendor_id );
if ( ! $vendor ) {
	return;
}

// ── Resolve store name via the shared Theme Builder helper when
//     available (single source of truth across ZYMARG plugins). Falls
//     back to a byte-equivalent local implementation when Theme Builder
//     is not active. ──────────────────────────────────────────────────
if ( function_exists( 'zymarg_tb_get_vendor_display_name' ) ) {
	$store_name = zymarg_tb_get_vendor_display_name( $vendor, $vendor_id );
} else {
	$store_name = method_exists( $vendor, 'get_shop_name' ) ? trim( (string) $vendor->get_shop_name() ) : '';
	if ( '' === $store_name ) {
		$user = get_userdata( $vendor_id );
		if ( $user ) {
			$candidates = array(
				$user->display_name,
				trim( $user->first_name . ' ' . $user->last_name ),
				$user->user_login,
			);
			foreach ( $candidates as $candidate ) {
				$candidate = trim( (string) $candidate );
				if ( '' !== $candidate ) {
					$store_name = $candidate;
					break;
				}
			}
		}
	}
}

if ( '' === $store_name ) {
	return; // Nothing useful to display.
}

// ── Gather widget settings ─────────────────────────────────────────────
$display  = isset( $settings['vendor_display'] ) ? (string) $settings['vendor_display'] : 'avatar_name';
$linkable = ! isset( $settings['vendor_link'] ) || in_array( (string) $settings['vendor_link'], array( '1', 'yes', 'true' ), true );

// Store URL — always via the Dokan Vendor object method (matches Theme
// Builder Seller Card + Store Hero). Falls back to empty on any Dokan
// version that doesn't expose get_shop_url; the link wrapper below
// gracefully degrades to a non-anchor span in that case.
$store_url = '';
if ( $linkable && method_exists( $vendor, 'get_shop_url' ) ) {
	$store_url = (string) $vendor->get_shop_url();
}

// Avatar — WordPress gravatar / profile photo.
$show_avatar = in_array( $display, array( 'avatar_name', 'avatar_name_location' ), true );
$avatar_size = isset( $settings['vendor_avatar_size']['size'] )
	? max( 12, min( 80, (int) $settings['vendor_avatar_size']['size'] ) )
	: 24;

// Avatar side: 'left' (default) or 'right'.
$avatar_side = isset( $settings['vendor_avatar_side'] ) && 'right' === $settings['vendor_avatar_side']
	? 'right'
	: 'left';

// Avatar shape: 'circle' (default), 'rounded', 'square'.
$allowed_shapes = array( 'circle', 'rounded', 'square' );
$avatar_shape   = isset( $settings['vendor_avatar_shape'] ) && in_array( $settings['vendor_avatar_shape'], $allowed_shapes, true )
	? $settings['vendor_avatar_shape']
	: 'circle';

// Location (city) — best-effort read from Dokan's store info. Safe to
// leave empty; the row still renders without it.
$location = '';
if ( 'avatar_name_location' === $display && function_exists( 'dokan_get_store_info' ) ) {
	$store_info = dokan_get_store_info( $vendor_id );
	if ( ! empty( $store_info['address']['city'] ) ) {
		$location = (string) $store_info['address']['city'];
	} elseif ( ! empty( $store_info['location'] ) ) {
		$location = (string) $store_info['location'];
	}
}
?>
<div class="zymarg-wcpg__vendor zymarg-wcpg__vendor--avatar-<?php echo esc_attr( $avatar_side ); ?>">
	<?php if ( $store_url ) : ?>
		<a class="zymarg-wcpg__vendor-inner"
			href="<?php echo esc_url( $store_url ); ?>"
			aria-label="<?php echo esc_attr( sprintf( /* translators: %s: vendor store name */ __( 'Visit %s store', 'zymarg-wcpg' ), $store_name ) ); ?>">
	<?php else : ?>
		<span class="zymarg-wcpg__vendor-inner">
	<?php endif; ?>

		<?php if ( $show_avatar ) : ?>
			<?php
			echo get_avatar(
				$vendor_id,
				$avatar_size * 2, // 2× for retina; CSS constrains display size.
				'',
				esc_attr( $store_name ),
				array(
					'class'   => 'zymarg-wcpg__vendor-avatar zymarg-wcpg__vendor-avatar--' . esc_attr( $avatar_shape ),
					'loading' => 'lazy',
				)
			);
			?>
		<?php endif; ?>

		<span class="zymarg-wcpg__vendor-meta">
			<span class="zymarg-wcpg__vendor-name"><?php echo esc_html( $store_name ); ?></span>
			<?php if ( $location ) : ?>
				<span class="zymarg-wcpg__vendor-location"><?php echo esc_html( $location ); ?></span>
			<?php endif; ?>
		</span>

	<?php if ( $store_url ) : ?>
		</a>
	<?php else : ?>
		</span>
	<?php endif; ?>
</div>
