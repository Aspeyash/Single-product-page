<?php
/**
 * Grid wrapper template.
 *
 * Theme override: copy to theme/zymarg-wcpg/grid/grid-wrapper.php
 *
 * @package Zymarg\WCPG
 *
 * @var array  $settings  Sanitized widget settings.
 * @var int    $widget_id Elementor widget ID.
 * @var array  $products  Array of WC_Product objects (may be empty).
 */

defined( 'ABSPATH' ) || exit;

// Defensive guard: $config must always be provided by Template_Manager::render_layout().
// If it is missing, this template is being called by a legacy integration that bypasses
// Template_Manager (e.g. a theme or old plugin calling Template_Loader directly).
// We build a minimal fallback so no PHP warning fires, but log a notice so the
// developer knows the old call path needs to be updated to use Template_Manager.
if ( ! isset( $config ) || ! is_array( $config ) ) {
	if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_trigger_error
		trigger_error(
			sprintF(
				'[ZYMARG WCPG] %s loaded without $config. Use Template_Manager::render_layout() instead of calling this template directly.',
				basename( __FILE__ )
			),
			E_USER_NOTICE
		);
	}
	$config = [];
}

// Accepts both Elementor strings ('yes') and canonical booleans (true/1).
// All legacy templates use this helper after the v1.6.5 migration audit.
$enabled = static function ( $value ) {
	return in_array( (string) $value, array( '1', 'yes', 'true' ), true );
};

$show_heading = isset( $settings['show_heading'] ) && $enabled( $settings['show_heading'] );

// Heading values are only used when show_heading is on.
$heading_text   = isset( $settings['heading_text'] ) ? (string) $settings['heading_text'] : '';
$subheading     = isset( $settings['subheading_text'] ) ? (string) $settings['subheading_text'] : '';
$allowed_tags   = array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'div', 'span' );
$heading_tag    = isset( $settings['heading_tag'] ) && in_array( $settings['heading_tag'], $allowed_tags, true ) ? $settings['heading_tag'] : 'h2';
$show_view_all  = isset( $settings['show_view_all'] ) && $enabled( $settings['show_view_all'] );
$view_all_text  = isset( $settings['view_all_text'] ) ? (string) $settings['view_all_text'] : __( 'View All', 'zymarg-wcpg' );
$view_all_url   = isset( $settings['view_all_url']['url'] ) ? (string) $settings['view_all_url']['url'] : '';
$view_all_blank = ! empty( $settings['view_all_url']['is_external'] );
$view_all_nf    = ! empty( $settings['view_all_url']['nofollow'] );

// Heading alignment — responsive (desktop / tablet / mobile).
// Tablet/mobile values fall back to the next-wider breakpoint when unset,
// matching Elementor's responsive resolution behaviour.
$allowed_alignments = array( 'left', 'center', 'right' );
$heading_align_d = isset( $settings['heading_alignment'] ) && in_array( $settings['heading_alignment'], $allowed_alignments, true )
	? $settings['heading_alignment'] : 'left';
$heading_align_t = isset( $settings['heading_alignment_tablet'] ) && in_array( $settings['heading_alignment_tablet'], $allowed_alignments, true )
	? $settings['heading_alignment_tablet'] : $heading_align_d;
$heading_align_m = isset( $settings['heading_alignment_mobile'] ) && in_array( $settings['heading_alignment_mobile'], $allowed_alignments, true )
	? $settings['heading_alignment_mobile'] : $heading_align_t;

$columns       = isset( $settings['columns'] ) ? max( 1, min( 6, (int) $settings['columns'] ) ) : 4;
$empty_message = isset( $settings['empty_message'] ) ? (string) $settings['empty_message'] : __( 'No products found.', 'zymarg-wcpg' );

$pagination_mode = isset( $settings['pagination_mode'] ) ? (string) $settings['pagination_mode'] : 'none';
$load_more_text  = isset( $settings['load_more_text'] ) ? (string) $settings['load_more_text'] : __( 'Load more', 'zymarg-wcpg' );

// v2.6.0: Infinite scroll. Every device batch/cap pair is emitted as a data
// attribute and resolved in the BROWSER from viewport width. Resolving it in
// PHP would bake one device's numbers into page-cached HTML. The cap counts
// auto-loaded products only, never the first page.
$is_infinite = 'infinite' === $pagination_mode;

$zymarg_pg_int = static function ( $key, $fallback, $ceiling ) use ( $settings ) {
	$value = isset( $settings[ $key ] ) && '' !== $settings[ $key ]
		? (int) $settings[ $key ]
		: (int) $fallback;
	return max( 1, min( (int) $ceiling, $value ) );
};

$inf_batch_d = $zymarg_pg_int( 'infinite_batch_size', 20, 48 );
$inf_batch_t = $zymarg_pg_int( 'infinite_batch_size_tablet', 20, 48 );
$inf_batch_m = $zymarg_pg_int( 'infinite_batch_size_mobile', 10, 48 );
$inf_max_d   = $zymarg_pg_int( 'infinite_max_products', 100, 500 );
$inf_max_t   = $zymarg_pg_int( 'infinite_max_products_tablet', 100, 500 );
$inf_max_m   = $zymarg_pg_int( 'infinite_max_products_mobile', 50, 500 );

// Settings payload echoed into a data-attr so the Load More AJAX request
// can replay the same query shape. Source-internal knobs are never echoed.
$payload_keys = array(
	'source',
	'total_products',
	'orderby',
	'order',
	'show_oos',
	'columns',
	'show_image',
	'show_discount_badge',
	'show_stock_badge',
	'show_wishlist',
	'show_quickview',
	'show_atc',
	'show_title',
	'show_rating',
	'show_sold_count',
	'show_price',
	'discount_badge_mode',
	'image_full_resolution',
	'image_hover_zoom',
	'show_stock_in',
	'show_stock_out',
	'title_lines',
	'sold_count_format',
	// v1.4.2: responsive meta-layout + show-sold-text controls. Tablet
	// and mobile suffixes are echoed so the Load More AJAX request
	// preserves per-breakpoint variants when the AJAX-rendered cards
	// are spliced into the existing grid.
	'meta_layout',
	'meta_layout_tablet',
	'meta_layout_mobile',
	'show_sold_text',
	'show_sold_text_tablet',
	'show_sold_text_mobile',
	// v1.5.22: filter group ID for the Vendor Category Filter widget.
	'filter_group_id',
	// v1.5.23: current_vendor_subset must be in the payload so the AJAX
	// handler knows which subset (all/featured/trending/best_selling) to query.
	'current_vendor_subset',
	'current_vendor_include_staff',
	// v2.3.0: propagate the ZYMARG card's optional rows + Quick View settings
	// through Load More so AJAX-appended cards match the first page.
	'show_vendor',
	'quickview_visibility',
	'quickview_display',
);
$payload = array();
foreach ( $payload_keys as $k ) {
	if ( isset( $settings[ $k ] ) ) {
		$payload[ $k ] = is_scalar( $settings[ $k ] ) ? (string) $settings[ $k ] : $settings[ $k ];
	}
}

// v2.3.0: The card-template slug lives on $config (not the flat $settings
// payload map), so echo it explicitly. Load More reads card_template to
// re-render the same card design instead of falling back to the classic card.
$card_template_slug = isset( $config['card']['template'] ) ? (string) $config['card']['template'] : 'classic';
$payload['card_template'] = $card_template_slug;
?>
<div class="zymarg-wcpg zymarg-wcpg--card-<?php echo esc_attr( $card_template_slug ); ?>"
	data-widget-id="<?php echo esc_attr( $widget_id ); ?>"
	data-zymarg-hydrate="1"
	data-show-view-cart="<?php echo ( ! isset( $settings['show_view_cart_link'] ) || $enabled( $settings['show_view_cart_link'] ) ) ? '1' : '0'; ?>"
	data-settings="<?php echo esc_attr( wp_json_encode( $payload ) ); ?>"
	<?php if ( ! empty( $settings['filter_group_id'] ) ) : ?>
		data-filter-group="<?php echo esc_attr( $settings['filter_group_id'] ); ?>"
	<?php endif; ?>
	<?php
	// v1.5.23: For current_vendor source, echo the resolved vendor ID so the
	// VCF AJAX re-fetch can pass it back as current_vendor_id. In AJAX context
	// get_query_var('author') returns empty, so the source cannot detect the
	// vendor on its own — this data attribute bridges the gap.
	if ( 'current_vendor' === ( $settings['source'] ?? '' ) ) :
		$_wcpg_vendor_id = (int) get_query_var( 'author' );
		if ( ! $_wcpg_vendor_id && function_exists( 'dokan_is_store_page' ) && dokan_is_store_page() ) {
			$_wcpg_queried = get_queried_object();
			if ( $_wcpg_queried instanceof \WP_User ) {
				$_wcpg_vendor_id = (int) $_wcpg_queried->ID;
			}
		}
		if ( ! $_wcpg_vendor_id ) {
			$_wcpg_slug = (string) get_query_var( 'author_name' );
			if ( $_wcpg_slug ) {
				$_wcpg_user = get_user_by( 'slug', $_wcpg_slug );
				if ( $_wcpg_user instanceof \WP_User ) {
					$_wcpg_vendor_id = (int) $_wcpg_user->ID;
				}
			}
		}
		if ( $_wcpg_vendor_id > 0 ) :
			?>
			data-vendor-id="<?php echo esc_attr( (string) $_wcpg_vendor_id ); ?>"
		<?php endif; ?>
	<?php endif; ?>>

	<?php if ( $show_heading && ( '' !== $heading_text || '' !== $subheading || ( $show_view_all && $view_all_url ) ) ) : ?>
		<div class="zymarg-wcpg__heading zymarg-wcpg__heading--align-<?php echo esc_attr( $heading_align_d ); ?>"
			<?php if ( $heading_align_t !== $heading_align_d ) : ?>data-align-tablet="<?php echo esc_attr( $heading_align_t ); ?>"<?php endif; ?>
			<?php if ( $heading_align_m !== $heading_align_t ) : ?>data-align-mobile="<?php echo esc_attr( $heading_align_m ); ?>"<?php endif; ?>>
			<div class="zymarg-wcpg__heading-main">
				<?php if ( '' !== $heading_text ) : ?>
					<<?php echo esc_html( $heading_tag ); ?> class="zymarg-wcpg__heading-title">
						<?php echo esc_html( $heading_text ); ?>
					</<?php echo esc_html( $heading_tag ); ?>>
				<?php endif; ?>

				<?php if ( '' !== $subheading ) : ?>
					<div class="zymarg-wcpg__heading-subtitle">
						<?php echo esc_html( $subheading ); ?>
					</div>
				<?php endif; ?>
			</div>

			<?php if ( $show_view_all && '' !== $view_all_url ) : ?>
				<a class="zymarg-wcpg__heading-link"
					href="<?php echo esc_url( $view_all_url ); ?>"
					<?php echo $view_all_blank ? 'target="_blank"' : ''; ?>
					<?php echo $view_all_nf ? 'rel="nofollow noopener"' : ( $view_all_blank ? 'rel="noopener"' : '' ); ?>>
					<?php echo esc_html( $view_all_text ); ?>
				</a>
			<?php endif; ?>
		</div>
	<?php endif; ?>

	<?php if ( empty( $products ) ) : ?>
		<?php
		\Zymarg\WCPG\Template_Loader::get_template(
			'parts/empty-state.php',
			array( 'message' => $empty_message )
		);
		?>
	<?php else : ?>
		<?php
		// Resolve responsive column counts.
		// (1) data-columns-* attributes: read by CSS attribute selectors (v1.6.5).
		// (2) CSS custom properties: --columns-desktop/tablet/mobile on the grid
		//     element allow per-card-template CSS to use repeat(var(--columns-desktop),1fr)
		//     so standalone plugins can change column counts without editing any CSS file.
		//     (v2.0.3 — per senior developer architecture recommendation)
		$columns_tablet = isset( $settings['columns_tablet'] ) && '' !== $settings['columns_tablet']
			? max( 1, min( 6, (int) $settings['columns_tablet'] ) )
			: null;
		$columns_mobile = isset( $settings['columns_mobile'] ) && '' !== $settings['columns_mobile']
			? max( 1, min( 6, (int) $settings['columns_mobile'] ) )
			: null;

		// Build the inline style block for CSS custom properties.
		// Always emit --columns-desktop so card-template CSS can rely on it unconditionally.
		$col_vars  = '--columns-desktop:' . (int) $columns . ';';
		$col_vars .= '--columns-tablet:' . (int) ( $columns_tablet ?? $columns ) . ';';
		$col_vars .= '--columns-mobile:' . (int) ( $columns_mobile ?? $columns_tablet ?? $columns ) . ';';
		// v2.4.2: grid gap is config-driven (layout.gap). Emit --grid-gap so the
		// stylesheet rule gap:var(--grid-gap,6px) applies it for every consumer
		// (shortcode, standalone plugins, Elementor). Clamped to a sane range.
		$grid_gap  = isset( $settings['gap'] ) ? max( 0, min( 100, (int) $settings['gap'] ) ) : 6;
		$col_vars .= '--grid-gap:' . (int) $grid_gap . 'px;';
		?>
		<div class="zymarg-wcpg__grid zymarg-wcpg__grid--cols-<?php echo (int) $columns; ?>"
			style="<?php echo esc_attr( $col_vars ); ?>"
			<?php if ( null !== $columns_tablet ) : ?>data-columns-tablet="<?php echo (int) $columns_tablet; ?>"<?php endif; ?>
			<?php if ( null !== $columns_mobile ) : ?>data-columns-mobile="<?php echo (int) $columns_mobile; ?>"<?php endif; ?>>
			<?php
			foreach ( $products as $product ) {
				if ( ! $product instanceof \WC_Product ) {
					continue;
				}
				// Template_Manager resolves the card template slug to a file path
				// and delegates to Template_Loader (which handles theme overrides).
				// 'classic' is the only template today; additional slugs are added
				// to Template_Manager::CARD_TEMPLATES when new designs are built.
				// Unknown slugs fall back to 'classic' — never a fatal error.
				// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- trusted plugin HTML.
				echo \Zymarg\WCPG\Templates\Template_Manager::render_card(
					$config['card']['template'] ?? 'classic',
					array(
						'product'   => $product,
						'settings'  => $settings,
						'config'    => $config,
						'widget_id' => $widget_id,
					)
				);
			}
			?>
		</div>

		<?php
		$total_setting = isset( $settings['total_products'] ) ? (int) $settings['total_products'] : 8;
		$is_unlimited  = $total_setting <= 0;
		// Load More is irrelevant when unlimited (we already showed everything),
		// and only shown when the page filled to the requested per-page count.
		// For Algolia source use nb_hits from the filter for accurate detection.
		$algolia_nb_hits = 'algolia' === ( $settings['source'] ?? '' )
			? (int) apply_filters( 'zymarg_wcpg_algolia_nb_hits', 0 )
			: 0;
		$show_load_more = ( 'load_more' === $pagination_mode || $is_infinite )
			&& ! $is_unlimited
			&& (
				( $algolia_nb_hits > 0 && $algolia_nb_hits > count( $products ) )
				|| ( 0 === $algolia_nb_hits && count( $products ) >= max( 1, $total_setting ) )
			);

		// For category source: read term ID from filter for load-more button.
		$category_term_id = 'category' === ( $settings['source'] ?? '' )
			? (int) apply_filters( 'zymarg_wcpg_category_term_id', 0 )
			: 0;
		?>
		<?php if ( $show_load_more ) : ?>
			<div class="zymarg-wcpg__pagination">
				<button type="button"
					class="zymarg-wcpg__load-more"
					data-page="2"
					data-action="zymarg-load-more"
					<?php if ( $is_infinite ) : ?>
						data-infinite="1"
						data-batch-desktop="<?php echo esc_attr( $inf_batch_d ); ?>"
						data-batch-tablet="<?php echo esc_attr( $inf_batch_t ); ?>"
						data-batch-mobile="<?php echo esc_attr( $inf_batch_m ); ?>"
						data-max-desktop="<?php echo esc_attr( $inf_max_d ); ?>"
						data-max-tablet="<?php echo esc_attr( $inf_max_t ); ?>"
						data-max-mobile="<?php echo esc_attr( $inf_max_m ); ?>"
					<?php endif; ?>
					<?php if ( 'algolia' === ( $settings['source'] ?? '' ) ) : ?>
						data-algolia-query="<?php echo esc_attr( get_search_query() ); ?>"
					<?php endif; ?>
					<?php if ( $category_term_id > 0 ) : ?>
						data-category-term-id="<?php echo esc_attr( $category_term_id ); ?>"
					<?php endif; ?>>
					<span class="zymarg-wcpg__load-more-text"><?php echo esc_html( $load_more_text ); ?></span>
					<span class="zymarg-wcpg__load-more-spinner" aria-hidden="true"></span>
				</button>
			</div>
			<?php if ( $is_infinite ) : ?>
				<div class="zymarg-wcpg__infinite-loader-area">
					<div class="zymarg-wcpg__infinite-loader" role="status" aria-live="polite" aria-atomic="true"></div>
				</div>
				<div class="zymarg-wcpg__scroll-sentinel" aria-hidden="true"></div>
			<?php endif; ?>
		<?php endif; ?>
	<?php endif; ?>

</div>
