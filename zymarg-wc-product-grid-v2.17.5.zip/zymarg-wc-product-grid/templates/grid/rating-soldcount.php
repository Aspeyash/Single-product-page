<?php
/**
 * Rating + sold count row.
 *
 * Hard rules:
 *   - Rating auto-hides when product has 0 ratings.
 *   - Sold count auto-hides when total_sales is 0.
 *   - Divider only renders when BOTH rating and sold count are visible
 *     AND layout is inline or count_first.
 *   - Entire wrapper is omitted when nothing renders.
 *
 * Layout modes (meta_layout setting, now responsive per device):
 *   inline          — ★★★★☆ | Sold 120   (default desktop/tablet)
 *   count_first     — Sold 120 | ★★★★☆   (sold count on the left)
 *   count_indicator — ★ 4.5 | Sold 120   (default mobile, v1.4.2)
 *
 * v1.4.2: meta_layout + show_sold_text are now RESPONSIVE controls.
 * Different layouts can be set per breakpoint. When the three breakpoints
 * share the same (layout + show_sold_text) signature, a SINGLE variant is
 * rendered (no extra HTML). When they differ, up to 3 variants are
 * rendered with `.zymarg-wcpg__meta--variant-{desktop|tablet|mobile}`
 * classes; CSS at Elementor breakpoints (1024px / 767px) shows exactly
 * one at a time.
 *
 * v1.3.28: 'stacked' layout was removed; widgets that have it saved
 * fall back to 'inline' via the validator below.
 *
 * v1.3.25: the stock badge is rendered into this row as the leftmost
 * element when product-card.php passes a non-empty $stock_badge_html.
 *
 * @package Zymarg\WCPG
 *
 * @var \WC_Product $product
 * @var array       $settings
 * @var string      $stock_badge_html  Pre-built badge HTML (already escaped) or ''.
 */

defined( 'ABSPATH' ) || exit;

if ( ! ( $product instanceof \WC_Product ) ) {
	return;
}

// Accepts both Elementor strings ('yes') and canonical booleans (true/1).
$enabled = static function ( $value ) {
	return in_array( (string) $value, array( '1', 'yes', 'true' ), true );
};

$show_rating = ! isset( $settings['show_rating'] )    || $enabled( $settings['show_rating'] );
$show_sold   = ! isset( $settings['show_sold_count'] ) || $enabled( $settings['show_sold_count'] );

$rating_count = (int) $product->get_rating_count();
$rating_avg   = (float) $product->get_average_rating();
$total_sales  = (int) $product->get_total_sales();

$render_rating = $show_rating && $rating_count > 0 && $rating_avg > 0;
$render_sold   = $show_sold && $total_sales > 0;

// Stock badge is owned by this row (since v1.3.25).
$stock_badge_html = isset( $stock_badge_html ) && is_string( $stock_badge_html ) ? $stock_badge_html : '';
$render_stock     = '' !== $stock_badge_html;

if ( ! $render_rating && ! $render_sold && ! $render_stock ) {
	return; // Whole row omitted from DOM.
}

// Wrapper class - allows product-card to pass row class.
$wrapper_class = isset( $wrapper_class ) && is_string( $wrapper_class )
	? $wrapper_class
	: 'zymarg-wcpg__meta';

/* -----------------------------------------------------------------------
 * Resolve per-device layout + show-sold-text values (v1.4.2).
 *
 * Elementor's add_responsive_control emits three sibling settings:
 *   <key>          => desktop value
 *   <key>_tablet   => tablet value
 *   <key>_mobile   => mobile value
 *
 * When a tablet/mobile value is empty/missing, fall back to the next-wider
 * device. This matches Elementor's own responsive resolution behaviour.
 * -------------------------------------------------------------------- */

$allowed_layouts = array( 'inline', 'count_first', 'count_indicator' );

$layout_d = isset( $settings['meta_layout'] ) ? (string) $settings['meta_layout'] : 'inline';
$layout_t = isset( $settings['meta_layout_tablet'] ) && '' !== (string) $settings['meta_layout_tablet']
	? (string) $settings['meta_layout_tablet']
	: $layout_d;
$layout_m = isset( $settings['meta_layout_mobile'] ) && '' !== (string) $settings['meta_layout_mobile']
	? (string) $settings['meta_layout_mobile']
	: $layout_t;

if ( ! in_array( $layout_d, $allowed_layouts, true ) ) {
	$layout_d = 'inline';
}
if ( ! in_array( $layout_t, $allowed_layouts, true ) ) {
	$layout_t = $layout_d;
}
if ( ! in_array( $layout_m, $allowed_layouts, true ) ) {
	$layout_m = $layout_t;
}

// show_sold_text: missing / non-'yes' value means OFF for that breakpoint.
// Desktop defaults to 'yes', mobile defaults to '' (off) - matches the
// control defaults registered in trait-controls-settings.php.
$show_text_d = ! isset( $settings['show_sold_text'] ) || $enabled( $settings['show_sold_text'] );
$show_text_t = isset( $settings['show_sold_text_tablet'] )
	? $enabled( $settings['show_sold_text_tablet'] )
	: $show_text_d;
$show_text_m = isset( $settings['show_sold_text_mobile'] )
	? $enabled( $settings['show_sold_text_mobile'] )
	: false; // Mobile default is OFF.

$variants = array(
	'desktop' => array( 'layout' => $layout_d, 'show_sold_text' => $show_text_d ),
	'tablet'  => array( 'layout' => $layout_t, 'show_sold_text' => $show_text_t ),
	'mobile'  => array( 'layout' => $layout_m, 'show_sold_text' => $show_text_m ),
);

// Signature-based dedupe: if all 3 breakpoints would render identical HTML,
// emit one variant instead of three. Saves DOM bytes on the common case.
$signatures = array();
foreach ( $variants as $device => $v ) {
	$signatures[ $device ] = $v['layout'] . '|' . ( $v['show_sold_text'] ? '1' : '0' );
}
$unique_signatures = array_values( array_unique( $signatures ) );

/* -----------------------------------------------------------------------
 * Variant renderer.
 * -------------------------------------------------------------------- */

$sold_format = isset( $settings['sold_count_format'] ) ? (string) $settings['sold_count_format'] : 'sold_n';

/**
 * Build the sold-count HTML for the given show_sold_text flag.
 *
 * @param bool $show_sold_text Whether to include the "Sold" / "sold" word.
 * @return string
 */
$build_sold_html = function ( $show_sold_text ) use ( $sold_format, $total_sales ) {
	if ( ! $show_sold_text ) {
		// Number only. For sold_n_plus keep the "+" suffix.
		if ( 'sold_n_plus' === $sold_format ) {
			$rounded = max( 0, (int) floor( $total_sales / 10 ) * 10 );
			$display = $rounded < 10 ? $total_sales : $rounded;
			return esc_html( number_format_i18n( $display ) ) . '+';
		}
		return esc_html( number_format_i18n( $total_sales ) );
	}
	switch ( $sold_format ) {
		case 'n_sold':
			return sprintf(
				/* translators: %s: number of items sold */
				esc_html__( '%s sold', 'zymarg-wcpg' ),
				esc_html( number_format_i18n( $total_sales ) )
			);
		case 'sold_n_plus':
			$rounded = max( 0, (int) floor( $total_sales / 10 ) * 10 );
			$display = $rounded < 10 ? $total_sales : $rounded;
			return sprintf(
				/* translators: %s: number of items sold (rounded down to nearest 10) */
				esc_html__( 'Sold %s+', 'zymarg-wcpg' ),
				esc_html( number_format_i18n( $display ) )
			);
		case 'sold_n':
		default:
			return sprintf(
				/* translators: %s: number of items sold */
				esc_html__( 'Sold %s', 'zymarg-wcpg' ),
				esc_html( number_format_i18n( $total_sales ) )
			);
	}
};

$fill_pct    = $render_rating ? min( 100, max( 0, ( $rating_avg / 5 ) * 100 ) ) : 0;
$aria_rating = $render_rating
	? sprintf(
		/* translators: %s: rating average */
		__( 'Rated %s out of 5', 'zymarg-wcpg' ),
		number_format_i18n( $rating_avg, 1 )
	)
	: '';

$rating_5star_html = '';
if ( $render_rating ) {
	$rating_5star_html = sprintf(
		'<div class="zymarg-wcpg__rating zymarg-wcpg__rating--with-count" aria-label="%s">
			<span class="zymarg-wcpg__rating-stars" aria-hidden="true">
				<span class="zymarg-wcpg__rating-fill" style="width:%s%%;"></span>
			</span>
			<span class="zymarg-wcpg__rating-count">(%s)</span>
		</div>',
		esc_attr( $aria_rating ),
		esc_attr( $fill_pct ),
		esc_html( number_format_i18n( $rating_avg, 1 ) )
	);
}

$rating_indicator_html = '';
if ( $render_rating ) {
	$rating_indicator_html = sprintf(
		'<div class="zymarg-wcpg__rating zymarg-wcpg__rating--indicator" aria-label="%s">
			<span class="zymarg-wcpg__rating-icon" aria-hidden="true">&#9733;</span>
			<span class="zymarg-wcpg__rating-value">%s</span>
		</div>',
		esc_attr( $aria_rating ),
		esc_html( number_format_i18n( $rating_avg, 1 ) )
	);
}

$divider_html = '<span class="zymarg-wcpg__divider" aria-hidden="true"></span>';

/**
 * Render one variant (returns HTML string).
 *
 * v1.4.3: rating + divider + sold-count are wrapped in a
 * `.zymarg-wcpg__meta-end` flex group. The stock badge stays outside
 * this group as a direct flex child of `.zymarg-wcpg__meta`. CSS uses
 * `flex: 1` on the end-group + `justify-content: space-between` inside
 * it to distribute the cluster across the available row width, leaving
 * no empty right gap on the card.
 *
 * @param string $layout         inline | count_first | count_indicator.
 * @param bool   $show_sold_text Include the "Sold" word.
 * @param string $variant_class  e.g. 'desktop' / 'tablet' / 'mobile' / 'all'.
 * @return string
 */
$render_variant = function ( $layout, $show_sold_text, $variant_class ) use (
	$wrapper_class,
	$render_stock,
	$render_rating,
	$render_sold,
	$stock_badge_html,
	$rating_5star_html,
	$rating_indicator_html,
	$divider_html,
	$build_sold_html
) {
	$rating_html = 'count_indicator' === $layout ? $rating_indicator_html : $rating_5star_html;
	$sold_inner  = $render_sold ? $build_sold_html( $show_sold_text ) : '';
	$sold_span   = $render_sold
		? '<span class="zymarg-wcpg__sold">' . $sold_inner . '</span>'
		: '';

	$classes = $wrapper_class . ' zymarg-wcpg__meta'
		. ( 'count_first' === $layout ? ' zymarg-wcpg__meta--count-first' : ' zymarg-wcpg__meta--inline' )
		. ' zymarg-wcpg__meta--layout-' . $layout
		. ' zymarg-wcpg__meta--variant-' . $variant_class;

	$out = '<div class="' . esc_attr( $classes ) . '">';

	// Stock badge: always direct child of .__meta (stays anchored at the
	// row's left edge regardless of which layout is in use).
	if ( $render_stock ) {
		$out .= $stock_badge_html;
	}

	// End-group: rating + divider + sold-count cluster, wrapped in a
	// flex:1 container that fills the rest of the row and distributes
	// its internal items with space-between (rating-side flush left of
	// the group, sold-side flush right, divider centered between).
	$end_inner = '';
	if ( 'count_first' === $layout ) {
		// Order: sold | divider | rating(5-star)
		if ( $render_sold ) {
			$end_inner .= $sold_span;
		}
		if ( $render_rating && $render_sold ) {
			$end_inner .= $divider_html;
		}
		if ( $render_rating ) {
			$end_inner .= $rating_html;
		}
	} else {
		// inline + count_indicator share element order:
		//   rating | divider | sold
		if ( $render_rating ) {
			$end_inner .= $rating_html;
		}
		if ( $render_rating && $render_sold ) {
			$end_inner .= $divider_html;
		}
		if ( $render_sold ) {
			$end_inner .= $sold_span;
		}
	}

	if ( '' !== $end_inner ) {
		$out .= '<div class="zymarg-wcpg__meta-end">' . $end_inner . '</div>';
	}

	$out .= '</div>';
	return $out;
};

/* -----------------------------------------------------------------------
 * Emit. One variant when all three breakpoints share the same signature,
 * otherwise emit one per breakpoint with CSS-controlled visibility.
 * -------------------------------------------------------------------- */

if ( count( $unique_signatures ) === 1 ) {
	// All three breakpoints would render identical HTML - emit once with
	// the catch-all 'all' variant class (always visible at every viewport).
	// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo $render_variant( $layout_d, $show_text_d, 'all' );
} else {
	// Emit each breakpoint variant. CSS makes exactly one visible at a time.
	foreach ( $variants as $device => $v ) {
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo $render_variant( $v['layout'], $v['show_sold_text'], $device );
	}
}
