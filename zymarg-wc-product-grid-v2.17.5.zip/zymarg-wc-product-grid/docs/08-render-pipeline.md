# Render Pipeline

This document describes the complete flow from a render request to HTML output.
It is intended for developers who need to understand the engine internals —
for example, when debugging, building extensions, or working on the engine itself.

External consumers (standalone plugins, shortcodes, Elementor widgets) only
need to read `01-public-api.md`. This document covers what happens inside.

---

## Pipeline overview

```
Caller
  │  Public_API::render( $args )
  ▼
Public_API                          ← stable public contract
  │
  ├─ Stage 1: Extract args
  ├─ Stage 2: Resolve input         config > template > slot
  ├─ Stage 3: Merge query override
  ├─ Stage 4: Resolve context       Context_Resolver
  ├─ Stage 5: Normalize config      Config_Normalizer → Config_Defaults
  ├─ Stage 5b: Cache lookup         Cache_Manager
  │     └─ HIT → return cached HTML immediately
  ├─ Stage 6: Fetch products        Query_Builder → Source_*
  │     └─ HIDE_WIDGET → return sentinel immediately
  ├─ Stage 7: Render                Render_Engine
  │     ├─ Asset_Manager::enqueue_for_render()
  │     ├─ Template_Manager::resolve_layout_path()   ← filter fires here (once)
  │     ├─ do_action( zymarg_product_grid_before_render )
  │     ├─ Template_Manager::render_layout()         ← uses resolved path
  │     │     └─ Template_Loader::get_template_html()
  │     │           └─ grid-wrapper.php / slider-wrapper.php
  │     │                 └─ Template_Manager::render_card() × N
  │     │                       └─ Template_Loader::get_template_html()
  │     │                             └─ product-card.php
  │     │                                   ├─ zymarg_card_classes filter
  │     │                                   ├─ zymarg_card_attributes filter
  │     │                                   ├─ zymarg_before_card action
  │     │                                   ├─ card HTML
  │     │                                   ├─ zymarg_after_card action
  │     │                                   └─ zymarg_card_html filter
  │     ├─ apply_filters( zymarg_product_grid_html )
  │     ├─ render_debug_overlay()   ← only when ZYMARG_DEBUG + admin
  │     └─ do_action( zymarg_product_grid_after_render )
  ├─ Stage 8: Write to cache        Cache_Manager
  └─ do_action( zymarg_product_grid_render_complete )
  │
  ▼
HTML string returned to caller
```

---

## Stage descriptions

### Stage 1 — Extract args

`Public_API` unpacks the `$args` array into typed local variables:
`$slot`, `$template_slug`, `$config_override`, `$query_override`,
`$products_arg`, `$context_arg`, `$widget_id`, `$is_preview`.

Unknown keys are silently ignored. No validation errors are thrown.

---

### Stage 2 — Resolve input

`resolve_template_config()` applies the priority rule:

1. If `config` was supplied → use it directly.
2. If `template` slug was supplied → load from `Template_Registry`.
3. If `slot` was supplied → resolve via `Slot_Registry` → load from `Template_Registry`.
4. If none → return `[]`; normalizer applies all defaults.

---

### Stage 3 — Merge query override

If `query` was supplied in `$args`, it is merged into `$template_config['query']`
using `array_merge`. Caller query keys win over template defaults.

---

### Stage 4 — Resolve context

`Context_Resolver::resolve( $context_arg )` auto-detects page context
(single product, store page, category archive, search results) and merges
with any context the caller explicitly supplied. The result is a flat array
used downstream by context-aware sources.

---

### Stage 5 — Normalize configuration

`Config_Normalizer::normalize()` walks the config through `Config_Defaults`,
filling every missing key with its default value and casting types. After
this stage, `$config` is complete and type-safe. No downstream class needs
to check for missing keys.

---

### Stage 5b — Cache lookup

`Cache_Manager` builds a cache key from the config and context fingerprint.
On a HIT, the cached HTML is returned immediately — stages 6 and 7 are skipped.

Cache is bypassed entirely when:
- The caller pre-supplied `products` (pre-fetched products skip the query, making cache irrelevant).
- The current viewer is an admin in preview, Elementor editor, or Customizer.
- `WP_DEBUG_DISPLAY` is true.

---

### Stage 6 — Fetch products

`Query_Adapter::to_settings()` translates the normalized config and resolved
context into the flat settings array that `Query_Builder` and source classes
expect (backward-compatible format).

`Query_Builder::get_products()` resolves the source key to a `Source_*` class
via the registry (filterable via `zymarg_wcpg_source_registry`) and calls
`get_products()`.

If the source returns `Source_Base::HIDE_WIDGET`, `Public_API` returns
`Public_API::HIDE_WIDGET` to the caller immediately. Nothing is rendered.

---

### Stage 7 — Render

`Render_Engine::render()` is the only class that knows how to turn config +
products into HTML. It:

1. Calls `Asset_Manager::enqueue_for_render()` — delegates all asset decisions.
2. Calls `Template_Manager::resolve_layout_path()` once to get the layout file
   path, applying the `zymarg_layout_template` filter. The result is stored as
   `$template_file`.
3. Fires `zymarg_product_grid_before_render` with `$template_file`.
4. Calls `Template_Manager::render_layout( $config, $render_context, $template_file )`.
   The pre-resolved path is passed in — the filter does not fire again.
5. Applies `zymarg_product_grid_html` filter to the result.
6. Appends the debug overlay if `ZYMARG_DEBUG` is enabled and viewer is admin.
7. Fires `zymarg_product_grid_after_render`.

---

### Stage 8 — Write to cache

If caching was enabled and a MISS occurred, the rendered HTML is stored via
`Cache_Manager::set()`. The default TTL is 300 seconds (filterable via
`zymarg_cache_ttl`). Cache uses `wp_cache_*` (Redis/Memcached if available)
with transients as fallback.

Cache invalidation uses version-bump strategy: when any product is saved,
`zymarg_cache_version` is incremented. All cache keys include the version,
so all grids are invalidated in O(1) without per-grid tracking.

---

## Class responsibilities

| Class | Responsibility |
|-------|---------------|
| `Public_API` | Orchestrate the pipeline. Stable public contract. |
| `Context_Resolver` | Detect and resolve page context. |
| `Config_Normalizer` | Fill defaults, cast types. |
| `Config_Defaults` | Define default values. |
| `Cache_Manager` | HTML cache: get, set, invalidate. |
| `Query_Adapter` | Translate config → legacy settings array. |
| `Query_Builder` | Resolve source key → Source class → call get_products(). |
| `Source_*` | Fetch products for a specific source. |
| `Render_Engine` | Coordinate assets + template rendering. |
| `Asset_Manager` | Enqueue CSS/JS. |
| `Template_Manager` | Map slugs to file paths. Knows all template filenames. |
| `Template_Loader` | Include files. Handles theme override resolution. |

Each class owns exactly one responsibility. No class reaches into another
class's responsibility.

---

## Key design decisions

**Template_Manager is the only class that knows filenames.** `Render_Engine`
never references `grid-wrapper.php` or any path. It asks `Template_Manager`
for a path and passes it to `Template_Loader`.

**The `zymarg_layout_template` filter fires exactly once per render.** Before
v2.0.2 it fired for hooks but not for the actual render — the filter affected
hook arguments but not the file that was loaded. This was a contract violation
fixed by resolving the path once in `Render_Engine` and passing it into
`render_layout()`.

**HIDE_WIDGET is a sentinel, not an error.** Context-aware sources return it
when rendering is not appropriate. The engine never emits markup for it. The
calling layer decides what to show (suppress entirely, show fallback, etc.).

**Cache bypasses pre-supplied products.** When a caller passes `products`,
they own the product data. Caching is irrelevant because the query stage
was skipped.

**The debug overlay is zero-cost in production.** `render_debug_overlay()`
is only called when `ZYMARG_DEBUG` is defined and true. The `$debug_meta`
array is built by `Public_API` and passed into `Render_Engine` as a parameter
— `Render_Engine` does not reach back up into `Public_API` to get it.
