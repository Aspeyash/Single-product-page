# Templates

This document explains what a template is in ZYMARG Product Grid, how to
create one, how styling works, how responsive behavior is configured, and
where the architecture is heading with the Component Library.

---

## What is a template?

A template is a **named visual configuration** for a product grid. It defines
how products are displayed — layout shape, card elements shown, column count,
spacing defaults. It knows nothing about which products to show.

```
Template  →  defines how products look
Source    →  defines which products to show
Consumer  →  chooses both
```

These are three completely independent responsibilities.

---

## The fundamental rule: templates never bind to a source

A template like `related-grid` does not mean "show related products using
this design." It means "use this design." The consumer (your standalone
plugin, shortcode, or Elementor widget) decides which source to query.

This means the same template can render:

```php
// Similar products — same template
Public_API::render( [
    'template' => 'related-grid',
    'query'    => [ 'source' => 'similar' ],
] );

// Vendor products — same template
Public_API::render( [
    'template' => 'related-grid',
    'query'    => [ 'source' => 'vendor' ],
] );

// Recommended products — same template
Public_API::render( [
    'template' => 'related-grid',
    'query'    => [ 'source' => 'recommended' ],
] );
```

The grid looks identical in all three cases. Only the products differ.
You never need a separate template per source combination.

---

## What a template configuration contains

A template config defines only visual/structural properties:

```php
[
    'query'  => [
        'limit'   => 8,      // sensible default size
        'orderby' => 'date', // default sort order
        // NO 'source' — ever
    ],
    'layout' => [
        'type'    => 'grid', // 'grid' | 'slider'
        'columns' => 4,      // desktop columns
    ],
    'card'   => [
        'show_vendor'       => false,
        'show_sold_count'   => true,
        'show_rating'       => true,
        'show_stock_badge'  => true,
        'show_discount_badge' => true,
    ],
    'heading' => [
        'show' => false,
    ],
    'pagination' => [
        'mode' => 'none', // 'none' | 'load_more'
    ],
    'responsive' => [
        'tablet' => [
            'layout' => [ 'columns' => 2 ],
            'card'   => [ 'show_sold_count' => false ],
        ],
        'mobile' => [
            'layout' => [ 'columns' => 1 ],
            'card'   => [ 'show_rating' => false, 'show_sold_count' => false ],
        ],
    ],
]
```

`Config_Normalizer` fills every key you omit with framework defaults.
You only write what makes your template unique.

---

## Built-in templates

| Slug            | Columns | Vendor | Sold count | Purpose |
|-----------------|---------|--------|------------|---------|
| `related-grid`  | 4       | ✗      | ✗          | Below-product related/similar sections |
| `store-grid`    | 4       | ✓      | ✗          | Vendor store pages |
| `homepage-grid` | 5       | ✓      | ✗          | Homepage featured sections |
| `category-grid` | 4       | ✓      | ✓          | Category archive pages |
| `search-grid`   | 4       | ✓      | ✓          | Search results pages |

These templates carry no source. Your consumer always specifies the source
when calling `Public_API::render()`.

---

## Built-in slots

Slots map a named page position to a template. They are the cleanest way for
standalone plugins to render a grid without knowing the template slug.

| Slot slug           | Default template  |
|---------------------|-------------------|
| `related-products`  | `related-grid`    |
| `store-products`    | `store-grid`      |
| `homepage-featured` | `homepage-grid`   |
| `category-products` | `category-grid`   |
| `search-results`    | `search-grid`     |

```php
// Slot call — standalone plugin does not need to know the template slug
Public_API::render( [
    'slot'  => 'related-products',
    'query' => [ 'source' => 'similar' ],
] );
```

---

## Per-template CSS and JS

Each card template folder can ship its own stylesheet and script. They are
loaded automatically by `Asset_Manager` when that template renders — no
manual registration needed.

```
templates/
└── cards/
    └── classic/
        ├── product-card.php   ← PHP template
        ├── style.css          ← loaded automatically when template renders
        └── script.js          ← loaded automatically when template renders (optional)
```

When you create a second template:

```
templates/
└── cards/
    ├── classic/
    │   ├── product-card.php
    │   └── style.css
    └── minimal/
        ├── product-card.php
        └── style.css          ← only loads when minimal template is used
```

`minimal/style.css` never loads when `classic` is rendering, and vice versa.
Each template is fully self-contained.

---

## Responsive columns via CSS custom properties

As of v2.0.3, the grid wrapper emits CSS custom properties for column counts:

```html
<div class="zymarg-wcpg__grid zymarg-wcpg__grid--cols-4"
     style="--columns-desktop:4;--columns-tablet:2;--columns-mobile:1;">
```

Your card template's `style.css` can use these instead of hardcoded values:

```css
/* templates/cards/classic/style.css */
.zymarg-wcpg__grid {
    display: grid;
    grid-template-columns: repeat( var(--columns-desktop), 1fr );
    gap: 20px;
}

@media ( max-width: 1024px ) {
    .zymarg-wcpg__grid {
        grid-template-columns: repeat( var(--columns-tablet), 1fr );
    }
}

@media ( max-width: 767px ) {
    .zymarg-wcpg__grid {
        grid-template-columns: repeat( var(--columns-mobile), 1fr );
    }
}
```

Now a standalone plugin can change column counts without touching any CSS:

```php
// Your Single Product plugin — 3 columns on tablet, 1 on mobile
Public_API::render( [
    'template' => 'related-grid',
    'query'    => [ 'source' => 'similar' ],
    'config'   => [
        'responsive' => [
            'tablet' => [ 'layout' => [ 'columns' => 3 ] ],
            'mobile' => [ 'layout' => [ 'columns' => 1 ] ],
        ],
    ],
] );
```

The CSS variables update, the layout adjusts. The template CSS never changes.

---

## Responsive card visibility

Beyond columns, the `responsive` config controls which card elements appear
at each breakpoint. The inheritance chain is desktop → tablet → mobile.

```php
Public_API::render( [
    'template' => 'related-grid',
    'query'    => [ 'source' => 'similar' ],
    'config'   => [
        'card' => [
            'show_rating'    => true,
            'show_sold_count' => true,
        ],
        'responsive' => [
            'tablet' => [
                'card' => [ 'show_sold_count' => false ], // hide sold count on tablet
            ],
            'mobile' => [
                'card' => [
                    'show_rating'    => false, // also hide rating on mobile
                    'show_sold_count' => false, // inherited from tablet, explicit here too
                ],
            ],
        ],
    ],
] );
```

Result:

| Breakpoint | Rating | Sold count |
|------------|--------|-----------|
| Desktop    | ✓      | ✓         |
| Tablet     | ✓      | ✗         |
| Mobile     | ✗      | ✗         |

No CSS changes. No separate templates. One render call.

---

## Registering a grid template config (Template_Registry)

These are named visual presets — layout, columns, card visibility defaults.
They do not contain a source.

```php
add_action( 'init', function () {
    \Zymarg\WCPG\Registry\Template_Registry::register(
        'flash-sale-grid',
        [
            'query'  => [ 'limit' => 6 ],
            'layout' => [ 'type' => 'grid', 'columns' => 6 ],
            'card'   => [
                'show_vendor'         => false,
                'show_discount_badge' => true,
                'show_stock_badge'    => true,
            ],
            'responsive' => [
                'tablet' => [ 'layout' => [ 'columns' => 3 ] ],
                'mobile' => [ 'layout' => [ 'columns' => 2 ] ],
            ],
        ],
        [
            'label'       => 'Flash Sale Grid',
            'description' => 'Compact high-density grid for time-limited sale sections.',
        ]
    );
} );
```

Once registered, use it anywhere:

```php
Public_API::render( [
    'template' => 'flash-sale-grid',
    'query'    => [ 'source' => 'featured' ],
] );
```

---

## Registering a card template (Template_Manager)

A card template is a PHP file that controls the HTML structure of each
product card — image container, title, price, badges, buttons.

This is the API for standalone template plugins. Register on `zymarg_wcpg_init`
so the core plugin is fully bootstrapped first.

```php
add_action( 'zymarg_wcpg_init', function () {
    \Zymarg\WCPG\Templates\Template_Manager::register_card(
        'fashion',                                              // slug
        plugin_dir_path( __FILE__ ) . 'templates/product-card.php' // absolute path
    );
} );
```

Then use it anywhere via `Public_API`:

```php
Public_API::render( [
    'config' => [
        'card' => [ 'template' => 'fashion' ],   // note: nested under 'card'
    ],
    'query'  => [ 'source' => 'trending' ],
] );
```

> **The slug must be nested under `card`.** The canonical location is
> `$config['card']['template']` — that is the only key `Config_Normalizer`
> reads. A top-level `$config['template']` is silently ignored and the render
> falls back to `classic` with no warning. Earlier revisions of this document
> showed the top-level form; it never worked. Corrected in v2.2.0.

Or via shortcode:

```
[zymarg_products card_template="fashion" source="trending"]
```

Or in the Elementor widget: **Content → Layout → Card template**, where every
registered template appears automatically (v2.2.0+).

### Validation rules

`register_card()` validates every registration and emits `E_USER_WARNING` (visible
in `debug.log` when `WP_DEBUG_LOG` is enabled) for any of these:

| Condition | Warning message |
|-----------|----------------|
| Empty slug | `Invalid slug ""` |
| Slug contains uppercase or special chars | `Invalid slug "Fashion"` — use `fashion` |
| Empty path | `Path for slug "fashion" must not be empty` |
| Slug matches a core template (`classic`) | `Cannot override core template "classic"` |
| Slug already registered by another plugin | `Card template "fashion" is already registered. First registration wins.` |

### Slug naming convention

Slugs must match `[a-z0-9_-]+`: lowercase letters, digits, hyphens, underscores.

```
fashion          ✅
fashion-grid     ✅
fashion_v2       ✅
Fashion          ❌  (uppercase rejected)
fashion grid     ❌  (space rejected)
classic          ❌  (core template — immutable)
```

### Unregistering (for testing)

```php
\Zymarg\WCPG\Templates\Template_Manager::unregister_card( 'fashion' );
```

Core templates (`classic`) cannot be unregistered. Primarily useful for
resetting state between automated tests.

---

## Creating a new card template (PHP file)

When you need a genuinely different card structure (not just different config
values), create a card template folder inside your standalone plugin:

```
my-template-plugin/
└── templates/
    └── product-card.php   ← your card HTML
```

Optionally add `style.css` and `script.js` in the same folder — if they
exist at the same path as the PHP file, `Asset_Manager` loads them
automatically when the template renders.

Register the card template via the public API on `zymarg_wcpg_init`:

```php
add_action( 'zymarg_wcpg_init', function () {
    \Zymarg\WCPG\Templates\Template_Manager::register_card(
        'minimal',
        plugin_dir_path( __FILE__ ) . 'templates/product-card.php'
    );
} );
```

Then use it anywhere:

```php
Public_API::render( [
    'config' => [
        'card' => [ 'template' => 'minimal' ],   // note: nested under 'card'
    ],
    'query'  => [ 'source' => 'trending' ],
] );
```

You never edit `Template_Manager` or any core plugin file. The standalone
plugin registers itself and is immediately available to all three consumers:

| Consumer | How to select the template |
|---|---|
| `Public_API` | `'config' => [ 'card' => [ 'template' => 'minimal' ] ]` |
| Shortcode | `[zymarg_products card_template="minimal"]` |
| Elementor widget | **Content → Layout → Card template** (v2.2.0+) |

The Elementor dropdown is populated from `get_registered_cards()` at
control-registration time, so activating a template plugin makes it selectable
with no change to the widget. To control how your template is labelled in that
dropdown, filter `zymarg_card_template_labels`:

```php
add_filter( 'zymarg_card_template_labels', function ( array $labels ) {
    $labels['minimal'] = 'Minimal (Editorial)';
    return $labels;
} );
```

---

## Reassigning a slot to a different template

If you want your store page to use a custom template instead of the default
`store-grid`, reassign the slot:

```php
add_filter( 'zymarg_product_grid_slots', function ( array $slots ): array {
    $slots['store-products']['template'] = 'my-premium-store-grid';
    return $slots;
} );
```

All callers using `slot: 'store-products'` now get your template automatically.
No code changes in any standalone plugin.

---

## Future direction: Component Library (Milestone 7+)

The senior developer's recommendation for the next major architectural step
is a **Component Library**. Rather than each card template reinventing the
HTML for rating, price, badges, etc., individual components become reusable
rendering units with configurable layout variants.

```
Card
├── Image component
├── Badge component     (discount badge, stock badge)
├── Title component
├── Rating component    → layout variants: full | compact | number-only
├── Vendor component
├── Price component
├── Sold count component
├── Add to Cart component
└── Wishlist component
```

Example — rating layout variants per breakpoint:

```php
'card' => [
    'rating_layout' => [
        'desktop' => 'full',    // ★★★★★ 4.8
        'tablet'  => 'full',    // ★★★★★ 4.8
        'mobile'  => 'compact', // ★ 4.8
    ],
],
```

The template assembles components in the order it wants. The Rating component
renders the appropriate variant based on the config. The same rating HTML
logic is never duplicated across templates.

**This is not yet implemented.** The current architecture (one PHP card
template file per design) is the right foundation. The Component Library
is the next layer. Build two or three card templates first — the duplication
you notice between them will tell you exactly which components to extract.

---

## Summary: what belongs where

| Concern | Where it lives |
|---------|---------------|
| Which products to show | `query.source` — chosen by the consumer |
| How many products | `query.limit` — template default, consumer can override |
| Grid columns (desktop) | `layout.columns` in template config |
| Grid columns (responsive) | `responsive.tablet.layout.columns`, `responsive.mobile.layout.columns` |
| CSS column layout | `--columns-desktop/tablet/mobile` CSS variables on the grid element |
| Which card elements show | `card.*` in template config |
| Responsive element visibility | `responsive.tablet.card.*`, `responsive.mobile.card.*` |
| Card HTML structure | `templates/cards/{slug}/product-card.php` |
| Card CSS and JS | `templates/cards/{slug}/style.css` and `script.js` — auto-loaded |
| Template → slot mapping | `Slot_Registry` |
| Template config registration | `Template_Registry` |
