# Standalone Plugin Integration

This guide explains how to build a standalone WordPress template plugin that
uses ZYMARG WC Product Grid as its rendering engine. This is the primary
integration pattern for ZYMARG's own ecosystem plugins (Single Product
Builder, Store Builder, Category Builder, etc.).

---

## The pattern

A standalone template plugin owns the page layout. ZYMARG Product Grid owns
product rendering. The plugin calls `Public_API::render()` and places the
result wherever it needs a grid.

```
Standalone Template Plugin
        │
        │  chooses template + source
        │  calls Public_API::render()
        ▼
ZYMARG Product Grid Engine
        │
        │  fetches products (source)
        │  renders grid (template)
        │  returns HTML string
        ▼
Standalone Template Plugin
        │
        │  echoes inside its template
        ▼
Browser
```

The standalone plugin never touches `Render_Engine`, `Query_Builder`,
`Template_Manager`, or any other internal class. It chooses two things:
**which template** (visual appearance) and **which source** (product data).
These are independent decisions.

---

## Plugin skeleton

```php
<?php
/**
 * Plugin Name: ZYMARG Single Product Builder
 * Description: Custom single product page template powered by ZYMARG Product Grid.
 * Version:     1.0.0
 * Requires Plugins: woocommerce, zymarg-wc-product-grid
 */

defined( 'ABSPATH' ) || exit;
```

---

## Availability check

Before calling `Public_API::render()`, always verify the engine is available:

```php
if ( ! class_exists( '\Zymarg\WCPG\Api\Public_API' ) ) {
    return; // Product Grid not active — skip silently.
}
```

---

## Template + source: the core pattern

Your standalone plugin always specifies template and source independently:

```php
\Zymarg\WCPG\Api\Public_API::render( [
    'template' => 'related-grid',  // visual appearance
    'query'    => [
        'source' => 'similar',     // which products
        'limit'  => 6,
    ],
] );
```

The same template with a different source:

```php
\Zymarg\WCPG\Api\Public_API::render( [
    'template' => 'related-grid',  // same visual appearance
    'query'    => [
        'source' => 'vendor',      // different products
        'limit'  => 6,
    ],
] );
```

Same card design. Different products. No template duplication.

---

## Single product page — multiple grids, one template

A complete single product page might show three distinct product sections,
all using the same visual template with different sources:

```php
// 1. Similar products
$html = \Zymarg\WCPG\Api\Public_API::render( [
    'template' => 'related-grid',
    'query'    => [ 'source' => 'similar', 'limit' => 6 ],
    'context'  => [ 'product_id' => get_the_ID() ],
] );
if ( \Zymarg\WCPG\Api\Public_API::HIDE_WIDGET !== $html ) {
    echo '<section class="similar-products"><h2>You May Also Like</h2>' . $html . '</section>';
}

// 2. More from this seller
$html = \Zymarg\WCPG\Api\Public_API::render( [
    'template' => 'related-grid',
    'query'    => [ 'source' => 'vendor', 'limit' => 6 ],
    'context'  => [ 'product_id' => get_the_ID() ],
] );
if ( \Zymarg\WCPG\Api\Public_API::HIDE_WIDGET !== $html ) {
    echo '<section class="more-from-seller"><h2>More From This Seller</h2>' . $html . '</section>';
}

// 3. Recommended for you
$html = \Zymarg\WCPG\Api\Public_API::render( [
    'template' => 'related-grid',
    'query'    => [ 'source' => 'recommended', 'limit' => 6 ],
    'context'  => [ 'product_id' => get_the_ID() ],
] );
if ( \Zymarg\WCPG\Api\Public_API::HIDE_WIDGET !== $html ) {
    echo '<section class="recommended"><h2>Recommended For You</h2>' . $html . '</section>';
}
```

One template. Three sources. The grid looks consistent throughout the page.

---

## Responsive overrides per section

Your standalone plugin can override responsive defaults without touching
the template or its CSS. The grid wrapper emits CSS custom properties
(`--columns-desktop`, `--columns-tablet`, `--columns-mobile`) that the
template stylesheet reads:

```php
\Zymarg\WCPG\Api\Public_API::render( [
    'template' => 'related-grid',
    'query'    => [ 'source' => 'similar', 'limit' => 8 ],
    'config'   => [
        'layout' => [ 'columns' => 4 ],
        'responsive' => [
            'tablet' => [ 'layout' => [ 'columns' => 3 ] ],
            'mobile' => [ 'layout' => [ 'columns' => 2 ] ],
        ],
    ],
] );
```

The template CSS never changes. Only the variable values update.

---

## Responsive card visibility overrides

```php
\Zymarg\WCPG\Api\Public_API::render( [
    'template' => 'related-grid',
    'query'    => [ 'source' => 'similar' ],
    'config'   => [
        'card' => [ 'show_rating' => true, 'show_sold_count' => true ],
        'responsive' => [
            'tablet' => [ 'card' => [ 'show_sold_count' => false ] ],
            'mobile' => [
                'card' => [
                    'show_rating'     => false,
                    'show_sold_count' => false,
                ],
            ],
        ],
    ],
] );
```

---

## Slot-based rendering (recommended for larger ecosystems)

If your ecosystem has multiple standalone plugins sharing the same visual
defaults, use slots. A slot is a named position that resolves to a registered
template — your plugin never needs to know the template slug:

```php
// In your Single Product plugin — just name the position
$html = \Zymarg\WCPG\Api\Public_API::render( [
    'slot'    => 'related-products',
    'query'   => [ 'source' => 'similar' ],
    'context' => [ 'product_id' => get_the_ID() ],
] );
```

To change the visual design across all consumers at once, reassign the slot:

```php
// In a config plugin — reassign once, all consumers update
add_filter( 'zymarg_product_grid_slots', function ( array $slots ): array {
    $slots['related-products']['template'] = 'my-premium-grid';
    return $slots;
} );
```

---

## Category archive grid

```php
function my_plugin_render_category_grid(): void {
    if ( ! class_exists( '\Zymarg\WCPG\Api\Public_API' ) ) {
        return;
    }

    echo \Zymarg\WCPG\Api\Public_API::render( [
        'template' => 'category-grid',
        'query'    => [ 'source' => 'category', 'limit' => 16 ],
        'config'   => [
            'pagination' => [ 'mode' => 'load_more' ],
            'responsive' => [
                'tablet' => [ 'layout' => [ 'columns' => 2 ] ],
                'mobile' => [ 'layout' => [ 'columns' => 1 ] ],
            ],
        ],
    ] );
}
```

---

## Vendor store grid

```php
function my_plugin_render_vendor_store(): void {
    if ( ! class_exists( '\Zymarg\WCPG\Api\Public_API' ) ) {
        return;
    }

    echo \Zymarg\WCPG\Api\Public_API::render( [
        'template' => 'store-grid',
        'query'    => [ 'source' => 'current_vendor', 'limit' => 12 ],
    ] );
}
```

`current_vendor` auto-detects the vendor from the current Dokan store URL.

---

## Pre-fetched products

If your plugin queries products itself, bypass the Query Engine entirely:

```php
$my_products = my_plugin_get_curated_products(); // WC_Product[]

echo \Zymarg\WCPG\Api\Public_API::render( [
    'template'  => 'related-grid',
    'products'  => $my_products,
] );
```

---

## Removing WooCommerce default output

When your standalone plugin takes over a WooCommerce page, remove the
default WooCommerce output to prevent duplicates:

```php
add_action( 'template_redirect', function () {
    if ( is_singular( 'product' ) && my_plugin_controls_this_page() ) {
        remove_action(
            'woocommerce_after_single_product_summary',
            'woocommerce_output_related_products',
            20
        );
    }
} );
```

---

## Debug mode

During development, add to `wp-config.php`:

```php
define( 'ZYMARG_DEBUG', true );
```

Every grid shows a bordered overlay (admins only) with source, template,
product count, cache status, consumer, context type, slot, and the resolved
layout file. Remove before going to production.
