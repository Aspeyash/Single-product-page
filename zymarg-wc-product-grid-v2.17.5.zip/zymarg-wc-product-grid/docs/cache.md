# ZYMARG WC Product Grid — Caching

> **Version:** 2.0.0
> **Class:** `includes/Services/class-cache-manager.php`

---

## Overview

The plugin caches the final rendered HTML for each unique product grid configuration. On a cache hit the entire pipeline (database query + template rendering) is skipped, returning stored HTML instantly.

```
Request
    │
    ▼
Public_API
    │
    ├─── Cache hit? ──YES──► return cached HTML
    │
    NO
    │
    ▼
Query + Render
    │
    ▼
Cache_Manager::set()
    │
    ▼
return HTML
```

---

## Cache backend

The cache uses **WordPress Object Cache** (wp_cache_*) when a persistent object cache (Redis, Memcached) is active. On standard hosting it falls back automatically to **transients** (wp_options table).

No configuration is needed — the correct backend is detected at runtime.

---

## Cache key

Each key is an MD5 hash of the values that affect rendered output:

| Component | Example |
|---|---|
| Cache version | `42` |
| Plugin version | `2.0.0` |
| Language | `en_US` |
| Layout type | `grid` |
| Card template | `classic` |
| Query source | `related` |
| Columns | `4` |
| Total products | `8` |
| Order | `date DESC` |
| Context fingerprint | `product_id=51\|vendor_id=7` |

Values that do **not** affect output are excluded: nonces, request IDs, timestamps, URLs, user identity (unless you add them via the filter).

---

## Cache invalidation

The plugin uses a **version-bump strategy**:

1. A single integer (`zymarg_cache_version`) is stored in `wp_options`.
2. Every cache key includes this version number.
3. When any product is updated, `invalidate_all()` increments the version.
4. All existing keys instantly become stale — no per-key tracking needed.

**Hooks that trigger invalidation:**

- `save_post_product`
- `deleted_post`
- `woocommerce_product_set_stock`
- `woocommerce_product_set_stock_status`
- `woocommerce_update_product`
- `clean_post_cache`
- `switch_theme`

To manually flush all plugin cache:

```php
\Zymarg\WCPG\Services\Cache_Manager::invalidate_all();
```

---

## Cache bypass conditions

The cache is automatically bypassed when:

- `WP_DEBUG_DISPLAY` is `true`
- WordPress Customizer preview is active (`is_customize_preview()`)
- WordPress post preview is active (`is_preview()`)
- Elementor editor is open (`?elementor-preview` in URL)
- Admin viewing a render preview (`context['is_preview']` + `manage_options`)
- The `zymarg_cache_enabled` filter returns `false`

---

## Filters and hooks

### `zymarg_cache_enabled`
**Type:** filter — returns `bool`

Disable cache for specific requests.

```php
// Disable cache for logged-in users.
add_filter( 'zymarg_cache_enabled', function ( bool $enabled, array $config, array $context ): bool {
    return is_user_logged_in() ? false : $enabled;
}, 10, 3 );
```

---

### `zymarg_cache_ttl`
**Type:** filter — returns `int` (seconds)

Change the cache lifetime. Return `0` to prevent storing this result.

```php
// Cache related-products grids for 10 minutes, everything else for 2.
add_filter( 'zymarg_cache_ttl', function ( int $ttl, string $key, string $html ): int {
    return str_contains( $key, 'source=related' ) ? 600 : 120;
}, 10, 3 );
```

Default: **300 seconds** (5 minutes).

---

### `zymarg_cache_key`
**Type:** filter — returns `array`

Add extra dimensions to the cache key. Use when your site varies output by factors the plugin doesn't know about (membership level, currency, A/B variant).

```php
// Vary by WooCommerce currency.
add_filter( 'zymarg_cache_key', function ( array $parts, array $config, array $context ): array {
    $parts['currency'] = get_woocommerce_currency();
    return $parts;
}, 10, 3 );
```

---

### `zymarg_cache_html`
**Type:** filter — returns `string`

Modify the HTML string immediately before it is stored. Rarely needed.

---

### `zymarg_before_cache_lookup`
**Type:** action | **Arguments:** `string $key`

Fires before every cache read. Use for profiling or logging.

---

### `zymarg_cache_hit`
**Type:** action | **Arguments:** `string $key`, `string $html`

Fires when a valid cache entry is found.

---

### `zymarg_cache_miss`
**Type:** action | **Arguments:** `string $key`

Fires when no valid cache entry exists and a full render will run.

---

### `zymarg_after_cache_store`
**Type:** action | **Arguments:** `string $key`, `string $html`, `int $ttl`

Fires after HTML is written to the cache.

---

## Testing checklist

| Scenario | Expected |
|---|---|
| First render | Cache miss → renders, stores HTML |
| Second identical render | Cache hit → no query, no template render |
| Different product context | Different cache key → fresh render |
| Different layout/template | Different cache key → fresh render |
| Different language | Different cache key → fresh render |
| Product updated | Version bumps → all keys stale → fresh render |
| Logged-in admin + preview | Cache bypassed |
| Elementor editor | Cache bypassed |
| WP_DEBUG_DISPLAY = true | Cache bypassed |
| Two grids, same config | Shared cache key → renders once |
| Extension filters (zymarg_products etc.) | Still execute on cache miss |
