# Public API

`Zymarg\WCPG\Api\Public_API` is the single entry point every external plugin
uses to render a product grid. Internal classes (Render_Engine, Query_Builder,
Template_Manager, etc.) are not part of the public contract and may change
between releases without notice. Only `Public_API::render()` is guaranteed
stable.

---

## Contract

```
Public_API::render(array $args): string
```

This signature will not change. Internal implementations may evolve freely
as long as the method accepts `$args` and returns a string.

### API version

```php
// Check the API version before calling render().
if ( version_compare( \Zymarg\WCPG\Api\Public_API::VERSION, '1.0.0', '>=' ) ) {
    $html = \Zymarg\WCPG\Api\Public_API::render( [ ... ] );
}
```

`Public_API::VERSION` is incremented only on breaking interface changes.
It is currently `'1.0.0'`.

---

## render()

```php
\Zymarg\WCPG\Api\Public_API::render( array $args = [] ): string
```

Renders a product grid and returns the complete HTML string. Never echoes.
Always safe to call — exceptions are caught internally and an empty string
is returned on failure. Never throws.

### Arguments

| Key         | Type            | Description |
|-------------|-----------------|-------------|
| `slot`      | `string`        | Named position registered via `Slot_Registry`. The engine resolves slot → template slug → config. |
| `template`  | `string`        | Template slug registered via `Template_Registry`. Bypasses slot resolution. |
| `config`    | `array`         | Complete or partial canonical config. Takes highest priority. |
| `query`     | `array`         | Query override merged into `config['query']`. Use to change source or limit without supplying a full config. |
| `products`  | `WC_Product[]`  | Pre-fetched product collection. When supplied, the Query Engine is skipped entirely. |
| `context`   | `array`         | Partial context passed to `Context_Resolver`. Use to supply `product_id`, `vendor_id`, etc. when the engine cannot detect them automatically. |
| `widget_id` | `string`        | Consumer-supplied instance identifier. Used by templates for unique DOM IDs (slider init, AJAX targets). |
| `is_preview`| `bool`          | Whether this render is inside a page-builder preview. Passed to templates; the engine itself does not branch on it. |

**Input priority** (highest → lowest):

1. `config` — used as-is; `Config_Normalizer` fills any missing keys with defaults.
2. `template` — slug loaded from `Template_Registry`.
3. `slot` — resolved to template slug, then config loaded from `Template_Registry`.

If none are supplied, `Config_Normalizer` applies all defaults and `source` defaults to `all`.

### Return value

| Value | Meaning |
|-------|---------|
| `string` (HTML) | Rendered product grid. May be an empty-state message if no products matched. |
| `''` (empty string) | The API was not yet initialized, or an unrecoverable internal error occurred. |
| `Public_API::HIDE_WIDGET` | The source determined that no output should be emitted for this context (e.g. "More From Seller" on a page with no current product). The **caller** decides what to show. |

### HIDE_WIDGET sentinel

```php
use Zymarg\WCPG\Api\Public_API;

$html = Public_API::render( [ 'slot' => 'related-products' ] );

if ( Public_API::HIDE_WIDGET === $html ) {
    // Source returned no results for this context.
    // Suppress the section entirely, or show a fallback.
    return;
}

echo $html;
```

`HIDE_WIDGET` is not an error. It is a deliberate signal from a
context-aware source (e.g. `vendor`, `similar`, `recommended`) that no
output is appropriate here. Always check for it before echoing.

---

## Examples

### Simplest call — render all products with defaults

```php
echo \Zymarg\WCPG\Api\Public_API::render();
```

### Slot-driven render (recommended for standalone template plugins)

```php
echo \Zymarg\WCPG\Api\Public_API::render( [
    'slot'    => 'related-products',
    'context' => [ 'product_id' => get_the_ID() ],
] );
```

### Template slug — bypass slot resolution

```php
echo \Zymarg\WCPG\Api\Public_API::render( [
    'template' => 'homepage-featured',
] );
```

### Inline config — full control

```php
echo \Zymarg\WCPG\Api\Public_API::render( [
    'config' => [
        'query'  => [ 'source' => 'trending', 'limit' => 8 ],
        'layout' => [ 'type' => 'grid', 'columns' => 4 ],
        'card'   => [
            'show_vendor'       => true,
            'show_stock_badge'  => true,
            'show_rating'       => true,
        ],
    ],
] );
```

### Query override — change source without touching config

```php
echo \Zymarg\WCPG\Api\Public_API::render( [
    'slot'  => 'category-products',
    'query' => [ 'source' => 'category', 'limit' => 12 ],
] );
```

### Pre-fetched products — bypass the Query Engine entirely

```php
$my_products = wc_get_products( [ 'limit' => 4, 'status' => 'publish' ] );

echo \Zymarg\WCPG\Api\Public_API::render( [
    'slot'     => 'flash-sale',
    'products' => $my_products,
] );
```

### With HIDE_WIDGET check (always do this for context-aware sources)

```php
use Zymarg\WCPG\Api\Public_API;

$html = Public_API::render( [
    'config' => [
        'query' => [ 'source' => 'vendor', 'limit' => 6 ],
    ],
    'context' => [ 'product_id' => get_the_ID() ],
] );

if ( Public_API::HIDE_WIDGET !== $html ) {
    echo '<section class="more-from-seller">';
    echo $html;
    echo '</section>';
}
```

---

## config[] structure

When passing a `config` array directly, the canonical structure is:

```php
[
    'query'      => [
        'source'             => 'all',       // See: sources reference
        'limit'              => 8,
        'orderby'            => 'date',
        'order'              => 'DESC',
        'include_categories' => [],          // int[]
        'exclude_categories' => [],          // int[]
        'include_products'   => [],          // int[]
        'exclude_products'   => [],          // int[]
    ],
    'layout'     => [
        'type'    => 'grid',                 // 'grid' | 'slider'
        'columns' => 4,                      // 1–6
    ],
    'card'       => [
        'show_image'          => true,
        'show_title'          => true,
        'show_price'          => true,
        'show_rating'         => true,
        'show_atc'            => true,
        'show_wishlist'       => true,
        'show_quickview'      => true,
        'show_vendor'         => false,      // off by default
        'show_sold_count'     => false,
        'show_discount_badge' => true,
        'show_stock_badge'    => true,
        'show_stock_in'       => false,      // "In stock" label
        'show_stock_out'      => true,       // "Out of stock" label
    ],
    'heading'    => [
        'show'          => false,
        'text'          => '',
        'tag'           => 'h2',
    ],
    'pagination' => [
        'mode' => 'none',                    // 'none' | 'load_more'
    ],
    'template'   => 'classic',              // card template slug
]
```

You do not need to supply every key. `Config_Normalizer` fills all missing
keys with their defaults before the config reaches the rendering layer.

---

## Sources reference

| Shortcode / config key | Description |
|------------------------|-------------|
| `all`                  | All published products |
| `featured`             | Products marked as featured |
| `best_selling`         | Ranked by `total_sales` descending |
| `trending`             | Recently high-velocity products |
| `recent`               | Newest products by publish date |
| `similar`              | Products similar to the current product (requires product context) |
| `vendor`               | Other products from the same seller — UI label: "More From Seller" (requires product context, Dokan) |
| `current_vendor`       | All products by the vendor on the current store page (Dokan store pages only) |
| `category`             | Products in the current or specified category |
| `wishlist`             | Products the current user has wishlisted |
| `dynamic`              | Dynamically configured source |
| `recommended`          | Per-visitor personalized feed |
| `algolia`              | Algolia-powered search results |

**Context-aware sources** (`similar`, `vendor`, `recommended`) return
`HIDE_WIDGET` when the required context cannot be resolved. Always check for it.

**Canonical key rule:** the registry key is the identifier used everywhere —
in `config['query']['source']`, shortcode attributes, and Elementor control
values. Human-readable labels ("More From Seller") appear only in the
Elementor widget UI. No aliases exist.

---

## query()

```php
Public_API::query( array $args = [] ): \WC_Product[]|string
```

`render()` is the entry point for anything that wants this plugin's markup.
`query()` is for the consumer that has its own layout, its own filters and its
own card loop, and only wants to borrow the query layer.

Before v2.12.0 such a consumer had two options and both were wrong:
re-implement the source logic, or call `Query_Builder` directly -- which is
internal and free to change without notice.

### Arguments

| Key | Type | Description |
|---|---|---|
| `query` | array | Query settings. Must include `source`. |
| `limit` | int | Products to return. Still bounded by `MAX_PRODUCTS`. |
| `offset` | int | Products to skip. Use for pagination. |
| `context` | array | Context values, merged *beneath* `query`. |

### Return value

| Value | Meaning |
|---|---|
| `WC_Product[]` | Zero or more products. An empty array means the source ran and matched nothing -- render your empty state. |
| `HIDE_WIDGET` | The source asked for no output, **or** the source key is unavailable. Render nothing at all. |

Like `render()`, this never throws. Internal failures return an empty array and
fire `zymarg_query_failed`.

### Unknown keys do NOT fall back

This is the one behavioural difference from `render()` worth internalising.
`Query_Builder::resolve_source()` substitutes `Source_All` for any key it does
not recognise, which is correct for a widget that must always show something.
For a consumer building a dedicated page it is a trap: a typo produces a page
of the entire catalogue that looks completely intentional.

`query()` therefore returns `HIDE_WIDGET` instead. Gate on `has_source()`
anyway, so you can choose the fallback yourself.

### Example

```php
if ( ! Public_API::has_source( $key ) ) {
    return $this->render_normal_page();
}

$products = Public_API::query( [
    'query'  => [ 'source' => $key ],
    'limit'  => 24,
    'offset' => $page * 24,
] );

if ( Public_API::HIDE_WIDGET === $products ) {
    return $this->render_normal_page();
}

foreach ( $products as $product ) {
    // your own card markup
}
```

### Pagination caveat

Sources return bounded arrays. There is no `found_posts` and no total count, so
you cannot show "1--24 of 812". Infer "has more" from a full batch, the way
`Handler_Load_More` does:

```php
$has_more = count( $products ) >= $per_page;
```

Both caps still apply: `MAX_PRODUCTS` (100) per call, and
`UNLIMITED_DEFAULT_CAP` (500) when a source runs unlimited. A feed is not an
endless scroll of the whole catalogue.

---

## has_source()

```php
Public_API::has_source( string $key ): bool
```

Whether a source key is registered **and** its class is actually loadable.

The second half is the entire reason this exists. A key can be registered while
the class implementing it ships in a later release; `resolve_source()` silently
substitutes `Source_All`, so an ungated caller renders a "Flash Deals" page
full of unrelated products and sees no error anywhere.

Use this instead of keeping a private hardcoded list of source keys. Such lists
go stale silently in both directions -- reporting a source that was removed, or
omitting one that was added.

```php
if ( Public_API::has_source( 'flash_deals' ) ) {
    // safe to query
}
```
