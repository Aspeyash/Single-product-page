# Upgrade Guide

---

## Upgrading to 2.0.3

### Built-in templates no longer embed a source — action may be required

If your code calls `Public_API::render()` using only a `template` or `slot`
argument and relies on the built-in template to supply a source, you must
now pass `query.source` explicitly.

**Before (relied on template's embedded source):**

```php
// Related products — worked because related-grid had source='similar' embedded
Public_API::render( [ 'slot' => 'related-products' ] );
```

**After (source is the consumer's responsibility):**

```php
Public_API::render( [
    'slot'  => 'related-products',
    'query' => [ 'source' => 'similar' ],
] );
```

The five built-in slots and templates affected:

| Slot / template | Old embedded source | Correct consumer source |
|---|---|---|
| `related-products` / `related-grid` | `similar` | `similar`, `vendor`, `recommended` — consumer decides |
| `store-products` / `store-grid` | `current_vendor` | `current_vendor` |
| `homepage-featured` / `homepage-grid` | `trending` | `trending`, `featured`, `best_selling` — consumer decides |
| `category-products` / `category-grid` | `category` | `category` |
| `search-results` / `search-grid` | `algolia` | `algolia`, or omit for WP search |

If you were calling `Public_API::render( [ 'slot' => 'store-products' ] )`
without a source and the grid showed vendor products correctly, that was
because the template happened to embed the right source. From 2.0.3 onward,
the correct call is:

```php
Public_API::render( [
    'slot'  => 'store-products',
    'query' => [ 'source' => 'current_vendor' ],
] );
```

Custom templates registered via `Template_Registry::register()` are
unaffected — they continue to work as registered.

### No other breaking changes

Per-template CSS/JS auto-loading and CSS custom properties are purely additive.
No existing code needs to change to benefit from them.

---

## Upgrading to 2.0.2

### Who is affected

- Developers who hook into `zymarg_layout_template`.
- Developers who call `Template_Manager::render_layout()` directly.

### `zymarg_layout_template` filter — behavior change

Before 2.0.2, this filter ran for lifecycle hooks (`zymarg_product_grid_before_render`)
but had no effect on the actual template file the renderer loaded. The filter
was wired but broken.

From 2.0.2 onward, the filter result is used by both hooks and the renderer.
If you had code hooked to `zymarg_layout_template` expecting it to only affect
hook arguments (and not the rendered output), that code will now also affect
what gets rendered. Review any existing hooks on this filter.

### `Template_Manager::render_layout()` — new optional parameter

The method signature changed from:

```php
render_layout( array $config, array $render_context ): string
```

to:

```php
render_layout( array $config, array $render_context, ?string $resolved_path = null ): string
```

The third parameter is optional and defaults to `null`. **Existing callers
passing two arguments are unaffected.** No action required unless you were
calling `render_layout()` directly (which should not be happening — this is
an internal method).

### `Render_Engine::render()` — new optional parameter

The method signature changed from:

```php
render( array $config, array $products, string $widget_id = '', bool $is_preview = false ): string
```

to:

```php
render( array $config, array $products, string $widget_id = '', bool $is_preview = false, array $debug_meta = [] ): string
```

The fifth parameter is optional. **Existing callers are unaffected.**

### No database changes

No new database tables, options, or transients are added in 2.0.2.
Cache invalidation does not require a manual flush after upgrading.

---

## Upgrading to 2.0.0

### Cache Manager introduced

The HTML render cache is enabled automatically. On sites with a persistent
object cache (Redis, Memcached), grids are cached immediately. On sites
without one, WordPress transients are used.

**If grids appear stale after upgrading:** flush the object cache or run
`Cache_Manager::invalidate_all()`. Saving any product will also invalidate
the cache automatically.

**To disable caching:** hook into `zymarg_cache_ttl` and return `0`, or
bypass the cache entirely by pre-supplying `products` to `Public_API::render()`.

### No breaking API changes

`Public_API::render()` and `Public_API::HIDE_WIDGET` are unchanged.

---

## Upgrading to 1.6.0 (Engine Foundation)

### Public API replaces direct class calls

Before 1.6.0, there was no stable public entry point. Any code calling
internal classes (`Render_Engine`, `Query_Builder`, etc.) directly must be
updated to use `Public_API::render()`.

### Template path change

The product card template moved to:

```
templates/cards/classic/product-card.php
```

The old path `templates/grid/product-card.php` is retained for backward
compatibility. Theme overrides at the old path continue to work.

**New theme overrides should use the new path:**

```
your-theme/zymarg-wcpg/cards/classic/product-card.php
```
