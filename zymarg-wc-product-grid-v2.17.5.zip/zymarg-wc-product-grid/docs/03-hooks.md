# Hooks & Filters Reference

All hooks are namespaced under `zymarg_` and fire in the order listed below.
Every hook passes typed parameters — never assume extra arguments exist beyond
what is documented here.

---

## Render pipeline hooks

These fire once per grid render, in order.

---

### `zymarg_product_grid_render_request`

**Type:** Action  
**File:** `includes/Api/class-public-api.php`  
**Since:** 1.6.0

Fires at the very start of a render request, before any pipeline work begins.
Use for logging, profiling, or cache-hit monitoring. Do not echo here.

```php
add_action( 'zymarg_product_grid_render_request', function ( array $args ) {
    // $args is the raw array passed to Public_API::render().
    error_log( 'Grid render requested: source = ' . ( $args['config']['query']['source'] ?? 'unknown' ) );
}, 10, 1 );
```

| Parameter | Type    | Description |
|-----------|---------|-------------|
| `$args`   | `array` | Raw render request arguments passed to `Public_API::render()`. |

---

### `zymarg_products`

**Type:** Filter  
**File:** `includes/Api/class-public-api.php`  
**Since:** 1.9.0

Filters the product collection after the Query Engine fetches it and before
the Render Engine receives it. Use to reorder, exclude, or inject products
without touching query logic.

Return value must be an array of `WC_Product` objects.

```php
add_filter( 'zymarg_products', function ( array $products, array $config, array $context ): array {
    // Put featured products first.
    usort( $products, fn( $a, $b ) => (int) $b->is_featured() - (int) $a->is_featured() );
    return $products;
}, 10, 3 );
```

| Parameter  | Type            | Description |
|------------|-----------------|-------------|
| `$products`| `WC_Product[]`  | Fetched product collection. |
| `$config`  | `array`         | Normalized render config. |
| `$context` | `array`         | Resolved page context. |

---

### `zymarg_product_grid_before_render`

**Type:** Action  
**File:** `includes/Render/class-render-engine.php`  
**Since:** 1.6.0

Fires after products are fetched and just before the layout wrapper template
is included. Do not echo here — use `zymarg_product_grid_html` to modify output.

```php
add_action(
    'zymarg_product_grid_before_render',
    function ( array $config, array $products, string $template_file, array $render_context ) {
        // Log which layout file is about to render.
        error_log( 'Rendering: ' . $template_file . ' with ' . count( $products ) . ' products' );
    },
    10, 4
);
```

| Parameter        | Type           | Description |
|------------------|----------------|-------------|
| `$config`        | `array`        | Normalized configuration. |
| `$products`      | `WC_Product[]` | Product collection. |
| `$template_file` | `string`       | Resolved layout wrapper path (relative to `/templates/`). |
| `$render_context`| `array`        | Full render context passed to the template. |

---

### `zymarg_layout_template`

**Type:** Filter  
**File:** `includes/Templates/class-template-manager.php`  
**Since:** 1.9.0

Filters the layout wrapper path before it is loaded. Return a path relative
to `/templates/`. Use to substitute a completely custom layout wrapper without
forking the plugin.

As of v2.0.2, this filter fires exactly once per render and the result is
used both by lifecycle hooks and by the renderer — hooks and the loaded file
are always the same path.

```php
add_filter(
    'zymarg_layout_template',
    function ( string $path, string $layout_type, array $config ): string {
        if ( 'grid' === $layout_type && is_singular( 'product' ) ) {
            return 'grid/single-product-grid-wrapper.php';
        }
        return $path;
    },
    10, 3
);
```

| Parameter     | Type     | Description |
|---------------|----------|-------------|
| `$path`       | `string` | Resolved path relative to `/templates/`. |
| `$layout_type`| `string` | Layout type slug: `'grid'` or `'slider'`. |
| `$config`     | `array`  | Normalized render config. |

---

### `zymarg_product_grid_html`

**Type:** Filter  
**File:** `includes/Render/class-render-engine.php`  
**Since:** 1.6.0

Filters the complete rendered grid HTML after the template has run, before
it is returned to the caller. Use for output wrappers, post-render
transformations, or A/B testing.

```php
add_filter(
    'zymarg_product_grid_html',
    function ( string $html, array $config, array $products, string $template_file ): string {
        return '<div class="my-grid-wrapper">' . $html . '</div>';
    },
    10, 4
);
```

| Parameter        | Type           | Description |
|------------------|----------------|-------------|
| `$html`          | `string`       | Complete rendered grid HTML. |
| `$config`        | `array`        | Normalized configuration. |
| `$products`      | `WC_Product[]` | Product collection. |
| `$template_file` | `string`       | Layout wrapper path that was used. |

---

### `zymarg_product_grid_after_render`

**Type:** Action  
**File:** `includes/Render/class-render-engine.php`  
**Since:** 1.6.0

Fires after the grid HTML has been produced and all filters applied. Use for
analytics events, cache population, or logging.

```php
add_action(
    'zymarg_product_grid_after_render',
    function ( string $html, array $config, array $products ) {
        // Track impression count.
        do_action( 'my_analytics_grid_impression', count( $products ) );
    },
    10, 3
);
```

| Parameter   | Type           | Description |
|-------------|----------------|-------------|
| `$html`     | `string`       | Final HTML string. |
| `$config`   | `array`        | Normalized configuration. |
| `$products` | `WC_Product[]` | Product collection. |

---

### `zymarg_product_grid_render_complete`

**Type:** Action  
**File:** `includes/Api/class-public-api.php`  
**Since:** 1.6.0

Fires after the render pipeline completes, including cache writes. Also fires
on cache hits (with the cached HTML). Use for request-level logging.

```php
add_action(
    'zymarg_product_grid_render_complete',
    function ( string $html, array $args ) {
        error_log( 'Grid render complete. HTML length: ' . strlen( $html ) );
    },
    10, 2
);
```

| Parameter | Type     | Description |
|-----------|----------|-------------|
| `$html`   | `string` | Final HTML string (may be from cache). |
| `$args`   | `array`  | Original render request arguments. |

---

## Card lifecycle hooks

These fire once per product card, inside the card template.

---

### `zymarg_card_classes`

**Type:** Filter  
**File:** `templates/cards/classic/product-card.php`  
**Since:** 1.9.0

Filters the CSS class array applied to the card wrapper `<div>`. Use to add
membership tiers, animation classes, A/B test variants, or schema markup classes.

```php
add_filter(
    'zymarg_card_classes',
    function ( array $classes, \WC_Product $product, array $settings ): array {
        if ( $product->is_on_sale() ) {
            $classes[] = 'is-sale-featured';
        }
        return $classes;
    },
    10, 3
);
```

| Parameter   | Type          | Description |
|-------------|---------------|-------------|
| `$classes`  | `string[]`    | Existing class array. |
| `$product`  | `WC_Product`  | Current product. |
| `$settings` | `array`       | Flattened render settings. |

---

### `zymarg_card_attributes`

**Type:** Filter  
**File:** `templates/cards/classic/product-card.php`  
**Since:** 1.9.0

Filters extra HTML attributes added to the card wrapper `<div>`. Return an
associative array of `attribute => value` pairs.

```php
add_filter(
    'zymarg_card_attributes',
    function ( array $attrs, \WC_Product $product, array $settings ): array {
        $attrs['data-brand'] = get_post_meta( $product->get_id(), '_brand', true );
        return $attrs;
    },
    10, 3
);
```

| Parameter   | Type         | Description |
|-------------|--------------|-------------|
| `$attrs`    | `array`      | Existing attribute map (empty by default). |
| `$product`  | `WC_Product` | Current product. |
| `$settings` | `array`      | Flattened render settings. |

---

### `zymarg_before_card`

**Type:** Action  
**File:** `templates/cards/classic/product-card.php`  
**Since:** 1.9.0

Fires immediately before the card content starts rendering, inside the
ob_start() buffer. Anything echoed here appears before the card image.

```php
add_action(
    'zymarg_before_card',
    function ( \WC_Product $product, array $settings ) {
        if ( $product->is_featured() ) {
            echo '<div class="featured-ribbon">Featured</div>';
        }
    },
    10, 2
);
```

| Parameter   | Type         | Description |
|-------------|--------------|-------------|
| `$product`  | `WC_Product` | Current product. |
| `$settings` | `array`      | Flattened render settings. |

---

### `zymarg_before_card_image`

**Type:** Action  
**File:** `templates/cards/classic/product-card.php`  
**Since:** 1.9.0

Fires inside the image container, before the image tag.

| Parameter   | Type         | Description |
|-------------|--------------|-------------|
| `$product`  | `WC_Product` | Current product. |
| `$settings` | `array`      | Flattened render settings. |

---

### `zymarg_after_card_image`

**Type:** Action  
**File:** `templates/cards/classic/product-card.php`  
**Since:** 1.9.0

Fires inside the image container, after the image tag and overlay buttons.

| Parameter   | Type         | Description |
|-------------|--------------|-------------|
| `$product`  | `WC_Product` | Current product. |
| `$settings` | `array`      | Flattened render settings. |

---

### `zymarg_before_card_title`

**Type:** Action  
**File:** `templates/cards/classic/product-card.php`  
**Since:** 1.9.0

Fires in the card content area, before the product title row.

| Parameter   | Type         | Description |
|-------------|--------------|-------------|
| `$product`  | `WC_Product` | Current product. |
| `$settings` | `array`      | Flattened render settings. |

---

### `zymarg_after_card_title`

**Type:** Action  
**File:** `templates/cards/classic/product-card.php`  
**Since:** 1.9.0

Fires in the card content area, after the product title row.

| Parameter   | Type         | Description |
|-------------|--------------|-------------|
| `$product`  | `WC_Product` | Current product. |
| `$settings` | `array`      | Flattened render settings. |

---

### `zymarg_before_card_price`

**Type:** Action  
**File:** `templates/cards/classic/product-card.php`  
**Since:** 1.9.0

Fires before the price display in the card content area.

| Parameter   | Type         | Description |
|-------------|--------------|-------------|
| `$product`  | `WC_Product` | Current product. |
| `$settings` | `array`      | Flattened render settings. |

---

### `zymarg_after_card_price`

**Type:** Action  
**File:** `templates/cards/classic/product-card.php`  
**Since:** 1.9.0

Fires after the price display in the card content area.

| Parameter   | Type         | Description |
|-------------|--------------|-------------|
| `$product`  | `WC_Product` | Current product. |
| `$settings` | `array`      | Flattened render settings. |

---

### `zymarg_before_add_to_cart`

**Type:** Action  
**File:** `templates/cards/classic/product-card.php`  
**Since:** 1.9.0

Fires before the Add to Cart button renders.

| Parameter   | Type         | Description |
|-------------|--------------|-------------|
| `$product`  | `WC_Product` | Current product. |
| `$settings` | `array`      | Flattened render settings. |

---

### `zymarg_after_add_to_cart`

**Type:** Action  
**File:** `templates/cards/classic/product-card.php`  
**Since:** 1.9.0

Fires after the Add to Cart button renders.

| Parameter   | Type         | Description |
|-------------|--------------|-------------|
| `$product`  | `WC_Product` | Current product. |
| `$settings` | `array`      | Flattened render settings. |

---

### `zymarg_after_card`

**Type:** Action  
**File:** `templates/cards/classic/product-card.php`  
**Since:** 1.9.0

Fires immediately after the card wrapper `</div>` closes, still inside the
ob_start() buffer. Content added here is included in `zymarg_card_html`.

| Parameter   | Type         | Description |
|-------------|--------------|-------------|
| `$product`  | `WC_Product` | Current product. |
| `$settings` | `array`      | Flattened render settings. |

---

### `zymarg_card_html`

**Type:** Filter  
**File:** `templates/cards/classic/product-card.php`  
**Since:** 1.9.0

Filters the complete HTML of one product card after the entire template has
run. This includes anything added by `zymarg_before_card` and `zymarg_after_card`.
Use to wrap, replace, or post-process individual card HTML.

```php
add_filter(
    'zymarg_card_html',
    function ( string $html, \WC_Product $product, array $settings ): string {
        // Wrap every card in a tracking container.
        $id = esc_attr( (string) $product->get_id() );
        return '<div class="tracked-card" data-product-id="' . $id . '">' . $html . '</div>';
    },
    10, 3
);
```

| Parameter   | Type         | Description |
|-------------|--------------|-------------|
| `$html`     | `string`     | Complete card HTML including before/after content. |
| `$product`  | `WC_Product` | Current product. |
| `$settings` | `array`      | Flattened render settings. |

---

### `zymarg_card_template`

**Type:** Filter  
**File:** `includes/Templates/class-template-manager.php`  
**Since:** 1.9.0

Filters the card template slug before it is resolved to a file path. Use to
substitute a different card design per-product or per-context without
changing the shortcode or widget.

```php
add_filter(
    'zymarg_card_template',
    function ( string $template, array $args ): string {
        // Use a minimal template for out-of-stock products.
        if ( $args['product'] instanceof \WC_Product && ! $args['product']->is_in_stock() ) {
            return 'minimal';
        }
        return $template;
    },
    10, 2
);
```

| Parameter   | Type     | Description |
|-------------|----------|-------------|
| `$template` | `string` | Card template slug (`'classic'`, `'minimal'`, …). |
| `$args`     | `array`  | Render args: `product`, `config`, `settings`, `widget_id`. |

---

## Query hooks

---

### `zymarg_wcpg_source_registry`

**Type:** Filter  
**File:** `includes/Query/class-query-builder.php`  
**Since:** 1.9.0

Filters the source registry map used by `Query_Builder`. Use to register a
custom source class without modifying core files.

```php
add_filter(
    'zymarg_wcpg_source_registry',
    function ( array $registry ): array {
        $registry['my_custom_source'] = \MyPlugin\Source_Custom::class;
        return $registry;
    }
);
```

Your class must extend `Zymarg\WCPG\Query\Source_Base` and implement
`get_products( array $settings )`. See `06-custom-sources.md` for a full
example.

| Parameter   | Type                    | Description |
|-------------|-------------------------|-------------|
| `$registry` | `array<string, string>` | Map of source key → fully qualified class name. |
