# Custom Sources

A custom source tells the Query Engine how to fetch a specific set of products.
You can register new sources without modifying the plugin using the
`zymarg_wcpg_source_registry` filter.

---

## Source class requirements

Your source class must:

1. Extend `Zymarg\WCPG\Query\Source_Base`
2. Implement `get_products( array $settings ): array|string`

`get_products()` returns either:
- An array of `WC_Product` objects (may be empty — engine shows empty state)
- `self::HIDE_WIDGET` — suppress all output for this render (not an error)

---

## Minimal example

```php
<?php

namespace MyPlugin;

use Zymarg\WCPG\Query\Source_Base;

defined( 'ABSPATH' ) || exit;

/**
 * Source: My Custom Products
 *
 * Returns products tagged with 'staff-pick'.
 */
class Source_Staff_Picks extends Source_Base {

    /**
     * @param array $settings Flattened render settings.
     * @return \WC_Product[]|string
     */
    public function get_products( array $settings ) {
        $limit = $this->get_limit( $settings );

        $ids = wc_get_products( [
            'limit'  => $limit,
            'status' => 'publish',
            'tag'    => 'staff-pick',
            'return' => 'ids',
        ] );

        if ( empty( $ids ) ) {
            return self::HIDE_WIDGET;
        }

        $products = array_filter(
            array_map( 'wc_get_product', $ids ),
            fn( $p ) => $p instanceof \WC_Product && $p->is_visible()
        );

        return array_values( $products );
    }
}
```

---

## Registering the source

```php
add_filter(
    'zymarg_wcpg_source_registry',
    function ( array $registry ): array {
        $registry['staff_picks'] = \MyPlugin\Source_Staff_Picks::class;
        return $registry;
    }
);
```

Once registered, `staff_picks` becomes a valid source key everywhere:

```php
// PHP / standalone plugin
echo \Zymarg\WCPG\Api\Public_API::render( [
    'config' => [
        'query' => [ 'source' => 'staff_picks', 'limit' => 8 ],
    ],
] );
```

```
[zymarg_products source="staff_picks" limit="8"]
```

---

## Source_Base helper methods

`Source_Base` provides utilities your source can use:

| Method | Description |
|--------|-------------|
| `$this->get_limit( $settings )` | Returns the configured product limit, clamped to `Query_Builder::MAX_PRODUCTS`. |
| `$this->fetch_products_by_ids( $ids, $limit )` | Fetches `WC_Product` objects from an ID array, respecting the limit. |
| `$this->apply_shared_filters( $products, $settings )` | Applies shared visibility and stock filters. |
| `$this->get_visibility_tax_clause()` | Returns a WP_Query `tax_query` clause for WooCommerce product visibility. |

---

## Context-aware source example

For sources that need page context (e.g. current product, current vendor),
detect the context from `$settings` which is populated by `Query_Adapter`
before your `get_products()` is called.

```php
class Source_Recently_Viewed extends Source_Base {

    public function get_products( array $settings ) {
        // Query_Adapter places context values into $settings.
        $viewed = isset( $_COOKIE['recently_viewed'] )
            ? array_map( 'intval', explode( ',', sanitize_text_field( $_COOKIE['recently_viewed'] ) ) )
            : [];

        if ( empty( $viewed ) ) {
            return self::HIDE_WIDGET; // Nothing to show — suppress entirely.
        }

        $limit    = $this->get_limit( $settings );
        $products = $this->fetch_products_by_ids( $viewed, $limit );

        return $products ?: self::HIDE_WIDGET;
    }
}
```

Register it:

```php
add_filter( 'zymarg_wcpg_source_registry', function ( array $registry ): array {
    $registry['recently_viewed'] = \MyPlugin\Source_Recently_Viewed::class;
    return $registry;
} );
```

---

## HIDE_WIDGET vs empty array

| Return value | Engine behaviour |
|---|---|
| `self::HIDE_WIDGET` | No HTML is emitted at all. `Public_API::HIDE_WIDGET` is returned to the caller. The section is completely suppressed. |
| `[]` (empty array) | The grid renders with the empty-state message ("No products found."). |

Use `HIDE_WIDGET` when the source itself is not applicable in the current
context (e.g. "More From Seller" on a page with no current product).
Use an empty array when the source is applicable but simply has no results.

---

## Naming convention

The registry key is the canonical identifier. Use it consistently:

- PHP: `'source' => 'staff_picks'`
- Shortcode: `source="staff_picks"`
- Elementor control value: `'staff_picks'`
- Elementor control label: `'Staff Picks'` (human-readable, UI only)

No aliases. One key.
