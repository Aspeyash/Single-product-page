# Extension Development Guide

An extension plugin customizes ZYMARG WC Product Grid through its public
hook API without modifying any plugin files. Extensions survive every plugin
update, can be enabled or disabled independently, and are safe to distribute.

---

## Extension plugin skeleton

```php
<?php
/**
 * Plugin Name: My ZYMARG Extension
 * Description: Customizes ZYMARG Product Grid cards.
 * Version:     1.0.0
 * Requires Plugins: zymarg-wc-product-grid
 */

defined( 'ABSPATH' ) || exit;
```

`Requires Plugins: zymarg-wc-product-grid` tells WordPress that this plugin
depends on the Product Grid. WordPress will warn the user if the dependency is
missing.

---

## What extensions can do

| Capability | Hook |
|-----------|------|
| Inject HTML before a card | `zymarg_before_card` |
| Inject HTML after a card | `zymarg_after_card` |
| Add CSS classes to a card | `zymarg_card_classes` |
| Add HTML attributes to a card | `zymarg_card_attributes` |
| Wrap or replace a complete card | `zymarg_card_html` |
| Switch card template per product | `zymarg_card_template` |
| Substitute a custom layout file | `zymarg_layout_template` |
| Reorder or filter the product list | `zymarg_products` |
| Register a custom query source | `zymarg_wcpg_source_registry` |
| Log or profile render requests | `zymarg_product_grid_render_request` |
| Wrap or post-process grid HTML | `zymarg_product_grid_html` |

---

## Examples

### Add a ribbon badge to featured products

```php
add_action(
    'zymarg_before_card',
    function ( \WC_Product $product, array $settings ) {
        if ( $product->is_featured() ) {
            echo '<div class="my-featured-ribbon">⭐ Featured</div>';
        }
    },
    10, 2
);
```

---

### Add a custom CSS class based on product metadata

```php
add_filter(
    'zymarg_card_classes',
    function ( array $classes, \WC_Product $product, array $settings ): array {
        $tier = get_post_meta( $product->get_id(), '_membership_tier', true );
        if ( $tier ) {
            $classes[] = 'membership-tier-' . sanitize_html_class( $tier );
        }
        return $classes;
    },
    10, 3
);
```

---

### Wrap every card in a tracking element

```php
add_filter(
    'zymarg_card_html',
    function ( string $html, \WC_Product $product, array $settings ): string {
        return sprintf(
            '<div class="tracked-product" data-product-id="%d">%s</div>',
            $product->get_id(),
            $html
        );
    },
    10, 3
);
```

---

### Add a custom data attribute to cards

```php
add_filter(
    'zymarg_card_attributes',
    function ( array $attrs, \WC_Product $product, array $settings ): array {
        $attrs['data-sku'] = esc_attr( $product->get_sku() );
        return $attrs;
    },
    10, 3
);
```

---

### Switch to a different card template for out-of-stock products

```php
add_filter(
    'zymarg_card_template',
    function ( string $template, array $args ): string {
        $product = $args['product'] ?? null;
        if ( $product instanceof \WC_Product && ! $product->is_in_stock() ) {
            return 'minimal'; // Must be registered in Template_Manager::CARD_TEMPLATES.
        }
        return $template;
    },
    10, 2
);
```

---

### Replace the layout wrapper on a specific page

```php
add_filter(
    'zymarg_layout_template',
    function ( string $path, string $layout_type, array $config ): string {
        if ( is_page( 'flash-sale' ) && 'grid' === $layout_type ) {
            // Your theme or plugin must supply this file.
            return 'grid/flash-sale-wrapper.php';
        }
        return $path;
    },
    10, 3
);
```

---

### Reorder products — featured first

```php
add_filter(
    'zymarg_products',
    function ( array $products, array $config, array $context ): array {
        usort(
            $products,
            fn( \WC_Product $a, \WC_Product $b ) =>
                (int) $b->is_featured() - (int) $a->is_featured()
        );
        return $products;
    },
    10, 3
);
```

---

### Register a custom query source

See `06-custom-sources.md` for a complete walkthrough. In short:

```php
add_filter(
    'zymarg_wcpg_source_registry',
    function ( array $registry ): array {
        $registry['my_source'] = \MyPlugin\Source_My_Source::class;
        return $registry;
    }
);
```

---

## Bootstrap hook for template registration

Template plugins must register on `zymarg_wcpg_init`, which fires at the end
of `Plugin::init()` after all core subsystems are ready:

```php
add_action( 'zymarg_wcpg_init', function () {
    \Zymarg\WCPG\Templates\Template_Manager::register_card(
        'fashion',
        plugin_dir_path( __FILE__ ) . 'templates/product-card.php'
    );
} );
```

`zymarg_wcpg_loaded` fires immediately after and is also safe, but
`zymarg_wcpg_init` is the preferred and documented hook for template packs.
Do not register on `plugins_loaded`, `init`, or `wp` — `Template_Manager`
may not be autoloaded yet at those points.

---

## Checking API availability

Always guard your extension code against the plugin not being active:

```php
// Method 1 — check the class exists.
if ( class_exists( '\Zymarg\WCPG\Api\Public_API' ) ) {
    // safe to hook in
}

// Method 2 — check the API version.
if (
    class_exists( '\Zymarg\WCPG\Api\Public_API' ) &&
    version_compare( \Zymarg\WCPG\Api\Public_API::VERSION, '1.0.0', '>=' )
) {
    // safe to hook in
}

// Method 3 — use the Requires Plugins header (recommended, no PHP check needed).
// WordPress handles the dependency — your plugin simply won't activate without it.
```

---

## Rules for extensions

These rules keep extensions forward-compatible:

1. **Never call internal classes directly.** Only `Public_API` is public.
   `Render_Engine`, `Template_Manager`, `Query_Builder`, `Config_Normalizer`
   etc. are internal and may change.

2. **Never include or require plugin files.** Use hooks only.

3. **Return the correct type from filters.** `zymarg_card_html` must return
   a string. `zymarg_card_classes` must return an array. `zymarg_products`
   must return an array of `WC_Product` objects.

4. **Always pass the correct `$accepted_args` to `add_filter`/`add_action`.**
   Some hooks pass 2–4 parameters; you must declare them explicitly:
   ```php
   add_filter( 'zymarg_card_html', $callback, 10, 3 ); // 3 params
   add_action( 'zymarg_before_card', $callback, 10, 2 ); // 2 params
   ```

5. **Do not echo inside filters.** Filters must return the modified value.
   Only actions should echo.
