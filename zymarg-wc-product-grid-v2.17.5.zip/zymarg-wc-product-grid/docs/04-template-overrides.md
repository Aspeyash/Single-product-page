# Template Overrides

ZYMARG WC Product Grid supports WordPress-style theme overrides for all
template files. You can customize any template without modifying plugin files,
so your changes survive plugin updates.

---

## Override directory

Place overrides in your active theme under:

```
your-theme/
└── zymarg-wcpg/
    └── <relative-path-from-plugin-templates-folder>
```

The override path mirrors the plugin's `templates/` folder exactly, but
without the `templates/` prefix.

**Plugin file:**
```
zymarg-wc-product-grid/templates/cards/classic/product-card.php
```

**Theme override:**
```
your-theme/zymarg-wcpg/cards/classic/product-card.php
```

---

## Resolution order

For every template request, `Template_Loader` checks in this order:

1. `your-theme/zymarg-wcpg/<path>` — theme override wins if found.
2. `zymarg-wc-product-grid/templates/<path>` — plugin default used as fallback.

If the theme override file is missing or deleted, the plugin file loads
automatically. No cache flush is needed.

---

## What can be overridden

Every file under `templates/` supports theme overrides.

| Plugin path | What it controls |
|-------------|-----------------|
| `templates/cards/classic/product-card.php` | Individual product card HTML |
| `templates/grid/grid-wrapper.php` | Grid layout wrapper (columns, heading, pagination) |
| `templates/slider/slider-wrapper.php` | Slider layout wrapper (Swiper config, arrows, pagination) |
| `templates/parts/empty-state.php` | Output when no products match |

---

## Card template override

The most common override. Copy the plugin's card template into your theme:

```
your-theme/
└── zymarg-wcpg/
    └── cards/
        └── classic/
            └── product-card.php
```

Edit freely. The override only applies to the `classic` card template.
If a second card template is registered (e.g. `minimal`), its override
path would be `zymarg-wcpg/cards/minimal/product-card.php`.

### Verify the override is loading

Temporarily add a visible marker at the top of your override file,
immediately after `defined( 'ABSPATH' ) || exit;`:

```php
echo '<div style="background:red;color:#fff;padding:6px;">THEME OVERRIDE ACTIVE</div>';
```

If the banner appears on every card, your override is loading correctly.
Remove it when done.

---

## Layout wrapper override

To replace the entire grid layout (heading block, column wrapper,
pagination button):

```
your-theme/
└── zymarg-wcpg/
    └── grid/
        └── grid-wrapper.php
```

> **Important:** The layout wrapper calls `Template_Manager::render_card()`
> for each product. Your override must keep this call intact, or cards will
> not render. Do not call `Template_Loader::get_template()` directly for the
> card file — `Template_Manager` handles card template resolution and
> theme overrides for cards automatically.

The correct pattern inside your override:

```php
foreach ( $products as $product ) {
    echo \Zymarg\WCPG\Templates\Template_Manager::render_card(
        $config['template'] ?? 'classic',
        [
            'product'   => $product,
            'settings'  => $settings,
            'config'    => $config,
            'widget_id' => $widget_id,
        ]
    );
}
```

---

## Slider wrapper override

```
your-theme/
└── zymarg-wcpg/
    └── slider/
        └── slider-wrapper.php
```

Same rules apply as the grid wrapper — keep the `render_card()` call intact
inside the `swiper-slide` loop.

---

## Available variables

All template files receive these variables via `extract()`:

| Variable     | Type            | Description |
|--------------|-----------------|-------------|
| `$config`    | `array`         | Full normalized config. Canonical source of truth. |
| `$settings`  | `array`         | Flattened settings (backward-compatible alias). |
| `$products`  | `WC_Product[]`  | Product collection. |
| `$widget_id` | `string`        | Consumer instance identifier. |
| `$is_preview`| `bool`          | Whether rendering inside a page-builder preview. |

Inside `product-card.php` specifically:

| Variable    | Type         | Description |
|-------------|--------------|-------------|
| `$product`  | `WC_Product` | The current product object. |
| `$settings` | `array`      | Flattened render settings. |
| `$config`   | `array`      | Full normalized config. |
| `$widget_id`| `string`     | Consumer instance identifier. |

---

## Using hooks instead of overrides

For targeted customizations, hooks are often cleaner than a full template
override because they survive card template updates automatically.

| Goal | Recommended approach |
|------|---------------------|
| Add HTML before every card | `zymarg_before_card` action |
| Add HTML after every card | `zymarg_after_card` action |
| Add a CSS class to the card | `zymarg_card_classes` filter |
| Wrap or replace a card's HTML | `zymarg_card_html` filter |
| Replace the layout file | `zymarg_layout_template` filter |
| Switch card template per product | `zymarg_card_template` filter |

See `03-hooks.md` for full hook reference and examples.

---

## Child theme support

Override files placed in a child theme take priority over the parent theme.
The resolution order is:

1. Child theme `zymarg-wcpg/<path>`
2. Parent theme `zymarg-wcpg/<path>`
3. Plugin `templates/<path>`

This follows WordPress's standard `locate_template()` behaviour.

---

## Important: do not call layout wrappers directly

After Milestone 6, only `Template_Manager` knows which layout wrapper file
to load. Calling `Template_Loader::get_template('grid/grid-wrapper.php', ...)`
directly from outside the plugin bypasses `Template_Manager` and will trigger
a PHP notice because `$config` will be undefined.

Always render through the public API:

```php
// Correct — goes through the full pipeline.
echo \Zymarg\WCPG\Api\Public_API::render( [ 'config' => $config ] );

// Wrong — bypasses Template_Manager, $config will be undefined.
\Zymarg\WCPG\Template_Loader::get_template( 'grid/grid-wrapper.php', [...] );
```
