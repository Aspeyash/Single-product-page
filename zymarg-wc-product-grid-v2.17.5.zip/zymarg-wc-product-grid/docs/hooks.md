# ZYMARG WC Product Grid — Extension API Hook Reference

> **Version:** 1.9.0
> **Status:** Stable public API — hooks listed here will not be removed without a deprecation notice.

Everything inside `includes/` is **private** unless it is a hook listed below or the `Public_API` class.
Never instantiate internal classes directly (`new Render_Engine()`, `Context_Resolver::resolve()`, etc.).

---

## Table of Contents

1. [Pipeline Hooks](#1-pipeline-hooks)
2. [Card Hooks](#2-card-hooks)
3. [Query Hooks](#3-query-hooks)
4. [Asset Hooks](#4-asset-hooks)
5. [AJAX Hooks](#5-ajax-hooks)
6. [System Hooks](#6-system-hooks)
7. [Deprecated / Legacy Names](#7-deprecated--legacy-names)
8. [Public vs Private Reference](#8-public-vs-private-reference)

---

## 1. Pipeline Hooks

These hooks fire as a render request moves through the pipeline.

---

### `zymarg_render_config`
**Type:** filter
**Since:** 1.9.0
**Location:** `Config_Normalizer`

Filters the fully normalized render config immediately before the Render Engine runs.
This is the most powerful single hook — use it to override layout, columns, template, or any config value.

```php
add_filter( 'zymarg_render_config', function ( array $config, array $context ): array {
    // Switch to slider on mobile.
    if ( wp_is_mobile() ) {
        $config['layout']['type'] = 'slider';
    }
    return $config;
}, 10, 2 );
```

**Arguments:**

| # | Type | Description |
|---|------|-------------|
| 1 | `array` | Normalized config array. |
| 2 | `array` | Resolved context (reserved; currently empty, will be populated in Milestone 8). |

> **Legacy alias:** `zymarg_product_grid_config` (fires first, same data).

---

### `zymarg_products`
**Type:** filter
**Since:** 1.9.0
**Location:** `Public_API`

Filters the product collection after fetching and before rendering.
Use to reorder, exclude, or inject products without replacing the query logic.

```php
add_filter( 'zymarg_products', function ( array $products, array $config, array $context ): array {
    // Put in-stock products first.
    usort( $products, fn( $a, $b ) => (int) $b->is_in_stock() - (int) $a->is_in_stock() );
    return $products;
}, 10, 3 );
```

**Arguments:**

| # | Type | Description |
|---|------|-------------|
| 1 | `WC_Product[]` | Fetched product collection. |
| 2 | `array` | Normalized render config. |
| 3 | `array` | Resolved context (reserved). |

---

### `zymarg_product_grid_before_render`
**Type:** action
**Since:** 1.6.0
**Location:** `Render_Engine`

Fires immediately before the grid HTML is produced.
Use for analytics, diagnostic output, or cache warm-up. **Do not echo here** — use `zymarg_product_grid_html` instead.

**Arguments:**

| # | Type | Description |
|---|------|-------------|
| 1 | `array` | Normalized config. |
| 2 | `WC_Product[]` | Product collection. |
| 3 | `string` | Layout wrapper path (relative to `/templates/`). |
| 4 | `array` | Full render context passed to the template. |

---

### `zymarg_product_grid_html`
**Type:** filter
**Since:** 1.6.0
**Location:** `Render_Engine`

Filters the complete rendered grid HTML string before it is returned.
Use for output caching write-through, A/B testing wrappers, or post-render transformations.

```php
add_filter( 'zymarg_product_grid_html', function ( string $html, array $config ): string {
    return '<div class="my-wrapper">' . $html . '</div>';
}, 10, 2 );
```

**Arguments:**

| # | Type | Description |
|---|------|-------------|
| 1 | `string` | Rendered HTML string. |
| 2 | `array` | Normalized config. |
| 3 | `WC_Product[]` | Product collection. |
| 4 | `string` | Layout wrapper path used. |

---

### `zymarg_product_grid_after_render`
**Type:** action
**Since:** 1.6.0
**Location:** `Render_Engine`

Fires immediately after the grid HTML is produced.
Use for analytics events, cache population, or logging.

**Arguments:**

| # | Type | Description |
|---|------|-------------|
| 1 | `string` | Final HTML string. |
| 2 | `array` | Normalized config. |
| 3 | `WC_Product[]` | Product collection. |

---

### `zymarg_product_grid_render_request`
**Type:** action
**Since:** 1.6.0
**Location:** `Public_API`

Fires at the very start of a render request, before any resolution or rendering.

**Arguments:**

| # | Type | Description |
|---|------|-------------|
| 1 | `array` | Raw `$args` passed to `Public_API::render()`. |

---

### `zymarg_product_grid_render_complete`
**Type:** action
**Since:** 1.6.0
**Location:** `Public_API`

Fires after the render request completes and HTML is ready to return.

**Arguments:**

| # | Type | Description |
|---|------|-------------|
| 1 | `string` | Final HTML string. |
| 2 | `array` | Raw `$args` passed to `Public_API::render()`. |

---

## 2. Card Hooks

These hooks fire inside `templates/cards/classic/product-card.php` for each product rendered.

---

### `zymarg_card_classes`
**Type:** filter
**Since:** 1.9.0

Filters the CSS class array on the product card wrapper element.

```php
add_filter( 'zymarg_card_classes', function ( array $classes, WC_Product $product, array $settings ): array {
    if ( $product->is_featured() ) {
        $classes[] = 'is-featured';
    }
    return $classes;
}, 10, 3 );
```

**Arguments:**

| # | Type | Description |
|---|------|-------------|
| 1 | `string[]` | CSS class array. |
| 2 | `WC_Product` | Current product. |
| 3 | `array` | Flattened render settings. |

---

### `zymarg_card_attributes`
**Type:** filter
**Since:** 1.9.0

Filters extra HTML attributes added to the product card wrapper.
Return an associative array of `attribute => value` pairs. Values are escaped with `esc_attr()`.
Do not include `class` or `data-product-id` — those are always emitted by the template.

```php
add_filter( 'zymarg_card_attributes', function ( array $attrs, WC_Product $product ): array {
    $attrs['data-sku'] = $product->get_sku();
    return $attrs;
}, 10, 2 );
```

**Arguments:**

| # | Type | Description |
|---|------|-------------|
| 1 | `array` | Associative attribute array. |
| 2 | `WC_Product` | Current product. |
| 3 | `array` | Flattened render settings. |

---

### `zymarg_before_card`
**Type:** action
**Since:** 1.9.0

Fires before the product card `<div>` opens. You are outside the card wrapper here.

**Arguments:** `WC_Product $product`, `array $settings`

---

### `zymarg_after_card`
**Type:** action
**Since:** 1.9.0

Fires after the product card `</div>` closes. You are outside the card wrapper here.

**Arguments:** `WC_Product $product`, `array $settings`

---

### `zymarg_before_card_image` / `zymarg_after_card_image`
**Type:** action
**Since:** 1.9.0

Fire before and after the product image container.

**Arguments:** `WC_Product $product`, `array $settings`

---

### `zymarg_before_card_title` / `zymarg_after_card_title`
**Type:** action
**Since:** 1.9.0

Fire before and after the product title row.

**Arguments:** `WC_Product $product`, `array $settings`

---

### `zymarg_before_card_price` / `zymarg_after_card_price`
**Type:** action
**Since:** 1.9.0

Fire before and after the price row. These hooks fire at whichever position the price is configured to appear (`above_title`, `above_rating`, `below_rating`).

**Arguments:** `WC_Product $product`, `array $settings`

---

### `zymarg_before_add_to_cart` / `zymarg_after_add_to_cart`
**Type:** action
**Since:** 1.9.0

Fire before and after the Add to Cart button wrapper.

```php
add_action( 'zymarg_after_add_to_cart', function ( WC_Product $product ): void {
    echo '<span class="free-shipping-badge">Free shipping</span>';
} );
```

**Arguments:** `WC_Product $product`, `array $settings`

---

## 3. Query Hooks

---

### `zymarg_product_grid_context`
**Type:** filter
**Since:** 1.6.0
**Location:** `Context_Resolver`

Filters the resolved page context before it is used for query building.
Use to inject membership level, language, currency, region, or warehouse context.

```php
add_filter( 'zymarg_product_grid_context', function ( array $context ): array {
    $context['membership'] = my_plugin_get_user_level();
    return $context;
} );
```

---

### `zymarg_wcpg_query_args`
**Type:** filter
**Since:** 1.0.0
**Location:** `Source_All`, `Source_Category`

Filters the `WP_Query` arguments before the query runs.
Use to exclude products, change ordering, modify tax_query, or add meta_query.

```php
add_filter( 'zymarg_wcpg_query_args', function ( array $args, array $settings ): array {
    // Exclude products tagged 'hidden'.
    $args['tax_query'][] = [
        'taxonomy' => 'product_tag',
        'field'    => 'slug',
        'terms'    => [ 'hidden' ],
        'operator' => 'NOT IN',
    ];
    return $args;
}, 10, 2 );
```

**Arguments:** `array $args`, `array $settings`

---

### `zymarg_layout_template`
**Type:** filter
**Since:** 1.9.0
**Location:** `Template_Manager`

Filters the layout wrapper template path before it is loaded.
Return a path relative to `/templates/`.

```php
add_filter( 'zymarg_layout_template', function ( string $path, string $layout_type, array $config ): string {
    if ( 'masonry' === $layout_type ) {
        return 'grid/masonry-wrapper.php';
    }
    return $path;
}, 10, 3 );
```

**Arguments:** `string $path`, `string $layout_type`, `array $config`

---

### `zymarg_card_template`
**Type:** filter
**Since:** 1.9.0
**Location:** `Template_Manager`

Filters the card template slug before it is resolved to a file path.
Use to swap card designs per product type, category, or any other condition.

```php
add_filter( 'zymarg_card_template', function ( string $template, array $args ): string {
    /** @var WC_Product $product */
    $product = $args['product'] ?? null;
    if ( $product && $product->is_type( 'variable' ) ) {
        return 'minimal'; // Use 'minimal' card for variable products.
    }
    return $template;
}, 10, 2 );
```

**Arguments:** `string $template`, `array $args` (contains `product`, `config`, `settings`, `widget_id`)

---

## 4. Asset Hooks

### `zymarg_wcpg_force_shortcode_asset_preload`
**Type:** filter — returns `bool`
**Since:** 1.0.0

Force early asset enqueue for shortcodes when server-side detection is not reliable.

```php
add_filter( 'zymarg_wcpg_force_shortcode_asset_preload', '__return_true' );
```

---

## 5. AJAX Hooks

### `zymarg_wcpg_added_to_cart`
**Type:** action | **Arguments:** `int $product_id`, `int $quantity`

### `zymarg_wcpg_wishlist_toggled`
**Type:** action | **Arguments:** `int $product_id`, `bool $is_in_wishlist`

### `zymarg_wcpg_quick_view_opened`
**Type:** action | **Arguments:** `int $product_id`

### `zymarg_wcpg_product_viewed`
**Type:** action | **Arguments:** `int $product_id`

---

## 6. System Hooks

### `zymarg_wcpg_loaded`
**Type:** action — fires when the plugin is fully initialised.

### `zymarg_wcpg_api_loaded`
**Type:** action — fires when the Public API is ready.

### `zymarg_wcpg_register_widgets`
**Type:** action | **Arguments:** `Elementor\Widgets_Manager $manager`
Use to register custom Elementor widgets that extend the plugin.

---

## 7. Deprecated / Legacy Names

These hooks remain active for backward compatibility but the canonical names above are preferred.

| Legacy name | Canonical name | Notes |
|---|---|---|
| `zymarg_product_grid_config` | `zymarg_render_config` | Fires first; same data |
| `zymarg_wcpg_query_args` | `zymarg_wcpg_query_args` | Already stable; no rename needed |

---

## 8. Public vs Private Reference

### ✅ Public (stable, supported)

- `Public_API::render( array $args ): string`
- All hooks listed in this document
- Template files in `templates/` (theme-overridable via `zymarg-wcpg/` in active theme)

### 🔒 Private (may change without notice)

- `Render_Engine`
- `Context_Resolver`
- `Config_Normalizer`
- `Config_Defaults`
- `Asset_Manager`
- `Template_Manager`
- `Query_Builder` and all `Source_*` classes
- `PageConsumers/*`
- `Services/*`
- `Bootstrap/*`
- `Registry/*`
- All `Ajax/Handlers/*` classes
- All `Elementor/*` internal classes (use `zymarg_wcpg_register_widgets` to extend)

Never call private classes directly. They may be renamed, split, or removed in any version.
