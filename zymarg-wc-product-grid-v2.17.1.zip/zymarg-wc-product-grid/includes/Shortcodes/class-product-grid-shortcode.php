<?php
/**
 * Product Grid Shortcode — [zymarg_products].
 *
 * Step 5 of Milestone 4 — Consumer Migration.
 *
 * This is a thin translator. Its only job:
 *
 *   shortcode_atts()
 *       ↓
 *   translate attributes → canonical config
 *       ↓
 *   Public_API::render( [ 'config' => $config ] )
 *
 * Nothing more. The engine owns everything below that hand-off.
 * This shortcode must never call Query_Builder, Render_Engine,
 * Template_Loader, or enqueue assets directly.
 *
 * Usage examples:
 *
 *   [zymarg_products]
 *   [zymarg_products slot="homepage-featured"]
 *   [zymarg_products template="homepage-grid"]
 *   [zymarg_products source="trending" limit="8" columns="4"]
 *   [zymarg_products source="category" include_categories="24,25" columns="3"]
 *   [zymarg_products source="featured" layout="slider" limit="10"]
 *   [zymarg_products show_heading="true" heading_text="New Arrivals" limit="8"]
 *   [zymarg_products show_heading="true" heading_text="New Arrivals" show_view_all="true" view_all_text="View All" view_all_url="https://example.com/shop/"]
 *   [zymarg_products pagination="load_more" limit="12"]
 *   [zymarg_products pagination="infinite" limit="20" batch_size="20" max_products="100"]
 *   [zymarg_products card_template="zymarg" source="similar"]
 *
 * Supported attributes: see self::default_atts().
 *
 * @package Zymarg\WCPG\Shortcodes
 * @since   1.6.5
 */

namespace Zymarg\WCPG\Shortcodes;

use Zymarg\WCPG\Api\Public_API;

defined( 'ABSPATH' ) || exit;

/**
 * Class Product_Grid_Shortcode
 */
class Product_Grid_Shortcode {

	/**
	 * Shortcode tag.
	 */
	public const SHORTCODE = 'zymarg_products';

	/**
	 * Register the shortcode with WordPress.
	 *
	 * Called from Plugin::init() after Api_Bootstrap::init() has fired,
	 * so Public_API is guaranteed ready when render() is invoked.
	 *
	 * @return void
	 */
	public function register(): void {
		add_shortcode( self::SHORTCODE, [ $this, 'render' ] );
	}

	/**
	 * Translate shortcode attributes into canonical config and hand off
	 * to the engine. This method must return HTML — never echo.
	 *
	 * @param  array|string $atts Raw shortcode attributes from WordPress.
	 * @return string             Rendered HTML, or empty string.
	 */
	public function render( $atts ): string {

		$atts = shortcode_atts( self::default_atts(), (array) $atts, self::SHORTCODE );

		// Build the canonical config from attributes.
		// Config_Normalizer fills every key not set here with its default.
		$config = [
			'query'      => [
				'source'              => sanitize_key( $atts['source'] ),
				'limit'               => max( 1, min( 48, (int) $atts['limit'] ) ),
				'orderby'             => sanitize_key( $atts['orderby'] ),
				'order'               => in_array( strtoupper( $atts['order'] ), [ 'ASC', 'DESC' ], true ) ? strtoupper( $atts['order'] ) : 'DESC',
				'include_categories'  => self::csv_to_int_array( $atts['include_categories'] ),
				'exclude_categories'  => self::csv_to_int_array( $atts['exclude_categories'] ),
				'include_products'    => self::csv_to_int_array( $atts['include_products'] ),
				'exclude_products'    => self::csv_to_int_array( $atts['exclude_products'] ),

				// Flash Deals source (v2.8.0). Ignored by all other sources.
				'flash_vendor_scope'  => sanitize_key( $atts['flash_vendor_scope'] ),
				'flash_min_discount'  => max( 0, min( 100, (int) $atts['flash_min_discount'] ) ),
				'flash_orderby'       => sanitize_key( $atts['flash_orderby'] ),
			],
			'layout'     => [
				'type'    => in_array( $atts['layout'], [ 'grid', 'slider' ], true ) ? $atts['layout'] : 'grid',
				'columns' => max( 1, min( 6, (int) $atts['columns'] ) ),
			],
			'card'       => self::build_card( $atts ),
			'heading'    => self::build_heading( $atts ),
			'pagination' => [
				'mode' => in_array( $atts['pagination'], [ 'none', 'load_more', 'infinite' ], true ) ? $atts['pagination'] : 'none',
			],
			'responsive' => [
				'tablet' => [ 'layout' => [] ],
				'mobile' => [ 'layout' => [] ],
			],
		];

		// Responsive column overrides — only set when the author provided them.
		// v2.4.2: optional grid gap override (column + row). Empty = Config_Defaults owns it (6px).
		// v2.6.0: Infinite scroll batch sizes and caps. Only applied when the
		// attribute is explicitly provided, so defaults stay centralized in
		// Config_Defaults.
		$zymarg_infinite_atts = [
			'batch_size'          => 48,
			'batch_size_tablet'   => 48,
			'batch_size_mobile'   => 48,
			'max_products'        => 500,
			'max_products_tablet' => 500,
			'max_products_mobile' => 500,
		];
		foreach ( $zymarg_infinite_atts as $zymarg_key => $zymarg_ceiling ) {
			if ( isset( $atts[ $zymarg_key ] ) && '' !== $atts[ $zymarg_key ] ) {
				$config['pagination'][ $zymarg_key ] = max( 1, min( $zymarg_ceiling, (int) $atts[ $zymarg_key ] ) );
			}
		}

		// v2.7.0: custom Load More button label (empty = translated default).
		if ( '' !== $atts['load_more_text'] ) {
			$config['pagination']['load_more_text'] = sanitize_text_field( $atts['load_more_text'] );
		}

		if ( '' !== $atts['gap'] ) {
			$config['layout']['gap'] = max( 0, min( 100, (int) $atts['gap'] ) );
		}

		// v2.5.0: slider smooth-scroll toggles. Truthy = on, '0'/'no' = off.
		if ( '' !== $atts['free_scroll'] ) {
			$config['layout']['slider']['free_scroll'] = in_array( strtolower( (string) $atts['free_scroll'] ), array( '1', 'yes', 'true', 'on' ), true );
		}
		if ( '' !== $atts['mousewheel'] ) {
			$config['layout']['slider']['mousewheel'] = in_array( strtolower( (string) $atts['mousewheel'] ), array( '1', 'yes', 'true', 'on' ), true );
		}

		// v2.7.0: remaining slider controls, previously reachable only from the
		// Elementor widget. Each is applied ONLY when explicitly provided, so
		// Config_Defaults and template overrides (e.g. the ZYMARG Template Pack
		// forcing progressbar pagination) remain authoritative otherwise.
		if ( '' !== $atts['slider_arrows'] ) {
			$config['layout']['slider']['show_arrows'] = self::to_bool( $atts['slider_arrows'] );
		}
		if ( '' !== $atts['slider_loop'] ) {
			$config['layout']['slider']['loop'] = self::to_bool( $atts['slider_loop'] );
		}
		if ( '' !== $atts['slider_autoplay'] ) {
			$config['layout']['slider']['autoplay'] = self::to_bool( $atts['slider_autoplay'] );
		}
		if ( '' !== $atts['slider_pagination'] ) {
			$zymarg_pagination_type = sanitize_key( $atts['slider_pagination'] );
			// v2.14.0: 'none' turns slider pagination off from the shortcode.
			//
			// slider-wrapper.php already treats an empty pagination_type as
			// "render nothing": it skips the Swiper pagination config and omits
			// the .swiper-pagination element. Only the shortcode whitelist and
			// Config_Normalizer::validate() stood in the way, so mapping the
			// off-switch aliases to '' is the whole change.
			//
			// Setting the key at all is also what stops the Template Pack from
			// reinstating its progress-bar default: capture_explicit() flags the
			// setting as explicit via array_key_exists(), and apply_defaults()
			// only fills in values that were not set explicitly.
			if ( in_array( $zymarg_pagination_type, [ 'none', 'off', 'hide', 'no', 'false', '0' ], true ) ) {
				$config['layout']['slider']['pagination_type'] = '';
			} elseif ( in_array( $zymarg_pagination_type, [ 'bullets', 'progress' ], true ) ) {
				$config['layout']['slider']['pagination_type'] = $zymarg_pagination_type;
			}
		}
		if ( '' !== $atts['slider_autoplay_delay'] ) {
			$config['layout']['slider']['autoplay_delay'] = max( 100, min( 30000, (int) $atts['slider_autoplay_delay'] ) );
		}
		if ( '' !== $atts['slider_speed'] ) {
			$config['layout']['slider']['speed'] = max( 100, min( 10000, (int) $atts['slider_speed'] ) );
		}
		if ( '' !== $atts['slider_marquee'] ) {
			$config['layout']['slider']['marquee'] = self::to_bool( $atts['slider_marquee'] );
		}
		if ( '' !== $atts['slider_marquee_speed'] ) {
			$config['layout']['slider']['marquee_speed'] = max( 500, min( 20000, (int) $atts['slider_marquee_speed'] ) );
		}
		if ( '' !== $atts['slider_space_between'] ) {
			$config['layout']['slider']['space_between'] = max( 0, min( 100, (int) $atts['slider_space_between'] ) );
		}

		if ( '' !== $atts['columns_tablet'] ) {
			$config['responsive']['tablet']['layout']['columns'] = max( 1, min( 6, (int) $atts['columns_tablet'] ) );
		}
		if ( '' !== $atts['columns_mobile'] ) {
			$config['responsive']['mobile']['layout']['columns'] = max( 1, min( 6, (int) $atts['columns_mobile'] ) );
		}

		// Hand off to the engine. slot and template are passed alongside
		// config so Public_API's priority resolution still applies:
		//   config > template > slot.
		// When the author provides slot or template AND config attributes,
		// the engine merges them correctly without this shortcode needing
		// to know the resolution logic.
		$output = Public_API::render( [
			'slot'     => sanitize_key( $atts['slot'] ),
			'template' => sanitize_key( $atts['template'] ),
			'config'   => $config,
		] );

		// HIDE_WIDGET sentinel: a source determined no products match.
		// Shortcodes have no editor layer — silently return empty string.
		if ( Public_API::HIDE_WIDGET === $output ) {
			return '';
		}

		return $output;
	}

	// -------------------------------------------------------------------------
	// Attribute defaults
	// -------------------------------------------------------------------------

	/**
	 * Shortcode attribute defaults.
	 *
	 * Empty string means "not provided by the author".
	 * Config_Normalizer applies its own defaults for anything not set here.
	 *
	 * @return array<string, string>
	 */
	private static function default_atts(): array {
		return [
			// Routing (Public_API resolves priority: config > template > slot).
			'slot'                => '',
			'template'            => '',
			// Query.
			'source'              => 'all',
			'limit'               => '8',
			'orderby'             => 'date',
			'order'               => 'DESC',
			'include_categories'  => '',
			'exclude_categories'  => '',
			'include_products'    => '',
			'exclude_products'    => '',
			// Flash Deals source (v2.8.0).
			'flash_vendor_scope'  => 'auto',
			'flash_min_discount'  => '0',
			'flash_orderby'       => 'sale_end',
			// Layout.
			'layout'              => 'grid',
			'columns'             => '4',
			'columns_tablet'      => '',
			'columns_mobile'      => '',
			'gap'                 => '',
			// Slider (v2.5.0).
			'free_scroll'         => '',
			'mousewheel'          => '',
			// Slider controls (v2.7.0) — parity with the Elementor widget.
			'slider_arrows'       => '',
			'slider_pagination'   => '',
			'slider_loop'         => '',
			'slider_autoplay'     => '',
			'slider_autoplay_delay' => '',
			'slider_speed'        => '',
			'slider_space_between' => '',
			// Marquee (v2.15.0).
			'slider_marquee'      => '',
			'slider_marquee_speed' => '',
			// Heading.
			'show_heading'        => '',
			'heading_text'        => '',
			'heading_tag'         => '',
			'heading_subtext'     => '',
			'heading_alignment'   => '',
			// Heading "View All" link (v2.6.1).
			'show_view_all'       => '',
			'view_all_text'       => '',
			'view_all_url'        => '',
			'view_all_auto_vendor'       => '',
			'view_all_vendor_product_id' => '',
			// Card visibility — empty = not set = Config_Defaults decides.
			'show_image'          => '',
			'show_title'          => '',
			'show_price'          => '',
			'show_rating'         => '',
			'show_atc'            => '',
			'show_wishlist'       => '',
			'show_quickview'      => '',
			'show_vendor'         => '',
			'show_sold_count'     => '',
			'show_discount_badge' => '',
			'show_stock_badge'    => '',
			// Card template slug — selects a registered card template.
			// Empty = use the engine default ('classic').
			// Example: card_template="zymarg"
			// The slug must be registered via Template_Manager::register_card().
			'card_template'       => '',

			// Countdown timer (v2.9.0).
			// show_countdown: 'auto' (Flash Deals only) | 'yes' | 'no'
			// countdown_position: 'below_price' | 'over_image' | 'before_title'
			'show_countdown'      => '',
			'countdown_position'  => '',
			// Pagination.
			'pagination'          => 'none',
			'load_more_text'      => '',
			'batch_size'          => '',
			'batch_size_tablet'   => '',
			'batch_size_mobile'   => '',
			'max_products'        => '',
			'max_products_tablet' => '',
			'max_products_mobile' => '',
			// Empty state.
			'empty_message'       => '',
		];
	}

	// -------------------------------------------------------------------------
	// Section translators
	// -------------------------------------------------------------------------

	/**
	 * Translate card-related attributes into the card config section.
	 *
	 * Card visibility flags are the only card properties exposed as shortcode
	 * attributes. Fine-grained card control (icons, positioning, vendor
	 * display options) belongs in the Elementor widget.
	 *
	 * We only set a key when the author explicitly provided the attribute,
	 * so Config_Defaults applies for everything left unset.
	 *
	 * @param  array $atts Normalised attributes.
	 * @return array       Partial card config.
	 */
	private static function build_card( array $atts ): array {
		$card = [];

		$visibility_keys = [
			'show_image', 'show_title', 'show_price', 'show_rating',
			'show_atc', 'show_wishlist', 'show_quickview', 'show_vendor',
			'show_sold_count', 'show_discount_badge', 'show_stock_badge',
		];

		foreach ( $visibility_keys as $key ) {
			if ( '' !== $atts[ $key ] ) {
				$card[ $key ] = self::to_bool( $atts[ $key ] );
			}
		}

		if ( '' !== $atts['empty_message'] ) {
			$card['empty_message'] = sanitize_text_field( $atts['empty_message'] );
		}

		// Card template slug — only set when the author explicitly provided it.
		// Config_Normalizer validates the slug against Template_Manager::is_registered_card()
		// and falls back to 'classic' if the slug is unknown, so it is safe to
		// pass any sanitized string here without further validation in the shortcode.
		if ( '' !== $atts['card_template'] ) {
			$card['template'] = sanitize_key( $atts['card_template'] );
		}

		// Countdown timer — only set when the author explicitly provided it, so
		// the 'auto' default keeps deciding per source. Config_Normalizer
		// validates both values and falls back if the slug is unknown.
		if ( '' !== $atts['show_countdown'] ) {
			$card['show_countdown'] = sanitize_key( $atts['show_countdown'] );
		}

		if ( '' !== $atts['countdown_position'] ) {
			$card['countdown_position'] = sanitize_key( $atts['countdown_position'] );
		}

		return $card;
	}

	/**
	 * Translate heading-related attributes into the heading config section.
	 *
	 * Heading is off by default (Config_Defaults: show = false).
	 * The author must explicitly pass show_heading="true" to opt in.
	 *
	 * @param  array $atts Normalised attributes.
	 * @return array       Partial heading config.
	 */
	private static function build_heading( array $atts ): array {
		$heading = [];

		if ( '' !== $atts['show_heading'] ) {
			$heading['show'] = self::to_bool( $atts['show_heading'] );
		}
		if ( '' !== $atts['heading_text'] ) {
			$heading['text'] = sanitize_text_field( $atts['heading_text'] );
		}
		if ( '' !== $atts['heading_tag'] ) {
			$allowed = [ 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'div', 'span' ];
			$tag     = sanitize_key( $atts['heading_tag'] );
			if ( in_array( $tag, $allowed, true ) ) {
				$heading['tag'] = $tag;
			}
		}

		// v2.7.0: subtext and alignment, previously Elementor-only.
		if ( '' !== $atts['heading_subtext'] ) {
			$heading['subtext'] = sanitize_text_field( $atts['heading_subtext'] );
		}
		if ( '' !== $atts['heading_alignment'] ) {
			$alignment = sanitize_key( $atts['heading_alignment'] );
			if ( in_array( $alignment, [ 'left', 'center', 'right' ], true ) ) {
				$heading['alignment'] = $alignment;
			}
		}

		// v2.6.1: "View All" link. Previously reachable only from the Elementor
		// widget or a direct Public_API::render() config array. These keys are
		// canonical heading config; Config_Normalizer converts a plain-string
		// view_all_url into the { url, is_external, nofollow } array shape the
		// wrapper templates read, so a bare URL string is safe here.
		if ( '' !== $atts['show_view_all'] ) {
			$heading['show_view_all'] = self::to_bool( $atts['show_view_all'] );
		}
		if ( '' !== $atts['view_all_text'] ) {
			$heading['view_all_text'] = sanitize_text_field( $atts['view_all_text'] );
		}
		if ( '' !== $atts['view_all_url'] ) {
			$heading['view_all_url'] = esc_url_raw( $atts['view_all_url'] );
		}
		if ( '' !== $atts['view_all_auto_vendor'] ) {
			$heading['view_all_auto_vendor'] = self::to_bool( $atts['view_all_auto_vendor'] );
		}
		if ( '' !== $atts['view_all_vendor_product_id'] ) {
			$heading['view_all_vendor_product_id'] = max( 0, (int) $atts['view_all_vendor_product_id'] );
		}

		return $heading;
	}

	// -------------------------------------------------------------------------
	// Value helpers
	// -------------------------------------------------------------------------

	/**
	 * Parse a comma-separated string of IDs into a sanitised int[].
	 *
	 * @param  string $value Raw attribute value.
	 * @return int[]
	 */
	private static function csv_to_int_array( string $value ): array {
		if ( '' === trim( $value ) ) {
			return [];
		}
		return array_values(
			array_filter(
				array_map( 'intval', explode( ',', $value ) ),
				static fn( int $id ) => $id > 0
			)
		);
	}

	/**
	 * Coerce a shortcode attribute string to bool.
	 *
	 * Accepts the spellings authors naturally write in shortcodes:
	 * "true", "1", "yes" → true. Everything else → false.
	 *
	 * @param  string $value Raw attribute value.
	 * @return bool
	 */
	private static function to_bool( string $value ): bool {
		return in_array( strtolower( trim( $value ) ), [ 'true', '1', 'yes' ], true );
	}
}
