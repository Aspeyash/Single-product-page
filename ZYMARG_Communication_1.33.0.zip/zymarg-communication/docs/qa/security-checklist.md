# Security Checklist (Phase 11)

This file records the Section 10 security review for the current release.

## Authentication & authorization

- [x] Every REST route declares a `permission_callback`. No route uses `__return_true` in production code.
- [x] `Authorization: Bearer zc_…` headers are validated by `ApiKeyService::verify()`. Invalid or revoked keys return `401 invalid_api_key` before any permission callback runs.
- [x] Admin-only endpoints call `AbstractController::requireAdmin()`.
- [x] Admin reads never trigger read receipts or notifications (Section 18).

## Input validation & sanitization

- [x] All request parameters are read through `AbstractController::param()` which applies `sanitize_text_field` / `wp_kses_post` by type.
- [x] File uploads go through `FileValidationService` (MIME + magic-byte check, allowlist enforced).
- [x] SVG, GIF, PDF are rejected. Only PNG / JPEG / WEBP are permitted.
- [x] Message bodies pass through `MessageSanitizer` before persistence.

## Output escaping

- [x] All admin-page output is escaped with `esc_html` / `esc_attr` / `esc_url`.
- [x] REST responses return JSON only; no raw HTML.

## Database

- [x] No file outside a `*/Repositories/*.php` touches `$wpdb`.
- [x] All SQL uses `$wpdb->prepare()`; no direct string interpolation.
- [x] Table names come from `Installer::MIGRATIONS`; no hard-coded prefixes.

## Secrets & credentials

- [x] Pusher and API-key secrets are encrypted via `EncryptionService` before persistence.
- [x] Credential fields in the admin UI render as `type="password"` with a Reveal toggle.
- [x] REST endpoints return `is_configured: true/false` — never the raw credential.

## Rate limiting

- [x] Message send, attachment upload, moderation report, and webhook create are covered by `RateLimitMiddleware`.

## Debug hygiene

- [x] No `console.log`, `var_dump`, `print_r`, `error_log` in production sources (verified by CI grep).
- [x] No inline `<style>` or `<script>` blocks in HTML output.

## Accessibility

- [x] Semantic HTML across every surface.
- [x] All interactive elements are keyboard-navigable with visible focus states.
- [x] Body-text contrast ≥ 4.5:1; large-text ≥ 3:1.
- [x] Heading hierarchy never skips levels within a surface.

## Performance

- [x] Repository methods use indexed columns for all list queries.
- [x] `FeatureFlagCacheService` memoizes the flag map per request.
- [x] Popup does not enqueue assets on pages where it is inactive.

## Responsive

- [x] Verified on mobile ≤ 767 px, tablet 768–1023 px, laptop 1024–1279 px, desktop ≥ 1280 px.
- [x] Container padding follows the tokenized breakpoint table (Section 16.13).
