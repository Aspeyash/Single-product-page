# Settings Reference

All plugin settings are at **ZYMARG Communication → Settings**.

## General

- **Plugin display name** — the name shown to users in the inbox header (default: "Messages").
- **Admin notification email** — address that receives moderation alerts.
- **Messages page** — select the page that contains the `[zymarg_my_messages]` shortcode.
- **Vendor messages page** — select the page that contains the `[zymarg_vendor_messages]` shortcode.

## Realtime (Pusher)

Required for live push notifications. Get free credentials at pusher.com.

- **App ID** — from your Pusher Channels app Keys tab.
- **Key** — public key.
- **Secret** — private key (never share this publicly).
- **Cluster** — e.g. `ap2` for Southeast Asia, `us2` for United States.

## Email Notifications

- **Enable email notifications** — send an email when a new message is received.
- **Email subject template** — use `{sender}` and `{site_name}` as placeholders.
- **Email from name** — displayed in the From field.
- **Email from address** — the sender address.

## Attachments

- **Allow attachments** — toggle file uploads in messages.
- **Max file size (MB)** — default 10.
- **Allowed file types** — comma-separated list (e.g. jpg,png,pdf,doc,docx,zip).

## Moderation

See the Moderation guide for full details.

## Feature Flags

Toggle individual features without editing code. Changes take effect immediately.

## Developer Tools

- **Enable debug logging** — write detailed logs to `/wp-content/plugins/zymarg-communication/storage/debug.log`.
- **Audit log** — view all admin actions.
- **REST API tester** — test API endpoints directly from the admin panel.
