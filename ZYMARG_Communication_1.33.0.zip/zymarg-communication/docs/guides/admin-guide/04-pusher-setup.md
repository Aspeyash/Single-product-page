# Pusher Setup Guide

Pusher powers real-time message delivery. Without it, users must refresh the page to see new messages. With it, messages appear instantly.

## Step 1 — Create a Pusher Account

1. Go to [https://pusher.com](https://pusher.com) and sign up for a free account.
2. In the Pusher dashboard, click **Create app**.
3. Name your app (e.g. "zymarg-messaging").
4. Select **Channels** as the product.
5. Choose the cluster closest to your users:
   - `ap2` — Singapore (recommended for Southeast Asia)
   - `eu` — Europe
   - `us2` — United States
6. Click **Create app**.

## Step 2 — Copy Your Keys

1. In your new app, go to the **Keys** tab.
2. Copy these four values:
   - **App ID**
   - **Key**
   - **Secret**
   - **Cluster**

## Step 3 — Enter Keys in Plugin Settings

1. Go to **WP Admin → ZYMARG Communication → Settings → Realtime**.
2. Paste the four values into the corresponding fields.
3. Click **Save Settings**.

## Step 4 — Test Real-Time Delivery

1. Open your site in two browser tabs, logged in as two different users.
2. Start a conversation from one tab.
3. The other tab should show the new message within one second, without refreshing.

## Free Tier Limits

Pusher's free Sandbox plan includes:

- 200,000 messages per day
- 100 simultaneous connections
- Unlimited channels

This is more than enough for a growing marketplace. Paid plans start at $49/month.

## Troubleshooting

- **Messages not appearing in real time** — double-check the App ID, Key, Secret, and Cluster. The cluster must match exactly (e.g. `ap2`, not `ap-2`).
- **Console error: 401 Unauthorized** — the Secret key may be wrong, or your server's clock may be out of sync.
- **Connection limit reached** — upgrade your Pusher plan or reduce idle connections.
