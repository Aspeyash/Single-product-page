# Admin Overview

This guide is for site administrators managing the ZYMARG Communication plugin.

## Admin Menu

After activation, a **ZYMARG Communication** top-level menu appears in the WordPress admin sidebar. It contains:

- **Dashboard** — overview stats (total conversations, messages sent today, unread count, active users).
- **Conversations** — browse and search all conversations on the site.
- **Moderation** — review reported conversations and take action.
- **Analytics** — message volume charts and engagement metrics.
- **Settings** — configure all plugin options.
- **Help & Docs** — this documentation.

## Initial Setup Checklist

1. **Settings → General** — set the plugin display name and default notification email.
2. **Settings → Realtime** — add Pusher credentials for live push notifications.
3. **Settings → Moderation** — configure auto-moderation rules (keyword filters, rate limits).
4. **Settings → Email** — customise the notification email templates.
5. **Pages** — verify the auto-created Messages and Vendor Messages pages are published.

## User Roles and Permissions

| Role | Send messages | View own inbox | View all conversations | Moderate |
|------|--------------|---------------|----------------------|----------|
| Subscriber (Buyer) | Yes | Yes | No | No |
| Vendor | Yes | Yes | Own conversations only | No |
| Editor | Yes | Yes | No | No |
| Administrator | Yes | Yes | Yes | Yes |

## Feature Flags

Feature flags let you enable or disable individual features without editing code. Go to **Settings → Feature Flags**:

- `live_chat` — show/hide the floating chat widget.
- `attachments` — allow file attachments in messages.
- `email_notifications` — send email alerts for new messages.
- `realtime` — enable Pusher-powered live updates.
- `analytics` — collect and display usage analytics.
- `moderation` — enable the moderation queue.
- `help_center` — show the Help & Docs menu to administrators.
- `vendor_inbox` — enable the vendor-specific inbox tab.
- `developer_tools` — expose the developer tools panel in admin.
