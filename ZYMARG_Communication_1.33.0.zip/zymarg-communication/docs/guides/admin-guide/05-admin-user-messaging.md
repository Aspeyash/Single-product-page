# Admin⇄User Messaging

Admin⇄User messaging is a direct support channel between your team and your users. A user opens a thread from anywhere you place a shortcode, and your support agents answer from the admin screen or from their own inbox.

The feature ships **disabled**. Nothing renders and no endpoints respond until you turn it on.

## Turning it on

Go to **ZYMARG Communication → Admin⇄User** and switch on the master toggle. This flips the `surface.support_chat` feature flag.

With the flag off:

- All support shortcodes render an empty string.
- The REST endpoints return a validation error.
- The admin inbox is hidden.

This means you can place shortcodes on your pages before you are ready to launch.

## Support agents

Anyone holding the `zymarg_support_agent` capability is a support agent. Administrators receive it automatically on upgrade.

On the Admin⇄User screen you can:

- **Add an agent** by username or email address.
- **Remove an agent**, which revokes the capability but leaves existing threads untouched.
- **Set the default agent**, who receives new threads when no other rule applies.
- **See each agent's current load**, so you can spread work sensibly.

Agents do not need `manage_options`. A user holding only `zymarg_support_agent` is treated as an admin participant for pairing purposes, so a customer contacting support is never mistaken for a buyer-to-buyer chat.

## How threading works

Each user gets **one ongoing support thread**. When a user clicks a support trigger:

1. If they already have a support thread, it reopens with the full history.
2. If they do not, a new thread is created and assigned to an available agent.

Support threads are ordinary conversations tagged with the context `support`. There is no separate table and no migration. They therefore inherit attachments, reactions, replies, typing indicators, read receipts, and moderation for free.

Because the thread is permanent, a user returning three months later continues the same conversation rather than starting from scratch.

## Where agents reply

Agents have two equivalent places to answer:

- **ZYMARG Communication → Admin⇄User** — the support inbox embedded in the admin screen.
- **Their own My Account inbox** — support threads appear alongside their other conversations.

Both use the identical chat interface as the buyer and seller inboxes.

## Placing the entry point

See the **Where to put it** panel on the Admin⇄User screen for a copy-paste reference. In short:

```
[zymarg_support_chat]
[zymarg_support_chat label="Contact Support"]
[zymarg_support_chat mode="inline"]
[zymarg_support_chat mode="link" label="Need help?"]
```

`[zymarg_contact_support]` and `[zymarg_support]` are aliases of the same shortcode, so you can use whichever name reads best in your template.

### Attributes

| Attribute | Values | Default | Purpose |
| --- | --- | --- | --- |
| `label` | any text | Contact Support | Visible text on the trigger |
| `title` | any text | inherits `label` | Tooltip and accessible name |
| `mode` | `button`, `link`, `inline` | `button` | Trigger style, or a full embedded inbox |
| `class` | any CSS classes | empty | Extra classes for your own styling |
| `icon` | `yes`, `no` | `yes` | Show the leading icon |
| `logged_out` | any text | empty | Message shown to logged-out visitors |

You can place the shortcode in as many locations as you like, under different names. They all resolve to the same single thread per user.

## Renaming the channel

The channel label is filterable, so you can call it Support, Contact Support, Alpha, or anything else:

```
add_filter( 'zymarg_comm_support_label', function() {
    return 'Alpha';
} );
```

## Known limitation

The conversation list is participant-scoped. An administrator who is **not** a participant of a given support thread will not see it in the inbox, because threads are assigned to a single agent. If you need supervisor visibility across all threads, use **Conversations** in the admin menu, which lists everything.

## What is not cleaned up on uninstall

Uninstalling does not remove the `zymarg_support_agent` capability or these options:

- `zymarg_comm_support_cap_version`
- `zymarg_comm_support_default_agent`
- `zymarg_comm_support_label`

This is deliberate, so that deactivating and reactivating does not lose your agent configuration.
