# Moderation

The moderation module lets you review and act on conversations that have been reported by users or flagged automatically by the keyword filter.

## Moderation Queue

Go to **ZYMARG Communication → Moderation** to see all pending reports. Each row shows:

- Reporter name and date
- Reported conversation participants
- Report reason
- Status (Pending, Reviewed, Dismissed, Actioned)

## Taking Action

Click any report row to open the full conversation thread. You can then:

- **Dismiss** — mark the report as reviewed and close it with no further action.
- **Warn** — send an automated warning email to the reported user.
- **Suspend conversation** — freeze the conversation so neither party can send new messages.
- **Block user** — prevent the reported user from starting new conversations.
- **Delete conversation** — permanently remove the conversation and all its messages.

## Auto-Moderation

Configure keyword filters at **Settings → Moderation → Keyword Filter**. Any message containing a blocked keyword is automatically:

1. Held for review (not delivered to the recipient).
2. Added to the moderation queue with reason "Auto-flagged: keyword match".

## Rate Limiting

To prevent spam, configure message rate limits at **Settings → Moderation → Rate Limits**:

- **Messages per minute** — default 5.
- **Messages per hour** — default 60.
- **Conversations per day** — default 20.

Users who exceed these limits are temporarily blocked from sending new messages.

## Audit Log

All moderation actions are recorded in the audit log. Go to **Settings → Developer Tools → Audit Log** to view a timestamped history of every admin action taken on conversations.
