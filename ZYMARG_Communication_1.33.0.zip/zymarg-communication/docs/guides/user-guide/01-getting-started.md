# Getting Started with ZYMARG Communication

Welcome to ZYMARG Communication — the built-in messaging system for the ZYMARG marketplace. This guide explains how buyers and vendors can start conversations and manage their messages.

## What is ZYMARG Communication?

ZYMARG Communication lets buyers and vendors send private messages directly on the marketplace. You can:

- Contact a vendor about a product before purchasing
- Ask follow-up questions about an order
- Receive vendor replies in real time
- Get desktop and email notifications for new messages

## Accessing Your Messages

There are three ways to open your inbox:

1. **My Account → Messages** — navigate to your account dashboard and click the Messages section in the sidebar.
2. **Live chat bubble** — the floating chat icon in the bottom-right corner of every page opens your most recent conversation.
3. **Direct URL** — visit the Messages page on your site (created automatically when the plugin activates).

## Starting a Conversation

As a **buyer**:

1. Visit any product page.
2. Click **Message Seller** (or the chat icon next to the vendor name).
3. Type your message and press Send.
4. The vendor receives a notification and can reply from their vendor dashboard.

As a **vendor**:

1. Go to your Vendor Dashboard → Messages.
2. You will see all conversations from buyers.
3. Click any conversation to open it and reply.

## Notifications

- **Real-time badge** — the live chat bubble shows an unread count badge.
- **Email notification** — when you receive a message, an email is sent to your registered address.
- **Admin notifications** — the site admin receives alerts for reported or flagged conversations.

## Message Status

Each message has a lifecycle status:

- **Sent** — delivered to the recipient.
- **Read** — the recipient has opened the conversation.
- **Archived** — the conversation has been closed or archived by either party.
- **Reported** — flagged for moderation review.
