# Using Your Inbox

The inbox is the central place to manage all your conversations.

## Inbox Layout

The inbox is divided into two panels:

- **Left panel** — conversation list, sorted by most recent activity. Each row shows the other party's name, a message preview, and the time of the last message.
- **Right panel** — the open conversation thread, with messages displayed in chronological order.

## Searching Conversations

Use the search bar at the top of the conversation list to filter by the other party's name or by keywords in the message preview.

## Replying to a Message

1. Click a conversation in the left panel to open it.
2. Type your reply in the text box at the bottom.
3. Press **Send** or hit `Ctrl + Enter`.

## Sending Attachments

1. Click the paperclip icon next to the message input.
2. Select a file (max 10 MB; allowed types: jpg, png, pdf, doc, docx, zip).
3. The file uploads and is sent as an attachment in the message.

## Archiving a Conversation

To archive a conversation, click the **⋯ menu** on the conversation row and select **Archive**. Archived conversations are hidden from the main list but can be found using the search bar.

## Reporting a Conversation

If a message violates marketplace policies:

1. Open the conversation.
2. Click **⋯ menu → Report**.
3. Choose a reason (spam, harassment, off-platform transaction, etc.).
4. Submit the report. The site admin will review and take action.

## Unread Count

The number of unread conversations appears:

- On the floating chat bubble (bottom-right corner)
- In the Messages sidebar link in My Account
- As a browser tab badge (when supported)
