# Contacting Support

If the site has enabled support messaging, you can message the site team directly and get replies in the same inbox you use for your other conversations.

## Starting a conversation

Look for a **Contact Support** button or link. Depending on the page, it may be named something else, such as Support or Help. Selecting it opens a chat with the support team.

You need to be signed in. If you are signed out, the button will tell you to sign in first.

## One continuous thread

You have a single ongoing support conversation. Every time you contact support, you return to the same thread with your full history, so you never have to repeat previous context and you can scroll back to earlier answers at any time.

## Reading replies

Replies arrive in **My Account → Messages**, alongside your other conversations. The support thread behaves exactly like any other conversation, so you can:

- Send attachments
- React to messages
- Reply to a specific message
- See when the agent is typing

## Response times

Messages are answered by the site's support team, not automatically. Response times depend on the site.
