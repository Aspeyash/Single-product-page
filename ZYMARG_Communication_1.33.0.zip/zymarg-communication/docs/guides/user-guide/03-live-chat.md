# Live Chat Widget

The live chat widget is the floating button in the bottom-right corner of every page on the site. It gives you instant access to your conversations without navigating away from the page you are on.

## Opening the Widget

Click the chat bubble icon. The widget expands to show your most recent conversation.

## Widget Features

- **Unread badge** — shows the number of unread messages across all conversations.
- **Quick reply** — type and send a reply directly from the widget without opening the full inbox.
- **Open full inbox** — click the expand icon (arrows) inside the widget to open the full inbox page.
- **Minimize** — click the bubble again or press Escape to minimize the widget.

## JavaScript API

If you are a developer, you can control the widget programmatically:

```
window.zymargLiveChat.open(conversationId);  // open a specific conversation
window.zymargLiveChat.close();               // minimize the widget
window.zymargLiveChat.refresh();             // reload messages
window.zymargLiveChat.unread();              // returns the unread count (integer)
```

## Disabling the Widget on Specific Pages

Add the following to your theme's functions.php or a custom plugin:

```
add_filter( 'zymarg_comm_show_live_chat', function( $show ) {
    // hide on checkout page
    if ( is_checkout() ) {
        return false;
    }
    return $show;
} );
```
