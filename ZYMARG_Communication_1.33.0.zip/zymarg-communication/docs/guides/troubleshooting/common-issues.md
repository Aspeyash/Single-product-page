# Troubleshooting Common Issues

## Plugin Activation Fails with "Critical Error"

**Symptom:** Activating the plugin shows "There has been a critical error on this website."

**Solution:**
1. Check the WordPress fatal-error email sent to your admin address. It contains the exact file and line number.
2. Use the recovery-mode link in the email to access your admin panel safely.
3. Update to the latest version of ZYMARG Communication.
4. Ensure your server runs PHP 8.1 or higher and WordPress 6.0 or higher.

## Documentation Is Not Available

**Symptom:** All Help & Docs sections show "Documentation is not available."

**Solution:** Ensure the `docs/` directory exists inside the plugin folder and contains the Markdown files. Reinstall the plugin using the latest zip file.

## Messages Not Appearing in Real Time

**Symptom:** Users must refresh the page to see new messages.

**Solution:**
1. Go to **Settings → Realtime** and verify all four Pusher credentials are entered correctly.
2. Check the Pusher dashboard to confirm your app is active and not over its message limit.
3. Open your browser console and look for WebSocket errors.
4. Ensure `Feature Flags → realtime` is enabled.

## Floating Chat Widget Not Appearing

**Symptom:** The chat bubble is not visible on the frontend.

**Solution:**
1. Confirm `Feature Flags → live_chat` is enabled.
2. Check that you are logged in — the widget only appears for authenticated users by default.
3. A theme or other plugin may be blocking the `wp_footer` hook. Check for JavaScript errors in the browser console.
4. Add `[zymarg_live_chat]` to a page manually to test if the shortcode renders.

## Inbox Page Shows Blank or "No Messages"

**Symptom:** The Messages page loads but shows nothing.

**Solution:**
1. Confirm the page contains the `[zymarg_my_messages]` shortcode.
2. Go to **Settings → Permalinks** and click **Save Changes** to flush rewrite rules.
3. Check that the logged-in user has the correct role (the inbox only shows for logged-in users).

## Vendor Messages Tab Missing

**Symptom:** The Messages tab does not appear in the vendor dashboard.

**Solution:**
1. Confirm the ZYMARG Vendor Dashboard plugin is active.
2. Confirm `Feature Flags → vendor_inbox` is enabled.
3. The vendor must be approved — pending vendors do not see the messages tab.

## Attachments Not Uploading

**Symptom:** File upload fails or the attachment icon is missing.

**Solution:**
1. Confirm `Feature Flags → attachments` is enabled.
2. Check **Settings → Attachments → Max file size** — the file may exceed the limit.
3. Verify the file type is in the allowed list.
4. Check your server's PHP `upload_max_filesize` and `post_max_size` settings in `php.ini`.

## Email Notifications Not Sending

**Symptom:** Users do not receive email alerts for new messages.

**Solution:**
1. Confirm `Feature Flags → email_notifications` is enabled.
2. Test your site's email delivery using a plugin like WP Mail SMTP.
3. Check the spam/junk folder of the recipient.
4. Verify the **Settings → Email → From address** is a valid address on your domain.

## REST API Returns 401 Unauthorized

**Symptom:** API requests fail with a 401 error.

**Solution:**
1. Ensure the request includes a valid WordPress nonce in the `X-WP-Nonce` header.
2. Confirm the authenticated user has permission to perform the requested action.
3. Check that REST API is not blocked by a security plugin or server firewall.

## Getting More Help

If your issue is not listed here:

1. Enable debug logging at **Settings → Developer Tools → Enable debug logging**.
2. Reproduce the issue and check the log at `wp-content/plugins/zymarg-communication/storage/debug.log`.
3. Contact support with the log file attached.

## The support button does not appear

Work through these in order:

1. **The feature is off.** Admin⇄User messaging ships disabled. Go to **ZYMARG Communication → Admin⇄User** and switch on the master toggle. While it is off, every support shortcode renders nothing at all, by design.
2. **The visitor is signed out.** Support requires a logged-in user. Set the `logged_out` attribute to show a prompt instead of nothing:
   `[zymarg_support_chat logged_out="Please sign in to contact support."]`
3. **The shortcode is in a location that does not run shortcodes.** Some page builders and widget areas do not process shortcodes. Use `do_shortcode( '[zymarg_support_chat]' )` in your template instead.

## "No support agent is available right now"

No user holds the `zymarg_support_agent` capability. Go to **ZYMARG Communication → Admin⇄User** and add at least one agent, then set a default agent.

Administrators receive the capability automatically. If they did not, delete the `zymarg_comm_support_cap_version` option to force the grant to run again on the next page load.

## An agent cannot see a support thread

The conversation list is participant-scoped, so an agent only sees threads they are a participant of. Threads are assigned to a single agent when they are created.

To see every support thread regardless of assignment, use **ZYMARG Communication → Conversations**, which lists all conversations on the site.

## Support replies go to the wrong page

Customers are sent to the WooCommerce My Account messages endpoint. If your site uses a different location, filter it:

```
add_filter( 'zymarg_comm_support_inbox_url', function( string $url ): string {
    return home_url( '/help/inbox/' );
} );
```

## A customer has two support threads

This should not happen, as threads are resolved per user. If it does, it usually means a thread was created directly through the conversations API with `context_type = 'support'` rather than through `POST /support/start`. Always use the start endpoint or `SupportService::startOrResume()`.
