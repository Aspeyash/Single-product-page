# JavaScript SDK Reference

The JS SDK is automatically loaded on all frontend pages when the plugin is active and the `live_chat` feature flag is enabled.

## Global Object

```
window.zymargLiveChat
```

Always check it exists before calling:

```
if ( typeof window.zymargLiveChat !== 'undefined' ) {
    window.zymargLiveChat.open( 42 );
}
```

## Configuration

The SDK config is injected by PHP via `wp_localize_script`:

```
{
  apiBase: '/wp-json/zymarg-comm/v1',
  nonce: '...',
  userId: 3,
  pusherKey: '...',
  pusherCluster: 'ap2',
  currentConversationId: null
}
```

## Methods

### open( conversationId )

Opens the live chat widget and loads the specified conversation.

```
window.zymargLiveChat.open( 42 );
```

**Parameters:** `conversationId` (integer) - the conversation to open.

### close()

Minimises the live chat widget.

```
window.zymargLiveChat.close();
```

### refresh()

Reloads the current conversation messages from the server.

```
window.zymargLiveChat.refresh();
```

### unread()

Returns the current unread message count as an integer.

```
const count = window.zymargLiveChat.unread();
console.log( 'You have ' + count + ' unread messages' );
```

### on( event, callback )

Subscribes to an SDK event.

```
window.zymargLiveChat.on( 'message.received', function( message ) {
    console.log( 'New message:', message.body );
} );
```

**Available events:**

- `message.received` - new message arrived. Payload: `{ id, conversation_id, sender_id, body, sent_at }`
- `conversation.opened` - widget opened. Payload: `{ conversation_id }`
- `conversation.closed` - widget minimised.
- `unread.updated` - unread count changed. Payload: `{ count }`

### off( event, callback )

Removes a registered event listener.

```
const handler = ( msg ) => console.log( msg );
window.zymargLiveChat.on( 'message.received', handler );
window.zymargLiveChat.off( 'message.received', handler );
```

## REST API Helper

The SDK exposes an `api` object that wraps `fetch` with authentication:

```
window.zymargLiveChat.api.get( '/conversations' )
    .then( data => console.log( data.conversations ) );

window.zymargLiveChat.api.post( '/conversations', {
    recipient_id: 7,
    message: 'Hello!'
} ).then( data => console.log( data ) );
```

All calls automatically include the REST nonce and handle errors.

## Controlling Widget Visibility

Hide the widget on specific pages using the PHP filter:

```
add_filter( 'zymarg_comm_show_live_chat', function( $show ) {
    if ( is_checkout() ) return false;
    return $show;
} );
```

Or hide it via JavaScript:

```
document.addEventListener( 'DOMContentLoaded', function() {
    var widget = document.querySelector( '.zymarg-live-chat' );
    if ( widget ) widget.style.display = 'none';
} );
```

## Shortcodes

Embed messaging components anywhere with shortcodes:

```
[zymarg_my_messages]       - full buyer inbox
[zymarg_vendor_messages]   - full vendor inbox
[zymarg_live_chat]         - embedded chat widget
[zymarg_unread_count]      - unread count number
```
