# Mobile Integration Guide

This guide explains how to integrate ZYMARG Communication into a mobile app using the REST API and Pusher for real-time updates.

## Authentication

Use WordPress Application Passwords (built into WordPress 5.6+) for mobile apps.

1. In WP Admin go to **Users > Profile > Application Passwords**.
2. Create a new application password (e.g. name it "iOS App").
3. Include it in every API request as a Basic Auth header:

```
Authorization: Basic base64(username:application_password)
```

## Fetching Conversations

```
GET https://zymarg.com/wp-json/zymarg-comm/v1/conversations
Authorization: Basic ...
```

Poll this endpoint on app foreground to refresh the conversation list.

## Sending a Message

```
POST https://zymarg.com/wp-json/zymarg-comm/v1/conversations/42/messages
Authorization: Basic ...
Content-Type: application/json

{ "body": "Your order has shipped!" }
```

## Uploading Attachments

Use multipart/form-data:

```
POST https://zymarg.com/wp-json/zymarg-comm/v1/conversations/42/messages
Content-Type: multipart/form-data

body = Hello, here is the image
file = <binary file data>
```

Maximum file size and allowed types are controlled by **Settings > Attachments**.

## Real-Time Updates with Pusher

Install the Pusher SDK for your platform:

- iOS: `pod 'PusherSwift'`
- Android: `implementation "com.pusher:pusher-java-client:2.4.0"`
- React Native: `npm install pusher-js`
- Flutter: `pusher_channels_flutter` package

Connect and subscribe:

```
// React Native example
import Pusher from 'pusher-js';

const pusher = new Pusher('YOUR_PUSHER_KEY', { cluster: 'ap2' });

// Subscribe to the user's private channel
const channel = pusher.subscribe('private-user-' + userId);

channel.bind('message.new', function(data) {
    console.log('New message:', data.body);
    // refresh conversation or show push notification
});
```

**Channel naming:**

- Per-user: `private-user-{user_id}` - all new messages for that user
- Per-conversation: `private-conversation-{conversation_id}` - messages in one thread

**Pusher auth endpoint:** `/wp-json/zymarg-comm/v1/pusher/auth`

```
const pusher = new Pusher('YOUR_KEY', {
    cluster: 'ap2',
    authEndpoint: 'https://zymarg.com/wp-json/zymarg-comm/v1/pusher/auth',
    auth: {
        headers: { Authorization: 'Basic ...' }
    }
});
```

## Push Notifications (Background)

For notifications when the app is closed:

1. Register the device push token:

```
POST /wp-json/zymarg-comm/v1/notifications/device

{ "token": "DEVICE_PUSH_TOKEN", "platform": "ios" }
```

Valid platforms: `ios`, `android`.

2. Configure your push provider credentials under **Settings > Mobile**:
   - Android: FCM Server Key
   - iOS: APNs Certificate or Key

3. The plugin sends a push payload whenever a new message arrives for that user.

## Marking Messages as Read

```
POST /wp-json/zymarg-comm/v1/conversations/42/messages/read
Authorization: Basic ...
```

Call this when the user opens a conversation in the app.

## Getting the Unread Count

```
GET /wp-json/zymarg-comm/v1/notifications/unread-count
Authorization: Basic ...

Response: { "unread_count": 3 }
```

Display this as a badge on your app icon.

## Rate Limits

The API enforces the same rate limits as the web frontend:

- 5 messages per minute
- 60 messages per hour
- 20 new conversations per day

If you receive `429 Too Many Requests`, check the `Retry-After` header for how many seconds to wait before retrying.

## Error Handling

All errors return standard HTTP status codes with a JSON body:

```
{
  "code": "zymarg_comm_not_found",
  "message": "Conversation not found.",
  "data": { "status": 404 }
}
```

Common error codes:

- `zymarg_comm_unauthorized` - not logged in or insufficient permissions
- `zymarg_comm_not_found` - resource does not exist
- `zymarg_comm_rate_limited` - too many requests
- `zymarg_comm_validation_error` - invalid request body
- `zymarg_comm_feature_disabled` - the required feature flag is off

## Support chat (Admin⇄User)

Support messaging is designed so a mobile client needs almost no support-specific code.

### 1. Check availability at launch

```
GET /wp-json/zymarg-comm/v1/support/config
```

Returns `enabled`, `label`, `is_agent`, `has_thread`, `inbox_url` and `rest_root`. If `enabled` is `false`, hide your support entry point entirely.

Use `label` for your button text rather than hardcoding a string, so the site owner can rename the channel without a client release.

### 2. Open the thread

```
POST /wp-json/zymarg-comm/v1/support/start
```

Returns `conversation_id`, `is_new`, `agent_id` and `inbox_url`. This is idempotent: calling it repeatedly returns the same thread, because each user has exactly one ongoing support conversation.

### 3. Message normally

From this point use the **standard** conversation endpoints with the returned `conversation_id`:

```
GET  /wp-json/zymarg-comm/v1/conversations/{id}/messages
POST /wp-json/zymarg-comm/v1/conversations/{id}/messages
```

Attachments, reactions, replies, typing indicators and read receipts all work exactly as they do for buyer and seller conversations. There are deliberately no support-specific messaging endpoints to implement.

### Listing support threads for agents

If your app has an agent mode:

```
GET /wp-json/zymarg-comm/v1/support/threads?limit=50&offset=0
```

Agents only. Returns `threads` and `total`.

### Filtering the inbox

The conversation list accepts an optional `context` parameter:

```
GET /wp-json/zymarg-comm/v1/conversations?context=support
```

Omit it to get the full inbox. Buyer and seller clients should omit it.
