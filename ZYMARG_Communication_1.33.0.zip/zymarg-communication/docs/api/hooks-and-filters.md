# Hooks & Filters Reference

ZYMARG Communication provides WordPress actions and filters so you can extend or modify its behaviour from your theme or another plugin.

## Actions

### zymarg_comm_activated

Fired after the plugin activates and all migrations have run.

```
add_action( 'zymarg_comm_activated', function() {
    // e.g. seed your own data
} );
```

### zymarg_comm_hooks_loaded

Fired after all module Hooks classes have registered with WordPress. Safe point to access plugin services.

```
add_action( 'zymarg_comm_hooks_loaded', function() {
    // plugin fully booted
} );
```

### zymarg_comm_message_sent

Fired after a message is saved to the database.

```
add_action( 'zymarg_comm_message_sent',
    function( int $message_id, int $conversation_id, int $sender_id ) {
        // e.g. trigger a custom notification
    },
    10, 3
);
```

### zymarg_comm_conversation_created

Fired after a new conversation is created.

```
add_action( 'zymarg_comm_conversation_created',
    function( int $conversation_id, int $initiator_id, int $recipient_id ) {},
    10, 3
);
```

### zymarg_comm_conversation_archived

Fired after a conversation is archived.

```
add_action( 'zymarg_comm_conversation_archived',
    function( int $conversation_id, int $user_id ) {},
    10, 2
);
```

### zymarg_comm_moderation_action

Fired after an admin takes a moderation action.

```
add_action( 'zymarg_comm_moderation_action',
    function( string $action, int $report_id, int $admin_id ) {},
    10, 3
);
```

## Filters

### zymarg_comm_show_live_chat

Control whether the floating chat widget is shown on a given page.

```
add_filter( 'zymarg_comm_show_live_chat', function( bool $show ): bool {
    if ( is_checkout() ) return false;
    return $show;
} );
```

### zymarg_comm_message_body

Filter the message body before it is saved. Return a WP_Error to block sending.

```
add_filter( 'zymarg_comm_message_body',
    function( string $body, int $sender_id ): string {
        return wp_strip_all_tags( $body );
    },
    10, 2
);
```

### zymarg_comm_allowed_file_types

Modify the list of allowed attachment file types.

```
add_filter( 'zymarg_comm_allowed_file_types', function( array $types ): array {
    $types[] = 'csv';
    return $types;
} );
```

### zymarg_comm_max_file_size

Change the maximum attachment size in megabytes (default 10).

```
add_filter( 'zymarg_comm_max_file_size', fn( int $mb ) => 25 );
```

### zymarg_comm_notification_email_subject

Customise the new-message notification email subject.

```
add_filter( 'zymarg_comm_notification_email_subject',
    function( string $subject, int $conversation_id ): string {
        return 'New message on My Marketplace';
    },
    10, 2
);
```

### zymarg_comm_conversation_permission

Control whether a user can start a conversation with another user.

```
add_filter( 'zymarg_comm_conversation_permission',
    function( bool $allowed, int $initiator_id, int $recipient_id ): bool {
        // only allow buyers to message vendors
        if ( ! user_can( $recipient_id, 'publish_products' ) ) {
            return false;
        }
        return $allowed;
    },
    10, 3
);
```

### zymarg_comm_rate_limit

Override rate-limiting settings per user.

```
add_filter( 'zymarg_comm_rate_limit',
    function( array $limits, int $user_id ): array {
        if ( user_can( $user_id, 'manage_options' ) ) {
            $limits['per_minute'] = 999;
        }
        return $limits;
    },
    10, 2
);
```

Default limits: `per_minute: 5`, `per_hour: 60`, `conversations_per_day: 20`.

### zymarg_comm_feature_flags

Register or override feature flag defaults.

```
add_filter( 'zymarg_comm_feature_flags', function( array $flags ): array {
    $flags['my_custom_feature'] = true;
    return $flags;
} );
```

## Ecosystem Filters (Theme / Vendor Plugin)

### zymarg_os_account_sections

Injects the Messages section into the ZYMARG OS theme My Account page.

```
add_filter( 'zymarg_os_account_sections', function( array $sections ): array {
    $sections['my-messages'] = [
        'label'     => 'Messages',
        'icon'      => 'message',
        'endpoint'  => 'my-messages',
        'after'     => 'addresses',
        'render_cb' => fn() => do_shortcode( '[zymarg_my_messages]' ),
        'enabled'   => true,
    ];
    return $sections;
} );
```

### zymarg_os_vendor_render_section

Injects the vendor Messages tab into the ZYMARG Vendor Dashboard.

```
add_filter( 'zymarg_os_vendor_render_section',
    function( string $output, string $section, int $user_id ): string {
        if ( 'messages' === $section ) {
            return do_shortcode( '[zymarg_vendor_messages]' );
        }
        return $output;
    },
    10, 3
);
```

### zymarg_comm_support_started

Fired when a **new** support thread is opened. Does not fire when an existing thread is resumed.

```
add_action( 'zymarg_comm_support_started',
    function( int $conversation_id, int $user_id, int $agent_id ) {
        // e.g. notify the agent, or push to your helpdesk
    },
    10, 3
);
```

### zymarg_comm_support_label

Filters the display name of the support channel. Use this to call it Support, Contact Support, Alpha, or anything else.

```
add_filter( 'zymarg_comm_support_label', function( string $label ): string {
    return 'Alpha';
} );
```

### zymarg_comm_support_agents

Filters the list of support agent user ids. Use this to source agents from your own logic instead of, or in addition to, the `zymarg_support_agent` capability.

```
add_filter( 'zymarg_comm_support_agents', function( array $ids ): array {
    $ids[] = 42;
    return array_values( array_unique( $ids ) );
} );
```

### zymarg_comm_support_inbox_url

Filters the URL customers are sent to in order to read support replies. Defaults to the WooCommerce My Account messages endpoint.

```
add_filter( 'zymarg_comm_support_inbox_url', function( string $url ): string {
    return home_url( '/help/inbox/' );
} );
```
