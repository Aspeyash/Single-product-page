# REST API Reference

Base namespace: `zymarg-comm/v1`
All endpoints require a valid WordPress authentication cookie or `X-WP-Nonce` header.

## Authentication

Obtain a nonce on any authenticated page and include it in every request:

```
fetch('/wp-json/zymarg-comm/v1/conversations', {
    headers: { 'X-WP-Nonce': wpApiSettings.nonce }
})
```

## Conversations

### List conversations

`GET /wp-json/zymarg-comm/v1/conversations`

Query parameters: `page` (default 1), `per_page` (default 20, max 100), `status` (active, archived, reported, pending_approval), `search`.

Response:

```
{
  "conversations": [
    {
      "id": 42,
      "status": "active",
      "created_at": "2026-07-01T10:00:00Z",
      "updated_at": "2026-07-26T15:30:00Z",
      "participants": [
        { "id": 1, "name": "Alice", "role": "buyer" },
        { "id": 7, "name": "Bob Shop", "role": "seller" }
      ],
      "last_message": {
        "id": 199,
        "body": "Thanks, I will ship today.",
        "sent_at": "2026-07-26T15:30:00Z"
      },
      "unread_count": 1
    }
  ],
  "total": 1,
  "pages": 1
}
```

### Create conversation

`POST /wp-json/zymarg-comm/v1/conversations`

Request body:

```
{ "recipient_id": 7, "message": "Hi, is this item still available?" }
```

Response: The created conversation object.

### Get conversation

`GET /wp-json/zymarg-comm/v1/conversations/{id}`

Returns a single conversation with its full participant list.

### Archive conversation

`POST /wp-json/zymarg-comm/v1/conversations/{id}/archive`

### Report conversation

`POST /wp-json/zymarg-comm/v1/conversations/{id}/report`

Request body:

```
{ "reason": "spam" }
```

Valid reasons: `spam`, `harassment`, `off_platform`, `inappropriate_content`, `other`.

## Messages

### List messages

`GET /wp-json/zymarg-comm/v1/conversations/{id}/messages`

Query parameters: `page`, `per_page` (default 50, max 200), `before` (ISO 8601 datetime).

Response:

```
{
  "messages": [
    {
      "id": 199,
      "conversation_id": 42,
      "sender_id": 7,
      "body": "Thanks, I will ship today.",
      "status": "read",
      "attachments": [],
      "sent_at": "2026-07-26T15:30:00Z"
    }
  ],
  "total": 1,
  "pages": 1
}
```

### Send message

`POST /wp-json/zymarg-comm/v1/conversations/{id}/messages`

JSON body for text-only messages:

```
{ "body": "Here is the tracking number: XYZ123" }
```

For attachments use `multipart/form-data` with fields `body` (text) and `file` (binary).

### Mark messages as read

`POST /wp-json/zymarg-comm/v1/conversations/{id}/messages/read`

Marks all messages in the conversation as read for the authenticated user.

## Notifications

### Get unread count

`GET /wp-json/zymarg-comm/v1/notifications/unread-count`

Response: `{ "unread_count": 3 }`

## Moderation (admin only)

### List reports

`GET /wp-json/zymarg-comm/v1/moderation/reports`

Query parameters: `status` (pending, reviewed, dismissed, actioned), `page`, `per_page`.

### Take action on a report

`POST /wp-json/zymarg-comm/v1/moderation/reports/{id}/action`

Request body:

```
{ "action": "dismiss", "note": "Reviewed and dismissed." }
```

Valid actions: `dismiss`, `warn`, `suspend`, `block`, `delete`.

## Feature Flags

### List flags

`GET /wp-json/zymarg-comm/v1/flags`

Response:

```
{
  "flags": {
    "live_chat": true,
    "attachments": true,
    "realtime": false,
    "email_notifications": true
  }
}
```

### Update a flag (admin only)

`PUT /wp-json/zymarg-comm/v1/flags/{key}`

Request body: `{ "enabled": false }`

## Analytics (admin only)

### Get summary

`GET /wp-json/zymarg-comm/v1/analytics/summary`

Query parameters: `period` (7d, 30d, 90d, 365d — default 30d).

Response:

```
{
  "period": "30d",
  "conversations_started": 142,
  "messages_sent": 891,
  "avg_response_time_minutes": 23,
  "active_users": 67
}
```

## Support (Admin⇄User)

Admin⇄User messaging. All routes require authentication. While the `surface.support_chat` feature flag is off, `POST /support/start` returns `403 support_disabled`.

Support threads are ordinary conversations tagged with the context `support`, so once a thread exists you send and read messages through the standard `/conversations/{id}/messages` routes. There are deliberately no support-specific messaging endpoints.

### Get support config

`GET /wp-json/zymarg-comm/v1/support/config`

Response:

```
{
  "enabled": true,
  "label": "Contact Support",
  "context": "support",
  "is_agent": false,
  "agent_count": 3,
  "has_thread": true,
  "inbox_url": "https://example.com/my-account/messages/",
  "rest_root": "https://example.com/wp-json/zymarg-comm/v1"
}
```

### Start or resume a support thread

`POST /wp-json/zymarg-comm/v1/support/start`

Requires a valid nonce. Idempotent: each user has exactly one ongoing support thread, so repeated calls return the same conversation.

Body parameters:

- `user_id` (integer, optional) — open a thread **on behalf of** this user. Support agents only. Customers omit this and receive their own thread.

Response:

```
{
  "conversation_id": 314,
  "is_new": true,
  "agent_id": 7,
  "inbox_url": "https://example.com/my-account/messages/"
}
```

When an existing thread is resumed, `is_new` is `false` and `agent_id` is `0`.

Errors:

- `403 support_disabled` — the feature flag is off.
- `403 forbidden` — a non-agent passed a `user_id` other than their own.
- `404` — no support agent is available.

### List support threads

`GET /wp-json/zymarg-comm/v1/support/threads`

Support agents only, otherwise `403 forbidden`.

Query parameters: `limit` (default 50), `offset` (default 0).

Response:

```
{
  "threads": [
    {
      "conversation_id": 314,
      "status": "active",
      "user_id": 22,
      "user_name": "Alice",
      "last_message_at": "2026-07-29T09:12:00Z",
      "created_at": "2026-07-01T10:00:00Z"
    }
  ],
  "total": 14
}
```

### List support agents

`GET /wp-json/zymarg-comm/v1/support/agents`

Administrators only.

Response:

```
{
  "agents": [
    { "id": 7, "name": "Bob", "email": "bob@example.com", "load": 4 }
  ]
}
```

`load` is the agent's current number of open support threads.

### Filtering the conversation list

`GET /wp-json/zymarg-comm/v1/conversations` accepts an optional `context` parameter:

```
GET /wp-json/zymarg-comm/v1/conversations?context=support
```

Omit it to receive the full inbox. This parameter is optional and additive; existing clients are unaffected.
