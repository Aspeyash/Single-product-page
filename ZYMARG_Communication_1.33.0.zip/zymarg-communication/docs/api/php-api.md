# PHP API Reference

The PHP API lets you interact with ZYMARG Communication from your theme or custom plugin without using the REST API.

## Accessing Services

All services are resolved through the service container:

```
use ZymargCommunication\Bootstrap\ServiceProvider;
use ZymargCommunication\Modules\Conversation\Services\ConversationService;

$service = ServiceProvider::get( ConversationService::class );
```

## ConversationService

### Create a conversation

```
$id = $service->create(
    initiator_id: get_current_user_id(),
    recipient_id: 7,
    body: 'Hello, is this available?'
);
// Returns: int (new conversation ID)
```

### Archive a conversation

```
$service->archive( conversation_id: 42, user_id: get_current_user_id() );
```

### Get conversation status

```
$status = $service->status( 42 );
// Returns: ConversationStatus enum (Active, Archived, PendingApproval, Reported)
```

## MessageService

```
use ZymargCommunication\Modules\Message\Services\MessageService;

$svc = ServiceProvider::get( MessageService::class );
```

### Send a message

```
$message_id = $svc->send(
    conversation_id: 42,
    sender_id: get_current_user_id(),
    body: 'Your order has shipped.'
);
// Returns: int (new message ID)
```

### Get messages for a conversation

```
$messages = $svc->forConversation(
    conversation_id: 42,
    limit: 50,
    offset: 0
);
// Returns: array of message arrays
// Each item: [ id, sender_id, body, status, sent_at, attachments ]
```

## NotificationService

### Get unread count for a user

```
use ZymargCommunication\Modules\Notification\Services\NotificationService;

$svc   = ServiceProvider::get( NotificationService::class );
$count = $svc->unreadCount( user_id: get_current_user_id() );
// Returns: int
```

## ParticipantService

### Add a participant

```
use ZymargCommunication\Modules\Conversation\Services\ParticipantService;
use ZymargCommunication\Shared\Enums\ParticipantRole;
use ZymargCommunication\Shared\Enums\ParticipantType;

$svc = ServiceProvider::get( ParticipantService::class );
$svc->add(
    conversation_id: 42,
    user_id: 12,
    type: ParticipantType::Buyer,
    role: ParticipantRole::Member
);
```

**ParticipantType values:** `Buyer`, `Seller`, `Admin`
**ParticipantRole values:** `Owner`, `Member`

## FlagRegistry

### Check if a feature is enabled

```
use ZymargCommunication\Modules\FeatureFlags\FlagRegistry;

if ( FlagRegistry::isEnabled( 'live_chat' ) ) {
    // render the widget
}
```

### Available flag keys

- `live_chat` - floating chat widget
- `attachments` - file uploads in messages
- `realtime` - Pusher live updates
- `email_notifications` - email alerts
- `analytics` - usage analytics collection
- `moderation` - moderation queue
- `help_center` - admin help docs menu
- `vendor_inbox` - vendor messages tab
- `developer_tools` - dev tools panel

## ZymargComm Global Facade

A simplified alias `ZymargComm` is always available when the plugin is active.
Safe to use from themes without coupling to the full namespace:

```
if ( class_exists( 'ZymargComm' ) ) {
    // Check a flag
    if ( ZymargComm::flag( 'live_chat' ) ) {
        echo 'Live chat is on';
    }

    // Get unread count
    $unread = ZymargComm::unreadCount( get_current_user_id() );

    // Check plugin version
    $version = ZymargComm::version(); // e.g. '1.12.2'
}
```

## ModerationService

```
use ZymargCommunication\Modules\Moderation\Services\ModerationService;

$svc = ServiceProvider::get( ModerationService::class );
```

### Report a conversation

```
$report_id = $svc->report(
    conversation_id: 42,
    reporter_id: get_current_user_id(),
    reason: 'spam'
);
```

### Resolve a report (admin)

```
$svc->resolve(
    report_id: 15,
    action: 'dismiss',
    admin_id: get_current_user_id(),
    note: 'Not a violation.'
);
```

Valid actions: `dismiss`, `warn`, `suspend`, `block`, `delete`.

## AnalyticsService

```
use ZymargCommunication\Modules\Analytics\Services\AnalyticsService;

$svc     = ServiceProvider::get( AnalyticsService::class );
$summary = $svc->summary( period: '30d' );
// Returns: [ conversations_started, messages_sent, avg_response_time_minutes, active_users ]
```

## SupportService

Admin⇄User messaging. All methods are safe to call when the feature is disabled; `startOrResume()` throws a `ValidationException` in that case.

```
use ZymargCommunication\Modules\Support\Services\SupportService;

$svc = ServiceProvider::get( SupportService::class );

$svc->enabled();                 // bool  - is surface.support_chat on
$svc->label();                   // string - filtered channel name
$svc->agentIds();                // int[]  - support agent user ids
$svc->isAgent( $user_id );       // bool
$svc->resolveAgent( $for_user ); // int    - agent who should take this user
$svc->config( $viewer_id );      // array  - machine-readable surface config

$result = $svc->startOrResume( $user_id );
// Returns: [ conversation_id, is_new, agent_id, inbox_url ]
```

Useful constants:

```
SupportService::CAPABILITY;           // 'zymarg_support_agent'
SupportService::FLAG;                 // 'surface.support_chat'
SupportService::OPTION_DEFAULT_AGENT; // 'zymarg_comm_support_default_agent'
SupportService::OPTION_LABEL;         // 'zymarg_comm_support_label'
```

## SupportRepository

```
use ZymargCommunication\Modules\Support\Repositories\SupportRepository;

$repo = ServiceProvider::get( SupportRepository::class );

SupportRepository::CONTEXT;                 // 'support' - the context_type marker
$repo->findForUser( $user_id );             // ?int conversation id
$repo->listAll( $limit = 50, $offset = 0 ); // array of thread rows
$repo->countAll();                          // int
$repo->loadForAgent( $agent_id );           // int open thread count
$repo->requesterFor( $conversation_id );    // ?int customer user id
```

Support threads are ordinary conversations tagged with `context_type = 'support'`. There is no separate table, so every existing conversation and message API works on them unchanged.
