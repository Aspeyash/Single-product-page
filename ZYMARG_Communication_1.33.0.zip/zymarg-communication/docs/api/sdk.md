# Extension SDK

The Extension SDK lets third-party developers add new features to ZYMARG Communication, such as custom message types, additional notification channels, or new feature flags.

## Custom Message Type

Extend AbstractMessageType and register it on the `zymarg_comm_hooks_loaded` action:

```
add_action( 'zymarg_comm_hooks_loaded', function() {
    do_action( 'zymarg_comm_register_message_type', new ProductLinkMessage() );
} );

class ProductLinkMessage {

    public function type(): string {
        return 'product_link';
    }

    public function render( array $message ): string {
        $product_id = $message['meta']['product_id'] ?? 0;
        return sprintf(
            '<a href="%s">%s</a>',
            esc_url( get_permalink( $product_id ) ),
            esc_html( get_the_title( $product_id ) )
        );
    }
}
```

## Custom Notification Channel

Send notifications via SMS, Slack, or any other channel:

```
add_action( 'zymarg_comm_hooks_loaded', function() {
    do_action( 'zymarg_comm_register_notification_channel', new SmsChannel() );
} );

class SmsChannel {

    public function name(): string {
        return 'sms';
    }

    public function send( array $notification ): void {
        $phone = get_user_meta( $notification['user_id'], 'phone_number', true );
        if ( $phone ) {
            my_sms_provider_send( $phone, $notification['body'] );
        }
    }
}
```

## Custom Feature Flag

Register additional feature flags so they appear in the admin Feature Flags panel:

```
add_filter( 'zymarg_comm_feature_flags', function( array $flags ): array {
    $flags['my_custom_feature'] = true; // default enabled
    return $flags;
} );
```

Check it anywhere using FlagRegistry:

```
use ZymargCommunication\Modules\FeatureFlags\FlagRegistry;

if ( FlagRegistry::isEnabled( 'my_custom_feature' ) ) {
    // run your feature
}
```

## Listening to Domain Events

Subscribe to domain events dispatched by the plugin:

```
add_action( 'zymarg_comm_hooks_loaded', function() {
    add_action( 'zymarg_comm_message_sent',
        function( int $message_id, int $conversation_id, int $sender_id ) {
            // e.g. log to an external CRM
            my_crm_log( $sender_id, 'message_sent', $message_id );
        },
        10, 3
    );
} );
```

**Available action hooks:**

- `zymarg_comm_message_sent` - args: `$message_id, $conversation_id, $sender_id`
- `zymarg_comm_conversation_created` - args: `$conversation_id, $initiator_id, $recipient_id`
- `zymarg_comm_conversation_archived` - args: `$conversation_id, $user_id`
- `zymarg_comm_moderation_action` - args: `$action, $report_id, $admin_id`

## Adding Admin Submenu Pages

Add your own submenu under ZYMARG Communication:

```
use ZymargCommunication\Bootstrap\AdminMenu;

add_action( 'admin_menu', function() {
    add_submenu_page(
        AdminMenu::MENU_SLUG,       // parent slug
        'My Extension',             // page title
        'My Extension',             // menu label
        'manage_options',           // capability
        'my-zymarg-extension',      // slug
        'my_extension_render_page'  // callback
    );
}, 99 );

function my_extension_render_page(): void {
    echo '<div class="wrap"><h1>My Extension</h1></div>';
}
```

## Accessing the Service Container

All plugin services are available via the ServiceProvider:

```
use ZymargCommunication\Bootstrap\ServiceProvider;
use ZymargCommunication\Modules\Conversation\Services\ConversationService;

$svc = ServiceProvider::get( ConversationService::class );
```

Refer to the PHP API Reference for a full list of available services and their methods.

## Compatibility Checks

Before calling any plugin code, check it is active:

```
if ( ! class_exists( 'ZymargComm' ) ) {
    return; // plugin not active
}
```

Or check the version:

```
if ( defined( 'ZYMARG_COMM_VERSION' ) && version_compare( ZYMARG_COMM_VERSION, '1.12.0', '>=' ) ) {
    // safe to use v1.12 features
}
```
