# ZYMARG Communication — Developer Reference

> This is the single source of truth for the ZYMARG Communication plugin.
> Read the entire document before writing a single line of code.
> If you are starting a build session with an AI assistant, paste this
> entire file as your first message. Everything needed is here.

---

## 0. Goal

This plugin is the unified messaging and communication layer for the ZYMARG
marketplace ecosystem. It owns all conversation surfaces across the platform:

- **Store page chat popup** — messenger-style floating popup on vendor store pages
- **Vendor dashboard inbox** — full inbox inside the vendor dashboard
- **Buyer inbox** — full inbox inside the buyer account area

No other plugin may own, render, or intercept any of these surfaces. This
plugin is the single authority for all messaging UI and all messaging data.
It is fully independent from the active WordPress theme.

---

## 1. Plugin Identity

| Field              | Value                                                          |
|--------------------|----------------------------------------------------------------|
| Plugin Name        | ZYMARG Communication                                           |
| Version            | 1.0.0                                                          |
| Text Domain        | `zymarg-communication`                                         |
| WordPress folder   | `zymarg-communication` (never versioned, never renamed)        |
| PHP Namespace      | `ZymargCommunication` (PSR-4, not procedural prefixes)         |
| Version constant   | `ZYMARG_COMM_VERSION` in `zymarg-communication.php`            |
| Bootstrap file     | `zymarg-communication.php`                                     |
| Minimum PHP        | 8.1                                                            |
| Minimum WordPress  | 6.0                                                            |
| Autoload map       | `ZymargCommunication\` → `app/`                                |
| REST namespace     | `zymarg-comm/v1`                                               |
| JS global          | `window.ZymargComm`                                            |
| CSS class prefix   | `zymarg-comm-`                                                 |

---

## 2. Version Bump — Mandatory Protocol

**Before writing a single line of code for any phase**, the version must be
bumped everywhere. The version on disk is always a truthful record of which
phase is currently in progress — not which phase is complete.

Work through this checklist in order before opening any other file:

- [ ] `zymarg-communication.php` → `Version:` header line
- [ ] `zymarg-communication.php` → `ZYMARG_COMM_VERSION` constant
- [ ] `composer.json` → `"version"` field
- [ ] `readme.txt` → `Stable tag:` field
- [ ] `readme.txt` → add new version entry under `== Changelog ==`

**Never write feature code and version bump code in the same commit.**
The bump is always its own isolated change.

**Never ship two different builds with the same version number.**

### Phase-to-version table

| Event                        | Version    |
|------------------------------|------------|
| Scaffold created             | `v1.0.0`   |
| Phase 1 begins               | `v1.1.0`   |
| Phase 2 begins               | `v1.2.0`   |
| Phase 3 begins               | `v1.3.0`   |
| Phase 4 begins               | `v1.4.0`   |
| Phase 5 begins               | `v1.5.0`   |
| Phase 6 begins               | `v1.6.0`   |
| Phase 7 begins               | `v1.7.0`   |
| Phase 8 begins               | `v1.8.0`   |
| Phase 9 begins               | `v1.9.0`   |
| Phase 10 begins              | `v1.10.0`  |
| Phase 11 begins              | `v1.11.0`  |

Anyone opening the plugin can look at the version and immediately know
exactly how far the build has progressed. `v1.7.0` means Phases 1–6 are
complete and Phase 7 is currently in progress.

---

## 3. Architecture Rules — Non-Negotiable

These rules apply to every file in the plugin without exception.
When in doubt, re-read this section before writing any code.

### The five-layer rule

Every feature must travel this exact path. No shortcuts.

```
UI (template / JS)
    ↓
REST API (Controller)
    ↓
Service Layer (Service)
    ↓
Repository Layer (Repository)
    ↓
Database (wpdb)
```

- **Controllers** validate the request, call one Service method, return a
  response. Nothing else. No database calls. No business logic.
- **Services** contain all business logic. They call Repositories for data.
  They never call `$wpdb` directly.
- **Repositories** are the only layer that touches `$wpdb`. They return plain
  data objects or arrays. They contain no business logic.
- **No feature exists only in JavaScript.** Every JS action must have a
  corresponding REST endpoint. Android and iOS consume the same REST endpoints.
- **No feature directly accesses the database** outside a Repository class.

### Module boundary rules

- Each module owns its own Controllers, Services, Repositories, Models, and Hooks.
- Modules may call Services from other modules. They must never call another
  module's Repository directly.
- Cross-module data flows through Service-to-Service calls only.

### Upload security rules

- Every file upload must pass through `FileValidationService` before any other
  code touches it. No exceptions.
- `AttachmentService` delegates to `FileValidationService` and `FileStorageService`.
  It never handles raw uploaded file data directly.
- Allowed upload types: JPG, JPEG, PNG, WebP only.
- MIME type must be verified. File signature (magic bytes) must be verified.
  Extension alone is never trusted.
- EXIF metadata must be stripped from all uploaded images.
- Filenames must be randomized on storage. Original filenames are never used.
- Uploaded files are stored under the WordPress uploads directory.
  Direct execution of uploaded files must be prevented.

### Admin privacy rules

- Admins may read both sides of every conversation.
- **A read by an admin must never trigger a read receipt for any participant.**
- **A read by an admin must never fire any notification to any participant.**
- All admin reads are recorded silently in the audit log via `AuditLogService`.
- `AdminViewService` is the only entry point for admin conversation reads.
  Never route an admin read through the same code path as a participant read.

### Scheduler rules

- `Bootstrap/Scheduler.php` is the only file that registers WP-Cron hooks.
- `MessageLifecycleService` is the only service that archives or deletes messages.
- No other file may schedule, archive, or delete messages.

### Realtime rules

- `RealtimeDriverInterface` is the contract all realtime drivers implement.
- The active driver (WebSocket / SSE / Pusher) is selected via configuration.
  Calling code never references a specific driver class directly.
- Typing indicators and online status are owned by `PresenceService`.
- Message queue and reconnection logic are owned by `QueueService`.

### Rate limiting rules

- Rate limiting is applied at the middleware level in
  `Infrastructure/Http/Middleware/RateLimitMiddleware.php`.
- Services never implement their own rate limiting logic.

### Audit log rules

- Every admin action is recorded by `AuditLogService`.
- Audit log writes are silent — they never throw, never affect the response,
  and never reveal their existence to users.

### Feature flag rules

- Every Service method that executes a toggleable feature must call
  `$this->isEnabled('flag.key')` as its first statement.
- If the flag is disabled, the method returns a silent no-op. No exception,
  no error, no log entry visible to the user.
- `FeatureFlagService` is the only class that reads or writes flag state.
- No flag state is hardcoded anywhere in the plugin. All defaults live in
  the Definition classes under `Modules/FeatureFlags/Definitions/`.

### Injection and compatibility rules

- `Bootstrap/Compatibility.php` is the **only file** permitted to reference
  external plugin names, classes, or functions.
- `Bootstrap/ShortcodeRegistrar.php` is the **only file** that calls
  `add_shortcode()`.
- `Bootstrap/PageRegistrar.php` is the **only file** that creates or deletes
  plugin-owned WordPress pages.
- The store page popup is injected exclusively via the `wp_footer` hook.
  No other injection mechanism is permitted for the popup.
- The chatbox must not load assets or fire network requests on any page
  where it is not active.

### Admin panel rules

- Every admin panel interaction must happen without a full page reload.
  No `<form method="POST" action="">` in any admin template. Everything is AJAX.
- All admin form submissions use `data-*` attributes handled by `assets/js/admin/admin.js`.
- Every admin action must have a corresponding REST endpoint. No action is
  JS-only with no server counterpart.
- Every AJAX action in the admin must show an inline spinner while pending,
  and an inline success or error state when complete.
- Admin JS lives exclusively in `assets/js/admin/admin.js`. No inline
  `<script>` blocks in any admin template.

### Credential security rules

- Every third-party credential field (Pusher App Secret, Pusher App ID,
  any future API key) renders as `type="password"` — always masked.
- When the admin pastes or types a value and moves focus away, the field
  stays masked permanently for that session.
- A "Reveal" toggle button sits beside every credential field. Clicking
  it temporarily shows the plaintext value. Clicking again re-masks it.
- On save, all credential values are encrypted via `EncryptionService`
  before being written to the database.
- Admin settings API endpoints must never return the raw credential value.
  They return `is_configured: true` or `is_configured: false` only.
- On admin settings page load, credential fields always load masked and
  empty. The stored value is never sent to the frontend.
- This rule applies to every credential field added in the future, not
  only Pusher. Any new third-party credential must follow this pattern.

### UI parity rules

- There is one chatbox component. Not one for buyers and one for sellers.
- Parity flags apply to both sides simultaneously. A parity flag cannot
  show information to the seller while hiding the equivalent from the buyer.
- Every asymmetric feature must be explicitly listed in Section 14.3 of
  this document before it is implemented.

- Escape all output: `esc_html()`, `esc_attr()`, `esc_url()`, `wp_kses_post()`.
- Sanitize all input and all data read from the database before use.
- Nonce-protect all form submissions and all state-changing REST endpoints.
- Use translation functions on all user-facing strings.
  Text domain: `zymarg-communication`.
- Never call `error_log()`, `var_dump()`, or `print_r()` in production code.

### Frontend rules

- Vanilla JavaScript on the frontend. No jQuery on the frontend.
- One responsibility per JS file.
- Use `data-*` attributes for PHP-to-JS data passing. No inline `onclick` handlers.
- No inline `<style>` blocks in HTML output.
- No inline `<script>` blocks in HTML output.
- All CSS classes use the `zymarg-comm-` prefix to prevent theme conflicts.

---

## 4. Boot Sequence

```
zymarg-communication.php
    → defines all ZYMARG_COMM_* constants
    → loads vendor/autoload.php
    → registers activation hook   → Bootstrap\Installer::activate()
    → registers deactivation hook → Bootstrap\Installer::deactivate()
    → plugins_loaded → Bootstrap\Plugin::init()
        → Bootstrap\ServiceProvider::register()
            → registers all module services into the container
            → registers FeatureFlagService as a singleton (checked everywhere)
        → Bootstrap\HookLoader::load()
            → loads Hooks class from each module in order
            → each Hooks class registers add_action / add_filter calls
        → Bootstrap\ShortcodeRegistrar::register()
            → registers all plugin shortcodes
            → the only file that calls add_shortcode()
        → Bootstrap\Compatibility::register()
            → detects which third-party plugins are active
            → registers the best available injection method per surface
            → hooks first, shortcode fallback second
            → the only file in the plugin that references external plugin names
        → Bootstrap\Scheduler::register()
            → registers all WP-Cron schedules and callbacks
        → Bootstrap\Updater::check()
            → runs pending database migrations on version change
```

**Admin sidebar menu label:** `Communication`
**Admin page title format:** `{Page Name} — Communication`
The menu is registered in `Settings/Hooks/SettingsHooks.php` using
`add_menu_page()` with the label `Communication`. Never use the full plugin
name `ZYMARG Communication` as the menu label.

On activation (`Installer::activate()`):
- All database tables are created via the Migration classes.
- Default settings are written.
- All feature flags are written with their default values via `FlagRegistry`.
- Plugin-owned pages are created via `PageRegistrar::create()`.
- Rewrite rules are flushed.

On deactivation (`Installer::deactivate()`):
- WP-Cron schedules are cleared.
- Rewrite rules are flushed.
- No data is deleted on deactivation. Data deletion only happens on uninstall.

On uninstall (`uninstall.php` → `Uninstaller::run()`):
- All plugin tables are dropped.
- All plugin options are deleted.
- All plugin-owned pages are deleted via `PageRegistrar::destroy()`.
- All plugin uploads are removed.

---

## 5. Directory Map

```
zymarg-communication/
│
├── zymarg-communication.php   Bootstrap file. Constants, autoloader, hooks.
├── composer.json              PSR-4 autoload map, dev dependencies.
├── uninstall.php              Runs Uninstaller on plugin deletion.
├── readme.txt                 WordPress plugin readme. Stable tag and changelog.
├── CONTRIBUTING.md            This file. Single source of truth.
│
├── app/
│   ├── Api/                   Public PHP API facade. Entry point for third-party plugins.
│   │
│   ├── Bootstrap/             Plugin startup. Runs before any module.
│   │   ├── Plugin.php             Main coordinator.
│   │   ├── ServiceProvider.php    Registers all services into the container.
│   │   ├── HookLoader.php         Loads all module Hooks classes.
│   │   ├── ShortcodeRegistrar.php Registers all shortcodes. Only file that calls add_shortcode().
│   │   ├── Compatibility.php      Detects active third-party plugins. Registers injection methods.
│   │   ├── PageRegistrar.php      Creates and destroys plugin-owned WordPress pages.
│   │   ├── Scheduler.php          Registers all WP-Cron schedules.
│   │   ├── Installer.php          Activation and deactivation logic.
│   │   ├── Uninstaller.php        Full data removal on plugin deletion.
│   │   └── Updater.php            Runs pending migrations on version change.
│   │
│   ├── Core/
│   │   ├── Contracts/         Interfaces. Define what every layer must implement.
│   │   ├── Abstracts/         Base classes. Shared behaviour for Controllers, Services, Repositories.
│   │   ├── Exceptions/        Typed exceptions. Thrown by Services, caught by Controllers.
│   │   └── Helpers/           Stateless utility functions. No dependencies.
│   │
│   ├── Infrastructure/
│   │   ├── Database/
│   │   │   ├── Migrations/    One class per schema change. Run by Updater on version bump.
│   │   │   ├── Repositories/  Base repository. All module repositories extend this.
│   │   │   └── QueryBuilders/ Fluent query construction for complex queries.
│   │   ├── Cache/             Cache drivers. Transient and object cache wrappers.
│   │   └── Http/
│   │       ├── Controllers/   Base REST controller. All module controllers extend this.
│   │       ├── Middleware/     Auth, nonce, rate limit. Applied before controllers run.
│   │       ├── Requests/      Request validation. Sanitizes and validates incoming data.
│   │       └── Responses/     Standardized API response shapes.
│   │
│   ├── Shared/
│   │   ├── DTOs/              Data Transfer Objects. Typed data carriers between layers.
│   │   ├── Enums/             PHP 8.1 backed enums. Shared constants across modules.
│   │   ├── Events/            Event objects and the EventDispatcher.
│   │   ├── Traits/            Reusable behaviour mixed into multiple classes.
│   │   └── ValueObjects/      Immutable typed identifiers (UserId, MessageId, etc.).
│   │
│   └── Modules/
│       ├── Conversation/      Thread lifecycle, participant management, permissions, export.
│       ├── Message/           Message CRUD, attachments, reactions, read receipts, lifecycle.
│       ├── Marketplace/       Store popup, vendor inbox, buyer inbox, product sharing, order chat.
│       ├── Notification/      Email, push, browser, mobile notifications and preferences.
│       ├── Realtime/          WebSocket, SSE, Pusher, polling, presence, queue.
│       ├── Moderation/        Reports, spam, blocklist, profanity filter, admin stealth view.
│       ├── Analytics/         Event tracking, admin reports, user reports, dashboards.
│       ├── Security/          File validation, EXIF strip, file storage, encryption, audit logs.
│       ├── HelpCenter/        User guide, admin guide, API docs, changelog, FAQ.
│       ├── Settings/          Global settings, user preferences, popup settings.
│       ├── FeatureFlags/      Master toggle system. Every feature check routes through here.
│       │   ├── Controllers/
│       │   ├── Services/
│       │   ├── Repositories/
│       │   ├── Models/
│       │   ├── Hooks/
│       │   ├── Definitions/   One file per flag group. Declares every toggleable flag.
│       │   └── FlagRegistry.php  Master list. Registers all flag definitions on boot.
│       └── Developer/         Webhooks, API keys, extensions, SDK.
│
├── assets/
│   ├── css/
│   │   ├── admin/             Admin-only stylesheets.
│   │   └── frontend/          Public-facing stylesheets.
│   ├── js/
│   │   ├── admin/             Admin-only scripts.
│   │   └── frontend/
│   │       ├── communication.js   Main frontend UI script.
│   │       ├── realtime.js        Realtime connection and event handling.
│   │       └── sdk.js             Public JS API. Exposes window.ZymargComm.
│   ├── images/
│   └── fonts/
│
├── docs/
│   ├── api/                   REST API documentation source files.
│   ├── architecture/          Architecture decision records.
│   └── guides/                User guide and admin guide source files.
│
├── languages/                 .po and .mo translation files.
│
├── storage/
│   ├── logs/                  Plugin-generated log files.
│   ├── cache/                 File-based cache if used.
│   └── uploads/               Temporary upload staging area.
│
└── tests/
    ├── Unit/                  Unit tests for Service layer.
    ├── Integration/           Integration tests for REST endpoints.
    └── Feature/               End-to-end feature tests.
```

---

## 6. Module Reference

Each module section describes what the module owns, what it does not own,
and the responsibility of every file inside it.

---

### 6.1 Conversation

**Owns:** conversation thread lifecycle, participant management, permission
rules, conversation search and filtering, archive, pin, delete, export.

**Does not own:** message content (Message module), realtime delivery
(Realtime module), notifications triggered by conversation events
(Notification module).

| File | Responsibility |
|------|---------------|
| `Controllers/ConversationController.php` | REST endpoints for conversation CRUD, archive, pin, search, filter. |
| `Services/ConversationService.php` | Create, archive, pin, delete, search, and filter conversations. Enforces business rules. |
| `Services/ConversationPermissionService.php` | Determines whether a given participant type may initiate or continue a conversation. Enforces the Buyer→Seller / Seller→Buyer approval rule and configurable Seller↔Seller / Buyer↔Buyer toggles. |
| `Services/ParticipantService.php` | Add, remove, and query participants within a conversation. |
| `Services/ConversationExportService.php` | Export conversation history to CSV or print-ready format. Admin only. |
| `Repositories/ConversationRepository.php` | All database reads and writes for the conversations table. |
| `Repositories/ParticipantRepository.php` | All database reads and writes for the participants table. |
| `Models/Conversation.php` | Plain data object representing a conversation record. |
| `Models/Participant.php` | Plain data object representing a participant record. |
| `Hooks/ConversationHooks.php` | Registers all WordPress actions and filters owned by this module. |

---

### 6.2 Message

**Owns:** message content, text, emoji, image attachments, reply threading,
message reactions, read receipts, delivered status, message lifecycle
(archive and deletion schedule).

**Does not own:** typing indicator and online status (Realtime module),
file upload security validation (Security module), push notifications
triggered by new messages (Notification module).

| File | Responsibility |
|------|---------------|
| `Controllers/MessageController.php` | REST endpoints for send, edit, delete, reply, copy, react. |
| `Controllers/AttachmentController.php` | REST endpoints for upload and retrieve attachments. |
| `Services/MessageService.php` | Send, edit, delete, and retrieve messages. Enforces reply threading. |
| `Services/AttachmentService.php` | Receives upload requests, delegates to Security module for validation and storage, saves attachment record. |
| `Services/ReactionService.php` | Add and remove emoji reactions on messages. |
| `Services/ReadReceiptService.php` | Mark messages as delivered and read. Must never be called for admin reads. |
| `Services/MessageLifecycleService.php` | Archives messages older than 90 days. Permanently deletes archived messages older than 365 days. Conversations are never touched. |
| `Repositories/MessageRepository.php` | All database reads and writes for the messages table. |
| `Repositories/AttachmentRepository.php` | All database reads and writes for the attachments table. |
| `Repositories/ReactionRepository.php` | All database reads and writes for the reactions table. |
| `Models/Message.php` | Plain data object representing a message record. |
| `Models/Attachment.php` | Plain data object representing an attachment record. |
| `Models/Reaction.php` | Plain data object representing a reaction record. |
| `Hooks/MessageHooks.php` | Registers all WordPress actions and filters owned by this module. |

---

### 6.3 Marketplace

**Owns:** the three rendered surfaces (store popup, vendor inbox, buyer inbox),
product sharing in chat (product cards, category shares, store links),
order communication (order chat, order timeline, attachments, notes),
popup page visibility rules.

**Does not own:** conversation data (Conversation module), message data
(Message module), popup global enable/disable toggle (Settings module).

| File | Responsibility |
|------|---------------|
| `Controllers/MarketplaceController.php` | REST endpoints for surface-specific actions. |
| `Services/StorePopupService.php` | Renders the floating chat popup on store pages. Handles auto-appear on new message. |
| `Services/VendorInboxService.php` | Renders the full inbox inside the vendor dashboard. |
| `Services/BuyerInboxService.php` | Renders the full inbox inside the buyer account area. |
| `Services/ProductSharingService.php` | Generates shareable product cards, category shares, and store link previews for use in chat. |
| `Services/OrderChatService.php` | Attaches a conversation thread to a WooCommerce order. Manages order timeline entries, order attachments, and order notes within chat. |
| `Repositories/MarketplaceRepository.php` | Marketplace-specific data queries (e.g. store context, order context). |
| `Models/MarketplaceContext.php` | Plain data object representing the current marketplace surface context. |
| `Models/ProductCard.php` | Plain data object representing a shareable product card. |
| `Hooks/MarketplaceHooks.php` | Registers all WordPress actions and filters owned by this module. |

---

### 6.4 Notification

**Owns:** all notification delivery channels (email, push, browser, mobile),
notification preferences per user, quiet hours enforcement.

**Does not own:** the events that trigger notifications (each module fires
its own events), realtime delivery of in-app notifications (Realtime module).

| File | Responsibility |
|------|---------------|
| `Controllers/NotificationController.php` | REST endpoints for reading and dismissing notifications. |
| `Services/NotificationService.php` | Central dispatcher. Receives notification requests and routes them to the correct channel services. |
| `Services/EmailNotificationService.php` | Sends email notifications via `wp_mail()`. |
| `Services/PushNotificationService.php` | Sends mobile push notifications (FCM / APNs). |
| `Services/BrowserNotificationService.php` | Sends Web Push API browser notifications. Distinct from mobile push. |
| `Services/NotificationPreferenceService.php` | Reads and writes per-user notification preferences. Enforces quiet hours. All channel services check here before sending. |
| `Repositories/NotificationRepository.php` | All database reads and writes for the notifications table. |
| `Models/Notification.php` | Plain data object representing a notification record. |
| `Hooks/NotificationHooks.php` | Listens to events from other modules and triggers notification dispatch. |

---

### 6.5 Realtime

**Owns:** all realtime connection handling, driver abstraction, presence
detection, typing indicators, online status, message queuing, reconnection.

**Does not own:** message content (Message module), notification content
(Notification module).

| File | Responsibility |
|------|---------------|
| `Controllers/RealtimeController.php` | REST endpoints for polling fallback and SSE stream initiation. |
| `Services/WebSocketService.php` | WebSocket driver. Implements `RealtimeDriverInterface`. |
| `Services/SseService.php` | Server-Sent Events driver. Implements `RealtimeDriverInterface`. Used as fallback when WebSocket is unavailable. |
| `Services/PusherService.php` | Pusher third-party driver. Implements `RealtimeDriverInterface`. Default driver. Exposes `testConnection( array $credentials ): array` used by the admin test button — returns `['status' => 'connected'\|'failed'\|'partial', 'message' => string]`. |
| `Services/PollingService.php` | Long-polling fallback for environments where SSE and WebSocket are unavailable. |
| `Services/PresenceService.php` | Tracks online status, typing indicators, and connection state per user per conversation. |
| `Services/QueueService.php` | Queues outgoing realtime events for reliable delivery. Handles reconnection and missed events. |
| `Repositories/RealtimeRepository.php` | Presence and queue state persistence. |
| `Models/RealtimeEvent.php` | Plain data object representing a realtime event to be delivered. |
| `Hooks/RealtimeHooks.php` | Listens to message and conversation events and pushes them through the active driver. |

---

### 6.6 Moderation

**Owns:** conversation reports, spam detection, profanity filtering,
blocklist management, admin review tools, admin stealth conversation reads.

**Does not own:** audit logs for admin actions (Security module), user
banning at the WordPress user level (handled outside this plugin).

| File | Responsibility |
|------|---------------|
| `Controllers/ModerationController.php` | REST endpoints for reporting, reviewing, and acting on moderation cases. |
| `Services/ModerationService.php` | Processes conversation reports, changes conversation status to Reported, surfaces cases for admin review. |
| `Services/SpamFilterService.php` | Analyses incoming messages for spam patterns. Blocks or flags messages that match. |
| `Services/BlocklistService.php` | Manages blocked words and blocked users. Checked before any message is stored. |
| `Services/AdminViewService.php` | The only entry point for admin reads of conversation content. Reads both sides without triggering any read receipts, delivered status, or notifications. Records the read silently via AuditLogService. |
| `Repositories/ModerationRepository.php` | All database reads and writes for the moderation_logs table. |
| `Models/ModerationLog.php` | Plain data object representing a moderation log entry. |
| `Hooks/ModerationHooks.php` | Registers all WordPress actions and filters owned by this module. |

---

### 6.7 Analytics

**Owns:** event tracking, admin-scoped reports (platform-wide), user-scoped
reports (per user), performance dashboards.

**Does not own:** raw message or conversation data (those modules own their
own data). Analytics reads from its own events table populated by listeners.

| File | Responsibility |
|------|---------------|
| `Controllers/AnalyticsController.php` | REST endpoints for dashboard data and report exports. |
| `Services/AnalyticsService.php` | Records analytics events. Called by other modules when trackable actions occur. |
| `Services/AdminReportService.php` | Platform-wide metrics: total conversation volume, all seller response rates, average response times, satisfaction scores, unread report count. Accessible to admins only. |
| `Services/UserReportService.php` | Per-user metrics: their own response time, conversation volume, seller response rate, personal performance dashboard. |
| `Services/ReportService.php` | Shared aggregation logic used by both Admin and User report services. |
| `Repositories/AnalyticsRepository.php` | All database reads and writes for the analytics_events table. |
| `Models/AnalyticsEvent.php` | Plain data object representing an analytics event record. |
| `Hooks/AnalyticsHooks.php` | Listens to events from all modules and records them as analytics events. |

---

### 6.8 Security

**Owns:** all file upload validation and secure storage, EXIF metadata
removal, encryption utilities, audit logs.

**Does not own:** permission checks for conversation access (Conversation
module), rate limiting (Infrastructure middleware).

| File | Responsibility |
|------|---------------|
| `Controllers/SecurityController.php` | REST endpoints for security-related admin actions. |
| `Services/SecurityService.php` | General security utilities. Coordinates the other Security services. |
| `Services/FileValidationService.php` | Validates every uploaded file before storage. Checks MIME type, verifies file signature (magic bytes), enforces allowlist (JPG, JPEG, PNG, WebP only), rejects all other types, enforces max file size and max image dimensions. |
| `Services/ExifStripService.php` | Strips EXIF metadata from validated images. Generates randomized storage filenames. |
| `Services/FileStorageService.php` | Moves validated, stripped files to the correct path under WordPress uploads. Applies permissions to prevent direct execution. Returns the final storage path. |
| `Services/EncryptionService.php` | Encryption and decryption utilities for sensitive data fields. Encryption-ready architecture — implement when required. |
| `Services/AuditLogService.php` | Records all admin actions silently. Writes to the audit_logs table. Never throws. Never affects the response that triggered it. |
| `Repositories/SecurityRepository.php` | All database reads and writes for the audit_logs table. |
| `Models/AuditLog.php` | Plain data object representing an audit log record. |
| `Hooks/SecurityHooks.php` | Registers all WordPress actions and filters owned by this module. |

---

### 6.9 HelpCenter

**Owns:** the built-in help page, user guide, admin guide, API documentation
rendering, hooks and filters reference, SDK documentation, mobile integration
guide, troubleshooting, changelog display, FAQ.

**Does not own:** the actual documentation content files (those live in
`/docs/` and are read by this module's services).

| File | Responsibility |
|------|---------------|
| `Controllers/HelpCenterController.php` | REST endpoints for help content retrieval. |
| `Services/HelpCenterService.php` | Renders the user guide and admin guide from `/docs/guides/`. |
| `Services/DocumentationService.php` | Serves all technical documentation: REST API docs, PHP API docs, JS API docs, hooks reference, SDK docs, mobile integration guide. Reads from `/docs/api/`. |
| `Services/ChangelogService.php` | Parses and serves the plugin changelog. Reads from `readme.txt`. |
| `Services/FaqService.php` | Manages FAQ articles. |
| `Repositories/HelpCenterRepository.php` | Persists FAQ articles and help content that is stored in the database. |
| `Models/HelpArticle.php` | Plain data object representing a help article. |
| `Hooks/HelpCenterHooks.php` | Registers all WordPress actions and filters owned by this module. |

---

### 6.10 Settings

**Owns:** global plugin settings, per-user preferences, chat popup page
visibility rules (which pages show the popup, global on/off toggle).

**Does not own:** module-specific configuration (each module may store its
own options, but the Settings module owns the admin UI for all of them).

| File | Responsibility |
|------|---------------|
| `Controllers/SettingsController.php` | REST endpoints for reading and writing settings. Registers the admin sidebar menu as "Communication". Handles `POST /settings/pusher/test` — calls `PusherService::testConnection()` and returns inline result. Never returns raw credential values on GET. |
| `Services/SettingsService.php` | Reads and writes global plugin settings. Encrypts credential values via `EncryptionService` before storage. Returns `is_configured: true/false` for credential fields instead of raw values. |
| `Services/UserPreferencesService.php` | Reads and writes per-user preferences (notification preferences delegated to Notification module). |
| `Services/PopupSettingsService.php` | Reads and writes popup visibility rules: global enable/disable, excluded page list. |
| `Repositories/SettingsRepository.php` | All database reads and writes for the settings table. |
| `Models/Setting.php` | Plain data object representing a setting record. |
| `Hooks/SettingsHooks.php` | Registers the WordPress admin sidebar menu with the label "Communication". Registers all other actions and filters owned by this module. |

---

### 6.11 Developer

**Owns:** webhook registration and dispatch, API key management, third-party
extension registration, SDK documentation.

**Does not own:** the public PHP API facade (that lives in `app/Api/`),
the JS SDK script (that lives in `assets/js/frontend/sdk.js`).

| File | Responsibility |
|------|---------------|
| `Controllers/DeveloperController.php` | REST endpoints for webhook management and API key management. |
| `Services/WebhookService.php` | Registers, validates, and dispatches outgoing webhooks when platform events occur. |
| `Services/ApiKeyService.php` | Creates, rotates, and revokes API keys for external consumers. |
| `Services/ExtensionService.php` | Allows third-party plugins to register as extensions. Provides the extension registration API. |
| `Repositories/DeveloperRepository.php` | All database reads and writes for the webhooks and api_keys tables. |
| `Models/Webhook.php` | Plain data object representing a webhook registration. |
| `Hooks/DeveloperHooks.php` | Registers all WordPress actions and filters owned by this module. |

---

### 6.12 FeatureFlags

**Owns:** the master toggle system for every feature in the plugin. Every
Service that executes a toggleable feature must check here first via the
`ChecksFeatureFlags` trait. The admin toggle UI reads and writes through
this module. This is the single source of truth for what is on and off.

**Does not own:** the features themselves. This module only stores state.
It never executes feature logic directly.

**Rule:** `FeatureFlagService::isEnabled( 'flag.key' )` must be the first
call inside any method that executes a toggleable feature. If the flag is
disabled, the method returns early. No exception, no error — silent no-op.

| File | Responsibility |
|------|---------------|
| `Controllers/FeatureFlagController.php` | REST endpoints for reading and toggling flags. Admin only for write. Public read for frontend. |
| `Services/FeatureFlagService.php` | Reads and writes flag state. The single `isEnabled()` authority. |
| `Services/FeatureFlagCacheService.php` | Caches flag state so every request does not hit the database. Cache is invalidated on any flag write. |
| `Repositories/FeatureFlagRepository.php` | All database reads and writes for the `zc_feature_flags` table. |
| `Models/FeatureFlag.php` | Plain data object representing a feature flag record. |
| `Hooks/FeatureFlagHooks.php` | Registers WordPress actions and filters owned by this module. |
| `FlagRegistry.php` | Loads all Definition classes on boot. Writes default flag state to the database on first activation if flags do not yet exist. |
| `Definitions/SurfaceFlags.php` | Declares all surface-level flags: popup, buyer inbox, vendor inbox. |
| `Definitions/ConversationFlags.php` | Declares all conversation flags: seller-initiate, seller-seller, buyer-buyer, archive, pin, search. |
| `Definitions/MessageFlags.php` | Declares all message flags: emoji, attachments, replies, reactions, typing, online status, read receipts, delivered status. |
| `Definitions/MarketplaceFlags.php` | Declares all marketplace flags: product sharing, category sharing, store links, order chat, order timeline. |
| `Definitions/ParityFlags.php` | Declares all UI parity flags: response rate visibility, last active visibility, avatar visibility, profile info visibility. Parity flags always apply to both sides simultaneously. |
| `Definitions/NotificationFlags.php` | Declares all notification flags: email, push, browser, mobile, quiet hours. |
| `Definitions/ModerationFlags.php` | Declares all moderation flags: spam filter, profanity filter, conversation reporting. |
| `Definitions/RealtimeFlags.php` | Declares all realtime flags: WebSocket, SSE, Pusher. |

---

## 7. Shared Layers Reference

### 7.1 Bootstrap

| File | Responsibility |
|------|---------------|
| `Plugin.php` | Main plugin class. Coordinates all Bootstrap classes in the correct order. |
| `ServiceProvider.php` | Registers all module services into the dependency container. Registers FeatureFlagService as a singleton. |
| `HookLoader.php` | Instantiates and loads each module's Hooks class in the correct order. |
| `ShortcodeRegistrar.php` | The only file that calls `add_shortcode()`. Registers all plugin shortcodes on boot. |
| `Compatibility.php` | Detects active third-party plugins and registers the best injection method per surface. The only file in the plugin that references external plugin names. |
| `PageRegistrar.php` | Creates plugin-owned WordPress pages on activation. Removes them on uninstall. |
| `Installer.php` | Runs on activation (create tables, write flag defaults, create pages, flush rules) and deactivation (clear cron, flush rules). |
| `Uninstaller.php` | Runs on plugin deletion. Drops all tables, deletes all options, destroys plugin pages, removes all uploads. |
| `Updater.php` | Runs pending migrations when the stored version does not match `ZYMARG_COMM_VERSION`. |
| `Scheduler.php` | The only file that registers WP-Cron schedules. Registers the message lifecycle job and any future scheduled jobs. |

### 7.2 Core / Contracts

| File | Responsibility |
|------|---------------|
| `RepositoryInterface.php` | Contract all Repositories must implement. Defines standard CRUD methods. |
| `ServiceInterface.php` | Contract all Services must implement. |
| `CacheInterface.php` | Contract for cache drivers. |
| `EventInterface.php` | Contract all Event objects must implement. |
| `HookableInterface.php` | Contract all Hooks classes must implement. |
| `ModuleInterface.php` | Contract all Module classes must implement. |
| `RealtimeDriverInterface.php` | Contract all realtime drivers must implement. WebSocket, SSE, and Pusher all implement this. |
| `FeatureFlagInterface.php` | Contract the FeatureFlagService must implement. Defines `isEnabled()`, `enable()`, `disable()`, `getAll()`. |

### 7.3 Core / Abstracts

| File | Responsibility |
|------|---------------|
| `AbstractModule.php` | Base class for module registration. |
| `AbstractRepository.php` | Base repository. Holds `$wpdb` reference. All module repositories extend this. |
| `AbstractService.php` | Base service. Holds common utilities. All module services extend this. |
| `AbstractController.php` | Base REST controller. Handles response formatting. All module controllers extend this. |
| `AbstractMigration.php` | Base migration. Provides `up()` and `down()` contract. All migration classes extend this. |

### 7.4 Core / Exceptions

| File | Responsibility |
|------|---------------|
| `PluginException.php` | Base exception for all plugin-thrown exceptions. |
| `NotFoundException.php` | Thrown when a requested resource does not exist. |
| `UnauthorizedException.php` | Thrown when a user lacks permission for the requested action. |
| `ValidationException.php` | Thrown when incoming data fails validation. |
| `DatabaseException.php` | Thrown when a database operation fails. |

### 7.5 Core / Helpers

| File | Responsibility |
|------|---------------|
| `DateHelper.php` | Date formatting and timezone utilities. |
| `SanitizeHelper.php` | Shared sanitization utilities beyond core WordPress functions. |
| `StringHelper.php` | String manipulation utilities. |
| `UrlHelper.php` | URL building and validation utilities. |

### 7.6 Infrastructure / Database

| File | Responsibility |
|------|---------------|
| `Migrations/CreateFeatureFlagsTable.php` | Creates the `zc_feature_flags` table. |
| `Migrations/CreateConversationsTable.php` | Creates the `zc_conversations` table. |
| `Migrations/CreateParticipantsTable.php` | Creates the `zc_participants` table. |
| `Migrations/CreateMessagesTable.php` | Creates the `zc_messages` table. |
| `Migrations/CreateAttachmentsTable.php` | Creates the `zc_attachments` table. |
| `Migrations/CreateReactionsTable.php` | Creates the `zc_reactions` table. |
| `Migrations/CreateNotificationsTable.php` | Creates the `zc_notifications` table. |
| `Migrations/CreateModerationLogsTable.php` | Creates the `zc_moderation_logs` table. |
| `Migrations/CreateAnalyticsEventsTable.php` | Creates the `zc_analytics_events` table. |
| `Migrations/AddArchivedAtToMessagesTable.php` | Adds `archived_at` column to `zc_messages`. |
| `Repositories/BaseRepository.php` | Shared base repository. Extended by `AbstractRepository`. |
| `QueryBuilders/ConversationQueryBuilder.php` | Fluent builder for complex conversation queries (search, filter, unread count). |
| `QueryBuilders/MessageQueryBuilder.php` | Fluent builder for complex message queries (pagination, reactions, lifecycle). |

### 7.7 Infrastructure / Cache

| File | Responsibility |
|------|---------------|
| `CacheManager.php` | Selects and coordinates the active cache driver. |
| `TransientCache.php` | WordPress transient-based cache driver. |
| `ObjectCache.php` | WordPress object cache driver. Used when persistent object cache is available. |

### 7.8 Infrastructure / Http

| File | Responsibility |
|------|---------------|
| `Controllers/RestController.php` | Base REST controller. Registers routes, applies middleware. |
| `Middleware/AuthMiddleware.php` | Verifies user is authenticated before request proceeds. |
| `Middleware/NonceMiddleware.php` | Verifies nonce on state-changing requests. |
| `Middleware/RateLimitMiddleware.php` | Enforces per-user and per-endpoint rate limits. |
| `Requests/BaseRequest.php` | Sanitizes and validates incoming request data. |
| `Responses/ApiResponse.php` | Standardized success response shape. |
| `Responses/ErrorResponse.php` | Standardized error response shape. |

### 7.9 Shared

| File | Responsibility |
|------|---------------|
| `DTOs/ConversationDTO.php` | Typed carrier for conversation data between layers. |
| `DTOs/MessageDTO.php` | Typed carrier for message data between layers. |
| `DTOs/ParticipantDTO.php` | Typed carrier for participant data between layers. |
| `DTOs/NotificationDTO.php` | Typed carrier for notification data between layers. |
| `Enums/ConversationStatus.php` | Pending Approval, Active, Reported. |
| `Enums/MessageStatus.php` | Sending, Delivered, Read, Failed. |
| `Enums/MessageLifecycleStatus.php` | Active, Archived, Deleted. |
| `Enums/ParticipantRole.php` | Owner, Member (role within a conversation). |
| `Enums/ParticipantType.php` | Buyer, Seller, Admin (type of the WordPress user). |
| `Enums/NotificationType.php` | NewMessage, ConversationRequest, ModerationAlert, etc. |
| `Enums/ModerationStatus.php` | Pending, Reviewed, Resolved, Dismissed. |
| `Events/EventDispatcher.php` | Central event dispatcher. Fires WordPress actions and notifies internal listeners from one place. |
| `Events/MessageSent.php` | Event fired after a message is successfully stored. |
| `Events/ConversationCreated.php` | Event fired after a new conversation is created. |
| `Events/ConversationClosed.php` | Event fired after a conversation is archived or deleted. |
| `Events/ParticipantJoined.php` | Event fired after a participant is added to a conversation. |
| `Traits/Hookable.php` | Provides `register_hooks()` helper for Hooks classes. |
| `Traits/Singleton.php` | Provides singleton pattern for classes that require it. |
| `Traits/HasTimestamps.php` | Provides `created_at` and `updated_at` management. |
| `Traits/Serializable.php` | Provides `to_array()` and `to_json()` methods. |
| `Traits/ChecksFeatureFlags.php` | Provides `isEnabled( string $flag )` helper to every Service. Use before executing any toggleable feature. |
| `ValueObjects/UserId.php` | Immutable typed wrapper for a WordPress user ID. |
| `ValueObjects/ConversationId.php` | Immutable typed wrapper for a conversation ID. |
| `ValueObjects/MessageId.php` | Immutable typed wrapper for a message ID. |

### 7.10 Api

| File | Responsibility |
|------|---------------|
| `Api/PhpApi.php` | Public PHP facade. The entry point for all third-party PHP integrations. Exposes a stable public API surface that calls internal Services. Third-party code must never call Services directly. |

---

## 8. Database Schema Plan

All table names are prefixed with the WordPress table prefix plus `zc_`.
Example: `wp_zc_conversations`.

### `zc_feature_flags`

| Column | Type | Notes |
|--------|------|-------|
| `id` | BIGINT UNSIGNED, AUTO_INCREMENT, PRIMARY KEY | |
| `flag_key` | VARCHAR(100), UNIQUE | Dot-notation slug. E.g. `message.reactions`, `surface.popup`. |
| `group` | VARCHAR(50) | Flag group. E.g. `surface`, `conversation`, `message`, `marketplace`, `parity`, `notification`, `moderation`, `realtime`. |
| `label` | VARCHAR(150) | Human-readable label shown in admin toggle UI. |
| `description` | TEXT | Explains what enabling this flag does. Shown as admin tooltip. |
| `is_enabled` | TINYINT(1) | Current state. Default defined per flag in its Definition class. |
| `is_locked` | TINYINT(1) | When 1, the flag cannot be toggled from the admin UI. Used for flags that depend on server infrastructure (e.g. WebSocket). |
| `updated_at` | DATETIME | Last time the flag state was changed. |

---

### `zc_conversations`

| Column | Type | Notes |
|--------|------|-------|
| `id` | BIGINT UNSIGNED, AUTO_INCREMENT, PRIMARY KEY | |
| `status` | ENUM('pending_approval', 'active', 'reported') | Default: `pending_approval` |
| `initiated_by` | BIGINT UNSIGNED | WordPress user ID of the user who started the conversation. FK to `wp_users`. |
| `context_type` | VARCHAR(50) | Optional. E.g. `order`, `product`. |
| `context_id` | BIGINT UNSIGNED | Optional. The WooCommerce order ID or product ID. |
| `is_pinned` | TINYINT(1) | Default: 0. |
| `last_message_at` | DATETIME | Updated on every new message. Used for sorting. |
| `created_at` | DATETIME | |
| `updated_at` | DATETIME | |

### `zc_participants`

| Column | Type | Notes |
|--------|------|-------|
| `id` | BIGINT UNSIGNED, AUTO_INCREMENT, PRIMARY KEY | |
| `conversation_id` | BIGINT UNSIGNED | FK to `zc_conversations`. |
| `user_id` | BIGINT UNSIGNED | FK to `wp_users`. |
| `participant_type` | ENUM('buyer', 'seller', 'admin') | |
| `role` | ENUM('owner', 'member') | |
| `last_read_at` | DATETIME | Used to calculate unread count. |
| `joined_at` | DATETIME | |

### `zc_messages`

| Column | Type | Notes |
|--------|------|-------|
| `id` | BIGINT UNSIGNED, AUTO_INCREMENT, PRIMARY KEY | |
| `conversation_id` | BIGINT UNSIGNED | FK to `zc_conversations`. |
| `sender_id` | BIGINT UNSIGNED | FK to `wp_users`. |
| `parent_id` | BIGINT UNSIGNED | Nullable. FK to `zc_messages`. Used for reply threading. |
| `body` | LONGTEXT | Message content. |
| `status` | ENUM('sending', 'delivered', 'read', 'failed') | |
| `lifecycle_status` | ENUM('active', 'archived', 'deleted') | Default: `active`. |
| `archived_at` | DATETIME | Nullable. Set when lifecycle_status becomes `archived`. |
| `deleted_at` | DATETIME | Nullable. Set when lifecycle_status becomes `deleted`. |
| `created_at` | DATETIME | |
| `updated_at` | DATETIME | |

### `zc_attachments`

| Column | Type | Notes |
|--------|------|-------|
| `id` | BIGINT UNSIGNED, AUTO_INCREMENT, PRIMARY KEY | |
| `message_id` | BIGINT UNSIGNED | FK to `zc_messages`. |
| `uploader_id` | BIGINT UNSIGNED | FK to `wp_users`. |
| `file_path` | VARCHAR(500) | Storage path relative to WP uploads directory. |
| `file_name` | VARCHAR(255) | Randomized filename as stored. |
| `mime_type` | VARCHAR(100) | Verified MIME type. |
| `file_size` | INT UNSIGNED | Size in bytes. |
| `width` | SMALLINT UNSIGNED | Nullable. Image width in pixels. |
| `height` | SMALLINT UNSIGNED | Nullable. Image height in pixels. |
| `created_at` | DATETIME | |

### `zc_reactions`

| Column | Type | Notes |
|--------|------|-------|
| `id` | BIGINT UNSIGNED, AUTO_INCREMENT, PRIMARY KEY | |
| `message_id` | BIGINT UNSIGNED | FK to `zc_messages`. |
| `user_id` | BIGINT UNSIGNED | FK to `wp_users`. |
| `emoji` | VARCHAR(10) | The emoji character. |
| `created_at` | DATETIME | |

Unique constraint on `(message_id, user_id, emoji)` — one reaction per emoji per user per message.

### `zc_notifications`

| Column | Type | Notes |
|--------|------|-------|
| `id` | BIGINT UNSIGNED, AUTO_INCREMENT, PRIMARY KEY | |
| `user_id` | BIGINT UNSIGNED | FK to `wp_users`. Recipient. |
| `type` | VARCHAR(100) | Notification type slug. |
| `payload` | JSON | Notification data. |
| `channel` | ENUM('email', 'push', 'browser', 'in_app') | |
| `is_read` | TINYINT(1) | Default: 0. |
| `sent_at` | DATETIME | Nullable. Set when delivery is attempted. |
| `read_at` | DATETIME | Nullable. Set when user reads the notification. |
| `created_at` | DATETIME | |

### `zc_moderation_logs`

| Column | Type | Notes |
|--------|------|-------|
| `id` | BIGINT UNSIGNED, AUTO_INCREMENT, PRIMARY KEY | |
| `conversation_id` | BIGINT UNSIGNED | FK to `zc_conversations`. |
| `reporter_id` | BIGINT UNSIGNED | Nullable. FK to `wp_users`. |
| `moderator_id` | BIGINT UNSIGNED | Nullable. FK to `wp_users`. Admin who acted. |
| `type` | VARCHAR(100) | E.g. `report`, `spam_detected`, `profanity_filtered`. |
| `status` | ENUM('pending', 'reviewed', 'resolved', 'dismissed') | |
| `notes` | TEXT | Nullable. Moderator notes. |
| `created_at` | DATETIME | |
| `updated_at` | DATETIME | |

### `zc_analytics_events`

| Column | Type | Notes |
|--------|------|-------|
| `id` | BIGINT UNSIGNED, AUTO_INCREMENT, PRIMARY KEY | |
| `user_id` | BIGINT UNSIGNED | Nullable. FK to `wp_users`. |
| `event` | VARCHAR(100) | Event slug. E.g. `message_sent`, `conversation_started`. |
| `payload` | JSON | Event metadata. |
| `created_at` | DATETIME | |

### `zc_audit_logs`

| Column | Type | Notes |
|--------|------|-------|
| `id` | BIGINT UNSIGNED, AUTO_INCREMENT, PRIMARY KEY | |
| `admin_id` | BIGINT UNSIGNED | FK to `wp_users`. The admin who performed the action. |
| `action` | VARCHAR(100) | E.g. `viewed_conversation`, `deleted_conversation`. |
| `target_type` | VARCHAR(50) | E.g. `conversation`, `message`. |
| `target_id` | BIGINT UNSIGNED | The ID of the affected record. |
| `ip_address` | VARCHAR(45) | IPv4 or IPv6. |
| `created_at` | DATETIME | |

---

## 9. API Contract

### REST API

Base URL: `/wp-json/zymarg-comm/v1/`

All endpoints require authentication unless noted. All state-changing endpoints
(POST, PUT, PATCH, DELETE) require a valid nonce header. All responses follow
the shape defined in `ApiResponse` and `ErrorResponse`.

| Group | Method | Endpoint | Description |
|-------|--------|----------|-------------|
| Conversations | GET | `/conversations` | List conversations for the current user. |
| Conversations | POST | `/conversations` | Create a new conversation. |
| Conversations | GET | `/conversations/{id}` | Get a single conversation. |
| Conversations | PATCH | `/conversations/{id}` | Archive, pin, or update status. |
| Conversations | DELETE | `/conversations/{id}` | Delete. Admin only. |
| Conversations | GET | `/conversations/search` | Search conversations. |
| Messages | GET | `/conversations/{id}/messages` | List messages in a conversation. |
| Messages | POST | `/conversations/{id}/messages` | Send a message. |
| Messages | PATCH | `/messages/{id}` | Edit a message. |
| Messages | DELETE | `/messages/{id}` | Delete a message. |
| Messages | POST | `/messages/{id}/react` | Add a reaction. |
| Messages | DELETE | `/messages/{id}/react` | Remove a reaction. |
| Attachments | POST | `/attachments` | Upload an attachment. |
| Attachments | GET | `/attachments/{id}` | Retrieve attachment metadata. |
| Notifications | GET | `/notifications` | List notifications for the current user. |
| Notifications | PATCH | `/notifications/{id}/read` | Mark a notification as read. |
| Notifications | PATCH | `/notifications/read-all` | Mark all as read. |
| Realtime | GET | `/realtime/token` | Get realtime connection token. |
| Realtime | GET | `/realtime/poll` | Long-poll endpoint for fallback. |
| Moderation | POST | `/conversations/{id}/report` | Report a conversation. |
| Moderation | GET | `/moderation/queue` | Get moderation queue. Admin only. |
| Moderation | PATCH | `/moderation/{id}` | Act on a moderation case. Admin only. |
| Analytics | GET | `/analytics/admin` | Admin analytics dashboard data. Admin only. |
| Analytics | GET | `/analytics/me` | Current user's analytics data. |
| Settings | GET | `/settings` | Get global settings. Admin only. Credential fields return `is_configured` boolean — never the raw value. |
| Settings | PATCH | `/settings` | Update global settings. Admin only. |
| Settings | POST | `/settings/pusher/test` | Test Pusher connection using credentials in request body. Does not save. Returns `connected`, `failed`, or `partial`. Admin only. |
| Settings | GET | `/settings/me` | Get current user's preferences. |
| Settings | PATCH | `/settings/me` | Update current user's preferences. |
| Feature Flags | GET | `/flags` | Get all feature flags with current state. Admin only. |
| Feature Flags | PATCH | `/flags/{key}` | Enable or disable a flag. Admin only. |
| Feature Flags | GET | `/flags/public` | Get all enabled flags. Used by frontend JS to know what to render. No auth required. |
| Developer | GET | `/developer/webhooks` | List registered webhooks. |
| Developer | POST | `/developer/webhooks` | Register a webhook. |
| Developer | DELETE | `/developer/webhooks/{id}` | Delete a webhook. |
| Developer | GET | `/developer/keys` | List API keys. |
| Developer | POST | `/developer/keys` | Create an API key. |
| Developer | DELETE | `/developer/keys/{id}` | Revoke an API key. |

### Public PHP API (`app/Api/PhpApi.php`)

Third-party plugins must use these methods. Never call internal Services directly.

```php
ZymargComm::conversations()->getForUser( int $user_id ): array
ZymargComm::conversations()->create( array $args ): ConversationDTO
ZymargComm::messages()->send( int $conversation_id, int $sender_id, string $body ): MessageDTO
ZymargComm::messages()->getForConversation( int $conversation_id ): array
ZymargComm::notifications()->send( int $user_id, string $type, array $payload ): void
ZymargComm::events()->on( string $event, callable $callback ): void
ZymargComm::events()->fire( string $event, array $payload ): void
ZymargComm::flags()->isEnabled( string $flag_key ): bool
ZymargComm::flags()->enable( string $flag_key ): void
ZymargComm::flags()->disable( string $flag_key ): void
ZymargComm::flags()->getAll(): array
```

### JavaScript SDK (`assets/js/frontend/sdk.js`)

Exposed as `window.ZymargComm`. All methods return Promises.

```javascript
ZymargComm.conversations.list()
ZymargComm.conversations.open( conversationId )
ZymargComm.messages.send( conversationId, body )
ZymargComm.messages.react( messageId, emoji )
ZymargComm.realtime.connect()
ZymargComm.realtime.disconnect()
ZymargComm.realtime.on( event, callback )
ZymargComm.notifications.list()
ZymargComm.notifications.markRead( notificationId )
ZymargComm.flags.isEnabled( flagKey )
ZymargComm.flags.getAll()
```

---

## 10. Security Checklist

Run through this checklist when building or reviewing any feature.

### File upload validation

- [ ] Upload passes through `FileValidationService` before any other code runs.
- [ ] MIME type is verified using PHP's `finfo_file()`.
- [ ] File signature (magic bytes) is verified — not just the extension.
- [ ] Extension is checked against the allowlist: `.jpg`, `.jpeg`, `.png`, `.webp` only.
- [ ] SVG, GIF, PDF, DOCX, ZIP, EXE, and all other types are rejected.
- [ ] File size is within the configured maximum.
- [ ] Image dimensions are within the configured maximum.
- [ ] EXIF metadata is stripped via `ExifStripService` before storage.
- [ ] Storage filename is randomized by `ExifStripService`.
- [ ] File is stored via `FileStorageService` — never moved manually.
- [ ] Stored file cannot be executed directly.

### Permission checks

| Action | Buyer | Seller | Admin |
|--------|-------|--------|-------|
| Start conversation with seller | ✓ | — | ✓ |
| Start conversation with buyer | — | Requires admin approval if buyer has not started first | ✓ |
| Start conversation with admin | ✓ | ✓ | — |
| Seller → Seller | Configurable toggle | Configurable toggle | ✓ |
| Buyer → Buyer | Configurable toggle | Configurable toggle | ✓ |
| Read any conversation | — | — | ✓ (via AdminViewService only) |
| Delete any conversation | — | — | ✓ |
| Export any conversation | — | — | ✓ |
| Access moderation queue | — | — | ✓ |
| Access admin analytics | — | — | ✓ |

### Rate limiting

- [ ] All POST endpoints have rate limiting applied at `RateLimitMiddleware`.
- [ ] The attachment upload endpoint has a stricter rate limit than message sending.
- [ ] The realtime poll endpoint has rate limiting appropriate for polling frequency.

### Audit log requirements

Every admin action below must be recorded by `AuditLogService` without exception:

- Admin reads a conversation via `AdminViewService`.
- Admin deletes a conversation.
- Admin exports a conversation.
- Admin acts on a moderation case.
- Admin changes global settings.
- Admin creates or revokes an API key.

### Admin privacy contract

- Admin reads a conversation → no read receipt fires → no notification fires → no `last_read_at` updates for the admin.
- The audit log entry is the only record of the admin read.
- This contract is enforced by routing all admin reads through `AdminViewService` exclusively. Any code path that bypasses `AdminViewService` violates this contract.

---

## 11. Realtime Engine

### Driver contract

All realtime drivers implement `Core/Contracts/RealtimeDriverInterface.php`.

```php
interface RealtimeDriverInterface {
    public function publish( string $channel, string $event, array $payload ): void;
    public function subscribe( string $channel ): void;
    public function authenticate( int $user_id ): string;
    public function isConnected(): bool;
}
```

### Driver selection

The active driver is set via plugin settings. Calling code never references a
specific driver class. The `ServiceProvider` resolves the correct implementation
based on the configured driver key.

| Driver | Class | When to use |
|--------|-------|-------------|
| Pusher | `PusherService` | **Default.** Managed, reliable, works on any hosting. Requires Pusher account and credentials. |
| WebSocket | `WebSocketService` | Alternative. Best raw performance. Requires WebSocket-capable hosting. |
| SSE | `SseService` | Fallback. Works on standard PHP hosting. One-directional server push. |
| Polling | `PollingService` | Last-resort fallback. Works everywhere. Highest latency. |

Pusher is the default driver because it works on any hosting environment
without server-level configuration. WebSocket requires the host to support
persistent connections — not guaranteed on shared hosting.

To switch drivers, change the active driver key in plugin settings.
`ServiceProvider` resolves the correct implementation. No code changes required.

### Pusher configuration

Pusher is the default driver. The admin must enter four values in
Settings → Realtime → Pusher before the plugin can send realtime events.

| Field | Stored as | Returned to frontend |
|-------|-----------|---------------------|
| App ID | Encrypted via `EncryptionService` | `is_configured: true/false` |
| App Key | Encrypted via `EncryptionService` | `is_configured: true/false` |
| App Secret | Encrypted via `EncryptionService` | `is_configured: true/false` |
| Cluster | Plaintext (not sensitive) | Full value |

All four credential fields in the admin UI render as `type="password"`.
After paste and blur, the field stays masked for the session.
A "Reveal" toggle button sits beside each field for temporary reveal.
On page reload, all credential fields load empty and masked — the stored
value is never sent to the browser.

### Pusher test button

The "Test Connection" button appears on the Settings → Realtime → Pusher
admin panel next to the credential fields.

**Flow:**
```
Admin enters credentials → clicks "Test Connection"
    → Button disabled, spinner shown (AJAX — no page reload)
    → POST /zymarg-comm/v1/settings/pusher/test
        → body: { app_id, app_key, app_secret, cluster }
        → PusherService::testConnection( $credentials )
            → Attempts to authenticate with Pusher API
            → Attempts to publish a test event to a private test channel
            → Returns { status: 'connected'|'failed'|'partial', message: string }
    → Inline result shown beside the button:
        ✅ connected  → green  → "Pusher connected successfully."
        ❌ failed     → red    → "Connection failed. Check your credentials."
        ⚠️ partial    → amber  → "Connected but could not publish. Check channel permissions."
    → Button re-enabled after result
    → Result clears automatically after 10 seconds
```

**Rules:**
- The test never saves credentials. It only tests what is currently in the fields.
- If any credential field is empty, the button is disabled with tooltip:
  "Enter all Pusher credentials first."
- The secret field stays masked during the test. JS reads the field value
  and sends it in the request body — it is never displayed in the UI.
- The test endpoint is admin-only. Returns `403` for non-admins.
- Test result is never stored or logged.

### Service ownership

| Concern | Owner |
|---------|-------|
| Typing indicators | `PresenceService` |
| Online status | `PresenceService` |
| Connection monitoring | `PresenceService` |
| Automatic reconnect | `QueueService` |
| Missed event recovery | `QueueService` |
| Message queuing | `QueueService` |
| Pusher credential storage | `SettingsService` via `EncryptionService` |
| Pusher connection test | `PusherService::testConnection()` |

---

## 12. Build Phases

Follow this order. Do not begin a phase without completing the version bump
first. Do not begin a phase until the previous phase's acceptance criteria
are all met.

---

### Phase 1 — Foundation
**Bump to `v1.1.0` before writing any code.**

**Goal:** Plugin boots cleanly. Activates and deactivates without errors.
All database tables exist after activation. Nothing visible to users yet.

**Files to implement:**

```
zymarg-communication.php         (constants, autoloader, hooks — structure already exists)
app/Bootstrap/Plugin.php
app/Bootstrap/ServiceProvider.php
app/Bootstrap/HookLoader.php
app/Bootstrap/Installer.php
app/Bootstrap/Uninstaller.php
app/Bootstrap/Updater.php
app/Infrastructure/Database/Migrations/ (all migration classes)
uninstall.php
```

**Acceptance criteria:**

- [ ] Plugin appears in the WordPress plugin list with correct name `ZYMARG Communication` and version `v1.1.0`.
- [ ] Plugin activates with zero PHP errors or warnings.
- [ ] Plugin deactivates with zero PHP errors or warnings.
- [ ] All `zc_*` tables exist in the database after activation, including `zc_feature_flags`.
- [ ] All feature flags are written to `zc_feature_flags` with correct default values on activation.
- [ ] Plugin-owned pages (`/messages/`, `/vendor-messages/`) are created on activation.
- [ ] Plugin-owned pages are deleted on uninstall.
- [ ] All `zc_*` tables are removed after uninstall.
- [ ] No visible output on any frontend page.
- [ ] `Compatibility.php` runs without errors even when no supported third-party plugins are active.

---

### Phase 2 — Conversation & Message Core
**Bump to `v1.2.0` before writing any code.**

**Goal:** Full conversation and message lifecycle works via REST API.
No UI yet. Verified with a REST client (e.g. Postman).

**Files to implement:**

```
app/Modules/FeatureFlags/FlagRegistry.php
app/Modules/FeatureFlags/Services/FeatureFlagService.php
app/Modules/FeatureFlags/Services/FeatureFlagCacheService.php
app/Modules/FeatureFlags/Repositories/FeatureFlagRepository.php
app/Modules/FeatureFlags/Models/FeatureFlag.php
app/Modules/FeatureFlags/Controllers/FeatureFlagController.php
app/Modules/FeatureFlags/Hooks/FeatureFlagHooks.php
app/Modules/FeatureFlags/Definitions/SurfaceFlags.php
app/Modules/FeatureFlags/Definitions/ConversationFlags.php
app/Modules/FeatureFlags/Definitions/MessageFlags.php
app/Modules/FeatureFlags/Definitions/MarketplaceFlags.php
app/Modules/FeatureFlags/Definitions/ParityFlags.php
app/Modules/FeatureFlags/Definitions/NotificationFlags.php
app/Modules/FeatureFlags/Definitions/ModerationFlags.php
app/Modules/FeatureFlags/Definitions/RealtimeFlags.php
app/Shared/Traits/ChecksFeatureFlags.php
app/Modules/Conversation/Services/ConversationService.php
app/Modules/Conversation/Services/ConversationPermissionService.php
app/Modules/Conversation/Services/ParticipantService.php
app/Modules/Conversation/Repositories/ConversationRepository.php
app/Modules/Conversation/Repositories/ParticipantRepository.php
app/Modules/Conversation/Models/Conversation.php
app/Modules/Conversation/Models/Participant.php
app/Modules/Conversation/Controllers/ConversationController.php
app/Modules/Conversation/Hooks/ConversationHooks.php
app/Modules/Message/Services/MessageService.php
app/Modules/Message/Services/AttachmentService.php
app/Modules/Message/Services/ReactionService.php
app/Modules/Message/Services/ReadReceiptService.php
app/Modules/Message/Repositories/MessageRepository.php
app/Modules/Message/Repositories/AttachmentRepository.php
app/Modules/Message/Repositories/ReactionRepository.php
app/Modules/Message/Models/Message.php
app/Modules/Message/Models/Attachment.php
app/Modules/Message/Models/Reaction.php
app/Modules/Message/Controllers/MessageController.php
app/Modules/Message/Controllers/AttachmentController.php
app/Modules/Message/Hooks/MessageHooks.php
app/Shared/Events/EventDispatcher.php
app/Shared/Events/MessageSent.php
app/Shared/Events/ConversationCreated.php
app/Shared/Events/ConversationClosed.php
app/Shared/Events/ParticipantJoined.php
app/Infrastructure/Http/Middleware/AuthMiddleware.php
app/Infrastructure/Http/Middleware/NonceMiddleware.php
app/Infrastructure/Http/Middleware/RateLimitMiddleware.php
app/Infrastructure/Http/Requests/BaseRequest.php
app/Infrastructure/Http/Responses/ApiResponse.php
app/Infrastructure/Http/Responses/ErrorResponse.php
```

**Acceptance criteria:**

- [ ] `GET /flags` returns all feature flags with correct default values. Returns `403` for non-admins.
- [ ] `GET /flags/public` returns only enabled flag keys. No authentication required.
- [ ] `PATCH /flags/{key}` toggles a flag on or off. Returns `403` for non-admins.
- [ ] Disabling `message.reactions` via the API causes `ReactionService::addReaction()` to silently return without executing.
- [ ] Flag state is cached — database is not queried on every `isEnabled()` call within the same request.
- [ ] Cache is invalidated immediately after any flag write.
- [ ] `Compatibility.php` detects active third-party plugins and logs the selected injection method in debug mode.
- [ ] `POST /conversations` creates a conversation and returns the correct shape.
- [ ] `GET /conversations` returns a list for the authenticated user.
- [ ] `POST /conversations/{id}/messages` sends a message.
- [ ] `GET /conversations/{id}/messages` returns paginated messages.
- [ ] Conversation permission rules are enforced (Buyer→Seller allowed, Seller→Buyer pending approval).
- [ ] Read receipt is recorded when a participant reads a message.
- [ ] `MessageSent` event fires after every successfully stored message.
- [ ] All endpoints return `401` for unauthenticated requests.
- [ ] Rate limiting returns `429` when exceeded.

---

### Phase 3 — Realtime Engine
**Bump to `v1.3.0` before writing any code.**

**Goal:** Realtime connection works. Typing indicators and online status
are functional. Driver is swappable via configuration without code changes.

**Files to implement:**

```
app/Core/Contracts/RealtimeDriverInterface.php
app/Modules/Realtime/Services/WebSocketService.php
app/Modules/Realtime/Services/SseService.php
app/Modules/Realtime/Services/PusherService.php
app/Modules/Realtime/Services/PollingService.php
app/Modules/Realtime/Services/PresenceService.php
app/Modules/Realtime/Services/QueueService.php
app/Modules/Realtime/Repositories/RealtimeRepository.php
app/Modules/Realtime/Models/RealtimeEvent.php
app/Modules/Realtime/Controllers/RealtimeController.php
app/Modules/Realtime/Hooks/RealtimeHooks.php
assets/js/frontend/realtime.js
```

**Acceptance criteria:**

- [ ] Pusher is the active driver with no configuration change — it is on by default.
- [ ] Admin sidebar menu label is exactly `Communication` — not `ZYMARG Communication`.
- [ ] Switching the driver config key (pusher / websocket / sse / polling) changes the active driver with no code changes.
- [ ] A new message sent via REST is pushed to the recipient's open client within 2 seconds using Pusher.
- [ ] Typing indicator fires when a user is typing and clears when they stop.
- [ ] Online status is accurate for connected users.
- [ ] SSE driver works on a standard PHP host when enabled as fallback.
- [ ] Polling fallback fires at the configured interval when enabled as last-resort fallback.
- [ ] `QueueService` replays missed events on reconnection.

---

### Phase 4 — Marketplace Surfaces
**Bump to `v1.4.0` before writing any code.**

**Goal:** All three surfaces render correctly and consume Phase 2 and Phase 3
APIs. Product sharing and order chat are functional.

**Files to implement:**

```
app/Modules/Marketplace/Services/StorePopupService.php
app/Modules/Marketplace/Services/VendorInboxService.php
app/Modules/Marketplace/Services/BuyerInboxService.php
app/Modules/Marketplace/Services/ProductSharingService.php
app/Modules/Marketplace/Services/OrderChatService.php
app/Modules/Marketplace/Repositories/MarketplaceRepository.php
app/Modules/Marketplace/Models/MarketplaceContext.php
app/Modules/Marketplace/Models/ProductCard.php
app/Modules/Marketplace/Controllers/MarketplaceController.php
app/Modules/Marketplace/Hooks/MarketplaceHooks.php
assets/js/frontend/communication.js
assets/css/frontend/communication.css
```

**Acceptance criteria:**

- [ ] Store page chat popup appears as a messenger-style floating widget.
- [ ] Popup auto-appears when the buyer receives a new message on the store page.
- [ ] Popup does not load assets or fire any network request on pages where it is inactive.
- [ ] `wp_footer` is the injection mechanism — no other hook or direct template edit is used.
- [ ] `[zymarg_comm_buyer_inbox]` shortcode renders the full buyer inbox on `/messages/`.
- [ ] `[zymarg_comm_vendor_inbox]` shortcode renders the full vendor inbox on `/vendor-messages/`.
- [ ] `[zymarg_comm_unread_count]` shortcode renders the correct unread badge count.
- [ ] `Compatibility.php` correctly detects the active vendor plugin and hooks into it.
- [ ] Vendor dashboard inbox renders all conversations for the vendor.
- [ ] Buyer account inbox renders all conversations for the buyer.
- [ ] Buyer chatbox and seller chatbox use the same single component with mirrored data.
- [ ] All parity flags are respected — disabling `parity.response_rate` hides response rate on both sides.
- [ ] Product card sharing sends a structured product card in chat.
- [ ] Order chat is accessible from the WooCommerce order page and shows the correct order context.
- [ ] All three surfaces are responsive on mobile.
- [ ] All UI actions call the REST API — no direct PHP calls from JS.
- [ ] Disabling `surface.popup` flag hides the popup on all pages immediately.

---

### Phase 5 — Notifications
**Bump to `v1.5.0` before writing any code.**

**Goal:** All notification channels deliver correctly. Quiet hours are
enforced. Per-user preferences are respected.

**Files to implement:**

```
app/Modules/Notification/Services/NotificationService.php
app/Modules/Notification/Services/EmailNotificationService.php
app/Modules/Notification/Services/PushNotificationService.php
app/Modules/Notification/Services/BrowserNotificationService.php
app/Modules/Notification/Services/NotificationPreferenceService.php
app/Modules/Notification/Repositories/NotificationRepository.php
app/Modules/Notification/Models/Notification.php
app/Modules/Notification/Controllers/NotificationController.php
app/Modules/Notification/Hooks/NotificationHooks.php
```

**Acceptance criteria:**

- [ ] Email notification is sent when a new message arrives and the recipient is offline.
- [ ] Browser push notification is sent when the browser notification channel is enabled.
- [ ] Mobile push notification is sent when the mobile channel is enabled.
- [ ] No notification is sent during the user's configured quiet hours.
- [ ] User can disable individual channels from their preferences.
- [ ] `GET /notifications` returns the notification list for the current user.
- [ ] `PATCH /notifications/{id}/read` marks a notification as read.

---

### Phase 6 — Moderation & Security
**Bump to `v1.6.0` before writing any code.**

**Goal:** Upload pipeline is secure. Moderation tools are functional.
Admin stealth reads are isolated and audited.

**Files to implement:**

```
app/Modules/Security/Services/FileValidationService.php
app/Modules/Security/Services/ExifStripService.php
app/Modules/Security/Services/FileStorageService.php
app/Modules/Security/Services/EncryptionService.php
app/Modules/Security/Services/AuditLogService.php
app/Modules/Security/Repositories/SecurityRepository.php
app/Modules/Security/Models/AuditLog.php
app/Modules/Security/Controllers/SecurityController.php
app/Modules/Security/Hooks/SecurityHooks.php
app/Modules/Moderation/Services/ModerationService.php
app/Modules/Moderation/Services/SpamFilterService.php
app/Modules/Moderation/Services/BlocklistService.php
app/Modules/Moderation/Services/AdminViewService.php
app/Modules/Moderation/Repositories/ModerationRepository.php
app/Modules/Moderation/Models/ModerationLog.php
app/Modules/Moderation/Controllers/ModerationController.php
app/Modules/Moderation/Hooks/ModerationHooks.php
```

**Acceptance criteria:**

- [ ] Uploading a JPG, JPEG, PNG, or WebP file succeeds.
- [ ] Uploading an SVG, GIF, PDF, or any other type is rejected with a clear error.
- [ ] Uploading a renamed executable (e.g. `shell.php` renamed to `image.jpg`) is rejected by magic byte check.
- [ ] EXIF metadata is absent from all stored images.
- [ ] Stored filenames are randomized — no original filenames on disk.
- [ ] Admin reads a conversation via `AdminViewService` — no read receipt is recorded for any participant.
- [ ] Admin read is recorded in `zc_audit_logs`.
- [ ] Reporting a conversation changes its status to `reported`.
- [ ] Spam-detected message is flagged before storage.
- [ ] Blocklisted word in a message body is caught before storage.
- [ ] Pusher App Secret field renders masked on load and stays masked after paste and blur.
- [ ] "Reveal" toggle button temporarily shows Pusher secret and re-masks on second click.
- [ ] `GET /settings` returns `is_configured: true` for saved Pusher credentials — never the raw values.
- [ ] Pusher credentials are stored encrypted in the database — plaintext is never written.
- [ ] `POST /settings/pusher/test` returns `connected`, `failed`, or `partial` with a message.
- [ ] Test button shows spinner while pending, inline result after response, clears after 10 seconds.
- [ ] Test button is disabled when any Pusher credential field is empty.
- [ ] Test endpoint returns `403` for non-admin users.
- [ ] All admin settings interactions (save, toggle, test) happen via AJAX with no page reload.

---

### Phase 7 — Analytics & Administration
**Bump to `v1.7.0` before writing any code.**

**Goal:** Admin and user analytics dashboards are functional. Conversation
export and print work.

**Files to implement:**

```
app/Modules/Analytics/Services/AnalyticsService.php
app/Modules/Analytics/Services/AdminReportService.php
app/Modules/Analytics/Services/UserReportService.php
app/Modules/Analytics/Services/ReportService.php
app/Modules/Analytics/Repositories/AnalyticsRepository.php
app/Modules/Analytics/Models/AnalyticsEvent.php
app/Modules/Analytics/Controllers/AnalyticsController.php
app/Modules/Analytics/Hooks/AnalyticsHooks.php
app/Modules/Conversation/Services/ConversationExportService.php
```

**Acceptance criteria:**

- [ ] `GET /analytics/admin` returns platform-wide conversation volume, response rates, and unread counts. Returns `403` for non-admins.
- [ ] `GET /analytics/me` returns the current user's personal metrics.
- [ ] Admin can export a conversation to CSV.
- [ ] Admin can generate a print-ready conversation view.
- [ ] Analytics events are recorded for `message_sent`, `conversation_started`, `conversation_reported`.

---

### Phase 8 — Message Lifecycle
**Bump to `v1.8.0` before writing any code.**

**Goal:** Messages are automatically archived at 90 days and permanently
deleted at 365 days. Conversations are never affected.

**Files to implement:**

```
app/Bootstrap/Scheduler.php
app/Modules/Message/Services/MessageLifecycleService.php
```

**Acceptance criteria:**

- [ ] WP-Cron job is registered on plugin activation.
- [ ] Messages with `created_at` older than 90 days are set to `lifecycle_status = archived` and `archived_at` is recorded.
- [ ] Messages with `archived_at` older than 365 days are set to `lifecycle_status = deleted` and `deleted_at` is recorded.
- [ ] Conversation records are never touched by the lifecycle job.
- [ ] Active messages are never archived or deleted by the job.
- [ ] Job runs without PHP errors when the messages table is empty.

---

### Phase 9 — Developer Platform
**Bump to `v1.9.0` before writing any code.**

**Goal:** Public PHP API, JS SDK, webhook dispatch, API key management,
and extension registration are all functional and documented.

**Files to implement:**

```
app/Api/PhpApi.php
app/Modules/Developer/Services/WebhookService.php
app/Modules/Developer/Services/ApiKeyService.php
app/Modules/Developer/Services/ExtensionService.php
app/Modules/Developer/Repositories/DeveloperRepository.php
app/Modules/Developer/Models/Webhook.php
app/Modules/Developer/Controllers/DeveloperController.php
app/Modules/Developer/Hooks/DeveloperHooks.php
assets/js/frontend/sdk.js
```

**Acceptance criteria:**

- [ ] `ZymargComm::messages()->send()` sends a message from PHP without calling any Service class directly.
- [ ] `ZymargComm::events()->on()` registers a listener that fires when the matching event occurs.
- [ ] `window.ZymargComm.messages.send()` sends a message via the JS SDK and returns a Promise.
- [ ] A registered webhook receives a POST request when a `message_sent` event fires.
- [ ] An invalid API key is rejected with `401`.
- [ ] A revoked API key is rejected with `401`.
- [ ] A third-party plugin can register an extension via `ExtensionService`.

---

### Phase 10 — Help Center & i18n
**Bump to `v1.10.0` before writing any code.**

**Goal:** Built-in help page is complete with all documentation sections.
All user-facing strings are translatable. Bangla translation file is scaffolded.

**Files to implement:**

```
app/Modules/HelpCenter/Services/HelpCenterService.php
app/Modules/HelpCenter/Services/DocumentationService.php
app/Modules/HelpCenter/Services/ChangelogService.php
app/Modules/HelpCenter/Services/FaqService.php
app/Modules/HelpCenter/Repositories/HelpCenterRepository.php
app/Modules/HelpCenter/Models/HelpArticle.php
app/Modules/HelpCenter/Controllers/HelpCenterController.php
app/Modules/HelpCenter/Hooks/HelpCenterHooks.php
docs/api/                        (REST API, PHP API, JS API, hooks reference, SDK docs)
docs/guides/                     (user guide, admin guide, mobile integration guide)
languages/zymarg-communication-bn_BD.po
```

**Acceptance criteria:**

- [ ] Help page renders with all sections: User Guide, Admin Guide, REST API Docs, PHP API Docs, JS API Docs, Hooks Reference, SDK Docs, Mobile Integration Guide, Troubleshooting, Changelog.
- [ ] Changelog section correctly reads and displays from `readme.txt`.
- [ ] All user-facing strings are wrapped in `__( '', 'zymarg-communication' )`.
- [ ] `.pot` file can be generated with WP-CLI without errors.
- [ ] `zymarg-communication-bn_BD.po` file is present and structured correctly.

---

### Phase 11 — QA & Hardening
**Bump to `v1.11.0` before writing any code.**

**Goal:** All tests pass. Security checklist signed off. Accessibility and
performance audited. No debug code remains. Plugin is production-ready.

**Tasks:**

- [ ] Write unit tests for all Service classes in `tests/Unit/`.
- [ ] Write integration tests for all REST endpoints in `tests/Integration/`.
- [ ] Run the full Security Checklist from Section 10 against the live plugin.
- [ ] Accessibility audit: semantic HTML, keyboard navigation, ARIA, focus states, heading hierarchy, alt text.
- [ ] Performance audit: no N+1 queries, all heavy queries cached, no unbounded loops.
- [ ] Responsive check: all three surfaces verified on mobile, tablet, and desktop.
- [ ] Search all files for `console.log`, `var_dump`, `print_r`, `error_log` — remove every occurrence.
- [ ] Verify all strings are translatable.
- [ ] Run PHPStan at level 5 with zero errors.
- [ ] Run PHPCS WordPress standard with zero errors.
- [ ] Final packaging checklist (Section 15) completed.

---

## 13. Injection Strategy & Third-Party Compatibility

> ZYMARG Communication is fully decoupled from every other plugin.
> It does not reach into other plugins. Other plugins connect to it.
> If the buyer plugin or vendor plugin changes tomorrow, zero lines of
> code change inside ZYMARG Communication.

### 13.1 The Decoupling Principle

This plugin exposes its functionality through four standard mechanisms:

1. **WordPress action hooks** — other plugins call `do_action()` at their injection points
2. **Shortcodes** — any page or template can place `[zymarg_comm_*]`
3. **Public PHP API** — `PhpApi.php` for PHP integrations
4. **REST API + JS SDK** — for JavaScript and mobile integrations

The communication plugin registers itself into these mechanisms. It never
calls functions, hooks, or classes from another plugin directly — except
inside `Bootstrap/Compatibility.php`, which is the one permitted exception.

### 13.2 Compatibility.php — The Bridge File

`app/Bootstrap/Compatibility.php` is the **only file** in this plugin that
is permitted to reference external plugin names, functions, or classes.

It runs after `plugins_loaded` and follows this detection order for each surface:

```
For each surface (popup, buyer inbox, vendor inbox):
    1. Detect which third-party plugin manages this surface
    2. If that plugin exposes a known action hook → register into it
    3. If no hook is available → register a shortcode fallback
    4. Log which method was selected (debug mode only)
```

No other file may check `class_exists('Dokan')` or `function_exists('wcfm_*')`.
All such checks live exclusively in `Compatibility.php`.

### 13.3 Plugin-Owned Pages

On activation, `PageRegistrar` creates these WordPress pages:

| Page | Slug | Shortcode | Surface |
|------|------|-----------|---------|
| Messages | `/messages/` | `[zymarg_comm_buyer_inbox]` | Buyer full inbox |
| Vendor Messages | `/vendor-messages/` | `[zymarg_comm_vendor_inbox]` | Vendor full inbox |

These pages are owned and managed entirely by this plugin. Their IDs are
stored in a plugin option. On uninstall, they are permanently deleted.

The buyer plugin and vendor plugin only need to **link to these URLs**.
That is the only integration required from them.

### 13.4 Registered Shortcodes

All shortcodes are registered in `Bootstrap/ShortcodeRegistrar.php` only.

| Shortcode | Renders | Surface |
|-----------|---------|---------|
| `[zymarg_comm_buyer_inbox]` | Full buyer inbox | Buyer messages page |
| `[zymarg_comm_vendor_inbox]` | Full vendor inbox | Vendor messages page |
| `[zymarg_comm_popup]` | Floating chat popup | Any page |
| `[zymarg_comm_chat conversation_id="123"]` | Single conversation thread | Embeddable anywhere |
| `[zymarg_comm_unread_count]` | Unread message badge count | Any page (nav, header) |

### 13.5 Store Page Popup Injection

The floating chat popup is injected via the `wp_footer` WordPress core hook.
This hook fires on every page on every WordPress site regardless of theme
or active plugins. Zero dependency on any third-party plugin.

```
wp_footer fires
    → StorePopupService::renderPopupContainer()
        → outputs a hidden <div id="zymarg-comm-popup-root"></div>
        → outputs localised JS data (current user, store context, enabled flags)
    → realtime.js detects page context
        → is this a vendor store page? (checks URL and page meta)
        → is the popup flag enabled?
        → is the user a buyer?
        → if all true → activates the popup component
        → if false → popup container stays hidden, no network requests made
```

The popup never loads assets or makes network requests on pages where it
is not needed.

### 13.6 Injection Fallback Priority

For each surface, `Compatibility.php` tries injection methods in this order:

```
Priority 1 — Known hook detected (cleanest, no page needed)
    Example: Dokan's do_action('dokan_dashboard_content_inside_before')
    Example: WCFM's do_action('wcfm_dashboard_before_content')

Priority 2 — Generic hook detected (works with any plugin that has it)
    Example: do_action('woocommerce_account_content')
    Example: do_action('woocommerce_after_single_vendor')

Priority 3 — Shortcode on plugin-owned page (universal fallback)
    The plugin-owned page at /messages/ or /vendor-messages/ always exists.
    Links from other plugins point to these URLs.
    No hook integration required.
```

Priority 3 always works. Priorities 1 and 2 are enhancements when available.

---

## 14. UI Parity Rules

> Whatever the seller can see or do in the chat interface, the buyer
> can see or do an equivalent. Neither side gets a richer experience
> than the other. Parity is enforced at the component level, not just
> at the data level.

### 14.1 The Parity Principle

UI parity means structural equality, not identical data. The seller sees
information about the buyer. The buyer sees equivalent information about
the seller. The layout, the controls, the visual weight — all identical.

| Seller sees about buyer | Buyer sees about seller |
|-------------------------|------------------------|
| Buyer display name | Seller / store name |
| Buyer avatar | Seller avatar |
| Buyer last active | Seller last active |
| Buyer response rate | Seller response rate |
| Number of orders placed | Total sales count |
| Buyer account join date | Store opening date |
| Order context (if order chat) | Order context (if order chat) |

### 14.2 Parity Flags

Every parity item has a corresponding flag in `Definitions/ParityFlags.php`.
Parity flags **always apply to both sides simultaneously**. There is no flag
that shows something to the seller but hides the equivalent from the buyer,
or vice versa. If you enable seller response rate visibility, buyer response
rate visibility is automatically enabled too.

| Flag Key | What it controls | Default |
|----------|-----------------|---------|
| `parity.response_rate` | Response rate shown on both sides | on |
| `parity.last_active` | Last active timestamp shown on both sides | on |
| `parity.avatar` | Avatar shown on both sides | on |
| `parity.profile_info` | Store info / buyer profile shown on both sides | on |
| `parity.join_date` | Join date / store open date shown on both sides | off |
| `parity.order_count` | Order count / sales count shown on both sides | off |

### 14.3 Asymmetric Features

Some features are legitimately asymmetric by nature. These are not parity
violations — they reflect the different roles in the marketplace.

| Feature | Seller only | Buyer only | Reason |
|---------|-------------|------------|--------|
| Initiate conversation without prior contact | Requires approval | Always allowed | Marketplace trust model |
| Order notes | ✓ | — | Seller operational tool |
| Moderation report of buyer | — | ✓ (report seller) | Both can report, different targets |

All asymmetric features must be explicitly listed here. Any new asymmetric
feature added in the future must be documented in this table and approved
before implementation.

### 14.4 Chatbox Component Parity

The chatbox is a single shared component. Role context is passed in as a
prop / data attribute. The component renders the correct side based on context.
There is no separate buyer chatbox and seller chatbox. There is one chatbox.

```
ZymargCommChatbox
    props: {
        viewer_role:     'buyer' | 'seller' | 'admin'
        viewer_id:       int
        conversation_id: int
        context_type:    'store' | 'order' | 'inbox' | null
        context_id:      int | null
        enabled_flags:   string[]   ← from /flags/public endpoint
    }
```

The component reads `enabled_flags` and shows or hides every control
accordingly. A seller and a buyer opening the same conversation see the
same layout with mirrored data and the same set of enabled controls.

---

## 15. Feature Flag System

> Every toggleable feature in this plugin is controlled by a feature flag.
> The flag is the gate. The admin panel is the switch. Nothing is hardcoded on.

### 15.1 How a Flag Check Works

Every Service method that executes a toggleable feature must follow this pattern:

```php
public function sendReaction( int $message_id, int $user_id, string $emoji ): void
{
    // 1. Check the flag first — always.
    if ( ! $this->isEnabled( 'message.reactions' ) ) {
        return; // Silent no-op. No exception. No error.
    }

    // 2. Feature logic here.
}
```

`isEnabled()` is provided by the `ChecksFeatureFlags` trait. It resolves
`FeatureFlagService` from the container and proxies the call. Results are
cached by `FeatureFlagCacheService` so the database is hit once per request,
not once per check.

### 15.2 Complete Flag Reference

#### Surface flags

| Flag Key | Label | Default | Notes |
|----------|-------|---------|-------|
| `surface.popup` | Store page chat popup | on | Disabling hides popup on all store pages |
| `surface.buyer_inbox` | Buyer inbox | on | Disabling hides the buyer inbox page |
| `surface.vendor_inbox` | Vendor inbox | on | Disabling hides the vendor inbox page |

#### Conversation flags

| Flag Key | Label | Default | Notes |
|----------|-------|---------|-------|
| `conversation.seller_initiate` | Seller can start conversations | on | When on, requires admin approval if buyer has not messaged first |
| `conversation.seller_seller` | Seller to seller messaging | off | |
| `conversation.buyer_buyer` | Buyer to buyer messaging | off | |
| `conversation.archive` | Archive conversations | on | |
| `conversation.pin` | Pin conversations | on | |
| `conversation.search` | Search conversations | on | |
| `conversation.filter` | Filter conversations | on | |

#### Message flags

| Flag Key | Label | Default | Notes |
|----------|-------|---------|-------|
| `message.attachments` | Image attachments | on | |
| `message.replies` | Reply to message | on | |
| `message.reactions` | Message reactions | on | |
| `message.read_receipts` | Read receipts | on | |
| `message.delivered_status` | Delivered status | on | |
| `message.typing_indicator` | Typing indicator | on | Requires realtime driver |
| `message.online_status` | Online status | on | Requires realtime driver |

#### Marketplace flags

| Flag Key | Label | Default | Notes |
|----------|-------|---------|-------|
| `marketplace.product_sharing` | Share products in chat | on | |
| `marketplace.category_sharing` | Share categories in chat | on | |
| `marketplace.store_link_sharing` | Share store links in chat | on | |
| `marketplace.order_chat` | Order chat | on | |
| `marketplace.order_timeline` | Order timeline in chat | off | |

#### Parity flags

| Flag Key | Label | Default | Notes |
|----------|-------|---------|-------|
| `parity.response_rate` | Response rate visibility | on | Applies to both sides |
| `parity.last_active` | Last active visibility | on | Applies to both sides |
| `parity.avatar` | Avatar visibility | on | Applies to both sides |
| `parity.profile_info` | Profile info visibility | on | Applies to both sides |
| `parity.join_date` | Join / open date visibility | off | Applies to both sides |
| `parity.order_count` | Order / sales count visibility | off | Applies to both sides |

#### Notification flags

| Flag Key | Label | Default | Notes |
|----------|-------|---------|-------|
| `notification.email` | Email notifications | on | |
| `notification.push` | Mobile push notifications | on | |
| `notification.browser` | Browser notifications | on | |
| `notification.quiet_hours` | Quiet hours | on | |

#### Moderation flags

| Flag Key | Label | Default | Notes |
|----------|-------|---------|-------|
| `moderation.spam_filter` | Spam detection | on | |
| `moderation.profanity_filter` | Profanity filter | off | Off by default — admin enables if needed |
| `moderation.reporting` | Conversation reporting | on | |

#### Realtime flags

| Flag Key | Label | Default | Notes |
|----------|-------|---------|-------|
| `realtime.pusher` | Pusher | **on** | Default driver. Requires Pusher credentials in Settings → Pusher. |
| `realtime.websocket` | WebSocket | off | Alternative driver. Requires WebSocket-capable hosting. |
| `realtime.sse` | Server-Sent Events fallback | off | Fallback driver. Enable if Pusher and WebSocket are unavailable. |
| `realtime.polling` | Long-polling fallback | off | Last-resort fallback. Enable only if all other drivers fail. |

### 15.3 Adding a New Flag

1. Decide which Definition file the flag belongs to.
2. Add the flag constant and its default to that Definition file.
3. Register it in `FlagRegistry.php`.
4. Add the flag key to the complete flag reference table above in this document.
5. Add `$this->isEnabled('your.flag')` as the first line of the Service method it gates.
6. Add the toggle to the admin Settings UI.
7. Bump the version (PATCH if no new feature, MINOR if new feature).

**A flag that is defined but not checked in code is useless.
A feature that executes without checking its flag violates this architecture.**

### 15.4 Flag State and the Frontend

On every page load where the chatbox renders, the JS SDK calls
`GET /flags/public` to receive the list of currently enabled flags.
This endpoint requires no authentication and returns only the flag keys
that are enabled — no labels, no descriptions, no admin-only data.

The chatbox component reads this list and shows or hides every control
before rendering. A user never sees a button for a disabled feature.
A disabled feature never makes a network request.

---

## 16. Design Tokens & Frontend Rules

> All visual values — colors, gradients, typography, spacing, radii, shadows,
> and animation durations — are defined in exactly two mirrored locations.
> **Never hard-code a hex, px, rem, or ms value anywhere else.**

### 16.1 The Two-File Rule

| Layer | File |
|-------|------|
| CSS | `assets/css/frontend/zymarg-comm-tokens.css` |
| PHP | `app/Core/Helpers/DesignTokens.php` |

If a token value changes, **both files must be updated in the same commit**
and the version must be bumped. A token that exists in one file but not the
other is a bug.

---

### 16.2 Color Tokens — Core Brand

All CSS variables use the `--zc-` prefix. All PHP constants use the
`ZC_COLOR_` prefix.

#### Primary palette

| CSS Variable | PHP Constant | Value | Usage |
|---|---|---|---|
| `--zc-color-primary` | `ZC_COLOR_PRIMARY` | `#6833EA` | CTAs, links, active states, primary buttons |
| `--zc-color-primary-deep` | `ZC_COLOR_PRIMARY_DEEP` | `#582A9F` | Hover states, pressed states, gradient end |
| `--zc-color-primary-fixed` | `ZC_COLOR_PRIMARY_FIXED` | `#ffd6fb` | Light tinted primary backgrounds |
| `--zc-color-primary-container` | `ZC_COLOR_PRIMARY_CONTAINER` | `#bd00d1` | Filled primary container surfaces |
| `--zc-color-primary-inverse` | `ZC_COLOR_PRIMARY_INVERSE` | `#fea9ff` | Primary color on dark surfaces |
| `--zc-color-on-primary-fixed` | `ZC_COLOR_ON_PRIMARY_FIXED` | `#36003d` | Text on primary-fixed backgrounds |

#### Secondary palette

| CSS Variable | PHP Constant | Value | Usage |
|---|---|---|---|
| `--zc-color-secondary` | `ZC_COLOR_SECONDARY` | `#505f76` | Secondary actions, secondary text elements |
| `--zc-color-secondary-container` | `ZC_COLOR_SECONDARY_CONTAINER` | `#d0e1fb` | Secondary container fills |

#### Surface & background

| CSS Variable | PHP Constant | Value | Usage |
|---|---|---|---|
| `--zc-color-surface` | `ZC_COLOR_SURFACE` | `#faf8ff` | Page and section backgrounds |
| `--zc-color-surface-container` | `ZC_COLOR_SURFACE_CONTAINER` | `#eaedff` | Card fills, input backgrounds |
| `--zc-color-surface-lowest` | `ZC_COLOR_SURFACE_LOWEST` | `#ffffff` | Modal backgrounds, floating panels |
| `--zc-color-surface-inverse` | `ZC_COLOR_SURFACE_INVERSE` | `#283044` | Dark surface (tooltips, toasts) |

#### Text

| CSS Variable | PHP Constant | Value | Usage |
|---|---|---|---|
| `--zc-color-text-body` | `ZC_COLOR_TEXT_BODY` | `#131b2e` | Primary body text |
| `--zc-color-text-muted` | `ZC_COLOR_TEXT_MUTED` | `#534152` | Secondary text, captions, placeholders |

#### Outline & border

| CSS Variable | PHP Constant | Value | Usage |
|---|---|---|---|
| `--zc-color-outline` | `ZC_COLOR_OUTLINE` | `#857183` | Input borders, dividers, separators |
| `--zc-color-outline-variant` | `ZC_COLOR_OUTLINE_VARIANT` | `#d8bfd3` | Subtle borders, hover borders |

#### Semantic states

| CSS Variable | PHP Constant | Value | Usage |
|---|---|---|---|
| `--zc-color-success` | `ZC_COLOR_SUCCESS` | `#1e7e34` | Delivered status, success messages |
| `--zc-color-warning` | `ZC_COLOR_WARNING` | `#856404` | Pending approval status, warnings |
| `--zc-color-danger` | `ZC_COLOR_DANGER` | `#721c24` | Errors, reported status, destructive actions |
| `--zc-color-info` | `ZC_COLOR_INFO` | `#0c5460` | Informational messages, tips |

---

### 16.3 Gradient Tokens

| CSS Variable | Value | Usage |
|---|---|---|
| `--zc-gradient-primary` | `135deg, #6833EA 0%, #582A9F 100%` | Primary buttons, active conversation headers |
| `--zc-gradient-brand` | `135deg, #9500a5 0%, #bd00d1 60%, #fea9ff 130%` | Hero accents, splash elements |
| `--zc-gradient-orb-top-left` | `radial-gradient, rgba(104,51,234,0.15), blur 60px` | Background decoration — top-left |
| `--zc-gradient-orb-bottom-right` | `radial-gradient, rgba(88,42,159,0.10), blur 80px` | Background decoration — bottom-right |

#### Background style

Every full-page surface in this plugin uses a white base with two blurred
radial gradient orbs:

```css
background-color: var(--zc-color-surface-lowest);

/* Top-left orb */
background-image: radial-gradient(
  circle at 0% 0%,
  rgba(104, 51, 234, 0.15) 0%,
  transparent 60%
);
filter: blur(60px);

/* Bottom-right orb */
background-image: radial-gradient(
  circle at 100% 100%,
  rgba(88, 42, 159, 0.10) 0%,
  transparent 60%
);
filter: blur(80px);
```

Do not deviate from this background pattern on any full-page surface.

---

### 16.4 Typography Tokens

Font family: **Inter Variable** only. No other font is permitted.

| CSS Variable | PHP Constant | Value | Usage |
|---|---|---|---|
| `--zc-font-family` | `ZC_FONT_FAMILY` | `'Inter Variable', Inter, sans-serif` | All text in the plugin |
| `--zc-font-size-xs` | `ZC_FONT_SIZE_XS` | `10px` | Labels, badges, timestamps |
| `--zc-font-size-sm` | `ZC_FONT_SIZE_SM` | `12px` | Captions, helper text |
| `--zc-font-size-base` | `ZC_FONT_SIZE_BASE` | `14px` | Body text, message content |
| `--zc-font-size-md` | `ZC_FONT_SIZE_MD` | `16px` | Subheadings, emphasized body |
| `--zc-font-size-lg` | `ZC_FONT_SIZE_LG` | `18px` | Section headings |
| `--zc-font-size-xl` | `ZC_FONT_SIZE_XL` | `22px` | Page headings |
| `--zc-font-size-2xl` | `ZC_FONT_SIZE_2XL` | `26px` | Hero headings |
| `--zc-font-size-3xl` | `ZC_FONT_SIZE_3XL` | `30px` | Display headings |
| `--zc-font-weight-medium` | `ZC_FONT_WEIGHT_MEDIUM` | `500` | Body, labels |
| `--zc-font-weight-semibold` | `ZC_FONT_WEIGHT_SEMIBOLD` | `600` | Subheadings, button labels |
| `--zc-font-weight-bold` | `ZC_FONT_WEIGHT_BOLD` | `700` | Headings |
| `--zc-font-weight-extrabold` | `ZC_FONT_WEIGHT_EXTRABOLD` | `800` | Display headings, hero text |
| `--zc-line-height-tight` | `ZC_LINE_HEIGHT_TIGHT` | `1.2` | Headings |
| `--zc-line-height-base` | `ZC_LINE_HEIGHT_BASE` | `1.5` | Body text |
| `--zc-line-height-relaxed` | `ZC_LINE_HEIGHT_RELAXED` | `1.75` | Long-form content |

Font weights below 500 and above 800 are not permitted.

---

### 16.5 Spacing Tokens

All spacing values follow an 8px base grid.

| CSS Variable | PHP Constant | Value | Usage |
|---|---|---|---|
| `--zc-space-1` | `ZC_SPACE_1` | `2px` | Micro gaps, icon padding |
| `--zc-space-2` | `ZC_SPACE_2` | `4px` | Tight internal padding |
| `--zc-space-3` | `ZC_SPACE_3` | `8px` | Small gaps, inline spacing |
| `--zc-space-4` | `ZC_SPACE_4` | `12px` | Input padding, small card gaps |
| `--zc-space-5` | `ZC_SPACE_5` | `16px` | Standard padding, card gaps |
| `--zc-space-6` | `ZC_SPACE_6` | `24px` | Section padding, large gaps |
| `--zc-space-7` | `ZC_SPACE_7` | `32px` | Container padding (desktop) |
| `--zc-space-8` | `ZC_SPACE_8` | `48px` | Large section spacing |
| `--zc-space-9` | `ZC_SPACE_9` | `64px` | Extra-large section spacing |

Never use an ad-hoc pixel value. If a required value is not in this scale,
add it to the token file and both files simultaneously.

---

### 16.6 Border Radius Tokens

| CSS Variable | PHP Constant | Value | Usage |
|---|---|---|---|
| `--zc-radius-sm` | `ZC_RADIUS_SM` | `6px` | Small elements, tooltips |
| `--zc-radius-md` | `ZC_RADIUS_MD` | `10px` | Badges, tags, small buttons |
| `--zc-radius-lg` | `ZC_RADIUS_LG` | `12px` | Buttons, interactive elements |
| `--zc-radius-xl` | `ZC_RADIUS_XL` | `14px` | Inputs, text areas |
| `--zc-radius-2xl` | `ZC_RADIUS_2XL` | `16px` | Cards, modals, panels |
| `--zc-radius-3xl` | `ZC_RADIUS_3XL` | `24px` | Large popup containers |
| `--zc-radius-full` | `ZC_RADIUS_FULL` | `9999px` | Avatars, pills, circular buttons |

Minimum radius on any interactive element is `--zc-radius-lg` (12px).
Minimum radius on any card or image is `--zc-radius-2xl` (16px).

---

### 16.7 Shadow Tokens

| CSS Variable | PHP Constant | Value | Usage |
|---|---|---|---|
| `--zc-shadow-sm` | `ZC_SHADOW_SM` | `0 1px 3px rgba(104,51,234,0.08)` | Subtle lift, input focus |
| `--zc-shadow-card` | `ZC_SHADOW_CARD` | `0 4px 16px rgba(104,51,234,0.10)` | Cards, conversation rows |
| `--zc-shadow-hover` | `ZC_SHADOW_HOVER` | `0 8px 24px rgba(104,51,234,0.16)` | Card hover state |
| `--zc-shadow-popup` | `ZC_SHADOW_POPUP` | `0 16px 48px rgba(104,51,234,0.20)` | Chat popup, modals, dropdowns |
| `--zc-shadow-focus` | `ZC_SHADOW_FOCUS` | `0 0 0 3px rgba(104,51,234,0.20)` | Focus ring on inputs and buttons |

Never use harsh drop-shadows. All shadows carry the purple brand tint.
Box-shadow values outside this table are not permitted.

---

### 16.8 Animation Tokens

| CSS Variable | PHP Constant | Value | Usage |
|---|---|---|---|
| `--zc-anim-fast` | `ZC_ANIM_FAST` | `100ms` | Micro-interactions, icon swaps |
| `--zc-anim-input` | `ZC_ANIM_INPUT` | `180ms` | Input focus transitions |
| `--zc-anim-standard` | `ZC_ANIM_STANDARD` | `300ms` | Card hover, popup open/close |
| `--zc-anim-slow` | `ZC_ANIM_SLOW` | `500ms` | Page-level transitions |
| `--zc-anim-easing` | `ZC_ANIM_EASING` | `ease-in-out` | Default easing for all transitions |

All `transition` declarations must use `var(--zc-anim-standard) var(--zc-anim-easing)`
unless a specific token is more appropriate. Never write a raw `ms` or `s` value.

---

### 16.9 Component Token Conventions

#### Buttons

```css
/* Primary button */
background: linear-gradient(var(--zc-gradient-primary));
color: var(--zc-color-surface-lowest);
border-radius: var(--zc-radius-lg);
padding: var(--zc-space-3) var(--zc-space-6);
font-weight: var(--zc-font-weight-semibold);
transition: box-shadow var(--zc-anim-standard) var(--zc-anim-easing);

/* Primary button — hover */
box-shadow: var(--zc-shadow-hover);
```

#### Inputs and text areas

```css
border: 1px solid var(--zc-color-outline);
border-radius: var(--zc-radius-xl);
padding: var(--zc-space-3) var(--zc-space-5);
font-family: var(--zc-font-family);
font-size: var(--zc-font-size-base);
transition: border-color var(--zc-anim-input) var(--zc-anim-easing),
            box-shadow  var(--zc-anim-input) var(--zc-anim-easing);

/* Focus */
border-color: var(--zc-color-primary);
box-shadow: var(--zc-shadow-focus);
outline: none;
```

#### Cards and conversation rows

```css
background: var(--zc-color-surface-lowest);
border-radius: var(--zc-radius-2xl);
box-shadow: var(--zc-shadow-card);
padding: var(--zc-space-5);
transition: box-shadow var(--zc-anim-standard) var(--zc-anim-easing),
            transform  var(--zc-anim-standard) var(--zc-anim-easing);

/* Hover */
box-shadow: var(--zc-shadow-hover);
transform: translateY(-2px);
```

#### Images

```css
border-radius: var(--zc-radius-2xl);
object-fit: cover;
transition: transform var(--zc-anim-standard) var(--zc-anim-easing);

/* Hover */
transform: scale(1.05);
```

---

### 16.10 Style Principles

Every template, component, and admin screen must follow these principles:

1. **Large white surfaces** — cards and panels feel open, never cramped.
2. **Soft purple-tinted shadows** — use the shadow token scale; never harsh drop-shadows.
3. **Large rounded corners** — minimum `--zc-radius-lg` on interactive elements, `--zc-radius-2xl` on cards.
4. **Purple gradient highlights** — use `--zc-gradient-primary` for primary actions and active states.
5. **Comfortable whitespace** — follow the spacing scale; never compress elements.
6. **Minimal layout** — no visual noise; every element earns its place.
7. **Premium appearance** — Inter Variable only; weights 500–800 only.
8. **Consistent spacing** — use `--zc-space-*` tokens; never ad-hoc pixel values.
9. **Smooth hover animations** — all transitions use `var(--zc-anim-standard) var(--zc-anim-easing)`.

---

### 16.11 CSS Class Prefix Rule

All CSS classes output by this plugin use the `zymarg-comm-` prefix.
This prevents conflicts with the active WordPress theme and other plugins.

```css
/* Correct */
.zymarg-comm-inbox { }
.zymarg-comm-message-bubble { }
.zymarg-comm-popup { }

/* Wrong — never do this */
.inbox { }
.message { }
.popup { }
```

---

### 16.12 Frontend Code Rules

- Vanilla JavaScript only on the frontend. No jQuery on the frontend.
- One responsibility per JS file.
- Use `data-*` attributes for PHP-to-JS data passing. No inline `onclick` handlers.
- No inline `<style>` blocks in HTML output.
- No inline `<script>` blocks in HTML output.
- All images use `loading="lazy"` with explicit `width` and `height` attributes.
- Enqueue all CSS and JS through WordPress — never with `<link>` or `<script>` tags in templates.

---

### 16.13 Responsive Breakpoints

| Breakpoint | Range | Container padding |
|------------|-------|-------------------|
| Mobile | up to 767px | `var(--zc-space-5)` (16px) |
| Tablet | 768px – 1023px | `var(--zc-space-6)` (24px) |
| Laptop | 1024px – 1279px | `var(--zc-space-6)` (24px) |
| Desktop | 1280px and above | `var(--zc-space-7)` (32px) |

Maximum container width: `1280px`.
All surface wrappers use a `.zymarg-comm-container` class that applies
max-width and responsive padding automatically.

---

### 16.14 Accessibility Requirements

- Semantic HTML throughout. Use `<button>`, `<nav>`, `<main>`, `<aside>` correctly.
- Keyboard navigation on all interactive elements.
- ARIA attributes where native semantics are insufficient.
- Visible focus states on all interactive elements using `var(--zc-shadow-focus)`.
- Correct heading hierarchy within each surface — never skip heading levels.
- Alt text on all images. Empty `alt=""` only on purely decorative images.
- Color contrast ratio minimum 4.5:1 for body text, 3:1 for large text.

---

## 17. Packaging Checklist

Run through this checklist before handing over or deploying any build.

- [ ] Version bumped in all four locations (plugin header, constant, `composer.json`, `readme.txt`).
- [ ] `readme.txt` changelog entry added for this version.
- [ ] No `console.log`, `var_dump`, `print_r`, or `error_log` in any file.
- [ ] PHPStan level 5 passes with zero errors.
- [ ] PHPCS WordPress standard passes with zero errors.
- [ ] All unit and integration tests pass.
- [ ] Zip named exactly: `zymarg-communication-v{X.X.X}.zip`
- [ ] Plugin folder inside the zip extracts as `zymarg-communication/` — never `zymarg-communication-v1.2.0/` or any versioned name.

---

## 18. What Not To Do

- Do not write any feature code before bumping the version for the current phase.
- Do not access `$wpdb` from any file outside a Repository class.
- Do not put business logic inside a Controller.
- Do not put query logic inside a Service — that belongs in a Repository.
- Do not call one module's Repository from a different module — use the Service.
- Do not create a feature that exists only in JavaScript with no REST endpoint.
- Do not route an admin read through the same code path as a participant read.
- Do not let an admin read trigger a read receipt or notification of any kind.
- Do not handle a raw uploaded file outside of `FileValidationService`.
- Do not trust a file extension alone — always verify MIME type and magic bytes.
- Do not allow SVG, GIF, PDF, or any file type outside the allowlist to be uploaded.
- Do not register a WP-Cron schedule outside of `Bootstrap/Scheduler.php`.
- Do not archive or delete messages from any code path outside `MessageLifecycleService`.
- Do not call a specific realtime driver class by name — always go through the interface.
- Do not put rate limiting logic inside a Service — it belongs in `RateLimitMiddleware`.
- Do not call `error_log()`, `var_dump()`, or `print_r()` in any production code.
- Do not use inline `<style>` or `<script>` blocks in HTML output.
- Do not use jQuery on the frontend.
- Do not hard-code any color, spacing, or visual value — use CSS variables.
- Do not version the plugin folder name.
- Do not ship a zip without completing the packaging checklist.
- Do not begin a new phase without completing the version bump first.
- Do not reference any external plugin name, class, or function outside `Bootstrap/Compatibility.php`.
- Do not create a separate chatbox component for buyer and another for seller — there is one chatbox component.
- Do not add a parity flag that applies to one side but not the other — parity flags always apply to both sides simultaneously.
- Do not add a new asymmetric feature without documenting it in Section 14.3 of this document first.
- Do not execute any toggleable feature without first calling `$this->isEnabled('flag.key')`.
- Do not define a flag that has no `isEnabled()` check in a Service method — a flag with no gate is meaningless.
- Do not call `add_shortcode()` anywhere except `Bootstrap/ShortcodeRegistrar.php`.
- Do not create plugin-owned WordPress pages anywhere except `Bootstrap/PageRegistrar.php`.
- Do not inject the chat popup via any mechanism other than the `wp_footer` hook.
- Do not make the chatbox load assets or fire network requests on pages where it is not active.
- Do not use `<form method="POST" action="">` in any admin template — all admin interactions are AJAX.
- Do not return a raw credential value (Pusher secret, API key, or any future credential) from any REST endpoint — return `is_configured: true/false` only.
- Do not render a credential field without masking (`type="password"`) and a "Reveal" toggle button.
- Do not save Pusher or any third-party credentials to the database without encrypting them first via `EncryptionService`.
- Do not register the admin sidebar menu with any label other than `Communication`.
- Do not set WebSocket or SSE as the default realtime driver — Pusher is always the default.
- Do not store or log the result of a Pusher test connection — test results are transient and UI-only.
- Do not enable the Pusher test button when any credential field is empty.

---

*ZYMARG Design System · ZYMARG Communication v1.0.0 · Single source of truth*
