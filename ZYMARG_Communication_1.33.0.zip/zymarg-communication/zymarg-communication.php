<?php
/**
 * Plugin Name:       ZYMARG Communication
 * Plugin URI:        https://zymarg.com
 * Description:       The unified messaging and communication layer for the ZYMARG marketplace ecosystem.
 * Version:           1.33.0
 * Requires at least: 6.0
 * Requires PHP:      8.1
 * Author:            ZYMARG Team
 * Author URI:        https://zymarg.com
 * License:           Proprietary
 * Text Domain:       zymarg-communication
 * Domain Path:       /languages
 *
 * @package ZymargCommunication
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ── Constants ─────────────────────────────────────────────────────────────────
define( 'ZYMARG_COMM_VERSION',     '1.33.0' );
define( 'ZYMARG_COMM_FILE',        __FILE__ );
define( 'ZYMARG_COMM_DIR',         plugin_dir_path( __FILE__ ) );
define( 'ZYMARG_COMM_URL',         plugin_dir_url( __FILE__ ) );
define( 'ZYMARG_COMM_BASENAME',    plugin_basename( __FILE__ ) );
define( 'ZYMARG_COMM_ASSETS_URL',  ZYMARG_COMM_URL  . 'assets/' );
define( 'ZYMARG_COMM_ASSETS_DIR',  ZYMARG_COMM_DIR  . 'assets/' );
define( 'ZYMARG_COMM_STORAGE_DIR', ZYMARG_COMM_DIR  . 'storage/' );
define( 'ZYMARG_COMM_MIN_PHP',     '8.1' );
define( 'ZYMARG_COMM_MIN_WP',      '6.0' );

// ── Composer autoloader (when available) ─────────────────────────────────────
if ( file_exists( ZYMARG_COMM_DIR . 'vendor/autoload.php' ) ) {
	require_once ZYMARG_COMM_DIR . 'vendor/autoload.php';
}

// ── PSR-4 fallback autoloader ────────────────────────────────────────────────
// Used when the plugin ships without `composer install`. Maps
// `ZymargCommunication\` to the `app/` directory.
spl_autoload_register( static function ( $class ) {
	$prefix   = 'ZymargCommunication\\';
	$base_dir = ZYMARG_COMM_DIR . 'app/';
	$len      = strlen( $prefix );
	if ( strncmp( $prefix, $class, $len ) !== 0 ) {
		return;
	}
	$relative = substr( $class, $len );
	$file     = $base_dir . str_replace( '\\', '/', $relative ) . '.php';
	if ( file_exists( $file ) ) {
		require_once $file;
	}
} );


// ── Public API alias ───────────────────────────────────────────────────────────────────────────────
// Register the root-namespaced `ZymargComm` alias so third-party plugins can
// call the public PHP API without a use statement.
if ( ! class_exists( 'ZymargComm' ) ) {
	class_alias( \ZymargCommunication\Api\PhpApi::class, 'ZymargComm' );
}

// ── Bootstrap ─────────────────────────────────────────────────────────────────
add_action( 'plugins_loaded', static function () {
	\ZymargCommunication\Bootstrap\Plugin::init();
} );

// ── Activation / Deactivation ─────────────────────────────────────────────────
register_activation_hook(   __FILE__, [ 'ZymargCommunication\\Bootstrap\\Installer', 'activate'   ] );
register_deactivation_hook( __FILE__, [ 'ZymargCommunication\\Bootstrap\\Installer', 'deactivate' ] );
