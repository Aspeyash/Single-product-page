<?php
/**
 * PHPUnit bootstrap for ZYMARG Communication tests.
 *
 * Runs before any test class is loaded. Defines the minimum WordPress
 * globals/functions our tests rely on so unit tests can execute without a
 * full WordPress test suite. Integration tests should be run under the WP
 * test scaffold (`wp scaffold plugin-tests zymarg-communication`) which
 * provides the real functions.
 *
 * @package ZymargCommunication
 */

if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/../' );
}
if ( ! defined( 'ZYMARG_COMM_TESTS' ) ) {
	define( 'ZYMARG_COMM_TESTS', true );
}

// Only shim WordPress helpers when the real ones are unavailable. When
// running under wp-phpunit these are provided by the WP test framework.
if ( ! function_exists( '__' ) ) {
	function __( $text, $domain = 'default' ) { unset( $domain ); return $text; }
}
if ( ! function_exists( '_e' ) ) {
	function _e( $text, $domain = 'default' ) { echo $text; }
}
if ( ! function_exists( 'esc_html' ) ) {
	function esc_html( $text ) { return htmlspecialchars( (string) $text, ENT_QUOTES ); }
}
if ( ! function_exists( 'esc_html__' ) ) {
	function esc_html__( $t, $d = 'default' ) { return esc_html( $t ); }
}
if ( ! function_exists( 'esc_attr' ) ) {
	function esc_attr( $text ) { return htmlspecialchars( (string) $text, ENT_QUOTES ); }
}
if ( ! function_exists( 'esc_attr__' ) ) {
	function esc_attr__( $t, $d = 'default' ) { return esc_attr( $t ); }
}
if ( ! function_exists( 'esc_url' ) ) {
	function esc_url( $u ) { return $u; }
}
if ( ! function_exists( 'esc_url_raw' ) ) {
	function esc_url_raw( $u ) { return $u; }
}
if ( ! function_exists( 'sanitize_text_field' ) ) {
	function sanitize_text_field( $t ) { return is_string( $t ) ? trim( strip_tags( $t ) ) : ''; }
}
if ( ! function_exists( 'sanitize_key' ) ) {
	function sanitize_key( $k ) { return strtolower( preg_replace( '/[^a-z0-9_\-]/i', '', (string) $k ) ); }
}
if ( ! function_exists( 'wp_json_encode' ) ) {
	function wp_json_encode( $data ) { return json_encode( $data ); }
}
if ( ! function_exists( 'wp_hash' ) ) {
	function wp_hash( $data ) { return hash( 'sha256', (string) $data . 'zc-test-salt' ); }
}
if ( ! function_exists( 'current_time' ) ) {
	function current_time( $type = 'mysql', $gmt = 0 ) { unset( $type, $gmt ); return gmdate( 'Y-m-d H:i:s' ); }
}
if ( ! function_exists( 'get_current_user_id' ) ) {
	function get_current_user_id() { return 0; }
}
if ( ! function_exists( 'get_option' ) ) {
	function get_option( $name, $default = false ) {
		global $zc_test_options;
		return array_key_exists( $name, (array) $zc_test_options ) ? $zc_test_options[ $name ] : $default;
	}
}
if ( ! function_exists( 'update_option' ) ) {
	function update_option( $name, $value, $autoload = null ) {
		global $zc_test_options;
		$zc_test_options[ $name ] = $value;
		return true;
	}
}
if ( ! function_exists( 'delete_option' ) ) {
	function delete_option( $name ) {
		global $zc_test_options;
		unset( $zc_test_options[ $name ] );
		return true;
	}
}
if ( ! function_exists( 'apply_filters' ) ) {
	function apply_filters( $tag, $value ) { return $value; }
}
if ( ! function_exists( 'do_action' ) ) {
	function do_action( $tag ) { unset( $tag ); }
}
if ( ! function_exists( 'add_action' ) ) {
	function add_action( $tag, $cb, $priority = 10, $args = 1 ) { unset( $tag, $cb, $priority, $args ); return true; }
}
if ( ! function_exists( 'add_filter' ) ) {
	function add_filter( $tag, $cb, $priority = 10, $args = 1 ) { unset( $tag, $cb, $priority, $args ); return true; }
}
if ( ! function_exists( 'wp_generate_password' ) ) {
	function wp_generate_password( $length = 12, $special = true ) {
		unset( $special );
		return bin2hex( random_bytes( max( 8, (int) ( $length / 2 ) ) ) );
	}
}

// PSR-4 fallback autoloader, mirroring the plugin's runtime autoloader.
if ( ! defined( 'ZYMARG_COMM_DIR' ) ) {
	define( 'ZYMARG_COMM_DIR', dirname( __DIR__ ) . '/' );
}
if ( ! defined( 'ZYMARG_COMM_FILE' ) ) {
	define( 'ZYMARG_COMM_FILE', ZYMARG_COMM_DIR . 'zymarg-communication.php' );
}
if ( ! defined( 'ZYMARG_COMM_VERSION' ) ) {
	define( 'ZYMARG_COMM_VERSION', '1.11.0' );
}
spl_autoload_register( static function ( $class ) {
	$prefix = 'ZymargCommunication\\';
	if ( 0 !== strncmp( $prefix, $class, strlen( $prefix ) ) ) {
		return;
	}
	$relative = substr( $class, strlen( $prefix ) );
	$file     = ZYMARG_COMM_DIR . 'app/' . str_replace( '\\', '/', $relative ) . '.php';
	if ( file_exists( $file ) ) {
		require_once $file;
	}
} );
