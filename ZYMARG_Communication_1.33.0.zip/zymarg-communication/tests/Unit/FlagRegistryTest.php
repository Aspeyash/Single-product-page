<?php
/**
 * Unit tests for FlagRegistry.
 *
 * Verifies every flag documented in Section 15.2 of CONTRIBUTING.md is
 * registered with the expected default. This is the guardrail described
 * in Section 15.3: a flag defined but not registered is meaningless.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Tests\Unit;

use PHPUnit\Framework\TestCase;
use ZymargCommunication\Modules\FeatureFlags\Definitions\FlagRegistry;

final class FlagRegistryTest extends TestCase {

	public function test_surface_flags_are_registered(): void {
		$flags = ( new FlagRegistry() )->all();
		foreach ( array( 'surface.popup', 'surface.buyer_inbox', 'surface.vendor_inbox' ) as $key ) {
			$this->assertArrayHasKey( $key, $flags, "$key must be registered" );
		}
	}

	public function test_realtime_default_is_pusher(): void {
		$flags = ( new FlagRegistry() )->all();
		$this->assertArrayHasKey( 'realtime.pusher', $flags );
		$this->assertTrue( (bool) ( $flags['realtime.pusher']['default'] ?? false ), 'Pusher is the default driver.' );
		if ( isset( $flags['realtime.websocket']['default'] ) ) {
			$this->assertFalse( (bool) $flags['realtime.websocket']['default'] );
		}
	}

	public function test_profanity_filter_is_off_by_default(): void {
		$flags = ( new FlagRegistry() )->all();
		$this->assertArrayHasKey( 'moderation.profanity_filter', $flags );
		$this->assertFalse( (bool) ( $flags['moderation.profanity_filter']['default'] ?? true ) );
	}
}
