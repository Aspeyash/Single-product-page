<?php
/**
 * Unit tests for FeatureFlagService.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Tests\Unit;

use PHPUnit\Framework\TestCase;
use ZymargCommunication\Modules\FeatureFlags\Definitions\FlagRegistry;
use ZymargCommunication\Modules\FeatureFlags\Repositories\FeatureFlagRepository;
use ZymargCommunication\Modules\FeatureFlags\Services\FeatureFlagCacheService;
use ZymargCommunication\Modules\FeatureFlags\Services\FeatureFlagService;

final class FeatureFlagServiceTest extends TestCase {

	protected function setUp(): void {
		parent::setUp();
		global $zc_test_options;
		$zc_test_options = array();
	}

	private function service(): FeatureFlagService {
		$repo  = new FeatureFlagRepository();
		$cache = new FeatureFlagCacheService();
		return new FeatureFlagService( $repo, new FlagRegistry(), $cache );
	}

	public function test_get_all_returns_registered_flags(): void {
		$flags = $this->service()->getAll();
		$this->assertIsArray( $flags );
		$this->assertNotEmpty( $flags, 'FlagRegistry should register default flags.' );
	}

	public function test_enable_and_disable_round_trip(): void {
		$svc = $this->service();
		$key = 'moderation.profanity_filter';

		$this->assertFalse( $svc->isEnabled( $key ), 'Profanity filter is off by default.' );
		$this->assertTrue( $svc->enable( $key ) );
		$this->assertTrue( $svc->isEnabled( $key ) );
		$this->assertTrue( $svc->disable( $key ) );
		$this->assertFalse( $svc->isEnabled( $key ) );
	}

	public function test_unknown_flag_is_not_enabled(): void {
		$this->assertFalse( $this->service()->isEnabled( 'does.not.exist' ) );
	}

	public function test_enabled_keys_excludes_disabled_flags(): void {
		$svc = $this->service();
		$svc->disable( 'surface.popup' );
		$this->assertNotContains( 'surface.popup', $svc->enabledKeys() );
	}
}
