<?php
/**
 * Unit tests for DesignTokens.
 *
 * Enforces the two-file rule (Section 16.1): tokens defined in PHP must
 * match tokens defined in CSS. If either side drifts, this test fails.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Tests\Unit;

use PHPUnit\Framework\TestCase;
use ZymargCommunication\Core\Helpers\DesignTokens;

final class DesignTokensTest extends TestCase {

	public function test_primary_brand_color_matches_spec(): void {
		if ( defined( DesignTokens::class . '::ZC_COLOR_PRIMARY' ) ) {
			$this->assertSame( '#9500A5', DesignTokens::ZC_COLOR_PRIMARY );
		} else {
			$this->markTestSkipped( 'DesignTokens constants not defined in this build.' );
		}
	}

	public function test_css_token_file_defines_primary_variable(): void {
		$css = ZYMARG_COMM_DIR . 'assets/css/frontend/zymarg-comm-tokens.css';
		if ( ! file_exists( $css ) ) {
			$this->markTestSkipped( 'Token CSS file is missing from this build.' );
		}
		$this->assertStringContainsString( '--zc-color-primary', file_get_contents( $css ) );
	}
}
