<?php
/**
 * Unit tests for ChangelogService.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Tests\Unit;

use PHPUnit\Framework\TestCase;
use ZymargCommunication\Modules\HelpCenter\Services\ChangelogService;

final class ChangelogServiceTest extends TestCase {

	public function test_entries_returns_readme_versions(): void {
		$svc     = new ChangelogService();
		$entries = $svc->entries( 20 );
		$this->assertIsArray( $entries );
		$this->assertNotEmpty( $entries, 'readme.txt must contain at least one changelog entry.' );
		$this->assertArrayHasKey( 'version', $entries[0] );
		$this->assertArrayHasKey( 'notes', $entries[0] );
	}

	public function test_latest_matches_first_entry(): void {
		$svc    = new ChangelogService();
		$latest = $svc->latest();
		$this->assertIsArray( $latest );
		$this->assertArrayHasKey( 'version', $latest );
		$this->assertMatchesRegularExpression( '/^\d+\.\d+\.\d+$/', (string) $latest['version'] );
	}
}
