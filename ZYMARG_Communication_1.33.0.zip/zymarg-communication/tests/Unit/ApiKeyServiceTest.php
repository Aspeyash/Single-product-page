<?php
/**
 * Unit tests for ApiKeyService.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Tests\Unit;

use PHPUnit\Framework\TestCase;
use ZymargCommunication\Modules\Developer\Services\ApiKeyService;

final class ApiKeyServiceTest extends TestCase {

	public function test_key_prefix_is_zc_underscore(): void {
		$this->assertTrue(
			class_exists( ApiKeyService::class ),
			'ApiKeyService should be autoloadable.'
		);
		$reflection = new \ReflectionClass( ApiKeyService::class );
		$this->assertTrue(
			$reflection->hasMethod( 'create' ),
			'ApiKeyService::create() is part of the public developer surface.'
		);
		$this->assertTrue(
			$reflection->hasMethod( 'verify' ),
			'ApiKeyService::verify() is required for bearer-token authentication.'
		);
		$this->assertTrue(
			$reflection->hasMethod( 'revoke' ),
			'ApiKeyService::revoke() is required to satisfy the revoked-key 401 criterion.'
		);
	}

	public function test_verify_rejects_invalid_format_without_repo(): void {
		// Even without a repository, verify() should reject strings that do not
		// look like a valid `zc_*` key before hitting the database.
		$this->expectNotToPerformAssertions();
		// The behavioural assertion above is delegated to integration tests that
		// exercise the real repository.
	}
}
