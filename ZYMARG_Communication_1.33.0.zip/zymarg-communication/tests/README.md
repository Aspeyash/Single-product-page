# ZYMARG Communication — Test Suite

This directory contains automated tests for the plugin.

```
tests/
├─ Unit/          Pure PHP unit tests. No WordPress runtime required.
├─ Integration/   REST + wiring tests. Run under the WordPress PHPUnit scaffold.
├─ Feature/       Full-stack behavioural tests. Optional.
├─ bootstrap.php  Shared PHPUnit bootstrap.
```

## Running the suite

```bash
# 1. Install dev dependencies
composer install

# 2. Unit tests only (fast, no WP required)
vendor/bin/phpunit --testsuite Unit

# 3. Full suite (requires the WordPress PHPUnit scaffold)
wp scaffold plugin-tests zymarg-communication
bash bin/install-wp-tests.sh wordpress_test root '' localhost latest
vendor/bin/phpunit
```

## Static analysis

```bash
vendor/bin/phpstan analyse   # phpstan.neon.dist, level 5
vendor/bin/phpcs             # phpcs.xml.dist, WordPress-Extra
```

## Coverage focus

- Every Service class in `app/Modules/**/Services/` has at least one Unit test.
- Every REST route registered under `zymarg-comm/v1` has at least one
  Integration test that verifies registration, auth policy, and 401 for
  invalid API keys.
- Feature flags round-trip (enable → isEnabled → disable) is verified
  against every category (surface, conversation, message, marketplace,
  parity, notification, moderation, realtime).
