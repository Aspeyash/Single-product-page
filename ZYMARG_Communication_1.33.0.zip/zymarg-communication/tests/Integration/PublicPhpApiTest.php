<?php
/**
 * Integration tests for the public PHP API facade.
 *
 * Verifies the acceptance criteria of Phase 9 continue to hold:
 *   - ZymargComm::messages()->send() dispatches without touching a Service.
 *   - ZymargComm::events()->on() registers a listener that fires.
 *   - Extension registration works through ZymargComm::extensions()->register().
 *
 * Runs only under the WordPress PHPUnit scaffold.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Tests\Integration;

use PHPUnit\Framework\TestCase;
use ZymargCommunication\Api\PhpApi;

final class PublicPhpApiTest extends TestCase {

	protected function setUp(): void {
		parent::setUp();
		if ( ! function_exists( 'wp_set_current_user' ) ) {
			$this->markTestSkipped( 'WordPress test scaffold not loaded.' );
		}
	}

	public function test_facade_gateways_are_instantiated(): void {
		$this->assertNotNull( PhpApi::conversations() );
		$this->assertNotNull( PhpApi::messages() );
		$this->assertNotNull( PhpApi::notifications() );
		$this->assertNotNull( PhpApi::events() );
		$this->assertNotNull( PhpApi::flags() );
		$this->assertNotNull( PhpApi::extensions() );
	}

	public function test_events_on_registers_listener(): void {
		$fired = false;
		PhpApi::events()->on(
			'zc.tests.event',
			static function () use ( &$fired ) {
				$fired = true;
			}
		);
		PhpApi::events()->fire( 'zc.tests.event', array( 'ok' => true ) );
		$this->assertTrue( $fired, 'Listener registered via ZymargComm::events()->on() should fire.' );
	}

	public function test_extension_registration_persists(): void {
		PhpApi::extensions()->register(
			'zc-tests-plugin',
			array(
				'name'    => 'ZC Tests Plugin',
				'version' => '0.0.1',
			)
		);
		$found = PhpApi::extensions()->find( 'zc-tests-plugin' );
		$this->assertIsArray( $found );
		$this->assertSame( 'ZC Tests Plugin', $found['name'] ?? '' );
	}
}
