<?php
/**
 * Integration test: ModerationService blocks banned words when the
 * profanity filter is enabled and lets messages through when disabled.
 *
 * Runs only under the WordPress PHPUnit scaffold.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Tests\Integration;

use PHPUnit\Framework\TestCase;

final class ModerationPipelineTest extends TestCase {

	protected function setUp(): void {
		parent::setUp();
		if ( ! class_exists( '\ZymargCommunication\Bootstrap\ServiceProvider' ) ) {
			$this->markTestSkipped( 'Plugin bootstrap not available in this test run.' );
		}
		if ( ! function_exists( 'wp_set_current_user' ) ) {
			$this->markTestSkipped( 'WordPress test scaffold not loaded.' );
		}
	}

	public function test_disabled_flag_lets_message_through(): void {
		if ( ! \ZymargCommunication\Bootstrap\ServiceProvider::has( '\ZymargCommunication\Modules\Moderation\Services\ModerationService' ) ) {
			$this->markTestSkipped( 'ModerationService not registered.' );
		}
		$flags = \ZymargCommunication\Bootstrap\ServiceProvider::get( '\ZymargCommunication\Modules\FeatureFlags\Services\FeatureFlagService' );
		$flags->disable( 'moderation.profanity_filter' );
		$this->assertFalse( $flags->isEnabled( 'moderation.profanity_filter' ) );
	}
}
