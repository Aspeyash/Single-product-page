<?php
/**
 * Integration smoke tests for the plugin's REST namespace.
 *
 * These tests are designed to run under the WordPress PHPUnit scaffold
 * (`wp scaffold plugin-tests zymarg-communication`). They boot WordPress,
 * activate the plugin, and hit each Controller through the REST server.
 *
 * When run against a bare unit-test bootstrap (without WordPress), every
 * test is skipped instead of failed.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Tests\Integration;

use PHPUnit\Framework\TestCase;

final class RestRoutesTest extends TestCase {

	protected function setUp(): void {
		parent::setUp();
		if ( ! function_exists( 'rest_get_server' ) ) {
			$this->markTestSkipped( 'WordPress test scaffold not loaded.' );
		}
	}

	public function test_conversations_route_is_registered(): void {
		$routes = rest_get_server()->get_routes();
		$this->assertArrayHasKey( '/zymarg-comm/v1/conversations', $routes );
	}

	public function test_messages_route_is_registered(): void {
		$routes = rest_get_server()->get_routes();
		$this->assertArrayHasKey( '/zymarg-comm/v1/conversations/(?P<id>\d+)/messages', $routes );
	}

	public function test_flags_public_endpoint_requires_no_authentication(): void {
		$request  = new \WP_REST_Request( 'GET', '/zymarg-comm/v1/flags/public' );
		$response = rest_get_server()->dispatch( $request );
		$this->assertSame( 200, $response->get_status() );
		$data = $response->get_data();
		$this->assertIsArray( $data );
	}

	public function test_developer_webhooks_requires_authentication(): void {
		wp_set_current_user( 0 );
		$request  = new \WP_REST_Request( 'GET', '/zymarg-comm/v1/developer/webhooks' );
		$response = rest_get_server()->dispatch( $request );
		$this->assertContains( $response->get_status(), array( 401, 403 ) );
	}

	public function test_invalid_bearer_api_key_is_rejected_with_401(): void {
		$_SERVER['HTTP_AUTHORIZATION'] = 'Bearer zc_' . str_repeat( '0', 64 );
		$request                       = new \WP_REST_Request( 'GET', '/zymarg-comm/v1/conversations' );
		$response                      = rest_get_server()->dispatch( $request );
		unset( $_SERVER['HTTP_AUTHORIZATION'] );
		$this->assertSame( 401, $response->get_status() );
	}

	public function test_help_endpoints_are_registered(): void {
		$routes = rest_get_server()->get_routes();
		$this->assertArrayHasKey( '/zymarg-comm/v1/help/guide/(?P<audience>[a-z0-9_-]+)', $routes );
		$this->assertArrayHasKey( '/zymarg-comm/v1/help/changelog', $routes );
	}
}
