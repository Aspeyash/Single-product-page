/**
 * ZYMARG Communication — Admin SPA navigation.
 *
 * Intercepts clicks on plugin admin links and loads them via fetch into
 * #wpbody-content without a full page reload. Keeps the WordPress sidebar
 * highlight in sync and supports browser back/forward.
 *
 * All admin JS lives in this file per CONTRIBUTING.md (no inline <script>).
 */
(function () {
	'use strict';

	var SLUGS = ['zymarg-communication', 'zymarg-comm-settings', 'zymarg-communication-help', 'zymarg-comm-conversations', 'zymarg-comm-moderation', 'zymarg-comm-analytics'];

	function isPluginUrl(url) {
		return url && SLUGS.some(function (s) { return url.indexOf('page=' + s) !== -1; });
	}

	if (!isPluginUrl(location.href)) return;

	var box = document.getElementById('wpbody-content');
	if (!box) return;

	function dim(on) {
		box.style.opacity = on ? '0.4' : '1';
		box.style.pointerEvents = on ? 'none' : '';
	}

	function execScripts(el) {
		el.querySelectorAll('script').forEach(function (old) {
			var s = document.createElement('script');
			s.textContent = old.textContent;
			if (old.src) s.src = old.src;
			document.body.appendChild(s);
		});
	}

	function syncSidebar(url) {
		var page = (url.split('page=')[1] || '').split('&')[0];
		document.querySelectorAll('#adminmenu li').forEach(function (li) {
			var a = li.querySelector('a');
			if (!a) return;
			var lp = (a.href.split('page=')[1] || '').split('&')[0];
			li.classList.toggle('current', lp === page);
		});
		var par = document.querySelector('#adminmenu a[href*="page=zymarg-communication"]');
		if (par) {
			var pl = par.closest('li.menu-top');
			if (pl) { pl.classList.add('wp-has-current-submenu', 'wp-menu-open'); pl.classList.remove('wp-not-current-submenu'); }
		}
	}

	function loadPage(url) {
		dim(true);
		fetch(url, { credentials: 'same-origin' })
			.then(function (r) { return r.text(); })
			.then(function (html) {
				var doc = new DOMParser().parseFromString(html, 'text/html');
				var nb = doc.getElementById('wpbody-content');
				if (!nb) { location.href = url; return; }
				box.innerHTML = nb.innerHTML;
				document.title = doc.title;
				history.pushState({ zcm: true, url: url }, doc.title, url);
				syncSidebar(url);
				execScripts(box);
				dim(false);
				window.scrollTo(0, 0);
			})
			.catch(function () { location.href = url; });
	}

	document.addEventListener('click', function (e) {
		var a = e.target.closest('a[href]');
		if (!a) return;
		var raw = a.getAttribute('href');
		if (!raw || raw.charAt(0) === '#') return; // in-page anchors (filter tabs) - let the page handle them
		if (!isPluginUrl(a.href)) return;
		if (a.target && a.target !== '_self') return;
		if (a.href.split('#')[0] === location.href.split('#')[0]) return; // same page, hash-only change
		e.preventDefault();
		loadPage(a.href);
	}, true);

	window.addEventListener('popstate', function (e) {
		if (e.state && e.state.zcm) loadPage(e.state.url);
		else if (isPluginUrl(location.href)) loadPage(location.href);
	});
}());
