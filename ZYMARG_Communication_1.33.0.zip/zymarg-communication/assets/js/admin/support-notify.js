/**
 * ZYMARG Communication — admin-side new-message notifier.
 *
 * Notification has to be SYMMETRIC: a customer learns about an admin reply, and
 * an admin learns about a customer message. The customer half is handled on the
 * frontend by live-chat.js, which hands off to the theme's unified toast system
 * (window.ZymargToast). That system does not exist inside wp-admin, and the
 * admin reply surface (ZYMARG Comm -> Admin<->User) lives there.
 *
 * Rather than ship a second, rival toast implementation for one screen, this
 * uses the affordances wp-admin already has, in order of how likely they are to
 * be seen:
 *
 *   1. document.title — "(3) Dashboard ...". Visible on the browser TAB, so it
 *      reaches an admin whose attention is in another tab entirely. This is the
 *      single most useful signal and costs nothing to render.
 *   2. A count bubble on the Admin<->User menu item, using WordPress's own
 *      `.update-plugins` / `.count-N` bubble markup so it looks native.
 *   3. window.ZymargToast, if some other admin screen happens to have loaded
 *      the theme's toast module. Purely opportunistic.
 *
 * Deliberately does NOT use the browser Notification API: that needs a
 * permission prompt, which is a product decision, not a bug fix.
 *
 * @since 1.26.0
 */
( function () {
	'use strict';

	var CFG = window.zymargCommNotify || {};
	if ( ! CFG.restUrl ) { return; }

	var POLL_MS   = Math.max( 15000, parseInt( CFG.pollInterval, 10 ) || 30000 );
	var BASE_TITLE = document.title.replace( /^\(\d+\)\s*/, '' );
	var last      = null;   // null = not seeded yet
	var bubbleEl  = null;

	function api( path ) {
		return fetch( String( CFG.restUrl ).replace( /\/$/, '' ) + path, {
			headers: { 'X-WP-Nonce': CFG.nonce || '' },
			credentials: 'same-origin'
		} ).then( function ( r ) {
			if ( ! r.ok ) { throw new Error( 'HTTP ' + r.status ); }
			return r.json();
		} );
	}

	/** The Admin<->User submenu anchor, if this admin can see it. */
	function menuLink() {
		if ( ! CFG.menuSlug ) { return null; }
		return document.querySelector(
			'#adminmenu a[href*="page=' + CFG.menuSlug + '"]'
		);
	}

	function setBubble( n ) {
		var link = menuLink();
		if ( ! link ) { return; }

		if ( ! bubbleEl || ! link.contains( bubbleEl ) ) {
			bubbleEl = link.querySelector( '.zymarg-comm-count' );
		}

		if ( n <= 0 ) {
			if ( bubbleEl && bubbleEl.parentNode ) { bubbleEl.parentNode.removeChild( bubbleEl ); }
			bubbleEl = null;
			return;
		}

		if ( ! bubbleEl ) {
			bubbleEl = document.createElement( 'span' );
			// WordPress's own bubble classes so this inherits core styling.
			bubbleEl.className = 'update-plugins zymarg-comm-count';
			link.appendChild( bubbleEl );
		}
		bubbleEl.className = 'update-plugins count-' + n + ' zymarg-comm-count';
		bubbleEl.innerHTML = '<span class="plugin-count">' + n + '</span>';
	}

	function setTitle( n ) {
		document.title = n > 0 ? '(' + n + ') ' + BASE_TITLE : BASE_TITLE;
	}

	function announce( n, added ) {
		// Already looking at the support screen? The thread is on-screen and has
		// its own live polling; a popup notification would be noise. The tab
		// title and the bubble still update.
		if ( CFG.onSupportPage && document.hasFocus && document.hasFocus() ) { return; }

		var toast = window.ZymargToast;
		if ( ! toast || typeof toast.show !== 'function' ) { return; }

		try {
			toast.show( {
				type:     'info',
				title:    added > 1 ? ( added + ' new support messages' ) : 'New support message',
				message:  added > 1 ? ( 'You have ' + n + ' unread.' ) : 'A customer is waiting for a reply.',
				duration: 8000,
				action:   CFG.supportUrl ? { label: 'Open', url: CFG.supportUrl } : null
			} );
		} catch ( e ) { /* non-fatal */ }
	}

	function poll() {
		return api( '/marketplace/unread-count' ).then( function ( r ) {
			var d = ( r && r.data ) || r || {};
			var n = Number( d.count != null ? d.count : ( r && r.count ) ) || 0;

			setTitle( n );
			setBubble( n );

			// Only a genuine increase after the first (seeding) response counts as
			// an arrival, so loading a page with a standing backlog stays quiet.
			if ( last !== null && n > last ) { announce( n, n - last ); }
			last = n;
		} ).catch( function () { /* offline / permissions — stay silent */ } );
	}

	poll();
	setInterval( poll, POLL_MS );

	// Coming back to the tab is the moment an admin most wants a fresh count.
	document.addEventListener( 'visibilitychange', function () {
		if ( ! document.hidden ) { poll(); }
	} );

	/**
	 * Instant update on a new message, at zero extra cost (1.29.0).
	 *
	 * RealtimeHooks already broadcasts 'message.sent' to each other
	 * participant's private channel, and realtime.js is enqueued in wp-admin as
	 * well as on the front end, so the connection already exists. Riding that
	 * event makes a waiting customer show up on the tab title and the menu
	 * bubble immediately, without publishing new events, opening a new
	 * connection, or consuming extra quota. The interval above remains the
	 * safety net for status changes and for when realtime is not configured.
	 */
	( function subscribeRealtime() {
		function bind() {
			var rt = window.ZymargComm && window.ZymargComm.realtime;
			if ( rt && typeof rt.on === 'function' ) { rt.on( 'message.sent', poll ); return true; }
			return false;
		}
		if ( bind() ) { return; }
		var tries = 0;
		var t = setInterval( function () { if ( bind() || ++tries > 20 ) { clearInterval( t ); } }, 250 );
	} )();
} )();
