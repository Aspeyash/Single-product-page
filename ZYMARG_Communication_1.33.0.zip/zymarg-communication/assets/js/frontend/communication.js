/*!
 * ZYMARG Communication — frontend runtime (Phase 4).
 *
 * Single vanilla-JS module that boots the marketplace surfaces:
 *   • Buyer inbox (data-zc-role="buyer")
 *   • Vendor inbox (data-zc-role="seller")
 *   • Store popup (#zymarg-comm-popup-root)
 *   • Shared chatbox component (data-zc-chatbox) — UI parity between roles.
 *
 * All UI actions go through the REST API. No direct PHP calls from JS.
 */
( function () {
	'use strict';

	var cfg = window.ZymargCommConfig || {};
	if ( ! cfg.restUrl ) {
		return;
	}

	var api = {
		headers: function () {
			return {
				'Accept': 'application/json',
				'Content-Type': 'application/json',
				'X-WP-Nonce': cfg.nonce || ''
			};
		},
		get: function ( path ) {
			return fetch( cfg.restUrl + path, {
				credentials: 'same-origin',
				headers: api.headers()
			} ).then( function ( r ) { return r.json(); } );
		},
		post: function ( path, body ) {
			return fetch( cfg.restUrl + path, {
				method: 'POST',
				credentials: 'same-origin',
				headers: api.headers(),
				body: JSON.stringify( body || {} )
			} ).then( function ( r ) { return r.json(); } );
		}
	};

	/* ------------------------------------------------------------------ *
	 * Unread badge — wire any [data-zc-unread] element to /marketplace/unread-count.
	 * ------------------------------------------------------------------ */
	function refreshUnread () {
		var badges = document.querySelectorAll( '[data-zc-unread]' );
		if ( ! badges.length ) { return; }
		api.get( 'marketplace/unread-count' ).then( function ( res ) {
			var count = ( res && res.data && res.data.count ) || 0;
			badges.forEach( function ( el ) { el.textContent = String( count ); } );
		} ).catch( function () {} );
	}

	/* ------------------------------------------------------------------ *
	 * Shared chatbox component.
	 * Consumes the parity flag set from /flags/public and hides controls
	 * that are disabled on either side.
	 * ------------------------------------------------------------------ */
	function Chatbox ( root, role ) {
		this.root = root;
		this.role = role;
		this.conversationId = null;
		this.flags = {};
	}
	Chatbox.prototype.mount = function () {
		var self = this;
		api.get( 'flags/public' ).then( function ( res ) {
			self.flags = ( res && res.data ) || {};
			self.render();
		} ).catch( function () { self.render(); } );
	};
	Chatbox.prototype.setConversation = function ( id ) {
		this.conversationId = id;
		this.render();
	};
	Chatbox.prototype.canShow = function ( flagKey ) {
		return this.flags[ flagKey ] !== false;
	};
	Chatbox.prototype.render = function () {
		if ( ! this.conversationId ) {
			return;
		}
		var avatar = this.canShow( 'parity.avatar' )
			? '<div class="zymarg-comm-chatbox__avatar"></div>' : '';
		var meta = '';
		if ( this.canShow( 'parity.last_active' ) ) {
			meta += '<span class="zymarg-comm-chatbox__meta-item" data-zc-meta="last_active"></span>';
		}
		if ( this.canShow( 'parity.response_rate' ) ) {
			meta += '<span class="zymarg-comm-chatbox__meta-item" data-zc-meta="response_rate"></span>';
		}
		this.root.innerHTML = ''
			+ '<header class="zymarg-comm-chatbox__header">'
			+ avatar
			+ '<div class="zymarg-comm-chatbox__meta">' + meta + '</div>'
			+ '</header>'
			+ '<div class="zymarg-comm-chatbox__messages" data-zc-messages></div>'
			+ '<footer class="zymarg-comm-chatbox__composer">'
			+ '  <textarea class="zymarg-comm-chatbox__input" data-zc-input rows="1"></textarea>'
			+ '  <button type="button" class="zymarg-comm-btn zymarg-comm-btn--primary" data-zc-send>'
			+ '    Send'
			+ '  </button>'
			+ '</footer>';
		this.wireComposer();
		this.loadMessages();
	};
	Chatbox.prototype.wireComposer = function () {
		var self = this;
		var btn = this.root.querySelector( '[data-zc-send]' );
		var input = this.root.querySelector( '[data-zc-input]' );
		if ( ! btn || ! input ) { return; }
		btn.addEventListener( 'click', function () {
			var body = ( input.value || '' ).trim();
			if ( ! body ) { return; }
			api.post( 'messages', {
				conversation_id: self.conversationId,
				body: body
			} ).then( function () {
				input.value = '';
				self.loadMessages();
			} ).catch( function () {} );
		} );
	};
	Chatbox.prototype.loadMessages = function () {
		var self = this;
		var wrap = this.root.querySelector( '[data-zc-messages]' );
		if ( ! wrap ) { return; }
		api.get( 'conversations/' + this.conversationId + '/messages' ).then( function ( res ) {
			var list = ( res && res.data && res.data.messages ) || [];
			wrap.innerHTML = list.map( function ( msg ) {
				return renderMessage( msg, self.role );
			} ).join( '' );
			wrap.scrollTop = wrap.scrollHeight;
		} ).catch( function () {} );
	};

	function renderMessage ( msg, viewerRole ) {
		var mine = ( msg.sender_id && cfg.userId && Number( msg.sender_id ) === Number( cfg.userId ) );
		var body = msg.body || '';
		var card = extractProductCard( body );
		var inner;
		if ( card ) {
			inner = ''
				+ '<a class="zymarg-comm-product-card" href="' + escapeAttr( card.permalink ) + '">'
				+ (   card.image_url ? '<img loading="lazy" width="120" height="120" alt="" src="' + escapeAttr( card.image_url ) + '" class="zymarg-comm-product-card__image"/>' : '' )
				+ '  <div class="zymarg-comm-product-card__body">'
				+ '    <div class="zymarg-comm-product-card__title">' + escapeHtml( card.title || '' ) + '</div>'
				+ (   card.price_html ? '<div class="zymarg-comm-product-card__price">' + card.price_html + '</div>' : '' )
				+ '  </div>'
				+ '</a>';
		} else {
			inner = escapeHtml( body ).replace( /\n/g, '<br>' );
		}
		return ''
			+ '<article class="zymarg-comm-message ' + ( mine ? 'zymarg-comm-message--mine' : 'zymarg-comm-message--theirs' ) + '" data-zc-role="' + escapeAttr( viewerRole ) + '">'
			+ '  <div class="zymarg-comm-message__bubble">' + inner + '</div>'
			+ '</article>';
	}

	function extractProductCard ( body ) {
		var m = /^\[zc-product-card\](\{[\s\S]*\})\[\/zc-product-card\]$/.exec( body || '' );
		if ( ! m ) { return null; }
		try { return JSON.parse( m[1] ); }
		catch ( _e ) { return null; }
	}

	function escapeHtml ( str ) {
		return String( str )
			.replace( /&/g, '&amp;' )
			.replace( /</g, '&lt;' )
			.replace( />/g, '&gt;' );
	}
	function escapeAttr ( str ) { return escapeHtml( str ).replace( /"/g, '&quot;' ); }

	/* ------------------------------------------------------------------ *
	 * Conversation list — populate any [data-zc-conversation-list] element.
	 * Selecting a conversation drives the sibling [data-zc-chatbox].
	 * ------------------------------------------------------------------ */
	function ConversationList ( root, chatbox ) {
		this.root = root;
		this.chatbox = chatbox;
	}
	ConversationList.prototype.mount = function () {
		var self = this;
		api.get( 'conversations' ).then( function ( res ) {
			var list = ( res && res.data ) || [];
			self.root.innerHTML = list.map( function ( conv ) {
				return ''
					+ '<button type="button" class="zymarg-comm-conversation-row" data-zc-conversation="' + Number( conv.id ) + '">'
					+ '  <div class="zymarg-comm-conversation-row__title">#' + Number( conv.id ) + '</div>'
					+ '  <div class="zymarg-comm-conversation-row__meta">' + escapeHtml( conv.status || '' ) + '</div>'
					+ '</button>';
			} ).join( '' );
			self.root.addEventListener( 'click', function ( ev ) {
				var btn = ev.target.closest( '[data-zc-conversation]' );
				if ( ! btn ) { return; }
				self.chatbox.setConversation( Number( btn.getAttribute( 'data-zc-conversation' ) ) );
			} );
		} ).catch( function () {} );
	};

	/* ------------------------------------------------------------------ *
	 * Boot: instantiate an inbox + chatbox per [data-zc-role] container.
	 * ------------------------------------------------------------------ */
	function boot () {
		refreshUnread();

		var inboxes = document.querySelectorAll( '.zymarg-comm-inbox[data-zc-role]' );
		inboxes.forEach( function ( inbox ) {
			var role = inbox.getAttribute( 'data-zc-role' ) || 'buyer';
			var chatboxRoot = inbox.querySelector( '[data-zc-chatbox]' );
			var listRoot    = inbox.querySelector( '[data-zc-conversation-list]' );
			if ( ! chatboxRoot || ! listRoot ) { return; }
			var chatbox = new Chatbox( chatboxRoot, role );
			chatbox.mount();
			new ConversationList( listRoot, chatbox ).mount();
		} );

		var popup = document.getElementById( 'zymarg-comm-popup-root' );
		if ( popup && cfg.popupOn ) {
			popup.hidden = false;
			popup.innerHTML = ''
				+ '<button type="button" class="zymarg-comm-popup__toggle" aria-label="Open messages">'
				+ '  <span class="zymarg-comm-unread-badge" data-zc-unread>0</span>'
				+ '</button>'
				+ '<section class="zymarg-comm-popup__panel" hidden>'
				+ '  <header class="zymarg-comm-popup__header">'
				+ '    <h2>Messages</h2>'
				+ '    <a class="zymarg-comm-popup__all" href="' + escapeAttr( cfg.inboxUrl || '#' ) + '">Open inbox</a>'
				+ '  </header>'
				+ '  <div class="zymarg-comm-popup__list" data-zc-conversation-list></div>'
				+ '  <div class="zymarg-comm-popup__chatbox" data-zc-chatbox data-zc-context-type="store"></div>'
				+ '</section>';
			var chatboxRoot = popup.querySelector( '[data-zc-chatbox]' );
			var listRoot    = popup.querySelector( '[data-zc-conversation-list]' );
			var chatbox     = new Chatbox( chatboxRoot, 'buyer' );
			chatbox.mount();
			new ConversationList( listRoot, chatbox ).mount();
			var toggle = popup.querySelector( '.zymarg-comm-popup__toggle' );
			var panel  = popup.querySelector( '.zymarg-comm-popup__panel' );
			toggle.addEventListener( 'click', function () { panel.hidden = ! panel.hidden; } );
			refreshUnread();
		}
	}

	/* Expose small public surface for other plugins / SDK usage. */
	window.ZymargComm = window.ZymargComm || {};
	window.ZymargComm.marketplace = {
		refreshUnread: refreshUnread,
		shareProduct: function ( conversationId, productId ) {
			return api.post( 'marketplace/product-share', {
				conversation_id: conversationId,
				product_id: productId
			} );
		},
		openOrderChat: function ( orderId ) {
			return api.post( 'marketplace/order-chat', { order_id: orderId } );
		}
	};

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', boot );
	} else {
		boot();
	}
} )();
