/**
 * ZYMARG Communication — Support ticket surface (1.27.0).
 *
 * Two cooperating pieces, one file because they share config and helpers:
 *
 *  A. SMART INTAKE — publishes window.zymargSupportIntake.collect(btn), which
 *     support.js awaits before opening a thread. Shows a topic + recent-order +
 *     subject card so the first message an agent sees already says what it is
 *     about, instead of "hi is anyone there".
 *
 *  B. TICKET PANEL — watches a support inbox for its active conversation and
 *     renders a panel above the thread: the status pill (both sides), and for
 *     agents the requester identity card, linked order/vendor context, past
 *     ticket history and Resolve / Reopen / Close actions. For a customer whose
 *     ticket was resolved, it shows a rating card.
 *
 * Vanilla JS, no jQuery, matching the rest of the plugin. Degrades to nothing
 * when the ticket REST routes are absent (e.g. table not migrated yet).
 *
 * @since 1.27.0
 */
( function () {
	"use strict";

	var CFG = window.zymargSupportTicket || {};
	if ( ! CFG.restUrl ) { return; }

	var IS_AGENT = !! CFG.isAgent;
	var REST     = String( CFG.restUrl ).replace( /\/$/, "" );

	/* ── helpers ─────────────────────────────────────────────────────────── */

	function esc( s ) {
		return String( s == null ? "" : s ).replace( /[&<>"']/g, function ( c ) {
			return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ c ];
		} );
	}

	function el( tag, cls, html ) {
		var n = document.createElement( tag );
		if ( cls ) { n.className = cls; }
		if ( html != null ) { n.innerHTML = html; }
		return n;
	}

	function req( method, path, body ) {
		return fetch( REST + path, {
			method: method,
			headers: {
				"Content-Type": "application/json",
				"X-WP-Nonce": CFG.nonce || ""
			},
			credentials: "same-origin",
			body: body ? JSON.stringify( body ) : undefined
		} ).then( function ( r ) {
			return r.json().then( function ( j ) {
				if ( ! r.ok ) { throw j; }
				return j;
			} );
		} );
	}
	function getJSON( path ) { return req( "GET", path ); }
	function postJSON( path, body ) { return req( "POST", path, body ); }

	function money( amount, currency ) {
		var n = Number( amount ) || 0;
		var sym = ( CFG.currencySymbols && CFG.currencySymbols[ currency ] ) || "";
		var val = n.toLocaleString( undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 } );
		return sym ? ( sym + val ) : ( val + " " + ( currency || "" ) ).trim();
	}

	var T = CFG.i18n || {};
	function t( key, fallback ) { return T[ key ] || fallback; }

	/* ====================================================================
	 * A. SMART INTAKE
	 * ================================================================== */

	var intakeOverlay = null;

	function closeIntake() {
		if ( intakeOverlay && intakeOverlay.parentNode ) {
			intakeOverlay.parentNode.removeChild( intakeOverlay );
		}
		intakeOverlay = null;
		document.removeEventListener( "keydown", intakeKeydown, true );
	}

	var intakeReject = null;
	function intakeKeydown( e ) {
		if ( "Escape" === e.key && intakeReject ) {
			var r = intakeReject; intakeReject = null; closeIntake(); r( null );
		}
	}

	/**
	 * Build and show the intake card. Resolves with a context object, or null if
	 * the customer backs out (support.js treats null as "do not open a thread").
	 */
	function collect( btn ) {
		// Agents opening a thread on someone's behalf skip intake; they use the
		// agent tools instead.
		if ( IS_AGENT ) { return Promise.resolve( {} ); }

		// Owner switched intake off (Settings -> Support): open the thread
		// immediately, exactly as the pre-1.27 flow did.
		if ( CFG.intakeEnabled === false ) { return Promise.resolve( {} ); }

		return getJSON( "/support/intake" )
			.then( function ( res ) {
				var d = ( res && res.data ) || res || {};

				// Already have an open ticket -> resume it, no intake needed.
				if ( d.has_open ) { return {}; }

				return showIntakeCard( d );
			} )
			.catch( function () {
				// Intake data failed to load -> do not block the customer; open a
				// thread the old way with no context.
				return {};
			} );
	}

	function showIntakeCard( data ) {
		return new Promise( function ( resolve ) {
			closeIntake();
			intakeReject = resolve;

			var topics = ( data && data.topics ) || [];
			var orders = ( data && data.orders ) || [];
			var avail  = ( data && data.availability ) || {};

			var chosen = { topic: "", subject: "", order_id: 0 };

			intakeOverlay = el( "div", "zymarg-intake-overlay" );
			var card = el( "div", "zymarg-intake" );
			card.setAttribute( "role", "dialog" );
			card.setAttribute( "aria-modal", "true" );
			card.setAttribute( "aria-label", t( "intakeTitle", "Contact Support" ) );

			// Header
			card.appendChild( el( "div", "zymarg-intake__head",
				'<h3 class="zymarg-intake__title">' + esc( t( "intakeTitle", "How can we help?" ) ) + "</h3>" +
				'<button type="button" class="zymarg-intake__x" aria-label="' + esc( t( "close", "Close" ) ) + '">&times;</button>'
			) );

			var bodyEl = el( "div", "zymarg-intake__body" );

			// Topics
			if ( topics.length ) {
				bodyEl.appendChild( el( "p", "zymarg-intake__label", esc( t( "whatAbout", "What is this about?" ) ) ) );
				var chips = el( "div", "zymarg-intake__chips" );
				topics.forEach( function ( tp ) {
					var chip = el( "button", "zymarg-intake__chip" );
					chip.type = "button";
					chip.textContent = tp.label;
					chip.setAttribute( "data-topic", tp.key );
					chip.addEventListener( "click", function () {
						chosen.topic = tp.key;
						Array.prototype.forEach.call( chips.children, function ( c ) { c.classList.remove( "is-on" ); } );
						chip.classList.add( "is-on" );
						syncOrderVisibility();
					} );
					chips.appendChild( chip );
				} );
				bodyEl.appendChild( chips );
			}

			// Recent orders (only meaningful for order-ish topics, but shown
			// whenever the customer has any).
			var orderWrap = el( "div", "zymarg-intake__orders" );
			if ( orders.length ) {
				orderWrap.appendChild( el( "p", "zymarg-intake__label", esc( t( "whichOrder", "Is it about a recent order?" ) ) ) );
				var oList = el( "div", "zymarg-intake__orderlist" );
				orders.forEach( function ( o ) {
					var b = el( "button", "zymarg-intake__order" );
					b.type = "button";
					b.setAttribute( "data-order", String( o.id ) );
					b.innerHTML =
						'<span class="zymarg-intake__order-num">#' + esc( o.number ) + "</span>" +
						'<span class="zymarg-intake__order-meta">' + esc( money( o.total, o.currency ) ) +
						( o.date ? ( " · " + esc( o.date ) ) : "" ) + "</span>";
					b.addEventListener( "click", function () {
						if ( chosen.order_id === o.id ) {
							chosen.order_id = 0; b.classList.remove( "is-on" );
						} else {
							chosen.order_id = o.id;
							Array.prototype.forEach.call( oList.children, function ( c ) { c.classList.remove( "is-on" ); } );
							b.classList.add( "is-on" );
						}
					} );
					oList.appendChild( b );
				} );
				orderWrap.appendChild( oList );
			}
			bodyEl.appendChild( orderWrap );

			function syncOrderVisibility() { /* orders always visible when present; hook kept for future topic-gating */ }

			// Subject
			bodyEl.appendChild( el( "p", "zymarg-intake__label", esc( t( "tellUs", "Tell us in one line" ) ) ) );
			var subject = el( "input", "zymarg-intake__subject" );
			subject.type = "text";
			subject.maxLength = 200;
			subject.placeholder = t( "subjectPlaceholder", "e.g. Wrong size delivered" );
			bodyEl.appendChild( subject );

			// Availability
			if ( avail && avail.eta_label ) {
				bodyEl.appendChild( el( "p", "zymarg-intake__avail", esc( avail.eta_label ) ) );
			}

			card.appendChild( bodyEl );

			// Footer
			var foot = el( "div", "zymarg-intake__foot" );
			var cancel = el( "button", "zymarg-intake__btn zymarg-intake__btn--ghost" );
			cancel.type = "button";
			cancel.textContent = t( "cancel", "Cancel" );
			var start = el( "button", "zymarg-intake__btn zymarg-intake__btn--primary" );
			start.type = "button";
			start.textContent = t( "startChat", "Start chat" );
			foot.appendChild( cancel );
			foot.appendChild( start );
			card.appendChild( foot );

			intakeOverlay.appendChild( card );
			document.body.appendChild( intakeOverlay );
			document.addEventListener( "keydown", intakeKeydown, true );
			setTimeout( function () { subject.focus(); }, 30 );

			function finish( value ) {
				intakeReject = null;
				closeIntake();
				resolve( value );
			}

			cancel.addEventListener( "click", function () { finish( null ); } );
			card.querySelector( ".zymarg-intake__x" ).addEventListener( "click", function () { finish( null ); } );
			intakeOverlay.addEventListener( "click", function ( e ) { if ( e.target === intakeOverlay ) { finish( null ); } } );

			start.addEventListener( "click", function () {
				chosen.subject = subject.value.trim();
				finish( {
					topic: chosen.topic,
					subject: chosen.subject,
					order_id: chosen.order_id
				} );
			} );
		} );
	}

	window.zymargSupportIntake = { collect: collect };

	/* ====================================================================
	 * B. TICKET PANEL
	 * ================================================================== */

	function isSupportRoot( root ) {
		return root && root.getAttribute && "support" === ( root.getAttribute( "data-context" ) || "" );
	}

	/** Ensure a persistent panel node between the header and body of the inbox. */
	function panelFor( root ) {
		var existing = root.querySelector( ":scope > .zymarg-ticket" );
		if ( existing ) { return existing; }

		var panel = el( "div", "zymarg-ticket" );
		panel.setAttribute( "data-zymarg-ticket-panel", "" );

		var body = root.querySelector( ".zymarg-inbox__body" );
		if ( body && body.parentNode === root ) {
			root.insertBefore( panel, body );
			return panel;
		}

		// 1.32.0 — the popup. Its panel has to sit directly above the message
		// pane, otherwise appendChild would drop the ticket context underneath the
		// composer where nobody looks. Without this the popup showed none of what
		// the customer chose during Smart Intake.
		var msgs = root.querySelector( "[data-zymarg-live-chat-messages]" );
		if ( msgs && msgs.parentNode ) {
			msgs.parentNode.insertBefore( panel, msgs );
			return panel;
		}

		root.appendChild( panel );
		return panel;
	}

	function pill( descriptor ) {
		if ( ! descriptor ) { return ""; }
		return '<span class="zymarg-ticket__pill zymarg-ticket__pill--' + esc( descriptor.tone || "muted" ) + '">' +
			esc( descriptor.label || "" ) + "</span>";
	}

	function renderAgentPanel( panel, data, conversationId ) {
		var r = data.requester || {};
		var ctx = data.context || null;
		var history = data.history || [];
		var status = data.status || {};

		var html = "";

		// Row 1: status + who
		html += '<div class="zymarg-ticket__row">';
		html += '<div class="zymarg-ticket__who">';
		if ( r.avatar ) { html += '<img class="zymarg-ticket__avatar" src="' + esc( r.avatar ) + '" alt="" />'; }
		html += '<div class="zymarg-ticket__whotext">';
		html += '<span class="zymarg-ticket__name">' + esc( r.name || "" ) +
			' <span class="zymarg-ticket__role zymarg-ticket__role--' + esc( r.role || "customer" ) + '">' + esc( r.role_label || "" ) + "</span></span>";
		var meta = [];
		if ( r.member_since ) { meta.push( t( "memberSince", "Member since" ) + " " + esc( r.member_since ) ); }
		if ( typeof r.order_count === "number" ) { meta.push( r.order_count + " " + t( "orders", "orders" ) ); }
		if ( r.lifetime_spend ) { meta.push( money( r.lifetime_spend, ( ctx && ctx.order && ctx.order.currency ) || "" ) ); }
		html += '<span class="zymarg-ticket__meta">' + esc( meta.join( " · " ) ) + "</span>";
		html += "</div></div>";
		html += '<div class="zymarg-ticket__status">' + pill( status );
		// 1.32.15 — how long this customer has been waiting on the team. Agent
		// payload only, and only while the case awaits a reply, so it never nags
		// about a case that is already the customer's turn.
		var wait = data.waiting && data.waiting.label ? data.waiting : null;
		if ( wait ) {
			html += '<span class="zymarg-ticket__wait is-' + esc( wait.tone || "ok" ) + '">' +
				esc( t( "waitingPrefix", "waiting" ) ) + " " + esc( wait.label ) + "</span>";
		}
		html += "</div>";
		html += "</div>";

		// Row 2: context card
		if ( ctx && ( ctx.order || ctx.vendor || ctx.topic ) ) {
			html += '<div class="zymarg-ticket__context">';
			if ( ctx.topic ) { html += '<span class="zymarg-ticket__topic">' + esc( ctx.topic ) + "</span>"; }
			if ( ctx.subject ) { html += '<span class="zymarg-ticket__subject">' + esc( ctx.subject ) + "</span>"; }
			if ( ctx.order ) {
				html += '<a class="zymarg-ticket__order" href="' + esc( ctx.order.admin_url ) + '" target="_blank" rel="noopener">' +
					"#" + esc( ctx.order.number ) + " · " + esc( money( ctx.order.total, ctx.order.currency ) ) +
					( ctx.order.status ? ( ' · ' + esc( ctx.order.status ) ) : "" ) + "</a>";
			}
			if ( ctx.vendor ) {
				html += '<span class="zymarg-ticket__vendor">' + esc( t( "vendor", "Vendor" ) + ": " + ctx.vendor.name ) + "</span>";
			}
			html += "</div>";
		}

		// Row 3: history
		if ( history.length ) {
			var resolvedCount = history.filter( function ( h ) { return "resolved" === h.status; } ).length;
			html += '<details class="zymarg-ticket__history"><summary>' +
				esc( history.length + " " + t( "priorTickets", "previous tickets" ) ) +
				( resolvedCount ? ( " · " + resolvedCount + " " + t( "resolved", "resolved" ) ) : "" ) +
				"</summary><ul>";
			history.forEach( function ( h ) {
				html += "<li>" + pill( { tone: h.tone, label: h.status_label } ) +
					" " + esc( h.topic || h.subject || ( "#" + h.conversation_id ) ) +
					( h.updated_at ? ( ' <span class="zymarg-ticket__hist-date">' + esc( ( h.updated_at || "" ).substring( 0, 10 ) ) + "</span>" ) : "" ) +
					"</li>";
			} );
			html += "</ul></details>";
		}

		// Row 3b: the helpline clock (1.31.0). Shown so an agent can see a case is
		// about to lapse BEFORE it does, and hold or extend it if the customer
		// legitimately needs longer (digging out an invoice, say).
		var ac = status.autoclose || {};
		if ( ac.active || ac.paused ) {
			html += '<div class="zymarg-ticket__session' + ( ac.paused ? " is-paused" : "" ) + '">';
			if ( ac.paused ) {
				html += esc( t( "sessionPaused", "The countdown is paused by our team." ) );
			} else {
				html += esc( t( "sessionClosesIn", "Waiting on you — this case closes in %s if you do not reply." )
					.replace( "%s", mmss( Number( ac.seconds_remaining ) || 0 ) ) );
			}
			html += '</div>';
		}

		// Row 4: actions
		html += '<div class="zymarg-ticket__actions">';
		if ( status.open ) {
			html += '<button type="button" class="zymarg-ticket__btn zymarg-ticket__btn--resolve" data-ticket-action="resolve">' + esc( t( "markResolved", "Mark resolved" ) ) + "</button>";
			html += '<button type="button" class="zymarg-ticket__btn zymarg-ticket__btn--close" data-ticket-action="close">' + esc( t( "close", "Close" ) ) + "</button>";

			// Clock controls only make sense while a clock exists.
			if ( ac.paused ) {
				html += '<button type="button" class="zymarg-ticket__btn zymarg-ticket__btn--resume" data-ticket-action="resume">' + esc( t( "sessionResume", "Resume timer" ) ) + "</button>";
			} else if ( ac.active ) {
				html += '<button type="button" class="zymarg-ticket__btn zymarg-ticket__btn--pause" data-ticket-action="pause">' + esc( t( "sessionPause", "Pause timer" ) ) + "</button>";
				html += '<button type="button" class="zymarg-ticket__btn zymarg-ticket__btn--extend" data-ticket-action="extend" data-ticket-minutes="10">' + esc( t( "sessionExtend", "Give more time" ) ) + "</button>";
			}
		} else {
			html += '<button type="button" class="zymarg-ticket__btn zymarg-ticket__btn--reopen" data-ticket-action="reopen">' + esc( t( "reopen", "Reopen" ) ) + "</button>";
		}
		html += "</div>";

		panel.innerHTML = html;
		panel.classList.add( "zymarg-ticket--agent" );

		Array.prototype.forEach.call( panel.querySelectorAll( "[data-ticket-action]" ), function ( b ) {
			b.addEventListener( "click", function () {
				var action = b.getAttribute( "data-ticket-action" );
				// `extend` is the only action carrying a body; the rest post empty.
				var minutes = parseInt( b.getAttribute( "data-ticket-minutes" ), 10 );
				var body = ( "extend" === action && minutes > 0 ) ? { minutes: minutes } : {};
				b.disabled = true;
				postJSON( "/support/ticket/" + conversationId + "/" + action, body )
					.then( function () { loadTicket( panel.__root, conversationId, true ); } )
					.catch( function () { b.disabled = false; } );
			} );
		} );
	}

	/* ------------------------------------------------------------------
	   Helpline countdown (1.31.0)

	   The server sends the deadline ONCE per ticket read and the browser counts
	   it down locally. A per-second poll would be the obvious implementation and
	   the wrong one: this is a marketplace, not a chat app, and the countdown
	   must not cost a request per tick.

	   One toast fires at the warning threshold, through the theme's existing
	   toast chain rather than a rival notifier. While the customer is actually
	   typing inside that window, a single heartbeat pushes the deadline out so
	   nobody mid-sentence is cut off.
	   ------------------------------------------------------------------ */
	var countdownTimer = null;
	var warnedFor      = {}; // conversationId -> true, so the toast fires once

	function clearCountdown() {
		if ( countdownTimer ) { window.clearInterval( countdownTimer ); countdownTimer = null; }
	}

	function mmss( secs ) {
		var s = Math.max( 0, Math.floor( secs ) );
		var m = Math.floor( s / 60 );
		var r = s % 60;
		return m + ":" + ( r < 10 ? "0" : "" ) + r;
	}

	/** Announce through the theme's toast, exactly as live-chat.js does. */
	function sessionToast( message ) {
		var payload = {
			type: "warning",
			title: t( "sessionClosingSoon", "Your support case is about to close" ),
			message: message,
			duration: 6000
		};

		var api = window.ZymargToast;
		if ( api && "function" === typeof api.show ) {
			try { api.show( payload ); return; } catch ( e ) { /* fall through */ }
		}
		try { document.dispatchEvent( new CustomEvent( "zymarg:toast", { detail: payload } ) ); } catch ( e ) {}
	}

	/**
	 * Drive the live countdown inside an already-rendered panel.
	 *
	 * @param {Element} noteEl   The countdown line.
	 * @param {Element} root     Inbox root, for the reload when the clock runs out.
	 */
	function startCountdown( noteEl, root, conversationId, autoclose ) {
		clearCountdown();

		var remaining = Number( autoclose.seconds_remaining );
		if ( ! isFinite( remaining ) ) { return; }

		var warnAt   = Math.max( 1, Number( autoclose.warn_seconds ) || 60 );
		// 1.32.1 — dropped the "Waiting on you —" prefix. The customer view
		// no longer surfaces the status pill and the countdown itself already
		// makes the "reply or lose it" state obvious.
		var template = t( "sessionClosesIn", "This case closes in %s if you do not reply." );
		var beat     = false; // one heartbeat per warning window, not per tick

		function paint() {
			noteEl.textContent = template.replace( "%s", mmss( remaining ) );
			noteEl.classList.toggle( "is-urgent", remaining <= warnAt );
		}

		paint();

		countdownTimer = window.setInterval( function () {
			remaining -= 1;

			if ( remaining <= 0 ) {
				clearCountdown();
				// The server is the authority on whether it actually closed, so ask
				// rather than assuming. force=true bypasses the dedupe cache.
				loadTicket( root, conversationId, true );
				return;
			}

			paint();

			if ( remaining <= warnAt && ! warnedFor[ conversationId ] ) {
				warnedFor[ conversationId ] = true;
				sessionToast( template.replace( "%s", mmss( remaining ) ) );
			}

			// Mid-sentence at the buzzer: buy them a fresh window, once.
			if ( remaining <= warnAt && ! beat && composerHasText( root ) ) {
				beat = true;
				postJSON( "/support/ticket/" + conversationId + "/heartbeat", {} )
					.then( function () { loadTicket( root, conversationId, true ); } )
					.catch( function () {} );
			}
		}, 1000 );
	}

	/** Is the customer part-way through writing something? */
	function composerHasText( root ) {
		if ( ! root ) { return false; }
		var ta = root.querySelector( ".zymarg-inbox__composer textarea" );
		if ( ta && ta.value && ta.value.trim() ) { return true; }

		// The popup composer lives outside the inbox root.
		var popup = document.querySelector( "[data-zymarg-live-chat-input]" );
		return !! ( popup && popup.value && popup.value.trim() );
	}

	function renderCustomerPanel( panel, data, conversationId ) {
		var status = data.status || {};
		var rated  = Number( data.rating || 0 ) > 0;
		var autoclose = status.autoclose || {};
		// 1.32.1 — customer view no longer shows the "Waiting on us" /
		// "Waiting on you" / "Resolved" / "Closed" status pill. It's noise
		// for the customer (they know what they typed and whether an agent
		// has replied), and the countdown / paused / closed / rating rows
		// below already communicate whatever action they can take. The pill
		// stays on the AGENT panel — the agent DOES need it to triage.
		var html = "";

		clearCountdown();

		// Live countdown while the case is waiting on the customer.
		if ( autoclose.active ) {
			html += '<div class="zymarg-ticket__session" data-ticket-countdown></div>';
		} else if ( autoclose.paused ) {
			html += '<div class="zymarg-ticket__session is-paused">' +
				esc( t( "sessionPaused", "The countdown is paused by our team." ) ) + "</div>";
		}

		// Closed by the timer rather than by a person: say so plainly, and give
		// them the way forward instead of a dead end.
		if ( "closed" === status.status && "auto_timeout" === autoclose.closed_reason ) {
			html += '<div class="zymarg-ticket__session is-closed">' +
				esc( t( "sessionClosedAuto", "This case was closed automatically because there was no reply." ) ) +
				'</div><div class="zymarg-ticket__actions">' +
				'<button type="button" class="zymarg-support-trigger zymarg-support-trigger--button"' +
				' data-zymarg-support-start' +
				' data-rest="' + esc( REST ) + '"' +
				' data-nonce="' + esc( CFG.nonce || "" ) + '">' +
				'<span class="zymarg-support-trigger__label">' +
				esc( t( "sessionStartNew", "Start a new case" ) ) + "</span></button></div>";
		}

		// Rating card once resolved and not yet rated.
		if ( "resolved" === status.status && ! rated ) {
			html += '<div class="zymarg-ticket__rate">';
			html += '<span class="zymarg-ticket__rate-label">' + esc( t( "howDidWeDo", "How did we do?" ) ) + "</span>";
			html += '<span class="zymarg-ticket__stars">';
			for ( var i = 1; i <= 5; i++ ) {
				html += '<button type="button" class="zymarg-ticket__star" data-star="' + i + '" aria-label="' + i + '">&#9733;</button>';
			}
			html += "</span></div>";
		} else if ( rated ) {
			html += '<div class="zymarg-ticket__rated">' + esc( t( "thanksRating", "Thanks for your feedback!" ) ) + "</div>";
		}

		panel.innerHTML = html;
		panel.classList.remove( "zymarg-ticket--agent" );

		// 1.32.2 — collapse the panel when it has nothing to say.
		//
		// Until 1.32.1 the customer panel ALWAYS had at least the status pill in
		// it, so it was never empty and nobody needed this. 1.32.1 removed the
		// pill from the customer view, which left the most common state — case
		// open, agent has not replied yet, so no countdown, no rating, not
		// closed — rendering an empty `.zymarg-ticket`. That node carries
		// padding, a surface background and a bottom border, so the customer saw
		// a blank mauve strip with a rule under it wedged above their messages.
		//
		// `.zymarg-ticket[hidden]{display:none}` already exists in the
		// stylesheet, so hiding the node is enough to collapse it completely.
		// loadTicket() sets panel.hidden = false before calling us, so this is
		// the authoritative last word for the customer surface.
		panel.hidden = ( "" === html );

		// Start ticking only once the node exists in the document.
		var noteEl = panel.querySelector( "[data-ticket-countdown]" );
		if ( noteEl && autoclose.active ) {
			startCountdown( noteEl, panel.__root, conversationId, autoclose );
		}

		// "Start a new case" is a real support trigger, so hand it to support.js
		// to wire rather than duplicating the whole start-thread flow here.
		// boot() is idempotent (it marks buttons data-zymarg-support-ready), so
		// re-announcing the section is safe.
		if ( panel.querySelector( "[data-zymarg-support-start]" ) ) {
			try { document.dispatchEvent( new CustomEvent( "zymarg:section-loaded" ) ); } catch ( e ) {}
		}

		var stars = panel.querySelectorAll( ".zymarg-ticket__star" );
		Array.prototype.forEach.call( stars, function ( starBtn ) {
			var val = parseInt( starBtn.getAttribute( "data-star" ), 10 );
			starBtn.addEventListener( "mouseenter", function () { paintStars( stars, val ); } );
			starBtn.addEventListener( "click", function () {
				postJSON( "/support/ticket/" + conversationId + "/rate", { rating: val } )
					.then( function () { loadTicket( panel.__root, conversationId, true ); } )
					.catch( function () {} );
			} );
		} );
		panel.addEventListener( "mouseleave", function () { paintStars( stars, 0 ); } );
	}

	function paintStars( stars, upTo ) {
		Array.prototype.forEach.call( stars, function ( s ) {
			var v = parseInt( s.getAttribute( "data-star" ), 10 );
			s.classList.toggle( "is-on", v <= upTo );
		} );
	}

	/**
	 * Per-root load state (1.32.0).
	 *
	 * Keyed on the root ELEMENT, not a string. The previous key was
	 * `data-user-id + ":" + conversationId`, which had two defects:
	 *
	 *   1. Because the id was IN the key, the map could never represent "this
	 *      root is currently showing X". Re-selecting a conversation you had
	 *      already viewed matched its own stale entry and returned early, so the
	 *      panel went on showing the PREVIOUS customer's name.
	 *   2. Two roots for the same user (the in-page inbox and the popup) produced
	 *      the identical key and fought over one slot.
	 *
	 * `seq` is a monotonic request counter used to discard stale responses. Agents
	 * click down a queue faster than the requests come back, and without this the
	 * slowest reply wins — which is exactly the "name changes, then a few seconds
	 * later it is wrong" symptom.
	 */
	var loadState = new WeakMap();
	var loadSeq   = 0;

	function loadTicket( root, conversationId, force ) {
		if ( ! root || ! conversationId ) { return; }

		var st = loadState.get( root ) || { loaded: 0, seq: 0 };

		// Already showing this conversation on this root.
		if ( ! force && st.loaded === conversationId ) { return; }

		var mySeq = ++loadSeq;
		st.loaded = conversationId;
		st.seq    = mySeq;
		loadState.set( root, st );

		getJSON( "/support/ticket/" + conversationId )
			.then( function ( res ) {
				// A newer selection has been made while this was in flight; its
				// response is the one that must win, so drop this one.
				var now = loadState.get( root );
				if ( ! now || now.seq !== mySeq ) { return; }

				var data = ( res && res.data ) || res || {};
				var panel = panelFor( root );
				panel.__root = root;
				panel.hidden = false;
				if ( IS_AGENT && data.requester ) {
					renderAgentPanel( panel, data, conversationId );
				} else {
					renderCustomerPanel( panel, data, conversationId );
				}
			} )
			.catch( function () {
				var now = loadState.get( root );
				if ( ! now || now.seq !== mySeq ) { return; }

				// Let the next selection retry rather than being deduped away.
				now.loaded = 0;
				loadState.set( root, now );

				// Ticket routes unavailable (older backend) — remove any panel so
				// the surface looks exactly as it did before.
				var panel = root.querySelector( ":scope > .zymarg-ticket" );
				if ( panel && panel.parentNode ) { panel.parentNode.removeChild( panel ); }
			} );
	}

	function watchRoot( root ) {
		if ( ! isSupportRoot( root ) || root.__zymargTicketWatched ) { return; }
		root.__zymargTicketWatched = true;

		var current = root.getAttribute( "data-active-conversation" );
		if ( current ) { loadTicket( root, parseInt( current, 10 ), false ); }

		var mo = new MutationObserver( function () {
			var id = parseInt( root.getAttribute( "data-active-conversation" ) || "0", 10 );
			if ( id ) { loadTicket( root, id, false ); }
		} );
		mo.observe( root, { attributes: true, attributeFilter: [ "data-active-conversation" ] } );
	}

	/**
	 * 1.32.0 — the popup is included now.
	 *
	 * support.js stamps `data-context="support"` and `data-active-conversation`
	 * onto the popup root whenever it puts a support thread in there, which is
	 * the same contract the in-page inbox already uses. The popup is shared with
	 * ordinary buyer/vendor chat, so the data-context marker is what keeps the
	 * ticket panel off conversations it has no business describing.
	 */
	function scanRoots() {
		var roots = document.querySelectorAll(
			'[data-zymarg-inbox][data-context="support"], [data-zymarg-live-chat][data-context="support"]'
		);
		Array.prototype.forEach.call( roots, watchRoot );
	}

	// Push signal from inbox.js (preferred) + observation fallback.
	document.addEventListener( "zymarg-comm:thread-opened", function ( e ) {
		var d = ( e && e.detail ) || {};
		if ( d.root && isSupportRoot( d.root ) && d.conversationId ) {
			watchRoot( d.root );
			loadTicket( d.root, parseInt( d.conversationId, 10 ), false );
		}
	} );

	function boot() { scanRoots(); }
	if ( document.readyState === "loading" ) {
		document.addEventListener( "DOMContentLoaded", boot );
	} else {
		boot();
	}
	[ "zymarg-vd:section-loaded", "zymarg:section-loaded", "zymarg-os:section-loaded" ].forEach( function ( evt ) {
		document.addEventListener( evt, boot );
	} );
	// The inbox markup is often injected after load; catch it.
	var rootMo = new MutationObserver( function () { scanRoots(); } );
	rootMo.observe( document.documentElement, { childList: true, subtree: true } );
} )();
