/*!
 * ZYMARG Communication — Live-chat popup (v1.12.27).
 * Vanilla JavaScript. No jQuery.
 *
 * Behaviour change (v1.12.20):
 *  - The launcher icon is NOT shown persistently across the site.
 *  - A lightweight background poll always runs and watches the unread count.
 *  - When a NEW message arrives (unread count increases) the popup panel
 *    surfaces automatically, opening the newest unread conversation.
 *  - The launcher is only visible while there are unread messages or the panel
 *    is open, and it hides again once everything is read and the panel closes.
 *
 * Reads config from `window.zymargLiveChat` (localized by AssetEnqueue).
 */
(function () {
	"use strict";

	var cfg = (typeof window !== "undefined" && window.zymargLiveChat) ? window.zymargLiveChat : null;
	if (!cfg || !cfg.enabled) return;

	var root, launcher, badge, panel, closeBtn, msgsEl, typingEl, form, input, sendBtn, titleEl;
	var activeConversationId = null;
	var pollTimer = null;
	var typingPollTimer = null;
	var typingStopTimer = null;
	var lastTypingSent = 0;
	var lastUnread = 0;
	var livePresenceEl = null;
	var liveTypingHideTimer = null;
	var seeded = false; // First unread reading only seeds state; it never auto-opens.

	function $(sel, ctx) { return (ctx || document).querySelector(sel); }
	function el(tag, cls, text) {
		var n = document.createElement(tag);
		if (cls) n.className = cls;
		if (text != null) n.textContent = text;
		return n;
	}

	/**
	 * Announce a panel lifecycle change on `document` (1.30.0).
	 *
	 * Until now the popup opened and closed in total silence, so nothing outside
	 * this file could react to it. The popup-first support flow needs exactly
	 * that: closing the popup has to reveal the in-page support inbox sitting
	 * hidden behind it. Rather than let support.js reach in and monkey-patch
	 * closePanel(), the popup publishes what it did and stays ignorant of who is
	 * listening — the same contract used for `zymarg:toast`.
	 *
	 * Events (all prefixed `zymarg-comm:`):
	 *   popup-opened     { conversationId }
	 *   popup-closed     { conversationId, reason }  reason: close | dismiss | expand
	 *   popup-minimized  { conversationId }
	 *
	 * `reason` is what lets a listener tell "give me the roomy view" (the cross,
	 * or the expand control) apart from "I am done, go away" (Escape). Escape
	 * must NOT resurrect a different surface — that would trap the customer.
	 *
	 * @param {boolean} [cancelable] Dispatch cancelably and report the verdict.
	 * @return {boolean} false only when a listener called preventDefault().
	 */
	function emit(name, detail, cancelable) {
		try {
			var ev = new CustomEvent("zymarg-comm:" + name, {
				detail: detail || {},
				cancelable: !!cancelable
			});
			return document.dispatchEvent(ev);
		} catch (e) {
			// IE-era browsers without the CustomEvent constructor: treat as
			// unhandled so callers keep their pre-1.30.0 behaviour.
			return true;
		}
	}

	// Upload a file to a message via multipart. Do NOT set Content-Type manually;
	// the browser adds the multipart boundary.
	function uploadAttachment(file, messageId) {
		var url = (cfg.restUrl || "").replace(/\/$/, "") + "/attachments";
		var fd = new FormData();
		fd.append("file", file);
		if (messageId) fd.append("message_id", String(messageId));
		return fetch(url, { method: "POST", headers: { "X-WP-Nonce": cfg.nonce || "" }, credentials: "same-origin", body: fd })
			.then(function (r) { if (!r.ok) throw new Error("HTTP " + r.status); return r.json(); });
	}
	function api(path, opts) {
		opts = opts || {};
		var url = (cfg.restUrl || "").replace(/\/$/, "") + path;
		var init = {
			method: opts.method || "GET",
			headers: { "X-WP-Nonce": cfg.nonce || "", "Content-Type": "application/json" },
			credentials: "same-origin"
		};
		if (opts.body) init.body = JSON.stringify(opts.body);
		return fetch(url, init).then(function (r) {
			if (!r.ok) throw new Error("HTTP " + r.status);
			return r.json();
		});
	}

	// Subscribe to the shared realtime bus (window.ZymargComm.realtime) once it
	// exists. realtime.js loads independently, so retry briefly in case this
	// script evaluates first.
	function onRealtime(event, handler) {
		function bind() {
			var rt = window.ZymargComm && window.ZymargComm.realtime;
			if (rt && typeof rt.on === "function") { rt.on(event, handler); return true; }
			return false;
		}
		if (bind()) return;
		var tries = 0;
		var t = setInterval(function () { if (bind() || ++tries > 20) clearInterval(t); }, 250);
	}

	// The launcher element doubles as the MINIMIZED DOCK from 1.26.0.
	//
	// It is still never shown during ordinary browsing -- the popup surfaces on
	// its own and the full messaging UI lives on the buyer My-Account and seller
	// inbox pages. It appears only while the popup is minimized, where it is the
	// small draggable puck the customer clicks to come back. Reusing one element
	// for both roles inherits the unread badge, gradient and hover lift instead
	// of duplicating them.
	var minimized = false;
	var MIN_KEY = null;

	function updateLauncherVisibility() {
		if (!launcher) return;
		launcher.hidden = !minimized;
		if (launcher.classList) launcher.classList.toggle("is-mini", !!minimized);
		launcher.setAttribute("aria-label", minimized ? "Restore chat" : "Open chat");
		if (minimized) launcher.title = "Restore chat \u2014 drag to move";
		else launcher.removeAttribute("title");
	}

	function saveMinState(on) {
		if (!MIN_KEY) return;
		try {
			if (on) window.localStorage.setItem(MIN_KEY, "1");
			else window.localStorage.removeItem(MIN_KEY);
		} catch (e) {}
	}
	function readMinState() {
		if (!MIN_KEY) return false;
		try { return "1" === window.localStorage.getItem(MIN_KEY); } catch (e) { return false; }
	}

	/* ------------------------------------------------------------------
	   Session continuity across page loads (1.31.0)

	   Before this, only MINIMIZED survived navigation. An OPEN popup did not:
	   the panel is server-rendered `hidden`, openPanel() had cleared the
	   minimized flag, and nothing on boot ever re-opened it -- so navigating
	   left the customer with no panel AND no puck. The chat vanished without a
	   trace, which is worse than closing it, because minimizing at least leaves
	   the puck behind.

	   MIN_KEY is deliberately still written and still read as a fallback, so
	   anyone who had the chat parked when the plugin updated keeps it.

	   The conversation id is stored alongside the state. Restoring "open"
	   without it would reopen an EMPTY panel -- the exact symptom this plugin
	   already had once -- so a session with no id degrades to the puck instead.
	   ------------------------------------------------------------------ */
	var SESSION_KEY = null;
	var SESSION_TTL_FALLBACK_MS = 12 * 60 * 60 * 1000;

	function sessionTtlMs() {
		// cfg.sessionTtl arrives in SECONDS from PHP (filterable) so a site can
		// widen or tighten the window without touching this file.
		var secs = parseInt(cfg && cfg.sessionTtl, 10);
		return secs > 0 ? secs * 1000 : SESSION_TTL_FALLBACK_MS;
	}

	/** @param {string|null} state "open" | "min", or null to forget the session. */
	function sessionWrite(state) {
		if (!SESSION_KEY) return;
		try {
			if (!state) { window.localStorage.removeItem(SESSION_KEY); return; }
			window.localStorage.setItem(SESSION_KEY, JSON.stringify({
				state: state,
				cid: activeConversationId ? parseInt(activeConversationId, 10) : 0,
				ts: Date.now()
			}));
		} catch (e) {}
	}

	function sessionRead() {
		if (!SESSION_KEY) return null;
		try {
			var raw = window.localStorage.getItem(SESSION_KEY);
			if (!raw) return null;

			var s = JSON.parse(raw);
			if (!s || ("open" !== s.state && "min" !== s.state)) return null;

			// Abandoned session: a popup left open on Monday must not reappear on
			// Thursday. Browsing refreshes the stamp, so this only expires real
			// inactivity.
			if (!s.ts || (Date.now() - s.ts) > sessionTtlMs()) {
				window.localStorage.removeItem(SESSION_KEY);
				return null;
			}

			s.cid = parseInt(s.cid, 10) || 0;
			return s;
		} catch (e) {
			return null;
		}
	}

	/* ------------------------------------------------------------------
	   Composer draft (1.31.0)

	   Half-typed text used to die on navigation along with the panel. Keeping
	   the popup open across pages without keeping the draft would be a worse
	   bug than the one it fixes: the window survives, the sentence does not.

	   Keyed per conversation, so switching threads does not smear one draft
	   across another. Cleared on a successful send.
	   ------------------------------------------------------------------ */
	var DRAFT_PREFIX = null;
	var draftTimer = null;

	function draftKey(cid) {
		var id = parseInt(cid, 10) || 0;
		if (!DRAFT_PREFIX || id < 1) return null;
		return DRAFT_PREFIX + id;
	}

	/**
	 * Which conversation's draft is currently sitting in the box.
	 *
	 * Needed because the composer is a single field shared by every thread the
	 * popup shows. Without tracking this, switching conversations left the
	 * previous thread's half-written message in the box and it would be sent to
	 * the wrong person.
	 */
	var draftLoadedFor = 0;

	/** @param {number} [cid] Save against a specific id (used when switching). */
	function draftSave(cid) {
		var key = draftKey(cid || activeConversationId);
		if (!key) return;
		try {
			var text = (input && input.value) || "";
			if (text.trim()) window.localStorage.setItem(key, text);
			else window.localStorage.removeItem(key);
		} catch (e) {}
	}

	/** Debounced so typing does not hit storage on every keystroke. */
	function draftSaveSoon() {
		if (draftTimer) window.clearTimeout(draftTimer);
		draftTimer = window.setTimeout(draftSave, 400);
	}

	function draftRestore() {
		var cid = parseInt(activeConversationId, 10) || 0;
		if (!input || cid < 1) return;

		// Already showing this thread's draft: leave the box alone, or every
		// refresh would fight whatever is being typed right now.
		if (draftLoadedFor === cid) return;

		// Changing threads. Bank the outgoing text against the id it was written
		// for and empty the box, otherwise it leaks into the new conversation and
		// could be sent to the wrong person.
		if (draftLoadedFor && draftLoadedFor !== cid) {
			draftSave(draftLoadedFor);
			input.value = "";
		}

		try {
			var text = window.localStorage.getItem(draftKey(cid));
			if (text && !input.value) {
				input.value = text;
				if ("function" === typeof input.dispatchEvent) {
					try { input.dispatchEvent(new Event("input", { bubbles: true })); } catch (e) {}
				}
			}
		} catch (e) {}

		draftLoadedFor = cid;
	}

	function draftClear(cid) {
		var key = draftKey(cid || activeConversationId);
		if (!key) return;
		try { window.localStorage.removeItem(key); } catch (e) {}
	}

	/**
	 * @param {boolean} [restored] True when re-opening after a page load rather
	 *                             than from a click. Suppresses the focus grab,
	 *                             because stealing focus on arrival scrolls the
	 *                             page and pops the keyboard open on phones.
	 *
	 * NOTE: never wire this straight into .then() -- the resolved value would
	 * arrive as `restored`. Always wrap it in a closure.
	 */
	function openPanel(restored) {
		if (!panel) return;
		minimized = false;
		saveMinState(false);
		panel.hidden = false;
		geoRestore();
		updateLauncherVisibility();
		if (input && true !== restored) input.focus();
		if (activeConversationId) refreshMessages();
		draftRestore();
		sessionWrite("open");
		emit("popup-opened", { conversationId: activeConversationId, restored: true === restored });
	}
	/**
	 * @param {string} [reason] close (the cross, default) | dismiss (Escape) |
	 *                          expand (the expand control). Passed straight
	 *                          through on the popup-closed event.
	 *
	 * NOTE: never wire this directly as an event listener — the DOM would hand
	 * the click Event in as `reason`. Always wrap it in a closure.
	 */
	function closePanel(reason) {
		if (!panel) return;
		minimized = false;
		saveMinState(false);
		panel.hidden = true;
		updateLauncherVisibility();
		// Closing is the one intentional "I am done" signal, so the session is
		// forgotten and the next page load starts clean. Minimize and navigation
		// both preserve it; only the cross (or Escape) throws it away.
		sessionWrite(null);
		emit("popup-closed", {
			conversationId: activeConversationId,
			reason: "string" === typeof reason ? reason : "close"
		});
	}
	// Minimize is NOT close. The panel is hidden but the conversation, the
	// polling loop and the unread counter all keep running, so a reply that
	// arrives while minimized still bumps the badge on the puck. The state is
	// persisted so parking the chat survives navigating to the next page --
	// which is the whole point of minimizing instead of closing.
	function minimizePanel() {
		if (!panel) return;
		minimized = true;
		saveMinState(true);
		panel.hidden = true;
		updateLauncherVisibility();
		dockRestore();
		sessionWrite("min");
		// Deliberately its own event, NOT popup-closed: the conversation, the
		// poll and the badge are all still live, so a listener must not treat a
		// parked chat as a finished one and swap in another surface.
		emit("popup-minimized", { conversationId: activeConversationId });
	}

	/* ------------------------------------------------------------------
	   Minimized dock geometry — draggable anywhere, remembered (1.26.0)

	   Deliberately separate from the panel geometry further down: dragging the
	   puck must not move the panel and vice versa, so each gets its own storage
	   key. Same reasoning as the panel for using localStorage over the server (a
	   spot picked on a 1920px monitor is wrong on a laptop) and the same
	   right/bottom anchoring, so the puck stays tethered to the corner it was
	   parked near when the viewport changes size.

	   A drag must not also register as a click, or letting go of the puck would
	   immediately re-open the panel. DOCK_SLOP is the movement past which a
	   gesture is treated as a drag; dockMoved carries that verdict to the click
	   handler, which consumes and clears it.
	   ------------------------------------------------------------------ */
	var DOCK_KEY = null, DOCK_EDGE = 6, DOCK_SLOP = 4;
	var dockMoved = false;

	function dockRead() {
		if (!DOCK_KEY) return null;
		try { return JSON.parse(window.localStorage.getItem(DOCK_KEY) || "null"); } catch (e) { return null; }
	}
	function dockWrite(g) {
		if (!DOCK_KEY) return;
		try { window.localStorage.setItem(DOCK_KEY, JSON.stringify(g)); } catch (e) {}
	}
	function dockClamp(right, bottom) {
		var w = (launcher && launcher.offsetWidth) || 40;
		var h = (launcher && launcher.offsetHeight) || 40;
		var vw = window.innerWidth || document.documentElement.clientWidth || 0;
		var vh = window.innerHeight || document.documentElement.clientHeight || 0;
		var maxR = Math.max(DOCK_EDGE, vw - w - DOCK_EDGE);
		var maxB = Math.max(DOCK_EDGE, vh - h - DOCK_EDGE);
		return {
			right:  Math.min(Math.max(DOCK_EDGE, Math.round(right)),  maxR),
			bottom: Math.min(Math.max(DOCK_EDGE, Math.round(bottom)), maxB)
		};
	}
	function dockApply(g) {
		if (!launcher || !g) return;
		launcher.style.position = "fixed";
		launcher.style.right    = g.right + "px";
		launcher.style.bottom   = g.bottom + "px";
		launcher.style.left     = "auto";
		launcher.style.top      = "auto";
	}
	function dockOffsets() {
		if (!launcher) return { right: DOCK_EDGE, bottom: DOCK_EDGE };
		var r  = launcher.getBoundingClientRect();
		var vw = window.innerWidth || document.documentElement.clientWidth || 0;
		var vh = window.innerHeight || document.documentElement.clientHeight || 0;
		return { right: Math.round(vw - r.right), bottom: Math.round(vh - r.bottom) };
	}
	function dockRestore() {
		var g = dockRead();
		if (!g) return; // never dragged — leave it in the CSS default corner
		dockApply(dockClamp(g.right, g.bottom));
	}
	function dockDragInit() {
		if (!launcher) return;
		var active = false, moved = false, sx = 0, sy = 0, baseR = 0, baseB = 0;

		function start(x, y) {
			var cur = dockOffsets();
			baseR = cur.right; baseB = cur.bottom;
			sx = x; sy = y;
			active = true; moved = false;
			if (launcher.classList) launcher.classList.add("is-dragging");
		}
		function move(x, y) {
			if (!active) return;
			// Right/bottom anchored, so a rightward pointer move DECREASES right.
			var dx = sx - x, dy = sy - y;
			if (!moved && (Math.abs(dx) > DOCK_SLOP || Math.abs(dy) > DOCK_SLOP)) moved = true;
			dockApply(dockClamp(baseR + dx, baseB + dy));
		}
		function end() {
			if (!active) return;
			active = false;
			if (launcher.classList) launcher.classList.remove("is-dragging");
			if (moved) { dockMoved = true; dockWrite(dockOffsets()); }
		}

		if (window.PointerEvent) {
			launcher.addEventListener("pointerdown", function (e) {
				if (!minimized || 0 !== e.button) return;
				start(e.clientX, e.clientY);
				try { launcher.setPointerCapture(e.pointerId); } catch (err) {}
			});
			launcher.addEventListener("pointermove", function (e) {
				if (!active) return;
				e.preventDefault();
				move(e.clientX, e.clientY);
			});
			launcher.addEventListener("pointerup", end);
			launcher.addEventListener("pointercancel", end);
		} else {
			launcher.addEventListener("mousedown", function (e) {
				if (!minimized || 0 !== e.button) return;
				start(e.clientX, e.clientY);
			});
			document.addEventListener("mousemove", function (e) { if (active) { e.preventDefault(); move(e.clientX, e.clientY); } });
			document.addEventListener("mouseup", end);
			launcher.addEventListener("touchstart", function (e) {
				if (!minimized || !e.touches || !e.touches[0]) return;
				start(e.touches[0].clientX, e.touches[0].clientY);
			}, { passive: true });
			launcher.addEventListener("touchmove", function (e) {
				if (!active || !e.touches || !e.touches[0]) return;
				e.preventDefault();
				move(e.touches[0].clientX, e.touches[0].clientY);
			}, { passive: false });
			launcher.addEventListener("touchend", end);
		}

		// Keep the puck on screen when the window shrinks or rotates.
		window.addEventListener("resize", function () { if (minimized) dockRestore(); });
	}

	/* ------------------------------------------------------------------
	   How an arriving message announces itself (1.26.0)

	   Before this, the only behaviour was flinging the panel open, which can
	   land on top of whatever the customer is doing -- mid-checkout, for
	   instance. "toast" is the polite default, "badge" is silent, and "autoopen"
	   preserves the historic behaviour exactly (still gated on cfg.autoOpen, so
	   existing per-page allow-lists keep working untouched).
	   ------------------------------------------------------------------ */
	function arrivalMode() {
		var m = String((cfg && cfg.newMessageBehavior) || "toast").toLowerCase();
		if ("autoopen" !== m && "toast" !== m && "badge" !== m) m = "toast";
		return m;
	}

	function surfaceLatest() {
		return selectLatestConversation().then(function (cid) { if (cid) openPanel(); });
	}

	function notifyArrival(n, prev) {
		var panelOpen = !!(panel && !panel.hidden);

		// Already reading the thread with the window focused? The message is on
		// screen already; announcing it again is pure noise.
		if (panelOpen && document.hasFocus && document.hasFocus()) return;

		var mode = arrivalMode();

		if ("autoopen" === mode) {
			if (!panelOpen && cfg && cfg.autoOpen) surfaceLatest();
			return;
		}
		if ("badge" === mode) return; // setBadge() already ran in refreshUnread

		// One toast per burst, not one per message.
		var added = Math.max(1, n - Math.max(0, prev));
		var payload = {
			type:     "info",
			title:    added > 1 ? (added + " new messages") : "New message",
			message:  added > 1 ? ("You have " + n + " unread.") : "Open the chat to read and reply.",
			duration: 6000
		};

		// Toasts are the THEME's job (ZYMARG OS ships the one unified toast
		// system for the whole site), so this delegates rather than shipping a
		// rival implementation that would stack two notification styles on one
		// screen. Preference order mirrors the theme's own documented contract:
		//   1. window.ZymargToast.show() — direct call, supports an onClick action
		//   2. the 'zymarg:toast' DOM event — the theme's explicitly
		//      dependency-free path, used when the global is not exposed yet
		//   3. legacy auto-open — so a site with no toast layer at all still
		//      surfaces the message instead of silently dropping it
		var api = window.ZymargToast;
		if (api && typeof api.show === "function") {
			payload.action = {
				label: "Open chat",
				onClick: function () {
					if (activeConversationId) openPanel();
					else surfaceLatest();
				}
			};
			try { api.show(payload); return; } catch (e) { /* fall through */ }
		}

		// Event path cannot rely on a callback surviving every consumer, so the
		// action degrades to a plain link to the full inbox.
		var inboxUrl = (cfg && cfg.inboxUrl) ? String(cfg.inboxUrl) : "";
		if (inboxUrl) payload.action = { label: "Open inbox", url: inboxUrl };
		try {
			document.dispatchEvent(new CustomEvent("zymarg:toast", { detail: payload }));
			return;
		} catch (e) { /* fall through */ }

		if (!panelOpen && cfg && cfg.autoOpen) surfaceLatest();
	}

	/* ------------------------------------------------------------------
	   Draggable + resizable panel, remembered per device (v1.25.4)

	   Geometry is stored in localStorage, NOT on the server. Window position
	   and size are a property of the screen you are sitting at, not of your
	   account: a layout saved on a 1920px monitor is wrong on a 1366px laptop
	   and meaningless on a phone, so syncing it across devices would import a
	   bad layout everywhere. localStorage also works for logged-out visitors
	   and costs no REST calls. The key is namespaced by user id so two
	   accounts on a shared computer do not inherit each other's layout.

	   Movement uses right/bottom offsets and never `transform`, because the
	   open animation (zc-pop-in) already animates transform and the two would
	   fight. Right/bottom anchoring also keeps the panel tethered to its
	   launcher corner instead of drifting when the viewport changes.
	   ------------------------------------------------------------------ */
	var GEO_VER = 1;
	var GEO_KEY = null;
	var geoEnabled = false;
	// There is no artificial ceiling: the popup may be grown to the full
	// viewport less an 8px breathing margin on each edge. The floor exists only
	// because the composer has an intrinsic minimum -- attach 32 + send 48 +
	// textarea 110 + gaps and padding -- below which the row wraps and breaks.
	var GEO_MIN_W = 320, GEO_MIN_H = 300, GEO_EDGE = 8;
	// Touch drags start on a press-and-hold so a tap or a scroll flick is never
	// mistaken for a drag. GEO_SLOP is how far a finger may wander during the
	// hold before we decide it was a scroll after all.
	var GEO_HOLD_MS = 350, GEO_SLOP = 10;

	// Active at every width. Touch users press and hold the header to pick the
	// window up, so there is no width gate: the popup can be moved and resized
	// on a phone exactly as it can on a desktop.
	function geoActive() { return geoEnabled; }

	function geoRead() {
		try { return JSON.parse(window.localStorage.getItem(GEO_KEY) || "null"); } catch (e) { return null; }
	}
	function geoWrite(g) {
		try { window.localStorage.setItem(GEO_KEY, JSON.stringify(g)); } catch (e) {}
	}
	function geoClear() {
		try { window.localStorage.removeItem(GEO_KEY); } catch (e) {}
	}

	// Clamp on every read and every move so the panel can never be stranded
	// off-screen after a window resize or a switch to a smaller monitor.
	function geoClamp(g) {
		var w = Math.min(Math.max(g.w, GEO_MIN_W), Math.max(GEO_MIN_W, window.innerWidth - GEO_EDGE * 2));
		var h = Math.min(Math.max(g.h, GEO_MIN_H), Math.max(GEO_MIN_H, window.innerHeight - GEO_EDGE * 2));
		var maxR = Math.max(GEO_EDGE, window.innerWidth - w - GEO_EDGE);
		var maxB = Math.max(GEO_EDGE, window.innerHeight - h - GEO_EDGE);
		return {
			v: GEO_VER,
			w: Math.round(w),
			h: Math.round(h),
			r: Math.round(Math.min(Math.max(g.r, GEO_EDGE), maxR)),
			b: Math.round(Math.min(Math.max(g.b, GEO_EDGE), maxB))
		};
	}

	// Switching to position:fixed decouples the panel from the launcher's
	// offsets so the stored numbers are plain viewport coordinates.
	function geoApply(g) {
		if (!panel) return;
		panel.style.position = "fixed";
		panel.style.left = "auto";
		panel.style.top = "auto";
		panel.style.right = g.r + "px";
		panel.style.bottom = g.b + "px";
		panel.style.width = g.w + "px";
		panel.style.height = g.h + "px";
		panel.style.maxWidth = "none";
		panel.style.maxHeight = "none";
	}

	// Drop every inline value so the stylesheet takes over again.
	function geoResetStyles() {
		if (!panel) return;
		var props = ["position", "left", "top", "right", "bottom", "width", "height", "maxWidth", "maxHeight"];
		for (var i = 0; i < props.length; i++) { panel.style[props[i]] = ""; }
	}

	function geoCurrent() {
		var r = panel.getBoundingClientRect();
		return {
			v: GEO_VER,
			w: Math.round(r.width),
			h: Math.round(r.height),
			r: Math.round(window.innerWidth - r.right),
			b: Math.round(window.innerHeight - r.bottom)
		};
	}

	function geoRestore() {
		if (!panel) return;
		if (!geoActive()) { geoResetStyles(); return; }
		var g = geoRead();
		// A stored value from an older schema is discarded rather than guessed
		// at, so changing the default later never strands anyone.
		if (!g || g.v !== GEO_VER) { geoResetStyles(); return; }
		geoApply(geoClamp(g));
	}

	// mode: "move" drags the whole panel; "size" resizes from the top-left.
	// The handle is top-left, not the usual bottom-right, because the panel is
	// anchored bottom-right: a bottom-right grip would sit on the send button
	// and push the panel down into the launcher.
	function geoBindDrag(handle, mode) {
		if (!handle) return;
		var startX = 0, startY = 0, base = null, pid = null, live = false, holdTimer = null;

		function clearHold() {
			if (holdTimer) { clearTimeout(holdTimer); holdTimer = null; }
		}

		function begin() {
			clearHold();
			if (!panel) return;
			live = true;
			try { handle.setPointerCapture(pid); } catch (err) {}
			panel.classList.add("is-zc-dragging");
		}

		handle.addEventListener("pointerdown", function (e) {
			if (!geoActive() || !panel || panel.hidden) return;
			if (e.button != null && e.button !== 0) return;
			// Never hijack the header's own controls (close, expand-to-inbox).
			if (mode === "move" && e.target && e.target.closest && e.target.closest("button,a,input,textarea")) return;
			base = geoCurrent();
			startX = e.clientX; startY = e.clientY; pid = e.pointerId;
			if (e.pointerType === "touch") {
				// Press and hold to pick the window up.
				live = false;
				clearHold();
				holdTimer = setTimeout(begin, GEO_HOLD_MS);
			} else {
				// Mouse and pen: start immediately, no hold needed.
				begin();
			}
			e.preventDefault();
		});

		handle.addEventListener("pointermove", function (e) {
			if (e.pointerId !== pid || !base) return;
			var dx = e.clientX - startX, dy = e.clientY - startY;
			if (!live) {
				// Finger moved before the hold completed: it was a scroll, not a drag.
				if (holdTimer && (Math.abs(dx) > GEO_SLOP || Math.abs(dy) > GEO_SLOP)) clearHold();
				return;
			}
			var g = (mode === "move")
				? { v: GEO_VER, w: base.w, h: base.h, r: base.r - dx, b: base.b - dy }
				: { v: GEO_VER, w: base.w - dx, h: base.h - dy, r: base.r, b: base.b };
			geoApply(geoClamp(g));
		});

		function endDrag(e) {
			clearHold();
			if (!live || (e && e.pointerId !== pid)) return;
			live = false;
			try { handle.releasePointerCapture(pid); } catch (err) {}
			if (panel) panel.classList.remove("is-zc-dragging");
			geoWrite(geoClamp(geoCurrent()));
		}
		handle.addEventListener("pointerup", endDrag);
		handle.addEventListener("pointercancel", endDrag);
	}

	function geoInit(header, handle) {
		if (!root || !panel) return;
		geoEnabled = root.getAttribute("data-zymarg-geometry") === "1";
		GEO_KEY = "zymargLiveChatGeo:" + (root.getAttribute("data-zymarg-user") || "0");
		if (!geoEnabled) { if (handle) handle.hidden = true; return; }
		if (handle) handle.hidden = !geoActive();
		geoBindDrag(header, "move");
		geoBindDrag(handle, "size");

		// Escape hatch: double-click the header to snap back to the default.
		if (header) {
			header.addEventListener("dblclick", function (e) {
				if (e.target && e.target.closest && e.target.closest("button,a")) return;
				geoClear();
				geoResetStyles();
			});
		}

		window.addEventListener("resize", function () {
			if (handle) handle.hidden = !geoActive();
			if (panel && !panel.hidden) geoRestore();
		});
	}

	function setTitle(text) {
		if (!titleEl) return;

		// Support conversations always render a fixed brand label instead of
		// the counterpart's display name. support.js stamps
		// `data-context="support"` on the popup root when it hands a support
		// thread over, so we key off that. Buyer↔vendor chats — where the
		// counterpart IS the person you're talking to — keep their existing
		// title behaviour unchanged.
		//
		// The literal comes from the localised bootstrap payload
		// (`zymargLiveChat.i18n.supportTitle`), so translators can override it
		// without touching this file.
		if (root && "support" === root.getAttribute("data-context")) {
			var supportTitle = (cfg && cfg.i18n && cfg.i18n.supportTitle) || "Support team";
			titleEl.textContent = supportTitle;
			return;
		}

		if (text) titleEl.textContent = text;
	}

	// Reflect the unread total in the browser tab title, e.g. "(3) My Account".
	// Idempotent: strips any existing "(n) " prefix before re-applying.
	function setTabBadge(n) {
		if (typeof document === "undefined") return;
		var clean = (document.title || "").replace(/^\(\d+\+?\)\s*/, "");
		document.title = n > 0 ? "(" + (String(n)) + ") " + clean : clean;
	}
	function setBadge(count) {
		var n = parseInt(count, 10) || 0;
		if (badge) {
			if (n <= 0) { badge.hidden = true; badge.textContent = "0"; }
			else { badge.hidden = false; badge.textContent = String(n); }
		}
		// Reflect on any `.zymarg-inbox__unread` badges elsewhere on the page.
		Array.prototype.forEach.call(document.querySelectorAll("[data-zymarg-unread-count]"), function (b) {
			b.hidden = n <= 0;
			b.textContent = String(n);
		});
		setTabBadge(n);
	}

	// WhatsApp-style delivery ticks for the sender's own messages.
	// sending: single tick · delivered: double tick · read: coloured double tick.
	function statusTicks(status) {
		var s = String(status || "delivered").toLowerCase();
		var span = el("span", "zymarg-live-chat__status is-" + s);
		span.textContent = (s === "sending") ? "\u2713" : "\u2713\u2713";
		span.setAttribute("aria-label", s === "read" ? "Read" : (s === "sending" ? "Sending" : "Delivered"));
		return span;
	}

	var reactsEnabled = !cfg || cfg.reactions !== false;
	var repliesEnabled = !cfg || cfg.replies !== false;
	var replyToId = null, replyPreviewEl = null;
	function startReply(m) { if (!m || !m.id) return; replyToId = m.id; renderReplyPreview(String(m.body || "")); if (input) input.focus(); }
	function cancelReply() { replyToId = null; renderReplyPreview(""); }
	function renderReplyPreview(body) {
		if (!form) return;
		if (!replyPreviewEl) {
			replyPreviewEl = el("div", "zymarg-live-chat__reply-preview");
			if (form.parentNode) form.parentNode.insertBefore(replyPreviewEl, form);
		}
		if (!replyToId) { replyPreviewEl.hidden = true; replyPreviewEl.innerHTML = ""; return; }
		replyPreviewEl.hidden = false; replyPreviewEl.innerHTML = "";
		var lbl = el("span", "zymarg-live-chat__reply-preview-text");
		lbl.textContent = "\u21A9 " + (body.length > 60 ? body.slice(0, 60) + "\u2026" : (body || "Attachment"));
		var x = el("button", "zymarg-live-chat__reply-cancel"); x.type = "button"; x.setAttribute("aria-label", "Cancel reply"); x.textContent = "\u00D7";
		x.addEventListener("click", function () { cancelReply(); });
		replyPreviewEl.appendChild(lbl); replyPreviewEl.appendChild(x);
	}
	function buildQuote(parent) {
		var q = el("div", "zymarg-live-chat__quote");
		var b = String((parent && parent.body) || "");
		q.textContent = b.length > 80 ? b.slice(0, 80) + "\u2026" : (b || "Attachment");
		return q;
	}
	var REACT_EMOJIS = ["\uD83D\uDC4D", "\u2764\uFE0F", "\u2705", "\uD83D\uDCE6", "\uD83D\uDE9A", "\u23F3", "\u2753", "\uD83C\uDF89"];
	// Full set behind the "+" button in the reaction bar.
	var REACT_MORE_EMOJIS = ["\uD83D\uDE00", "\uD83D\uDE03", "\uD83D\uDE04", "\uD83D\uDE01", "\uD83D\uDE06", "\uD83D\uDE02", "\uD83D\uDE42", "\uD83D\uDE09", "\uD83D\uDE0A", "\uD83D\uDE0D", "\uD83D\uDE0E", "\uD83E\uDD14", "\uD83D\uDE2E", "\uD83D\uDE22", "\uD83D\uDC4D", "\uD83D\uDC4E", "\uD83D\uDC4F", "\uD83D\uDE4C", "\uD83D\uDE4F", "\uD83D\uDC4B", "\uD83E\uDD1D", "\uD83D\uDC4C", "\uD83D\uDCAA", "\u270C\uFE0F", "\u2764\uFE0F", "\uD83E\uDDE1", "\uD83D\uDC9B", "\uD83D\uDC9A", "\uD83D\uDC99", "\uD83D\uDC9C", "\uD83D\uDD25", "\u2B50", "\u2728", "\u2705", "\uD83D\uDED2", "\uD83D\uDCE6", "\uD83D\uDCB0", "\uD83D\uDCB3", "\uD83D\uDE9A", "\uD83D\uDCF8", "\uD83C\uDF89", "\uD83C\uDF81", "\uD83D\uDCAF", "\uD83C\uDFF7\uFE0F", "\u23F3", "\u2753"];
	function toggleReaction(id, emoji, mine) {
		if (!id) return;
		api("/messages/" + id + "/react", { method: mine ? "DELETE" : "POST", body: { emoji: emoji } })
			.then(function () { refreshMessages(); })
			.catch(function () {});
	}
	function reactionIsMine(m, emo) {
		var mineR = false;
		((m && m.reactions) || []).forEach(function (r) { if (r && r.emoji === emo && Number(r.user_id) === Number(cfg.userId)) mineR = true; });
		return mineR;
	}
	// Reactions render only as pills for messages that have them (no persistent
	// button row). Reply + react are gestures: swipe toward the bubble's own side
	// to reply, long-press to react -- same as Messenger / WhatsApp.
	function buildReactions(m) {
		if (!reactsEnabled) return null;
		var list = (m && m.reactions) || [];
		var map = {}, order = [];
		list.forEach(function (r) {
			var e = r && r.emoji; if (!e) return;
			if (!map[e]) { map[e] = { count: 0, mine: false }; order.push(e); }
			map[e].count++;
			if (Number(r.user_id) === Number(cfg.userId)) map[e].mine = true;
		});
		if (!order.length) return null;
		var wrap = el("div", "zymarg-live-chat__reacts");
		// Collapsed by default: only the most recent reaction sits under the
		// bubble, so bubble height never grows with the reaction count. The
		// "+N" hint on the right expands the full list on demand.
		var latest = null;
		for (var i = list.length - 1; i >= 0; i--) {
			if (list[i] && list[i].emoji && map[list[i].emoji]) { latest = list[i].emoji; break; }
		}
		if (!latest) latest = order[order.length - 1];
		var total = 0;
		order.forEach(function (e) { total += map[e].count; });
		var hidden = total - map[latest].count;
		var expanded = false;
		function makePill(e) {
			var info = map[e];
			var pill = el("button", "zymarg-live-chat__react-pill" + (info.mine ? " is-mine" : ""));
			pill.type = "button"; pill.textContent = e + " " + info.count;
			pill.addEventListener("click", function () { toggleReaction(m.id, e, info.mine); });
			return pill;
		}
		function renderReacts() {
			wrap.textContent = "";
			if (expanded) wrap.classList.remove("is-collapsed");
			else wrap.classList.add("is-collapsed");
			(expanded ? order : [latest]).forEach(function (e) { wrap.appendChild(makePill(e)); });
			if (hidden > 0) {
				var more = el("button", "zymarg-live-chat__reacts-more");
				more.type = "button";
				more.textContent = expanded ? "\u2212" : "+" + hidden;
				more.setAttribute("aria-expanded", expanded ? "true" : "false");
				more.setAttribute("aria-label", expanded ? "Hide reactions" : "Show all reactions");
				more.addEventListener("click", function (ev) {
					ev.stopPropagation();
					expanded = !expanded;
					renderReacts();
				});
				wrap.appendChild(more);
			}
		}
		renderReacts();
		return wrap;
	}
	// Swipe-to-reply (toward the bubble's own side) + long-press-to-react.
	// Pointer Events unify touch and mouse; touch-action:pan-y keeps scroll native.
	function attachGestures(bubble, m) {
		if (!bubble || !m || !m.id) return;
		if (!repliesEnabled && !reactsEnabled) return;
		var mine = bubble.classList.contains("is-mine");
		var dir = mine ? -1 : 1;
		var startX = 0, startY = 0, dx = 0;
		var dragging = false, decided = false, isHoriz = false, moved = false;
		var lpTimer = null, captured = false, pid = null;
		var THRESH = 55, MAX = 90;
		var hint = null, pop = null;
		function ensureHint() {
			if (hint) return hint;
			hint = el("span", "zymarg-live-chat__swipe-hint" + (mine ? " is-right" : " is-left"));
			hint.textContent = "\u21A9"; hint.setAttribute("aria-hidden", "true");
			bubble.appendChild(hint);
			return hint;
		}
		function setDrag(v) {
			dx = v;
			bubble.style.transform = v ? ("translateX(" + v + "px)") : "";
			ensureHint().style.opacity = String(Math.min(1, Math.abs(v) / THRESH));
		}
		function release() {
			bubble.style.transition = "transform .18s ease";
			bubble.style.transform = ""; if (hint) hint.style.opacity = "0"; dx = 0;
			setTimeout(function () { bubble.style.transition = ""; }, 220);
		}
		function clearLP() { if (lpTimer) { clearTimeout(lpTimer); lpTimer = null; } }
		function buildPop() {
			pop = el("div", "zymarg-live-chat__react-pop" + (mine ? " is-right" : " is-left")); pop.hidden = true;
			REACT_EMOJIS.forEach(function (emo) {
				var b = el("button", "zymarg-live-chat__react-opt"); b.type = "button"; b.textContent = emo;
				b.addEventListener("click", function (ev) { ev.stopPropagation(); pop.hidden = true; toggleReaction(m.id, emo, reactionIsMine(m, emo)); });
				pop.appendChild(b);
			});
			// "+" on the right opens the full emoji list for reactions.
			var morePanel = el("div", "zymarg-live-chat__react-panel"); morePanel.hidden = true;
			REACT_MORE_EMOJIS.forEach(function (emo) {
				var o = el("button", "zymarg-live-chat__react-opt"); o.type = "button"; o.textContent = emo;
				o.addEventListener("click", function (ev) { ev.stopPropagation(); morePanel.hidden = true; pop.hidden = true; toggleReaction(m.id, emo, reactionIsMine(m, emo)); });
				morePanel.appendChild(o);
			});
			var moreBtn = el("button", "zymarg-live-chat__react-more"); moreBtn.type = "button"; moreBtn.textContent = "+";
			moreBtn.setAttribute("aria-label", "More reactions");
			moreBtn.addEventListener("click", function (ev) { ev.stopPropagation(); morePanel.hidden = !morePanel.hidden; });
			pop.appendChild(moreBtn);
			pop.appendChild(morePanel);
			bubble.appendChild(pop);
		}
		function openPop() {
			if (!reactsEnabled) return;
			if (!pop) buildPop();
			var others = document.querySelectorAll(".zymarg-live-chat__react-pop:not([hidden])");
			Array.prototype.forEach.call(others, function (p) { p.hidden = true; });
			pop.hidden = false;
			if (navigator.vibrate) { try { navigator.vibrate(12); } catch (e) {} }
			setTimeout(function () {
				var onDoc = function (ev) { if (pop && !pop.contains(ev.target)) { pop.hidden = true; document.removeEventListener("pointerdown", onDoc, true); } };
				document.addEventListener("pointerdown", onDoc, true);
			}, 0);
		}
		bubble.addEventListener("pointerdown", function (e) {
			if (e.pointerType === "mouse" && e.button !== 0) return;
			if (e.target && e.target.closest && e.target.closest("a, button, img, input, textarea, .zymarg-live-chat__reacts, .zymarg-live-chat__react-pop")) return;
			startX = e.clientX; startY = e.clientY; dx = 0;
			dragging = true; decided = false; isHoriz = false; moved = false; pid = e.pointerId;
			if (reactsEnabled) { clearLP(); lpTimer = setTimeout(function () { if (!moved && dragging) { dragging = false; openPop(); } }, 480); }
		});
		bubble.addEventListener("pointermove", function (e) {
			if (!dragging) return;
			var ddx = e.clientX - startX, ddy = e.clientY - startY;
			if (!moved && (Math.abs(ddx) > 6 || Math.abs(ddy) > 6)) { moved = true; clearLP(); }
			if (!decided) {
				if (Math.abs(ddx) < 8 && Math.abs(ddy) < 8) return;
				decided = true; isHoriz = Math.abs(ddx) > Math.abs(ddy) + 2;
				if (isHoriz && repliesEnabled) { try { bubble.setPointerCapture(pid); captured = true; } catch (err) {} }
			}
			if (!isHoriz || !repliesEnabled) return;
			var raw = dir === 1 ? Math.max(0, ddx) : Math.min(0, ddx);
			setDrag(Math.max(-MAX, Math.min(MAX, raw)));
		});
		function endDrag() {
			clearLP();
			if (captured && pid != null) { try { bubble.releasePointerCapture(pid); } catch (err) {} captured = false; }
			var fire = dragging && isHoriz && repliesEnabled && Math.abs(dx) >= THRESH;
			dragging = false;
			if (fire) startReply(m);
			if (isHoriz) release();
		}
		bubble.addEventListener("pointerup", endDrag);
		bubble.addEventListener("pointercancel", endDrag);
	}
	// --- history paging -------------------------------------------------------
	// The endpoint hands back the NEWEST page of a conversation. historyOffset is
	// where that window starts in the full thread, so it doubles as the count of
	// older messages still waiting above it.
	var historyConvId  = null;
	var historyOffset  = 0;
	var historyLoading = false;
	var historyMsgs    = [];

	// Combine two lists, de-duplicated by id and in id order. Later entries win,
	// so a polled copy refreshes the status on one already held.
	function mergeMsgs(existing, incoming) {
		var byId = {};
		var order = [];
		(existing || []).concat(incoming || []).forEach(function (m) {
			if (!m || m.id == null) return;
			var k = String(m.id);
			if (!(k in byId)) order.push(k);
			byId[k] = m;
		});
		return order
			.map(function (k) { return byId[k]; })
			.sort(function (a, b) { return (Number(a.id) || 0) - (Number(b.id) || 0); });
	}

	function nearMsgsBottom() {
		if (!msgsEl) return true;
		return (msgsEl.scrollHeight - msgsEl.scrollTop - msgsEl.clientHeight) < 80;
	}

	// Park on the newest message and hold there while the layout settles (lazy
	// avatars and attachment images change the height after the first paint).
	// Aborts the moment the reader scrolls up.
	function pinMsgsToBottom() {
		if (!msgsEl) return;
		msgsEl.__zymargUserScrolled = false;
		var pin = function () {
			if (!msgsEl || msgsEl.__zymargUserScrolled) return;
			msgsEl.scrollTop = msgsEl.scrollHeight;
		};
		pin();
		if (window.requestAnimationFrame) {
			window.requestAnimationFrame(function () { pin(); window.requestAnimationFrame(pin); });
		}
		[60, 200, 500].forEach(function (t) { setTimeout(pin, t); });
		Array.prototype.forEach.call(msgsEl.querySelectorAll("img"), function (img) {
			if (img.complete) return;
			img.addEventListener("load", pin);
			img.addEventListener("error", pin);
		});
	}

	function bindHistoryScroll() {
		if (!msgsEl || msgsEl.__zymargScrollBound) return;
		msgsEl.__zymargScrollBound = true;
		msgsEl.addEventListener("scroll", function () {
			msgsEl.__zymargUserScrolled = !nearMsgsBottom();
			if (msgsEl.scrollTop <= 48 && msgsEl.scrollHeight > msgsEl.clientHeight + 48) loadOlderMessages();
		});
	}

	function loadOlderMessages() {
		if (historyLoading || !activeConversationId) return;
		var remaining = Math.max(0, Number(historyOffset) || 0);
		if (remaining <= 0) return; // already at the beginning

		historyLoading = true;
		var id         = activeConversationId;
		var take       = Math.min(30, remaining);
		var from       = Math.max(0, remaining - take);
		var prevHeight = msgsEl ? msgsEl.scrollHeight : 0;
		var prevTop    = msgsEl ? msgsEl.scrollTop : 0;

		api("/conversations/" + id + "/messages?limit=" + take + "&offset=" + from)
			.then(function (r) {
				if (String(activeConversationId) !== String(id)) return; // switched threads
				var d = (r && r.data) || r || {};
				var older = d.messages || d.items || (Array.isArray(d) ? d : []);
				if (!Array.isArray(older)) older = [];
				historyOffset = from;
				if (!older.length) return;
				historyMsgs = mergeMsgs(older, historyMsgs);
				// Hold the reader's place now that content was added above them.
				renderMessages(historyMsgs, { keepScroll: { height: prevHeight, top: prevTop } });
			})
			.catch(function () {})
			.then(function () { historyLoading = false; });
	}

	function renderMessages(messages, opts) {
		if (!msgsEl) return;
		msgsEl.innerHTML = "";
		var lastIncomingId = 0;
		var msgById = {};
		(messages || []).forEach(function (mm) { if (mm && mm.id != null) msgById[mm.id] = mm; });
		(messages || []).forEach(function (m) {
			var mine = Number(m.sender_id) === Number(cfg.userId);
			var row = el("div", "zymarg-live-chat__msg" + (mine ? " is-mine" : ""));
			if (repliesEnabled && m.parent_id && msgById[m.parent_id]) row.appendChild(buildQuote(msgById[m.parent_id]));
			row.appendChild(document.createTextNode(m.body || ""));
			if (m.attachments && m.attachments.length) {
				var atts = el("div", "zymarg-live-chat__atts");
				m.attachments.forEach(function (a) {
					if (!a || !a.url) return;
					var link = el("a"); link.href = a.url; link.target = "_blank"; link.rel = "noopener noreferrer";
					if (/^image\//.test(String(a.mime_type || ""))) {
						link.className = "zymarg-live-chat__att is-image";
						var img = el("img"); img.src = a.url; img.alt = a.file_name || "attachment"; img.loading = "lazy";
						link.appendChild(img);
					} else {
						link.className = "zymarg-live-chat__att is-file";
						link.textContent = "\uD83D\uDCCE " + (a.file_name || "attachment");
					}
					atts.appendChild(link);
				});
				row.appendChild(atts);
			}
			if (mine) row.appendChild(statusTicks(m.status));
			else if (m.id) lastIncomingId = Math.max(lastIncomingId, Number(m.id) || 0);
			if ((reactsEnabled || repliesEnabled) && m.id) {
				attachGestures(row, m);
				var rx = buildReactions(m);
				if (rx) row.appendChild(rx);
			}
			msgsEl.appendChild(row);
		});
		bindHistoryScroll();
		opts = opts || {};
		if (opts.keepScroll) {
			var ks = opts.keepScroll;
			var restore = function () {
				msgsEl.scrollTop = Math.max(0, msgsEl.scrollHeight - (ks.height || 0) + (ks.top || 0));
			};
			restore();
			if (window.requestAnimationFrame) window.requestAnimationFrame(restore);
		} else {
			pinMsgsToBottom();
		}
		if (lastIncomingId > 0) markReadUpTo(lastIncomingId);
	}

	// Tell the server the reader has seen incoming messages up to this id so the
	// other party's copies flip to "read". Fire-and-forget; never blocks the UI.
	var lastMarkedRead = {};
	function markReadUpTo(messageId) {
		if (!activeConversationId || !messageId) return;
		var key = String(activeConversationId);
		if (messageId <= (lastMarkedRead[key] || 0)) return;
		lastMarkedRead[key] = messageId;
		api("/conversations/" + activeConversationId + "/read", { method: "PATCH", body: { before_message_id: messageId } })
			.then(refreshUnread)
			.catch(function () { /* silent */ });
	}

	function refreshMessages() {
		if (!activeConversationId) return Promise.resolve();

		// Switched conversation -> forget the previous thread's loaded history.
		if (String(historyConvId) !== String(activeConversationId)) {
			historyConvId  = activeConversationId;
			historyOffset  = 0;
			historyMsgs    = [];
			historyLoading = false;
		}

		var id         = activeConversationId;
		var stick      = nearMsgsBottom();
		var prevHeight = msgsEl ? msgsEl.scrollHeight : 0;
		var prevTop    = msgsEl ? msgsEl.scrollTop : 0;

		return api("/conversations/" + id + "/messages").then(function (r) {
			if (String(activeConversationId) !== String(id)) return; // switched mid-flight
			var d = (r && r.data) || r || {};
			var msgs = d.messages || d.items || (Array.isArray(d) ? d : []);
			if (!Array.isArray(msgs)) msgs = [];
			// Only the first load fixes where our window starts; later polls report a
			// larger offset as the thread grows, which would lose loaded history.
			if (!historyMsgs.length) historyOffset = Math.max(0, Number(d.offset) || 0);
			historyMsgs = mergeMsgs(historyMsgs, msgs);
			// Reading history -> hold their place. Otherwise follow the newest.
			renderMessages(historyMsgs, stick ? null : { keepScroll: { height: prevHeight, top: prevTop } });
		}).catch(function (err) {
			if (window.console && console.warn) console.warn("[ZymargLiveChat] could not load messages:", err);
		});
	}

	// Pick the newest unread conversation (fallback: most recent) and activate it.
	// RESOLVES WITH THE CONVERSATION ID (or null). Callers must check the result:
	// opening the panel without an id produces an empty chat box AND a composer
	// that silently swallows whatever the user types.
	function selectLatestConversation() {
		return api("/conversations").then(function (r) {
			var d = (r && r.data) || r || {};
			var list = d.conversations || d.items || (Array.isArray(d) ? d : []);
			if (!Array.isArray(list)) list = [];
			var target = null, i;
			for (i = 0; i < list.length; i++) {
				if (list[i] && Number(list[i].unread_count) > 0) { target = list[i]; break; }
			}
			if (!target && list.length) target = list[0];
			if (!target) return null;
			var cid = parseInt(target.id != null ? target.id : target.conversation_id, 10);
			if (!cid) return null;
			activeConversationId = cid;
			setTitle(target.title || "Chat");
			return cid;
		}).catch(function (err) {
			// Previously swallowed in total silence, which made this failure
			// impossible to diagnose from the browser console.
			if (window.console && console.warn) console.warn("[ZymargLiveChat] could not load conversations:", err);
			return null;
		});
	}

	function sendMessage(text, file) {
		if (!activeConversationId) return Promise.reject(new Error("no conversation"));
		var body = text || (file ? file.name : "");
		var pid = replyToId;
		return api("/conversations/" + activeConversationId + "/messages", { method: "POST", body: pid ? { body: body, parent_id: pid } : { body: body } })
			.then(function (r) {
				var d = (r && r.data) || r || {};
				var sent = d.message || {};
				if (file && sent && sent.id) return uploadAttachment(file, sent.id);
			})
			.then(function () { cancelReply(); })
			.then(refreshMessages)
			.then(refreshUnread);
	}

	function refreshUnread() {
		// NOTE: /notifications/unread has never been registered by this plugin
		// (see NotificationController::register()), so this 404'd on every poll —
		// the unread badge never updated and the popup never auto-surfaced on a
		// new message. /marketplace/unread-count is the real endpoint; it returns
		// { success, data: { user_id, count } }.
		return api("/marketplace/unread-count").then(function (r) {
			var d = (r && r.data) || r || {};
			var n = Number(d.count != null ? d.count : (r && r.count)) || 0;
			var prev = lastUnread;
			lastUnread = n;
			setBadge(n);
			updateLauncherVisibility();
			// Only a genuine NEW arrival (after the initial seed) announces
			// itself. How it announces is now configurable — see notifyArrival().
			// The historic "fling the panel open" path still exists as the
			// "autoopen" mode and is still gated on cfg.autoOpen, so pages the
			// admin opted in via Communication -> Settings -> General behave
			// exactly as they did before 1.26.0.
			if (seeded && n > prev) notifyArrival(n, prev);
			seeded = true;
		}).catch(function () { /* silent */ });
	}

	function relTime(ts) {
		var s = Math.max(0, Math.floor(Date.now() / 1000) - (Number(ts) || 0));
		if (s < 60) return "just now";
		var m = Math.floor(s / 60); if (m < 60) return m + "m ago";
		var h = Math.floor(m / 60); if (h < 24) return h + "h ago";
		var d = Math.floor(h / 24); if (d < 7) return d + "d ago";
		try { return new Date((Number(ts) || 0) * 1000).toLocaleDateString(); } catch (e) { return d + "d ago"; }
	}

	function sendTypingState(isTyping) {
		if (!activeConversationId) return;
		api("/realtime/typing", { method: "POST", body: { conversation_id: activeConversationId, typing: !!isTyping } }).catch(function () {});
	}

	function startPolling() {
		stopPolling();
		var every = parseInt(cfg.pollInterval, 10) || 15000;
		pollTimer = setInterval(function () {
			refreshUnread();
			if (panel && !panel.hidden && activeConversationId) refreshMessages();
		}, every);
	}
	function stopPolling() {
		if (pollTimer) { clearInterval(pollTimer); pollTimer = null; }
	}

	// Compose a warm first-message greeting for a brand-new store conversation.
	function greetingFor(name) {
		name = (name || "").trim();
		return name
			? "Hi " + name + " \uD83D\uDC4B I'm interested in your products and had a quick question."
			: "Hi \uD83D\uDC4B I'd love to inquire about your products.";
	}

	// Open (or create) the conversation with a store's seller and surface the
	// popup. Called by the storefront [data-chat-btn] buttons via delegation.
	function openWithSeller(sellerId) {
		var id = parseInt(sellerId, 10);
		if (!id) return Promise.resolve();
		return api("/marketplace/store-chat", { method: "POST", body: { seller_id: id } }).then(function (r) {
			var d = (r && r.data) || r || {};
			var convId = d.conversation_id != null ? d.conversation_id : d.conversationId;
			if (convId) activeConversationId = parseInt(convId, 10) || activeConversationId;
			setTitle(d.store_name || d.counterpart_name || "Chat");
			openPanel();
			refreshMessages();
			if (d.is_new && input && !(input.value || "").trim()) {
				input.value = greetingFor(d.counterpart_name || d.store_name);
				input.focus();
			}
		}).catch(function () { /* silent */ });
	}

	// Public API for other scripts (buyer/vendor inbox can open a specific
	// conversation in the popup on click).
	window.zymargLiveChat = Object.assign({}, cfg, {
		open: function (conversationId) {
			activeConversationId = conversationId ? parseInt(conversationId, 10) : activeConversationId;
			openPanel();
		},
		// Alias. support.js historically called `openConversation()` on a
		// mis-cased global, so the method never existed and every Contact Support
		// click fell through to a full page navigation. The probe is fixed, but
		// publishing the name too means any other caller that copied the old
		// signature keeps working instead of failing silently.
		openConversation: function (conversationId) {
			activeConversationId = conversationId ? parseInt(conversationId, 10) : activeConversationId;
			openPanel();
		},
		openWithSeller: openWithSeller,
		close: closePanel,
		minimize: minimizePanel,
		refresh: refreshMessages,
		unread: refreshUnread,
		// Diagnostics: run window.zymargLiveChat.debug() in the browser console
		// to see why the popup is empty without digging through the source.
		debug: function () {
			return {
				autoOpen: !!cfg.autoOpen,
				newMessageBehavior: arrivalMode(),
				supportDelivery: String(cfg.supportDelivery || "auto"),
				conversationId: activeConversationId,
				panelOpen: !!(panel && !panel.hidden),
				minimized: !!minimized,
				dockPosition: dockRead(),
				themeToast: !!(window.ZymargToast && typeof window.ZymargToast.show === "function"),
				hasMessagesBox: !!msgsEl,
				bubblesRendered: msgsEl ? msgsEl.children.length : -1,
				unreadCount: lastUnread
			};
		}
	});

	function wire() {
		root = $("[data-zymarg-live-chat]");
		if (!root) return;
		// If this script is enqueued twice on a page, two rival instances end up
		// sharing one DOM with separate conversation state -- one renders, the
		// other blanks it out. Boot only once.
		if (root.__zymargLiveChatBooted) return;
		root.__zymargLiveChatBooted = true;
		launcher = $("[data-zymarg-live-chat-launcher]", root);
		badge    = $("[data-zymarg-live-chat-badge]",    root);
		panel    = $("[data-zymarg-live-chat-panel]",    root);
		closeBtn = $("[data-zymarg-live-chat-close]",    root);
		msgsEl   = $("[data-zymarg-live-chat-messages]", root);
		typingEl = $("[data-zymarg-live-chat-typing]",   root);
		form     = $("[data-zymarg-live-chat-composer]", root);
		input    = $("[data-zymarg-live-chat-input]",    root);
		sendBtn  = $("[data-zymarg-live-chat-send]",     root);
		titleEl  = $("[data-zymarg-live-chat-title]",    root);
		geoInit($("[data-zymarg-live-chat-header]", root), $("[data-zymarg-live-chat-resize]", root));
		// Grow with the text up to 3 lines, then scroll inside the field.
		// The popup panel is short (540px, less on phones with the keyboard
		// open), so it caps one line lower than the full inbox.
		var TA_MAX_LINES = 3;
		function autoGrow() {
			if (!input) return;
			var cs = window.getComputedStyle(input);
			var lh = parseFloat(cs.lineHeight) || 20;
			var pad = (parseFloat(cs.paddingTop) || 0) + (parseFloat(cs.paddingBottom) || 0);
			var bord = (parseFloat(cs.borderTopWidth) || 0) + (parseFloat(cs.borderBottomWidth) || 0);
			var max = Math.round(lh * TA_MAX_LINES + pad + bord);
			input.style.height = "auto";
			var next = input.scrollHeight + bord;
			input.style.height = Math.min(next, max) + "px";
			input.style.overflowY = next > max ? "auto" : "hidden";
		}
		function resetGrow() {
			if (!input) return;
			input.style.height = "";
			input.style.overflowY = "hidden";
		}
		if (input) {
			input.addEventListener("input", autoGrow);
			// Enter sends (as it did while this was a single-line input);
			// Shift+Enter inserts a newline now that the field can grow.
			input.addEventListener("keydown", function (e) {
				if (e.key !== "Enter" || e.shiftKey || !form) return;
				e.preventDefault();
				if (form.requestSubmit) form.requestSubmit();
				else form.dispatchEvent(new Event("submit", { cancelable: true }));
			});
		}
		var attachBtn  = $("[data-zymarg-live-chat-attach]",      root);
		var fileInput  = $("[data-zymarg-live-chat-file]",        root);
		var attachChip = $("[data-zymarg-live-chat-attach-chip]", root);
		var attachChipName = $("[data-zymarg-live-chat-attach-chip-name]", root) || attachChip;
		var attachChipX = $("[data-zymarg-live-chat-attach-chip-remove]", root);
		var pendingFile = null;
		function clearPendingFile() {
			pendingFile = null;
			if (fileInput) fileInput.value = "";
			if (attachChip) attachChip.hidden = true;
			if (attachChipName) attachChipName.textContent = "";
		}
		if (attachChipX) {
			attachChipX.addEventListener("click", function () {
				clearPendingFile();
				if (input) input.focus();
			});
		}
		if (attachBtn && fileInput) {
			attachBtn.addEventListener("click", function () { fileInput.click(); });
			fileInput.addEventListener("change", function () {
				pendingFile = (fileInput.files && fileInput.files[0]) || null;
				if (attachChip) {
					if (pendingFile) { attachChip.hidden = false; if (attachChipName) attachChipName.textContent = pendingFile.name; }
					else { clearPendingFile(); }
				}
			});
		}

		/**
		 * 1.32.15 — name the typist on a support case.
		 *
		 * The popup already had a TEXT slot here (LiveChat.php renders the static
		 * "Typing…"), so this only swaps its contents when the server supplies a
		 * label and restores the original literal otherwise. The default text is
		 * captured from the DOM rather than hardcoded, so it stays translated.
		 */
		var typingDefaultText = typingEl ? typingEl.textContent : "";
		function applyTypingLabel(label) {
			if (!typingEl) return;
			typingEl.textContent = label || typingDefaultText;
		}

		var typingEnabled = !cfg || cfg.typing_indicator !== false;
		if (typingEnabled && input) {
			input.addEventListener("input", function () {
				if (!activeConversationId) return;
				var now = Date.now();
				if (now - lastTypingSent > 3000) { lastTypingSent = now; sendTypingState(true); }
				if (typingStopTimer) clearTimeout(typingStopTimer);
				typingStopTimer = setTimeout(function () { lastTypingSent = 0; sendTypingState(false); }, 3500);
			});
			typingPollTimer = setInterval(function () {
				if (!typingEl || !panel || panel.hidden || !activeConversationId) { if (typingEl) typingEl.hidden = true; return; }
				api("/realtime/typing-status?conversation_id=" + activeConversationId).then(function (r) {
					var d = (r && r.data) || r || {};
					applyTypingLabel(d.typing ? d.typing_label : "");
					typingEl.hidden = !d.typing;
				}).catch(function () {});
			}, 3000);
		}

		/**
		 * Paint the presence indicator: GREEN DOT ONLY, inline on the header's
		 * first row (1.32.13).
		 *
		 * Until now this logic existed TWICE — once in the 30s poll below and
		 * once in the realtime `presence.update` handler further down — and both
		 * copies printed "Active now" (and "Last seen X ago") for buyer↔vendor
		 * threads while showing a bare dot for support. The text is what forced
		 * the header onto two rows: `.zymarg-live-chat__presence` carried
		 * `flex-basis:100%`, so the label claimed a full row of its own beneath
		 * the title, and on the store page that is a second row of chrome above
		 * a conversation that has not started yet. The dot alone says the same
		 * thing in 8px.
		 *
		 * The label survives where it is actually useful: the vendor's inbox
		 * (inbox.js) still shows the full "Active now" / "Last seen X ago" text
		 * for buyer↔vendor threads, so a shopkeeper working their Messages tab
		 * keeps that detail. This is only the floating popup.
		 *
		 * `title`/`aria-label` keep the meaning available to hover and to screen
		 * readers, so removing the visible text costs no accessibility.
		 */
		function applyPresence(elm, data) {
			if (!elm) return;
			data = data || {};

			if (data.online) {
				elm.hidden = false;
				elm.className = "zymarg-live-chat__presence is-online";
				elm.textContent = "";
				elm.setAttribute("title", "Active now");
				elm.setAttribute("aria-label", "Active now");
				return;
			}

			// Offline, or offline-with-a-last-seen: no status prose at all.
			elm.hidden = true;
			elm.className = "zymarg-live-chat__presence";
			elm.textContent = "";
			elm.removeAttribute("title");
			elm.removeAttribute("aria-label");
		}

		var presenceEnabled = !cfg || cfg.online_status !== false;
		if (presenceEnabled) {
			var beat = function () { api("/realtime/heartbeat", { method: "POST", body: activeConversationId ? { conversation_id: activeConversationId } : {} }).catch(function () {}); };
			beat();
			setInterval(beat, 30000);
			var presenceEl = null;
			if (titleEl && titleEl.parentNode) {
				presenceEl = el("span", "zymarg-live-chat__presence"); presenceEl.hidden = true;
				titleEl.parentNode.appendChild(presenceEl);
				livePresenceEl = presenceEl;
			}
			setInterval(function () {
				if (!presenceEl || !panel || panel.hidden || !activeConversationId) { if (presenceEl) presenceEl.hidden = true; return; }
				api("/realtime/presence-status?conversation_id=" + activeConversationId).then(function (r) {
					// 1.32.13 — one shared painter for both this poll and the
					// realtime push below, dot-only for every context. See
					// applyPresence().
					applyPresence(presenceEl, (r && r.data) || r || {});
				}).catch(function () {});
			}, 30000);
		}

		// Per-user storage keys for the session, the puck position and drafts.
		var uidKey = root.getAttribute("data-zymarg-user") || "0";
		MIN_KEY      = "zymargLiveChatMin:"     + uidKey;
		DOCK_KEY     = "zymargLiveChatDock:"    + uidKey;
		SESSION_KEY  = "zymargLiveChatSession:" + uidKey;
		DRAFT_PREFIX = "zymargLiveChatDraft:"   + uidKey + ":";

		// Read once, before anything mutates it: openPanel() rewrites the session.
		var restored = sessionRead();

		// The launcher is the minimized puck. It stays hidden unless the customer
		// actually minimized -- including across a page load, because parking the
		// chat is meant to survive navigating to the next page.
		if (launcher) {
			// The session record wins when present; MIN_KEY remains the fallback so
			// a chat parked before this version still comes back.
			minimized = restored ? ("min" === restored.state) : readMinState();
			if (minimized && panel) panel.hidden = true;
			updateLauncherVisibility();
			dockRestore();
			dockDragInit();

			launcher.addEventListener("click", function () {
				// A drag that ends over the puck also fires click; consume the
				// verdict from dockDragInit so letting go does not re-open.
				if (dockMoved) { dockMoved = false; return; }
				if (panel.hidden) {
					// Wrapped, not passed by reference: .then(openPanel) would feed
					// the resolved conversation id in as the `restored` flag and
					// silently suppress the focus grab on a real click.
					(activeConversationId ? Promise.resolve() : selectLatestConversation())
						.then(function () { openPanel(); });
				} else {
					// Effectively unreachable (the puck only shows while minimized,
					// and then the panel is already hidden), but "dismiss" is the
					// safe reason: tucking the chat away must not pop a different
					// surface open in its place.
					closePanel("dismiss");
				}
			});
		}

		/*
		 * Re-open a panel that was open when the customer navigated.
		 *
		 * Runs AFTER the launcher block above so updateLauncherVisibility() has
		 * already settled the puck, and openPanel() can flip it back off.
		 *
		 * `true` marks this as a restore rather than a click, so focus is not
		 * stolen on arrival. openPanel() also calls refreshMessages(), which is
		 * what actually re-paints the conversation -- without the stored id there
		 * would be nothing to fetch and the panel would come back blank.
		 */
		if (restored && "open" === restored.state) {
			if (restored.cid > 0) {
				activeConversationId = restored.cid;
				openPanel(true);
			} else {
				// An open session with no conversation would restore an EMPTY
				// panel, which reads as broken. Park it as the puck instead: one
				// click away, and honest about having nothing loaded.
				minimized = true;
				saveMinState(true);
				sessionWrite("min");
				if (panel) panel.hidden = true;
				updateLauncherVisibility();
				dockRestore();
			}
		}

		// Keep the half-typed message alive across navigation. Registered
		// unconditionally -- unlike the typing indicator below, drafts are not
		// behind a feature flag.
		if (input) {
			input.addEventListener("input", draftSaveSoon);
			// Wrapped: a bare listener would hand the blur Event in as `cid`,
			// which parses to NaN and silently saves nothing.
			input.addEventListener("blur", function () { draftSave(); });
		}

		// Minimize — park the chat without ending it.
		var minBtn = $("[data-zymarg-live-chat-min]", root);
		if (minBtn) minBtn.addEventListener("click", minimizePanel);

		// "Open full inbox" — links to the buyer's My Account Messages page.
		//
		// 1.26.0: injected at the FRONT of the controls wrapper, so the order is
		// [expand] [minimize] | [close] and the destructive control is last with
		// a separator before it. Previously this was inserted immediately before
		// close, putting a navigating link 2px from the dismiss button -- the
		// cause of "clicking the cross reloads the page".
		var controls = $("[data-zymarg-live-chat-controls]", root);
		var inboxUrl = (cfg && cfg.inboxUrl) ? String(cfg.inboxUrl) : "";
		if (inboxUrl) {
			var expand = el("a", "zymarg-live-chat__expand");
			expand.href = inboxUrl;
			// 1.30.0: the label no longer promises "leaves this page", because it
			// often does not any more — see the click handler below.
			expand.title = "Open the full inbox";
			expand.setAttribute("aria-label", "Open the full inbox");
			expand.innerHTML = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 3 21 3 21 9"></polyline><polyline points="9 21 3 21 3 15"></polyline><line x1="21" y1="3" x2="14" y2="10"></line><line x1="3" y1="21" x2="10" y2="14"></line></svg>';

			// Prefer a surface already on this page over a page load. Ask first:
			// if a listener claims the expand by calling preventDefault() (that is
			// support.js, when this page has a support inbox to reveal) we stay put
			// and let it take over. Unclaimed, this is the plain link to the full
			// Messages page it has been since 1.26.0.
			expand.addEventListener("click", function (e) {
				if (!emit("popup-expand", { conversationId: activeConversationId }, true)) {
					e.preventDefault();
					closePanel("expand");
				}
			});
			if (controls) {
				controls.insertBefore(expand, controls.firstChild);
			} else if (closeBtn && closeBtn.parentNode) {
				// Older markup with no controls wrapper — keep the previous spot.
				closeBtn.parentNode.insertBefore(expand, closeBtn);
			}
		}
		// The cross means "show me the roomy view if there is one" under the
		// popup-first support flow, so it reports reason "close". Wrapped in a
		// closure because a bare listener would pass the click Event as `reason`.
		if (closeBtn) closeBtn.addEventListener("click", function () { closePanel("close"); });
		// Escape closes the popup when it is open. Reason "dismiss" — the
		// customer wants OUT, so listeners must not reveal a replacement
		// surface. This is the only guaranteed way back to plain browsing.
		document.addEventListener("keydown", function (e) {
			if (e.key === "Escape" && panel && !panel.hidden) closePanel("dismiss");
		});
		if (form) {
			form.addEventListener("submit", function (e) {
				e.preventDefault();
				var text = (input && input.value || "").trim();
				if (!text && !pendingFile) return;
				var theFile = pendingFile;
				if (sendBtn) sendBtn.disabled = true;
				// If the popup somehow opened without a conversation resolved, recover
				// instead of silently throwing away what the user typed.
				var ready = activeConversationId
					? Promise.resolve(activeConversationId)
					: selectLatestConversation();
				ready
					.then(function () {
						if (!activeConversationId) throw new Error("no conversation");
						return sendMessage(text, theFile);
					})
					.then(function () {
						input.value = "";
						resetGrow();
						clearPendingFile();
						// Sent means the draft is spent. Only on success, so a failed
						// send still leaves the text recoverable after a reload.
						draftClear();
					})
					.catch(function (err) { if (window.console && console.warn) console.warn("[ZymargLiveChat] send failed:", err); })
					.then(function () { if (sendBtn) sendBtn.disabled = false; if (input) input.focus(); });
			});
		}

		// Store/product "Chat" buttons live OUTSIDE this container (e.g. the
		// storefront header + hero). Delegate on the document so a click on any
		// [data-chat-btn] opens the popup against that seller. Bound once.
		if (!document.__zymargChatBtnBound) {
			document.__zymargChatBtnBound = true;
			document.addEventListener("click", function (e) {
				var btn = (e.target && e.target.closest) ? e.target.closest("[data-chat-btn]") : null;
				if (!btn) return;
				e.preventDefault();
				openWithSeller(btn.getAttribute("data-seller-id"));
			});
		}

		// \u2500\u2500 Realtime (Pusher) bridge \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
		// Instant delivery when a realtime driver is connected; the background
		// poll below stays as an automatic fallback.
		onRealtime("message.sent", function (payload) {
			payload = payload || {};
			// refreshUnread() surfaces the popup on a genuine new arrival.
			refreshUnread();
			var cid = Number(payload.conversation_id) || 0;
			if (cid && String(cid) === String(activeConversationId) && panel && !panel.hidden) { refreshMessages(); }
		});
		onRealtime("typing.update", function (payload) {
			payload = payload || {};
			if (!typingEl || !panel || panel.hidden) return;
			var cid = Number(payload.conversation_id) || 0;
			if (!cid || String(cid) !== String(activeConversationId)) return;
			if (Number(payload.user_id) === Number(cfg.userId)) return;
			// 1.32.15 — the push carries the persona label for support cases, so a
			// Pusher-driven indicator names the agent immediately instead of
			// showing the generic literal until the next 3s poll renames it.
			applyTypingLabel(payload.typing ? payload.typing_label : "");
			if (payload.typing) {
				typingEl.hidden = false;
				if (liveTypingHideTimer) clearTimeout(liveTypingHideTimer);
				liveTypingHideTimer = setTimeout(function () { if (typingEl) typingEl.hidden = true; }, 4000);
			} else {
				typingEl.hidden = true;
				if (liveTypingHideTimer) clearTimeout(liveTypingHideTimer);
			}
		});
		onRealtime("presence.update", function (payload) {
			payload = payload || {};
			if (!livePresenceEl || !panel || panel.hidden) return;
			var cid = Number(payload.conversation_id) || 0;
			if (!cid || String(cid) !== String(activeConversationId)) return;
			if (Number(payload.user_id) === Number(cfg.userId)) return;
			// 1.32.13 — same painter as the poll above. Note this now also acts
			// on an `online:false` push, which previously did nothing at all and
			// left a stale dot lit until the next 30s poll caught up.
			applyPresence(livePresenceEl, payload);
		});

		// Background poll runs continuously so a new message can surface the popup
		// even while the panel is closed and the launcher is hidden.
		startPolling();
		refreshUnread();
	}

	if (document.readyState === "loading") {
		document.addEventListener("DOMContentLoaded", wire);
	} else {
		wire();
	}
})();
