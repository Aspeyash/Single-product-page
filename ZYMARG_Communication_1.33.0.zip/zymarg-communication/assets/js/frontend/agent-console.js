/**
 * ZYMARG Communication — Agent console drawer (1.28.0).
 *
 * The admin-bar "Support (N)" node opens this drawer on the frontend so an
 * agent can triage and reply without going into wp-admin. It is pure glue over
 * machinery that already exists:
 *
 *   - the ticket QUEUE comes from /support/queue (+/support/counts for badges);
 *   - the THREAD is the support inbox root rendered into the drawer by
 *     AgentConsole::renderDrawer(), driven by window.zymargInbox.openConversation
 *     (added in 1.26.0);
 *   - the identity / context / history / Resolve-Reopen-Close panel is painted
 *     by support-ticket.js, exactly as on every other support surface.
 *
 * So this file owns only: open/close, the four queue tabs, rendering the queue
 * list, and keeping the badges current.
 *
 * @since 1.28.0
 */
( function () {
	"use strict";

	var CFG = window.zymargAgentConsole || {};
	if ( ! CFG.restUrl ) { return; }

	var REST = String( CFG.restUrl ).replace( /\/$/, "" );
	var T    = CFG.i18n || {};
	function t( k, f ) { return T[ k ] || f; }

	function esc( s ) {
		return String( s == null ? "" : s ).replace( /[&<>"']/g, function ( c ) {
			return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ c ];
		} );
	}

	function getJSON( path ) {
		return fetch( REST + path, {
			headers: { "X-WP-Nonce": CFG.nonce || "" },
			credentials: "same-origin"
		} ).then( function ( r ) {
			if ( ! r.ok ) { throw new Error( "HTTP " + r.status ); }
			return r.json();
		} );
	}

	var drawer, scrim, queueEl, threadEl, tabsEl, currentFilter = "needs", selectedId = 0;

	/* filter -> query string for /support/queue */
	function queryFor( filter ) {
		switch ( filter ) {
			case "mine":     return "?scope=mine&status=open&limit=100";
			case "waiting":  return "?status=awaiting_user&limit=100";
			case "resolved": return "?status=resolved&limit=100";
			case "needs":
			default:         return "?status=awaiting_agent&limit=100";
		}
	}

	function root() { return document.querySelector( "[data-zymarg-ac]" ); }

	function open() {
		if ( ! drawer ) { return; }
		drawer.hidden = false;
		drawer.setAttribute( "aria-hidden", "false" );
		document.body.classList.add( "zymarg-ac-open" );
		loadQueue( currentFilter );
		refreshCounts();
	}
	function close() {
		if ( ! drawer ) { return; }
		drawer.hidden = true;
		drawer.setAttribute( "aria-hidden", "true" );
		document.body.classList.remove( "zymarg-ac-open" );
	}
	function toggle() { if ( drawer && drawer.hidden ) { open(); } else { close(); } }

	function renderQueue( rows ) {
		if ( ! queueEl ) { return; }
		if ( ! rows || ! rows.length ) {
			queueEl.innerHTML = '<div class="zymarg-ac__empty">' + esc( t( "empty", "Nothing here right now." ) ) + "</div>";
			return;
		}
		var html = "";
		rows.forEach( function ( r ) {
			var when = ( r.updated_at || "" ).replace( "T", " " ).substring( 0, 16 );
			// 1.32.15 — how long this person has been waiting on US. Only present
			// while the case awaits an agent, so a case waiting on the customer
			// still shows the plain timestamp and nothing accuses the team.
			var wait = r.waiting && r.waiting.label ? r.waiting : null;
			html += '<button type="button" class="zymarg-ac__row' + ( r.conversation_id === selectedId ? " is-active" : "" ) +
				'" data-ac-open="' + r.conversation_id + '">' +
				'<span class="zymarg-ac__row-top">' +
					'<span class="zymarg-ac__row-name">' + esc( r.requester_name || ( "#" + r.conversation_id ) ) + "</span>" +
					'<span class="zymarg-ticket__pill zymarg-ticket__pill--' + esc( r.tone || "muted" ) + '">' + esc( r.status_label || "" ) + "</span>" +
				"</span>" +
				'<span class="zymarg-ac__row-sub">' +
					esc( r.topic || r.subject || "" ) +
					( r.order_id ? ' · #' + esc( r.order_id ) : "" ) +
					( r.escalation_count ? ' · <span class="zymarg-ac__esc">' + t( "escalated", "escalated" ) + "</span>" : "" ) +
				"</span>" +
				( wait
					? '<span class="zymarg-ac__row-wait is-' + esc( wait.tone || "ok" ) + '" title="' +
						esc( t( "waitingTitle", "Waiting for a reply from your team" ) ) + '">' +
						esc( t( "waitingPrefix", "waiting" ) ) + " " + esc( wait.label ) + "</span>"
					: ( when ? '<span class="zymarg-ac__row-when">' + esc( when ) + "</span>" : "" ) ) +
				"</button>";
		} );
		queueEl.innerHTML = html;

		Array.prototype.forEach.call( queueEl.querySelectorAll( "[data-ac-open]" ), function ( b ) {
			b.addEventListener( "click", function () {
				openTicket( parseInt( b.getAttribute( "data-ac-open" ), 10 ) );
			} );
		} );
	}

	function loadQueue( filter ) {
		currentFilter = filter;
		if ( queueEl ) { queueEl.innerHTML = '<div class="zymarg-ac__loading">' + esc( t( "loading", "Loading…" ) ) + "</div>"; }
		getJSON( "/support/queue" + queryFor( filter ) )
			.then( function ( res ) {
				var d = ( res && res.data ) || res || {};
				renderQueue( d.tickets || [] );
				if ( d.counts ) { paintCounts( d.counts ); }
			} )
			.catch( function () {
				if ( queueEl ) { queueEl.innerHTML = '<div class="zymarg-ac__empty">' + esc( t( "empty", "Nothing here right now." ) ) + "</div>"; }
			} );
	}

	function openTicket( conversationId ) {
		if ( ! conversationId || ! threadEl ) { return; }
		selectedId = conversationId;

		// Highlight the active row.
		Array.prototype.forEach.call( queueEl.querySelectorAll( "[data-ac-open]" ), function ( b ) {
			b.classList.toggle( "is-active", parseInt( b.getAttribute( "data-ac-open" ), 10 ) === conversationId );
		} );

		var inboxRoot = threadEl.querySelector( '[data-zymarg-inbox]' );
		if ( inboxRoot && window.zymargInbox && typeof window.zymargInbox.openConversation === "function" ) {
			window.zymargInbox.openConversation( conversationId, inboxRoot );
		}
		drawer.classList.add( "zymarg-ac--has-thread" );
	}

	function paintCounts( counts ) {
		var needs = document.querySelector( '[data-ac-count="needs"]' );
		if ( needs ) {
			var n = ( counts && counts.awaiting_agent ) || 0;
			needs.textContent = n > 0 ? String( n ) : "";
			needs.hidden = ! ( n > 0 );
		}
		// Admin-bar badge = total open.
		var badge = document.querySelector( "[data-zymarg-ac-badge]" );
		if ( badge ) {
			var open = ( counts && counts.open ) || 0;
			badge.textContent = String( open );
			badge.hidden = ! ( open > 0 );
		}
	}

	function refreshCounts() {
		getJSON( "/support/counts" )
			.then( function ( res ) {
				var d = ( res && res.data ) || res || {};
				if ( d.counts ) { paintCounts( d.counts ); }
			} )
			.catch( function () {} );
	}

	function bindTabs() {
		if ( ! tabsEl ) { return; }
		Array.prototype.forEach.call( tabsEl.querySelectorAll( "[data-ac-filter]" ), function ( tab ) {
			tab.addEventListener( "click", function () {
				Array.prototype.forEach.call( tabsEl.querySelectorAll( "[data-ac-filter]" ), function ( x ) { x.classList.remove( "is-active" ); } );
				tab.classList.add( "is-active" );
				loadQueue( tab.getAttribute( "data-ac-filter" ) );
			} );
		} );
	}

	function bindAdminBar() {
		var node = CFG.nodeId ? document.getElementById( "wp-admin-bar-" + CFG.nodeId ) : null;
		if ( ! node ) { return; }
		var link = node.querySelector( "a.ab-item" ) || node.querySelector( "a" );
		if ( ! link ) { return; }
		// On the frontend, hijack the click to open the drawer instead of
		// navigating to wp-admin. (In wp-admin this script never loads, so the
		// link keeps working as a normal link there.)
		link.addEventListener( "click", function ( e ) {
			e.preventDefault();
			toggle();
		} );
	}

	function boot() {
		drawer   = root();
		if ( ! drawer ) { return; }
		scrim    = drawer.querySelector( "[data-zymarg-ac-scrim]" );
		queueEl  = drawer.querySelector( "[data-zymarg-ac-queue]" );
		threadEl = drawer.querySelector( "[data-zymarg-ac-thread]" );
		tabsEl   = drawer.querySelector( "[data-zymarg-ac-tabs]" );

		bindTabs();
		bindAdminBar();

		var closeBtn = drawer.querySelector( "[data-zymarg-ac-close]" );
		if ( closeBtn ) { closeBtn.addEventListener( "click", close ); }
		if ( scrim ) { scrim.addEventListener( "click", close ); }
		document.addEventListener( "keydown", function ( e ) {
			if ( "Escape" === e.key && drawer && ! drawer.hidden ) { close(); }
		} );

		// Keep the badge fresh even while the drawer is shut.
		refreshCounts();
		var every = Math.max( 15000, parseInt( CFG.pollMs, 10 ) || 30000 );
		setInterval( function () {
			refreshCounts();
			if ( drawer && ! drawer.hidden ) { loadQueue( currentFilter ); }
		}, every );

		// Instant badge on a new message, at zero extra cost.
		//
		// RealtimeHooks ALREADY broadcasts 'message.sent' to every other
		// participant's private channel, and the realtime client is already
		// connected and subscribed. Riding that existing event makes the case
		// that actually matters — a customer just wrote — appear immediately,
		// without publishing any new Pusher events, opening any new connection
		// or touching the message quota. The interval above stays as the safety
		// net: it still catches status changes (resolve/close/escalate) and
		// covers any moment the realtime transport is unavailable, so nothing
		// depends on Pusher being configured or reachable.
		onRealtime( 'message.sent', function () {
			refreshCounts();
			if ( drawer && ! drawer.hidden ) { loadQueue( currentFilter ); }
		} );
	}

	/**
	 * Subscribe to the shared realtime bus once it exists. realtime.js loads
	 * independently, so retry briefly in case this evaluates first. A no-op when
	 * realtime is unavailable — the poll already covers that case.
	 */
	function onRealtime( event, handler ) {
		function bind() {
			var rt = window.ZymargComm && window.ZymargComm.realtime;
			if ( rt && typeof rt.on === 'function' ) { rt.on( event, handler ); return true; }
			return false;
		}
		if ( bind() ) { return; }
		var tries = 0;
		var t = setInterval( function () { if ( bind() || ++tries > 20 ) { clearInterval( t ); } }, 250 );
	}

	if ( document.readyState === "loading" ) {
		document.addEventListener( "DOMContentLoaded", boot );
	} else {
		boot();
	}
} )();
