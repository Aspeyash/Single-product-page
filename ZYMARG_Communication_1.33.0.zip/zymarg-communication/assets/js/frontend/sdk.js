/**
 * ZYMARG Communication — JavaScript SDK.
 *
 * Exposes `window.ZymargComm` so third-party themes and plugins can drive
 * conversations, messages, realtime, notifications, and feature flags from
 * the frontend. All methods return Promises.
 *
 * Configuration is provided by wp_localize_script under
 * `window.ZymargCommSdkConfig`:
 *   {
 *     restUrl:    '<site>/wp-json/zymarg-comm/v1',
 *     nonce:      'wp-rest-nonce',
 *     userId:     123,
 *     apiKey:     'zc_...'   // optional — for non-cookie contexts.
 *   }
 *
 * No jQuery. Vanilla only. Uses fetch + AbortController.
 *
 * @package ZymargCommunication
 */
( function ( global ) {
	'use strict';

	var cfg = global.ZymargCommSdkConfig || {};
	var base = ( cfg.restUrl || '' ).replace( /\/+$/, '' );

	function buildUrl( path, params ) {
		var url = base + '/' + String( path || '' ).replace( /^\/+/, '' );
		if ( params && typeof params === 'object' ) {
			var qs = [];
			for ( var k in params ) {
				if ( ! Object.prototype.hasOwnProperty.call( params, k ) ) continue;
				if ( params[ k ] === undefined || params[ k ] === null ) continue;
				qs.push( encodeURIComponent( k ) + '=' + encodeURIComponent( params[ k ] ) );
			}
			if ( qs.length ) url += ( url.indexOf( '?' ) === -1 ? '?' : '&' ) + qs.join( '&' );
		}
		return url;
	}

	function request( method, path, opts ) {
		opts = opts || {};
		var url  = buildUrl( path, opts.query );
		var init = {
			method:      method,
			credentials: 'same-origin',
			headers:     { 'Accept': 'application/json' }
		};
		if ( cfg.nonce ) init.headers[ 'X-WP-Nonce' ] = cfg.nonce;
		if ( cfg.apiKey ) init.headers[ 'Authorization' ] = 'Bearer ' + cfg.apiKey;
		if ( opts.body !== undefined ) {
			init.headers[ 'Content-Type' ] = 'application/json';
			init.body = JSON.stringify( opts.body );
		}
		if ( opts.signal ) init.signal = opts.signal;

		return fetch( url, init ).then( function ( response ) {
			return response.json().then( function ( body ) {
				if ( ! response.ok ) {
					var err = new Error( ( body && body.message ) || ( 'HTTP ' + response.status ) );
					err.status = response.status;
					err.code   = body && body.code;
					err.data   = body;
					throw err;
				}
				return body && Object.prototype.hasOwnProperty.call( body, 'data' ) ? body.data : body;
			}, function () {
				if ( ! response.ok ) {
					var err = new Error( 'HTTP ' + response.status );
					err.status = response.status;
					throw err;
				}
				return null;
			} );
		} );
	}

	var get    = function ( path, query ) { return request( 'GET',    path, { query: query } ); };
	var post   = function ( path, body )  { return request( 'POST',   path, { body:  body  } ); };
	var del    = function ( path )        { return request( 'DELETE', path, {} ); };
	var patch  = function ( path, body )  { return request( 'PATCH',  path, { body:  body  } ); };

	// ── Realtime bridge ──────────────────────────────────────────────────────
	var realtime = ( function () {
		var existing = global.ZymargComm && global.ZymargComm.realtime;

		var api = {
			connect:    function ()          { return existing && existing.connect    ? existing.connect()          : Promise.resolve(); },
			disconnect: function ()          { return existing && existing.disconnect ? existing.disconnect()       : Promise.resolve(); },
			on:         function ( ev, fn )  { return existing && existing.on         ? existing.on( ev, fn )       : undefined; },
			off:        function ( ev, fn )  { return existing && existing.off        ? existing.off( ev, fn )      : undefined; }
		};
		return api;
	}() );

	// ── Public surface ───────────────────────────────────────────────────────
	var ZymargComm = {
		version: '1.9.0',
		config:  cfg,

		conversations: {
			list:    function ( params ) { return get( '/conversations', params ); },
			open:    function ( id )     { return get( '/conversations/' + encodeURIComponent( id ) ); },
			create:  function ( body )   { return post( '/conversations', body ); },
			close:   function ( id )     { return post( '/conversations/' + encodeURIComponent( id ) + '/close', {} ); },
			archive: function ( id )     { return post( '/conversations/' + encodeURIComponent( id ) + '/archive', {} ); },
			pin:     function ( id, pinned ) { return post( '/conversations/' + encodeURIComponent( id ) + '/pin', { pinned: !! pinned } ); }
		},

		messages: {
			list: function ( conversationId, params ) {
				return get( '/conversations/' + encodeURIComponent( conversationId ) + '/messages', params );
			},
			send: function ( conversationId, body, parentId ) {
				var payload = ( typeof body === 'string' ) ? { body: body } : ( body || {} );
				if ( parentId ) payload.parent_id = parentId;
				return post( '/conversations/' + encodeURIComponent( conversationId ) + '/messages', payload );
			},
			edit: function ( messageId, body ) {
				return patch( '/messages/' + encodeURIComponent( messageId ), { body: body } );
			},
			remove: function ( messageId ) {
				return del( '/messages/' + encodeURIComponent( messageId ) );
			},
			react: function ( messageId, emoji ) {
				return post( '/messages/' + encodeURIComponent( messageId ) + '/reactions', { emoji: emoji } );
			}
		},

		notifications: {
			list:      function ( params ) { return get( '/notifications', params ); },
			markRead:  function ( id )     { return post( '/notifications/' + encodeURIComponent( id ) + '/read', {} ); },
			markAllRead: function ()       { return post( '/notifications/read-all', {} ); },
			preferences: {
				get: function ()          { return get( '/notifications/preferences' ); },
				set: function ( prefs )   { return patch( '/notifications/preferences', prefs ); }
			}
		},

		flags: {
			getAll:    function ()      { return get( '/flags/public' ); },
			isEnabled: function ( key ) {
				return get( '/flags/public' ).then( function ( flags ) {
					if ( ! flags ) return false;
					if ( Array.isArray( flags ) ) {
						for ( var i = 0; i < flags.length; i++ ) {
							if ( flags[ i ] && flags[ i ].flag_key === key ) return !! flags[ i ].is_enabled;
						}
						return false;
					}
					return !! flags[ key ];
				} );
			}
		},

		developer: {
			webhooks: {
				list:   function ( params ) { return get( '/developer/webhooks', params ); },
				create: function ( body )   { return post( '/developer/webhooks', body ); },
				remove: function ( id )     { return del( '/developer/webhooks/' + encodeURIComponent( id ) ); }
			},
			keys: {
				list:   function ()     { return get( '/developer/keys' ); },
				create: function ( body ) { return post( '/developer/keys', body ); },
				revoke: function ( id ) { return del( '/developer/keys/' + encodeURIComponent( id ) ); }
			},
			events: function () { return get( '/developer/events' ); }
		},

		help: {
			guide:           function ( audience ) { return get( '/help/guide/' + encodeURIComponent( audience || 'user' ) ); },
			troubleshooting: function ()           { return get( '/help/troubleshooting' ); },
			docs:            function ( topic )    { return get( '/help/docs/' + encodeURIComponent( topic || 'rest' ) ); },
			changelog:       function ()           { return get( '/help/changelog' ); },
			faq: {
				list:   function ()          { return get( '/help/faq' ); },
				get:    function ( slug )    { return get( '/help/faq/' + encodeURIComponent( slug ) ); },
				save:   function ( body )    { return post( '/help/faq', body ); },
				remove: function ( slug )    { return del( '/help/faq/' + encodeURIComponent( slug ) ); }
			}
		},

		realtime: realtime,

		// Low-level escape hatches so power users can call any endpoint the SDK
		// has not wrapped yet without patching the SDK.
		_get:   get,
		_post:  post,
		_patch: patch,
		_del:   del
	};

	global.ZymargComm = ZymargComm;

	if ( typeof global.dispatchEvent === 'function' && typeof global.CustomEvent === 'function' ) {
		try {
			global.dispatchEvent( new CustomEvent( 'zymarg-comm:sdk-ready', { detail: ZymargComm } ) );
		} catch ( e ) { /* swallow */ }
	}
}( typeof window !== 'undefined' ? window : globalThis ) );
