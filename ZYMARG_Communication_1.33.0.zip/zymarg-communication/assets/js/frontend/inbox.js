/*!
 * ZYMARG Communication — Inbox hydration client (v1.12.27).
 * Vanilla JavaScript. No jQuery.
 *
 * Hydrates every `[data-zymarg-inbox]` root on the page against the REST
 * namespace `zymarg-comm/v1`. Handles list rendering, thread loading,
 * search, filters, composer, and delegated click events. Compatible with
 * the theme's SPA-style AJAX section swapping (re-hydrates when the DOM
 * gets replaced).
 */
(function () {
	"use strict";

	var HYDRATED = "__zymargInboxHydrated";

	// Matches live-chat.js cfg.pollInterval (15s) so the inbox surface and the
	// store popup stay in step. The inbox previously had NO refresh loop at all,
	// which is why incoming messages only appeared on a click or a page reload.
	var POLL_INTERVAL = 15000;

	function attr(el, name) { return el.getAttribute(name) || ""; }
	function $(root, sel) { return root.querySelector(sel); }
	function $$(root, sel) { return Array.prototype.slice.call(root.querySelectorAll(sel)); }
	function el(tag, cls, text) {
		var n = document.createElement(tag);
		if (cls) n.className = cls;
		if (text != null) n.textContent = text;
		return n;
	}
	function fmtTime(ts) {
		if (!ts) return "";
		var d = new Date(ts);
		if (isNaN(d.getTime())) return "";
		var now = new Date();
		if (d.toDateString() === now.toDateString()) {
			return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
		}
		return d.toLocaleDateString();
	}

	// Upload a file to a message via multipart. Never set Content-Type manually —
	// the browser must add the multipart boundary itself.
	function uploadAttachment(root, file, messageId) {
		var base  = attr(root, "data-rest");
		var nonce = attr(root, "data-nonce");
		var url   = base.replace(/\/$/, "") + "/attachments";
		var fd = new FormData();
		fd.append("file", file);
		if (messageId) fd.append("message_id", String(messageId));
		return fetch(url, { method: "POST", headers: { "X-WP-Nonce": nonce }, credentials: "same-origin", body: fd })
			.then(function (r) { if (!r.ok) throw new Error("HTTP " + r.status); return r.json(); });
	}
	function api(root, path, opts) {
		opts = opts || {};
		var base  = attr(root, "data-rest");
		var nonce = attr(root, "data-nonce");
		var url   = base.replace(/\/$/, "") + path;
		var init  = {
			method: opts.method || "GET",
			headers: { "X-WP-Nonce": nonce, "Content-Type": "application/json" },
			credentials: "same-origin"
		};
		if (opts.body) init.body = JSON.stringify(opts.body);
		return fetch(url, init).then(function (r) {
			if (!r.ok) throw new Error("HTTP " + r.status);
			return r.json();
		});
	}

	function relTime(ts) {
		var s = Math.max(0, Math.floor(Date.now() / 1000) - (Number(ts) || 0));
		if (s < 60) return "just now";
		var m = Math.floor(s / 60); if (m < 60) return m + "m ago";
		var h = Math.floor(m / 60); if (h < 24) return h + "h ago";
		var d = Math.floor(h / 24); if (d < 7) return d + "d ago";
		try { return new Date((Number(ts) || 0) * 1000).toLocaleDateString(); } catch (e) { return d + "d ago"; }
	}

	// Subscribe to the shared realtime bus (window.ZymargComm.realtime) once it
	// exists. realtime.js loads independently, so retry briefly in case this
	// script evaluates first. Handlers are also fed by the polling driver, which
	// unifies instant (Pusher) and fallback delivery.
	function onRealtime(event, handler) {
		function bind() {
			var rt = window.ZymargComm && window.ZymargComm.realtime;
			if (rt && typeof rt.on === "function") { rt.on(event, handler); return true; }
			return false;
		}
		if (bind()) return;
		var tries = 0;
		var t = setInterval(function () { if (bind() || ++tries > 20) clearInterval(t); }, 250);
	}

	function hydrate(root) {
		if (root[HYDRATED]) return;
		root[HYDRATED] = true;

		var presenceEnabled = attr(root, "data-presence") !== "0";
		if (presenceEnabled) {
			var beat = function () {
				var hb = (typeof state !== "undefined" && state && state.activeId) ? { conversation_id: state.activeId } : {};
				api(root, "/realtime/heartbeat", { method: "POST", body: hb }).catch(function () {});
			};
			beat();
			if (root.__zymargBeat) clearInterval(root.__zymargBeat);
			root.__zymargBeat = setInterval(beat, 30000);
		}

		var listEl    = $(root, "[data-zymarg-inbox-list]");
		var threadEl  = $(root, "[data-zymarg-inbox-thread]");
		var searchEl  = $(root, "[data-zymarg-inbox-search]");
		var filterEls = $$(root, "[data-zymarg-inbox-filter]");
		var loadingEl = $(root, "[data-zymarg-inbox-loading]");

		var state = {
			userId: parseInt(attr(root, "data-user-id"), 10) || 0,
			side: attr(root, "data-zymarg-inbox") || "buyer",
			conversations: [],
			activeId: null,
			filter: "all",
			search: ""
		};

		// Live handles to the currently rendered thread's typing / presence UI so
		// realtime (Pusher) events can update them instantly.
		var liveTypingInd = null;
		var livePresenceEl = null;
		var liveTypingHideTimer = null;

		function filtered() {
			var q = state.search.trim().toLowerCase();
			return state.conversations.filter(function (c) {
				if (state.filter === "unread" && !c.unread_count) return false;
				if (state.filter === "orders"   && c.context_type !== "order") return false;
				if (state.filter === "products" && c.context_type !== "product") return false;
				if (q) {
					var hay = (c.title || "") + " " + (c.preview || "");
					if (hay.toLowerCase().indexOf(q) < 0) return false;
				}
				return true;
			});
		}

		function buildItemMenu() {
			var actions = el("div", "zymarg-inbox__item-actions");
			var menuBtn = el("button", "zymarg-inbox__item-menu-btn");
			menuBtn.type = "button";
			menuBtn.setAttribute("aria-label", "Conversation options");
			menuBtn.setAttribute("data-inbox-action", "menu-toggle");
			menuBtn.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><circle cx="12" cy="5" r="1.7"></circle><circle cx="12" cy="12" r="1.7"></circle><circle cx="12" cy="19" r="1.7"></circle></svg>';
			var menu = el("div", "zymarg-inbox__item-menu");
			var arch = el("button", "zymarg-inbox__item-menu-item", "Archive");
			arch.type = "button"; arch.setAttribute("data-inbox-action", "archive");
			var rep = el("button", "zymarg-inbox__item-menu-item is-danger", "Report");
			rep.type = "button"; rep.setAttribute("data-inbox-action", "report");
			menu.appendChild(arch); menu.appendChild(rep);
			actions.appendChild(menuBtn); actions.appendChild(menu);
			return actions;
		}

		function renderList() {
			if (!listEl) return;
			listEl.innerHTML = "";
			var rows = filtered();
			if (rows.length === 0) {
				listEl.appendChild(el("div", "zymarg-inbox__list-empty", "No conversations."));
				return;
			}
			rows.forEach(function (c) {
				var item = el("div", "zymarg-inbox__item");
				if (c.unread_count > 0) item.className += " is-unread";
				if (c.id === state.activeId) item.className += " is-active";
				item.setAttribute("data-conversation-id", String(c.id));

				var avatar = el("div", "zymarg-inbox__item-avatar", (c.title || "?").charAt(0).toUpperCase());
				var body   = el("div", "zymarg-inbox__item-body");
				var row    = el("div", "zymarg-inbox__item-row");
				row.appendChild(el("span", "zymarg-inbox__item-name", c.title || "Conversation"));
				row.appendChild(el("span", "zymarg-inbox__item-time", fmtTime(c.last_message_at)));
				body.appendChild(row);
				body.appendChild(el("div", "zymarg-inbox__item-preview", c.preview || ""));
				item.appendChild(avatar);
				item.appendChild(body);
				item.appendChild(buildItemMenu());
				listEl.appendChild(item);
			});
		}

		var reactsEnabled = attr(root, "data-reactions") !== "0";
		var repliesEnabled = attr(root, "data-replies") !== "0";
		var replyState = { to: null, onChange: null };
		function startReply(m) { if (!m) return; replyState.to = m; if (replyState.onChange) replyState.onChange(); }
		function cancelReply() { replyState.to = null; if (replyState.onChange) replyState.onChange(); }
		function buildQuote(parent) {
			var q = el("div", "zymarg-inbox__quote");
			var b = String((parent && parent.body) || "");
			q.textContent = b.length > 90 ? b.slice(0, 90) + "\u2026" : (b || "Attachment");
			return q;
		}
		var REACT_EMOJIS = ["\uD83D\uDC4D", "\u2764\uFE0F", "\u2705", "\uD83D\uDCE6", "\uD83D\uDE9A", "\u23F3", "\u2753", "\uD83C\uDF89"];
		// Full set behind the "+" button in the reaction bar.
		var REACT_MORE_EMOJIS = ["\uD83D\uDE00", "\uD83D\uDE03", "\uD83D\uDE04", "\uD83D\uDE01", "\uD83D\uDE06", "\uD83D\uDE02", "\uD83D\uDE42", "\uD83D\uDE09", "\uD83D\uDE0A", "\uD83D\uDE0D", "\uD83D\uDE0E", "\uD83E\uDD14", "\uD83D\uDE2E", "\uD83D\uDE22", "\uD83D\uDC4D", "\uD83D\uDC4E", "\uD83D\uDC4F", "\uD83D\uDE4C", "\uD83D\uDE4F", "\uD83D\uDC4B", "\uD83E\uDD1D", "\uD83D\uDC4C", "\uD83D\uDCAA", "\u270C\uFE0F", "\u2764\uFE0F", "\uD83E\uDDE1", "\uD83D\uDC9B", "\uD83D\uDC9A", "\uD83D\uDC99", "\uD83D\uDC9C", "\uD83D\uDD25", "\u2B50", "\u2728", "\u2705", "\uD83D\uDED2", "\uD83D\uDCE6", "\uD83D\uDCB0", "\uD83D\uDCB3", "\uD83D\uDE9A", "\uD83D\uDCF8", "\uD83C\uDF89", "\uD83C\uDF81", "\uD83D\uDCAF", "\uD83C\uDFF7\uFE0F", "\u23F3", "\u2753"];
		function toggleReaction(id, emoji, mine) {
			if (!id) return;
			api(root, "/messages/" + id + "/react", { method: mine ? "DELETE" : "POST", body: { emoji: emoji } })
				.then(function () { if (state.activeId) loadThread(state.activeId); })
				.catch(function () {});
		}
		function reactionIsMine(m, emo) {
			var mineR = false;
			((m && m.reactions) || []).forEach(function (r) { if (r && r.emoji === emo && Number(r.user_id) === Number(state.userId)) mineR = true; });
			return mineR;
		}
		// Reactions now render only as pills for messages that actually have them
		// (no persistent button row under every bubble). Reply + react are gestures:
		// swipe the bubble toward its own side to reply, long-press to react.
		function buildReactions(m) {
			if (!reactsEnabled) return null;
			var list = (m && m.reactions) || [];
			var map = {}, order = [];
			list.forEach(function (r) {
				var e = r && r.emoji; if (!e) return;
				if (!map[e]) { map[e] = { count: 0, mine: false }; order.push(e); }
				map[e].count++;
				if (Number(r.user_id) === Number(state.userId)) map[e].mine = true;
			});
			if (!order.length) return null;
			var wrap = el("div", "zymarg-inbox__reacts");
			// Collapsed by default: only the most recent reaction sits under the
			// bubble, so bubble height never grows with the reaction count. The
			// "+N" hint on the right expands the full list on demand.
			var latest = null;
			for (var i = list.length - 1; i >= 0; i--) {
				if (list[i] && list[i].emoji && map[list[i].emoji]) { latest = list[i].emoji; break; }
			}
			if (!latest) latest = order[order.length - 1];
			var total = 0;
			order.forEach(function (e) { total += map[e].count; });
			var hidden = total - map[latest].count;
			var expanded = false;
			function makePill(e) {
				var info = map[e];
				var pill = el("button", "zymarg-inbox__react-pill" + (info.mine ? " is-mine" : ""));
				pill.type = "button"; pill.textContent = e + " " + info.count;
				pill.addEventListener("click", function () { toggleReaction(m.id, e, info.mine); });
				return pill;
			}
			function renderReacts() {
				wrap.textContent = "";
				if (expanded) wrap.classList.remove("is-collapsed");
				else wrap.classList.add("is-collapsed");
				(expanded ? order : [latest]).forEach(function (e) { wrap.appendChild(makePill(e)); });
				if (hidden > 0) {
					var more = el("button", "zymarg-inbox__reacts-more");
					more.type = "button";
					more.textContent = expanded ? "\u2212" : "+" + hidden;
					more.setAttribute("aria-expanded", expanded ? "true" : "false");
					more.setAttribute("aria-label", expanded ? "Hide reactions" : "Show all reactions");
					more.addEventListener("click", function (ev) {
						ev.stopPropagation();
						expanded = !expanded;
						renderReacts();
					});
					wrap.appendChild(more);
				}
			}
			renderReacts();
			return wrap;
		}
		// Swipe-to-reply (toward the bubble's own side) + long-press-to-react,
		// mirroring Messenger / WhatsApp. Uses Pointer Events so touch and mouse
		// share one path; touch-action:pan-y (CSS) keeps vertical scrolling native.
		function attachGestures(bubble, m) {
			if (!bubble || !m || !m.id) return;
			if (!repliesEnabled && !reactsEnabled) return;
			var mine = bubble.classList.contains("is-mine");
			var dir = mine ? -1 : 1;
			var startX = 0, startY = 0, dx = 0;
			var dragging = false, decided = false, isHoriz = false, moved = false;
			var lpTimer = null, captured = false, pid = null;
			var THRESH = 55, MAX = 90;
			var hint = null, pop = null;
			function ensureHint() {
				if (hint) return hint;
				hint = el("span", "zymarg-inbox__swipe-hint" + (mine ? " is-right" : " is-left"));
				hint.textContent = "\u21A9"; hint.setAttribute("aria-hidden", "true");
				bubble.appendChild(hint);
				return hint;
			}
			function setDrag(v) {
				dx = v;
				bubble.style.transform = v ? ("translateX(" + v + "px)") : "";
				ensureHint().style.opacity = String(Math.min(1, Math.abs(v) / THRESH));
			}
			function release() {
				bubble.style.transition = "transform .18s ease";
				bubble.style.transform = ""; if (hint) hint.style.opacity = "0"; dx = 0;
				setTimeout(function () { bubble.style.transition = ""; }, 220);
			}
			function clearLP() { if (lpTimer) { clearTimeout(lpTimer); lpTimer = null; } }
			function buildPop() {
				pop = el("div", "zymarg-inbox__react-pop" + (mine ? " is-right" : " is-left")); pop.hidden = true;
				REACT_EMOJIS.forEach(function (emo) {
					var b = el("button", "zymarg-inbox__react-opt"); b.type = "button"; b.textContent = emo;
					b.addEventListener("click", function (ev) { ev.stopPropagation(); pop.hidden = true; toggleReaction(m.id, emo, reactionIsMine(m, emo)); });
					pop.appendChild(b);
				});
				// "+" on the right opens the full emoji list for reactions.
				var morePanel = el("div", "zymarg-inbox__react-panel"); morePanel.hidden = true;
				REACT_MORE_EMOJIS.forEach(function (emo) {
					var o = el("button", "zymarg-inbox__react-opt"); o.type = "button"; o.textContent = emo;
					o.addEventListener("click", function (ev) { ev.stopPropagation(); morePanel.hidden = true; pop.hidden = true; toggleReaction(m.id, emo, reactionIsMine(m, emo)); });
					morePanel.appendChild(o);
				});
				var moreBtn = el("button", "zymarg-inbox__react-more"); moreBtn.type = "button"; moreBtn.textContent = "+";
				moreBtn.setAttribute("aria-label", "More reactions");
				moreBtn.addEventListener("click", function (ev) { ev.stopPropagation(); morePanel.hidden = !morePanel.hidden; });
				pop.appendChild(moreBtn);
				pop.appendChild(morePanel);
				bubble.appendChild(pop);
			}
			function openPop() {
				if (!reactsEnabled) return;
				if (!pop) buildPop();
				var others = document.querySelectorAll(".zymarg-inbox__react-pop:not([hidden])");
				Array.prototype.forEach.call(others, function (p) { p.hidden = true; });
				pop.hidden = false;
				if (navigator.vibrate) { try { navigator.vibrate(12); } catch (e) {} }
				setTimeout(function () {
					var onDoc = function (ev) { if (pop && !pop.contains(ev.target)) { pop.hidden = true; document.removeEventListener("pointerdown", onDoc, true); } };
					document.addEventListener("pointerdown", onDoc, true);
				}, 0);
			}
			bubble.addEventListener("pointerdown", function (e) {
				if (e.pointerType === "mouse" && e.button !== 0) return;
				if (e.target && e.target.closest && e.target.closest("a, button, img, input, textarea, .zymarg-inbox__reacts, .zymarg-inbox__react-pop")) return;
				startX = e.clientX; startY = e.clientY; dx = 0;
				dragging = true; decided = false; isHoriz = false; moved = false; pid = e.pointerId;
				if (reactsEnabled) { clearLP(); lpTimer = setTimeout(function () { if (!moved && dragging) { dragging = false; openPop(); } }, 480); }
			});
			bubble.addEventListener("pointermove", function (e) {
				if (!dragging) return;
				var ddx = e.clientX - startX, ddy = e.clientY - startY;
				if (!moved && (Math.abs(ddx) > 6 || Math.abs(ddy) > 6)) { moved = true; clearLP(); }
				if (!decided) {
					if (Math.abs(ddx) < 8 && Math.abs(ddy) < 8) return;
					decided = true; isHoriz = Math.abs(ddx) > Math.abs(ddy) + 2;
					if (isHoriz && repliesEnabled) { try { bubble.setPointerCapture(pid); captured = true; } catch (err) {} }
				}
				if (!isHoriz || !repliesEnabled) return;
				var raw = dir === 1 ? Math.max(0, ddx) : Math.min(0, ddx);
				setDrag(Math.max(-MAX, Math.min(MAX, raw)));
			});
			function endDrag() {
				clearLP();
				if (captured && pid != null) { try { bubble.releasePointerCapture(pid); } catch (err) {} captured = false; }
				var fire = dragging && isHoriz && repliesEnabled && Math.abs(dx) >= THRESH;
				dragging = false;
				if (fire) startReply(m);
				if (isHoriz) release();
			}
			bubble.addEventListener("pointerup", endDrag);
			bubble.addEventListener("pointercancel", endDrag);
		}
		// Paints the thread shell immediately on click. The "Select a conversation"
		// text is server-rendered markup that lives inside the thread column, and
		// nothing replaced it until the messages request came back. On desktop that
		// showed as a flash; on mobile the thread view was revealed still holding
		// it. Rendering the real header plus three skeleton bubbles means the first
		// thing the user sees is the conversation they tapped.
		function renderThreadLoading(conv) {
			if (!threadEl) return;
			threadEl.innerHTML = "";
			var h = el("header", "zymarg-inbox__thread-header");
			h.appendChild(el("span", "zymarg-inbox__thread-title", conv.title || "Conversation"));
			threadEl.appendChild(h);
			var box = el("div", "zymarg-inbox__thread-messages");
			for (var i = 0; i < 3; i++) {
				box.appendChild(el("div", "zymarg-inbox__skeleton" + (i === 1 ? " is-mine" : "")));
			}
			threadEl.appendChild(box);
		}
		function renderThread(conv, messages, opts) {
			if (!threadEl) return;
			threadEl.innerHTML = "";
			var threadHeader = el("header", "zymarg-inbox__thread-header");
			threadHeader.appendChild(el("span", "zymarg-inbox__thread-title", conv.title || "Conversation"));
			var presenceEl = el("span", "zymarg-inbox__presence"); presenceEl.hidden = true;
			threadHeader.appendChild(presenceEl);
			livePresenceEl = presenceEl;
			threadEl.appendChild(threadHeader);
			if (root.__zymargPresencePoll) { clearInterval(root.__zymargPresencePoll); root.__zymargPresencePoll = null; }
			if (presenceEnabled && conv.id) {
				var pollPresence = function () {
					if (String(state.activeId) !== String(conv.id)) return;
					api(root, "/realtime/presence-status?conversation_id=" + conv.id).then(function (r) {
						var d = (r && r.data) || r || {};
						// 1.32.4 — the support surface shows the green dot ONLY,
						// inline with the thread title. 1.32.1 did this for the
						// popup but missed this file, so the in-page support
						// inbox kept printing "Active now" next to the title.
						// Buyer<->vendor inboxes keep the full text, which is
						// why this is gated on the support context rather than
						// simply deleted.
						var isSupport = "support" === (root.getAttribute("data-context") || "");
						if (d.online) {
							presenceEl.hidden = false;
							presenceEl.className = "zymarg-inbox__presence is-online";
							if (isSupport) {
								presenceEl.textContent = "";
								presenceEl.setAttribute("title", "Active now");
								presenceEl.setAttribute("aria-label", "Active now");
							} else {
								presenceEl.textContent = "Active now";
								presenceEl.removeAttribute("title");
								presenceEl.removeAttribute("aria-label");
							}
						}
						else if (!isSupport && d.last_seen) { presenceEl.hidden = false; presenceEl.className = "zymarg-inbox__presence"; presenceEl.textContent = "Last seen " + relTime(d.last_seen); }
						else { presenceEl.hidden = true; }
					}).catch(function () {});
				};
				pollPresence();
				root.__zymargPresencePoll = setInterval(pollPresence, 30000);
			}
			var msgs = el("div", "zymarg-inbox__thread-messages");
			replyState.to = null;
			var msgById = {};
			(messages || []).forEach(function (mm) { if (mm && mm.id != null) msgById[mm.id] = mm; });
			(messages || []).forEach(function (m) {
				var mine = Number(m.sender_id) === Number(state.userId);
				var msg = el("div", "zymarg-inbox__msg" + (mine ? " is-mine" : "") + (m.is_teammate ? " is-teammate" : ""));
				// 1.32.15 — name a COLLEAGUE's reply. The server sends agent_name only
				// to agents on a support case, so customers never see staff names and
				// buyer/vendor threads are unaffected. Without this a teammate's reply
				// was indistinguishable from the customer's own messages.
				if (m.is_teammate && m.agent_name) {
					msg.appendChild(el("span", "zymarg-inbox__msg-author", m.agent_name));
				}
				if (repliesEnabled && m.parent_id && msgById[m.parent_id]) msg.appendChild(buildQuote(msgById[m.parent_id]));
				msg.appendChild(document.createTextNode(m.body || ""));
				if (m.attachments && m.attachments.length) {
					var atts = el("div", "zymarg-inbox__msg-atts");
					m.attachments.forEach(function (a) {
						if (!a || !a.url) return;
						var link = el("a"); link.href = a.url; link.target = "_blank"; link.rel = "noopener noreferrer";
						if (/^image\//.test(String(a.mime_type || ""))) {
							link.className = "zymarg-inbox__msg-att is-image";
							var img = el("img"); img.src = a.url; img.alt = a.file_name || "attachment"; img.loading = "lazy";
							link.appendChild(img);
						} else {
							link.className = "zymarg-inbox__msg-att is-file";
							link.textContent = "\uD83D\uDCCE " + (a.file_name || "attachment");
						}
						atts.appendChild(link);
					});
					msg.appendChild(atts);
				}
				var meta = el("span", "zymarg-inbox__msg-time", fmtTime(m.created_at));
				if (mine) {
					var s = String(m.status || "delivered").toLowerCase();
					var st = el("span", "zymarg-inbox__msg-status is-" + s);
					st.textContent = (s === "sending") ? " \u2713" : " \u2713\u2713";
					st.setAttribute("aria-label", s === "read" ? "Read" : (s === "sending" ? "Sending" : "Delivered"));
					meta.appendChild(st);
				}
				msg.appendChild(meta);
				if ((reactsEnabled || repliesEnabled) && m.id) {
					attachGestures(msg, m);
					var rx = buildReactions(m);
					if (rx) msg.appendChild(rx);
				}
				msgs.appendChild(msg);
			});
			threadEl.appendChild(msgs);
			msgs.addEventListener("scroll", function () {
				// Remember whether the reader has deliberately moved off the bottom,
				// so the delayed re-pins below can never yank them back down.
				msgs.__zymargUserScrolled = !nearBottom(msgs);
				// Reached the top -> pull in the previous page of history.
				if (msgs.scrollTop <= 48 && msgs.scrollHeight > msgs.clientHeight + 48) loadOlder(msgs);
			});

			var form = el("form", "zymarg-inbox__composer");
			var ta   = el("textarea"); ta.rows = 1; ta.placeholder = "Write a message…"; ta.autocomplete = "off";
			// Grow with the text up to 4 lines, then scroll inside the field.
			var TA_MAX_LINES = 4;
			function autoGrow() {
				var cs = window.getComputedStyle(ta);
				var lh = parseFloat(cs.lineHeight) || 20;
				var pad = (parseFloat(cs.paddingTop) || 0) + (parseFloat(cs.paddingBottom) || 0);
				var bord = (parseFloat(cs.borderTopWidth) || 0) + (parseFloat(cs.borderBottomWidth) || 0);
				var max = Math.round(lh * TA_MAX_LINES + pad + bord);
				ta.style.height = "auto";
				var next = ta.scrollHeight + bord;
				ta.style.height = Math.min(next, max) + "px";
				ta.style.overflowY = next > max ? "auto" : "hidden";
			}
			function resetGrow() { ta.style.height = ""; ta.style.overflowY = "hidden"; }
			ta.addEventListener("input", autoGrow);
			var btn  = el("button"); btn.type = "submit"; btn.setAttribute("aria-label", "Send");
			btn.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>';
			var pendingFile = null;
			var fileInput = el("input"); fileInput.type = "file"; fileInput.accept = "image/*"; fileInput.className = "zymarg-inbox__attach-input"; fileInput.style.display = "none";
			var clip = el("button", "zymarg-inbox__attach"); clip.type = "button"; clip.setAttribute("aria-label", "Attach image");
			clip.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21.44 11.05l-9.19 9.19a5 5 0 0 1-7.07-7.07l9.19-9.19a3 3 0 0 1 4.24 4.24l-9.2 9.19a1 1 0 0 1-1.41-1.41l8.49-8.49"></path></svg>';
			var chip     = el("span", "zymarg-inbox__attach-chip"); chip.hidden = true;
			var chipName = el("span", "zymarg-inbox__attach-chip-name");
			var chipX    = el("button", "zymarg-inbox__attach-chip-remove"); chipX.type = "button"; chipX.setAttribute("aria-label", "Remove attachment"); chipX.textContent = "\u00D7";
			chip.appendChild(chipName); chip.appendChild(chipX);
			function clearPendingFile() {
				pendingFile = null;
				fileInput.value = "";
				chip.hidden = true;
				chipName.textContent = "";
			}
			chipX.addEventListener("click", function () { clearPendingFile(); if (ta) ta.focus(); });
			clip.addEventListener("click", function () { fileInput.click(); });
			fileInput.addEventListener("change", function () {
				pendingFile = (fileInput.files && fileInput.files[0]) || null;
				if (pendingFile) { chip.hidden = false; chipName.textContent = pendingFile.name; }
				else { clearPendingFile(); }
			});
			var attachEnabled = attr(root, "data-attachments") !== "0";
			if (attachEnabled) { form.appendChild(clip); form.appendChild(fileInput); }
			form.appendChild(ta);
			form.appendChild(btn);
			if (attachEnabled) { form.appendChild(chip); }
			var replyPreview = el("div", "zymarg-inbox__reply-preview"); replyPreview.hidden = true;
			replyState.onChange = function () {
				replyPreview.innerHTML = "";
				if (!replyState.to) { replyPreview.hidden = true; return; }
				replyPreview.hidden = false;
				var lbl = el("span", "zymarg-inbox__reply-preview-text");
				var b = String(replyState.to.body || "");
				lbl.textContent = "\u21A9 " + (b.length > 70 ? b.slice(0, 70) + "\u2026" : (b || "Attachment"));
				var x = el("button", "zymarg-inbox__reply-cancel"); x.type = "button"; x.setAttribute("aria-label", "Cancel reply"); x.textContent = "\u00D7";
				x.addEventListener("click", function () { cancelReply(); });
				replyPreview.appendChild(lbl); replyPreview.appendChild(x);
				if (ta) ta.focus();
			};
			if (repliesEnabled) { form.appendChild(replyPreview); }
			form.addEventListener("submit", function (e) {
				e.preventDefault();
				var text = ta.value.trim();
				if (!text && !pendingFile) return;
				var body = text || (pendingFile ? pendingFile.name : "");
				var theFile = pendingFile;
				var parentId = replyState.to ? replyState.to.id : null;
				btn.disabled = true;
				api(root, "/conversations/" + conv.id + "/messages", { method: "POST", body: parentId ? { body: body, parent_id: parentId } : { body: body } })
					.then(function (r) {
						var d = (r && r.data) || r || {};
						var sent = d.message || {};
						if (theFile && sent && sent.id) return uploadAttachment(root, theFile, sent.id);
					})
					.then(function () { ta.value = ""; resetGrow(); theFile = null; clearPendingFile(); cancelReply(); loadThread(conv.id); loadList(); })
					.catch(function () { /* silent */ })
					.then(function () { btn.disabled = false; ta.focus(); });
			});
			// Enter sends (as it did while this was a single-line input);
			// Shift+Enter inserts a newline now that the field can grow.
			ta.addEventListener("keydown", function (e) {
				if (e.key === "Enter" && !e.shiftKey) {
					e.preventDefault();
					if (form.requestSubmit) form.requestSubmit();
					else form.dispatchEvent(new Event("submit", { cancelable: true }));
				}
			});
			var typingEnabled = attr(root, "data-typing") !== "0";
			var typingInd = el("div", "zymarg-inbox__typing"); typingInd.hidden = true;
			// 1.32.15 — the dots are unchanged. A named row is ADDED in front of
			// them only when the server sends a label (support cases, customer
			// side), so every other thread renders exactly what it did before.
			typingInd.innerHTML = '<span class="zymarg-inbox__typing-who" hidden></span><span class="zymarg-inbox__typing-dots"><i></i><i></i><i></i></span>';
			var typingWho = typingInd.querySelector(".zymarg-inbox__typing-who");
			function paintTypingLabel(label) {
				if (!typingWho) return;
				if (label) { typingWho.textContent = label; typingWho.hidden = false; }
				else { typingWho.textContent = ""; typingWho.hidden = true; }
			}
			liveTypingInd = typingInd;
			if (root.__zymargTypingPoll) { clearInterval(root.__zymargTypingPoll); root.__zymargTypingPoll = null; }
			if (root.__zymargTypingStop) { clearTimeout(root.__zymargTypingStop); root.__zymargTypingStop = null; }
			if (typingEnabled) {
				threadEl.appendChild(typingInd);
				var lastTypingSent = 0;
				var sendTyping = function (isTyping) {
					if (!conv.id) return;
					api(root, "/realtime/typing", { method: "POST", body: { conversation_id: conv.id, typing: !!isTyping } }).catch(function () {});
				};
				ta.addEventListener("input", function () {
					var now = Date.now();
					if (now - lastTypingSent > 3000) { lastTypingSent = now; sendTyping(true); }
					if (root.__zymargTypingStop) clearTimeout(root.__zymargTypingStop);
					root.__zymargTypingStop = setTimeout(function () { lastTypingSent = 0; sendTyping(false); }, 3500);
				});
				root.__zymargTypingPoll = setInterval(function () {
					if (String(state.activeId) !== String(conv.id)) return;
					api(root, "/realtime/typing-status?conversation_id=" + conv.id).then(function (r) {
						var d = (r && r.data) || r || {};
						var was = !typingInd.hidden;
						paintTypingLabel(d.typing ? d.typing_label : "");
						typingInd.hidden = !d.typing;
						// The typing indicator must NEVER yank the reader to the bottom.
						// Only follow along if they were already there.
						if (d.typing && !was && (msgs.scrollHeight - msgs.scrollTop - msgs.clientHeight) < 80) msgs.scrollTop = msgs.scrollHeight;
					}).catch(function () {});
				}, 3000);
			}
			threadEl.appendChild(form);

			// Scroll only AFTER the composer is in the DOM. Appending it shrinks the
			// message box, so a scroll measured beforehand lands short by exactly the
			// height of the input row and hides the newest message behind it.
			opts = opts || {};
			if (opts.keepScroll) {
				var ks = opts.keepScroll;
				var restore = function () {
					msgs.scrollTop = Math.max(0, msgs.scrollHeight - (ks.height || 0) + (ks.top || 0));
				};
				restore();
				if (window.requestAnimationFrame) window.requestAnimationFrame(restore);
			} else {
				pinToBottom(msgs);
			}
		}

		// Park the view on the newest message and keep it there while the layout
		// settles (fonts, lazy avatars, attachment images all change the height
		// after the first paint). Aborts the moment the reader scrolls up.
		function pinToBottom(msgs) {
			if (!msgs) return;
			msgs.__zymargUserScrolled = false;
			var pin = function () {
				if (msgs.__zymargUserScrolled) return;
				msgs.scrollTop = msgs.scrollHeight;
			};
			pin();
			if (window.requestAnimationFrame) {
				window.requestAnimationFrame(function () { pin(); window.requestAnimationFrame(pin); });
			}
			[60, 200, 500].forEach(function (t) { setTimeout(pin, t); });
			$$(msgs, "img").forEach(function (img) {
				if (img.complete) return;
				img.addEventListener("load", pin);
				img.addEventListener("error", pin);
			});
		}

		// Combine two lists of messages, de-duplicated by id and in id order.
		// Later entries win, so a polled copy refreshes status on one already held.
		function mergeThread(existing, incoming) {
			var byId = {};
			var order = [];
			(existing || []).concat(incoming || []).forEach(function (m) {
				if (!m || m.id == null) return;
				var k = String(m.id);
				if (!(k in byId)) order.push(k);
				byId[k] = m;
			});
			return order
				.map(function (k) { return byId[k]; })
				.sort(function (a, b) { return (Number(a.id) || 0) - (Number(b.id) || 0); });
		}

		// Pull the page of history immediately above what is currently loaded.
		// state.threadOffset is where the loaded window starts in the full thread,
		// so it doubles as the count of messages still unread above it.
		function loadOlder(msgsEl) {
			if (state.loadingOlder || !state.activeId) return;
			var remaining = Math.max(0, Number(state.threadOffset) || 0);
			if (remaining <= 0) return; // already at the beginning

			state.loadingOlder = true;
			var id         = state.activeId;
			var take       = Math.min(30, remaining);
			var from       = Math.max(0, remaining - take);
			var prevHeight = msgsEl ? msgsEl.scrollHeight : 0;
			var prevTop    = msgsEl ? msgsEl.scrollTop : 0;

			var banner = el("div", "zymarg-inbox__older", "Loading earlier messages\u2026");
			if (msgsEl) msgsEl.insertBefore(banner, msgsEl.firstChild);

			api(root, "/conversations/" + id + "/messages?limit=" + take + "&offset=" + from)
				.then(function (r) {
					if (String(state.activeId) !== String(id)) return; // switched threads
					var d = (r && r.data) || r || {};
					var older = d.messages || (Array.isArray(d) ? d : []);
					state.threadOffset = from;
					if (!older.length) return;
					state.threadMsgs = mergeThread(older, state.threadMsgs);
					var conv = state.conversations.filter(function (c) { return c.id === id; })[0] || { id: id, title: "" };
					// Hold the reader's place: keep the same message under the cursor
					// instead of jumping, now that content was added above.
					renderThread(conv, state.threadMsgs, { keepScroll: { height: prevHeight, top: prevTop } });
				})
				.catch(function () {})
				.then(function () {
					state.loadingOlder = false;
					if (banner && banner.parentNode) banner.parentNode.removeChild(banner);
				});
		}

		function loadList() {
			if (loadingEl) loadingEl.hidden = false;
			// The support surface sets data-context so it lists only support
			// threads. Buyer and vendor roots have no data-context, so their
			// request is byte-for-byte what it was before 1.25.0.
			var listCtx = attr(root, "data-context") || "";
			var listUrl = "/conversations?side=" + encodeURIComponent(state.side);
			if (listCtx) {
				listUrl += "&context=" + encodeURIComponent(listCtx);
			} else {
				// 1.32.6 — a root with no data-context is the ordinary buyer or
				// vendor inbox, which must NOT list helpline cases. Until now it
				// sent no filter at all and so received every conversation the
				// user took part in, support included: messaging the helpline
				// made the case appear in the regular buyer/seller message box
				// too, mixed in with vendor threads. They are separate products
				// and do not share a list.
				listUrl += "&exclude_context=support";
			}

			return api(root, listUrl)
				.then(function (r) {
					var d = (r && r.data) || r || {};
					state.conversations = d.conversations || (Array.isArray(d) ? d : []);
					renderList();
				})
				.catch(function () { if (listEl) listEl.innerHTML = ""; renderList(); })
				.then(function () { if (loadingEl) loadingEl.hidden = true; });
		}

		function loadThread(id) {
			state.activeId = id;
			// Publish the active conversation on the root as an observable signal
			// (1.27.0). The support ticket panel watches this to know which
			// ticket to load, without reaching into inbox internals. Also fire a
			// DOM event for listeners that prefer push over observation.
			try {
				root.setAttribute("data-active-conversation", String(id));
				document.dispatchEvent(new CustomEvent("zymarg-comm:thread-opened", {
					detail: { conversationId: id, root: root, context: attr(root, "data-context") || "" }
				}));
			} catch (e) { /* non-fatal */ }
			openThreadView();
			renderList();
			var conv = state.conversations.filter(function (c) { return c.id === id; })[0] || { id: id, title: "" };
			state.threadMsgs   = [];
			state.threadOffset = 0;
			state.loadingOlder = false;
			renderThreadLoading(conv);
			api(root, "/conversations/" + id + "/messages").then(function (r) {
				if (String(state.activeId) !== String(id)) return; // switched away mid-flight
				var d = (r && r.data) || r || {};
				var msgs = d.messages || (Array.isArray(d) ? d : []);
				// Where this window starts in the full thread == how much history is
				// still above it, which is what scrolling up will fetch.
				state.threadOffset = Math.max(0, Number(d.offset) || 0);
				state.threadMsgs   = msgs;
				renderThread(conv, msgs);
				state.threadSig = threadSig(msgs);
				// Mark incoming messages read: PATCH with the required before_message_id.
				var lastId = 0;
				(msgs || []).forEach(function (m) {
					if (Number(m.sender_id) !== Number(state.userId)) lastId = Math.max(lastId, Number(m.id) || 0);
				});
				if (lastId > 0) {
					api(root, "/conversations/" + id + "/read", { method: "PATCH", body: { before_message_id: lastId } })
						.then(function () { loadList(); })
						.catch(function () {});
				}
			}).catch(function () { renderThread(conv, []); });
		}

		function closeAllMenus() {
			$$(root, ".zymarg-inbox__item.is-menu-open").forEach(function (x) { x.classList.remove("is-menu-open"); });
		}
		function toggleMenu(rowEl) {
			if (!rowEl) return;
			var open = rowEl.classList.contains("is-menu-open");
			closeAllMenus();
			if (!open) rowEl.classList.add("is-menu-open");
		}
		function doArchive(cid) {
			if (!cid) return;
			if (!window.confirm("Archive this conversation? It will be moved out of your inbox.")) return;
			api(root, "/conversations/" + cid, { method: "PATCH", body: { archive: true } })
				.then(function () {
					if (state.activeId === cid) { state.activeId = null; if (threadEl) threadEl.innerHTML = ""; }
					loadList();
				})
				.catch(function () { window.alert("Sorry, we couldn't archive that conversation."); });
		}
		function doReport(cid) {
			if (!cid) return;
			var notes = window.prompt("Report this conversation to the moderators?\n\nOptionally add a reason (e.g. spam, harassment, scam):", "");
			if (notes === null) return;
			api(root, "/conversations/" + cid + "/report", { method: "POST", body: { notes: notes } })
				.then(function () { window.alert("Thanks \u2014 this conversation has been reported to the moderators."); })
				.catch(function () { window.alert("Sorry, we couldn't submit that report."); });
		}

		// Close any open row menu when clicking elsewhere on the page.
		document.addEventListener("click", function (e) {
			var inActions = e.target && e.target.closest && e.target.closest(".zymarg-inbox__item-actions");
			if (!inActions) closeAllMenus();
		});

		// Event delegation.
		if (listEl) {
			listEl.addEventListener("click", function (e) {
				var actionEl = e.target.closest ? e.target.closest("[data-inbox-action]") : null;
				if (actionEl) {
					e.stopPropagation();
					var arow = actionEl.closest("[data-conversation-id]");
					var acid = arow ? parseInt(arow.getAttribute("data-conversation-id"), 10) : 0;
					var action = actionEl.getAttribute("data-inbox-action");
					if (action === "menu-toggle") { toggleMenu(arow); return; }
					closeAllMenus();
					if (action === "archive") doArchive(acid);
					else if (action === "report") doReport(acid);
					return;
				}
				var item = e.target.closest("[data-conversation-id]");
				if (!item) return;
				var id = parseInt(item.getAttribute("data-conversation-id"), 10);
				if (id) loadThread(id);
			});
		}
		if (searchEl) {
			var t = null;
			searchEl.addEventListener("input", function () {
				if (t) clearTimeout(t);
				t = setTimeout(function () { state.search = searchEl.value; renderList(); }, 150);
			});
		}
		// Mobile search: the field is hidden behind an icon. Opening it hides the
		// title and filters so the field can take the full header width; closing
		// it clears the query so the list is never left silently filtered.
		var searchToggle = $(root, "[data-zymarg-inbox-search-toggle]");
		var searchClose  = $(root, "[data-zymarg-inbox-search-close]");
		if (searchToggle && searchEl) {
			var headerEl = searchToggle.closest(".zymarg-inbox__header");
			var setSearching = function (on) {
				if (headerEl) headerEl.classList.toggle("is-searching", !!on);
				searchToggle.setAttribute("aria-expanded", on ? "true" : "false");
				if (on) {
					searchEl.focus();
					return;
				}
				if (searchEl.value) {
					searchEl.value = "";
					state.search = "";
					renderList();
				}
				searchToggle.focus();
			};
			searchToggle.addEventListener("click", function () { setSearching(true); });
			if (searchClose) {
				searchClose.addEventListener("click", function () { setSearching(false); });
			}
			searchEl.addEventListener("keydown", function (e) {
				if (e.key === "Escape") { e.preventDefault(); setSearching(false); }
			});
		}
		// Mobile master-detail.
		// On phones the list and the thread are two separate full-screen views.
		// Opening a conversation hides the list; the device back button, the iOS
		// swipe-back gesture and any filter pill all return to it. Desktop is
		// untouched: is-thread-open is only acted on inside the 640px media query.
		var threadHistoryPushed = false;
		function isNarrowView() {
			return window.matchMedia ? window.matchMedia("(max-width:640px)").matches : false;
		}
		function setThreadOpen(on) {
			if (root) root.classList.toggle("is-thread-open", !!on);
		}
		function openThreadView() {
			if (!isNarrowView()) return;
			setThreadOpen(true);
			// One history entry per thread view, so the device back button returns
			// to the list instead of leaving the page.
			if (!threadHistoryPushed && window.history && window.history.pushState) {
				try {
					window.history.pushState({ zymargInboxThread: true }, "");
					threadHistoryPushed = true;
				} catch (e) {}
			}
		}
		function closeThreadView() {
			setThreadOpen(false);
			if (threadHistoryPushed) {
				threadHistoryPushed = false;
				try { window.history.back(); } catch (e) {}
			}
		}
		window.addEventListener("popstate", function () {
			if (root && root.classList.contains("is-thread-open")) {
				threadHistoryPushed = false;
				setThreadOpen(false);
			}
		});

		// The panel fills whatever vertical space is left below the site header.
		// Measured rather than assumed: header height varies by device, by theme
		// settings and by whether the WordPress admin bar is present.
		function syncViewportOffset() {
			if (!root) return;
			var rect = root.getBoundingClientRect();
			var top  = rect.top + (window.pageYOffset || document.documentElement.scrollTop || 0);
			root.style.setProperty("--zi-offset", Math.max(0, Math.round(top)) + "px");
		}
		syncViewportOffset();
		window.addEventListener("resize", syncViewportOffset);
		window.addEventListener("orientationchange", syncViewportOffset);

		filterEls.forEach(function (btn) {
			btn.addEventListener("click", function () {
				filterEls.forEach(function (b) { b.classList.remove("is-active"); b.setAttribute("aria-selected", "false"); });
				btn.classList.add("is-active"); btn.setAttribute("aria-selected", "true");
				state.filter = btn.getAttribute("data-zymarg-inbox-filter") || "all";
				// Picking a filter means "show me the list", so on mobile this also
				// returns from an open thread.
				closeThreadView();
				renderList();
			});
		});

		// \u2500\u2500 Realtime (Pusher) bridge \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
		// Instant updates when a realtime driver is connected; the polls above
		// remain an automatic fallback (and drive non-Pusher drivers).
		onRealtime("message.sent", function (payload) {
			if (root && !document.contains(root)) return;
			payload = payload || {};
			var cid = Number(payload.conversation_id) || 0;
			if (cid && String(cid) === String(state.activeId)) { loadThread(state.activeId); }
			loadList();
		});
		onRealtime("typing.update", function (payload) {
			if (root && !document.contains(root)) return;
			payload = payload || {};
			var cid = Number(payload.conversation_id) || 0;
			if (!liveTypingInd || !cid || String(cid) !== String(state.activeId)) return;
			if (Number(payload.user_id) === Number(state.userId)) return;
			// 1.32.15 — keep the named row in step with the push. The server sends
			// typing_label only for support cases viewed by the customer; absent it
			// the row stays hidden and the dots behave exactly as before.
			var who = liveTypingInd.querySelector(".zymarg-inbox__typing-who");
			if (who) {
				if (payload.typing && payload.typing_label) { who.textContent = payload.typing_label; who.hidden = false; }
				else { who.textContent = ""; who.hidden = true; }
			}
			if (payload.typing) {
				liveTypingInd.hidden = false;
				if (liveTypingHideTimer) clearTimeout(liveTypingHideTimer);
				liveTypingHideTimer = setTimeout(function () { if (liveTypingInd) liveTypingInd.hidden = true; }, 4000);
			} else {
				liveTypingInd.hidden = true;
				if (liveTypingHideTimer) clearTimeout(liveTypingHideTimer);
			}
		});
		onRealtime("presence.update", function (payload) {
			if (root && !document.contains(root)) return;
			payload = payload || {};
			var cid = Number(payload.conversation_id) || 0;
			if (!livePresenceEl || !cid || String(cid) !== String(state.activeId)) return;
			if (Number(payload.user_id) === Number(state.userId)) return;
			if (payload.online) {
				// 1.32.4 — support = dot only, buyer<->vendor = keep the label.
				var isSupport = root && "support" === (root.getAttribute("data-context") || "");
				livePresenceEl.hidden = false;
				livePresenceEl.className = "zymarg-inbox__presence is-online";
				if (isSupport) {
					livePresenceEl.textContent = "";
					livePresenceEl.setAttribute("title", "Active now");
					livePresenceEl.setAttribute("aria-label", "Active now");
				} else {
					livePresenceEl.textContent = "Active now";
					livePresenceEl.removeAttribute("title");
					livePresenceEl.removeAttribute("aria-label");
				}
			}
		});

		// \u2500\u2500 Live refresh \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\n		// realtime.js is never enqueued, so the onRealtime() bridge above never
		// fires and the inbox had no way to learn about new messages. Poll like
		// live-chat.js does, but re-render only when the thread actually changed
		// so we never clobber what the user is typing.

		function composerSnapshot() {
			var ta = threadEl ? threadEl.querySelector(".zymarg-inbox__composer textarea") : null;
			if (!ta) return null;
			return {
				value: ta.value,
				focused: document.activeElement === ta,
				start: ta.selectionStart,
				end: ta.selectionEnd
			};
		}
		function restoreComposer(saved) {
			if (!saved) return;
			var ta = threadEl ? threadEl.querySelector(".zymarg-inbox__composer textarea") : null;
			if (!ta) return;
			ta.value = saved.value;
			if (saved.focused) {
				try { ta.focus(); ta.setSelectionRange(saved.start, saved.end); } catch (e) {}
			}
		}
		function nearBottom(elm) {
			if (!elm) return true;
			return (elm.scrollHeight - elm.scrollTop - elm.clientHeight) < 80;
		}

		function pollThread() {
			if (!state.activeId) return;
			var id = state.activeId;
			api(root, "/conversations/" + id + "/messages").then(function (r) {
				if (String(state.activeId) !== String(id)) return; // user switched threads
				var d = (r && r.data) || r || {};
				var list = d.messages || (Array.isArray(d) ? d : []);
				var sig = threadSig(list);
				if (sig === state.threadSig) return; // nothing new \u2014 leave the DOM alone

				var oldMsgs    = threadEl ? threadEl.querySelector(".zymarg-inbox__thread-messages") : null;
				var stick      = nearBottom(oldMsgs);
				var prevTop    = oldMsgs ? oldMsgs.scrollTop : 0;
				var prevHeight = oldMsgs ? oldMsgs.scrollHeight : 0;
				var saved      = composerSnapshot();
				var conv       = state.conversations.filter(function (c) { return c.id === id; })[0] || { id: id, title: "" };

				// Keep whatever earlier history the reader has already pulled in.
				state.threadMsgs = mergeThread(state.threadMsgs, list);

				// Reading history -> hold their place. Otherwise follow the newest.
				renderThread(conv, state.threadMsgs, stick ? null : { keepScroll: { height: prevHeight, top: prevTop } });
				state.threadSig = sig;
				restoreComposer(saved);

				var lastId = 0;
				list.forEach(function (m) {
					if (Number(m.sender_id) !== Number(state.userId)) lastId = Math.max(lastId, Number(m.id) || 0);
				});
				if (lastId > 0) {
					api(root, "/conversations/" + id + "/read", { method: "PATCH", body: { before_message_id: lastId } })
						.then(function () { loadList(); })
						.catch(function () {});
				}
			}).catch(function () {});
		}

		if (root.__zymargPoll) { clearInterval(root.__zymargPoll); root.__zymargPoll = null; }
		root.__zymargPoll = setInterval(function () {
			// Stop cleanly if the theme's SPA swapped this root out of the document.
			if (!document.contains(root)) {
				clearInterval(root.__zymargPoll);
				root.__zymargPoll = null;
				if (root.__zymargBeat) { clearInterval(root.__zymargBeat); root.__zymargBeat = null; }
				return;
			}
			if (document.hidden) return; // don't poll a backgrounded tab
			loadList();
			pollThread();
		}, POLL_INTERVAL);

		// Catch up immediately when the user comes back to the tab.
		document.addEventListener("visibilitychange", function () {
			if (document.hidden || !document.contains(root)) return;
			loadList();
			pollThread();
		});

		// ── Public per-root handle (1.26.0) ─────────────────────────────────
		// support.js needs to point an already-rendered inline inbox at a
		// specific thread once POST /support/start resolves. The handle lives on
		// the root element rather than in a single global so several inbox roots
		// on one page stay independent.
		root.__zymargInboxApi = {
			open: function (id) {
				var cid = parseInt(id, 10) || 0;
				if (!cid) return false;
				loadThread(cid);
				return true;
			},
			openLatest: function () {
				var first = state.conversations[0];
				if (!first) return false;
				loadThread(first.id);
				return true;
			}
		};

		// A thread asked for before this root finished hydrating.
		var pendingOpenId = parseInt(root.__zymargInboxPendingId || 0, 10) || 0;
		root.__zymargInboxPendingId = 0;

		loadList().then(function () {
			if (pendingOpenId) { loadThread(pendingOpenId); return; }
			// Support surfaces hide the conversation list entirely (there is only
			// ever the one admin thread), so leaving the thread pane unselected
			// reads as a dead empty state. Buyer/vendor roots keep their existing
			// behaviour untouched — this only fires for data-context="support".
			if ("support" === (attr(root, "data-context") || "") && !state.activeId) {
				var first = state.conversations[0];
				if (first) loadThread(first.id);
			}
		});
	}

	// Cheap fingerprint of a thread: length + newest id + newest status. Changes
	// when a message arrives, is deleted, or flips to "read".
	function threadSig(list) {
		list = list || [];
		var last = list[list.length - 1] || {};
		return list.length + ":" + (last.id || 0) + ":" + (last.status || "");
	}

	function scan() {
		var roots = document.querySelectorAll("[data-zymarg-inbox]");
		Array.prototype.forEach.call(roots, hydrate);
	}

	// ── Global entry point (1.26.0) ─────────────────────────────────────────
	// Lets support.js open a specific thread in an inline inbox without leaving
	// the page. Safe to call before the root has hydrated: the id is stashed and
	// consumed by hydrate() as soon as the conversation list resolves.
	window.zymargInbox = window.zymargInbox || {};
	window.zymargInbox.openConversation = function (id, rootEl) {
		var cid = parseInt(id, 10) || 0;
		var target = rootEl
			|| document.querySelector('[data-zymarg-inbox][data-context="support"]')
			|| document.querySelector("[data-zymarg-inbox]");
		if (!target) return false;

		if (!target[HYDRATED]) {
			target.__zymargInboxPendingId = cid;
			hydrate(target);
			return true;
		}

		var api = target.__zymargInboxApi;
		if (api && typeof api.open === "function") return api.open(cid);
		return false;
	};

	document.addEventListener("zymarg-comm:open-conversation", function (e) {
		var d = (e && e.detail) || {};
		window.zymargInbox.openConversation(d.conversationId, d.root || null);
	});

	if (document.readyState === "loading") {
		document.addEventListener("DOMContentLoaded", scan);
	} else {
		scan();
	}

	// Re-hydrate when the theme's SPA swaps section markup.
	var mo = new MutationObserver(function (muts) {
		for (var i = 0; i < muts.length; i++) {
			var added = muts[i].addedNodes;
			for (var j = 0; j < added.length; j++) {
				var n = added[j];
				if (n.nodeType !== 1) continue;
				if (n.matches && n.matches("[data-zymarg-inbox]")) hydrate(n);
				else if (n.querySelectorAll) {
					Array.prototype.forEach.call(n.querySelectorAll("[data-zymarg-inbox]"), hydrate);
				}
			}
		}
	});
	mo.observe(document.documentElement, { childList: true, subtree: true });

	// Hosts (ZYMARG OS theme My Account + ZYMARG Vendor Dashboard) swap
	// dashboard sections client-side via AJAX and announce it with a custom
	// event so integrations can re-bind. The MutationObserver above usually
	// catches the injected markup, but these explicit hooks guarantee the
	// inbox hydrates the instant a section is swapped in — no page reload.
	["zymarg-vd:section-loaded", "zymarg:section:swapped", "zymarg-os:section-loaded", "zymarg-os:section-changed"].forEach(function (evt) {
		document.addEventListener(evt, scan);
	});

	// Buyer fallback: the ZYMARG OS theme My Account SPA swaps sections via
	// innerHTML and dispatches NO event, so there is nothing to listen for.
	// Any user navigation can trigger an async section swap, so re-scan a few
	// times shortly after a nav interaction. scan() is idempotent (already-
	// hydrated roots are skipped), so these repeats are cheap no-ops.
	function scanSoon() {
		[120, 350, 700, 1200].forEach(function (t) { setTimeout(scan, t); });
	}
	document.addEventListener("click", function (e) {
		var nav = (e.target && e.target.closest)
			? e.target.closest("a[href], [data-nav], [data-section], .nav-link")
			: null;
		if (nav) scanSoon();
	}, true);
	window.addEventListener("popstate", scanSoon);
})();
