/**
 * ZYMARG Communication — Realtime client.
 *
 * Provides a single API surface (`window.ZymargComm.realtime`) backed by a
 * pluggable driver resolved at runtime from `/realtime/token`. Supported
 * drivers: pusher, websocket, sse, polling. Reconnect + replay is handled
 * transparently — callers only see `on(event, handler)`.
 *
 * @package ZymargCommunication
 */
( function ( global ) {
	'use strict';

	var cfg = global.ZymargCommRealtimeConfig || {};
	if ( ! cfg.restUrl || ! cfg.userId ) {
		return;
	}

	var listeners = {};
	var lastEventId = null;
	var active = null;
	var heartbeatTimer = null;

	function on( event, handler ) {
		if ( ! listeners[ event ] ) {
			listeners[ event ] = [];
		}
		listeners[ event ].push( handler );
	}

	function off( event, handler ) {
		if ( ! listeners[ event ] ) return;
		listeners[ event ] = listeners[ event ].filter( function ( h ) { return h !== handler; } );
	}

	function emit( event, payload ) {
		( listeners[ event ] || [] ).forEach( function ( h ) {
			try { h( payload ); } catch ( e ) { /* swallow */ }
		} );
		( listeners[ '*' ] || [] ).forEach( function ( h ) {
			try { h( event, payload ); } catch ( e ) { /* swallow */ }
		} );
	}

	function request( path, options ) {
		options = options || {};
		options.headers = Object.assign(
			{ 'Content-Type': 'application/json', 'X-WP-Nonce': cfg.nonce },
			options.headers || {}
		);
		options.credentials = 'same-origin';
		return fetch( cfg.restUrl + path, options ).then( function ( r ) { return r.json(); } );
	}

	function ingestEvent( evt ) {
		if ( ! evt || ! evt.event ) return;
		if ( evt.id ) { lastEventId = evt.id; }
		emit( evt.event, evt.payload || {} );
	}

	// ── Pusher driver ────────────────────────────────────────────────────────────────────
	function connectPusher( token ) {
		if ( typeof global.Pusher === 'undefined' ) {
			// Pusher lib not present — fall back to polling.
			connectPolling( { endpoint: cfg.restUrl + '/realtime/poll', interval_ms: 4000 } );
			return;
		}
		try {
			var client = new global.Pusher( token.app_key, {
				cluster: token.cluster,
				authEndpoint: token.auth_url,
				auth: { headers: { 'X-WP-Nonce': cfg.nonce } }
			} );

			// A refused subscription or a socket that never opens used to leave
			// this client permanently dead with NO fallback: active still said
			// 'pusher', nothing was ever delivered, and no error surfaced, so
			// surfaces had to wait on their own slow refresh timers. Always
			// degrade to polling instead of dying quietly.
			var degraded = false;
			var degrade = function ( reason ) {
				if ( degraded ) { return; }
				degraded = true;
				try { client.disconnect(); } catch ( err ) { /* ignore */ }
				active = null;
				if ( global.console && global.console.warn ) {
					global.console.warn( '[ZymargComm] Realtime push unavailable (' + reason + '). Falling back to polling.' );
				}
				connectPolling( { endpoint: cfg.restUrl + '/realtime/poll', interval_ms: 4000 } );
			};

			var channel = client.subscribe( token.channel );
			channel.bind( 'pusher:subscription_error', function ( status ) {
				var code = ( status && ( status.status || status.error ) ) ? ( status.status || status.error ) : 'refused';
				degrade( 'channel ' + token.channel + ' ' + code );
			} );
			client.connection.bind( 'failed', function () { degrade( 'connection failed' ); } );
			client.connection.bind( 'unavailable', function () { degrade( 'connection unavailable' ); } );

			channel.bind_global( function ( eventName, payload ) {
				// Pusher lifecycle events are not app data.
				if ( 0 === String( eventName ).indexOf( 'pusher:' ) ) { return; }
				ingestEvent( { event: eventName, payload: payload } );
			} );

			channel.bind( 'pusher:subscription_succeeded', function () {
				replayMissed();
			} );

			active = { type: 'pusher', client: client };
			emit( 'realtime.connected', { driver: 'pusher' } );
			replayMissed();
		} catch ( e ) {
			connectPolling( { endpoint: cfg.restUrl + '/realtime/poll', interval_ms: 4000 } );
		}
	}

	// ── SSE driver ───────────────────────────────────────────────────────────────────────────
	function connectSse( token ) {
		if ( typeof global.EventSource === 'undefined' ) {
			connectPolling( { endpoint: cfg.restUrl + '/realtime/poll', interval_ms: 4000 } );
			return;
		}
		var source = new global.EventSource( token.endpoint, { withCredentials: true } );
		source.onmessage = function ( ev ) {
			try { ingestEvent( JSON.parse( ev.data ) ); } catch ( e ) { /* ignore */ }
		};
		source.onerror = function () {
			source.close();
			setTimeout( function () { connectSse( token ); }, 3000 );
		};
		active = { type: 'sse', client: source };
		emit( 'realtime.connected', { driver: 'sse' } );
		replayMissed();
	}

	// ── Polling driver ───────────────────────────────────────────────────────────────────
	function connectPolling( token ) {
		var interval = ( token && token.interval_ms ) || 4000;
		var timer = setInterval( function () {
			var suffix = lastEventId ? ( '?since=' + encodeURIComponent( lastEventId ) ) : '';
			request( '/realtime/poll' + suffix ).then( function ( res ) {
				if ( ! res || ! res.success ) return;
				( res.data && res.data.events || [] ).forEach( ingestEvent );
			} ).catch( function () { /* swallow */ } );
		}, interval );
		active = { type: 'polling', client: timer };
		emit( 'realtime.connected', { driver: 'polling' } );
	}

	// ── WebSocket driver ─────────────────────────────────────────────────────────────────
	function connectWebSocket( token ) {
		if ( ! token.endpoint || typeof global.WebSocket === 'undefined' ) {
			connectPolling( { endpoint: cfg.restUrl + '/realtime/poll', interval_ms: 4000 } );
			return;
		}
		try {
			var ws = new global.WebSocket( token.endpoint + '?auth=' + encodeURIComponent( token.auth ) + '&channel=' + encodeURIComponent( token.channel ) );
			ws.onmessage = function ( ev ) {
				try { ingestEvent( JSON.parse( ev.data ) ); } catch ( e ) { /* ignore */ }
			};
			ws.onclose = function () { setTimeout( bootstrap, 3000 ); };
			active = { type: 'websocket', client: ws };
			emit( 'realtime.connected', { driver: 'websocket' } );
			replayMissed();
		} catch ( e ) {
			connectPolling( { endpoint: cfg.restUrl + '/realtime/poll', interval_ms: 4000 } );
		}
	}

	function replayMissed() {
		var suffix = lastEventId ? ( '?since=' + encodeURIComponent( lastEventId ) ) : '';
		request( '/realtime/poll' + suffix ).then( function ( res ) {
			if ( ! res || ! res.success ) return;
			( res.data && res.data.events || [] ).forEach( ingestEvent );
		} ).catch( function () { /* swallow */ } );
	}

	function disconnect() {
		if ( ! active ) return;
		try {
			if ( active.type === 'pusher' && active.client ) { active.client.disconnect(); }
			else if ( active.type === 'sse' && active.client ) { active.client.close(); }
			else if ( active.type === 'polling' && active.client ) { clearInterval( active.client ); }
			else if ( active.type === 'websocket' && active.client ) { active.client.close(); }
		} catch ( e ) { /* swallow */ }
		active = null;
		if ( heartbeatTimer ) { clearInterval( heartbeatTimer ); heartbeatTimer = null; }
	}

	function bootstrap() {
		disconnect();
		request( '/realtime/token' ).then( function ( res ) {
			if ( ! res || ! res.success ) {
				connectPolling( { endpoint: cfg.restUrl + '/realtime/poll', interval_ms: 4000 } );
				return;
			}
			var data = res.data || {};
			switch ( data.driver ) {
				case 'pusher':    connectPusher( data.token || {} ); break;
				case 'websocket': connectWebSocket( data.token || {} ); break;
				case 'sse':       connectSse( data.token || {} ); break;
				case 'polling':   connectPolling( data.token || {} ); break;
				default:          connectPolling( { endpoint: cfg.restUrl + '/realtime/poll', interval_ms: 4000 } ); break;
			}
			heartbeatTimer = setInterval( function () {
				request( '/realtime/heartbeat', { method: 'POST', body: '{}' } );
			}, cfg.heartbeat || 30000 );
		} ).catch( function () {
			connectPolling( { endpoint: cfg.restUrl + '/realtime/poll', interval_ms: 4000 } );
		} );
	}

	var api = {
		connect:    bootstrap,
		disconnect: disconnect,
		on:         on,
		off:        off,
		setTyping:  function ( conversationId, isTyping ) {
			return request( '/realtime/typing', {
				method: 'POST',
				body: JSON.stringify( { conversation_id: conversationId, typing: !! isTyping } )
			} );
		},
		ack: function ( eventId ) {
			return request( '/realtime/ack', {
				method: 'POST',
				body: JSON.stringify( { event_id: eventId } )
			} );
		},
		driver: function () { return active ? active.type : null; }
	};

	global.ZymargComm = global.ZymargComm || {};
	global.ZymargComm.realtime = api;

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', bootstrap );
	} else {
		bootstrap();
	}
} )( typeof window !== 'undefined' ? window : this );
