/**
 * ZYMARG Communication — Admin<->User support trigger.
 *
 * Hydrates any [data-zymarg-support-start] control, wherever it appears and
 * whatever it is labelled. Clicking it starts or resumes the caller's support
 * thread, then hands the thread to the BEST AVAILABLE SURFACE ON THIS PAGE.
 *
 * ---------------------------------------------------------------------------
 * 1.26.0 — why this file was reworked
 * ---------------------------------------------------------------------------
 * Two defects made every Contact Support click navigate the customer away to
 * My Account -> Messages, which is a different feature for a different job:
 *
 *   a) The popup hand-off probed `window.ZymargLiveChat` (capital Z, capital C)
 *      and called `.openConversation()`. live-chat.js actually publishes
 *      `window.zymargLiveChat` (lowercase z) and exposes `.open()`. JavaScript
 *      is case sensitive, so the guard was permanently `undefined` and the
 *      method never existed -- the popup branch was unreachable dead code.
 *
 *   b) With the popup branch unreachable, control always fell through to
 *      `window.location.href = inbox_url`. Both hosts (the theme account page
 *      and the vendor dashboard) already ship a hidden inline support inbox on
 *      the very same page and already declare it via `data-inline-target` --
 *      but this script never read that attribute, so the in-place surface sat
 *      there unused while the customer got redirected off the page.
 *
 * Resolution order is now explicit, and navigation is the LAST resort:
 *
 *   1. inline  -- an inline support inbox on this page (declared via
 *                 data-inline-target, or discovered by scanning for a support
 *                 inbox root). Reveals it in place. NEVER leaves the page.
 *   2. popup   -- the floating live-chat popup, if live-chat.js is present.
 *   3. page    -- full inbox URL. Only when neither surface exists, or when
 *                 the delivery preference explicitly asks for it.
 *
 * Vanilla JS, no jQuery, matching the rest of the plugin.
 *
 * @since 1.25.0
 * @since 1.26.0 Inline-first resolution; popup hand-off repaired; delivery preference.
 */
(function () {
	"use strict";

	function post(root, nonce, path, body) {
		return fetch(String(root).replace(/\/$/, "") + path, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				"X-WP-Nonce": nonce || ""
			},
			credentials: "same-origin",
			body: JSON.stringify(body || {})
		}).then(function (r) {
			return r.json().then(function (j) {
				if (!r.ok) throw j;
				return j;
			});
		});
	}

	/**
	 * Resolve the live-chat popup API tolerantly.
	 *
	 * live-chat.js publishes `window.zymargLiveChat` with an `open()` method.
	 * The historic (broken) probe here looked for `window.ZymargLiveChat` with
	 * `openConversation()`. Both spellings and both method names are accepted so
	 * this keeps working if either side is renamed later.
	 */
	function popupApi() {
		var api = window.zymargLiveChat || window.ZymargLiveChat || null;
		if (!api) return null;

		var open = null;
		if (typeof api.open === "function") open = api.open;
		else if (typeof api.openConversation === "function") open = api.openConversation;
		if (!open) return null;

		return {
			open: function (id) { return open.call(api, id); }
		};
	}

	/**
	 * Strip `hidden` / `display:none` from a node and every ancestor up to
	 * <body>. Hosts wrap the inline inbox in a hidden container, and that
	 * container is sometimes nested, so unhiding only the inbox root would
	 * leave it invisible inside a collapsed parent.
	 */
	/**
	 * A sensible `display` to force on an element the host stylesheet collapsed.
	 *
	 * Forcing `block` onto a table part or a list item would wreck the layout,
	 * so the few structural tags that have a meaningful intrinsic display are
	 * mapped explicitly. Everything else is a wrapper and gets `block`.
	 */
	function defaultDisplayFor(elm) {
		switch ((elm.tagName || "").toUpperCase()) {
			case "TR":     return "table-row";
			case "TD":
			case "TH":     return "table-cell";
			case "THEAD":  return "table-header-group";
			case "TBODY":  return "table-row-group";
			case "TABLE":  return "table";
			case "LI":     return "list-item";
			case "SPAN":
			case "A":
			case "BUTTON": return "inline-flex";
			default:       return "block";
		}
	}

	/**
	 * Elements whose `display` we had to force, so hideInline() can undo it.
	 *
	 * Exclusivity depends on this: if a forced ancestor kept its inline
	 * `display` after the inbox was collapsed again, the in-page inbox would
	 * stay on screen behind the popup, which is the very thing popup-first
	 * delivery exists to prevent.
	 */
	var forcedAncestors = [];

	function reveal(node) {
		/*
		 * 1.32.8 — start at the inbox root INSIDE the container, not at the
		 * container itself.
		 *
		 * This walk only ever went UPWARDS, which silently assumed the node it
		 * was handed IS the inbox. It usually is not: hosts point
		 * `data-inline-target` at their own wrapper (#zymarg-os-support-inbox,
		 * #zymarg-vd-support-inbox), and under popup_first renderInline() stamps
		 * `hidden style="display:none"` on the inbox root itself — a CHILD of
		 * that wrapper. So the wrapper was prised open while the inbox inside it
		 * stayed hidden, leaving a container that measured 0 tall. Closing the
		 * popup therefore showed nothing, and from 1.32.7 the verified hand-off
		 * read that empty wrapper as "not rendered" and navigated to the full
		 * inbox page instead of revealing it in place.
		 *
		 * That is what 1.32.4 and 1.32.6 were really chasing: the blocker was
		 * not an ancestor a theme had collapsed, it was a descendant this plugin
		 * hid itself. Starting the walk at the inbox root clears it and still
		 * covers every ancestor above it, so those fixes are unaffected. When
		 * the node IS the inbox root this resolves to exactly the old
		 * behaviour.
		 */
		var start = inboxRootIn(node) || node;

		var n = start;
		while (n && n !== document.body && n.nodeType === 1) {
			if (n.hasAttribute("hidden")) n.removeAttribute("hidden");
			if (n.style && "none" === n.style.display) n.style.display = "";

			/*
			 * 1.32.4 — defeat a CLASS-BASED `display:none` as well.
			 *
			 * Clearing the `hidden` attribute and an inline `display:none` is
			 * not enough: when the host wraps the inbox in a container that a
			 * stylesheet collapses (`.is-hidden{display:none}` and friends),
			 * neither of the two lines above can touch it. The inbox then ends
			 * up un-hidden but never laid out, measuring 0x0 with a null
			 * offsetParent, so closing the popup under popup-first delivery
			 * looked like nothing happened at all — the customer only ever saw
			 * the popup, and the full inbox they were promised never arrived.
			 *
			 * An inline style with `important` is the only thing that reliably
			 * beats a stylesheet rule that may itself be `!important`. Every
			 * element touched is recorded so hideInline() can put it back and
			 * one-surface-at-a-time still holds.
			 */
			try {
				if ("none" === getComputedStyle(n).display) {
					n.style.setProperty("display", defaultDisplayFor(n), "important");
					if (forcedAncestors.indexOf(n) === -1) forcedAncestors.push(n);
				}
			} catch (e) { /* getComputedStyle can throw on detached nodes */ }

			n = n.parentNode;
		}

		// 1.32.6 — second pass, only when the first one did not do the job.
		// 1.32.8 — measured from the inbox root, so an empty host wrapper can no
		// longer read as "rendered" (nor a revealed inbox as "collapsed").
		forceRendered(start);
	}

	/** Is the element actually laid out (not merely un-hidden)? */
	function isRendered(elm) {
		if (!elm) return false;
		if (!elm.offsetParent && "fixed" !== (getComputedStyle(elm).position || "")) return false;
		var r = elm.getBoundingClientRect();
		return r.width > 0 && r.height > 0;
	}

	/**
	 * Last-resort pass for a node that is un-hidden yet still not rendered.
	 *
	 * 1.32.4 taught reveal() to force `display` on ancestors a stylesheet had
	 * collapsed, which covers `display:none`. It does not cover the other ways a
	 * theme can collapse a wrapper — `visibility:hidden`, `max-height:0`, or the
	 * `height:0 + overflow:hidden` pairing that accordions and tab panels use.
	 * When one of those is in play the inbox still measures 0x0 with a null
	 * offsetParent, and closing the popup still looks like nothing happened.
	 *
	 * This runs only when the node is genuinely not rendered, so a normal page
	 * is never touched. Everything forced is recorded for hideInline() to undo,
	 * and if it STILL cannot get the inbox on screen it says so in the console
	 * with the offending element — so the cause is visible immediately instead
	 * of needing another round of guessing.
	 */
	function forceRendered(node) {
		if (isRendered(node)) return;

		var n = node, depth = 0, touched = [];
		while (n && n !== document.body && n.nodeType === 1 && depth < 20) {
			try {
				var cs = getComputedStyle(n);
				var fixes = [];

				if ("hidden" === cs.visibility)  { n.style.setProperty("visibility", "visible", "important"); fixes.push("visibility"); }
				if ("0px" === cs.maxHeight)      { n.style.setProperty("max-height", "none", "important");    fixes.push("max-height"); }
				if ("0px" === cs.height && "visible" !== cs.overflow) { n.style.setProperty("height", "auto", "important"); fixes.push("height"); }
				if ("0" === cs.opacity)          { n.style.setProperty("opacity", "1", "important");          fixes.push("opacity"); }

				if (fixes.length) {
					if (forcedAncestors.indexOf(n) === -1) forcedAncestors.push(n);
					touched.push((n.tagName || "?").toLowerCase() + (n.className ? "." + String(n.className).split(" ")[0] : "") + " [" + fixes.join(",") + "]");
				}
			} catch (e) { /* detached node */ }

			n = n.parentNode;
			depth++;
		}

		if (!isRendered(node)) {
			// Deliberately loud: this is the difference between "the inbox is
			// there" and "the customer sees nothing", and it is invisible in the
			// UI by definition.
			try {
				var chain = [], m = node, d2 = 0;
				while (m && m !== document.body && m.nodeType === 1 && d2 < 8) {
					var c2 = getComputedStyle(m);
					if ("none" === c2.display || "hidden" === c2.visibility || "0px" === c2.height || "0px" === c2.maxHeight) {
						chain.push((m.tagName || "?").toLowerCase() + (m.className ? "." + String(m.className).split(" ")[0] : "") + " {display:" + c2.display + ";visibility:" + c2.visibility + ";height:" + c2.height + ";max-height:" + c2.maxHeight + "}");
					}
					m = m.parentNode; d2++;
				}
				console.warn("[ZYMARG Communication] The in-page support inbox could not be shown. Something on this page is still collapsing it:", chain.length ? chain : "(no obvious CSS blocker — the node may be detached or zero-sized for another reason)", "| forced so far:", touched);
			} catch (e) {}
		}
	}

	/** Undo everything reveal()/forceRendered() had to force. */
	function unforceAncestors() {
		while (forcedAncestors.length) {
			var elm = forcedAncestors.pop();
			try {
				elm.style.removeProperty("display");
				elm.style.removeProperty("visibility");
				elm.style.removeProperty("max-height");
				elm.style.removeProperty("height");
				elm.style.removeProperty("opacity");
			} catch (e) {}
		}
	}

	/** The inbox root inside (or equal to) a revealed container. */
	function inboxRootIn(node) {
		if (!node || node.nodeType !== 1) return null;
		if (node.matches && node.matches("[data-zymarg-inbox]")) return node;
		return node.querySelector ? node.querySelector("[data-zymarg-inbox]") : null;
	}

	/**
	 * Find an inline support surface on this page.
	 *
	 * Preference is the host's explicit contract (`data-inline-target`), which
	 * both the theme (#zymarg-os-support-inbox) and the vendor dashboard
	 * (#zymarg-vd-support-inbox) already set. Falling back to discovery means a
	 * host that renders [zymarg_support_chat mode="inline"] without wiring the
	 * attribute still gets in-place behaviour for free.
	 */
	function inlineSurface(btn) {
		var sel = btn.getAttribute("data-inline-target") || "";
		if (sel) {
			try {
				var explicit = document.querySelector(sel);
				if (explicit) return explicit;
			} catch (e) { /* malformed selector — fall through to discovery */ }
		}

		var found = document.querySelector('[data-zymarg-inbox][data-context="support"]');
		if (!found) return null;

		// Climb to the outermost hidden wrapper so we reveal the whole thing.
		var top = found, walk = found.parentNode;
		while (walk && walk !== document.body && walk.nodeType === 1) {
			if (walk.hasAttribute("hidden") || (walk.style && "none" === walk.style.display)) top = walk;
			walk = walk.parentNode;
		}
		return top;
	}

	/**
	 * Once the inbox is open in place, the intro line and the Contact Support /
	 * Help Center cards above it are just clutter behind the conversation, so
	 * they are hidden. This runs ONLY after a thread actually opens inline — a
	 * cancelled Smart Intake never reaches here, so the prompt stays intact.
	 *
	 * Host-agnostic: it hides the card group the clicked trigger lives in (the
	 * theme's [data-zymarg-support-cards] / .cards-grid, or the vendor
	 * dashboard's .zvd-support-tiles) plus the panel description immediately
	 * before it. The elements are remembered so restoreTriggerChrome() can bring
	 * them back if the surface is ever collapsed. Fully guarded — a host without
	 * these nodes simply keeps its layout.
	 */
	var hiddenChrome = [];

	/**
	 * Collapse one element, remembering how it looked so showEl() can undo it.
	 *
	 * `track` is the list restoreTriggerChrome() will later drain. It is a
	 * parameter rather than always `hiddenChrome` for a reason: the in-page inbox
	 * is collapsed through this same function, and if it landed on that list then
	 * dismissing support with Escape would "restore" the inbox and throw it open
	 * — the exact two-surfaces-at-once bug this release exists to fix. Chrome is
	 * tracked; the inbox is not, because its own restore path is openInline().
	 */
	function hideEl(elm, track) {
		if (!elm || elm.__zymargSupportHidden) return;
		elm.__zymargSupportHidden = { hidden: elm.hasAttribute("hidden"), display: elm.style ? elm.style.display : "" };
		try { elm.setAttribute("hidden", ""); } catch (e) {}
		if (elm.style) elm.style.display = "none";
		if (track) track.push(elm);
	}

	/** Put one element back exactly as it was before hideEl() touched it. */
	function showEl(elm) {
		if (!elm || !elm.__zymargSupportHidden) return;
		var prev = elm.__zymargSupportHidden;
		try { if (!prev.hidden) elm.removeAttribute("hidden"); } catch (e) {}
		if (elm.style) elm.style.display = prev.display || "";
		delete elm.__zymargSupportHidden;
	}

	function hideTriggerChrome(btn) {
		if (!btn || typeof btn.closest !== "function") return;
		try {
			// The host card group, when there is one.
			var cards = btn.closest('[data-zymarg-support-cards], .zvd-support-tiles, .cards-grid');

			if (cards) {
				// The description sits just before the card group in both hosts.
				var prev = cards.previousElementSibling;
				if (prev && (
					(prev.classList && (prev.classList.contains("panel-desc") || prev.classList.contains("zvd-support-desc"))) ||
					prev.hasAttribute("data-zymarg-support-desc")
				)) {
					hideEl(prev, hiddenChrome);
				}

				hideEl(cards, hiddenChrome);
			} else {
				// 1.30.0 — no recognised card group. Before this the function simply
				// gave up here, which is why a "Contact support" button placed in a
				// plain wrapper stayed visible behind the opened conversation and the
				// customer saw the call to action twice. Hide the button itself as a
				// floor, so the duplicate can never survive whatever the host markup
				// happens to be.
				hideEl(btn, hiddenChrome);
			}
		} catch (e) { /* leave the layout untouched on any surprise */ }

		// 1.32.1 — belt-and-braces. hideTriggerChrome() historically only touched
		// the CLICKED trigger's card group. If the host page carries a SECOND
		// "Contact Support" button anywhere else on the page (a sidebar link,
		// a footer callout, another shortcode further down), that duplicate
		// stayed visible right next to the opened conversation. Sweep ALL
		// support triggers on the page now so no duplicate can survive.
		//
		// 1.32.2 — but NEVER touch a trigger that lives inside a ticket panel.
		// renderCustomerPanel() renders "Start a new case" as a real support
		// trigger inside `.zymarg-ticket` when a case was auto-closed. That is
		// not a duplicate call to action, it is the customer's only way forward,
		// and hiding it strands them.
		try {
			var all = document.querySelectorAll('[data-zymarg-support-start]');
			for (var i = 0; i < all.length; i++) {
				var other = all[i];
				if (other === btn) continue;
				if (other.__zymargSupportHidden) continue;
				if (other.closest && other.closest(".zymarg-ticket")) continue;
				hideEl(other, hiddenChrome);
			}
		} catch (e) { /* never let this abort the handoff */ }
	}

	/**
	 * Bring back whatever hideTriggerChrome() hid.
	 *
	 * Promised in a comment since 1.28.1 but never actually implemented, which
	 * meant `hiddenChrome` was write-only: once the cards went away nothing could
	 * restore them, so dismissing support left the page permanently missing its
	 * own call to action until a reload.
	 */
	function restoreTriggerChrome() {
		while (hiddenChrome.length) showEl(hiddenChrome.pop());
	}

	/**
	 * Collapse an inline surface, remembering how it looked.
	 *
	 * The mirror of reveal(). Only the node itself is touched — never its
	 * ancestors — because reveal() walks UP the tree clearing `hidden`, so
	 * hiding a parent here would have it strip that parent again later and drag
	 * unrelated host chrome back on screen with it.
	 *
	 * Deliberately NOT tracked in `hiddenChrome`: Escape must leave the inbox
	 * collapsed, and restoreTriggerChrome() drains that list.
	 */
	function hideInline(node) {
		if (!node) return;
		// 1.32.4 — drop any forced ancestor display first, otherwise a wrapper
		// reveal() had to prise open would keep the inbox on screen behind the
		// popup and break one-surface-at-a-time.
		unforceAncestors();
		// 1.32.10 — hand the host column its gutter back before collapsing, so
		// the Support landing cards are never left flush against the sidebar
		// while the thread sits in the popup instead.
		markLive(inboxRootIn(node), false);
		hideEl(node, null);
	}

	/**
	 * Flag/unflag the inbox root as on screen for inbox.css (1.32.10).
	 *
	 * Deliberately a class on the INBOX rather than on the host wrapper: the
	 * wrapper is page-author markup whose id differs per host
	 * (#zymarg-os-support-inbox, #zymarg-vd-support-inbox) and may not exist at
	 * all when the shortcode is dropped straight onto a page, whereas the inbox
	 * root is always ours.
	 */
	function markLive(rootEl, live) {
		if (!rootEl || !rootEl.classList) return;
		try {
			rootEl.classList[ live ? "add" : "remove" ]("is-support-live");
		} catch (e) { /* non-fatal: layout falls back to the host's own gutter */ }
	}

	/**
	 * Keep the presence dot on the single header row (1.32.12).
	 *
	 * `.is-compact-head` collapses the thread pane's duplicate header row, and
	 * the "active now" GREEN DOT lives inside it: inbox.js builds
	 * `.zymarg-inbox__presence` as a child of `.zymarg-inbox__thread-header`
	 * (renderThread), so collapsing that row would take the dot with it and the
	 * customer would lose the only signal that an agent is on the other end.
	 *
	 * The dot is therefore adopted into the surviving header row instead of
	 * being hidden. Re-parenting is safe precisely because inbox.js holds the
	 * element BY REFERENCE (`livePresenceEl`) and mutates that same node's
	 * hidden/className/textContent when the presence poll returns — so its live
	 * updates keep working from its new home, with no change needed there.
	 *
	 * Re-applied through a MutationObserver because inbox.js does
	 * `threadEl.innerHTML = ""` and builds a BRAND NEW presence element on every
	 * thread render, which would otherwise silently strand the dot in the
	 * collapsed row from the second render onwards. Moving the node out of the
	 * observed subtree fires one more record, the next pass finds nothing to
	 * move, and it settles — no loop.
	 */
	function adoptPresenceIntoHead(rootEl) {
		if (!rootEl || !rootEl.classList || !rootEl.classList.contains("is-compact-head")) return;

		var head   = rootEl.querySelector(".zymarg-inbox__header");
		var thread = rootEl.querySelector(".zymarg-inbox__thread");
		if (!head || !thread) return;

		function adopt() {
			var dot = thread.querySelector(".zymarg-inbox__presence");
			if (!dot) return;

			/*
			 * Drop the dot adopted from a PREVIOUS render first.
			 *
			 * inbox.js clears the thread pane with `innerHTML = ""` and builds a
			 * fresh presence element every render. The one adopted last time is
			 * no longer in that pane to be cleared with it — it is sitting here —
			 * so without this every thread render would stack another dot on the
			 * row. Caught by _verify/support-inbox-presence.test.js on the second
			 * render; a single-render check passes either way.
			 */
			var adopted = head.querySelectorAll(".zymarg-inbox__presence");
			for (var i = 0; i < adopted.length; i++) {
				if (adopted[i] !== dot && adopted[i].parentNode) {
					adopted[i].parentNode.removeChild(adopted[i]);
				}
			}

			// Straight after the title, so it reads "Support team ●" rather than
			// being flung to the far end of the row by its own margin-left:auto.
			var title = head.querySelector(".zymarg-inbox__title");
			if (title && title.parentNode === head) head.insertBefore(dot, title.nextSibling);
			else head.appendChild(dot);
		}

		adopt();

		if (rootEl.__zymargPresenceObserver) return;
		try {
			var obs = new MutationObserver(adopt);
			obs.observe(thread, { childList: true, subtree: true });
			rootEl.__zymargPresenceObserver = obs;
		} catch (e) { /* no MutationObserver: the first adopt() above still ran */ }
	}

	/**
	 * Which conversation is on screen, and where.
	 *
	 * Remembered per page so the two-way popup <-> inline toggle can hand the
	 * same thread back and forth without re-hitting /support/start.
	 *
	 * `ownsPopup` records that WE put a support thread into the shared popup.
	 * The popup is also used for ordinary buyer/vendor chat, and popup-closed
	 * fires for every one of those too — without this flag, a customer closing a
	 * vendor conversation on the support page would have the support inbox thrown
	 * open at them for no reason.
	 */
	var state = { conversationId: 0, inlineNode: null, triggerBtn: null, ownsPopup: false, inboxUrl: "" };

	/**
	 * Best known URL of the full inbox (1.32.7).
	 *
	 * Recorded from whichever response mentions it — /support/start and
	 * /support/config both return `inbox_url` — so closing the popup can fall
	 * back to navigation when the in-page surface cannot be shown. Falls back to
	 * the trigger's own data attribute if the host supplied one.
	 */
	function rememberInboxUrl(url) {
		if (url && typeof url === "string") state.inboxUrl = url;
	}

	function knownInboxUrl(btn) {
		if (state.inboxUrl) return state.inboxUrl;
		if (btn && btn.getAttribute) {
			var a = btn.getAttribute("data-inbox-url") || "";
			if (a) return a;
		}
		var cfg = window.zymargLiveChat || {};
		return cfg.inboxUrl || cfg.inbox_url || "";
	}

	/* ------------------------------------------------------------------
	   Ownership across page loads (1.31.0)

	   `state` above is per-page. From 1.31.0 the popup itself survives
	   navigation, so without persisting ownership the popup would come back
	   holding a support thread while this file had forgotten all about it — and
	   closing it would no longer reveal the in-page inbox.

	   Only the conversation id is stored, and it is only trusted when it matches
	   the id the popup actually restored.
	   ------------------------------------------------------------------ */
	function ownKey() {
		var cfg = window.zymargLiveChat || {};
		var uid = (cfg.userId || 0);
		return "zymargSupportOwnsPopup:" + uid;
	}

	function ownWrite(cid) {
		try {
			var key = ownKey();
			var id = parseInt(cid, 10) || 0;
			if (id > 0) window.localStorage.setItem(key, String(id));
			else window.localStorage.removeItem(key);
		} catch (e) {}
	}

	function ownRead() {
		try {
			return parseInt(window.localStorage.getItem(ownKey()), 10) || 0;
		} catch (e) {
			return 0;
		}
	}

	/** Find the inline support surface without needing a trigger to ask from. */
	function inlineSurfaceFromDocument() {
		var found = document.querySelector('[data-zymarg-inbox][data-context="support"]');
		return found || null;
	}

	/**
	 * Best-known conversation id.
	 *
	 * Falls back to the attribute inbox.js stamps on the root when it opens a
	 * thread, so the "Open in popup" control still works after a page load where
	 * this script never saw the original Contact Support click.
	 */
	function knownConversationId() {
		if (state.conversationId) return state.conversationId;

		var root = inlineSurfaceFromDocument();
		root = root ? inboxRootIn(root) : null;
		var id = root ? parseInt(root.getAttribute("data-active-conversation") || "0", 10) : 0;

		return id > 0 ? id : 0;
	}

	/**
	 * Reveal the inline surface and point it at the resolved thread.
	 *
	 * 1.30.0: hiding the trigger chrome moved OUT of here and up into handoff(),
	 * because it used to run only on this path — so opening the thread in the
	 * popup instead left the "Contact support" call to action sitting there, and
	 * the customer saw it twice.
	 */
	function openInline(node, conversationId, btn) {
		// The node may have been collapsed by hideInline() rather than by the
		// server, so clear that bookkeeping before reveal() walks the tree.
		showEl(node);
		reveal(node);

		var rootEl = inboxRootIn(node);

		// 1.32.10 — mark the inbox as genuinely on screen.
		//
		// inbox.css keys the support surface's host adaptation (dropping the
		// host column's gutter and width cap, squaring the sidebar seam) on
		// this class rather than on the inbox merely EXISTING. Under
		// popup-first the inbox is in the DOM from page load but hidden behind
		// the popup, and stripping the column's padding then would flatten the
		// Support landing cards for no reason. Set here, cleared in
		// hideInline(), so the column's gutter tracks the inbox exactly.
		markLive(rootEl, true);
		adoptPresenceIntoHead(rootEl);

		// inbox.js exposes openConversation() from 1.26.0. When present we drive
		// it directly; otherwise we announce an event it also listens for. Either
		// path is a no-op on older builds, which just show the newest thread.
		var api = window.zymargInbox;
		if (rootEl && api && typeof api.openConversation === "function") {
			try { api.openConversation(conversationId, rootEl); } catch (e) { /* non-fatal */ }
		} else {
			try {
				document.dispatchEvent(new CustomEvent("zymarg-comm:open-conversation", {
					detail: { conversationId: conversationId, root: rootEl || null }
				}));
			} catch (e) { /* IE-era browsers — the reveal above still worked */ }
		}

		try {
			node.scrollIntoView({ behavior: "smooth", block: "start" });
		} catch (e) {
			try { node.scrollIntoView(); } catch (e2) {}
		}

		// Put the cursor where they are meant to type.
		if (rootEl) {
			var ta = rootEl.querySelector(".zymarg-inbox__composer textarea");
			if (ta) { try { ta.focus({ preventScroll: true }); } catch (e) { try { ta.focus(); } catch (e2) {} } }
		}

		return true;
	}

	/**
	 * Delivery preference: where a support thread should be shown.
	 *
	 *   popup_first (default) — popup now; closing it reveals the in-page inbox
	 *   auto                  — in-page inbox if this page has one, else popup
	 *   popup                 — popup only; never reveal the in-page inbox
	 *   page                  — always the full inbox page
	 *   inline                — legacy (pre-1.30.0); resolves exactly like auto
	 *
	 * Per-control `data-delivery` wins over the site-wide setting so a single
	 * shortcode can opt out without changing global config.
	 */
	function delivery(btn) {
		var local = (btn && btn.getAttribute("data-delivery") || "").toLowerCase().trim();
		if (local) return local;

		var cfg = window.zymargLiveChat || {};
		var pref = String(cfg.supportDelivery || "popup_first").toLowerCase().trim();
		return pref || "popup_first";
	}

	/**
	 * Show the thread in the popup, collapsing the in-page inbox first.
	 *
	 * Exclusivity is the whole point: before 1.30.0 the popup branch opened the
	 * popup and left the in-page inbox visible behind it, so "popup" delivery
	 * still showed a second window. One surface at a time, always.
	 */
	function openPopup(popup, inline, conversationId, btn) {
		state.conversationId = conversationId;
		state.inlineNode     = inline || inlineSurfaceFromDocument();
		state.triggerBtn     = btn || state.triggerBtn;
		state.ownsPopup      = true;
		ownWrite(conversationId);

		if (state.inlineNode) hideInline(state.inlineNode);
		markPopupAsSupport(conversationId);
		popup.open(conversationId);

		return true;
	}

	/**
	 * Tell support-ticket.js that the popup is holding a support case (1.32.0).
	 *
	 * These are the same two attributes the in-page inbox exposes, so the ticket
	 * panel picks the popup up with no new plumbing: `data-context` makes it
	 * eligible, `data-active-conversation` says which case, and its
	 * MutationObserver reacts to the latter changing.
	 *
	 * Before this the popup showed nothing of the Smart Intake answers — no
	 * topic, no order, no status — because the panel only ever mounted on the
	 * inbox. Cleared again in unmarkPopup() so an ordinary buyer/vendor chat
	 * never inherits a support panel.
	 */
	function markPopupAsSupport(conversationId) {
		var root = document.querySelector("[data-zymarg-live-chat]");
		if (!root) return;

		try {
			root.setAttribute("data-context", "support");
			root.setAttribute("data-active-conversation", String(parseInt(conversationId, 10) || 0));

			// 1.32.3 — apply the support header label right now, rather than
			// waiting for live-chat.js to call setTitle() again.
			//
			// setTitle() keys off data-context, but it can run BEFORE this
			// function does. A popup restored after a page load (1.31.0 session
			// persistence) titles its own header from the conversation payload
			// while this file is still working out that the thread is a support
			// case — so the customer was left looking at "Chat". Attributes do
			// not survive navigation, only the stored conversation id does, so
			// this stamping always trails the popup's own render on that path.
			//
			// Writing the label here makes both orderings converge: whichever
			// runs last, the header ends up correct. Same localised string
			// live-chat.js uses, so there is one source of truth.
			var titleEl = root.querySelector("[data-zymarg-live-chat-title]");
			if (titleEl) {
				var lc = window.zymargLiveChat || {};
				titleEl.textContent = (lc.i18n && lc.i18n.supportTitle) || "Support team";
			}

			document.dispatchEvent(new CustomEvent("zymarg:section-loaded"));
		} catch (e) { /* non-fatal: the popup simply keeps no panel */ }
	}

	/** Drop the support markers when the popup no longer holds our thread. */
	function unmarkPopup() {
		var root = document.querySelector("[data-zymarg-live-chat]");
		if (!root) return;

		try {
			root.removeAttribute("data-context");
			root.removeAttribute("data-active-conversation");
			var panel = root.querySelector(".zymarg-ticket");
			if (panel && panel.parentNode) panel.parentNode.removeChild(panel);
		} catch (e) {}
	}

	/**
	 * Hand the resolved thread to a surface. Returns true when handled without
	 * navigating, false when the caller should fall back to the inbox URL.
	 *
	 * Whichever surface wins, the trigger chrome is retired once — the call used
	 * to live inside openInline() and so was skipped on every popup path.
	 */
	function handoff(btn, conversationId) {
		var mode   = delivery(btn);
		var inline = inlineSurface(btn);
		var popup  = popupApi();

		if ("page" === mode) return false;

		// Remember the thread even when the popup is not involved, so the
		// in-page "Open in popup" control has something to hand over later.
		state.conversationId = conversationId;
		state.inlineNode     = inline || inlineSurfaceFromDocument();
		state.triggerBtn     = btn;

		var handled = false;

		if ("popup_first" === mode) {
			// The quick lane. Only fall back to the in-page inbox when the popup
			// genuinely is not available (the surface.popup flag is off, so
			// live-chat.js never published open()).
			if (popup) handled = openPopup(popup, inline, conversationId, btn);
			else if (inline) handled = openInline(inline, conversationId, btn);
		} else if ("popup" === mode) {
			if (popup) handled = openPopup(popup, inline, conversationId, btn);
			else if (inline) handled = openInline(inline, conversationId, btn);
		} else {
			// auto (and the legacy `inline` value): staying on the page the
			// customer deliberately navigated to beats everything else.
			//
			// The old code had a viewport split here — popup on desktop, popup on
			// mobile — where both arms did the identical thing, so it was dead
			// weight pretending to be a mobile optimisation. Removed.
			if (inline) handled = openInline(inline, conversationId, btn);
			else if (popup) handled = openPopup(popup, inline, conversationId, btn);
		}

		if (handled) hideTriggerChrome(btn);

		return handled;
	}

	function wire(btn) {
		if (!btn || btn.getAttribute("data-zymarg-support-ready") === "1") return;
		btn.setAttribute("data-zymarg-support-ready", "1");

		btn.addEventListener("click", function () {
			if (btn.disabled) return;

			var root = btn.getAttribute("data-rest") || "";
			var nonce = btn.getAttribute("data-nonce") || "";
			var labelEl = btn.querySelector(".zymarg-support-trigger__label");
			var original = labelEl ? labelEl.textContent : "";
			var busy = btn.getAttribute("data-busy-label") || "";

			// Smart Intake (1.27.0) is an OPTIONAL layer. When the intake module
			// is present it collects a topic / order / subject first and returns
			// the context to send; returning null means the customer backed out,
			// so we abort without opening a thread. When the module is absent the
			// flow is byte-for-byte the Stage 0 behaviour: POST an empty body.
			var intake = window.zymargSupportIntake;
			var collect = (intake && typeof intake.collect === "function")
				? intake.collect(btn)
				: Promise.resolve({});

			Promise.resolve(collect).then(function (context) {
				if (context === null || context === false) {
					// Customer cancelled the intake — leave everything untouched.
					return;
				}

				btn.disabled = true;
				btn.setAttribute("aria-busy", "true");
				if (labelEl && busy) labelEl.textContent = busy;

				startThread(context || {});
			});

			function startThread(context) {
			post(root, nonce, "/support/start", context)
				.then(function (res) {
					var d = (res && res.data) || res || {};
					var id = d.conversation_id || 0;

					// 1.32.7 — keep the inbox URL for the close fallback below.
					rememberInboxUrl(d.inbox_url);

					if (id && handoff(btn, id)) {
						restore();
						return;
					}

					// Last resort only. Everything above failed to find a surface
					// on this page, so the full inbox is genuinely the only place
					// the thread can be read.
					if (d.inbox_url) {
						window.location.href = d.inbox_url;
						return;
					}
					restore();
				})
				.catch(function () {
					restore();
					var msg = btn.getAttribute("data-error-label") || "";
					if (msg) window.alert(msg);
				});

			function restore() {
				btn.disabled = false;
				btn.removeAttribute("aria-busy");
				if (labelEl) labelEl.textContent = original;
			}
			} // end startThread
		});
	}

	function boot() {
		var nodes = document.querySelectorAll("[data-zymarg-support-start]");
		for (var i = 0; i < nodes.length; i++) wire(nodes[i]);

		/*
		 * 1.32.10 — an inbox the SERVER rendered visible is already on screen.
		 *
		 * Under `auto` / `inline` delivery there is no popup hand-off and no
		 * click to hang the host adaptation off, so the column would keep its
		 * gutter and the surface would still not match Messages. Verified with
		 * isRendered() rather than assumed: under popup-first the inbox carries
		 * `hidden`, and on a page whose own wrapper is collapsed it is present
		 * but not visible — neither should move the host's gutter.
		 *
		 * Re-runs on the hosts' section-loaded events below, so an AJAX section
		 * swap re-evaluates instead of going stale.
		 */
		var live = inlineSurfaceFromDocument();
		if (live && !live.hasAttribute("hidden") && isRendered(live)) markLive(live, true);
		// Independent of the live check: the dot has to be adopted wherever the
		// compact head is in play, including a surface the popup has not touched
		// yet, so the first presence poll cannot land in the collapsed row.
		if (live) adoptPresenceIntoHead(live);

		// 1.32.2 — the 1.32.1 "proactive duplicate kill" that used to live here
		// has been REMOVED, because it created two dead ends worse than the
		// duplicate it was trying to fix:
		//
		//  a) It keyed off "the support inbox has any conversation row in it",
		//     but a CLOSED case still shows in that list. So a customer whose
		//     case had ended got the Contact Support CTA hidden and had no way
		//     to open a new one.
		//  b) renderCustomerPanel() re-announces the section (dispatching
		//     `zymarg:section-loaded`) right after it renders the "Start a new
		//     case" button — and that button is itself a
		//     [data-zymarg-support-start]. This listener calls boot() on that
		//     event, so the sweep hid the very button it had just been told
		//     about, one tick after it appeared.
		//
		// The page-reload case it was meant to cover is handled properly and
		// authoritatively on the server instead: SupportChat::renderTrigger()
		// asks SupportService::hasOpenTicketForUser(), which is true only for
		// genuinely OPEN tickets, and renders the trigger hidden. Click-time
		// duplicates are handled by hideTriggerChrome() below.
	}

	if (document.readyState === "loading") {
		document.addEventListener("DOMContentLoaded", boot);
	} else {
		boot();
	}

	// Hosts that swap content over AJAX (the theme account page and the vendor
	// dashboard both do) re-announce their sections; re-scan on those events.
	document.addEventListener("zymarg-vd:section-loaded", boot);
	document.addEventListener("zymarg:section-loaded", boot);

	/* ------------------------------------------------------------------
	   1.30.0 — the popup <-> in-page inbox toggle

	   Closing the popup should not dead-end the customer. Under popup-first
	   delivery the in-page inbox is rendered hidden behind the popup, so closing
	   the popup reveals it with the same conversation already loaded, and the
	   "Open in popup" control in its header hands the thread back.

	   Exactly one surface is ever on screen. Escape is the deliberate exception:
	   reason "dismiss" means the customer wants out, so nothing is revealed and
	   the trigger chrome comes back.
	   ------------------------------------------------------------------ */

	document.addEventListener("zymarg-comm:popup-closed", function (e) {
		var detail = e.detail || {};
		var reason = detail.reason || "close";

		// Not our thread in there — an ordinary buyer/vendor chat closing. Leave
		// the page alone.
		if (!state.ownsPopup) return;

		// Escape / parking the puck: go back to plain browsing.
		if ("dismiss" === reason) {
			state.ownsPopup = false;
			ownWrite(0);
			unmarkPopup();
			restoreTriggerChrome();
			return;
		}

		if ("popup" === delivery(state.triggerBtn)) return; // popup-only: nothing to reveal.

		var node = state.inlineNode || inlineSurfaceFromDocument();
		if (!node) {
			/*
			 * No in-page inbox on this page — a footer help link, or a page
			 * carrying only the trigger shortcode.
			 *
			 * 1.32.8: this used to return silently, which lost the case. The
			 * 1.32.7 "verify the hand-off, navigate if it failed" guarantee
			 * lives further down this handler, so it was never reached on the
			 * one path that needs it most: there is not merely a collapsed
			 * inbox here, there is no inbox at all. Popup-first promises the
			 * full inbox when the popup closes, so honour it.
			 */
			state.ownsPopup = false;
			ownWrite(0);
			unmarkPopup();

			var soloUrl = knownInboxUrl(state.triggerBtn);
			if (soloUrl) {
				window.location.href = soloUrl;
				return;
			}

			// Nowhere to send them: put the call to action back so the customer
			// can re-open the case instead of being left with a dead page.
			restoreTriggerChrome();
			return;
		}

		var id = detail.conversationId || knownConversationId();
		state.conversationId = id || state.conversationId;
		state.inlineNode     = node;
		state.ownsPopup      = false; // The inbox holds the thread now.
		ownWrite(0);
		unmarkPopup();

		openInline(node, state.conversationId, state.triggerBtn);
		hideTriggerChrome(state.triggerBtn);

		/*
		 * 1.32.7 — guaranteed delivery of the full inbox.
		 *
		 * Popup-first promises the roomy in-page inbox when the popup closes.
		 * Whether that promise can be kept depends on the host page: the inbox
		 * is revealed inside whatever container the theme put it in, and if that
		 * container is collapsed by CSS the inbox ends up present but unrendered
		 * (0x0, null offsetParent) and the customer sees nothing at all. 1.32.4
		 * and 1.32.6 taught reveal() to prise open five different collapse
		 * mechanisms, which is a game of whack-a-mole against every theme and
		 * page builder in existence, and it cannot be won in general.
		 *
		 * So: try in place, verify, and if the inbox genuinely is not on screen,
		 * NAVIGATE to the full inbox instead. Navigation is not the nicest
		 * outcome, but it is the difference between the customer reading their
		 * conversation and the customer staring at a page where their support
		 * case appears to have evaporated. Correct beats elegant.
		 *
		 * The check is deferred a tick so the browser has laid the revealed
		 * inbox out before it is measured.
		 *
		 * 1.32.8 — measure the INBOX, not the host wrapper it sits in. A wrapper
		 * whose only child is still hidden measures 0x0 however wide the page is,
		 * so this check used to condemn a perfectly healthy page and navigate
		 * away from an inbox that was about to appear.
		 */
		var revealedNode = inboxRootIn(node) || node;
		var fallbackUrl  = knownInboxUrl(state.triggerBtn);
		window.setTimeout(function () {
			if (isRendered(revealedNode)) return;      // in-place worked, nothing to do
			if (!fallbackUrl) return;                  // nowhere to go; the console warning already fired
			window.location.href = fallbackUrl;
		}, 120);
	});

	/*
	 * Re-adopt a support thread the popup restored after a page load (1.31.0).
	 *
	 * The popup now survives navigation, so on the next page it may already be
	 * open on a support conversation that this file knows nothing about. Without
	 * this, closing it would look like an unrelated chat and the in-page inbox
	 * would never appear.
	 *
	 * The stored id must match the one the popup actually restored, so a stale
	 * record cannot make us hijack somebody else's conversation.
	 */
	document.addEventListener("zymarg-comm:popup-opened", function (e) {
		var detail = e.detail || {};
		if (!detail.restored || state.ownsPopup) return;

		var cid = parseInt(detail.conversationId, 10) || 0;
		if (cid < 1 || ownRead() !== cid) return;

		state.conversationId = cid;
		state.ownsPopup      = true;
		state.inlineNode     = state.inlineNode || inlineSurfaceFromDocument();

		// Restored after a page load, so re-stamp the markers the ticket panel
		// needs — attributes do not survive navigation, only our stored id does.
		markPopupAsSupport(cid);

		// The inbox is server-rendered hidden under popup_first, but on any other
		// mode it arrives visible — and the popup is holding this thread, so the
		// two would be on screen together.
		if (state.inlineNode) hideInline(state.inlineNode);
	});

	// The popup's expand control asks before navigating. Claiming the event with
	// preventDefault() keeps the customer on the page; live-chat.js then closes
	// the popup with reason "expand" and the handler above reveals the inbox.
	document.addEventListener("zymarg-comm:popup-expand", function (e) {
		if (state.inlineNode || inlineSurfaceFromDocument()) e.preventDefault();
	});

	// "Open in popup" — delegated, because inbox.js re-renders its header.
	document.addEventListener("click", function (e) {
		var target = e.target;
		if (!target || typeof target.closest !== "function") return;

		var btn = target.closest("[data-zymarg-support-popup-open]");
		if (!btn) return;

		e.preventDefault();

		var popup = popupApi();
		if (!popup) return; // Popup unavailable — leave the inbox exactly as it is.

		var id = knownConversationId();
		if (!id) return; // Nothing resolved yet; opening an empty popup helps nobody.

		openPopup(popup, state.inlineNode || inlineSurfaceFromDocument(), id, state.triggerBtn);
	});
})();
