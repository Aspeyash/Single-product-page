=== ZYMARG Communication ===
Contributors:      zymarg
Tags:              messaging, communication, marketplace, chat, inbox
Requires at least: 6.0
Tested up to:      6.7
Requires PHP:      8.1
Stable tag:        1.33.0
License:           Proprietary

The unified messaging and communication layer for the ZYMARG marketplace ecosystem.

== Description ==

ZYMARG Communication is the central messaging plugin for the ZYMARG platform.
It owns all conversation surfaces: the store-page chat popup, the vendor dashboard
inbox, and the buyer inbox â providing a consistent, extensible messaging layer
across every touchpoint in the marketplace.

== Modules ==

* Conversation  â Thread lifecycle, participant management
* Message       â Message CRUD, attachments, read receipts
* Marketplace   â Store popup, vendor inbox, buyer inbox surfaces
* Notification  â Email, push, and in-app notifications
* Realtime      â Polling and WebSocket presence
* Moderation    â Spam filtering, blocklists, moderation logs
* Analytics     â Event tracking, reporting
* Security      â Encryption, audit logs, rate limiting
* HelpCenter    â FAQ and support articles
* Settings      â Global and per-user preferences
* Developer     â Webhooks, API keys, extensibility

== Changelog ==

= 1.33.0 - A case belongs to one agent, and can never be stranded =

Two agents could open the same case and both answer it, leaving the customer
with two replies that often contradicted each other. This release makes a case
belong to exactly one agent at a time.

The lock is deliberately a SOFT lock. It prevents two agents colliding, but it
can never prevent a case being answered.

**It fixes a live bug first.** `staleAwaitingAgent()` filters
`last_agent_reply_at IS NULL`, so the hourly escalation sweep only ever rescued
cases NOBODY had answered. The moment an agent replied once, that column was
stamped and the case became permanently invisible to the only automatic
reassignment the plugin has. An agent who replied and then quit, fell ill, or
lost their account stranded that customer forever, and nobody was told.
Auto-close could not save it either: that fires only on `awaiting_user`, while
an abandoned case sits in `awaiting_agent`. This was broken since 1.27.0 and is
independent of the lock.

* Fixed: **Abandoned cases are now rescued.** New sibling sweep
  `staleAwaitingAgentClaimed()` finds cases that WERE answered and then went
  quiet, and rotates them to another agent. Anchored on `last_user_reply_at`,
  not `updated_at`, so an agent's own writes cannot postpone the rescue of the
  case they are neglecting - the same trap the 1.32.15 waiting clock avoided.
* Fixed: An abandoned case now rotates AWAY from its current owner. That owner
  is precisely the person who stopped responding, so handing it back to them
  would re-strand the customer for another full window.
* Added: **Case ownership lock.** A second agent replying to a case a colleague
  owns is told who has it, instead of silently double-answering the customer.
* Added: `takeOver()` - hand a case to a new owner for the human cases: on
  leave, off sick, simply forgot. Fires `zymarg_comm_support_case_taken_over`
  so an audit trail can be attached.
* Added: Filter `zymarg_comm_support_case_lock_enabled` to switch enforcement
  off site-wide while leaving every ownership read model working.

**Five safety valves, because this is the only code that can refuse a reply:**

1. The lock IS `zc_support_tickets.agent_id`. There is deliberately no
   `locked_by` column - a parallel lock field is the thing that strands cases.
   Anything that reassigns the owner releases the lock automatically.
2. Fail-open. It blocks only when it can positively confirm a different,
   still-valid owner. Missing row, un-migrated table, container failure, any
   exception at all -> the reply goes through. Enforced structurally:
   `denialReason()` returns a string and the caller throws only on a non-empty
   one.
3. Liveness at read time. The owner must still exist AND still hold
   `zymarg_support_agent`. A deleted account or a revoked capability releases
   the case instantly - no cron, no admin action, no waiting.
4. Administrators are never blocked. As long as one site admin exists, no case
   is ever unreachable. Consistent with `assertMemberOrAdmin()`.
5. Take-over, for when the account is fine and the person simply is not.

**No schema change.** The lock reads a column that has been populated since
1.27.0. Marketplace buyer/vendor threads are untouched: non-support
conversations short-circuit before any database work.

= 1.32.15 - The support team gets a face, and a clock =

The support surface had no concept of a public identity. Headers said the fixed
brand label "Support team", the typing indicator was three anonymous dots, and
the notification payload shipped the agent's raw WordPress `display_name` — so a
customer whose chat window said "Support team" could still be emailed "New
message from admin" about that very same case. Meanwhile agents could not see how
long anyone had been waiting, nor tell a colleague's reply apart from the
customer's own messages.

* Added: **Public name** per support agent, on Communication -> Support. This is
  what CUSTOMERS see; real names and emails stay visible only to the owner.
  Resolves in three tiers so a real username can never leak: the agent's own
  public name, then the site-wide default (ships as "Alpha"), then "Support
  team". Stored as user meta, so it never touches the WordPress account —
  `display_name`, login and email are untouched and every other plugin that
  reads the user's name is unaffected. Filterable via
  `zymarg_comm_support_agent_alias`.
* Added: the typing indicator now NAMES the agent — "Alpha is typing…" — instead
  of an anonymous row of dots. The name belongs to the case OWNER
  (`zc_support_tickets.agent_id`, claimed by the first agent to reply and never
  reassigned to a later one), so one case keeps one persona for its whole life
  and the person the customer is talking to never appears to change mid-thread.
  The label rides along with the Pusher push as well as the poll, so a realtime
  indicator is named immediately instead of showing the generic literal until the
  next 3-second poll renames it.
* Fixed: notification titles no longer leak a support agent's real name. On a
  support case the customer now reads "New message from Alpha", matching the
  window in front of them. Scoped as tightly as possible — a customer's OWN
  message keeps their real name so agents still see who wrote to them, and
  agent-to-agent notifications are untouched.
* Added: **waiting time in the agent queue.** Every case awaiting a reply shows
  "waiting 47 mins", colour-coded from the escalation window this site is already
  configured with (`zymarg_comm_support_escalate_hours`, default 2h): plain under
  half of it, amber past half, red once it is overdue. Also shown beside the
  status pill in the agent ticket panel. The clock is anchored on
  `last_user_reply_at` — the moment the customer last wrote — NOT on
  `updated_at`, which every repository write bumps and which therefore made an
  agent's own actions visibly reset the apparent wait. Cases awaiting the
  customer, and resolved or closed cases, deliberately show nothing at all.
  Customers are never shown their own waiting time; their side keeps the measured
  "we usually reply in about X" estimate.
* Added: a colleague's reply is now labelled with their real name in the AGENT
  view, with a tinted left edge. The thread renderer only knew "mine" and "not
  mine", so on a case answered by two people the second agent's replies were
  drawn exactly like the customer's own messages and an owner genuinely could not
  tell them apart. Sent only to agents, and only on support cases — customers
  never receive staff names.
* Changed: the "Admin⇄User" submenu is now simply **Support**. The ⇄ glyph is
  easy to miss at sidebar size, so the item read as "Admin User" and looked like
  a user account rather than a place to answer customers. The page slug is
  unchanged, so every existing bookmark, redirect and `admin.php?page=` link
  keeps working.
* Housekeeping: the expanded plugin source in the repository had not been updated
  since 1.32.0 — releases 1.32.7 through 1.32.14 shipped as zips only. The tree
  now matches what actually runs, committed separately from this release so the
  1.32.15 changes stay reviewable on their own.

Compatibility: no database schema change, no new table and no new column. One
option row and one user-meta key, both created lazily, so an existing install
behaves exactly as before until a public name is actually set. Every new code
path fails open — if the Support module is unavailable or anything throws, the
typing indicator, the notification and the message list all fall back to their
pre-1.32.15 behaviour rather than breaking.

= 1.32.14 - Support header: name on the left, dot and control on the right =

* Fixed: on the single-row support header from 1.32.12 the conversation name, the
  green dot and the "Open in popup" control all packed together on the left with
  dead space to their right. 1.32.12 relied on the base `.zymarg-inbox__title
  {flex:1}` stretching to push the controls over, and pinned the adopted dot at
  `margin-left:0` — so the moment the title did not stretch (below 640px, or any
  host that restyles the title) there was nothing pushing anything.
* The name is now a tight block on the left and the dot plus the control are
  carried to the right edge, with the dot sitting 8px before the control. Holds
  with the dot lit or hidden, at 375px as well as full width, and in host-chrome
  card mode.
* Note for anyone reading the CSS: exactly ONE auto margin does the pushing.
  Flexbox splits free space equally between every auto margin on the line, so
  putting it on both the dot and the control does not make the first one win — it
  parked the dot in the middle of the row instead (measured 425px adrift before
  this was corrected). The dot carries it while it is in flow; when the agent is
  offline the dot is `[hidden]` and therefore cannot push, so the control picks
  the job up through a `:has()` escape.

= 1.32.13 - The popup chat header is one row too: green dot, no "Active now" text =

* Changed: the floating chat popup (the one on store and product pages) printed
  "Active now" — and "Last seen X ago" when offline — in its header, and
  `.zymarg-live-chat__presence` carried `flex-basis:100%` so that label claimed a
  full row of its own beneath the title. Two rows of chrome above a conversation
  that often has not started yet. The green dot alone says the same thing in 8px,
  so the label is gone and the dot sits inline with the title on one row.
* 1.32.1 had already done exactly this for SUPPORT popups and deliberately left
  buyer<->vendor threads with the full label. That distinction is what this
  release drops: the popup is now dot-only in every context.
* The label is untouched where it earns its space: the vendor's Messages inbox
  (inbox.js) still shows "Active now" / "Last seen X ago" for buyer<->vendor
  threads, so a shopkeeper working their inbox keeps that detail. This is only
  the popup.
* No accessibility cost: the meaning stays on the element's `title` and
  `aria-label`, so it is still available on hover and to screen readers.

**Two things cleaned up on the way**

* The presence logic existed TWICE — once in the 30-second poll and once in the
  realtime `presence.update` handler — with the same branches copied into both.
  They are now one shared `applyPresence()`.
* Fixed as a side effect: an `online:false` realtime push previously did nothing
  at all, leaving a stale green dot lit until the next poll caught up 30 seconds
  later. It now goes out immediately.

= 1.32.12 - One header row on the support surface instead of two =

**Two rows said the same thing twice**

* Changed: the customer support surface stacked two full-width header rows — this
  inbox's own header (its title plus the "Open in popup" control) and, directly
  beneath it, the thread pane's header carrying the conversation title. On a
  helpline that second row is pure duplication: there is exactly one case, so a
  section title and a conversation title name the same thing, and the pair cost
  roughly 50px out of the message log.
* The conversation name is the one worth keeping, so it now sits on the single
  surviving row next to the controls, the host's own `title` attribute is ignored
  on this surface (it was the duplicate — "Contact Support" above "Support team"),
  and the thread pane's header row is collapsed.
* Collapsed in CSS rather than removed in PHP on purpose: inbox.js rebuilds that
  header on every thread render, so anything deleted from the DOM would simply
  return on the next paint.

**The green "active now" dot moves up with it**

* Fixed: the presence dot is built INSIDE the row being collapsed
  (`.zymarg-inbox__presence`, created by inbox.js in renderThread), so hiding
  that row would have taken away the only signal that an agent is on the other
  end. support.js now adopts the dot into the surviving row, directly after the
  conversation name, and overrides the `margin-left:auto` that used to fling it
  to the far end of a row holding nothing else.
* Re-parenting is safe because inbox.js holds that element by reference and
  mutates the same node when the presence poll returns, so its live updates keep
  working from its new home with no change needed there. Re-applied through a
  MutationObserver, since inbox.js clears the thread pane and builds a brand new
  dot on every render — and the previously adopted one is explicitly discarded,
  otherwise each render stacked another dot on the row.
* The dot stays hidden until an agent is genuinely online, and stays dot-only on
  the support surface, exactly as before.

**Unchanged**

* The agent console and admin support screen call inboxRoot() with no options,
  so they keep both rows, keep their own title and keep the full "Active now" /
  "Last seen" presence text. Buyer and vendor inboxes are untouched.

= 1.32.11 - The seller support inbox matches too, and stops fighting the vendor dashboard =

**A rule of ours was matching a hidden inbox, and the vendor dashboard had to work around it**

* Fixed: `.zymarg-vendor-main:has(.zymarg-inbox:not(.is-host-chrome)){padding:0}`
  (shipped in 1.24.14 for the Messages section) matched ANY inbox anywhere in
  the vendor column, and `:has()` matches on DOM PRESENCE rather than on whether
  a node renders. The vendor dashboard's Support section ships an inline support
  inbox that starts `hidden`, so that rule stripped the entire Support section's
  clamp(16px,3vw,28px) frame on first paint — greeting and tiles flush against
  the sidebar and overflowing the right edge, with nothing clicked. It is now
  scoped to the Messages variant (`.zymarg-inbox--vendor`), which is always the
  section itself, and the support surface is governed by the `.is-support-live`
  rules added in 1.32.10, which track whether the inbox is actually on screen.
* Consequence worth spelling out: the vendor dashboard worked around the above
  by regex-injecting `.is-host-chrome` into our markup after calling the
  shortcode. Because every edge-to-edge rule here is keyed
  `:not(.is-host-chrome)`, that made all of them stand down on the seller side —
  so the seller support inbox kept a rounded card, a 28px frame and a 1180px
  width cap while the seller Messages inbox ran flush and full width, and the
  buyer and seller support surfaces did not match each other either. It also
  overrode the site's own "Match host page heading style" setting, which
  SupportChat has read for itself since 1.32.9. With the cause fixed here, the
  vendor dashboard drops that workaround in its 1.46.13 and the setting is
  authoritative on both surfaces.
* Added the missing seller half of the 1.32.10 work: the support surface now
  zeroes `.zymarg-vendor-main`'s frame itself (gated on `.is-support-live`)
  rather than relying on the Messages rule to do it by accident.

**Host cards are left alone until the inbox is actually on screen**

* Changed: the rules that neutralise the host's own wrapper card
  (`#zymarg-os-support-inbox`, `#zymarg-vd-support-inbox`) are now also gated on
  `.is-support-live`. Both hosts draw that wrapper as one of their own cards —
  the theme's rounded panel, the vendor dashboard's `.zymarg-vendor-card` — and
  while the inbox is not on screen that card is theirs to style, not ours to
  flatten.

= 1.32.10 - The support inbox finally sits flush, on both the buyer and the seller side =

**1.32.9 fixed the wrapper's card but left the host column's gutter**

* Fixed: the support inbox still did not match the Messages inbox. 1.32.9
  flattened the page wrapper's own rounded card, which was real but was only
  half the cause: what actually makes the Messages inbox sit flush is the HOST
  COLUMN dropping its gutter and its width cap, and neither host does that for
  the Support section.
* Buyer side: the theme zeroes the column for Messages only, keyed off a body
  class (`body.zymarg-acc-section-messages ... .main-content{padding:0}`,
  theme 5.12.17). The Support section's body class is
  `zymarg-acc-section-support`, so that rule never fired and the column kept
  its 16px/24px padding — the gap down both sides. The theme's matching
  "square the sidebar's right corners" rule (5.12.20) was skipped for the same
  reason, which would have left a notch at each end of the seam.
* The plugin now restates both for the support surface only. The Messages rules
  are untouched; this is purely additive, and no theme file is modified.

**Buyer support and seller support no longer disagree with each other**

* Fixed: the two support surfaces were broken in DIFFERENT ways, so they did
  not match each other either. On the seller side the column-padding rule uses
  a descendant `:has()` and already reached the inbox through the wrapper, but
  the width rule (`.zymarg-vendor-content:has(> .zymarg-inbox ...)`) requires a
  DIRECT child, which the wrapper breaks. So seller support lost its gutter but
  kept its 1180px cap — no side gap, yet visibly narrower than seller Messages
  and nothing like buyer support. That rule is now ID-anchored so it holds at
  any nesting depth.

**The column's gutter now tracks the inbox instead of guessing**

* support.js marks the inbox root `.is-support-live` only while it is genuinely
  on screen, and clears it when the popup takes the thread back. Under
  popup-first the inbox exists in the DOM from page load but hidden, so keying
  the layout off its mere presence would have stripped the column's padding and
  left the Support landing cards flush against the sidebar for no reason. An
  inbox the server renders visible (`auto` / `inline` delivery) is detected on
  boot and re-checked on the hosts' AJAX section swaps.

**Corrections**

* The 1.32.9 code comment claimed the full-bleed squaring rule "never had a
  chance to apply" to the support inbox. That was wrong — it is a descendant
  selector and was already applying, which is why the inbox itself measured 0px
  radius all along. Comment corrected in place.
* Host-chrome ON now gives the support inbox the same per-host frame token the
  buyer and vendor inboxes get (16px/24px on the buyer column,
  clamp(16px,3vw,28px) on the seller column) instead of falling back to a
  generic 24px on both.

= 1.32.9 - Support inbox matches the theme and vendor dashboard, one card not two =

**The reported "gap around the message box" was a second, hidden card**

* Fixed: on the customer Support section, the inline support inbox
  (`[zymarg_support_chat mode="inline"]`) showed a visible gap and rounded
  corners around it, unlike the buyer My Account inbox and the vendor
  dashboard inbox, which sit flush with no gap. Cause: `.zymarg-inbox` was
  already squaring its own corners correctly, but the PAGE'S OWN wrapper
  around the shortcode (`#zymarg-os-support-inbox` on My Account,
  `#zymarg-vd-support-inbox` on the vendor dashboard) carries its own
  independent card styling — a border-radius and a box-shadow that this
  plugin never touched. A correctly-squared inbox sitting inside a
  still-rounded, still-shadowed wrapper is two nested cards, and the
  wrapper's curve and shadow were what read as a gap.
* The wrapper's own margin, padding, border, radius, shadow and background are
  now neutralised whenever it is hosting a non-host-chrome support inbox, so
  the inbox is the only visual surface — matching the buyer and vendor inboxes
  exactly, with no theme or Vendor Dashboard file touched.

**"Match host page heading style" now does something coherent on Support too**

* Fixed: the `surface.host_native_chrome` setting already gives the buyer and
  vendor inboxes two consistent looks (edge-to-edge, or one card inside the
  host's own heading). `SupportChat.php` never read this flag at all, so
  toggling it changed nothing on the Support inbox — what looked like a worse
  gap on "ON" was the same untouched wrapper, just more obviously mismatched.
* The Support inbox now honours the same flag, resolved against the page's own
  wrapper since Support has no dashboard heading to borrow: OFF keeps the fix
  above (edge-to-edge, wrapper neutralised); ON leaves the wrapper's own card
  untouched and flattens the INBOX's own border/radius/shadow instead, so
  toggling either state produces exactly one card, never two. The support
  inbox keeps its own "Support" title in both states — there is no host
  heading to replace it with.
* The two agent-facing surfaces (Admin Support screen, Agent Console drawer)
  never pass this option and are unaffected either way.

= 1.32.8 - Closing the popup reveals the inbox in place, instead of redirecting =

**The blocker was never the theme's CSS — it was this plugin's own hidden attribute**

* Fixed: under popup-first delivery, closing the popup redirected to My Account
  -> Messages instead of revealing the in-page inbox. Hosts point
  `data-inline-target` at their own container (#zymarg-os-support-inbox,
  #zymarg-vd-support-inbox), but renderInline() puts `hidden style="display:none"`
  on the inbox root INSIDE that container. reveal() only ever walked UPWARDS from
  the node it was given, so the container was prised open while the inbox inside
  it stayed hidden — leaving a container measuring 0 tall. 1.32.7 then read that
  empty container as a failed hand-off and navigated away, which is why the URL
  changed to /my-account/messages/ on close.
* reveal() now starts at the inbox root inside the container and walks up from
  there, so the inbox is un-hidden along with every ancestor above it. When the
  node it is handed already IS the inbox root, behaviour is unchanged.
* The 1.32.7 verification measures the inbox itself rather than the container it
  sits in, so a container whose child is still hidden can no longer be mistaken
  for a healthy reveal — and a healthy reveal can no longer be mistaken for a
  collapsed one.
* This also explains why `auto` delivery always worked: on that mode the inbox is
  rendered visible, so the only thing needing a reveal was the host container —
  the half that was never broken. `auto`, `popup`, `inline` and `page` behave
  exactly as before.

**Closing the popup on a page with no inbox no longer loses the case**

* Fixed: on a page carrying only the trigger (a footer help link, or the button
  shortcode on its own) closing the popup returned silently and the case
  disappeared. That early return sat BEFORE the 1.32.7 navigation fallback, so
  the one path with nothing to reveal was the one path that could not fall back.
  It now opens the full inbox, or restores the Contact Support button when no
  inbox URL is known, rather than leaving a dead page.

= 1.32.7 - Closing the popup always gets you to the full inbox =

**Guaranteed hand-off instead of a CSS arms race**

* Fixed: closing the popup under popup-first delivery could still leave the
  customer with nothing. The in-page inbox is revealed inside whatever container
  the theme placed it in, and when that container is collapsed by CSS the inbox
  ends up present but unrendered -- 0x0, no offsetParent -- so the case appears
  to have evaporated. 1.32.4 and 1.32.6 taught reveal() to prise open five
  different collapse mechanisms, but that is a game that cannot be won against
  every theme and page builder in existence.
* The hand-off is now verified rather than assumed: the inbox is revealed in
  place, measured a tick later, and if it genuinely is not on screen the browser
  navigates to the full inbox instead. Navigation is not the nicest outcome, but
  it beats the customer staring at a page where their conversation has vanished.

**The plugin's own pages now heal themselves**

* Fixed: the Messages and Vendor Messages pages carry the inbox shortcodes, and
  the support popup hands off to the first of them. Until 1.32.5, deleting the
  plugin permanently deleted both pages, and they were only ever created on
  activation -- so a site that lost them had a support flow pointing at a page
  that no longer existed, with nothing anywhere reporting it. Missing pages are
  now detected and recreated in wp-admin, with a dismissible notice saying which
  ones. An existing page on the same slug is adopted rather than duplicated.
* The full inbox URL is also published to the frontend now, so the fallback
  above works even on a page load where the support API was never called (a
  restored popup, for instance).

= 1.32.6 - Helpline cases stay out of the buyer/seller message box =

**Support threads were leaking into the regular inbox**

* Fixed: messaging the helpline made that case appear in the ordinary
  buyer/seller message box as well, mixed in with vendor conversations. The
  support inbox has asked for `context=support` since 1.25.0 so it lists only
  support threads, but nothing ever did the reverse: the buyer and vendor
  inboxes sent no context filter at all and therefore received EVERY
  conversation the user took part in, support cases included. The two are
  separate products for separate jobs and must not share a list.
* The buyer and vendor inboxes now send `exclude_context=support`, backed by a
  new exclusion branch in the conversation query. The agent-facing surfaces and
  any other API consumer are unaffected -- an explicit `context` still wins, and
  calling the endpoint with neither parameter behaves exactly as before.
* The exclusion is written as `context_type IS NULL OR context_type <> 'support'`
  on purpose. Ordinary buyer/vendor chats carry no context at all, and a plain
  `<>` comparison discards NULLs in SQL, which would have emptied the buyer
  inbox completely rather than merely filtering it.

**Closing the popup: more ways to un-collapse the in-page inbox**

* Fixed: 1.32.4 taught reveal() to force `display` on an ancestor that a
  stylesheet had collapsed, which covers `display:none`. It did not cover the
  other ways a theme can collapse a wrapper: `visibility:hidden`,
  `max-height:0`, the `height:0` plus `overflow:hidden` pairing that accordions
  and tab panels use, or `opacity:0`. With any of those in play the inbox was
  still un-hidden yet unrendered -- 0x0, null offsetParent -- so closing the
  popup continued to look like nothing had happened. All five mechanisms are now
  neutralised, and only when the inbox is genuinely not rendered, so an ordinary
  page is never touched. Everything forced is still undone when the inbox is
  collapsed again, so one surface on screen at a time still holds.
* Added: if the inbox STILL cannot be shown, the plugin now logs a console
  warning naming the element that is collapsing it and the properties involved.
  This condition is by definition invisible in the UI, and it should not take a
  debugging session to identify.

= 1.32.5 - Deleting the plugin no longer destroys your data =

**Uninstall is non-destructive by default**

* Fixed: deleting the plugin wiped everything, unconditionally and without
  warning. The uninstaller dropped all eleven plugin tables -- conversations,
  participants, messages, attachments, reactions, notifications, moderation
  logs, analytics events, audit logs, support tickets and the feature flags --
  then deleted every `zymarg_comm_*` option, destroyed the registered pages and
  recursively removed the uploads directory. Since this plugin is distributed as
  a zip rather than through the WordPress.org updater, deleting it in order to
  install a newer build was a normal thing to do, and it silently threw away
  every support conversation and its whole ticket history. It also reset
  `surface.support_chat`, which ships disabled, so support came back OFF and the
  front end answered "Could not open support. Please try again." until somebody
  worked out why.
* Uninstall now keeps all data unless you explicitly opt in, by setting the
  `zymarg_comm_delete_data_on_uninstall` option or returning true from the
  filter of the same name. Transient and cache cleanup still always runs,
  including stale rate-limit counters so a reinstalled plugin cannot inherit an
  immediate 429.
* This restores the documented expectation that uninstalling never deletes
  customer data.

**Rate limiter now correct on hosts with a persistent object cache**

* Fixed: the 1.32.4 window fix depended on reading the
  `_transient_timeout_{key}` option to preserve a counter's expiry. That option
  only exists when transients live in the options table. With Redis or
  Memcached in front of them -- as on Pantheon -- the lookup found nothing and
  the code fell back to restarting the full window on every increment, which is
  the sliding behaviour 1.32.4 set out to remove, on exactly the hosts most
  likely to be polling hardest. The window end is now stored inside the cached
  value, so correctness no longer depends on where transients are kept. A
  counter written by an older version is detected and rolled over cleanly.
* `retry_after` on a 429 now reports the real seconds remaining rather than the
  full window, so clients can back off accurately.

= 1.32.4 - Popup-first finally delivers the full inbox, and the 429 storm is gone =

**"Popup first" now actually reveals the in-page inbox**

* Fixed: under popup-first delivery, closing the popup left the customer with
  nothing. The inbox was being un-hidden correctly -- the `hidden` attribute and
  the inline `display:none` were both cleared, and the close event fired with
  the right reason and conversation id -- but when the host wraps the inbox in a
  container that a STYLESHEET collapses (a class such as `.is-hidden`), neither
  of those two steps can touch it. The inbox ended up un-hidden yet never laid
  out: 0x0, null offsetParent, invisible. So the customer only ever saw the
  popup and the full inbox they were promised never arrived. reveal() now also
  forces `display` (as an important inline style, the only thing that reliably
  beats a stylesheet rule) on any ancestor it finds collapsed, and records each
  one so collapsing the inbox again puts them all back -- one surface on screen
  at a time still holds.

**No more "Active now" on the in-page support inbox**

* Fixed: 1.32.1 removed that label from the popup but missed the in-page inbox,
  which has its own separate presence code. The support thread header showed
  "Support team" followed by "Active now". The in-page inbox now shows the green
  dot only, matching the popup. Buyer and vendor inboxes keep the full
  "Active now" / "Last seen ..." text, so only support is affected. The label
  remains available to screen readers via title/aria-label.

**Realtime polling no longer rate-limits itself**

* Fixed: repeated `GET /realtime/poll 429 (Too Many Requests)` during entirely
  normal use. The rate limiter rewrote the counter's expiry on every accepted
  request, so while a client polled steadily the window could never roll and the
  tally only climbed. Polling runs every 4 seconds (15/min) against a 120/min
  cap, so after about eight minutes the cap was reached and the endpoint
  returned 429 for a full window before resetting -- a sawtooth lockout caused
  by ordinary traffic rather than abuse, which also stalled message delivery.
  The expiry is now written only when the counter is created, so the window
  means what it says: a steady 15/min never trips a 120/min cap, while a real
  flood is still stopped.

= 1.32.3 - The popup header says "Support team" even when the popup restored itself =

* Fixed: a popup that restored itself after a page load (the session
  persistence added in 1.31.0) still showed **"Chat"** in its header. The
  header label is chosen from the `data-context="support"` marker, but on that
  path the popup renders its own header from the conversation payload *before*
  support.js has worked out that the thread is a support case and stamped the
  marker — attributes do not survive navigation, only the stored conversation
  id does. The label is now applied at the moment the marker is stamped as
  well, so whichever of the two runs last, the header ends up correct.

= 1.32.2 - Fixes two regressions introduced by 1.32.1 =

1.32.1 removed the status pill from the customer view and started sweeping
duplicate "Contact Support" buttons. Both changes had consequences that were
not caught before release. Neither is present in 1.32.0, so this affects
1.32.1 only.

* Fixed: **an empty mauve strip appeared above the customer's messages.**
  Removing the status pill left the customer ticket panel with no content at
  all in the most common state — case open, agent has not replied yet, so
  there is no countdown, no rating card and no closure notice. The panel node
  still carried its padding, surface background and bottom border, so the
  customer saw a blank bar with a rule under it wedged above the conversation.
  The panel now collapses itself (`hidden`) whenever it has nothing to say,
  which the stylesheet already handles via `.zymarg-ticket[hidden]`.
* Fixed: **"Start a new case" hid itself one tick after appearing.** When a
  case closes on the timer, the panel renders a "Start a new case" button —
  and that button is itself a support trigger. The panel re-announces the
  section after rendering it, support.js boots on that announcement, and the
  1.32.1 sweep then hid every support trigger on the page including the one
  just rendered. A customer whose case timed out was left with no way to open
  a new one. The sweep now skips any trigger inside a ticket panel, because
  those are the way forward rather than a duplicate call to action.
* Fixed: **the CTA was suppressed for customers with no open case.** The
  1.32.1 page-load check decided "this customer is already in a case" from the
  presence of any row in the support conversation list — but a closed case
  still appears in that list. Customers whose case had ended could not see
  Contact Support at all. That client-side guess has been removed entirely.
  The page-reload case it was meant to cover is handled correctly on the
  server by `SupportService::hasOpenTicketForUser()`, which is true only for
  genuinely open tickets.

= 1.32.1 - Customer-facing support panel is quieter, and the "Contact Support" duplicate is gone =

**What the customer sees is cleaner**

* Changed: the popup header now reads **"Support team"** on support threads,
  never a raw agent name and never the customer's own name. Buyer↔vendor chats
  keep showing the store name, so shopping conversations are unaffected.
* Changed: the presence indicator on the support popup is **a small green dot
  next to the title**, only when the agent is online. The "Active now" label
  and the "Last seen X ago" line are both gone from the support surface — they
  were taking a whole row for information the dot conveys on its own. Buyer↔
  vendor popups keep the full text so the shopkeeper can still tell when a
  customer was last around.
* Changed: the customer view no longer shows the **status pill** ("Waiting on
  us" / "Waiting on you" / "Resolved" / "Closed"). The pill was noise on the
  customer's side of the glass — the countdown, paused, closed and rating rows
  below already tell them anything they need to act on. Agents still see the
  pill because they need it to triage a queue.
* Changed: the live countdown line no longer starts with "Waiting on you —".
  It now reads simply **"This case closes in 2:41 if you do not reply."** —
  the timer itself already implies who is being waited on.
* Changed: the customer's inbox list row for a support case now reads
  **"Support team"** instead of the customer's own display name. On some
  installs the participant lookup returned the customer's own name for their
  own view of the support thread; the override kills that at the source but
  is scoped so agents still see the customer's name in their queue.

**The duplicate "Contact Support" button is gone**

* Fixed: after a customer clicked **"Contact Support"** on a page that carried
  a second trigger elsewhere (a sidebar link, a footer callout, another
  shortcode), the second trigger stayed on screen next to the just-opened
  conversation. The customer saw the same call to action twice — once above
  the live conversation, once still offering to open it. hideTriggerChrome()
  used to only touch the CLICKED trigger. It now sweeps **every** support
  trigger on the page in one pass, and every one comes back if the case is
  dismissed with Escape.
* Fixed: reloading the page mid-case brought the button right back, because
  the server didn't know a case was already in flight and re-rendered it. The
  server-side renderer now consults `SupportService::hasOpenTicketForUser()`
  and renders the trigger `hidden` when the customer already has an open
  ticket. The click handler is still attached, so the button reappears the
  moment the case closes / is resolved without a page reload.
* Added: on boot, support.js also proactively hides every trigger when it
  spots an inline support inbox on the page — belt-and-braces for themes
  where the server hint didn't run.

**Admin support inbox is tighter, search matches the buttons**

* Changed: the header row of the admin support inbox ("Support" title, filter
  tabs, search) now sits on **one tight line** on desktop. Padding dropped from
  18/22 px to 12/16 px, the heading font from 1.25 rem to 1.05 rem, filter
  pills from 7/15 to 6/12 px. Everything is still readable, and the density
  matches what an agent triaging a live queue actually wants.
* Changed: the search input is now **pill-shaped** to match the round filter
  buttons sitting next to it — no more square/rounded mismatch. Height dropped
  to 36 px so it doesn't dominate the tighter header.
* Both changes are scoped to `data-context="support"`, so the buyer and
  vendor inboxes keep their roomier layout.

= 1.32.0 - Fixed: what you type into Smart Intake is now actually in the chat, and the reply time is real =

**Your answers become the first message**

* Fixed: **choosing a topic and typing a subject opened a completely blank chat
  window.** The answers were saved onto the ticket record and never turned into a
  message, so from the customer's side the form appeared to throw their words
  away. What they type is now posted as the thread's opening message, from them,
  so the conversation opens with their own words in it.
  * It goes through the normal message path, which means the assigned agent is
    notified and the case correctly reads **"Waiting on us"** instead of sitting
    in a state implying the customer still owes a reply.
  * A selected order is added as a line ("Regarding order #1234"), using the
    customer-facing order number rather than the internal post ID.
  * Picked a topic but typed nothing? The topic's own label is used — never the
    raw slug.
  * Typed nothing and picked nothing? No message is posted; an empty thread is
    honest at that point.
  * Best-effort by design: if the message cannot be stored for any reason the
    thread still opens. Being unable to reach support at all would be far worse
    than a missing opening line.
* Fixed: **the popup showed none of the Smart Intake context.** The ticket panel
  only ever mounted on the in-page inbox, so the popup had no topic, no order and
  no status — the intake answers were invisible there even once stored. The popup
  now carries the same panel, inserted directly above the message pane.

**The reply-time line is measured, not invented**

* Changed: "We usually reply within a few hours." was **hard-coded**, which meant
  it might simply be untrue. It is now the **median time your team actually took
  to first reply** over the last 30 days, computed from data the plugin was
  already recording.
* Added: nothing is shown until there are at least **3 answered cases** to
  measure. A brand-new site has no evidence, and a promise you cannot keep is
  worse than no promise at all.
* Added: a **"Show reply-time line"** checkbox. Blank previously meant "work it
  out yourself", so there was no way to say "show nothing" — now there is.
* The manual override still wins, for stating real opening hours the plugin
  cannot know. Median is used rather than mean so one badly delayed case cannot
  distort the figure. Cached for an hour, because decorative copy on a modal must
  not put an aggregate query on a hot path.

**The agent panel stopped following the conversation you clicked**

* Fixed: **selecting a case showed the right customer for a second, then switched
  to the wrong one.** Two separate defects, both in the panel loader:
  * There was no guard against stale responses. Agents click down a queue faster
    than requests return, so the slowest reply won and painted over the newest
    selection. Responses are now matched to the request that is still current and
    late ones are discarded.
  * The dedupe key included the conversation id, so it could never express "this
    panel is currently showing X". Re-opening a case you had already viewed
    matched its own stale entry and returned early, leaving the previous
    customer's details on screen. It is now keyed on the panel itself, so
    switching back reloads properly.
  * As a side effect, two panels for the same user (the inbox and the popup) no
    longer collide over one cache slot.

**For developers**

* Added: filter `zymarg_comm_support_eta_label` ( string $label, ?int $seconds ).
* Added: `SupportTicketRepository::medianFirstResponseSeconds( $days, $min_samples )`.
* Added: `SupportIntakeSettings::showAvailability()` / `setShowAvailability()` and
  the `support_intake_show_availability` option.
* Changed: `SupportService` takes an optional fourth constructor argument,
  `?MessageService`, used to post the opening message. Optional, so its absence
  degrades to the previous behaviour rather than fataling.
* Changed: `support.js` stamps `data-context="support"` and
  `data-active-conversation` onto the popup root while it holds a support case,
  and clears both when it does not — the same contract the inbox already used, so
  the ticket panel needed no new plumbing.

= 1.31.0 - Added: the chat popup survives navigation, and quiet support cases close themselves =

**The popup stays where you left it**

* Fixed: **the chat popup vanished the moment you opened another page.** Only the
  *minimized* state had ever been persisted; an open panel was not, and the panel
  is rendered hidden on every page load — so navigating left the customer with no
  panel *and* no puck. The chat disappeared without a trace, which is worse than
  closing it, since minimizing at least leaves the puck behind. The popup now
  stays open across page loads until it is closed on purpose.
* Added: the conversation is remembered with it. Restoring "open" without the
  conversation id would have reopened an **empty** popup — a bug this plugin has
  had before — so a session with no id deliberately comes back as the puck
  instead. An empty panel is never shown.
* Added: **your half-typed message survives too.** Keeping the window but losing
  the sentence would have been a worse bug than the one being fixed. Drafts are
  kept per conversation and cleared once the message actually sends, so a failed
  send still leaves the text recoverable.
* Added: restoring does not steal focus, so arriving on a page no longer scrolls
  you around or pops the keyboard open on a phone.
* Added: a 12-hour lifetime, filterable via `zymarg_comm_popup_session_ttl`. Only
  genuine abandonment expires — browsing keeps the session fresh — so a popup left
  open on Monday does not reappear on Thursday.
* Fixed: after navigating, closing a restored support popup now still reveals the
  in-page inbox. Ownership of the popup is remembered, and only trusted when the
  stored conversation matches the one the popup actually restored.

**Helpline sessions: quiet cases close themselves**

Support is a helpline, not a mailbox. A customer has one live case at a time, so
a case left half-finished blocks them from ever getting a clean start. When your
team has replied and the customer goes quiet, the case now closes itself.

* Added: **Settings → Support → Helpline session**, with the wait as an editable
  field. Three minutes is only the shipped default — set anything from 1 minute
  to 1440 (a full day). It is a setting, never a hard-coded constant.
* Added: a **live countdown** for the customer ("this case closes in 2:41"), one
  notification at a configurable warning point, and an urgent colour change at the
  threshold. The deadline is sent once per ticket read and counted down in the
  browser, so the timer costs **no extra requests** — a per-second poll would have
  been the obvious implementation and the wrong one.
* Added: **typing buys you time.** If the customer is part-way through a message
  when the countdown runs low, a single keep-alive grants a fresh window. Nobody
  mid-sentence gets cut off.
* Added: agents get **Pause timer**, **Resume timer** and **Give more time** on the
  case, plus the countdown in their own panel so they can see a case about to lapse
  *before* it does. Deliberately styled quieter than Resolve and Close.
* Added: choose what a lapsed case becomes — **Closed** (their next message starts
  a brand-new case, the true helpline behaviour) or **Resolved** (their next message
  reopens the same case with its context intact).
* Added: the customer is told plainly when a case closed on a timer, and offered
  **Start a new case** rather than a dead end.
* Added: `closed_reason` records that a timer did this and not a person, so a lapse
  is never counted as a resolution in your metrics.
* Important: this **never** applies while a case is waiting on YOUR team. Closing
  those would blame the customer for your own backlog. The asymmetry is the design.
* Nothing is ever deleted. Closing is a status change; the whole conversation is
  kept.

**Why it is not driven by cron**

WP-Cron's shortest schedule here is hourly, and it only fires when somebody visits
the site — so a 3-minute deadline could be honoured 57 minutes late, or never on a
quiet site. The deadline is therefore derived arithmetically and settled the moment
anybody reads the case, which makes correctness independent of cron entirely. The
hourly sweep is only a janitor for cases nobody opened.

**For developers**

* Added: `zymarg_comm_support_session_timeout`, `_session_paused`, `_session_resumed`
  and `_session_extended` actions.
* Added: `POST /support/ticket/{id}/{pause|resume|extend}` (agent) and
  `POST /support/ticket/{id}/heartbeat` (the case owner only).
* Added: `autoclose` on the ticket status descriptor — `active`, `paused`,
  `expires_at`, `seconds_remaining`, `warn_seconds`, `minutes`, `closed_reason`.
* Added: filters `zymarg_comm_support_session_minutes` and
  `zymarg_comm_popup_session_ttl`.
* Added: migration `AddSessionColumnsToSupportTickets` — `closed_reason`,
  `autoclose_paused`, `autoclose_until`, plus an `autoclose_idx` index, since the
  existing `queue_idx` covers `updated_at` and the sweep filters on
  `last_agent_reply_at`.
* Note: the closure is announced by a **hook, not a thread message**. `zc_messages`
  has no system-message kind, and the message-sent listener would have read an
  inserted notice as a customer reply and flipped the case straight back to
  awaiting_agent — reopening the very case it had just closed.

= 1.30.0 - Added: popup-first support — the chat popup opens instantly, closing it reveals the full inbox =

**The new Contact Support flow**

Support is a helpline, not an inbox. The fastest possible path to typing the
problem wins, so Contact Support now opens the chat popup immediately. The roomy
in-page inbox sits hidden behind it and appears when the customer closes the
popup, with the same conversation already loaded. An **Open in popup** button in
the inbox header hands the thread back the other way.

* Added: **Popup first** delivery mode, now the default. Click Contact Support ->
  popup opens at once. Close it (the cross, or the expand control) -> the full
  in-page inbox appears with the conversation loaded. Press **Escape** instead
  and support closes completely, so there is always a way back to browsing.
* Added: **Open in popup** control in the in-page support inbox header, so the
  toggle works in both directions. Icon-only on phones to save header space.
* Added: exactly **one surface is ever on screen**. Opening the popup collapses
  the in-page inbox; revealing the inbox closes the popup.
* Changed: the popup's expand control now **prefers the inbox already on this
  page** over navigating to My Account -> Messages. It only navigates when the
  page has no support inbox to reveal, and its tooltip no longer claims it
  always "leaves this page", because usually it no longer does.

**Fixes to the surrounding support UI**

* Fixed: **"Contact support" appearing twice.** The code that retires the intro
  text and the support cards only ran when the thread opened *in place*, so every
  popup hand-off left the call to action sitting there behind the conversation.
  It now runs for whichever surface handled the thread. It also no longer gives
  up when the host markup is not one of three specific wrappers — it falls back
  to hiding the button itself, so the duplicate cannot survive any layout.
* Fixed: **the popup was not exclusive.** Choosing "Floating popup" opened the
  popup but left the in-page inbox visible behind it, so the customer still saw a
  second window. The in-page inbox is now collapsed before the popup opens.
* Fixed: **restoring the support cards was impossible.** `restoreTriggerChrome()`
  had been promised in a code comment since 1.28.1 but never actually written, so
  the list of hidden elements was write-only and dismissing support left the page
  permanently missing its own call to action until a reload. It now exists and
  runs when the customer dismisses support with Escape.
* Fixed: `hidden` did not reliably hide an inbox. There was no
  `.zymarg-inbox[hidden]` rule, so the plugin's own author styles beat the
  browser's low-specificity `[hidden]` rule. Added for both the inbox and the
  support trigger.
* Fixed: dismissing support with Escape could resurrect the in-page inbox. The
  code that collapses the inbox shared its bookkeeping list with the code that
  hides the support cards, and restoring the cards therefore restored the inbox
  too — so Escape left the customer looking at the thing they had just
  dismissed. The two are now tracked separately.
* Fixed: the delivery mode sent to the browser fell back to `auto` if reading the
  setting failed, while the server-side default had moved to `popup_first`. A
  settings hiccup could therefore render the inbox for one flow and run the
  other. Both now read the same constant.

**Settings**

* Changed: the **Contact Support opens** dropdown is honest now. It had four
  options where two — "Auto" and "In-page inbox" — ran byte-for-byte identical
  code, and "In-page inbox" promised it would never navigate while its own last
  line did exactly that. The list is now Popup first / Auto / Popup only / Full
  Messages page, with descriptions that match the behaviour. Sites that saved the
  old `inline` value keep working: it still resolves like Auto and stays visible
  in the dropdown until changed.
* Added: a warning on the Support tab when the chosen mode needs the popup but
  the **Store page chat popup** feature flag is switched off. Previously the mode
  silently degraded with nothing to explain why.
* Fixed: `composer.json` still declared 1.24.0, having missed five releases.

**For developers**

* Added: the popup now announces its lifecycle on `document`, so other code can
  react to it instead of monkey-patching:
  `zymarg-comm:popup-opened`, `zymarg-comm:popup-closed` and
  `zymarg-comm:popup-minimized`. `popup-closed` carries a `reason` of `close`,
  `dismiss` or `expand`. Minimize is deliberately its own event, because the
  conversation, the poll and the badge all keep running.
* Added: `zymarg-comm:popup-expand`, dispatched **cancelably** before the expand
  control navigates. Calling `preventDefault()` claims the expand and keeps the
  customer on the page.
* Added: `SupportChat::inboxRoot()` takes an optional fifth `$opts` array
  (`hidden`, `popup_toggle`). Both default to false, so the two agent callers —
  the wp-admin Admin&#8646;User screen and the frontend Agent Console drawer — are
  unchanged and can never be handed a hidden inbox.
* Added: `PopupSettingsService::inlineStartsHidden()` and
  `deliveryNeedsPopup()`, plus a `DELIVERY_DEFAULT` constant.
* Removed: a dead viewport branch in the support hand-off that split on mobile
  versus desktop and then did the identical thing in both arms.

= 1.29.0 - Added: a Support settings tab — choose where support opens, and edit every word of Smart Intake =

**Settings > Support (new tab)**

* Added: **Contact Support opens** — Auto, In-page inbox, **Floating popup (the
  same draggable window as the store page)**, or Full Messages page. Choosing the
  floating popup gives the store-page chat experience while still keeping the
  customer on the page they were already on. Requires the "Store page chat popup"
  feature flag.
* Added: **When a new message arrives** — Toast, Auto-open the popup, or Silent
  (badge only). Auto-open still respects the per-page allow-list under General.
* Fixed: both of these settings existed in code since 1.26.0 with **no form field
  anywhere**, so they could not be changed without editing the database. A setting
  nobody can reach is not a setting; they are now both reachable.

**Smart Intake is fully yours to edit**

* Added: a master **on/off** switch. Off opens the chat immediately with no
  questions, exactly like the pre-1.27 flow.
* Added: **every string is editable** — card title, the topic question, the order
  question, the subject question and its placeholder, the availability line, and
  both button labels. Leave a field blank to fall back to the shipped default,
  which is also how you undo a customisation. Defaults appear as grey
  placeholders so you can always see what you are overriding.
* Added: **the topic chips are editable**, separately for customers and vendors.
  One per line, as `key|Label`, or just write a label and a key is derived for
  you. The key is what gets stored on the ticket and shown to your team, so
  renaming a label is always safe while changing a key starts a fresh bucket for
  future tickets. Blank uses the defaults, and a list that cannot be parsed falls
  back to the defaults rather than showing a customer an empty row.
* Added: the **availability line** can be set to your real opening hours; left
  blank it computes an automatic reply-time message as before.

**Instant agent badges, at no extra cost**

* Added: the agent console badge, the Needs-reply count and the wp-admin tab-title
  counter now update the moment a customer writes, by riding the `message.sent`
  event that the realtime layer **already** broadcasts to each participant. No new
  Pusher events are published, no new connection is opened and no extra message
  quota is consumed.
* Unchanged: the 15-30s interval poll remains as the safety net. It still catches
  status changes (resolve / close / escalate) and covers any moment realtime is
  not configured or not reachable, so nothing depends on Pusher being present.

= 1.28.2 - Fixed: REVERTED the store-page popup regression introduced in 1.26.0 =

1.26.0 damaged the store-page chat popup. This restores it.

* Fixed: **removed the mobile "sheet" override.** 1.26.0 added an
  `@media (max-width:767px)` block that forced the popup to `position:fixed`,
  `width:100%` and `height:86vh` with `!important`, hid the resize handle and set
  the header cursor to `default`. Below 768px — and on any narrowed desktop
  window — that gave the popup a different default size and made it look and
  behave as though it could not be dragged. It also directly contradicted a
  documented decision in the geometry code itself: *"Active at every width ...
  there is no width gate: the popup can be moved and resized on a phone exactly
  as it can on a desktop."* The popup is once again draggable and resizable at
  every width, with press-and-hold on touch, and keeps its own 420x400 default
  with only the original 480px narrow-viewport tweak.
* Fixed: **the close button looks like itself again.** 1.26.0 gave it a divider
  rule, a border-radius and `width:auto`, visibly restyling a control that had
  shipped as a plain 24x24 glyph. Only the 6px gap remains — that spacing is what
  actually prevented the mis-click with the adjacent "open full inbox" link, so
  the cosmetics were unnecessary.
* Unchanged: the Minimize control and the draggable minimized puck stay. They are
  additions beside the original controls, sized to match at 24x24, and they do
  not alter the panel's geometry.
* Added: `_verify/popup-integrity.test.php`, a regression guard asserting the
  original popup contract — its own 420x400 default, `position:absolute`
  anchoring, drag/resize at every width, no `!important` near the panel, and no
  media query hiding the resize handle or the grab cursor. Run against the broken
  1.28.1 stylesheet it fails on precisely the five points above, so this class of
  regression cannot recur silently. Every other suite asserted on behaviour that
  was added; nothing asserted on behaviour that must not change. Now something
  does.

= 1.28.1 - Changed: opening support in place now retires the intro + Contact Support cards behind it =

* Changed: when the support inbox opens inline, the "Get help with your orders,
  account, or any issues." intro line and the Contact Support / Help Center card
  group above it are hidden, so the conversation is not sharing the panel with a
  prompt to start a conversation the customer has already started. Hidden only
  AFTER a thread actually opens — a cancelled Smart Intake leaves the prompt
  exactly as it was.
* Host-agnostic and additive: the plugin hides the card group the trigger lives
  in (the theme's card grid or the vendor dashboard's support tiles) and the
  description immediately before it, all guarded, with no change required to the
  theme or the vendor dashboard.

= 1.28.0 - Added: the Agent Console — triage and reply to support from the storefront, without wp-admin =

Completes the support surface. An agent browsing the site gets a "Support (N)"
node in the WordPress admin bar carrying a live open-ticket badge; clicking it
opens a slide-out drawer with the ticket queue and the full conversation, so
tickets can be answered without leaving the page they are on.

* Added: admin-bar "Support" node with a live open-ticket count, shown only to
  users who can answer (administrators and holders of the support-agent
  capability) and only while support is switched on. Invisible to shoppers.
* Added: a right-side console drawer with four queue tabs — Needs reply, Mine,
  Waiting on customer, Resolved — backed by /support/queue and ordered
  needs-reply-first. Escalated tickets are flagged in the list.
* Added: picking a ticket opens the full thread inside the drawer, with the same
  composer and the same ticket panel (identity, order/vendor context, history,
  Resolve / Reopen / Close) used on every other support surface. This is pure
  glue over existing machinery — window.zymargInbox.openConversation() from
  1.26.0 drives the thread and support-ticket.js paints the panel — so there is
  no second copy of the chat UI to drift.
* Added: the admin-bar badge and the Needs-reply tab count refresh on a timer,
  so an agent sees new work arrive without reloading.
* Note: admin-bar-only was chosen over a floating on-page widget on purpose — a
  pill would sit on every page competing with the customer chat popup and the
  toast region, whereas the admin bar is where staff already expect controls and
  shoppers never see it.
* Note: a non-administrator agent can open a ticket in the drawer only for
  conversations they participate in (the standard conversation permission);
  administrators can open any. Assignment/escalation add the agent as a
  participant, so their own queue always opens.

= 1.27.0 - Added: support tickets — solved/unsolved status, who is asking, what it is about, Smart Intake, escalation =

This release answers the two questions the old support surface could not: "is
this solved?" and "who is asking, about what?". Support threads were previously
ordinary conversations with only a moderation status, so an agent's only way to
mark a problem done was to Archive it, and a thread carried no idea of the order
or person behind it.

**Ticket lifecycle**

* Added: a real ticket status distinct from the moderation lifecycle —
  Waiting on us / Waiting on you / Resolved / Closed. Driven by actual messages:
  a customer reply moves a ticket into the queue, an agent reply hands it back,
  and the first agent reply time is recorded.
* Added: a status pill shown to both sides, worded correctly for each — "Waiting
  on you" means opposite things to a customer and an agent, so the two never
  share one misleading string.
* Added: agent actions — Mark resolved, Reopen, Close. Resolve and close are
  distinct: a customer reply REOPENS a resolved ticket (people do say "actually
  it is still broken"), while closed is final and a new message starts a fresh
  ticket rather than resurrecting a dead one. Reopens are counted.
* Changed: ticket-per-issue. Contact Support now resumes only an OPEN ticket; a
  new problem after a resolved/closed one opens a new thread instead of piling
  onto a conversation an agent already signed off. Sites upgrading before the
  new table exists fall back to the previous one-thread behaviour until it does.
* Added: `zc_support_tickets` table. It is created on activation and, for sites
  that upgrade in place, on the version check; threads that predate it are
  adopted lazily the first time they are touched, so there is no backfill pass.

**Who is asking, and about what (agent view)**

* Added: a requester identity card in the thread — name, avatar, whether they
  are a customer or a vendor, member-since, order count and lifetime spend, and
  how many open tickets they have. Answers "who needs help" at a glance.
* Added: an order / vendor context card, with a one-click link to the order in
  wp-admin. This required a dedicated ticket table: a conversation has only one
  context slot and support already spends it on the string "support", so an
  order link had nowhere else to live.
* Added: a collapsible history of the requester's previous tickets
  ("3 previous tickets, 2 resolved"), so an agent has memory across contacts.

**Smart Intake**

* Added: an optional intake card before a customer opens a thread — topic chips
  (tailored for buyers vs sellers), a picker of their own recent orders, and a
  one-line subject. The chosen context is stored on the ticket, so the first
  thing an agent sees already says what it is about, with the order attached. An
  order can only be attached if it actually belongs to the person asking.
* Added: a friendly availability line on the intake card.

**Escalation, rating, analytics**

* Added: hourly no-reply escalation. A ticket left Waiting-on-us past a window
  (default 2 hours, filterable) is reassigned to the least-loaded other agent
  and fires `zymarg_comm_support_escalated`. The sweep is a no-op while support
  is off.
* Added: a customer rating card (1-5) shown once a ticket is resolved.
* Added: lifecycle actions for other plugins to consume —
  `zymarg_comm_support_resolved`, `_closed`, `_reopened`, `_rated`,
  `_escalated`, and `_closed_ticket_pinged`. Automation and Insights can wire to
  these without this plugin depending on either.
* Added: REST for the whole surface under `zymarg-comm/v1` —
  `/support/intake`, `/support/queue`, `/support/counts`, `/support/stats`,
  `/support/ticket/{id}` and its `resolve|reopen|close`, `context` and `rate`
  actions. Agent load balancing now counts OPEN tickets rather than every thread
  an agent ever touched.

= 1.26.0 - Fixed: Contact Support no longer navigates away; popup gains minimize; notifications go both ways =

**Contact Support stayed on the wrong page (the headline fix)**

* Fixed: clicking Contact Support redirected the customer to My Account -> Messages instead of opening support where they already were. Two separate defects combined to force this. First, `support.js` probed `window.ZymargLiveChat` and called `.openConversation()`, but `live-chat.js` publishes `window.zymargLiveChat` (lowercase z) and exposes `.open()` — JavaScript is case sensitive, so the guard was permanently `undefined` and the method never existed. The popup hand-off was unreachable dead code. Second, with that branch unreachable, control always fell through to `window.location.href = inbox_url`. Both hosts already ship a hidden inline support inbox on the same page and already declare it via `data-inline-target`, but `support.js` never read that attribute, so the in-place surface sat unused while the customer got moved off the page. Messages is a different feature for a different job; support now resolves in place.
* Added: explicit surface resolution — inline, then popup, then page. Navigation is the last resort, reached only when the page genuinely has no surface. An inline surface is discovered even when the host did not set `data-inline-target`, by scanning for a support inbox root, so hosts get in-place behaviour without changes.
* Added: `openConversation()` published as an alias of `open()`, so any other caller that copied the old (broken) signature starts working rather than failing silently.
* Added: `window.zymargInbox.openConversation( id, root )` plus a `zymarg-comm:open-conversation` DOM event, so a revealed inline inbox can be pointed at the resolved thread. Safe to call before hydration — the id is stashed and consumed once the conversation list resolves.
* Fixed: a support inbox no longer opens on a dead "Select a conversation" pane. Support surfaces hide the conversation list entirely (there is only ever the one admin thread), so the newest thread is auto-selected. Scoped to `data-context="support"`; buyer and vendor inboxes are untouched.

**The cross that looked like it reloaded the page**

* Fixed: the close button was never broken. `live-chat.js` injected the "open full inbox" LINK immediately against it — same 24x24 box, same white-at-.9 colour, 2px apart — so aiming for close hit the link and navigated away. Controls are now grouped and ordered [expand] [minimize] | [close], with a separator, a wider gap and distinct hover states before the destructive one. Both controls also carry explicit tooltips, and expand says it leaves the page.

**Minimize**

* Added: a Minimize control. Minimize is not close — the panel hides but the conversation, the polling loop and the unread counter all keep running, so a reply that arrives while minimized still bumps the badge.
* Added: minimized state renders as a small 40px puck that can be dragged anywhere on the page. Position is remembered per device in `localStorage`, under its own key so dragging the puck never moves the panel and vice versa. Right/bottom anchored and re-clamped on resize and rotation, so it cannot end up off-screen.
* Added: the puck parks on the RIGHT EDGE, vertically centred, rather than bottom-right — the theme's toast region defaults to bottom-right, and a puck under the toast stack would be covered by the very notifications it exists to answer.
* Added: minimized state survives navigation. Parking the chat rather than closing it is a deliberate choice to keep it reachable while browsing, so it persists to the next page.
* Fixed: a drag that ends over the puck no longer registers as a click, which previously would have re-opened the panel the instant you let go.

**Notifications, in both directions**

* Added: arriving messages announce themselves. Behaviour is configurable — `toast` (new default), `autoopen` (the historic behaviour) or `badge` (silent).
* Changed: the popup no longer throws itself open by default. That could land on top of whatever the customer was doing, mid-checkout included. `autoopen` still exists and is still additionally gated by the auto-open page allow-list, so existing configurations behave exactly as they did.
* Added: customer-side notification delegates to the theme's unified toast (`window.ZymargToast`, falling back to the `zymarg:toast` DOM event, then to legacy auto-open). Toasts are the theme's job — this deliberately does not ship a rival implementation that would stack two notification styles on one screen.
* Added: admin-side notification, so support is symmetric. The theme's toast does not exist inside wp-admin, where the reply surface lives, so this uses what wp-admin already has: a `(N)` counter on `document.title` (visible on the browser tab, reaching an agent whose attention is in another tab), a native WordPress count bubble on the Admin<->User menu item, and the theme toast opportunistically if some screen has loaded it. Loads on every admin screen, because the point is reaching an agent who is doing something else. Gated to `manage_options` or `zymarg_support_agent`, and silent while the support feature is off.
* Note: the browser Notification API is deliberately not used. It requires a permission prompt, which is a product decision rather than a bug fix.

**Mobile**

* Added: below 768px the popup becomes a full-width bottom sheet. A 320px-minimum popup on a 360px viewport is fullscreen with worse ergonomics — the on-screen keyboard eats the composer. Resize and drag are hidden there, since a sheet is already edge to edge.

**Settings**

* Added: `support_delivery` — `auto` (default, resolves inline then popup then page), `inline`, `popup` or `page`. Overridable per control with `data-delivery`, so one shortcode can opt out without changing site config.
* Added: `new_message_behavior` — `toast` (default), `autoopen` or `badge`.
* Added: `window.zymargLiveChat.debug()` now also reports `newMessageBehavior`, `supportDelivery`, `minimized`, `dockPosition` and whether the theme toast was detected.

= 1.25.9 - Changed: the host-heading layout is now opt-in, and can no longer switch itself on =

* Changed: `surface.host_native_chrome` now ships DISABLED. 1.25.8 shipped it enabled, which restyled two live customer-facing pages on update. In practice the edge-to-edge inbox reads better on most setups, so edge-to-edge is now the default and the host-heading layout is something you opt into deliberately. Sites already running it keep their current setting — only the seeded default changed, so nothing flips underneath you either way.
* Fixed: both `hostChromeEnabled()` checks now fail CLOSED instead of open. They previously returned true when the feature-flag service was unavailable, meaning an early-boot render or a fault in the flags module could enable the host-heading layout on a site that never asked for it. The surface flags above still fail open on purpose — a missing flag service should never hide an inbox someone is reading — but this one is cosmetic, so the safe answer is to leave the known-good layout alone.
* Note: `FeatureFlagService::isEnabled()` resolves only from the `zc_feature_flags` table; there is no filter or constant override. If you need to force this off without the admin toggle: `UPDATE wp_zc_feature_flags SET is_enabled = 0 WHERE flag_key = 'surface.host_native_chrome';` then clear your object cache.
* Unchanged: everything else in 1.25.8. With the flag off, both inboxes render exactly as 1.25.7 did — edge to edge, own title, and without the dark purple accent rule removed in 1.25.7.

= 1.25.8 - Added: the inbox now wears its host page's own section heading, so Messages reads as a tab rather than a destination =

* Added: on My Account the Messages section now opens with the theme's own `.panel-header` (section icon + h2) and `.panel-desc`, structurally identical to Orders, Addresses and every other native panel. On the seller dashboard it opens with the dashboard's own `.zymarg-vendor-greeting` (h1 + subtitle), word for word the copy the dashboard's native messages section used. Both are consumed from the host's existing stylesheet, already enqueued on those pages, so no new CSS ships for the headings.
* Added: feature flag `surface.host_native_chrome` (Surfaces group, ON by default). Turn it off to restore the inbox's own built-in title and its full-bleed layout exactly as 1.25.7 rendered them. One click, no code edit.
* Changed: with the host heading present the inbox's own `Messages` title is omitted, so the heading is never duplicated on screen or in the accessibility tree. The conversation filters inherit the `flex:1` the title used to hold, keeping search at the far end of the row.
* Changed: the inbox is once again a card inside the host's page frame rather than a full-bleed region. The four `:has()` layout escapes, the squared corners and the dropped left border now apply only to inboxes WITHOUT host chrome, so the host's own padding and max-width apply untouched and cannot drift from the plugin's copy of them. Corner radius and shadow are taken per surface from `--zv-radius`/`--zv-shadow` on the seller side and matched to `.dash-detail` (12px, `0 8px 24px rgba(0,0,0,.04)`) on the buyer side.
* Changed: height now subtracts the frame's bottom gutter so the card closes with the same breathing room every other panel ends on. It remains a fixed box, so the conversation list and message log keep their own scrolling and the composer stays pinned — a page-height inbox would push the composer below the fold on long threads. The JS-measured `--zi-offset` is the root's absolute document top, so it already accounts for the new heading and needed no change.
* Changed: on phones the inbox header collapses from two rows to one (filters + search icon), returning roughly 34px of vertical space to the conversation list. The expanded-search state is unaffected.
* Unchanged: standalone `[zymarg_my_messages]`, `[zymarg_vendor_messages]` and the inline support inbox render exactly as they did in 1.25.7 — they never request host chrome, so they keep their own title, gutter, 18px radius and full-bleed escapes.
* Unchanged: zero edits to the ZYMARG OS theme and zero edits to ZYMARG Vendor Dashboard. Both surfaces are reached only through the filters they already expose, and the host heading is emitted from the hosted callbacks so the shortcode paths are untouched. No JS, REST, database or migration changes.

= 1.25.7 - Fixed: the inbox no longer opens with a dark purple rule that made it read as a separate page =

* Fixed: removed the 3px full-width brand gradient bar (`.zymarg-inbox::before`) from the top of the buyer My Account inbox and the seller dashboard inbox. At 3px tall across a wide element the 135deg ramp is seen almost entirely at its #9500a5 end, so it presented as a solid dark purple line spanning the content column. Neither host opens a section that way: buyer panels start with `.panel-header` (whose 2px rule sits *below* the heading) and seller sections start with `.zymarg-vendor-greeting` (no rule at all), so the bar was the single strongest cue that the Messages tab was a different page rather than the next tab of the same one.
* Fixed: zeroed the accompanying `margin-top:3px` on `.zymarg-inbox__header`, which existed only to clear that bar. Without this, removing the bar would have left a 3px dead strip in its place. Desktop only â the mobile breakpoint already set 0.
* Unchanged: standalone `[zymarg_my_messages]`, `[zymarg_vendor_messages]` and the inline support inbox keep the accent bar, their gutter and their 18px radius. On a normal page the inbox genuinely is a card, and there the accent mirrors the theme's own `.dash-detail .gradient-bar`.
* Unchanged: no PHP, JS, REST, database or feature-flag behaviour is affected. The root's 1px outline border, the header padding and the header's 1px bottom border are all untouched. Scoped with the same two selectors already used by the full-bleed and border-seam rules, so every host-chrome adjustment stays in one place.

= 1.25.6 - Added: press-and-hold dragging on touch, and dragging on every screen size =

* Added: on touch devices, press and hold the purple header for 350ms to pick the window up, then move it anywhere. A hold is required so an ordinary tap or a scroll flick is never mistaken for a drag. If the finger travels more than 10px before the hold completes, the gesture is released back to the browser as a scroll.
* Changed: dragging and resizing now work at every screen width. The previous build disabled geometry below 768px on the assumption that a movable window is a misfeature on a phone. That assumption was wrong for this marketplace, where a user may want the chat moved clear of the page behind it on any device.
* Changed: the grab cursor, text-selection suppression and touch-action rules moved out of the min-width:768px media query so they apply everywhere. touch-action:none on the header is what allows a finger to drag the panel rather than scroll the page underneath it.
* Added: the panel casts a deeper shadow while it is being dragged, so it reads as physically picked up.
* Unchanged: mouse and pen still start dragging immediately with no hold, since there is no scroll gesture to disambiguate from.

Note on reach: the popup can be moved anywhere within the viewport, down to an 8px margin from each edge. It cannot be dragged off-screen, and it is re-clamped whenever the window is resized or the device is rotated, so it can never end up stranded out of view.

= 1.25.5 - Fixed: draggable popup never activated after an in-place upgrade =

* Fixed: dragging and resizing did nothing on sites that updated from 1.25.3 to 1.25.4 without deactivating and reactivating the plugin. The feature is guarded by the new surface.popup_draggable flag, but flag defaults were only ever written during Installer::activate(). On an in-place upgrade that method never runs, so the flag row was absent from zc_feature_flags, isEnabled() returned false, the container rendered data-zymarg-geometry="0", and the JavaScript disabled itself exactly as designed. The code was correct; the flag was never seeded.
* Fixed: Updater::check() now calls FlagRegistry::writeDefaults() after running migrations, so every release seeds flags introduced since the installed version. Existing rows are preserved and only missing keys are inserted, so an administrator who has switched a flag off will not have that choice overwritten. This repairs the same class of bug for all future flags, not just this one.
* Fixed: the feature flag cache entry is invalidated during upgrade, so a persistent object cache cannot serve a stale enabled-key list for up to five minutes after the new flag is seeded.
* Added: FeatureFlagService::exists() reports whether a flag row is present at all, which distinguishes "an administrator switched this off" from "this was never seeded".
* Changed: LiveChat::geometryEnabled() now fails open. If the surface.popup_draggable row is missing it treats the feature as on, since it ships enabled by default. A flag that is present and set to 0 is still respected. This is a second, independent safeguard so the popup works even if the upgrade routine did not run.

= 1.25.4 - Added: draggable and resizable chat popup with per-device memory =

* Added: the popup can be dragged by its header. Buttons and links inside the header are excluded, so close and open-full-inbox still work normally.
* Added: the popup can be resized from a grip in the top-left corner. The grip is top-left rather than the conventional bottom-right because the panel is anchored to the bottom-right, so a bottom-right grip would sit on top of the send button and grow the panel down into the launcher.
* Added: position and size are remembered in localStorage, keyed by user id so two accounts on a shared computer do not inherit each other's layout.
* Added: double-click the header to reset the popup to its default 420x400 position and size.
* Added: feature flag surface.popup_draggable, enabled by default. Turning it off removes the grip and the drag behaviour entirely.
* Size limits: there is no artificial maximum. The popup can be grown to the full viewport less an 8px margin on each edge, so it can be made to fill the screen. The only floor is 320x300, which exists because the composer has an intrinsic minimum width (attach 32 + send 48 + textarea 110 plus gaps and padding) below which the row wraps and breaks.
* Behaviour: geometry is clamped on every open, every drag frame and every window resize, so the popup can never be stranded off-screen after the browser is resized or the user moves to a smaller monitor. A minimum 8px margin from every viewport edge is always preserved.
* Behaviour: movement uses right and bottom offsets and never transform, because the open animation already animates transform and the two would conflict.
* Behaviour: disabled below 768px. On phones the panel is already near full-width, and stored geometry from a desktop is ignored rather than applied.
* Behaviour: stored values carry a schema version. Values from an older schema are discarded rather than reinterpreted, so changing the default later cannot strand anyone.
* Unchanged (deliberately): nothing is stored server-side and no REST call is added. Window geometry is a property of the screen in use, not of the account, so it is deliberately not synced across devices.
* Unchanged (deliberately): the buyer, seller and support inboxes were not touched.

= 1.25.3 - Changed: tighter chat popup, 580px to 400px =

* Changed: the popup panel height is now 400px, down from 580px.
* Changed: the header is tighter. Padding 14px 18px to 8px 14px, title 15px to 14px, the close button is now a fixed 24x24 box at 20px instead of a loose 24px glyph, and the expand link is 24x24 instead of 28x28. Header height drops from 56px to 40px.
* Changed: the composer row is tighter. Padding 10px 12px to 8px 10px, gap 8px to 6px, textarea min-height 48px to 40px with padding 13px 16px to 9px 14px, send button 56x48 to 48x40, attach button 36x36 to 32x32. Composer height drops from 68px to 56px.
* Changed: on screens 768px and wider the textarea and send button are 38px tall, down from 44px.
* Fixed: the attach button was 36px tall plus a 6px bottom margin, which is taller than the new 40px textarea and would have dictated the composer height on its own. Reduced to 32px plus 4px so the textarea stays the tallest element and the row collapses as intended.
* Result: the message area gains height as a proportion of the panel, rising from 79 percent of 580px to 76 percent of 400px, so the reduction comes almost entirely out of chrome rather than out of readable content.
* Unchanged (deliberately): the panel stays 420px wide, the launcher stays 56x56, message bubbles keep 82 percent max-width and 11px 15px padding, and the textarea still grows to a maximum of 3 lines before scrolling.
* Unchanged (deliberately): the buyer, seller and support inboxes were not touched. This release only affects the popup.

= 1.25.2 - Fixed: squared the inbox outer frame in full-bleed hosts =

* Fixed: the buyer and vendor inboxes kept an 18px card radius after their host gutters were dropped to 0, so the rounded left edge sat flush against the sidebar and left a lens-shaped sliver of background where the two curves pulled apart. The outer frame is now square in both hosted inboxes.
* Fixed: the sidebar border-right and the inbox border-left rendered as a single 2px seam. The redundant inbox border-left is removed on screens 768px and wider, where the two are adjacent.
* Unchanged (deliberately): every inner radius is untouched. Avatars stay 12px, message bubbles stay 16px, and all pills, buttons, menus, chips and the reaction panel keep their existing shape.
* Unchanged (deliberately): a standalone [zymarg_my_messages] or an inline support inbox placed on a normal page still has a gutter, so it keeps the 18px radius and continues to read as a card.
* Unchanged (deliberately): the chat popup was not touched.

= 1.25.1 - Added: Admin/User messaging documentation =

* Added: Help & Docs -> Admin Guide now includes an "Admin/User Messaging" chapter covering the master toggle, the agent pool, one-thread-per-user threading, where agents reply, shortcode placement and attributes, renaming the channel, and the participant-scoped visibility limitation.
* Added: Help & Docs -> User Guide now includes a "Contacting Support" chapter for end users.
* Added: Help & Docs -> REST API now documents GET /support/config, POST /support/start, GET /support/threads and GET /support/agents with full request and response payloads and error codes, plus the optional context parameter on the conversation list.
* Added: Help & Docs -> PHP API now documents SupportService and SupportRepository, including all public methods and constants.
* Added: Help & Docs -> Hooks & Filters now documents the zymarg_comm_support_started action and the zymarg_comm_support_label, zymarg_comm_support_agents and zymarg_comm_support_inbox_url filters.
* Added: Help & Docs -> Mobile Integration now documents the three-step support flow for the future app.
* Added: Help & Docs -> Troubleshooting now covers the five most likely support issues, including the button not appearing and "No support agent is available right now".
* Unchanged (deliberately): no code, markup, styling or behaviour was altered in this release. Documentation only.

= 1.25.0 - Added: Admin⇄User messaging =
* Added: a new "Admin⇄User" submenu under Communication. One screen owns the whole feature: the master on/off switch, the support agent pool, a copy-paste placement reference, and the live support inbox.
* Added: the feature ships OFF. While off the shortcodes render nothing at all, the support API returns 403, and the admin screen shows a disabled state. Nothing existing changes until you turn it on.
* Added: shortcodes [zymarg_support_chat], [zymarg_contact_support] and [zymarg_support], so the same feature can be placed anywhere under any name. Attributes: label, title, mode (button | link | inline), class, icon, logged_out. Example: [zymarg_support_chat label="Alpha"].
* Added: mode="inline" embeds the full inbox in any page, rendered from the SAME .zymarg-inbox markup and the SAME inbox.css and inbox.js as the buyer and vendor inboxes, so the chatbox is identical by construction rather than by imitation and inherits every 1.24.x layout, composer, reaction and mobile fix automatically.
* Added: support agents are a pool, identified by the new zymarg_support_agent capability rather than a single hardcoded administrator, so support survives one person being away. Granting it does not give WordPress admin access. Administrators receive it once on upgrade.
* Added: new threads are assigned to the configured default agent, or otherwise to whichever agent currently carries the fewest support threads, so load spreads instead of piling on one person.
* Added: one ongoing thread per user. Repeat contacts resume the same conversation instead of spawning duplicates.
* Added: either side can start first. A user can contact support, and an agent can open a thread with a user.
* Added: agents can reply from the admin screen or from their own My Account inbox. They are ordinary participants, so no separate surface was needed.
* Added: REST endpoints for a future app, under zymarg-comm/v1 - GET /support/config, POST /support/start, GET /support/threads, GET /support/agents. Messaging itself deliberately has no bespoke endpoints: once a thread exists, clients use the standard /conversations/{id}/messages surface and get attachments, reactions, replies, typing and read receipts with no support-specific code.
* Added: filters zymarg_comm_support_agents, zymarg_comm_support_label and zymarg_comm_support_inbox_url, plus the zymarg_comm_support_started action.
* Changed: the conversation list endpoint accepts an optional context parameter. The buyer and vendor inboxes do not send it, so their requests and payloads are byte-for-byte unchanged; the support inbox sends context=support to see only support threads.
* Fixed: a support agent without full administrator rights would previously have been typed as a buyer or a seller, so a customer contacting support would have been treated as a buyer-to-buyer chat and rejected by a gate that is off by default. Support agents now pair as Admin.
* Unchanged (deliberately): no database migration. Support threads are ordinary conversations marked with context_type = 'support', reusing the existing tables exactly as the other surfaces do.
* Unchanged (deliberately): the chat popup, the buyer inbox and the seller inbox. No markup, styling or behaviour on any existing surface was altered.

= 1.24.14 - Changed: the seller inbox is now edge to edge, matching the buyer inbox =
* Fixed: the seller inbox was still framed by the vendor dashboard shell, which pads its main column with clamp(16px, 3vw, 28px), so on a desktop there was a 28px gap on all four sides that the buyer inbox no longer had. The buyer side went edge to edge in theme 5.12.17; this brings the seller side in line.
* Changed: that padding is zeroed only while the vendor main column is rendering the inbox. Every other vendor section keeps its 28px frame and its 1180px reading width.
* Changed: the vendor content wrapper's 1180px cap and auto centering are also released for the inbox only, so the conversation list and thread use the full column.
* Changed: no change is needed to the ZYMARG Vendor Dashboard plugin. The rules live in the Communication plugin's own stylesheet, alongside the existing full-width host rules from 1.24.9, so there is one place to look and only one plugin to update.
* Technical: scoped with :has() rather than a body class, deliberately. The vendor dashboard swaps sections over AJAX, so a class written at page load would go stale exactly as the theme's did before 5.12.19, while :has() is re-evaluated by the browser on every DOM change.
* Unchanged (deliberately): the 264px vendor sidebar, the brand orbs, the shell background, and every other vendor section. Browsers without :has() keep the padded layout, which is the existing behaviour.

= 1.24.13 - Fixed: the empty-state text no longer flashes when opening a conversation =
* Fixed: clicking a conversation briefly showed "Select a conversation to view your messages" ("Select a customer to view the conversation" on the seller side) before the chat appeared. That text is server-rendered markup sitting inside the thread column, and nothing replaced it until the messages request came back, so it stayed on screen for the length of the round trip.
* Changed: the thread shell is now painted the instant a conversation is clicked, before the request is sent. The real conversation title appears in the thread header immediately, followed by three shimmering skeleton bubbles that match the shape of real messages.
* Changed: on mobile this also means the thread view is revealed already showing the conversation you tapped, instead of being revealed still holding the placeholder.
* Added: the skeleton honours prefers-reduced-motion and stops animating for visitors who ask for reduced motion.
* Unchanged (deliberately): the placeholder itself, which is still correct and still shows on desktop before any conversation has been opened.

= 1.24.12 - Changed: tighter mobile header stack and corrected composer row gaps =
* Fixed: the attachment chip and the reply preview each carried margin-bottom: 8px while sitting in a composer that already has gap: 8px, so the real space below them was 16px, double the 8px used everywhere else in the composer. Both margins are removed and the flex row gap alone now spaces them.
* Changed: on screens 640px and below the three stacked rows above the first message (the Messages title row, the filter pill row and the thread header) are tighter. Header padding 18px 22px becomes 12px 16px, the header margin-top is dropped, the title drops from 1.25rem to 1.05rem, the filter pills go from 7px 15px to 6px 12px, and the thread header goes from 15px 22px to 10px 16px.
* Changed: the wrap gap between the title row and the filter row is now set with row-gap: 8px, so the vertical gap tightens to 8 while the horizontal gap between the title and the search icon stays at 12.
* Changed: the mobile search icon goes from 38px to 34px square, matching the search close button.
* Result: roughly 173px of chrome above the first message becomes roughly 139px, about 34px given back to the conversation. No tap target is smaller than 34px.
* Unchanged (deliberately): every desktop dimension. All of the tightening lives inside the max-width:640px media query, so the two-column layout above 640px is untouched.

= 1.24.11 - Changed: the inbox now fills the screen on every device, not only on phones =
* Fixed: on tablets and desktops the inbox still stopped short of the bottom edge. 1.24.10 moved the viewport-fill height into the max-width:640px media query, so everything above 640px kept the old height:100% plus max-height: min(78vh, 820px) and therefore kept the dead space below the panel.
* Changed: the viewport-fill height now lives on the root rule and applies at every width. The height is calc(100dvh -- var(--zi-offset)), with a 100vh line before it as a fallback, and --zi-offset is measured in JavaScript on load, on resize and on orientation change.
* Changed: min-height is now 420px, replacing 520px. The old floor could exceed the space available on short laptop screens and reintroduce an overflow.
* Removed: the duplicate height declaration from the mobile media query, which now only sets min-height:0 for the master-detail views. One source of truth for the panel height.
* Unchanged (deliberately): the mobile master-detail behaviour, the history handling and the filter-pill return path from 1.24.10, and the two-column desktop layout.

= 1.24.10 - Changed: mobile inbox is now a proper two-view layout and fills the screen =
* Fixed: the inbox stopped short of the bottom of the screen on phones. The root carried max-height: min(78vh, 820px), a cap that made sense when the panel was a card inside a padded column but left roughly 22vh of dead space once it went edge-to-edge. On screens 640px and below the panel now fills the space that is actually left below the site header.
* Changed: that remaining space is measured in JavaScript rather than assumed. The distance from the top of the document to the inbox is written to a --zi-offset custom property on load, on resize and on orientation change, and the height is calc(100dvh -- var(--zi-offset)). This stays correct whatever the header height is, with or without the WordPress admin bar. A 100vh line precedes it as a fallback for browsers without dvh, and dvh also keeps the height right while a mobile browser's URL bar collapses.
* Changed: on phones the conversation list and the open thread are now two separate full-screen views instead of being stacked. Opening a conversation hides the list; previously it stayed on screen in a 220px window above the thread and ate space that the messages needed.
* Changed: the list is no longer capped at 220px on mobile, so when it is showing it uses the full height.
* Added: tapping any filter pill -- All, Unread, Orders or Product -- returns from an open thread to the list. Picking a filter means "show me the list", and Unread, Orders and Product return to a filtered list rather than resetting the filter.
* Added: the device back button closes the thread and returns to the list instead of leaving the page. One history entry is pushed per thread view, and it is popped when the thread is closed by any route, so no stray entries accumulate. On iOS the same entry makes the edge-swipe-back gesture work identically.
* No on-screen back arrow was added: the device back button, the swipe gesture and the filter pills already cover the return path.
* Unchanged (deliberately): desktop. The two-column layout, the 78vh height cap and every dimension above 640px are exactly as they were -- the new is-thread-open class is only acted on inside the max-width:640px media query.

= 1.24.9 - Changed: the inbox now uses the full width of its column, and the chat popup is wider =
* Changed: the buyer inbox was being letterboxed by the theme's My Account content column, which caps at 960px. The cap is now released, but ONLY while the Messages tab is the active panel, so Dashboard, Orders, Downloads, Addresses and every other tab keep their original 960px reading width.
* Unchanged (deliberately): the 260px My Account sidebar. It is a fixed/sticky flex sibling of the main column and nothing about its width, position, padding or stacking was altered. Only the max-width of the fluid main column is relaxed, so the inbox grows into the empty space to the right of the sidebar and never underneath it. The main column keeps its own horizontal padding, so the inbox still clears the sidebar border and the viewport edge.
* Changed: any direct wrapper of the inbox also has its width cap released, which gives the seller inbox the same full-width behaviour inside the Vendor Dashboard panel without this plugin having to know that plugin's class names.
* Changed: the live chat popup is now 420x580 instead of 370x540. Its max-width of calc(100vw -- 40px) and max-height of calc(100vh -- 120px) are unchanged, and the small-screen rule at 480px and below still takes over, so on phones it behaves exactly as before.
* Note: the full-width rules use the CSS :has() selector. On a browser that does not support it the layout simply stays as it was in 1.24.8 -- nothing breaks.

= 1.24.8 - Fixed: buyer and seller inboxes now render pixel-identically =
* Fixed: the two inboxes could render with a different corner radius and a different drop shadow. The root mapped --zi-radius to --zv-radius and --zi-shadow to --zv-shadow, but those two tokens are published by the Vendor Dashboard plugin only. On the seller surface they resolved to the vendor plugin's values; on the buyer surface they fell through to the built-in literals. Both are now pinned to the same literals.
* Every other token alias maps to a theme token (--color-*, --zymarg-*), and the theme is active on both surfaces, so colours, fonts and the inner radius remain host-driven and still follow the merchant's Customizer settings and dark mode.
* Fixed: the inbox root now declares margin:0, width:100% and max-width:100% so it cannot inherit different outer spacing from the theme's section panel than from the vendor dashboard's panel.
* Fixed: box-sizing:border-box is now applied to the root and every descendant. Previously the component relied on whichever reset the host page happened to apply, so the padded fields could compute to different widths on the two surfaces.
* Audited and confirmed already identical: the stylesheet contains no .zymarg-inbox--vendor rule of any kind, so every header, list, thread, message and composer dimension was already shared. The JavaScript differs only in the side parameter it sends to the conversations endpoint.
* Remaining differences are deliberate and non-visual: the buyer surface says "Search conversations" and "Select a conversation to view your messages", the seller surface says "Search customers" and "Select a customer to view the conversation"; the surfaces use different feature flags (surface.buyer_inbox and surface.vendor_inbox); and the buyer surface renders a logged-out notice where the seller surface renders nothing.
* NOT changed: the padding of the host containers themselves. The theme's My Account section panel and the vendor dashboard's section wrapper are owned by the theme and the vendor plugin, which this plugin treats as read-only.

= 1.24.7 - New: All / Unread / Orders / Product filters on the buyer inbox =
* New: the buyer inbox now has the same filter row as the seller inbox -- All, Unread, Orders and Product -- placed between the title and the search icon, so both headers are structurally identical.
* No new JavaScript was needed. The filter handler already bound generically to every [data-zymarg-inbox-filter] element and the filtering logic already understood the unread, orders and products cases; the buyer inbox simply never rendered the buttons.
* Filtering is client-side over the conversations already loaded in memory and combines with search, exactly as on the seller side. No REST call and no database query were added.
* context_type is stored on the conversation itself rather than per participant, so Orders and Product filter correctly for buyers with no API change.
* On mobile the buttons inherit the ordering from 1.24.6: title and search icon on row 1, filters on their own sideways-scrolling row below, and all of them hidden while search is open.

= 1.24.6 - Fixed: seller search icon dropped below the filter buttons on mobile =
* Fixed: on the seller inbox the search icon rendered on a third line, underneath the All / Unread / Orders / Product buttons. The header is a wrapping flex row and the filters sit between the title and the icon in source order, so once the pills no longer fitted beside the title they wrapped and carried the icon down with them.
* Changed: on mobile the header now uses explicit ordering -- title (order 0) and search icon (order 1) always share the first row, and the filters are forced onto their own full-width row below (order 2). The seller header row is now pixel-identical to the buyer header row: 18px 22px padding, 12px gap, flexible title, 38x38 icon at the end.
* Changed: the filter row scrolls sideways instead of wrapping, so it stays a single tidy line even at 320px where the four pills total roughly 314px against about 276px of usable width. The scrollbar is hidden on both WebKit and Firefox.
* Desktop is untouched; the ordering and scroll rules live entirely inside the 640px media query.

= 1.24.5 - Changed: inbox search collapses to an icon on mobile =
* Changed: on screens 640px and below the search field is hidden behind a 38px round search icon at the end of the header, reclaiming the full-width 42px row it previously occupied. Desktop is untouched -- the field stays permanently visible at its fixed 220px.
* New: tapping the icon puts the header into search mode. The title, the filter buttons and the icon itself are hidden so the field spans the full header width, with a close button beside it.
* Closing search (via the close button or the Escape key) clears the query and re-renders the list, so the conversation list can never be left silently filtered by a query the user can no longer see.
* Search remains entirely client-side -- it filters the conversations already loaded in memory against their title and preview, with a 150ms debounce. No REST call and no database query were added.
* Applied to both the buyer and the seller inbox. The seller inbox keeps its All / Unread / Orders / Product filters, which reappear as soon as search is closed.
* Accessibility: the icon exposes aria-expanded, and the icon, close button and field labels all run through the translation layer.
* UNCHANGED (deliberately): the search behaviour itself, the filter buttons, the conversation list and the composer.

= 1.24.4 - Changed: live chat popup message field caps at 3 lines =
* Changed: the live chat popup composer now grows to 3 lines instead of 4 before scrolling internally. The panel is only 540px tall (and shorter on phones once the keyboard is open), so a 4-line field left too little room for the message list.
* The buyer and seller inboxes keep the 4-line cap, since they render in a much taller container (min-height 520px, max-height min(78vh, 820px)).
* UNCHANGED (deliberately): everything else in the composer -- min-width:0 shrink fix, tightened spacing, the attachment bubble with its remove button, Enter to send and Shift+Enter for a newline.

= 1.24.3 - Fixed: send button wrapping below the input. Changed: composer spacing, attachment bubble, growing message field =
* Fixed: the send button no longer drops onto its own line on narrow devices. The composer is a wrapping flex row and the message field used flex:1, but min-width defaults to auto, so a form field refuses to shrink below its intrinsic width (about 180px for a default text input). The row therefore needed roughly 328px, while a 360px phone leaves only about 304px inside the popup panel, so the button wrapped. The field now sets min-width:0 and can shrink properly.
* Changed: composer spacing tightened -- gap 10px to 8px, padding 12px 16px to 10px 12px, and the paperclip button 40x40 to 36x36 with a 10px radius. Items align to flex-end so the buttons stay level with the bottom of the field as it grows.
* Changed: the selected-attachment chip now sits ABOVE the message field as a rounded bubble (order:-2) instead of below it, with the filename truncated by ellipsis.
* New: a x button inside the attachment bubble removes the pending file before sending. It clears the file input, the pending reference and the bubble.
* New: the message field is now a textarea that grows with the text up to 4 lines and then scrolls internally. Enter still sends; Shift+Enter inserts a newline. The height resets after each send.
* Fixed: draft preservation during polling was silently dead in the inbox -- composerSnapshot() and restoreComposer() queried ".zymarg-inbox__composer textarea", but the composer built an <input>. Converting the field to a textarea makes the existing draft-restore code work, so polling no longer discards what is being typed.
* Fixed: the attachment remove button and the reply-cancel button were being styled as 56x48 gradient send buttons, because ".zymarg-inbox__composer button" (specificity 0,1,1) outranked their single-class rules (0,1,0). Both are now scoped under .zymarg-inbox__composer.
* Applied to all three surfaces: buyer inbox, seller inbox and the live chat popup.
* UNCHANGED (deliberately): attachments, reactions, replies, typing indicator, read receipts and the swipe/long-press gestures. No database, REST or schema changes.

= 1.24.2 - Changed: reactions collapse to the latest one with a "+N" expander =
* Fixed: message bubbles no longer grow taller as reactions are added. Previously every distinct emoji rendered as its own pill inside the bubble, and .zymarg-inbox__reacts / .zymarg-live-chat__reacts used flex-wrap:wrap, so once the pills exceeded the bubble max-width (78% inbox / 82% popup) they wrapped onto extra rows and the bubble grew.
* Changed: by default only the most recent reaction is shown, followed by a "+N" hint on the right where N is the number of remaining reactions. Bubble height is now constant regardless of how many reactions a message receives.
* New: clicking the "+N" hint expands every reaction pill with its own count; the button becomes a minus sign to collapse again. The hint is hidden entirely when nothing is hidden (for example when many users pick the same emoji).
* The collapsed row uses flex-wrap:nowrap so it can never spill onto a second line, and the hint is pushed right with margin-left:auto.
* UNCHANGED (deliberately): reactions still save and toggle through the same /messages/{id}/react endpoints, the long-press gesture, the 8 marketplace default reactions and the "+" full emoji panel in the reaction bar all behave exactly as in 1.24.1. No database, REST or schema changes.

= 1.24.1 - Removed: composer emoji picker. Changed: marketplace default reactions =
* Removed: the emoji picker button next to the message box, on all three surfaces (buyer inbox, seller inbox, live chat popup). Modern phone and desktop keyboards already have an emoji key, so the extra button was redundant.
* Typed emoji are unaffected and fully supported: tables are created with $wpdb->get_charset_collate() (utf8mb4), the body column is LONGTEXT, SanitizeHelper::messageBody() uses wp_kses() which strips HTML tags but never Unicode characters, and the plugin never calls wp_encode_emoji()/wp_staticize_emoji(). Message bodies render through textContent.
* Removed the message.emoji_picker feature flag and its Communication > Settings toggle. Because the settings screen builds toggles from the flag definitions, no dead switch is left behind. Any existing zc_feature_flags row for the old key is simply ignored.
* Changed: default message reactions are now marketplace-oriented -- thumbs up, heart, check, package, delivery truck, hourglass, question mark and party popper (was thumbs up, heart, laughing, surprised, crying).
* New: a "+" button on the right of the reaction bar opens a full emoji panel, so any emoji can still be used as a reaction. Reactions cannot be typed from the keyboard, so the picker belongs here rather than on the message box.
* UNCHANGED (deliberately): image attachments (the paperclip), message reactions themselves, replies, read receipts, typing indicator, online status, swipe-to-reply and long-press-to-react. No REST route, table or schema changes; reaction emoji are still not restricted server-side.

= 1.24.0 =
* New: Per-user performance tab on the Analytics screen (Communication > Analytics > "Per user"). The existing platform-wide report is unchanged and remains the default view.
* Shows, for every person with messaging activity: messages sent, conversations, typical (median) reply time, reply rate, longest time they left someone waiting, and last active -- with plain-language suggestions such as "Very slow to reply", "Misses over half of incoming messages" or "Top performer".
* Buyer/seller filter defers to zymarg_os_user_is_vendor() from the Vendor Dashboard plugin, so the role shown always agrees with who can actually open the vendor dashboard. Dokan, role list and the dokandar capability are fallbacks.
* Metrics are derived from the zc_messages table, not from analytics events. This measures every turn in every conversation rather than only the first reply to a new conversation, and it works retroactively across the full message history. The existing event-based platform figures are untouched.
* Load safety: rendering the tab never queries the message table. The walk runs only on an explicit "Refresh now" or on an optional timer (Off / daily / twice daily / every 6 hours / hourly, selectable on the tab). Results are stored in a non-autoloaded option, so ordinary page loads and front-end visitors are completely unaffected. Setting the timer to Off means no background work happens at all.
* The reply-time walk uses keyset pagination on id (never OFFSET) and accumulates gaps into a fixed 12-bucket histogram, so memory stays flat regardless of message volume. No JSON_EXTRACT, so no MySQL version sensitivity.
* No database schema changes. Read-only: the feature never writes to messages, conversations or users.

= 1.23.0 =
* Fix (critical): Realtime push had never worked for any user. PusherService::credentials() read the Pusher app key and secret straight out of wp_options without decrypting them, but the Settings screen stores them encrypted (zc_enc_v1: prefix). Every private-channel signature was therefore signed with the ciphertext as the secret and stamped with the ciphertext as the key, and every server-side publish authenticated with the same garbage. Pusher rejected all of it, so every client sat at subscribed = false and no event was ever delivered. Credentials are now decrypted before use, matching what the admin Test Connection button already did.
* Why this went unnoticed: the admin 'Test Connection' button decrypts the credentials itself before calling testConnection(), so it reported a healthy green connection while the entire runtime path was dead. Messages were actually being delivered by the surface refresh timers -- roughly 1-4 seconds in the popup and up to 15 seconds in the inboxes -- which is why delivery felt instant sometimes and slow at other times.
* Fix: POST /realtime/auth returned the signature wrapped in the plugin's standard {success,data} envelope. Pusher's client cannot parse that shape and refuses the subscription. The endpoint now returns the bare {"auth":"key:sig"} body Pusher requires.
* Fix: connectPusher() had no failure path. If a subscription was refused or the socket never opened, the client was left permanently dead with no fallback and no warning, and surfaces silently degraded to their slow refresh timers. A refused subscription, a failed connection or an unavailable connection now falls back to polling and logs a console warning.
* Pusher's own lifecycle events (pusher:*) are no longer forwarded to surface listeners as if they were application events.
* Missed-event replay now also runs on pusher:subscription_succeeded, so events published while the channel was still being authorised are not lost.

= 1.21.0 =
* Fix: Opening a conversation left the newest message hidden behind the composer. renderThread() ran `msgs.scrollTop = msgs.scrollHeight` BEFORE `threadEl.appendChild(form)`, so the scroll was measured against a message box that still included the composer's height. Appending the composer then shrank the box, leaving the view short by exactly the height of the input row. The scroll now happens after the composer is in the DOM.
* Fix: The scroll is re-applied on the next two animation frames, at 60/200/500ms, and as each avatar or attachment image finishes loading, so late layout shifts cannot leave the view parked above the newest message. Every re-apply aborts instantly if the reader has scrolled up.
* Added: Load-on-scroll history in all three surfaces (buyer inbox, vendor inbox, live-chat popup). Scrolling to the top of the message box pulls in the previous 30 messages and holds the reader's position instead of jumping. Repeats until the beginning of the conversation.
* The live-chat popup no longer yanks the view to the bottom on every 15-second refresh; it only follows the conversation when the reader is already at the bottom.
* Polling now merges into the loaded history rather than replacing it, so earlier messages pulled in by scrolling survive each refresh.

= 1.20.0 =
* Fix (major): The message pane stopped showing new messages in EVERY thread view -- buyer inbox, vendor inbox and the live-chat popup. MessageRepository::findForConversation() orders by created_at ASC, and GET /conversations/{id}/messages defaulted to offset 0, so the endpoint always returned the OLDEST 30 messages. Once a conversation grew past 30 messages the newest ones fell permanently outside that window: the pane froze while the conversation list kept showing new previews, because the list fetches the latest message separately for its preview text.
* Added MessageService::listLatestForConversation(), which anchors the window to the end of the conversation (offset = total - limit) while keeping chronological order.
* MessageController::index() now inspects the raw query string to tell "no offset requested" apart from "offset=0". Callers that pass an explicit offset keep the original paging behaviour, so nothing that relies on paging changes.

= 1.19.0 =
* Removed: The "New message" jump chip added in 1.18.0. It was never requested. The inbox keeps the quiet scrolling behaviour: no animation, no jumping when you are reading back through history.
* Fix: The auto-opened popup showed an empty chat box. refreshUnread() called selectLatestConversation().then(openPanel), which opened the panel whether or not a conversation had actually been resolved, and every failure inside that function was swallowed by a bare .catch(). openPanel() then skipped loading messages because activeConversationId was still null. The popup now opens only once a conversation id is resolved.
* Fix: Messages typed into the popup were silently discarded. The submit handler began with `if ((!text && !pendingFile) || !activeConversationId) return;` -- with no conversation resolved it dropped the message without any error. It now recovers by resolving the conversation first, and logs a console warning if it genuinely cannot send.
* Fix: selectLatestConversation() now coerces the conversation id to an integer and tolerates alternative response shapes, instead of assigning whatever it found and hoping.
* Fix: live-chat.js now refuses to boot twice on one page. A duplicate enqueue previously produced two rival instances sharing one DOM with separate conversation state, so one would blank out what the other rendered.
* Added: window.zymargLiveChat.debug() reports autoOpen, conversation id, panel state and rendered bubble count for quick diagnosis from the browser console.
* Changed: The three silent .catch() blocks in the popup's conversation, message and send paths now emit console warnings. They previously hid every failure completely.

= 1.18.0 =
* Fix: The message area no longer scrolls for no reason. The thread had scroll-behavior:smooth, renderThread() force-scrolled to the bottom on every redraw, and the 15s poll then restored the reader's position -- so each new message produced a visible glide down to the bottom and back up again. The smooth animation has been removed so position changes are instant and invisible.
* Fix: The typing indicator force-scrolled the reader to the bottom every time the other party started typing, regardless of where they were reading. It now only follows along if the reader was already at the bottom.
* Added: A "New message" chip appears when a message arrives while the reader has scrolled up, instead of moving them. Tapping it jumps to the newest message; it hides itself once the reader returns to the bottom.
* Added: Popup auto-open is now opt-in per page. Communication -> Settings -> General gains a master toggle plus a checkbox list of pages where the popup may open by itself. Defaults to OFF, so no site inherits the previous open-everywhere behaviour.
* Note: The auto-open behaviour itself is not new -- it shipped long ago but never actually fired, because the unread poll targeted a route that did not exist. Repairing that route in 1.17.0 made it visible for the first time.
* Implemented PopupSettingsService, previously an empty "TODO: implement" stub. Exposes the zymarg_comm_popup_autoopen_allowed filter for programmatic overrides.

= 1.17.0 =
* Fix: Buyer inbox never rendered on the theme My Account "Messages" section. BuyerInbox::renderAccountSection() returned its markup, but the zymarg-os theme invokes the section render_cb with call_user_func() and discards the return value, so the panel was always empty and inbox.js had no root to hydrate. The callback now echoes.
* Fix: Inbox had no live refresh. realtime.js is never enqueued, so the realtime bridge never fired and new messages only appeared on a click or reload. Added a 15s polling loop (matching live-chat.js) that re-renders only when the thread actually changed, preserves composer text/caret, and keeps scroll position if the reader scrolled up.
* Fix: Inbox grew vertically instead of scrolling. .zymarg-inbox height:100% collapsed to auto inside the theme's section panel; added max-height:min(78vh,820px).
* Fix: Admin feature-flag toggles always rendered OFF and could never save. AdminSettingsPage/AdminMenu read snake_case properties (flag_key/is_enabled/is_locked) that do not exist on the FeatureFlag model (flagKey/isEnabled/isLocked).
* Fix: Feature-flag AJAX save mangled every key. sanitize_key() strips dots, turning "surface.buyer_inbox" into "surfacebuyer_inbox"; now matches the REST pattern [a-z0-9._-].
* Fix: Feature-flag AJAX save bypassed FeatureFlagService, leaving the flag cache stale for up to 5 minutes and skipping the locked-flag check. Now routed through the service.
* Fix: live-chat.js polled GET /notifications/unread every 15s, which has never been a registered route (404 flood). Now uses GET /marketplace/unread-count, restoring the unread badge and new-message popup surfacing.

= 1.16.0 =
* Changed - All inline style attributes converted to brand tokens; no hardcoded colours remain in the admin.
* Changed - Analytics stat colour and chart gradient moved off the legacy purple.
* Changed - Settings toggle green and status colours now use the brand semantic tokens.
* Note - The admin rebrand is complete as of this release.

= 1.15.0 =
* Added - ZYMARG brand admin header on all six pages: Discovery Spark, purple wordmark, gradient strip.
* Added - Version badge, right-aligned in the header.
* Added - assets/css/admin/spark.css, the canonical Discovery Spark animation.
* Changed - All six WordPress loading spinners replaced with the Discovery Spark loading component.
* Note - Inline style attributes are not yet rebranded.

= 1.14.2 =
* Fixed - Settings and Dashboard were missing the zcm-admin-page class, so no admin styling applied to them.

= 1.14.1 =
* Fixed - Admin text now uses brand colours; the shell sets a base colour so all copy inherits it.
* Added - --zc-color-ink (#36003D) for headings and emphasis, matching the brand text roles.
* Fixed - --zc-color-text-body corrected to #534152 (body copy); it was wrongly set to the ink colour.
* Added - Brand styling for h2-h4, paragraphs, lists, labels, strong and links.

= 1.14.0 =
* Added - Brand tokens are now loaded in wp-admin; admin.css depends on them.
* Added - Admin surface tokens: divider, neutral, success/warning/error backgrounds, control radius, button shadows, focus ring.
* Changed - admin.css rebuilt on tokens; no hardcoded colours remain.
* Changed - All six admin <style> blocks converted to brand tokens.
* Changed - inbox.css converted from hardcoded hex to brand tokens.
* Note - Inline style attributes are not yet rebranded.

= 1.13.0 =
* Changed - Design tokens rebranded to the ZYMARG brand primary #9500A5 (was #6833EA).
* Changed - Status colours now follow the brand: success #1A7F37, warning #ED8936, error #B3261E.
* Changed - Shadows and the focus ring recoloured from the legacy purple.
* Changed - Admin tab styling updated to the brand purple.
* Note - Inline styles inside admin page templates are not yet rebranded.

= 1.12.44 =
* Removed the always-visible reaction and reply buttons under each message bubble to reclaim vertical space; bubbles are now cleaner.
* Added swipe-to-reply: swipe a bubble toward its own side (incoming = swipe right, your own = swipe left) to reply, with a live drag hint -- just like Messenger and WhatsApp.
* Added long-press-to-react: press and hold a bubble to open the quick reaction picker. Existing reactions still show as pills below the bubble.

= 1.12.43 =
* Realtime R3+R4: inbox and My Account popup now update instantly over Pusher -- new messages, typing indicators, and presence are pushed to each recipient private user channel; polling is retained as an automatic fallback.
* Fixed the typing publish that previously went to an unsubscribed conversation channel with recipient 0, so it never reached anyone.
* Heartbeat now reports the actively viewed conversation so the counterpart "Active now" status flips in real time.

= 1.12.42 =
* Realtime R2 (Pusher SDK): The official Pusher JS SDK is now loaded from its CDN for logged-in users whenever Pusher is the active, configured realtime driver, and the realtime client is set to depend on it. Previously realtime.js could never find the Pusher library, so it silently fell back to REST polling. Loads only when the driver is "pusher" and credentials are set. Next: UI wiring (R3) so the inbox and popup consume these live events.

= 1.12.41 =
* Realtime R1 (backend publish fix): New messages are now actually broadcast to the realtime driver (Pusher). Fixed an event-name mismatch (the realtime listener used "message.sent" with a dot while the dispatcher fires "message_sent") that silently prevented every message, conversation, and participant event from ever reaching the driver. Events are now published to each recipient's private user channel (the channel the client subscribes to). This is the foundation for true Pusher-backed realtime; the frontend still needs the Pusher SDK loaded (R2) and UI wiring (R3) to consume it.

= 1.12.40 =
* Polish: Composer inputs and send buttons settle to a 44px height on wider ( >= 768px ) viewports for a tighter desktop rhythm, matching the design spec.
* Polish: The storefront chat popup header now has an "Open full inbox" button that links to the buyer's My Account Messages page (filterable via the "zymarg_comm_inbox_url" filter).
* Polish: Unread badges (launcher, browser tab title, and in-page counters) now show the exact unread total instead of capping the display at "99+".

= 1.12.39 =
* Feature: Online/presence status. The buyer/vendor inbox thread header and the storefront popup header now show whether the other participant is "Active now" (with a green dot) or their "Last seen" relative time. Presence is driven by the realtime heartbeat store (60s TTL) with the messaging UI pinging a heartbeat every 30s and reading the counterpart's status every 30s, so it is near-real-time and requires no external websocket driver. Gated by the "Online status" feature flag.

= 1.12.38 =
* Feature: Typing indicator. While the other participant is composing a reply you now see an animated "typing" indicator (a dotted bubble in the buyer/vendor inbox, a "Typing…" line in the storefront popup). Implemented over the realtime presence store with short-interval polling (~3s), so it is near-real-time rather than instantaneous, and it does not require an external websocket driver. Gated by the "Typing indicator" feature flag.

= 1.12.37 =
* Feature: Emoji picker in the composer. Tap the emoji (☺) button next to the message input to open a categorized popover (Smileys, Gestures, Hearts, Shopping); selecting an emoji inserts it at the cursor position in the message you are typing. Available in both the storefront popup and the buyer/vendor inbox, gated by the "Emoji picker" feature flag.

= 1.12.36 =
* Feature: Reply to a message. Hover a message and tap the reply (↩) button to quote it; the composer shows a cancellable preview of the message you are replying to, and sent replies render a compact quoted snippet above the body. Works in both the storefront popup and the buyer/vendor inbox, gated by the "Reply to message" feature flag.

= 1.12.35 =
* Feature: Message reactions. Hover a message and tap the reaction button to add an emoji (👍 ❤️ 😂 😮 😢); reaction pills show counts and your own reactions are highlighted. Tap a pill to toggle your reaction. Available in both the storefront popup and the buyer/vendor inbox, gated by the "Message reactions" feature flag.
= 1.12.34 =
* Improvement: The attachment (paperclip) button now respects the "Image attachments" feature flag. When an admin disables attachments in Settings, the paperclip is hidden in both the inbox composer and the storefront popup instead of showing a button that would fail on upload.

= 1.12.33 =
* Feature: Image & file attachments — a paperclip button in both the inbox composer and the storefront popup lets you attach an image (or file) to a message. Sent images render as inline thumbnails; other files show as a downloadable link. Backend now surfaces each message's attachments (with public URLs) in the message payload.

= 1.12.32 =
* Feature: Conversation actions menu ('â¯') on each inbox row â Archive a conversation or Report it to moderators.
* Feature: Browser tab now shows an unread badge, e.g. "(3) My Account", updated as messages arrive and clear.
* Feature: Keyboard shortcuts â Ctrl/Cmd+Enter sends from the inbox composer; Escape closes the storefront popup.

= 1.12.31 =
* Feature: Delivery + read receipts are now visible in the UI on both the storefront popup and the buyer/vendor inbox. Your own messages show WhatsApp-style ticks (single = sending, double = delivered, coloured #FEA9FF double = read).
* Fix: Opening a conversation now correctly marks incoming messages as read. The frontend was calling POST /read with an empty body; it now sends PATCH /conversations/{id}/read with the required before_message_id. The storefront popup now also marks messages read on open (previously it never did).

= 1.12.30 =
* Design: Match the composer to the approved chat mockup on both the storefront popup and the buyer/vendor inbox. The message field is now a single-line input (height 48px, 14px radius, subtle input shadow, Enter sends) and the Send button is the icon-only pill (arrow glyph, 2px #FEA9FF accent border, gradient fill). CSS + markup only; no REST/messaging behaviour changed.

= 1.12.29 =
* Fix: In the storefront chat popup, your own sent messages now align to the right (receiver messages stay on the left). wp_localize_script casts userId to a string, so the strict sender_id === userId comparison always failed and every bubble rendered left; both live-chat.js and inbox.js now compare numerically.

= 1.12.28 =
* Fix: Buyer and vendor message threads were empty and messages sent from the storefront popup were invisible. The REST endpoints wrap results as {data:{conversations:[...]}} and {data:{messages:[...]}}, but the frontend read data as the array directly, so nothing rendered. live-chat.js and inbox.js now unwrap .conversations/.messages and use sender_id (not author_id) to mark own messages.
* Improve: Conversation list responses now include a title (counterpart name), a last-message preview, and an unread indicator so inbox rows are meaningful.

= 1.12.27 =
* Fix: Buyer (My Account) inbox now hydrates reliably after SPA section swaps. The ZYMARG OS theme swaps account sections via innerHTML without dispatching any event, so a navigation-triggered re-scan fallback (click + popstate) was added alongside the MutationObserver. The vendor dashboard uses its zymarg-vd:section-loaded / zymarg:section:swapped events.

= 1.12.26 =
* Fix: Storefront "Chat" buttons ([data-chat-btn]) now open the popup â added document-level click delegation and openWithSeller() (POST /marketplace/store-chat) in live-chat.js, with a warm auto-greeting for brand-new store conversations.
* Fix: Buyer + vendor inbox now hydrate on client-side section swaps (no reload needed) by also listening for the host SPA events zymarg-vd:section-loaded and zymarg:section:swapped, in addition to the existing MutationObserver.

= 1.12.25 =
* Design: Harmonized the buyer (My Account) and vendor (Dashboard) inbox with the host ZYMARG OS theme and Vendor Dashboard design tokens (brand colours, gradient, 18px card radius, soft shadow, Inter/Sora typography) so the messenger matches the surrounding UI and inherits Customizer + dark mode. Popup (live chat) unchanged.

= 1.12.24 =
* Fixed the buyer inbox (My Account > Messages) and vendor inbox rendering completely blank. Both were gated on feature-flag keys that were never defined (marketplace.buyer_inbox / marketplace.vendor_inbox); corrected them to the real, default-on flags surface.buyer_inbox / surface.vendor_inbox.

= 1.12.23 =
* Storefront "Chat" buttons now open the chat popup. Any [data-chat-btn] element (such as the two Chat buttons on the ZYMARG Store Page) opens the popup on the buyer/seller conversation when clicked.
* Added the get-or-create store-chat endpoint (POST /marketplace/store-chat) so repeat clicks reuse the existing buyer/seller thread instead of creating duplicates.
* First-time chats with a seller pre-fill an editable greeting ("Hi {vendor name}...", with a name-safe fallback); existing threads open without altering any draft.

= 1.12.22 =
* Live-chat launcher icon is now never displayed. The popup panel surfaces on its own only when a new message arrives; the persistent full messaging UI remains on the buyer My Account and seller inbox pages.

= 1.12.21 =
* Re-skinned the buyer (My Account) and vendor/seller inboxes to the brand two-pane messenger design: gradient accent bar, gradient avatars, active-conversation accent, gradient outgoing bubbles, pill filters, and gradient send button.
* Fixed undefined component CSS variables (--zc-accent, --zc-bg, --zc-border, etc.) that previously fell back to generic black/white; mapped them to the canonical brand tokens in both zymarg-comm-tokens.css and DesignTokens.php.
* Live-chat popup no longer shows a persistent launcher icon. A background poll surfaces the popup automatically only when a new message arrives (opening the newest unread conversation); the launcher is shown only while unread messages exist or the panel is open.
* Re-skinned the live-chat popup to match the brand design.

= 1.11.0 =
* Phase 11: QA & Hardening. Unit test scaffolds for FeatureFlagService, ApiKeyService, ChangelogService, DesignTokens, and FlagRegistry.
* Phase 11: Integration test scaffolds for REST route registration, invalid-bearer 401 rejection, the public PHP API facade, and the moderation pipeline.
* Phase 11: PHPUnit, PHPStan (level 5), and PHPCS (WordPress-Extra) configuration files added at phpunit.xml.dist, phpstan.neon.dist, phpcs.xml.dist.
* Phase 11: Composer dev-dependencies declared (phpunit ^9.6, phpstan ^1.10, php_codesniffer ^3.7, wpcs ^3.0). Convenience scripts: composer test, test:unit, test:integration, analyse, lint.
* Phase 11: Security checklist recorded at docs/qa/security-checklist.md.
* Phase 11: Verified no console.log, var_dump, print_r, or error_log occurrences in production sources.

= 1.10.0 =
* Phase 10: Built-in Help & Docs admin submenu under Communication. Renders User Guide, Admin Guide, REST API, PHP API, JS SDK, Hooks & Filters, Extension SDK, Mobile Integration, Troubleshooting, and Changelog sections.
* Phase 10: Changelog viewer reads directly from readme.txt via ChangelogService.
* Phase 10: Full internationalization (i18n) surface. Every user-facing string flows through __() / esc_html__() with the zymarg-communication text domain.
* Phase 10: Bangla translation scaffolded at languages/zymarg-communication-bn_BD.po plus a generated zymarg-communication.pot template.

= 1.9.0 =
* Phase 9: Developer Platform. Public PHP API facade `ZymargComm::messages()->send()`, `ZymargComm::conversations()`, `ZymargComm::events()->on()/fire()`, `ZymargComm::notifications()`, `ZymargComm::flags()`, `ZymargComm::extensions()`.
* Phase 9: JavaScript SDK at `assets/js/frontend/sdk.js`, exposed as `window.ZymargComm`. All methods return Promises. Automatically enqueued on the frontend with a REST nonce and current user id.
* Phase 9: `Authorization: Bearer zc_...` API-key authentication for REST. Invalid or revoked keys are rejected with `401 invalid_api_key` before any permission callback runs.
* Phase 9: Global `ZymargComm` class alias so extensions can call the public API without a `use` statement.

= 1.8.0 =
* Phase 8: HelpCenter module. Serves the user guide and admin guide from /docs/guides/, developer documentation from /docs/api/, changelog from readme.txt, and FAQ CRUD via WordPress options.
* Phase 8: Developer module. Webhook registration and HMAC-signed dispatch on message_sent, conversation_created, conversation_closed, participant_joined, attachment_uploaded, moderation_reported, moderation_resolved.
* Phase 8: API keys (hashed at rest with SHA-256, raw key returned exactly once) and third-party extension registration via zymarg_comm_extension_registered.
* Adds developer.webhooks, developer.api_keys, developer.extensions, and help_center.* feature flags (all on by default).
* New database tables: zc_webhooks, zc_api_keys.

= 1.7.0 =
* Phase 7: Analytics module. Records events from every module (message_sent, conversation_created, moderation_reported, spam_detected, and more) into zc_analytics_events.
* Admin dashboard endpoint GET /analytics/admin â totals, response times, response rate, daily series, pending moderation count.
* Per-user dashboard endpoint GET /analytics/me â scoped strictly to the current user.
* Adds analytics.tracking feature flag (on by default) so recording can be disabled without redeploying.


= 1.6.0 =
* Security module: file validation (magic bytes + MIME + allowlist for jpg/jpeg/png/webp), EXIF strip, randomized storage filenames, secure file storage with .htaccess/index.html execution guard.
* EncryptionService: AES-256-CBC around a WordPress salt-derived key; used for Pusher credentials.
* AuditLogService: silent, never-throwing writes to zc_audit_logs for all admin actions.
* Moderation module: BlocklistService (blocked words + blocked users) and SpamFilterService, both wired into MessageService before storage.
* AdminViewService: the only stealth-read entry point for admin conversation access â no read receipts, no notifications, no last_read_at updates. Every access is audited.
* Reporting a conversation flips its status to reported and files a moderation_logs entry.
* Settings module rebuilt: Pusher credentials stored encrypted; GET /settings only returns is_configured booleans; POST /settings/pusher/test returns connected|partial|failed.

= 1.5.0 =
* Notification module: email (wp_mail), mobile push (webhook), browser Web Push, and in-app.
* Per-user notification preferences (user_meta) with quiet hours enforcement.
* Recipient online-state gating via PresenceService â no duplicate delivery when the user is already connected in realtime.
* REST endpoints: /notifications, /notifications/{id}/read, /notifications/read-all, /notifications/preferences.
* NotificationHooks bridges message.sent, conversation.created, participant.joined events to the dispatcher.

= 1.4.0 =
* Marketplace module: buyer inbox, vendor inbox, store-page popup, product sharing, order chat.
* Shared chatbox component enforcing UI parity between buyer and seller.
* Design tokens (CSS + PHP) formalised per two-file rule.
* REST endpoints: /marketplace/product-share, /marketplace/order-chat, /marketplace/context, /marketplace/unread-count.
* Shortcodes now render real content on /messages/, /vendor-messages/, and via [zymarg_comm_popup], [zymarg_comm_chat], [zymarg_comm_unread_count].

= 1.3.0 =
* Realtime engine: Pusher (default), WebSocket, SSE, and Polling drivers behind a single RealtimeDriverInterface.
* Presence: online status + typing indicators via PresenceService, driven by short-lived transients.
* Reliability: QueueService stores realtime events per recipient and replays on reconnect.
* REST: /realtime/token, /realtime/poll, /realtime/typing, /realtime/heartbeat.
* Frontend: assets/js/frontend/realtime.js client with pluggable driver + reconnect + polling fallback.
* Bootstrap: Communication admin menu registered from the zymarg_comm_admin_menu_label option.

= 1.2.0 =
* Phase 2 â Conversation & Message Core.
* FeatureFlags module: Definitions, FlagRegistry, FeatureFlagService, FeatureFlagCacheService, REST endpoints (/flags, /flags/public, PATCH /flags/{key}).
* Conversation module: create, list, view, archive, pin, permission service (BuyerâSeller allowed, SellerâBuyer pending approval), participant management.
* Message module: send, edit, delete, react/un-react, read receipts.
* Shared: EventDispatcher plus MessageSent, ConversationCreated, ConversationClosed, ParticipantJoined events.
* Http middleware: Auth, Nonce, RateLimit; standardized ApiResponse and ErrorResponse envelopes.
* REST namespace: zymarg-comm/v1.

= 1.1.0 =
* Phase 1 â Foundation.
* Bootstrap sequence: Plugin, ServiceProvider, HookLoader, Compatibility, ShortcodeRegistrar, Scheduler, Updater.
* Installer creates every `zc_*` database table via versioned migrations.
* Installer writes every feature flag with its default state to `zc_feature_flags`.
* PageRegistrar creates plugin-owned pages: `/messages/` and `/vendor-messages/`.
* Uninstaller drops all plugin tables, deletes all plugin options, and removes plugin-owned pages.
* PSR-4 fallback autoloader so the plugin activates without `composer install`.

= 1.0.0 =
* Initial architecture scaffold.

== 1.12.14 =
* Improvement: Communication dashboard now shows live stats (conversations, messages, pending moderation, feature flags), system status (Pusher config, PHP/WP versions, OpenSSL), and quick action buttons.

= 1.12.13 =
* Improvement: Admin sidebar links between plugin pages (Communication, Settings, Help) now load instantly via AJAX with no page reload. Back/forward browser buttons work correctly.

= 1.12.12 =
* Improvement: Entire admin side is now fully AJAX. Tab/section switching on Settings and Help pages loads content instantly without any page reload. AdminMenu dashboard updated with quick-access buttons.

= 1.12.11 =
* Improvement: Settings page is now fully AJAX â no page reloads on save.
* Fix: Secret field stays fully hidden (shows only Saved status, no partial reveal).
* Fix: App ID shows in full, Key shows first 8 chars masked, below each field inside the cell.

= 1.12.10 =
* Fix: Current App ID and Key now display inside the table cell below the input field using WordPress description style.

= 1.12.9 =
* Fix: Settings Realtime tab now shows the current App ID in full and Key partially masked (first 8 chars visible). Secret stays hidden for security.

= 1.12.8 =
* Fix: Test Pusher Connection button now reads stored (encrypted) credentials server-side via admin-ajax instead of sending empty params to REST endpoint.

= 1.12.7 =
* Fix: Corrected ap1 cluster label to Singapore (not Mumbai).

= 1.12.6 =
* Fix: Added ap1 (Mumbai) cluster to Pusher settings dropdown.

= 1.12.5 =
* Fix: Pusher credentials now saved correctly. Bypassed ServiceProvider in admin-post handler; writes directly to SettingsRepository + EncryptionService to avoid service-container timing issues.

= 1.12.4 =
* Add: Full admin Settings page with General, Realtime (Pusher), and Feature Flags tabs. Flags toggle instantly with no page reload. Pusher Test Connection button included.

= 1.12.3 =
* Add: Full Help & Docs content for all 10 sections (User Guide, Admin Guide, REST API, PHP API, JS SDK, Hooks & Filters, Extension SDK, Mobile Integration, Troubleshooting, Changelog).
* Fix: Services used wrong constant ZYMARG_COMM_PLUGIN_DIR; corrected to ZYMARG_COMM_DIR so docs files are found.

= 1.12.2 =
* Fix: RestController::queue() call in MarketplaceHooks replaced with RestController::register().

= 1.12.1 =
* Fix: `HookableInterface::register()` declared as instance method conflicted with static implementations in every module Hooks class, causing E_COMPILE_ERROR on activation. Interface now correctly declares the method as static.

= 1.12.0 ==
* Frontend surfaces shipped. Real renderers for buyer inbox, vendor inbox, and floating live-chat widget replace the Phase 1-11 placeholders.
* Ecosystem integration for the ZYMARG theme + ZYMARG Vendor Dashboard plugin: hooks into `zymarg_os_account_sections` (buyer Messages section in My Account) and `zymarg_os_vendor_render_section` (vendor Messages panel).
* New CSS class names align with the theme/vendor plugin contract: `zymarg-inbox`, `zymarg-live-chat`. JS bootstrap global is `zymargLiveChat`.
* Shortcodes: `[zymarg_my_messages]`, `[zymarg_vendor_messages]`, `[zymarg_live_chat]`, `[zymarg_unread_count]`. Legacy `[zymarg_comm_*]` shortcodes kept as aliases.
* Fallback marketplace injections for WooCommerce, Dokan, WCFM, and WC Vendors when the ZYMARG theme/vendor plugin are not active.
* Central asset enqueue via `Frontend\AssetEnqueue`. Duplicate popup footer wiring removed from MarketplaceHooks.
