<?php
/**
 * ZYMARG Communication — Uninstall
 *
 * Fired when the plugin is deleted from the WordPress admin.
 *
 * @package ZymargCommunication
 */

// WordPress uninstall guard.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// Manually bootstrap the autoloader — WordPress does not load the main plugin
// file when running uninstall.php.
require_once __DIR__ . '/zymarg-communication.php';

\ZymargCommunication\Bootstrap\Uninstaller::run();
