<?php
/**
 * ZYMARG Communication — Public PHP API.
 *
 * Fluent facade over the plugin's internal Services. Third-party plugins
 * MUST use these entry points and never call Service classes directly.
 *
 *     ZymargComm::messages()->send( $conversationId, $senderId, $body );
 *     ZymargComm::conversations()->getForUser( $userId );
 *     ZymargComm::events()->on( 'message_sent', $callback );
 *     ZymargComm::flags()->isEnabled( 'developer.webhooks' );
 *
 * @package    ZymargCommunication
 * @version    1.9.0
 */

namespace ZymargCommunication\Api;

use ZymargCommunication\Bootstrap\ServiceProvider;
use ZymargCommunication\Modules\Conversation\Services\ConversationService;
use ZymargCommunication\Modules\Developer\Services\ExtensionService;
use ZymargCommunication\Modules\FeatureFlags\Services\FeatureFlagService;
use ZymargCommunication\Modules\Message\Services\MessageService;
use ZymargCommunication\Modules\Notification\Services\NotificationService;
use ZymargCommunication\Shared\Events\EventDispatcher;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PhpApi is the routing hub. The class-level static methods return small
 * accessor objects (below) that expose the sanctioned public surface.
 */
final class PhpApi {

	private static ?ConversationsApi $conversations = null;
	private static ?MessagesApi $messages           = null;
	private static ?NotificationsApi $notifications = null;
	private static ?EventsApi $events               = null;
	private static ?FlagsApi $flags                 = null;
	private static ?ExtensionsApi $extensions       = null;

	public static function conversations(): ConversationsApi {
		return self::$conversations ??= new ConversationsApi();
	}

	public static function messages(): MessagesApi {
		return self::$messages ??= new MessagesApi();
	}

	public static function notifications(): NotificationsApi {
		return self::$notifications ??= new NotificationsApi();
	}

	public static function events(): EventsApi {
		return self::$events ??= new EventsApi();
	}

	public static function flags(): FlagsApi {
		return self::$flags ??= new FlagsApi();
	}

	public static function extensions(): ExtensionsApi {
		return self::$extensions ??= new ExtensionsApi();
	}

	/** Version of the public API. Semver-tracked separately from plugin version. */
	public static function version(): string {
		return '1.0';
	}
}

// ─────────────────────────────────────────────────────────────────────────────
// Fluent facade accessors. Each one resolves its Service lazily.
// ─────────────────────────────────────────────────────────────────────────────

final class ConversationsApi {

	private function service(): ConversationService {
		return ServiceProvider::get( ConversationService::class );
	}

	public function getForUser( int $user_id, int $limit = 20, int $offset = 0 ): array {
		return $this->service()->listForUser( $user_id, $limit, $offset );
	}

	public function view( int $conversation_id, int $user_id ): array {
		return $this->service()->view( $conversation_id, $user_id );
	}

	public function create( array $args ): array {
		$initiator_id = (int) ( $args['initiator_id'] ?? get_current_user_id() );
		$recipient_id = (int) ( $args['recipient_id'] ?? 0 );
		$context_type = isset( $args['context_type'] ) ? (string) $args['context_type'] : null;
		$context_id   = isset( $args['context_id'] ) ? (int) $args['context_id'] : null;

		return $this->service()->create( $initiator_id, $recipient_id, $context_type, $context_id );
	}

	public function archive( int $conversation_id, int $user_id ): bool {
		return $this->service()->archive( $conversation_id, $user_id );
	}

	public function pin( int $conversation_id, int $user_id, bool $pinned = true ): bool {
		return $this->service()->pin( $conversation_id, $user_id, $pinned );
	}
}

final class MessagesApi {

	private function service(): MessageService {
		return ServiceProvider::get( MessageService::class );
	}

	public function send( int $conversation_id, int $sender_id, string $body, ?int $parent_id = null ): array {
		return $this->service()->send( $conversation_id, $sender_id, $body, $parent_id );
	}

	public function getForConversation( int $conversation_id, int $user_id, int $limit = 30, int $offset = 0 ): array {
		return $this->service()->listForConversation( $conversation_id, $user_id, $limit, $offset );
	}

	public function edit( int $message_id, int $editor_id, string $body ): array {
		return $this->service()->edit( $message_id, $editor_id, $body );
	}

	public function delete( int $message_id, int $actor_id ): bool {
		return $this->service()->delete( $message_id, $actor_id );
	}
}

final class NotificationsApi {

	private function service(): NotificationService {
		return ServiceProvider::get( NotificationService::class );
	}

	public function send( int $user_id, string $type, array $payload = array() ): array {
		return $this->service()->dispatch( $user_id, $type, $payload );
	}
}

final class EventsApi {

	private function dispatcher(): EventDispatcher {
		return ServiceProvider::get( EventDispatcher::class );
	}

	public function on( string $event, callable $callback ): void {
		$this->dispatcher()->on( $event, $callback );
	}

	public function fire( string $event, array $payload = array() ): void {
		$this->dispatcher()->fire( $event, $payload );
	}
}

final class FlagsApi {

	private function service(): FeatureFlagService {
		return ServiceProvider::get( FeatureFlagService::class );
	}

	public function isEnabled( string $flag_key ): bool {
		return $this->service()->isEnabled( $flag_key );
	}

	public function enable( string $flag_key ): bool {
		return $this->service()->enable( $flag_key );
	}

	public function disable( string $flag_key ): bool {
		return $this->service()->disable( $flag_key );
	}

	public function getAll(): array {
		return $this->service()->getAll();
	}
}

final class ExtensionsApi {

	private function service(): ExtensionService {
		return ServiceProvider::get( ExtensionService::class );
	}

	public function register( string $slug, array $manifest ): void {
		$this->service()->register( $slug, $manifest );
	}

	public function all(): array {
		return $this->service()->list();
	}

	public function find( string $slug ): ?array {
		return $this->service()->find( $slug );
	}
}
