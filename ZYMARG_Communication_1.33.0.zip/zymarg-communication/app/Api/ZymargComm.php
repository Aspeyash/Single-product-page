<?php
/**
 * Root-namespaced convenience alias for the public PHP API.
 *
 *     use ZymargCommunication\Api\ZymargComm;
 *     ZymargComm::messages()->send( $cid, $uid, 'hi' );
 *
 * `ZymargComm` (unqualified) is also registered as a global alias by the
 * Bootstrap so plugins can call `ZymargComm::messages()->send(...)` without
 * a use statement.
 *
 * @package    ZymargCommunication
 * @version    1.9.0
 */

namespace ZymargCommunication\Api;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ZymargComm extends PhpApi {}
