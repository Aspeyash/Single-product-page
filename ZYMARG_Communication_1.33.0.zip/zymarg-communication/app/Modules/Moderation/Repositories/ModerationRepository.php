<?php
/**
 * All database reads and writes for the `zc_moderation_logs` table.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Moderation\Repositories;

use ZymargCommunication\Core\Abstracts\AbstractRepository;
use ZymargCommunication\Modules\Moderation\Models\ModerationLog;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ModerationRepository extends AbstractRepository {

	protected function tableSuffix(): string {
		return 'zc_moderation_logs';
	}

	public function findModel( int $id ): ?ModerationLog {
		$row = $this->find( $id );
		return $row ? ModerationLog::fromRow( $row ) : null;
	}

	public function create( array $data ): int {
		$now = current_time( 'mysql', true );
		return $this->insert(
			array(
				'conversation_id' => (int) $data['conversation_id'],
				'reporter_id'     => isset( $data['reporter_id'] ) ? (int) $data['reporter_id'] : null,
				'moderator_id'    => isset( $data['moderator_id'] ) ? (int) $data['moderator_id'] : null,
				'type'            => (string) $data['type'],
				'status'          => isset( $data['status'] ) ? (string) $data['status'] : 'pending',
				'notes'           => isset( $data['notes'] ) ? (string) $data['notes'] : null,
				'created_at'      => $now,
				'updated_at'      => $now,
			)
		);
	}

	public function updateStatus( int $id, string $status, ?int $moderator_id = null, ?string $notes = null ): bool {
		$data = array(
			'status'     => $status,
			'updated_at' => current_time( 'mysql', true ),
		);
		if ( null !== $moderator_id ) {
			$data['moderator_id'] = $moderator_id;
		}
		if ( null !== $notes ) {
			$data['notes'] = $notes;
		}
		return $this->update( $id, $data );
	}

	/** @return array<int, ModerationLog> */
	public function queue( ?string $status = null, int $limit = 50, int $offset = 0 ): array {
		$sql = 'SELECT * FROM `' . $this->table() . '`';
		$args = array();
		if ( null !== $status ) {
			$sql .= ' WHERE status = %s';
			$args[] = $status;
		}
		$sql .= ' ORDER BY created_at DESC LIMIT %d OFFSET %d';
		$args[] = $limit;
		$args[] = $offset;

		$rows = $args
			? $this->wpdb->get_results( $this->wpdb->prepare( $sql, ...$args ) )
			: $this->wpdb->get_results( $sql );
		if ( ! is_array( $rows ) ) {
			return array();
		}
		return array_map( array( ModerationLog::class, 'fromRow' ), $rows );
	}

	public function countPending(): int {
		return (int) $this->wpdb->get_var(
			'SELECT COUNT(*) FROM `' . $this->table() . "` WHERE status = 'pending'"
		);
	}
}
