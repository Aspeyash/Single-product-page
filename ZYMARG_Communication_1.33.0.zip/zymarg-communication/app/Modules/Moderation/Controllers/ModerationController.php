<?php
/**
 * REST endpoints for reporting, reviewing, and acting on moderation cases,
 * plus admin stealth-read of conversation content.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Moderation\Controllers;

use ZymargCommunication\Core\Abstracts\AbstractController;
use ZymargCommunication\Infrastructure\Http\Middleware\AuthMiddleware;
use ZymargCommunication\Infrastructure\Http\Middleware\NonceMiddleware;
use ZymargCommunication\Modules\Moderation\Services\AdminViewService;
use ZymargCommunication\Modules\Moderation\Services\ModerationService;
use WP_REST_Request;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ModerationController extends AbstractController {

	public function __construct(
		private ModerationService $moderation,
		private AdminViewService $adminView
	) {}

	public function registerRoutes(): void {
		$ns = self::NAMESPACE;

		register_rest_route( $ns, '/conversations/(?P<id>\d+)/report', array(
			'methods'             => 'POST',
			'callback'            => array( $this, 'report' ),
			'permission_callback' => $this->userWriteGuard(),
			'args'                => array( 'id' => array( 'required' => true ) ),
		) );

		register_rest_route( $ns, '/moderation/queue', array(
			'methods'             => 'GET',
			'callback'            => array( $this, 'queue' ),
			'permission_callback' => static fn( $request ) => AuthMiddleware::requireAdmin( $request ),
		) );

		register_rest_route( $ns, '/moderation/(?P<id>\d+)', array(
			'methods'             => 'PATCH',
			'callback'            => array( $this, 'act' ),
			'permission_callback' => $this->adminWriteGuard(),
			'args'                => array( 'id' => array( 'required' => true ) ),
		) );

		register_rest_route( $ns, '/moderation/conversations/(?P<id>\d+)', array(
			'methods'             => 'GET',
			'callback'            => array( $this, 'adminView' ),
			'permission_callback' => static fn( $request ) => AuthMiddleware::requireAdmin( $request ),
			'args'                => array( 'id' => array( 'required' => true ) ),
		) );
	}

	public function report( WP_REST_Request $request ) {
		return $this->handle( function () use ( $request ) {
			$id    = (int) $request['id'];
			$notes = sanitize_textarea_field( (string) $this->param( $request, 'notes', '' ) );
			$out   = $this->moderation->reportConversation( $id, $this->currentUserId(), '' !== $notes ? $notes : null );
			return $this->ok( $out );
		} );
	}

	public function queue( WP_REST_Request $request ) {
		return $this->handle( function () use ( $request ) {
			$status = $this->param( $request, 'status', null );
			$status = is_string( $status ) && '' !== $status ? sanitize_key( $status ) : null;
			$limit  = max( 1, min( 200, (int) $this->param( $request, 'limit', 50 ) ) );
			$offset = max( 0, (int) $this->param( $request, 'offset', 0 ) );
			return $this->ok( array(
				'items'         => $this->moderation->queue( $status, $limit, $offset ),
				'pending_count' => $this->moderation->pendingCount(),
			) );
		} );
	}

	public function act( WP_REST_Request $request ) {
		return $this->handle( function () use ( $request ) {
			$id     = (int) $request['id'];
			$status = sanitize_key( (string) $this->param( $request, 'status', '' ) );
			$notes  = sanitize_textarea_field( (string) $this->param( $request, 'notes', '' ) );
			if ( '' === $status ) {
				return $this->fail( 'invalid_status', __( 'Missing moderation status.', 'zymarg-communication' ), 400 );
			}
			return $this->ok( $this->moderation->actOnCase( $id, $this->currentUserId(), $status, '' !== $notes ? $notes : null ) );
		} );
	}

	public function adminView( WP_REST_Request $request ) {
		return $this->handle( function () use ( $request ) {
			$id    = (int) $request['id'];
			$limit = max( 1, min( 500, (int) $this->param( $request, 'limit', 200 ) ) );
			return $this->ok( $this->adminView->view( $id, $this->currentUserId(), $limit ) );
		} );
	}

	private function userWriteGuard(): callable {
		return static function ( $request ) {
			$auth = AuthMiddleware::requireLoggedIn( $request );
			if ( true !== $auth ) {
				return $auth;
			}
			return NonceMiddleware::verify( $request );
		};
	}

	private function adminWriteGuard(): callable {
		return static function ( $request ) {
			$auth = AuthMiddleware::requireAdmin( $request );
			if ( true !== $auth ) {
				return $auth;
			}
			return NonceMiddleware::verify( $request );
		};
	}
}
