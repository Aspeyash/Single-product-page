<?php
/**
 * Plain data object representing a moderation log entry.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Moderation\Models;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ModerationLog {

	public function __construct(
		public int $id,
		public int $conversationId,
		public ?int $reporterId,
		public ?int $moderatorId,
		public string $type,
		public string $status,
		public ?string $notes,
		public string $createdAt,
		public string $updatedAt
	) {}

	public static function fromRow( object $row ): self {
		return new self(
			(int) $row->id,
			(int) $row->conversation_id,
			isset( $row->reporter_id ) ? (int) $row->reporter_id : null,
			isset( $row->moderator_id ) ? (int) $row->moderator_id : null,
			(string) $row->type,
			(string) $row->status,
			$row->notes ?? null,
			(string) $row->created_at,
			(string) $row->updated_at
		);
	}

	public function toArray(): array {
		return array(
			'id'              => $this->id,
			'conversation_id' => $this->conversationId,
			'reporter_id'     => $this->reporterId,
			'moderator_id'    => $this->moderatorId,
			'type'            => $this->type,
			'status'          => $this->status,
			'notes'           => $this->notes,
			'created_at'      => $this->createdAt,
			'updated_at'      => $this->updatedAt,
		);
	}
}
