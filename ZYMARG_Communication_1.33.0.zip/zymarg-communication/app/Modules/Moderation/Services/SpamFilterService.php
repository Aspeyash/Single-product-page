<?php
/**
 * SpamFilterService — heuristic spam detection for incoming message bodies.
 *
 * Signals used (any single hit above the threshold flags the message):
 *   • High link density (>3 URLs in a single message).
 *   • Long runs of the same character (">10" ceases to be conversational).
 *   • Excessive uppercase for messages of ≥15 characters.
 *   • Known spam phrases via the `zymarg_comm_spam_phrases` filter.
 *   • Third-party `zymarg_comm_spam_check` filter (return true to flag).
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Moderation\Services;

use ZymargCommunication\Core\Abstracts\AbstractService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class SpamFilterService extends AbstractService {

	/** @return array{is_spam:bool,reason?:string,score:int} */
	public function analyse( string $body, ?int $sender_id = null ): array {
		$plain = trim( wp_strip_all_tags( $body ) );
		if ( '' === $plain ) {
			return array( 'is_spam' => false, 'score' => 0 );
		}

		$score  = 0;
		$reason = '';

		$link_count = preg_match_all( '#https?://#i', $plain );
		if ( $link_count >= 4 ) {
			$score += 3;
			$reason = __( 'Excessive links.', 'zymarg-communication' );
		}

		if ( preg_match( '/(.)\\1{10,}/u', $plain ) ) {
			$score += 2;
			$reason = $reason ?: __( 'Repeated character run.', 'zymarg-communication' );
		}

		$length = function_exists( 'mb_strlen' ) ? mb_strlen( $plain ) : strlen( $plain );
		if ( $length >= 15 ) {
			$letters = preg_replace( '/[^a-zA-Z]/', '', $plain );
			$upper   = preg_replace( '/[^A-Z]/', '', (string) $letters );
			if ( '' !== $letters && strlen( (string) $upper ) / max( 1, strlen( (string) $letters ) ) >= 0.7 ) {
				$score += 1;
				$reason = $reason ?: __( 'Excessive uppercase.', 'zymarg-communication' );
			}
		}

		$phrases = (array) apply_filters( 'zymarg_comm_spam_phrases', array(
			'buy now', 'click here', 'earn money fast', 'crypto giveaway', 'nigerian prince',
			'wire transfer', 'you have won', 'free bitcoin', 'ready when you are',
		) );
		$lower = function_exists( 'mb_strtolower' ) ? mb_strtolower( $plain ) : strtolower( $plain );
		foreach ( $phrases as $phrase ) {
			$p = trim( (string) $phrase );
			if ( '' === $p ) {
				continue;
			}
			if ( false !== strpos( $lower, strtolower( $p ) ) ) {
				$score += 3;
				$reason = $reason ?: sprintf( __( 'Matched phrase: %s', 'zymarg-communication' ), $p );
				break;
			}
		}

		/**
		 * Third-party override. Return true to force flag, or a string reason.
		 */
		$override = apply_filters( 'zymarg_comm_spam_check', null, $body, $sender_id );
		if ( true === $override ) {
			return array( 'is_spam' => true, 'score' => max( 3, $score ), 'reason' => $reason ?: __( 'Flagged by integration.', 'zymarg-communication' ) );
		}
		if ( is_string( $override ) && '' !== $override ) {
			return array( 'is_spam' => true, 'score' => max( 3, $score ), 'reason' => $override );
		}

		$threshold = (int) apply_filters( 'zymarg_comm_spam_threshold', 3 );
		if ( $score >= $threshold ) {
			return array( 'is_spam' => true, 'score' => $score, 'reason' => $reason ?: __( 'Spam patterns detected.', 'zymarg-communication' ) );
		}
		return array( 'is_spam' => false, 'score' => $score );
	}
}
