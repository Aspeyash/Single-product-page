<?php
/**
 * BlocklistService — manages blocked words and blocked users.
 *
 * Blocked words:
 *   Stored as a comma/newline-separated list in the option
 *   `zymarg_comm_blocklist_words`. Case-insensitive whole-word match.
 *
 * Blocked users (per-user):
 *   Stored in user_meta at `_zymarg_comm_blocked_users` as an array of
 *   user IDs. If user A blocks user B, neither can message the other.
 *
 * Checks are run before storing a message.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Moderation\Services;

use ZymargCommunication\Core\Abstracts\AbstractService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BlocklistService extends AbstractService {

	public const OPTION_WORDS      = 'zymarg_comm_blocklist_words';
	public const META_BLOCKED_USERS = '_zymarg_comm_blocked_users';

	/** Detects the first blocklisted word inside a message body. Returns null when clean. */
	public function firstBlockedWord( string $body ): ?string {
		$words = $this->words();
		if ( empty( $words ) || '' === trim( $body ) ) {
			return null;
		}
		$plain = strtolower( wp_strip_all_tags( $body ) );
		foreach ( $words as $word ) {
			$lower = strtolower( $word );
			if ( '' === $lower ) {
				continue;
			}
			if ( 1 === preg_match( '/\\b' . preg_quote( $lower, '/' ) . '\\b/u', $plain ) ) {
				return $word;
			}
		}
		return null;
	}

	/** True when the sender is blocked by any recipient, or when the sender has blocked any recipient. */
	public function isSenderBlocked( int $sender_id, array $recipient_ids ): bool {
		if ( $sender_id <= 0 || empty( $recipient_ids ) ) {
			return false;
		}
		$sender_blocklist = $this->blockedUsersFor( $sender_id );
		foreach ( $recipient_ids as $recipient_id ) {
			$rid = (int) $recipient_id;
			if ( $rid <= 0 || $rid === $sender_id ) {
				continue;
			}
			if ( in_array( $rid, $sender_blocklist, true ) ) {
				return true;
			}
			if ( in_array( $sender_id, $this->blockedUsersFor( $rid ), true ) ) {
				return true;
			}
		}
		return false;
	}

	public function blockUser( int $blocker_id, int $blocked_id ): void {
		if ( $blocker_id <= 0 || $blocked_id <= 0 || $blocker_id === $blocked_id ) {
			return;
		}
		$list = $this->blockedUsersFor( $blocker_id );
		if ( ! in_array( $blocked_id, $list, true ) ) {
			$list[] = $blocked_id;
			update_user_meta( $blocker_id, self::META_BLOCKED_USERS, array_values( array_unique( $list ) ) );
		}
	}

	public function unblockUser( int $blocker_id, int $blocked_id ): void {
		$list = array_values( array_filter( $this->blockedUsersFor( $blocker_id ), fn( $id ) => (int) $id !== $blocked_id ) );
		update_user_meta( $blocker_id, self::META_BLOCKED_USERS, $list );
	}

	/** @return array<int, int> */
	public function blockedUsersFor( int $user_id ): array {
		$raw = get_user_meta( $user_id, self::META_BLOCKED_USERS, true );
		if ( ! is_array( $raw ) ) {
			return array();
		}
		return array_values( array_filter( array_map( 'intval', $raw ), fn( $id ) => $id > 0 ) );
	}

	public function setBlockedWords( array $words ): void {
		$clean = array();
		foreach ( $words as $word ) {
			$trim = trim( (string) $word );
			if ( '' !== $trim ) {
				$clean[] = sanitize_text_field( $trim );
			}
		}
		update_option( self::OPTION_WORDS, implode( "\n", $clean ), false );
	}

	/** @return array<int, string> */
	public function words(): array {
		$raw = (string) get_option( self::OPTION_WORDS, '' );
		if ( '' === $raw ) {
			return array();
		}
		$parts = preg_split( '/[\\r\\n,]+/', $raw );
		if ( ! is_array( $parts ) ) {
			return array();
		}
		$out = array();
		foreach ( $parts as $part ) {
			$trim = trim( $part );
			if ( '' !== $trim ) {
				$out[] = $trim;
			}
		}
		return $out;
	}
}
