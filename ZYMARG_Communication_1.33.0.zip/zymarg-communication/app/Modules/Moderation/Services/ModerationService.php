<?php
/**
 * ModerationService — processes conversation reports and surfaces cases
 * for admin review.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Moderation\Services;

use ZymargCommunication\Core\Abstracts\AbstractService;
use ZymargCommunication\Core\Exceptions\NotFoundException;
use ZymargCommunication\Core\Exceptions\UnauthorizedException;
use ZymargCommunication\Modules\Conversation\Repositories\ConversationRepository;
use ZymargCommunication\Modules\Conversation\Repositories\ParticipantRepository;
use ZymargCommunication\Modules\Moderation\Repositories\ModerationRepository;
use ZymargCommunication\Modules\Security\Services\AuditLogService;
use ZymargCommunication\Shared\Enums\ConversationStatus;
use ZymargCommunication\Shared\Enums\ModerationStatus;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ModerationService extends AbstractService {

	public function __construct(
		private ModerationRepository $repository,
		private ConversationRepository $conversations,
		private ParticipantRepository $participants,
		private AuditLogService $audit
	) {}

	/**
	 * Report a conversation. Only participants (or admins) may report.
	 * Flips the conversation status to `reported` and files a moderation log.
	 */
	public function reportConversation( int $conversation_id, int $reporter_id, ?string $notes = null ): array {
		if ( ! $this->isEnabled( 'moderation.reporting' ) ) {
			throw new UnauthorizedException( __( 'Reporting is disabled.', 'zymarg-communication' ) );
		}
		$conversation = $this->conversations->findModel( $conversation_id );
		if ( ! $conversation ) {
			throw new NotFoundException( __( 'Conversation not found.', 'zymarg-communication' ) );
		}

		$is_admin = user_can( $reporter_id, 'manage_options' );
		if ( ! $is_admin && ! $this->participants->isParticipant( $conversation_id, $reporter_id ) ) {
			throw new UnauthorizedException( __( 'You are not part of this conversation.', 'zymarg-communication' ) );
		}

		$this->conversations->updateStatus( $conversation_id, ConversationStatus::Reported->value );

		$id = $this->repository->create( array(
			'conversation_id' => $conversation_id,
			'reporter_id'     => $reporter_id,
			'type'            => 'report',
			'status'          => ModerationStatus::Pending->value,
			'notes'           => $notes,
		) );

		return array(
			'id'              => $id,
			'conversation_id' => $conversation_id,
			'status'          => ConversationStatus::Reported->value,
		);
	}

	/** Record a system-triggered moderation entry (spam / blocklist hits). */
	public function recordSystemFlag( int $conversation_id, string $type, ?string $notes = null ): int {
		return $this->repository->create( array(
			'conversation_id' => $conversation_id,
			'reporter_id'     => null,
			'type'            => $type,
			'status'          => ModerationStatus::Pending->value,
			'notes'           => $notes,
		) );
	}

	/**
	 * Admin action: dismiss / resolve / mark reviewed a moderation entry.
	 */
	public function actOnCase( int $case_id, int $moderator_id, string $status, ?string $notes = null ): array {
		$case = $this->repository->findModel( $case_id );
		if ( ! $case ) {
			throw new NotFoundException( __( 'Moderation case not found.', 'zymarg-communication' ) );
		}
		$valid = array_map( fn( $s ) => $s->value, ModerationStatus::cases() );
		if ( ! in_array( $status, $valid, true ) ) {
			throw new \InvalidArgumentException( 'Invalid moderation status.' );
		}

		$this->repository->updateStatus( $case_id, $status, $moderator_id, $notes );
		$this->audit->record( 'moderation_case_' . $status, 'moderation_log', $case_id, array( 'notes' => $notes ), $moderator_id );

		$updated = $this->repository->findModel( $case_id );
		return $updated ? $updated->toArray() : array();
	}

	public function queue( ?string $status = null, int $limit = 50, int $offset = 0 ): array {
		return array_map( fn( $l ) => $l->toArray(), $this->repository->queue( $status, $limit, $offset ) );
	}

	public function pendingCount(): int {
		return $this->repository->countPending();
	}
}
