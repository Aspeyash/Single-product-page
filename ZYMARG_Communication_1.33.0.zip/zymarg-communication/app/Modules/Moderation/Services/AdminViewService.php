<?php
/**
 * AdminViewService — the only entry point for admin reads of conversation
 * content. Reads never trigger read receipts, delivered status, or
 * notifications, and never update `last_read_at`. Every access is silently
 * recorded via AuditLogService.
 *
 * Any code path that bypasses this service and reads conversation content
 * as an admin violates the admin privacy contract in the security checklist.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Moderation\Services;

use ZymargCommunication\Core\Abstracts\AbstractService;
use ZymargCommunication\Core\Exceptions\NotFoundException;
use ZymargCommunication\Modules\Conversation\Repositories\ConversationRepository;
use ZymargCommunication\Modules\Conversation\Repositories\ParticipantRepository;
use ZymargCommunication\Modules\Message\Repositories\MessageRepository;
use ZymargCommunication\Modules\Security\Services\AuditLogService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdminViewService extends AbstractService {

	public const AUDIT_ACTION = 'admin_viewed_conversation';

	public function __construct(
		private ConversationRepository $conversations,
		private ParticipantRepository $participants,
		private MessageRepository $messages,
		private AuditLogService $audit
	) {}

	/**
	 * Load a full conversation view for an admin. Does not update any
	 * read state and never fires notifications.
	 *
	 * @return array{conversation:array<string,mixed>,participants:array<int,array<string,mixed>>,messages:array<int,array<string,mixed>>}
	 */
	public function view( int $conversation_id, int $admin_id, int $message_limit = 200 ): array {
		$conversation = $this->conversations->findModel( $conversation_id );
		if ( ! $conversation ) {
			throw new NotFoundException( __( 'Conversation not found.', 'zymarg-communication' ) );
		}

		$participants = $this->participants->findForConversation( $conversation_id );
		$messages     = $this->messages->findForConversation( $conversation_id, max( 1, min( 500, $message_limit ) ), 0 );

		$this->audit->record(
			self::AUDIT_ACTION,
			'conversation',
			$conversation_id,
			array( 'message_count' => is_array( $messages ) ? count( $messages ) : 0 ),
			$admin_id
		);

		return array(
			'conversation' => $conversation->toArray(),
			'participants' => array_map( fn( $p ) => $p->toArray(), $participants ),
			'messages'     => array_map( fn( $m ) => $m->toArray(), is_array( $messages ) ? $messages : array() ),
		);
	}
}
