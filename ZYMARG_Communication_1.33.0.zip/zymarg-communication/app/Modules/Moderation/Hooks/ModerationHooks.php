<?php
/**
 * ModerationHooks — registers the moderation REST controller.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Moderation\Hooks;

use ZymargCommunication\Bootstrap\ServiceProvider;
use ZymargCommunication\Core\Contracts\HookableInterface;
use ZymargCommunication\Infrastructure\Http\Controllers\RestController;
use ZymargCommunication\Modules\Moderation\Controllers\ModerationController;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ModerationHooks implements HookableInterface {

	public static function register(): void {
		$instance = new self();
		$instance->registerHooks();
	}

	private function registerHooks(): void {
		if ( ! ServiceProvider::has( ModerationController::class ) ) {
			return;
		}
		$controller = ServiceProvider::get( ModerationController::class );
		if ( $controller instanceof ModerationController ) {
			RestController::register( $controller );
		}
	}
}
