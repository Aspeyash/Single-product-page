<?php
/**
 * SettingsService — reads and writes global plugin settings.
 *
 * Sensitive credential fields (currently the Pusher app_id / app_key /
 * app_secret) are encrypted via EncryptionService before storage and never
 * returned to the browser. GET responses expose only `is_configured` booleans.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Settings\Services;

use ZymargCommunication\Core\Abstracts\AbstractService;
use ZymargCommunication\Modules\Security\Services\EncryptionService;
use ZymargCommunication\Modules\Settings\Repositories\SettingsRepository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class SettingsService extends AbstractService {

	/** @var array<string, array{group:string,sensitive:bool}> */
	private const KNOWN = array(
		'realtime_driver'      => array( 'group' => 'realtime', 'sensitive' => false ),
		'pusher_app_id'        => array( 'group' => 'pusher',   'sensitive' => true ),
		'pusher_app_key'       => array( 'group' => 'pusher',   'sensitive' => true ),
		'pusher_app_secret'    => array( 'group' => 'pusher',   'sensitive' => true ),
		'pusher_cluster'       => array( 'group' => 'pusher',   'sensitive' => false ),
		'push_endpoint'        => array( 'group' => 'notification', 'sensitive' => false ),
		'push_token'           => array( 'group' => 'notification', 'sensitive' => true ),
		'browser_push_endpoint'=> array( 'group' => 'notification', 'sensitive' => false ),
		'browser_push_token'   => array( 'group' => 'notification', 'sensitive' => true ),
		'vapid_public_key'     => array( 'group' => 'notification', 'sensitive' => false ),
	);

	public function __construct(
		private SettingsRepository $repository,
		private EncryptionService $encryption
	) {}

	/**
	 * Public settings view. Sensitive fields never leak their raw value —
	 * only an `is_configured` boolean per credential group.
	 *
	 * @return array<string, mixed>
	 */
	public function publicSnapshot(): array {
		return array(
			'realtime' => array(
				'driver' => (string) $this->repository->get( 'realtime_driver', 'pusher' ),
			),
			'pusher' => array(
				'is_configured'  => $this->pusherIsConfigured(),
				'cluster'        => (string) $this->repository->get( 'pusher_cluster', '' ),
				'has_app_id'     => '' !== (string) $this->repository->get( 'pusher_app_id', '' ),
				'has_app_key'    => '' !== (string) $this->repository->get( 'pusher_app_key', '' ),
				'has_app_secret' => '' !== (string) $this->repository->get( 'pusher_app_secret', '' ),
			),
			'notification' => array(
				'push_endpoint_is_set'         => '' !== (string) $this->repository->get( 'push_endpoint', '' ),
				'push_token_is_set'            => '' !== (string) $this->repository->get( 'push_token', '' ),
				'browser_push_endpoint_is_set' => '' !== (string) $this->repository->get( 'browser_push_endpoint', '' ),
				'browser_push_token_is_set'    => '' !== (string) $this->repository->get( 'browser_push_token', '' ),
				'vapid_public_key'             => (string) $this->repository->get( 'vapid_public_key', '' ),
			),
		);
	}

	/**
	 * Apply an admin-supplied patch. Ignores unknown keys. Empty strings on
	 * sensitive fields are treated as "no change" so the admin can save the
	 * form without re-typing masked credentials.
	 *
	 * @param array<string, mixed> $patch
	 */
	public function update( array $patch ): array {
		foreach ( $patch as $key => $raw ) {
			if ( ! isset( self::KNOWN[ $key ] ) ) {
				continue;
			}
			$meta = self::KNOWN[ $key ];
			$value = is_scalar( $raw ) ? (string) $raw : '';

			if ( $meta['sensitive'] ) {
				if ( '' === $value ) {
					continue; // Leave the stored value alone — preserves masked credentials.
				}
				$this->repository->set( $key, $this->encryption->encrypt( $value ) );
				continue;
			}
			$this->repository->set( $key, sanitize_text_field( $value ) );
		}
		return $this->publicSnapshot();
	}

	/**
	 * Decrypt and return the current Pusher credentials for internal use
	 * (never returned via REST).
	 *
	 * @return array{app_id:string,app_key:string,app_secret:string,cluster:string}
	 */
	public function pusherCredentials(): array {
		return array(
			'app_id'     => $this->decrypted( 'pusher_app_id' ),
			'app_key'    => $this->decrypted( 'pusher_app_key' ),
			'app_secret' => $this->decrypted( 'pusher_app_secret' ),
			'cluster'    => (string) $this->repository->get( 'pusher_cluster', 'mt1' ),
		);
	}

	public function pusherIsConfigured(): bool {
		foreach ( array( 'pusher_app_id', 'pusher_app_key', 'pusher_app_secret' ) as $key ) {
			if ( '' === (string) $this->repository->get( $key, '' ) ) {
				return false;
			}
		}
		return true;
	}

	private function decrypted( string $key ): string {
		$raw = (string) $this->repository->get( $key, '' );
		if ( '' === $raw ) {
			return '';
		}
		if ( $this->encryption->isEncrypted( $raw ) ) {
			return $this->encryption->decrypt( $raw );
		}
		return $raw; // Backwards-compat with pre-encryption stored values.
	}
}
