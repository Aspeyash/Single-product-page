<?php
/**
 * ZYMARG Communication
 *
 * @package    ZymargCommunication
 * @version    1.0.0
 * @author     ZYMARG Team
 */

namespace ZymargCommunication\Modules\Settings\Services;

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class UserPreferencesService {
    // TODO: implement
}
