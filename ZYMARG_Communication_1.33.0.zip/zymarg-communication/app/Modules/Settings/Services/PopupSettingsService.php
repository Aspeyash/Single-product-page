<?php
/**
 * ZYMARG Communication
 *
 * Controls when the floating live-chat popup is allowed to open by itself.
 *
 * Before 1.18.0 the popup surfaced itself on EVERY page as soon as the unread
 * count went up. (In practice it never fired at all, because the unread poll
 * was hitting a route that did not exist -- see the 1.17.0 changelog. Fixing
 * that route made the always-on behaviour visible for the first time.)
 *
 * Auto-open is now opt-in and scoped to an explicit list of page IDs chosen by
 * an administrator. Both conditions must hold:
 *   1. the master toggle is on, and
 *   2. the page being viewed is on the allow-list.
 * Anything else -- including an empty allow-list -- means no auto-open. The
 * launcher badge still updates, so unread messages are never hidden.
 *
 * @package    ZymargCommunication
 * @version    1.18.0
 * @author     ZYMARG Team
 */

namespace ZymargCommunication\Modules\Settings\Services;

use ZymargCommunication\Modules\Settings\Repositories\SettingsRepository;

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PopupSettingsService {

    /** Master on/off switch for popup auto-open. */
    public const AUTO_OPEN_ENABLED = 'popup_autoopen_enabled';

    /** Comma-separated list of page IDs where auto-open is permitted. */
    public const AUTO_OPEN_PAGES = 'popup_autoopen_page_ids';

    private SettingsRepository $repo;

    public function __construct( ?SettingsRepository $repo = null ) {
        $this->repo = $repo ?? new SettingsRepository();
    }

    /**
     * Master toggle. Defaults to OFF so upgrading sites do not inherit the
     * old open-everywhere behaviour.
     */
    public function isAutoOpenEnabled(): bool {
        return '1' === (string) $this->repo->get( self::AUTO_OPEN_ENABLED, '0' );
    }

    public function setAutoOpenEnabled( bool $enabled ): void {
        $this->repo->set( self::AUTO_OPEN_ENABLED, $enabled ? '1' : '0' );
    }

    /**
     * Page IDs where auto-open is permitted.
     *
     * @return array<int, int>
     */
    public function allowedPageIds(): array {
        $raw = (string) $this->repo->get( self::AUTO_OPEN_PAGES, '' );
        if ( '' === trim( $raw ) ) {
            return array();
        }

        $ids = array_map( 'absint', explode( ',', $raw ) );
        $ids = array_filter(
            $ids,
            static function ( int $id ): bool {
                return $id > 0;
            }
        );

        return array_values( array_unique( $ids ) );
    }

    /**
     * @param array<int|string> $ids
     */
    public function setAllowedPageIds( array $ids ): void {
        $clean = array_map( 'absint', $ids );
        $clean = array_filter(
            $clean,
            static function ( int $id ): bool {
                return $id > 0;
            }
        );
        $clean = array_values( array_unique( $clean ) );

        $this->repo->set( self::AUTO_OPEN_PAGES, implode( ',', $clean ) );
    }

    /* ---------------------------------------------------------------------
     * 1.26.0 — support delivery + arrival behaviour
     * ------------------------------------------------------------------ */

    /** Where a support thread opens. popup_first|auto|inline|popup|page */
    public const SUPPORT_DELIVERY = 'support_delivery';

    /** How an arriving message announces itself. toast|autoopen|badge */
    public const NEW_MESSAGE_BEHAVIOR = 'new_message_behavior';

    /**
     * Valid delivery modes.
     *
     * `popup_first` (1.30.0) is the default and the only mode with a two-step
     * flow: the popup opens immediately, and closing it reveals the in-page
     * inbox that was sitting hidden behind it. `inline` is retained purely so
     * sites that saved it before 1.30.0 keep working; it resolves like `auto`.
     */
    public const DELIVERY_MODES = array( 'popup_first', 'auto', 'inline', 'popup', 'page' );
    public const ARRIVAL_MODES  = array( 'toast', 'autoopen', 'badge' );

    /** Shipped default, named so callers never repeat the literal. */
    public const DELIVERY_DEFAULT = 'popup_first';

    /**
     * Where clicking a support trigger should open the thread.
     *
     * Defaults to `popup_first`: the customer gets the quick popup lane straight
     * away, and the roomy in-page inbox is one click behind it. Support is a
     * helpline -- the fastest path to typing the problem wins, and the full
     * inbox stays available for anyone who wants the space.
     */
    public function supportDelivery(): string {
        $mode = strtolower( trim( (string) $this->repo->get( self::SUPPORT_DELIVERY, self::DELIVERY_DEFAULT ) ) );

        return in_array( $mode, self::DELIVERY_MODES, true ) ? $mode : self::DELIVERY_DEFAULT;
    }

    public function setSupportDelivery( string $mode ): void {
        $mode = strtolower( trim( $mode ) );
        if ( ! in_array( $mode, self::DELIVERY_MODES, true ) ) {
            $mode = self::DELIVERY_DEFAULT;
        }
        $this->repo->set( self::SUPPORT_DELIVERY, $mode );
    }

    /**
     * Should the in-page support inbox be rendered hidden?
     *
     * True only for `popup_first`, where the popup is the first thing the
     * customer sees and the inbox is revealed when they close it. Every other
     * mode renders the inbox visible exactly as it did before 1.30.0.
     *
     * NOTE: this governs the CUSTOMER surface only. The agent surfaces (the
     * wp-admin Admin<->User screen and the frontend Agent Console drawer) call
     * SupportChat::inboxRoot() directly without these options, so an agent can
     * never end up staring at a hidden inbox.
     */
    public function inlineStartsHidden(): bool {
        return 'popup_first' === $this->supportDelivery();
    }

    /**
     * Does the configured mode depend on the live-chat popup existing?
     *
     * Used by the settings screen to warn when the `surface.popup` feature flag
     * is off: in that case live-chat.js returns early before publishing its
     * open() method, so the popup branch silently degrades to the in-page inbox.
     */
    public function deliveryNeedsPopup(): bool {
        return in_array( $this->supportDelivery(), array( 'popup_first', 'popup' ), true );
    }

    /**
     * How a newly arrived message announces itself.
     *
     * Defaults to `toast`. The historic behaviour -- throwing the popup open on
     * top of whatever the customer was doing -- is still available as
     * `autoopen`, and remains additionally gated by the auto-open page
     * allow-list above, so existing configurations are unchanged.
     */
    public function newMessageBehavior(): string {
        $mode = strtolower( trim( (string) $this->repo->get( self::NEW_MESSAGE_BEHAVIOR, 'toast' ) ) );

        return in_array( $mode, self::ARRIVAL_MODES, true ) ? $mode : 'toast';
    }

    public function setNewMessageBehavior( string $mode ): void {
        $mode = strtolower( trim( $mode ) );
        if ( ! in_array( $mode, self::ARRIVAL_MODES, true ) ) {
            $mode = 'toast';
        }
        $this->repo->set( self::NEW_MESSAGE_BEHAVIOR, $mode );
    }

    /**
     * Whether the popup may auto-open on the page currently being rendered.
     *
     * Safe to call during `wp_enqueue_scripts`; returns false in any admin,
     * REST, AJAX or CLI context where there is no queried page.
     */
    public function isAutoOpenAllowedHere(): bool {
        if ( ! $this->isAutoOpenEnabled() ) {
            return false;
        }

        $allowed = $this->allowedPageIds();
        if ( empty( $allowed ) ) {
            return false;
        }

        if ( ! function_exists( 'get_queried_object_id' ) ) {
            return false;
        }

        $current = (int) get_queried_object_id();
        if ( $current <= 0 ) {
            return false;
        }

        $allowed_here = in_array( $current, $allowed, true );

        /**
         * Filter whether the live-chat popup may auto-open on this page.
         *
         * @param bool            $allowed_here Result of the page allow-list check.
         * @param int             $current      Queried object ID.
         * @param array<int, int> $allowed      Configured page IDs.
         */
        return (bool) apply_filters( 'zymarg_comm_popup_autoopen_allowed', $allowed_here, $current, $allowed );
    }
}
