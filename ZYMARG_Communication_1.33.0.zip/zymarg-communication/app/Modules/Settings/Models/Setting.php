<?php
/**
 * Plain data object representing a plugin-scoped setting value.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Settings\Models;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Setting {

	public function __construct(
		public string $key,
		public mixed $value,
		public bool $isEncrypted = false
	) {}

	public function toArray(): array {
		return array(
			'key'          => $this->key,
			'value'        => $this->value,
			'is_encrypted' => $this->isEncrypted,
		);
	}
}
