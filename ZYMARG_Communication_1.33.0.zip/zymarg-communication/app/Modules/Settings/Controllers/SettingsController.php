<?php
/**
 * REST endpoints for reading and writing global settings, plus the Pusher
 * "Test Connection" endpoint. Never returns raw credential values on GET.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Settings\Controllers;

use ZymargCommunication\Core\Abstracts\AbstractController;
use ZymargCommunication\Infrastructure\Http\Middleware\AuthMiddleware;
use ZymargCommunication\Infrastructure\Http\Middleware\NonceMiddleware;
use ZymargCommunication\Modules\Realtime\Services\PusherService;
use ZymargCommunication\Modules\Security\Services\AuditLogService;
use ZymargCommunication\Modules\Settings\Services\SettingsService;
use WP_REST_Request;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class SettingsController extends AbstractController {

	public function __construct(
		private SettingsService $settings,
		private PusherService $pusher,
		private AuditLogService $audit
	) {}

	public function registerRoutes(): void {
		$ns = self::NAMESPACE;

		register_rest_route( $ns, '/settings', array(
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get' ),
				'permission_callback' => static fn( $request ) => AuthMiddleware::requireAdmin( $request ),
			),
			array(
				'methods'             => 'PATCH',
				'callback'            => array( $this, 'update' ),
				'permission_callback' => $this->adminWriteGuard(),
			),
		) );

		register_rest_route( $ns, '/settings/pusher/test', array(
			'methods'             => 'POST',
			'callback'            => array( $this, 'pusherTest' ),
			'permission_callback' => $this->adminWriteGuard(),
		) );
	}

	public function get( WP_REST_Request $request ) {
		return $this->handle( fn () => $this->ok( array( 'settings' => $this->settings->publicSnapshot() ) ) );
	}

	public function update( WP_REST_Request $request ) {
		return $this->handle( function () use ( $request ) {
			$patch = array();
			foreach ( array( 'realtime_driver', 'pusher_app_id', 'pusher_app_key', 'pusher_app_secret', 'pusher_cluster', 'push_endpoint', 'push_token', 'browser_push_endpoint', 'browser_push_token', 'vapid_public_key' ) as $key ) {
				$value = $request->get_param( $key );
				if ( null !== $value ) {
					$patch[ $key ] = $value;
				}
			}
			$snapshot = $this->settings->update( $patch );
			$this->audit->record( 'settings_updated', 'settings', 0, array( 'keys' => array_keys( $patch ) ) );
			return $this->ok( array( 'settings' => $snapshot ) );
		} );
	}

	public function pusherTest( WP_REST_Request $request ) {
		return $this->handle( function () use ( $request ) {
			$credentials = array(
				'app_id'     => (string) $this->param( $request, 'app_id', '' ),
				'app_key'    => (string) $this->param( $request, 'app_key', '' ),
				'app_secret' => (string) $this->param( $request, 'app_secret', '' ),
				'cluster'    => (string) $this->param( $request, 'cluster', 'mt1' ),
			);

			foreach ( array( 'app_id', 'app_key', 'app_secret', 'cluster' ) as $field ) {
				if ( '' === $credentials[ $field ] ) {
					return $this->ok( array(
						'status'  => 'failed',
						'message' => __( 'Enter all Pusher credentials first.', 'zymarg-communication' ),
					) );
				}
			}

			$result = $this->pusher->testConnection( $credentials );
			$this->audit->record(
				'settings_pusher_tested',
				'settings',
				0,
				array( 'status' => (string) ( $result['status'] ?? 'unknown' ) )
			);
			return $this->ok( $result );
		} );
	}

	private function adminWriteGuard(): callable {
		return static function ( $request ) {
			$auth = AuthMiddleware::requireAdmin( $request );
			if ( true !== $auth ) {
				return $auth;
			}
			return NonceMiddleware::verify( $request );
		};
	}
}
