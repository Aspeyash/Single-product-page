<?php
/**
 * SettingsHooks — registers the Settings REST controller.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Settings\Hooks;

use ZymargCommunication\Bootstrap\ServiceProvider;
use ZymargCommunication\Core\Contracts\HookableInterface;
use ZymargCommunication\Infrastructure\Http\Controllers\RestController;
use ZymargCommunication\Modules\Settings\Controllers\SettingsController;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class SettingsHooks implements HookableInterface {

	public static function register(): void {
		$instance = new self();
		$instance->registerHooks();
	}

	private function registerHooks(): void {
		if ( ! ServiceProvider::has( SettingsController::class ) ) {
			return;
		}
		$controller = ServiceProvider::get( SettingsController::class );
		if ( $controller instanceof SettingsController ) {
			RestController::register( $controller );
		}
	}
}
