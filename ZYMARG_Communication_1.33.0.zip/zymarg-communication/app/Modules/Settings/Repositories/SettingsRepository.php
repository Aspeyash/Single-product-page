<?php
/**
 * SettingsRepository — thin wrapper over WordPress options for plugin-scoped
 * settings. The Settings module owns which values are sensitive (encrypted)
 * and which are plaintext; this repository just persists whatever it is given.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Settings\Repositories;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class SettingsRepository {

	public const OPTION_PREFIX = 'zymarg_comm_';

	public function get( string $key, mixed $default = null ): mixed {
		return get_option( self::OPTION_PREFIX . $key, $default );
	}

	public function set( string $key, mixed $value ): bool {
		return (bool) update_option( self::OPTION_PREFIX . $key, $value, false );
	}

	public function delete( string $key ): bool {
		return (bool) delete_option( self::OPTION_PREFIX . $key );
	}
}
