<?php
/**
 * UserPerformanceRepository - per-user messaging statistics derived from the
 * real message table (`zc_messages`), not from analytics events.
 *
 * WHY THE MESSAGE TABLE AND NOT ANALYTICS EVENTS:
 * ReportService::averageResponseSeconds() joins `conversation_created` to the
 * first following `message_sent` event, so it only ever measures the very
 * first reply in a conversation and only covers the period analytics events
 * happened to be recorded. Sellers who ignore follow-up messages score
 * perfectly under that definition. This class walks actual messages, so every
 * turn in every conversation is measured and the full history is available
 * retroactively.
 *
 * LOAD SAFETY - this class is deliberately cheap:
 *   - ONE indexed query per batch, keyset paginated on `id` (never OFFSET).
 *   - Reply gaps are accumulated into a fixed 12-bucket histogram per user,
 *     so memory stays flat no matter how many messages exist. Holding every
 *     gap in an array to compute an exact median would grow without bound.
 *   - No JSON_EXTRACT (unlike the analytics-event queries), so there is no
 *     MySQL version sensitivity.
 * It is only ever called from an explicit admin refresh or the scheduled
 * rebuild - never from a front-end request.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Analytics\Repositories;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class UserPerformanceRepository {

	/** Rows pulled per query. */
	private const BATCH = 2000;

	/** Hard ceiling on distinct users retained, newest activity wins. */
	private const MAX_USERS = 5000;

	/** Upper bounds (seconds) for the reply-time histogram. */
	private const BUCKETS = array( 60, 300, 900, 3600, 10800, 21600, 43200, 86400, 172800, 259200, 604800 );

	/**
	 * Walk messages in the window and accumulate per-user statistics.
	 *
	 * @return array<int,array<string,mixed>> Keyed by user id.
	 */
	public function collect( string $since, string $until ): array {
		global $wpdb;
		$table = $wpdb->prefix . 'zc_messages';

		$stats   = array();
		$convs   = array();
		$last_id = 0;
		$guard   = 0;

		while ( $guard < 10000 ) {
			$guard++;

			$rows = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT id, conversation_id, sender_id, created_at
					 FROM {$table}
					 WHERE id > %d
					   AND created_at >= %s
					   AND created_at <= %s
					   AND deleted_at IS NULL
					 ORDER BY id ASC
					 LIMIT %d",
					$last_id,
					$since,
					$until,
					self::BATCH
				),
				ARRAY_A
			);

			if ( empty( $rows ) ) {
				break;
			}

			foreach ( $rows as $row ) {
				$last_id = (int) $row['id'];
				$uid     = (int) $row['sender_id'];
				$cid     = (int) $row['conversation_id'];
				$ts      = (int) strtotime( (string) $row['created_at'] . ' UTC' );

				if ( $uid < 1 || $cid < 1 || $ts < 1 ) {
					continue;
				}

				if ( ! isset( $stats[ $uid ] ) ) {
					if ( count( $stats ) >= self::MAX_USERS ) {
						continue;
					}
					$stats[ $uid ] = $this->blank();
				}

				$stats[ $uid ]['messages']++;
				$stats[ $uid ]['convs'][ $cid ] = true;
				if ( $ts > $stats[ $uid ]['last_active'] ) {
					$stats[ $uid ]['last_active'] = $ts;
				}

				$state = isset( $convs[ $cid ] ) ? $convs[ $cid ] : null;

				if ( null === $state ) {
					// First message of this conversation in the window.
					$convs[ $cid ] = array( 'sender' => $uid, 'ts' => $ts, 'prev' => 0 );
					continue;
				}

				if ( (int) $state['sender'] === $uid ) {
					// Same person still talking - the block start time is unchanged.
					continue;
				}

				// Sender changed: this message answers the previous block.
				$wait = $ts - (int) $state['ts'];
				if ( $wait >= 0 ) {
					$stats[ $uid ]['answered']++;
					$stats[ $uid ]['reply_total'] += $wait;
					$stats[ $uid ]['reply_count']++;
					if ( $wait > $stats[ $uid ]['longest'] ) {
						$stats[ $uid ]['longest'] = $wait;
					}
					$this->bucket( $stats[ $uid ]['hist'], $wait );
				}

				$convs[ $cid ] = array( 'sender' => $uid, 'ts' => $ts, 'prev' => (int) $state['sender'] );
			}

			if ( count( $rows ) < self::BATCH ) {
				break;
			}
		}

		// Any conversation left mid-turn means the previous speaker was never
		// answered. That is an unanswered prompt against them.
		foreach ( $convs as $state ) {
			$waiting = (int) $state['prev'];
			if ( $waiting > 0 && isset( $stats[ $waiting ] ) ) {
				$stats[ $waiting ]['unanswered']++;
			}
		}

		return $this->finalise( $stats );
	}

	/** @return array<string,mixed> */
	private function blank(): array {
		return array(
			'messages'    => 0,
			'convs'       => array(),
			'answered'    => 0,
			'unanswered'  => 0,
			'reply_total' => 0,
			'reply_count' => 0,
			'longest'     => 0,
			'last_active' => 0,
			'hist'        => array_fill( 0, count( self::BUCKETS ) + 1, 0 ),
		);
	}

	/**
	 * @param array<int,int> $hist
	 */
	private function bucket( array &$hist, int $seconds ): void {
		foreach ( self::BUCKETS as $i => $bound ) {
			if ( $seconds <= $bound ) {
				$hist[ $i ]++;
				return;
			}
		}
		$hist[ count( self::BUCKETS ) ]++;
	}

	/**
	 * Approximate median from the histogram, interpolated inside the bucket
	 * that contains the middle sample. Exact enough to rank people by speed,
	 * and unlike a true median it costs no memory.
	 */
	private function median( array $hist, int $total ): ?float {
		if ( $total < 1 ) {
			return null;
		}
		$target = $total / 2;
		$cum    = 0;
		$lower  = 0;
		foreach ( $hist as $i => $n ) {
			$n = (int) $n;
			if ( $n < 1 ) {
				$lower = isset( self::BUCKETS[ $i ] ) ? (int) self::BUCKETS[ $i ] : $lower;
				continue;
			}
			if ( $cum + $n >= $target ) {
				if ( ! isset( self::BUCKETS[ $i ] ) ) {
					return (float) $lower;
				}
				$upper = (int) self::BUCKETS[ $i ];
				$into  = ( $target - $cum ) / $n;
				return round( $lower + ( ( $upper - $lower ) * $into ), 2 );
			}
			$cum  += $n;
			$lower = isset( self::BUCKETS[ $i ] ) ? (int) self::BUCKETS[ $i ] : $lower;
		}
		return (float) $lower;
	}

	/** @return array<int,array<string,mixed>> */
	private function finalise( array $stats ): array {
		$out = array();
		foreach ( $stats as $uid => $b ) {
			$prompts = (int) $b['answered'] + (int) $b['unanswered'];
			$out[ $uid ] = array(
				'user_id'     => (int) $uid,
				'messages'    => (int) $b['messages'],
				'convs'       => count( $b['convs'] ),
				'answered'    => (int) $b['answered'],
				'unanswered'  => (int) $b['unanswered'],
				'reply_avg'   => $b['reply_count'] > 0 ? round( $b['reply_total'] / $b['reply_count'], 2 ) : null,
				'reply_med'   => $this->median( (array) $b['hist'], (int) $b['reply_count'] ),
				'longest'     => (int) $b['longest'] > 0 ? (int) $b['longest'] : null,
				'rate'        => $prompts > 0 ? round( ( (int) $b['answered'] / $prompts ) * 100, 1 ) : null,
				'last_active' => (int) $b['last_active'],
			);
		}
		return $out;
	}
}
