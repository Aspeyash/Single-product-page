<?php
/**
 * AnalyticsRepository — all reads and writes for `zc_analytics_events`.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Analytics\Repositories;

use ZymargCommunication\Core\Abstracts\AbstractRepository;
use ZymargCommunication\Modules\Analytics\Models\AnalyticsEvent;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AnalyticsRepository extends AbstractRepository {

	protected function tableSuffix(): string {
		return 'zc_analytics_events';
	}

	public function record( ?int $user_id, string $event, array $payload ): int {
		return $this->insert(
			array(
				'user_id'    => $user_id,
				'event'      => $event,
				'payload'    => wp_json_encode( $payload ),
				'created_at' => current_time( 'mysql', true ),
			)
		);
	}

	public function findRecent( int $limit = 100, int $offset = 0 ): array {
		$limit  = max( 1, min( 500, $limit ) );
		$offset = max( 0, $offset );
		$rows   = $this->wpdb->get_results(
			$this->wpdb->prepare(
				'SELECT * FROM `' . $this->table() . '` ORDER BY id DESC LIMIT %d OFFSET %d',
				$limit,
				$offset
			)
		);
		return array_map( static fn( $r ) => AnalyticsEvent::fromRow( $r ), $rows ?: array() );
	}

	public function countEvent( string $event, ?string $since = null, ?string $until = null, ?int $user_id = null ): int {
		$sql    = 'SELECT COUNT(*) FROM `' . $this->table() . '` WHERE event = %s';
		$params = array( $event );
		if ( $since ) {
			$sql     .= ' AND created_at >= %s';
			$params[] = $since;
		}
		if ( $until ) {
			$sql     .= ' AND created_at <= %s';
			$params[] = $until;
		}
		if ( null !== $user_id ) {
			$sql     .= ' AND user_id = %d';
			$params[] = $user_id;
		}
		return (int) $this->wpdb->get_var( $this->wpdb->prepare( $sql, ...$params ) );
	}

	public function distinctUserCount( string $event, ?string $since = null, ?string $until = null ): int {
		$sql    = 'SELECT COUNT(DISTINCT user_id) FROM `' . $this->table() . '` WHERE event = %s AND user_id IS NOT NULL';
		$params = array( $event );
		if ( $since ) {
			$sql     .= ' AND created_at >= %s';
			$params[] = $since;
		}
		if ( $until ) {
			$sql     .= ' AND created_at <= %s';
			$params[] = $until;
		}
		return (int) $this->wpdb->get_var( $this->wpdb->prepare( $sql, ...$params ) );
	}

	public function findForUser( int $user_id, ?string $event = null, int $limit = 100 ): array {
		$limit = max( 1, min( 500, $limit ) );
		if ( null !== $event ) {
			$rows = $this->wpdb->get_results(
				$this->wpdb->prepare(
					'SELECT * FROM `' . $this->table() . '` WHERE user_id = %d AND event = %s ORDER BY id DESC LIMIT %d',
					$user_id,
					$event,
					$limit
				)
			);
		} else {
			$rows = $this->wpdb->get_results(
				$this->wpdb->prepare(
					'SELECT * FROM `' . $this->table() . '` WHERE user_id = %d ORDER BY id DESC LIMIT %d',
					$user_id,
					$limit
				)
			);
		}
		return array_map( static fn( $r ) => AnalyticsEvent::fromRow( $r ), $rows ?: array() );
	}

	/**
	 * Daily counts of an event in a range, keyed by YYYY-MM-DD.
	 *
	 * @return array<string,int>
	 */
	public function dailyCounts( string $event, string $since, string $until, ?int $user_id = null ): array {
		$sql    = 'SELECT DATE(created_at) AS day, COUNT(*) AS total FROM `' . $this->table() . '` WHERE event = %s AND created_at >= %s AND created_at <= %s';
		$params = array( $event, $since, $until );
		if ( null !== $user_id ) {
			$sql     .= ' AND user_id = %d';
			$params[] = $user_id;
		}
		$sql .= ' GROUP BY day ORDER BY day ASC';
		$rows = $this->wpdb->get_results( $this->wpdb->prepare( $sql, ...$params ) );
		$out  = array();
		foreach ( $rows ?: array() as $r ) {
			$out[ (string) $r->day ] = (int) $r->total;
		}
		return $out;
	}

	public function purgeOlderThan( string $cutoff ): int {
		$deleted = $this->wpdb->query(
			$this->wpdb->prepare(
				'DELETE FROM `' . $this->table() . '` WHERE created_at < %s',
				$cutoff
			)
		);
		return (int) $deleted;
	}
}
