<?php
/**
 * AnalyticsHooks — registers the Analytics REST controller and subscribes to
 * every domain event fired via EventDispatcher. Every event is recorded as
 * an analytics row with its payload. Recording is best-effort and never
 * affects the originating request.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Analytics\Hooks;

use ZymargCommunication\Bootstrap\ServiceProvider;
use ZymargCommunication\Core\Contracts\HookableInterface;
use ZymargCommunication\Infrastructure\Http\Controllers\RestController;
use ZymargCommunication\Modules\Analytics\Controllers\AnalyticsController;
use ZymargCommunication\Modules\Analytics\Services\AnalyticsService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AnalyticsHooks implements HookableInterface {

	public static function register(): void {
		$instance = new self();
		$instance->registerHooks();
	}

	private function registerHooks(): void {
		if ( ServiceProvider::has( AnalyticsController::class ) ) {
			$controller = ServiceProvider::get( AnalyticsController::class );
			if ( $controller instanceof AnalyticsController ) {
				RestController::register( $controller );
			}
		}

		// Generic listener: catches every plugin event via the shared hook
		// `zymarg_comm_event` fired by the dispatcher.
		add_action( 'zymarg_comm_event', array( __CLASS__, 'onAnyEvent' ), 20, 2 );

		// Explicit high-signal events — covers listeners that fire the
		// per-event action directly without going through the dispatcher.
		foreach ( array(
			'message_sent',
			'conversation_created',
			'conversation_closed',
			'participant_joined',
			'attachment_uploaded',
			'moderation_reported',
			'moderation_resolved',
			'spam_detected',
			'user_blocked',
			'notification_dispatched',
			'settings_updated',
		) as $event ) {
			add_action(
				'zymarg_comm_event_' . $event,
				static function ( $payload ) use ( $event ) {
					self::onAnyEvent( $event, is_array( $payload ) ? $payload : array() );
				},
				20,
				1
			);
		}
	}

	public static function onAnyEvent( string $event, array $payload ): void {
		if ( ! ServiceProvider::has( AnalyticsService::class ) ) {
			return;
		}
		$service = ServiceProvider::get( AnalyticsService::class );
		if ( $service instanceof AnalyticsService ) {
			$service->record( $event, $payload );
		}
	}
}
