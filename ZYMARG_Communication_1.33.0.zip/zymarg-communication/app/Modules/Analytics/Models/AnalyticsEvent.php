<?php
/**
 * Plain data object representing a single analytics event row.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Analytics\Models;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AnalyticsEvent {

	public function __construct(
		public int $id,
		public ?int $userId,
		public string $event,
		public array $payload,
		public string $createdAt
	) {}

	public static function fromRow( object $row ): self {
		$payload = array();
		if ( isset( $row->payload ) && is_string( $row->payload ) && '' !== $row->payload ) {
			$decoded = json_decode( $row->payload, true );
			if ( is_array( $decoded ) ) {
				$payload = $decoded;
			}
		}
		return new self(
			(int) ( $row->id ?? 0 ),
			isset( $row->user_id ) ? (int) $row->user_id : null,
			(string) ( $row->event ?? '' ),
			$payload,
			(string) ( $row->created_at ?? '' )
		);
	}

	public function toArray(): array {
		return array(
			'id'         => $this->id,
			'user_id'    => $this->userId,
			'event'      => $this->event,
			'payload'    => $this->payload,
			'created_at' => $this->createdAt,
		);
	}
}
