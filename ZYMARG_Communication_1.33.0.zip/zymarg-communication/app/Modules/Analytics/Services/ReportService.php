<?php
/**
 * ReportService — shared aggregation primitives used by both
 * AdminReportService (platform-wide) and UserReportService (per-user).
 *
 * All time ranges are supplied as ISO 8601 UTC strings.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Analytics\Services;

use ZymargCommunication\Core\Abstracts\AbstractService;
use ZymargCommunication\Modules\Analytics\Repositories\AnalyticsRepository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ReportService extends AbstractService {

	public function __construct( protected AnalyticsRepository $repository ) {}

	/**
	 * Resolve a caller-supplied "range" shorthand into concrete UTC bounds.
	 *
	 * Supported shorthands: `7d`, `30d`, `90d`, `all`.
	 *
	 * @return array{since:string,until:string,label:string}
	 */
	public function resolveRange( string $shorthand ): array {
		$shorthand = strtolower( trim( $shorthand ) );
		$now       = current_time( 'timestamp', true );
		$until     = gmdate( 'Y-m-d H:i:s', $now );

		$days = match ( $shorthand ) {
			'7d'  => 7,
			'30d' => 30,
			'90d' => 90,
			'all' => null,
			default => 30,
		};

		if ( null === $days ) {
			return array(
				'since' => '1970-01-01 00:00:00',
				'until' => $until,
				'label' => 'all',
			);
		}
		return array(
			'since' => gmdate( 'Y-m-d H:i:s', $now - ( $days * DAY_IN_SECONDS ) ),
			'until' => $until,
			'label' => $days . 'd',
		);
	}

	public function eventCount( string $event, array $range, ?int $user_id = null ): int {
		return $this->repository->countEvent( $event, $range['since'], $range['until'], $user_id );
	}

	public function distinctUsers( string $event, array $range ): int {
		return $this->repository->distinctUserCount( $event, $range['since'], $range['until'] );
	}

	public function daily( string $event, array $range, ?int $user_id = null ): array {
		$daily = $this->repository->dailyCounts( $event, $range['since'], $range['until'], $user_id );
		return $this->fillGaps( $range, $daily );
	}

	/**
	 * Compute the average response time in seconds between an initiating
	 * event and its follow-up event. Optionally filter by the responding
	 * user (for per-user seller response rates).
	 *
	 * Purely event-driven: uses `first_message_at` timestamps in payloads if
	 * present. Returns `null` when there is insufficient data.
	 */
	public function averageResponseSeconds( array $range, ?int $responder_id = null ): ?float {
		global $wpdb;
		$table = $wpdb->prefix . 'zc_analytics_events';

		$sql = "SELECT AVG(TIMESTAMPDIFF(SECOND, opened.created_at, replied.created_at)) FROM {$table} opened
				INNER JOIN {$table} replied
					ON JSON_EXTRACT(replied.payload, '$.conversation_id') = JSON_EXTRACT(opened.payload, '$.conversation_id')
				WHERE opened.event = %s AND replied.event = %s
				  AND opened.created_at >= %s AND opened.created_at <= %s
				  AND replied.created_at > opened.created_at";
		$params = array( 'conversation_created', 'message_sent', $range['since'], $range['until'] );
		if ( null !== $responder_id ) {
			$sql     .= ' AND replied.user_id = %d';
			$params[] = $responder_id;
		}

		$avg = $wpdb->get_var( $wpdb->prepare( $sql, ...$params ) );
		return null === $avg ? null : round( (float) $avg, 2 );
	}

	/**
	 * Percentage of conversations initiated in this range that received at
	 * least one reply (from the responder if supplied).
	 */
	public function responseRate( array $range, ?int $responder_id = null ): ?float {
		global $wpdb;
		$table = $wpdb->prefix . 'zc_analytics_events';

		$initiated = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$table} WHERE event = %s AND created_at >= %s AND created_at <= %s",
				'conversation_created',
				$range['since'],
				$range['until']
			)
		);
		if ( 0 === $initiated ) {
			return null;
		}

		$sql = "SELECT COUNT(DISTINCT JSON_EXTRACT(opened.payload, '$.conversation_id'))
				FROM {$table} opened
				INNER JOIN {$table} replied
					ON JSON_EXTRACT(replied.payload, '$.conversation_id') = JSON_EXTRACT(opened.payload, '$.conversation_id')
				WHERE opened.event = %s AND replied.event = %s
				  AND opened.created_at >= %s AND opened.created_at <= %s";
		$params = array( 'conversation_created', 'message_sent', $range['since'], $range['until'] );
		if ( null !== $responder_id ) {
			$sql     .= ' AND replied.user_id = %d';
			$params[] = $responder_id;
		}

		$responded = (int) $wpdb->get_var( $wpdb->prepare( $sql, ...$params ) );
		return round( ( $responded / $initiated ) * 100, 2 );
	}

	/**
	 * @param array<string,int> $counts
	 * @return array<int, array{date:string,count:int}>
	 */
	protected function fillGaps( array $range, array $counts ): array {
		$out   = array();
		$start = strtotime( $range['since'] );
		$end   = strtotime( $range['until'] );
		if ( ! $start || ! $end || $end - $start > 366 * DAY_IN_SECONDS ) {
			foreach ( $counts as $day => $c ) {
				$out[] = array( 'date' => $day, 'count' => $c );
			}
			return $out;
		}
		for ( $t = $start; $t <= $end; $t += DAY_IN_SECONDS ) {
			$day   = gmdate( 'Y-m-d', $t );
			$out[] = array( 'date' => $day, 'count' => (int) ( $counts[ $day ] ?? 0 ) );
		}
		return $out;
	}
}
