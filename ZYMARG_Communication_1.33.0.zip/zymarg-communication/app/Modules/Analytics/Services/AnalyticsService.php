<?php
/**
 * AnalyticsService — records analytics events. Called by AnalyticsHooks
 * whenever any module fires a domain event, and also directly by module code
 * that wants to record something that isn't fronted by an event.
 *
 * Recording is best-effort: this service never throws and never affects the
 * caller. Analytics is a passive observer.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Analytics\Services;

use ZymargCommunication\Core\Abstracts\AbstractService;
use ZymargCommunication\Modules\Analytics\Repositories\AnalyticsRepository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AnalyticsService extends AbstractService {

	public function __construct( private AnalyticsRepository $repository ) {}

	public function record( string $event, array $payload = array(), ?int $user_id = null ): void {
		try {
			if ( ! $this->isEnabled( 'analytics.tracking' ) ) {
				return;
			}
			$event = sanitize_key( $event );
			if ( '' === $event ) {
				return;
			}
			if ( null === $user_id ) {
				$user_id = $this->extractUserId( $payload );
			}
			$this->repository->record( $user_id, $event, $payload );
		} catch ( \Throwable $e ) {
			// Swallow — analytics must never break the caller.
		}
	}

	private function extractUserId( array $payload ): ?int {
		foreach ( array( 'user_id', 'sender_id', 'actor_id', 'initiated_by', 'uploader_id', 'reporter_id', 'moderator_id' ) as $key ) {
			if ( isset( $payload[ $key ] ) && (int) $payload[ $key ] > 0 ) {
				return (int) $payload[ $key ];
			}
		}
		return null;
	}
}
