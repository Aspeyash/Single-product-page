<?php
/**
 * AdminReportService — platform-wide metrics for the admin dashboard.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Analytics\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdminReportService extends ReportService {

	/**
	 * Complete admin dashboard payload for a range.
	 *
	 * @return array<string, mixed>
	 */
	public function dashboard( string $range_shorthand ): array {
		$range = $this->resolveRange( $range_shorthand );

		return array(
			'range' => $range,
			'totals' => array(
				'messages_sent'         => $this->eventCount( 'message_sent', $range ),
				'conversations_started' => $this->eventCount( 'conversation_created', $range ),
				'conversations_closed'  => $this->eventCount( 'conversation_closed', $range ),
				'attachments_uploaded'  => $this->eventCount( 'attachment_uploaded', $range ),
				'reports_filed'         => $this->eventCount( 'moderation_reported', $range ),
				'spam_flagged'          => $this->eventCount( 'spam_detected', $range ),
				'active_users'          => $this->distinctUsers( 'message_sent', $range ),
			),
			'response' => array(
				'average_seconds' => $this->averageResponseSeconds( $range ),
				'response_rate'   => $this->responseRate( $range ),
			),
			'daily' => array(
				'messages_sent'         => $this->daily( 'message_sent', $range ),
				'conversations_started' => $this->daily( 'conversation_created', $range ),
			),
			'moderation' => array(
				'pending' => $this->pendingModerationCount(),
			),
		);
	}

	private function pendingModerationCount(): int {
		global $wpdb;
		$table = $wpdb->prefix . 'zc_moderation_logs';
		$count = $wpdb->get_var(
			$wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE status = %s", 'pending' )
		);
		return (int) ( $count ?? 0 );
	}
}
