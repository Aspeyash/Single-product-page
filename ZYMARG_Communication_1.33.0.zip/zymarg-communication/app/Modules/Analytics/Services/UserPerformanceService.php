<?php
/**
 * UserPerformanceService - builds, caches and interprets the per-user
 * messaging report shown on the Analytics screen.
 *
 * CACHING MODEL (this is what keeps site load near zero):
 * The expensive walk over the message table NEVER runs on a page view. It runs
 * only when an administrator presses "Refresh now" or when the optional timer
 * fires. The finished table is stored in a non-autoloaded option, so it costs
 * nothing on ordinary requests and is a single tiny read when the tab is
 * opened. Setting the interval to "off" means no background work happens at
 * all, ever.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Analytics\Services;

use ZymargCommunication\Modules\Analytics\Repositories\UserPerformanceRepository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class UserPerformanceService {

	public const OPTION_PREFIX   = 'zymarg_comm_user_perf_';
	public const OPTION_INTERVAL = 'zymarg_comm_user_perf_interval';
	public const OPTION_INDEX    = 'zymarg_comm_user_perf_ranges';

	/** @return array<string,string> */
	public static function intervals(): array {
		return array(
			'off'        => __( 'Off - only when I press Refresh', 'zymarg-communication' ),
			'daily'      => __( 'Once a day', 'zymarg-communication' ),
			'twicedaily' => __( 'Twice a day', 'zymarg-communication' ),
			'sixhours'   => __( 'Every 6 hours', 'zymarg-communication' ),
			'hourly'     => __( 'Every hour', 'zymarg-communication' ),
		);
	}

	public static function interval(): string {
		$v = (string) get_option( self::OPTION_INTERVAL, 'daily' );
		return array_key_exists( $v, self::intervals() ) ? $v : 'daily';
	}

	/** @return array{since:string,until:string,label:string} */
	public function resolveRange( string $shorthand ): array {
		$now   = (int) current_time( 'timestamp', true );
		$until = gmdate( 'Y-m-d H:i:s', $now );
		$days  = match ( strtolower( trim( $shorthand ) ) ) {
			'7d'    => 7,
			'30d'   => 30,
			'90d'   => 90,
			'all'   => null,
			default => 30,
		};
		if ( null === $days ) {
			return array( 'since' => '1970-01-01 00:00:00', 'until' => $until, 'label' => 'all' );
		}
		return array(
			'since' => gmdate( 'Y-m-d H:i:s', $now - ( $days * DAY_IN_SECONDS ) ),
			'until' => $until,
			'label' => $days . 'd',
		);
	}

	private function optionKey( string $range ): string {
		return self::OPTION_PREFIX . preg_replace( '/[^a-z0-9]/', '', strtolower( $range ) );
	}

	/**
	 * Cached report. Never calculates unless asked to.
	 *
	 * @return array<string,mixed>|null Null when nothing has been built yet.
	 */
	public function cached( string $range ): ?array {
		$data = get_option( $this->optionKey( $range ), null );
		return is_array( $data ) ? $data : null;
	}

	/**
	 * Recalculate from the message table and store the result.
	 *
	 * @return array<string,mixed>
	 */
	public function rebuild( string $range ): array {
		$bounds  = $this->resolveRange( $range );
		$started = microtime( true );

		$rows = ( new UserPerformanceRepository() )->collect( $bounds['since'], $bounds['until'] );

		// Resolve names and roles once, here, so rendering touches no user
		// tables at all. cache_users() primes them in a single query.
		$ids = array_keys( $rows );
		if ( ! empty( $ids ) && function_exists( 'cache_users' ) ) {
			cache_users( $ids );
		}

		$out = array();
		foreach ( $rows as $uid => $row ) {
			$user  = get_userdata( (int) $uid );
			$row['name']  = $user ? (string) $user->display_name : sprintf( __( 'Deleted user (#%d)', 'zymarg-communication' ), (int) $uid );
			$row['email'] = $user ? (string) $user->user_email : '';
			$row['role']  = $user ? ( self::isSeller( (int) $uid ) ? 'seller' : 'buyer' ) : 'gone';
			$out[] = $row;
		}

		$report = array(
			'range'        => $bounds['label'],
			'rows'         => $out,
			'generated_at' => time(),
			'took_ms'      => (int) round( ( microtime( true ) - $started ) * 1000 ),
		);

		update_option( $this->optionKey( $range ), $report, false );
		$this->rememberRange( $range );

		return $report;
	}

	private function rememberRange( string $range ): void {
		$known = (array) get_option( self::OPTION_INDEX, array() );
		if ( ! in_array( $range, $known, true ) ) {
			$known[] = $range;
			update_option( self::OPTION_INDEX, $known, false );
		}
	}

	/**
	 * Scheduled rebuild. Only refreshes ranges an admin has actually looked
	 * at, so the timer never does speculative work.
	 */
	public static function rebuildScheduled(): void {
		if ( 'off' === self::interval() ) {
			return;
		}
		$svc   = new self();
		$known = (array) get_option( self::OPTION_INDEX, array( '30d' ) );
		if ( empty( $known ) ) {
			$known = array( '30d' );
		}
		foreach ( array_slice( $known, 0, 4 ) as $range ) {
			$svc->rebuild( (string) $range );
		}
	}

	/** Delete every cached table (used when the data would be stale/invalid). */
	public static function flush(): void {
		foreach ( (array) get_option( self::OPTION_INDEX, array() ) as $range ) {
			delete_option( self::OPTION_PREFIX . preg_replace( '/[^a-z0-9]/', '', strtolower( (string) $range ) ) );
		}
		delete_option( self::OPTION_INDEX );
	}

	/**
	 * Seller detection. Defers to the Vendor Dashboard plugin so this always
	 * agrees with who can actually open the vendor dashboard; the role list is
	 * only a fallback for when that plugin is inactive.
	 */
	public static function isSeller( int $user_id ): bool {
		if ( function_exists( 'zymarg_os_user_is_vendor' ) ) {
			return (bool) zymarg_os_user_is_vendor( $user_id );
		}
		if ( function_exists( 'dokan_is_user_seller' ) && dokan_is_user_seller( $user_id ) ) {
			return true;
		}
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return false;
		}
		if ( array_intersect( (array) $user->roles, array( 'seller', 'vendor', 'dc_vendor', 'wcfm_vendor' ) ) ) {
			return true;
		}
		return user_can( $user, 'dokandar' );
	}

	/**
	 * Plain-language suggestions. Computed at render time (not stored) so the
	 * rules can change without anyone needing to rebuild the table.
	 *
	 * @param array<string,mixed> $r
	 * @return array<int,array{text:string,tone:string}>
	 */
	public static function suggestions( array $r ): array {
		$out      = array();
		$med      = isset( $r['reply_med'] ) ? $r['reply_med'] : null;
		$rate     = isset( $r['rate'] ) ? $r['rate'] : null;
		$longest  = isset( $r['longest'] ) ? (int) $r['longest'] : 0;
		$msgs     = isset( $r['messages'] ) ? (int) $r['messages'] : 0;
		$answered = isset( $r['answered'] ) ? (int) $r['answered'] : 0;
		$unans    = isset( $r['unanswered'] ) ? (int) $r['unanswered'] : 0;
		$seen     = isset( $r['last_active'] ) ? (int) $r['last_active'] : 0;

		if ( $unans > 0 && 0 === $answered ) {
			$out[] = array( 'text' => __( 'Never replies - every message left unanswered', 'zymarg-communication' ), 'tone' => 'bad' );
		} elseif ( null !== $rate && $rate < 50.0 ) {
			$out[] = array( 'text' => __( 'Misses over half of incoming messages', 'zymarg-communication' ), 'tone' => 'bad' );
		}

		if ( null !== $med && $med > 43200 ) {
			$out[] = array( 'text' => __( 'Very slow to reply - suggest turning on email notifications', 'zymarg-communication' ), 'tone' => 'bad' );
		} elseif ( null !== $med && $med > 14400 ) {
			$out[] = array( 'text' => __( 'Slow to reply - typically several hours', 'zymarg-communication' ), 'tone' => 'warn' );
		}

		if ( $longest > 259200 ) {
			$out[] = array( 'text' => __( 'Left someone waiting more than 3 days', 'zymarg-communication' ), 'tone' => 'warn' );
		}

		if ( $seen > 0 && ( time() - $seen ) > ( 14 * DAY_IN_SECONDS ) ) {
			$out[] = array( 'text' => __( 'Gone quiet - no messages in over 2 weeks', 'zymarg-communication' ), 'tone' => 'warn' );
		}

		if ( empty( $out ) && $msgs >= 20 && null !== $med && $med <= 1800 && ( null === $rate || $rate >= 90.0 ) ) {
			$out[] = array( 'text' => __( 'Top performer - fast and consistent', 'zymarg-communication' ), 'tone' => 'good' );
		}

		if ( empty( $out ) ) {
			$out[] = array( 'text' => __( 'Nothing to flag', 'zymarg-communication' ), 'tone' => 'ok' );
		}

		return $out;
	}
}
