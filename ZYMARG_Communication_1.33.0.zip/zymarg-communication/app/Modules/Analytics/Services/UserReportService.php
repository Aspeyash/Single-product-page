<?php
/**
 * UserReportService — metrics scoped to a single user (their own dashboard).
 *
 * Every method requires an explicit `$user_id` supplied by the caller; the
 * REST controller passes `get_current_user_id()`. Nothing in this class ever
 * returns data for another user.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Analytics\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class UserReportService extends ReportService {

	public function dashboard( int $user_id, string $range_shorthand ): array {
		$user_id = max( 0, $user_id );
		$range   = $this->resolveRange( $range_shorthand );

		return array(
			'user_id' => $user_id,
			'range'   => $range,
			'totals'  => array(
				'messages_sent'         => $this->eventCount( 'message_sent', $range, $user_id ),
				'conversations_started' => $this->eventCount( 'conversation_created', $range, $user_id ),
				'attachments_uploaded'  => $this->eventCount( 'attachment_uploaded', $range, $user_id ),
			),
			'response' => array(
				'average_seconds' => $this->averageResponseSeconds( $range, $user_id ),
				'response_rate'   => $this->responseRate( $range, $user_id ),
			),
			'daily' => array(
				'messages_sent'         => $this->daily( 'message_sent', $range, $user_id ),
				'conversations_started' => $this->daily( 'conversation_created', $range, $user_id ),
			),
		);
	}
}
