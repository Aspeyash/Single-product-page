<?php
/**
 * REST endpoints for analytics dashboards.
 *
 *   GET /analytics/admin  — platform-wide dashboard, admin only.
 *   GET /analytics/me     — current user's own dashboard.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Analytics\Controllers;

use WP_REST_Request;
use WP_REST_Response;
use ZymargCommunication\Core\Abstracts\AbstractController;
use ZymargCommunication\Infrastructure\Http\Middleware\AuthMiddleware;
use ZymargCommunication\Modules\Analytics\Services\AdminReportService;
use ZymargCommunication\Modules\Analytics\Services\UserReportService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AnalyticsController extends AbstractController {

	public function __construct(
		private AdminReportService $admin,
		private UserReportService $user
	) {}

	public function registerRoutes(): void {
		register_rest_route(
			self::NAMESPACE,
			'/analytics/admin',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'admin' ),
				'permission_callback' => static fn( $request ) => AuthMiddleware::requireAdmin( $request ),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/analytics/me',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'me' ),
				'permission_callback' => array( AuthMiddleware::class, 'requireLoggedIn' ),
			)
		);
	}

	public function admin( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle( function () use ( $request ) {
			$range = (string) $this->param( $request, 'range', '30d' );
			return array( 'dashboard' => $this->admin->dashboard( $range ) );
		} );
	}

	public function me( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle( function () use ( $request ) {
			$this->requireAuthenticated();
			$range = (string) $this->param( $request, 'range', '30d' );
			return array( 'dashboard' => $this->user->dashboard( $this->currentUserId(), $range ) );
		} );
	}
}
