<?php
/**
 * ProductCard — plain data object representing a shared product card in chat.
 *
 * Persisted as part of message body (JSON block) so it survives without a new table.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Marketplace\Models;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ProductCard {

	public function __construct(
		public int $productId,
		public string $title,
		public string $permalink,
		public ?string $priceHtml = null,
		public ?string $imageUrl = null,
		public ?int $vendorUserId = null,
		public ?string $vendorName = null
	) {}

	public function toArray(): array {
		return array(
			'product_id'     => $this->productId,
			'title'          => $this->title,
			'permalink'      => $this->permalink,
			'price_html'     => $this->priceHtml,
			'image_url'      => $this->imageUrl,
			'vendor_user_id' => $this->vendorUserId,
			'vendor_name'    => $this->vendorName,
		);
	}

	public static function fromArray( array $data ): self {
		return new self(
			(int) ( $data['product_id'] ?? 0 ),
			(string) ( $data['title'] ?? '' ),
			(string) ( $data['permalink'] ?? '' ),
			isset( $data['price_html'] ) ? (string) $data['price_html'] : null,
			isset( $data['image_url'] ) ? (string) $data['image_url'] : null,
			isset( $data['vendor_user_id'] ) ? (int) $data['vendor_user_id'] : null,
			isset( $data['vendor_name'] ) ? (string) $data['vendor_name'] : null
		);
	}

	/** Encode the card into a chat body block that the frontend renders as a card. */
	public function toBodyBlock(): string {
		$json = wp_json_encode( $this->toArray() );
		return "[zc-product-card]{$json}[/zc-product-card]";
	}
}
