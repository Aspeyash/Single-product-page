<?php
/**
 * MarketplaceContext — plain data object representing the marketplace context of
 * a conversation surface (store page, product, order, or plain inbox).
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Marketplace\Models;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class MarketplaceContext {

	public const TYPE_STORE   = 'store';
	public const TYPE_PRODUCT = 'product';
	public const TYPE_ORDER   = 'order';
	public const TYPE_INBOX   = 'inbox';

	public function __construct(
		public string $type,
		public ?int $id = null,
		public ?int $vendorUserId = null,
		public ?int $buyerUserId = null,
		public ?string $title = null,
		public ?string $permalink = null,
		public array $meta = array()
	) {}

	public function toArray(): array {
		return array(
			'type'           => $this->type,
			'id'             => $this->id,
			'vendor_user_id' => $this->vendorUserId,
			'buyer_user_id'  => $this->buyerUserId,
			'title'          => $this->title,
			'permalink'      => $this->permalink,
			'meta'           => $this->meta,
		);
	}
}
