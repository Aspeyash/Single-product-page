<?php
/**
 * MarketplaceController — REST endpoints for marketplace surfaces.
 *
 * Routes (namespace zymarg-comm/v1):
 *   GET  /marketplace/unread-count            — unread badge count for current user
 *   GET  /marketplace/context/(?P<type>...)/(?P<id>\d+)  — resolve context details
 *   POST /marketplace/product-share           — attach a product card to a conversation
 *   POST /marketplace/order-chat              — open (or create) the order chat
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Marketplace\Controllers;

use WP_REST_Request;
use WP_REST_Response;
use ZymargCommunication\Core\Abstracts\AbstractController;
use ZymargCommunication\Infrastructure\Http\Middleware\AuthMiddleware;
use ZymargCommunication\Infrastructure\Http\Middleware\NonceMiddleware;
use ZymargCommunication\Modules\Marketplace\Repositories\MarketplaceRepository;
use ZymargCommunication\Modules\Marketplace\Services\OrderChatService;
use ZymargCommunication\Modules\Marketplace\Services\ProductSharingService;
use ZymargCommunication\Modules\Marketplace\Services\StoreChatService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class MarketplaceController extends AbstractController {

	public function __construct(
		private MarketplaceRepository $repository,
		private ProductSharingService $sharing,
		private OrderChatService $orderChat,
		private StoreChatService $storeChat
	) {}

	public function registerRoutes(): void {
		register_rest_route(
			self::NAMESPACE,
			'/marketplace/unread-count',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'unreadCount' ),
				'permission_callback' => array( AuthMiddleware::class, 'requireLoggedIn' ),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/marketplace/context/(?P<type>[a-z_]+)/(?P<id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'context' ),
				'permission_callback' => array( AuthMiddleware::class, 'requireLoggedIn' ),
				'args'                => array(
					'type' => array( 'type' => 'string' ),
					'id'   => array( 'type' => 'integer' ),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/marketplace/product-share',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'shareProduct' ),
				'permission_callback' => array( $this, 'writeGuard' ),
				'args'                => array(
					'conversation_id' => array( 'type' => 'integer', 'required' => true ),
					'product_id'      => array( 'type' => 'integer', 'required' => true ),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/marketplace/order-chat',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'openOrderChat' ),
				'permission_callback' => array( $this, 'writeGuard' ),
				'args'                => array(
					'order_id' => array( 'type' => 'integer', 'required' => true ),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/marketplace/store-chat',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'openStoreChat' ),
				'permission_callback' => array( $this, 'writeGuard' ),
				'args'                => array(
					'seller_id' => array( 'type' => 'integer', 'required' => true ),
				),
			)
		);
	}

	/** Combined auth + nonce guard for POST routes. */
	public function writeGuard( WP_REST_Request $request ) {
		$auth = AuthMiddleware::requireLoggedIn( $request );
		if ( $auth instanceof \WP_Error ) {
			return $auth;
		}
		$nonce = NonceMiddleware::verify( $request );
		if ( $nonce instanceof \WP_Error ) {
			return $nonce;
		}
		return true;
	}

	public function unreadCount( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle( function () {
			return array(
				'user_id' => $this->currentUserId(),
				'count'   => $this->repository->unreadCountForUser( $this->currentUserId() ),
			);
		} );
	}

	public function context( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle( function () use ( $request ) {
			$type = (string) $this->param( $request, 'type', '' );
			$id   = (int) $this->param( $request, 'id', 0 );
			if ( $id <= 0 || '' === $type ) {
				return $this->fail( 'bad_request', __( 'Invalid context.', 'zymarg-communication' ), 400 );
			}
			return $this->repository->resolveContext( $type, $id );
		} );
	}

	public function shareProduct( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle( function () use ( $request ) {
			$conversation_id = (int) $this->param( $request, 'conversation_id', 0 );
			$product_id      = (int) $this->param( $request, 'product_id', 0 );
			return $this->sharing->share( $conversation_id, $this->currentUserId(), $product_id );
		} );
	}

	public function openOrderChat( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle( function () use ( $request ) {
			$order_id = (int) $this->param( $request, 'order_id', 0 );
			return $this->orderChat->openForOrder( $order_id, $this->currentUserId() );
		} );
	}

	public function openStoreChat( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle( function () use ( $request ) {
			$seller_id = (int) $this->param( $request, 'seller_id', 0 );
			return $this->storeChat->openForStore( $seller_id, $this->currentUserId() );
		} );
	}
}
