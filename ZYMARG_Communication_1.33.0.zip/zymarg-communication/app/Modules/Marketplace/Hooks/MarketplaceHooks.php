<?php
/**
 * MarketplaceHooks — wires the marketplace module into WordPress.
 *
 *  - Registers REST routes on `rest_api_init` (via RestController queue).
 *  - Renders the store popup container on `wp_footer` (§ 13.5).
 *  - Enqueues the chatbox CSS/JS + design tokens on frontend surfaces where
 *    they are needed.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Marketplace\Hooks;

use ZymargCommunication\Bootstrap\ServiceProvider;
use ZymargCommunication\Core\Contracts\HookableInterface;
use ZymargCommunication\Infrastructure\Http\Controllers\RestController;
use ZymargCommunication\Modules\Marketplace\Controllers\MarketplaceController;
use ZymargCommunication\Modules\Marketplace\Services\StorePopupService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class MarketplaceHooks implements HookableInterface {

	private MarketplaceController $controller;
	private StorePopupService $popup;

	public static function register(): void {
		$instance = new self();
		$instance->registerHooks();
	}

	private function registerHooks(): void {
		$this->controller = ServiceProvider::get( MarketplaceController::class );
		$this->popup      = ServiceProvider::get( StorePopupService::class );

		RestController::register( $this->controller );

		add_action( 'wp_enqueue_scripts', array( $this, 'enqueueFrontend' ) );
	}

	public function enqueueFrontend(): void {
		// Frontend CSS/JS is enqueued centrally by
		// ZymargCommunication\Frontend\AssetEnqueue as of v1.12.0.
	}
}
