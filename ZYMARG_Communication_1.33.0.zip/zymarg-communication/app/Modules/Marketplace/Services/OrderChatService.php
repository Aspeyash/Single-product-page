<?php
/**
 * OrderChatService — resolves the conversation that pairs a buyer and vendor
 * around a specific order, creating one on first use.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Marketplace\Services;

use ZymargCommunication\Core\Abstracts\AbstractService;
use ZymargCommunication\Core\Exceptions\NotFoundException;
use ZymargCommunication\Core\Exceptions\ValidationException;
use ZymargCommunication\Modules\Conversation\Services\ConversationService;
use ZymargCommunication\Modules\Marketplace\Repositories\MarketplaceRepository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class OrderChatService extends AbstractService {

	public function __construct(
		private MarketplaceRepository $repository,
		private ConversationService $conversations
	) {}

	/**
	 * Open or create the order chat for a given order.
	 *
	 * @param int $order_id      Order ID (WooCommerce / marketplace).
	 * @param int $current_user  Current user opening the chat.
	 *
	 * @return array<string, mixed> Conversation view.
	 */
	public function openForOrder( int $order_id, int $current_user ): array {
		if ( ! $this->isEnabled( 'marketplace.order_chat' ) ) {
			throw new ValidationException( __( 'Order chat is disabled.', 'zymarg-communication' ), array( 'flag' => 'off' ) );
		}

		/**
		 * Integrators (Compatibility.php / WooCommerce bridge) return the
		 * buyer_user_id and vendor_user_id for a given order via this filter.
		 *
		 * @param array|null $participants ['buyer_user_id'=>int,'vendor_user_id'=>int] or null.
		 * @param int        $order_id     Order ID.
		 */
		$participants = apply_filters( 'zymarg_comm_marketplace_order_participants', null, $order_id );
		if ( ! is_array( $participants ) || empty( $participants['buyer_user_id'] ) || empty( $participants['vendor_user_id'] ) ) {
			throw new NotFoundException( __( 'Order participants could not be resolved.', 'zymarg-communication' ) );
		}

		$buyer_id  = (int) $participants['buyer_user_id'];
		$vendor_id = (int) $participants['vendor_user_id'];

		if ( $current_user !== $buyer_id && $current_user !== $vendor_id && ! current_user_can( 'manage_options' ) ) {
			throw new ValidationException( __( 'You are not associated with this order.', 'zymarg-communication' ), array( 'order_id' => 'forbidden' ) );
		}

		// Determine initiator vs recipient from the perspective of the current user.
		$initiator = $current_user;
		$recipient = ( $current_user === $buyer_id ) ? $vendor_id : $buyer_id;

		return $this->conversations->create( $initiator, $recipient, 'order', $order_id );
	}
}
