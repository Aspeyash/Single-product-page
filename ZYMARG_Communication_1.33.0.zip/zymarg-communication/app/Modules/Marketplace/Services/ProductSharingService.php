<?php
/**
 * ProductSharingService — attaches a structured product card to a conversation.
 *
 * Sends a message whose body encodes a `[zc-product-card]{json}[/zc-product-card]`
 * block so no new database table is required. Frontend renders it as a card.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Marketplace\Services;

use ZymargCommunication\Core\Abstracts\AbstractService;
use ZymargCommunication\Core\Exceptions\NotFoundException;
use ZymargCommunication\Core\Exceptions\ValidationException;
use ZymargCommunication\Modules\Marketplace\Models\ProductCard;
use ZymargCommunication\Modules\Marketplace\Repositories\MarketplaceRepository;
use ZymargCommunication\Modules\Message\Services\MessageService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ProductSharingService extends AbstractService {

	public function __construct(
		private MarketplaceRepository $repository,
		private MessageService $messages
	) {}

	/**
	 * Share a product into a conversation.
	 *
	 * @return array<string, mixed> The created message row.
	 */
	public function share( int $conversation_id, int $sender_id, int $product_id ): array {
		if ( ! $this->isEnabled( 'marketplace.product_sharing' ) ) {
			throw new ValidationException( __( 'Product sharing is disabled.', 'zymarg-communication' ), array( 'flag' => 'off' ) );
		}

		$product = get_post( $product_id );
		if ( ! $product ) {
			throw new NotFoundException( __( 'Product not found.', 'zymarg-communication' ) );
		}

		/**
		 * Filters the product card payload before sharing.
		 * Allows WooCommerce or vendor plugins to inject price/image.
		 *
		 * @param array $card       Card fields.
		 * @param int   $product_id Product post ID.
		 */
		$card_data = apply_filters(
			'zymarg_comm_marketplace_product_card',
			array(
				'product_id'     => $product_id,
				'title'          => (string) get_the_title( $product_id ),
				'permalink'      => (string) get_permalink( $product_id ),
				'price_html'     => null,
				'image_url'      => (string) get_the_post_thumbnail_url( $product_id, 'medium' ),
				'vendor_user_id' => (int) get_post_field( 'post_author', $product_id ),
				'vendor_name'    => null,
			),
			$product_id
		);

		$card = ProductCard::fromArray( $card_data );
		return $this->messages->send( $conversation_id, $sender_id, $card->toBodyBlock(), null );
	}
}
