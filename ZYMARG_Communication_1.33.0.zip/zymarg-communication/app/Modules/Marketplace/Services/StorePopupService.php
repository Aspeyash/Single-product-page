<?php
/**
 * StorePopupService — renders the store page chat popup container and
 * localised bootstrap data. Injected via `wp_footer` (§ 13.5). Only outputs
 * markup when the current user is logged in and the `surface.popup` flag is on.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Marketplace\Services;

use ZymargCommunication\Core\Abstracts\AbstractService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class StorePopupService extends AbstractService {

	public function isActive(): bool {
		if ( ! is_user_logged_in() ) {
			return false;
		}
		if ( ! $this->isEnabled( 'surface.popup' ) ) {
			return false;
		}
		/**
		 * Filters whether the store popup should be enqueued on the current request.
		 * Integrators (e.g. Compatibility.php) may narrow this to store pages only.
		 */
		return (bool) apply_filters( 'zymarg_comm_popup_should_render', true );
	}

	/** Output the hidden popup root element. Called on `wp_footer`. */
	public function renderPopupContainer(): void {
		if ( ! $this->isActive() ) {
			return;
		}
		echo '<div id="zymarg-comm-popup-root" class="zymarg-comm-popup-root" data-zc-role="buyer" hidden></div>';
	}

	/** Data localised into the frontend for the popup component. */
	public function bootstrapData(): array {
		$user_id = get_current_user_id();
		return array(
			'restUrl'    => esc_url_raw( rest_url( 'zymarg-comm/v1/' ) ),
			'nonce'      => wp_create_nonce( 'wp_rest' ),
			'userId'     => $user_id,
			'popupOn'    => $this->isEnabled( 'surface.popup' ),
			'inboxUrl'   => (string) home_url( '/messages/' ),
			'vendorUrl'  => (string) home_url( '/vendor-messages/' ),
		);
	}

	/** Render fallback for the [zymarg_comm_popup] shortcode. */
	public function shortcode(): string {
		if ( ! $this->isActive() ) {
			return '';
		}
		return '<div class="zymarg-comm-popup-root" data-zc-role="buyer" hidden></div>';
	}
}
