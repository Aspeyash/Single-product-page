<?php
/**
 * BuyerInboxService — renders the buyer full-inbox surface (`/messages/`).
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Marketplace\Services;

use ZymargCommunication\Core\Abstracts\AbstractService;
use ZymargCommunication\Modules\Marketplace\Repositories\MarketplaceRepository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BuyerInboxService extends AbstractService {

	public function __construct( private MarketplaceRepository $repository ) {}

	public function render(): string {
		if ( ! $this->isEnabled( 'surface.buyer_inbox' ) ) {
			return '';
		}
		if ( ! is_user_logged_in() ) {
			return '<div class="zymarg-comm-container zymarg-comm-inbox zymarg-comm-inbox--empty">'
				. '<p class="zymarg-comm-inbox__notice">'
				. esc_html__( 'Please log in to view your messages.', 'zymarg-communication' )
				. '</p></div>';
		}

		$user_id = get_current_user_id();
		$unread  = $this->repository->unreadCountForUser( $user_id );

		$html  = '<div class="zymarg-comm-container zymarg-comm-inbox" data-zc-role="buyer" data-zc-user="' . esc_attr( (string) $user_id ) . '">';
		$html .= '<header class="zymarg-comm-inbox__header">';
		$html .= '<h1 class="zymarg-comm-inbox__title">' . esc_html__( 'Messages', 'zymarg-communication' ) . '</h1>';
		$html .= '<span class="zymarg-comm-unread-badge" data-zc-unread>' . esc_html( (string) $unread ) . '</span>';
		$html .= '</header>';
		$html .= '<div class="zymarg-comm-inbox__body">';
		$html .= '<aside class="zymarg-comm-inbox__list" data-zc-conversation-list></aside>';
		$html .= '<section class="zymarg-comm-chatbox" data-zc-chatbox data-zc-context-type="inbox">';
		$html .= '<div class="zymarg-comm-chatbox__empty">' . esc_html__( 'Select a conversation to start chatting.', 'zymarg-communication' ) . '</div>';
		$html .= '</section>';
		$html .= '</div></div>';
		return $html;
	}
}
