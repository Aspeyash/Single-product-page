<?php
/**
 * StoreChatService - resolves (or creates) the buyer/seller conversation for a
 * storefront "Chat" button and returns the data the popup needs to open it.
 *
 * The store-page plugin renders [data-chat-btn data-seller-id] and this plugin
 * owns the click -> popup wiring (see the ZYMARG_SP_Chat contract). This is the
 * REST side of that contract.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Marketplace\Services;

use ZymargCommunication\Core\Abstracts\AbstractService;
use ZymargCommunication\Core\Exceptions\NotFoundException;
use ZymargCommunication\Core\Exceptions\ValidationException;
use ZymargCommunication\Modules\Conversation\Services\ConversationService;
use ZymargCommunication\Modules\Marketplace\Repositories\MarketplaceRepository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class StoreChatService extends AbstractService {

	public function __construct(
		private MarketplaceRepository $repository,
		private ConversationService $conversations
	) {}

	/**
	 * Open (or create) the conversation between the current user and a store's
	 * vendor, ready for the popup to display.
	 *
	 * @param int $seller_id    Store/seller identifier from data-seller-id.
	 * @param int $current_user Current logged-in user opening the chat.
	 *
	 * @return array<string, mixed> conversation_id, is_new, counterpart_name, store_name.
	 */
	public function openForStore( int $seller_id, int $current_user ): array {
		if ( $seller_id < 1 ) {
			throw new ValidationException(
				__( 'A valid seller is required.', 'zymarg-communication' ),
				array( 'seller_id' => 'Must be a positive integer.' )
			);
		}

		// The store/seller id maps to the vendor's user id; integrators may
		// override the resolution when store id and user id differ.
		$recipient_id = $this->repository->resolveVendorUserId( 'store', $seller_id );
		if ( null === $recipient_id ) {
			$recipient_id = $seller_id;
		}

		if ( ! get_userdata( $recipient_id ) ) {
			throw new NotFoundException( __( 'Seller could not be found.', 'zymarg-communication' ) );
		}

		if ( $recipient_id === $current_user ) {
			throw new ValidationException(
				__( 'You cannot start a chat with your own store.', 'zymarg-communication' ),
				array( 'seller_id' => 'self' )
			);
		}

		// Reuse an existing buyer/seller thread when one already exists so repeat
		// clicks never spawn duplicate conversations.
		$existing_id = $this->repository->findConversationBetween( $current_user, $recipient_id );

		if ( null !== $existing_id ) {
			$conversation_id = $existing_id;
			$is_new          = false;
		} else {
			$conversation    = $this->conversations->create( $current_user, $recipient_id, 'store', $seller_id );
			$conversation_id = (int) ( $conversation['id'] ?? 0 );
			$is_new          = true;
		}

		if ( $conversation_id < 1 ) {
			throw new NotFoundException( __( 'Conversation could not be opened.', 'zymarg-communication' ) );
		}

		return array(
			'conversation_id'  => $conversation_id,
			'is_new'           => $is_new,
			'counterpart_name' => $this->vendorDisplayName( $recipient_id ),
			'store_name'       => $this->storeName( 'store', $seller_id, $recipient_id ),
		);
	}

	private function vendorDisplayName( int $user_id ): string {
		$user = get_userdata( $user_id );
		return $user ? (string) $user->display_name : '';
	}

	private function storeName( string $context_type, int $context_id, int $vendor_id ): string {
		$ctx   = $this->repository->resolveContext( $context_type, $context_id );
		$title = isset( $ctx['title'] ) ? trim( (string) $ctx['title'] ) : '';
		if ( '' !== $title ) {
			return $title;
		}
		return $this->vendorDisplayName( $vendor_id );
	}
}
