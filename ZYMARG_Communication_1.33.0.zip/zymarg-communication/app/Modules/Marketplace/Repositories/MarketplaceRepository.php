<?php
/**
 * MarketplaceRepository — resolves marketplace context, unread counts, and
 * vendor/buyer inbox summaries without introducing a new database table.
 *
 * Reads WordPress core objects, uses filters `zymarg_comm_marketplace_*` for
 * third-party plugin integrators to provide vendor/product/order data.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Marketplace\Repositories;

use ZymargCommunication\Modules\Conversation\Repositories\ConversationRepository;
use ZymargCommunication\Modules\Message\Repositories\MessageRepository;
use ZymargCommunication\Modules\Conversation\Repositories\ParticipantRepository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class MarketplaceRepository {

	public function __construct(
		private ConversationRepository $conversations,
		private MessageRepository $messages,
		private ParticipantRepository $participants
	) {}

	/**
	 * Count unread conversations for a user.
	 * Uses last_read_at vs conversation last_message_at.
	 *
	 * @return int Number of conversations with unread activity.
	 */
	public function unreadCountForUser( int $user_id ): int {
		$rows = $this->conversations->findForUser( $user_id, 100, 0 );
		$unread = 0;
		foreach ( $rows as $conv ) {
			$participant = $this->participants->findByUserAndConversation( $user_id, $conv->id );
			if ( ! $participant ) {
				continue;
			}
			$last_msg   = $conv->lastMessageAt;
			$last_read  = $participant->lastReadAt ?? null;
			if ( null === $last_msg ) {
				continue;
			}
			if ( null === $last_read || strtotime( (string) $last_msg ) > strtotime( (string) $last_read ) ) {
				$unread++;
			}
		}
		return $unread;
	}

	/**
	 * Resolve the vendor user ID for a store context.
	 * Delegates to third-party integrators via filter; falls back to post author.
	 */
	public function resolveVendorUserId( string $context_type, int $context_id ): ?int {
		/**
		 * Filters the resolved vendor user ID for a marketplace context.
		 *
		 * @param int|null $vendor_user_id Resolved vendor user ID or null.
		 * @param string   $context_type   'store'|'product'|'order'.
		 * @param int      $context_id     Context ID.
		 */
		$vendor = apply_filters( 'zymarg_comm_marketplace_resolve_vendor', null, $context_type, $context_id );
		if ( is_int( $vendor ) && $vendor > 0 ) {
			return $vendor;
		}
		if ( 'product' === $context_type && function_exists( 'get_post_field' ) ) {
			$author = (int) get_post_field( 'post_author', $context_id );
			return $author > 0 ? $author : null;
		}
		return null;
	}

	/**
	 * Find an existing conversation shared by two users, if any.
	 *
	 * Reuses findForUser + counterpart lookup so we avoid bespoke SQL.
	 *
	 * @return int|null Conversation ID, or null when none exists yet.
	 */
	public function findConversationBetween( int $user_a, int $user_b ): ?int {
		$rows = $this->conversations->findForUser( $user_a, 100, 0 );
		foreach ( $rows as $conv ) {
			if ( $this->participants->counterpartUserId( (int) $conv->id, $user_a ) === $user_b ) {
				return (int) $conv->id;
			}
		}
		return null;
	}

	/**
	 * Resolve marketplace context details (title, permalink, vendor).
	 */
	public function resolveContext( string $context_type, int $context_id ): array {
		/**
		 * Filters marketplace context details for rendering.
		 *
		 * @param array|null $context Array with title/permalink/vendor_user_id/meta or null to fall back.
		 * @param string     $type    Context type.
		 * @param int        $id      Context ID.
		 */
		$ctx = apply_filters( 'zymarg_comm_marketplace_context', null, $context_type, $context_id );
		if ( is_array( $ctx ) ) {
			return $ctx;
		}
		$title     = get_the_title( $context_id );
		$permalink = (string) get_permalink( $context_id );
		return array(
			'title'          => $title ?: '',
			'permalink'      => $permalink,
			'vendor_user_id' => $this->resolveVendorUserId( $context_type, $context_id ),
			'meta'           => array(),
		);
	}

	/**
	 * Enrich a conversation array with the counterpart display data for inbox rendering.
	 *
	 * @return array<string, mixed>
	 */
	public function conversationSummary( int $conversation_id, int $viewer_user_id ): array {
		$conv = $this->conversations->findModel( $conversation_id );
		if ( ! $conv ) {
			return array();
		}
		$counterpart_id = $this->participants->counterpartUserId( $conversation_id, $viewer_user_id );
		$counterpart    = $counterpart_id ? get_userdata( $counterpart_id ) : null;

		return array(
			'id'                    => $conv->id,
			'status'                => $conv->status,
			'context_type'          => $conv->contextType,
			'context_id'            => $conv->contextId,
			'is_pinned'             => $conv->isPinned,
			'last_message_at'       => $conv->lastMessageAt,
			'counterpart_user_id'   => $counterpart_id,
			'counterpart_name'      => $counterpart ? $counterpart->display_name : '',
			'counterpart_avatar'    => $counterpart_id ? get_avatar_url( $counterpart_id ) : '',
		);
	}
}
