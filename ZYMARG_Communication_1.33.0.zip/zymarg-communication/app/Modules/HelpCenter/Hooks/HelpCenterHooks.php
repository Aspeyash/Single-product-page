<?php
/**
 * HelpCenterHooks — registers the HelpCenter REST controller.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\HelpCenter\Hooks;

use ZymargCommunication\Bootstrap\ServiceProvider;
use ZymargCommunication\Core\Contracts\HookableInterface;
use ZymargCommunication\Infrastructure\Http\Controllers\RestController;
use ZymargCommunication\Modules\HelpCenter\Controllers\HelpCenterController;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class HelpCenterHooks implements HookableInterface {

	public static function register(): void {
		$instance = new self();
		$instance->registerHooks();
	}

	private function registerHooks(): void {
		if ( ! ServiceProvider::has( HelpCenterController::class ) ) {
			return;
		}
		$controller = ServiceProvider::get( HelpCenterController::class );
		if ( $controller instanceof HelpCenterController ) {
			RestController::register( $controller );
		}
	}
}
