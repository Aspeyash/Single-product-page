<?php
/**
 * DocumentationService — serves technical documentation for developers:
 * REST API reference, PHP API reference, JS SDK reference, hooks/filters
 * reference, mobile integration guide. Reads from `/docs/api/`.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\HelpCenter\Services;

use ZymargCommunication\Core\Abstracts\AbstractService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class DocumentationService extends AbstractService {

	private const TOPICS = array(
		'rest'   => 'rest-api',
		'php'    => 'php-api',
		'js'     => 'js-sdk',
		'hooks'  => 'hooks-and-filters',
		'mobile' => 'mobile-integration',
		'sdk'    => 'sdk',
	);

	public function listTopics(): array {
		return array_keys( self::TOPICS );
	}

	public function topic( string $key ): array {
		$key  = array_key_exists( $key, self::TOPICS ) ? $key : 'rest';
		$slug = self::TOPICS[ $key ];
		$path = trailingslashit( ZYMARG_COMM_DIR ) . 'docs/api/' . $slug . '.md';

		if ( ! file_exists( $path ) ) {
			return array(
				'topic' => $key,
				'title' => ucwords( str_replace( '-', ' ', $slug ) ),
				'body'  => '',
			);
		}

		$body  = (string) @file_get_contents( $path );
		$title = $this->firstHeading( $body ) ?: ucwords( str_replace( '-', ' ', $slug ) );

		return array(
			'topic' => $key,
			'title' => $title,
			'body'  => $body,
		);
	}

	private function firstHeading( string $markdown ): string {
		if ( preg_match( '/^#\s+(.+)$/m', $markdown, $m ) ) {
			return trim( $m[1] );
		}
		return '';
	}
}
