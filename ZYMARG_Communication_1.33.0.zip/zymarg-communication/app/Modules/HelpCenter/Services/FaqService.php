<?php
/**
 * FaqService — manages FAQ articles stored in the WordPress options table
 * via HelpCenterRepository. Read is public; write is admin-only (guarded at
 * the controller layer).
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\HelpCenter\Services;

use ZymargCommunication\Core\Abstracts\AbstractService;
use ZymargCommunication\Core\Exceptions\NotFoundException;
use ZymargCommunication\Core\Exceptions\ValidationException;
use ZymargCommunication\Modules\HelpCenter\Models\HelpArticle;
use ZymargCommunication\Modules\HelpCenter\Repositories\HelpCenterRepository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class FaqService extends AbstractService {

	public function __construct( private HelpCenterRepository $repository ) {}

	public function list(): array {
		return array_map( static fn( $a ) => $a->toArray(), $this->repository->all() );
	}

	public function get( string $slug ): array {
		$article = $this->repository->findBySlug( sanitize_key( $slug ) );
		if ( ! $article ) {
			throw new NotFoundException( __( 'FAQ article not found.', 'zymarg-communication' ) );
		}
		return $article->toArray();
	}

	public function upsert( array $input ): array {
		$slug = sanitize_key( (string) ( $input['slug'] ?? '' ) );
		if ( '' === $slug ) {
			throw new ValidationException( __( 'FAQ slug is required.', 'zymarg-communication' ), array( 'slug' => 'required' ) );
		}
		$title = trim( (string) ( $input['title'] ?? '' ) );
		if ( '' === $title ) {
			throw new ValidationException( __( 'FAQ title is required.', 'zymarg-communication' ), array( 'title' => 'required' ) );
		}
		$body    = (string) ( $input['body'] ?? '' );
		$section = sanitize_key( (string) ( $input['section'] ?? 'faq' ) );

		$article = new HelpArticle( $slug, $title, wp_kses_post( $body ), $section );
		return $this->repository->save( $article )->toArray();
	}

	public function delete( string $slug ): bool {
		return $this->repository->delete( sanitize_key( $slug ) );
	}
}
