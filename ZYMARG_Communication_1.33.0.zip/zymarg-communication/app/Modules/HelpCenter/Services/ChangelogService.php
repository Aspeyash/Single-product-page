<?php
/**
 * ChangelogService — parses `readme.txt` and returns the changelog as a
 * structured list of versions with their notes.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\HelpCenter\Services;

use ZymargCommunication\Core\Abstracts\AbstractService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ChangelogService extends AbstractService {

	public function entries( int $limit = 20 ): array {
		$path = trailingslashit( ZYMARG_COMM_DIR ) . 'readme.txt';
		if ( ! file_exists( $path ) ) {
			return array();
		}
		$contents = (string) @file_get_contents( $path );
		if ( '' === $contents ) {
			return array();
		}

		$section = $this->section( $contents, 'Changelog' );
		if ( '' === $section ) {
			return array();
		}

		$entries = array();
		preg_match_all( '/^=\s*([^=]+?)\s*=\s*$/m', $section, $matches, PREG_OFFSET_CAPTURE );
		$count = count( $matches[0] );
		for ( $i = 0; $i < $count; $i++ ) {
			$version = trim( $matches[1][ $i ][0] );
			$start   = $matches[0][ $i ][1] + strlen( $matches[0][ $i ][0] );
			$end     = ( $i + 1 < $count ) ? $matches[0][ $i + 1 ][1] : strlen( $section );
			$body    = trim( substr( $section, $start, $end - $start ) );
			$entries[] = array(
				'version' => $version,
				'notes'   => $this->parseNotes( $body ),
			);
			if ( count( $entries ) >= max( 1, $limit ) ) {
				break;
			}
		}
		return $entries;
	}

	public function latest(): ?array {
		$all = $this->entries( 1 );
		return $all[0] ?? null;
	}

	private function section( string $contents, string $heading ): string {
		$pattern = '/^==\s*' . preg_quote( $heading, '/' ) . '\s*==\s*$/m';
		if ( ! preg_match( $pattern, $contents, $m, PREG_OFFSET_CAPTURE ) ) {
			return '';
		}
		$start = $m[0][1] + strlen( $m[0][0] );
		if ( preg_match( '/^==\s+[^=]+?\s+==\s*$/m', $contents, $next, PREG_OFFSET_CAPTURE, $start ) ) {
			return substr( $contents, $start, $next[0][1] - $start );
		}
		return substr( $contents, $start );
	}

	/** @return array<int, string> */
	private function parseNotes( string $body ): array {
		$lines = preg_split( '/\r?\n/', $body );
		$out   = array();
		foreach ( $lines ?: array() as $line ) {
			$line = trim( $line );
			if ( '' === $line ) {
				continue;
			}
			$out[] = ltrim( $line, '*- ' );
		}
		return $out;
	}
}
