<?php
/**
 * HelpCenterService — reads the user guide and admin guide from
 * `/docs/guides/` and exposes them as structured content.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\HelpCenter\Services;

use ZymargCommunication\Core\Abstracts\AbstractService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class HelpCenterService extends AbstractService {

	private const AUDIENCES = array(
		'user'  => 'user-guide',
		'admin' => 'admin-guide',
	);

	public function guide( string $audience ): array {
		$audience = array_key_exists( $audience, self::AUDIENCES ) ? $audience : 'user';
		$slug     = self::AUDIENCES[ $audience ];
		return array(
			'audience' => $audience,
			'sections' => $this->loadSections( 'guides/' . $slug ),
		);
	}

	public function troubleshooting(): array {
		return array(
			'sections' => $this->loadSections( 'guides/troubleshooting' ),
		);
	}

	public function listGuides(): array {
		return array_keys( self::AUDIENCES );
	}

	/**
	 * @return array<int, array{slug:string,title:string,body:string}>
	 */
	private function loadSections( string $relative ): array {
		$dir = trailingslashit( ZYMARG_COMM_DIR ) . 'docs/' . ltrim( $relative, '/' );
		if ( ! is_dir( $dir ) ) {
			return array();
		}
		$files = glob( $dir . '/*.md' ) ?: array();
		sort( $files );
		$out = array();
		foreach ( $files as $file ) {
			$slug     = pathinfo( $file, PATHINFO_FILENAME );
			$contents = (string) @file_get_contents( $file );
			$title    = $this->extractTitle( $contents, $slug );
			$out[]    = array(
				'slug'  => $slug,
				'title' => $title,
				'body'  => $contents,
			);
		}
		return $out;
	}

	private function extractTitle( string $markdown, string $fallback ): string {
		if ( preg_match( '/^#\s+(.+)$/m', $markdown, $m ) ) {
			return trim( $m[1] );
		}
		return ucwords( str_replace( array( '-', '_' ), ' ', $fallback ) );
	}
}
