<?php
/**
 * Plain data object representing a help article (either DB-backed or
 * filesystem-backed).
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\HelpCenter\Models;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class HelpArticle {

	public function __construct(
		public string $slug,
		public string $title,
		public string $body,
		public string $section = 'general',
		public ?int $id = null,
		public ?string $updatedAt = null
	) {}

	public static function fromRow( object $row ): self {
		return new self(
			(string) ( $row->slug ?? '' ),
			(string) ( $row->title ?? '' ),
			(string) ( $row->body ?? '' ),
			(string) ( $row->section ?? 'general' ),
			isset( $row->id ) ? (int) $row->id : null,
			isset( $row->updated_at ) ? (string) $row->updated_at : null
		);
	}

	public function toArray(): array {
		return array(
			'id'         => $this->id,
			'slug'       => $this->slug,
			'title'      => $this->title,
			'body'       => $this->body,
			'section'    => $this->section,
			'updated_at' => $this->updatedAt,
		);
	}
}
