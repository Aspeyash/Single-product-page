<?php
/**
 * REST endpoints for the built-in help center: user/admin guides,
 * developer documentation, changelog, and FAQ CRUD.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\HelpCenter\Controllers;

use WP_REST_Request;
use WP_REST_Response;
use ZymargCommunication\Core\Abstracts\AbstractController;
use ZymargCommunication\Infrastructure\Http\Middleware\AuthMiddleware;
use ZymargCommunication\Infrastructure\Http\Middleware\NonceMiddleware;
use ZymargCommunication\Modules\HelpCenter\Services\ChangelogService;
use ZymargCommunication\Modules\HelpCenter\Services\DocumentationService;
use ZymargCommunication\Modules\HelpCenter\Services\FaqService;
use ZymargCommunication\Modules\HelpCenter\Services\HelpCenterService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class HelpCenterController extends AbstractController {

	public function __construct(
		private HelpCenterService $help,
		private DocumentationService $docs,
		private ChangelogService $changelog,
		private FaqService $faq
	) {}

	public function registerRoutes(): void {
		$ns = self::NAMESPACE;

		register_rest_route( $ns, '/help/guide/(?P<audience>[a-z]+)', array(
			'methods'             => 'GET',
			'callback'            => array( $this, 'guide' ),
			'permission_callback' => array( AuthMiddleware::class, 'requireLoggedIn' ),
		) );
		register_rest_route( $ns, '/help/troubleshooting', array(
			'methods'             => 'GET',
			'callback'            => array( $this, 'troubleshooting' ),
			'permission_callback' => array( AuthMiddleware::class, 'requireLoggedIn' ),
		) );
		register_rest_route( $ns, '/help/docs/(?P<topic>[a-z-]+)', array(
			'methods'             => 'GET',
			'callback'            => array( $this, 'docs' ),
			'permission_callback' => array( AuthMiddleware::class, 'requireLoggedIn' ),
		) );
		register_rest_route( $ns, '/help/changelog', array(
			'methods'             => 'GET',
			'callback'            => array( $this, 'changelog' ),
			'permission_callback' => '__return_true',
		) );

		// FAQ CRUD.
		register_rest_route( $ns, '/help/faq', array(
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'faqList' ),
				'permission_callback' => '__return_true',
			),
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'faqSave' ),
				'permission_callback' => $this->adminWriteGuard(),
			),
		) );
		register_rest_route( $ns, '/help/faq/(?P<slug>[a-z0-9_-]+)', array(
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'faqGet' ),
				'permission_callback' => '__return_true',
			),
			array(
				'methods'             => 'DELETE',
				'callback'            => array( $this, 'faqDelete' ),
				'permission_callback' => $this->adminWriteGuard(),
			),
		) );
	}

	public function guide( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle( fn () => $this->help->guide( (string) $request->get_param( 'audience' ) ) );
	}

	public function troubleshooting( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle( fn () => $this->help->troubleshooting() );
	}

	public function docs( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle( fn () => $this->docs->topic( (string) $request->get_param( 'topic' ) ) );
	}

	public function changelog( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle( fn () => array( 'entries' => $this->changelog->entries( 50 ) ) );
	}

	public function faqList( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle( fn () => array( 'articles' => $this->faq->list() ) );
	}

	public function faqGet( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle( fn () => array( 'article' => $this->faq->get( (string) $request->get_param( 'slug' ) ) ) );
	}

	public function faqSave( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle( fn () => array( 'article' => $this->faq->upsert( (array) $request->get_json_params() ?: $request->get_params() ) ) );
	}

	public function faqDelete( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle( fn () => array( 'deleted' => $this->faq->delete( (string) $request->get_param( 'slug' ) ) ) );
	}

	private function adminWriteGuard(): callable {
		return static function ( $request ) {
			$auth = AuthMiddleware::requireAdmin( $request );
			if ( true !== $auth ) {
				return $auth;
			}
			return NonceMiddleware::verify( $request );
		};
	}
}
