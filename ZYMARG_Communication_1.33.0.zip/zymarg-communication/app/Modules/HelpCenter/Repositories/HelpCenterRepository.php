<?php
/**
 * HelpCenterRepository — persists FAQ articles. Uses the WordPress options
 * table under a single key so we don't need a dedicated migration for a
 * feature that mostly reads from filesystem docs.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\HelpCenter\Repositories;

use ZymargCommunication\Modules\HelpCenter\Models\HelpArticle;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class HelpCenterRepository {

	private const OPTION_KEY = 'zymarg_comm_faq_articles';

	/** @return HelpArticle[] */
	public function all(): array {
		$raw = get_option( self::OPTION_KEY, array() );
		if ( ! is_array( $raw ) ) {
			return array();
		}
		$out = array();
		foreach ( $raw as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$out[] = new HelpArticle(
				(string) ( $row['slug'] ?? '' ),
				(string) ( $row['title'] ?? '' ),
				(string) ( $row['body'] ?? '' ),
				(string) ( $row['section'] ?? 'faq' ),
				isset( $row['id'] ) ? (int) $row['id'] : null,
				isset( $row['updated_at'] ) ? (string) $row['updated_at'] : null
			);
		}
		return $out;
	}

	public function findBySlug( string $slug ): ?HelpArticle {
		foreach ( $this->all() as $article ) {
			if ( $article->slug === $slug ) {
				return $article;
			}
		}
		return null;
	}

	public function save( HelpArticle $article ): HelpArticle {
		$rows    = $this->rawAll();
		$updated = false;
		$now     = current_time( 'mysql', true );

		foreach ( $rows as &$row ) {
			if ( isset( $row['slug'] ) && $row['slug'] === $article->slug ) {
				$row['title']      = $article->title;
				$row['body']       = $article->body;
				$row['section']    = $article->section;
				$row['updated_at'] = $now;
				$updated           = true;
				$article->updatedAt = $now;
				$article->id        = isset( $row['id'] ) ? (int) $row['id'] : null;
				break;
			}
		}
		unset( $row );

		if ( ! $updated ) {
			$nextId    = $this->nextId( $rows );
			$article->id        = $nextId;
			$article->updatedAt = $now;
			$rows[]    = array(
				'id'         => $nextId,
				'slug'       => $article->slug,
				'title'      => $article->title,
				'body'       => $article->body,
				'section'    => $article->section,
				'updated_at' => $now,
			);
		}

		update_option( self::OPTION_KEY, $rows, false );
		return $article;
	}

	public function delete( string $slug ): bool {
		$rows     = $this->rawAll();
		$filtered = array_values(
			array_filter( $rows, static fn( $r ) => ! isset( $r['slug'] ) || $r['slug'] !== $slug )
		);
		if ( count( $filtered ) === count( $rows ) ) {
			return false;
		}
		update_option( self::OPTION_KEY, $filtered, false );
		return true;
	}

	private function rawAll(): array {
		$raw = get_option( self::OPTION_KEY, array() );
		return is_array( $raw ) ? $raw : array();
	}

	private function nextId( array $rows ): int {
		$max = 0;
		foreach ( $rows as $row ) {
			if ( isset( $row['id'] ) && (int) $row['id'] > $max ) {
				$max = (int) $row['id'];
			}
		}
		return $max + 1;
	}
}
