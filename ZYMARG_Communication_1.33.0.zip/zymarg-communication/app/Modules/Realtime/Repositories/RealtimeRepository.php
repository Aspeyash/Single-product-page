<?php
/**
 * Presence and queue state persistence for the Realtime module.
 *
 * Uses WordPress transients + user_meta so no additional database table is
 * required. Presence is short-lived (heartbeat TTL). The queue is per-user
 * and capped to prevent unbounded growth.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Realtime\Repositories;

use ZymargCommunication\Modules\Realtime\Models\RealtimeEvent;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class RealtimeRepository {

	private const PRESENCE_TTL       = 60;    // seconds — heartbeat window
	private const TYPING_TTL         = 6;     // seconds
	private const QUEUE_META_KEY     = '_zymarg_comm_rt_queue';
	private const QUEUE_CURSOR_META  = '_zymarg_comm_rt_cursor';
	private const QUEUE_MAX_EVENTS   = 200;

	// ── Presence ─────────────────────────────────────────────────────────────────────
	public function heartbeat( int $user_id ): void {
		set_transient( $this->presenceKey( $user_id ), time(), self::PRESENCE_TTL );
	}

	public function lastSeen( int $user_id ): ?int {
		$val = get_transient( $this->presenceKey( $user_id ) );
		return false === $val ? null : (int) $val;
	}

	public function isOnline( int $user_id ): bool {
		return null !== $this->lastSeen( $user_id );
	}

	public function clearPresence( int $user_id ): void {
		delete_transient( $this->presenceKey( $user_id ) );
	}

	// ── Typing ────────────────────────────────────────────────────────────────────────────
	public function markTyping( int $conversation_id, int $user_id, bool $typing ): void {
		$key = $this->typingKey( $conversation_id, $user_id );
		if ( $typing ) {
			set_transient( $key, time(), self::TYPING_TTL );
		} else {
			delete_transient( $key );
		}
	}

	public function isTyping( int $conversation_id, int $user_id ): bool {
		return false !== get_transient( $this->typingKey( $conversation_id, $user_id ) );
	}

	// ── Queue ─────────────────────────────────────────────────────────────────────────────
	public function enqueueFor( int $user_id, RealtimeEvent $event ): void {
		$queue   = $this->loadQueue( $user_id );
		$queue[] = $event->toArray();
		// Cap queue length.
		if ( count( $queue ) > self::QUEUE_MAX_EVENTS ) {
			$queue = array_slice( $queue, -self::QUEUE_MAX_EVENTS );
		}
		update_user_meta( $user_id, self::QUEUE_META_KEY, wp_slash( wp_json_encode( $queue ) ?: '[]' ) );
	}

	/** @return array<int, RealtimeEvent> */
	public function drainSince( int $user_id, ?string $since_event_id ): array {
		$queue = $this->loadQueue( $user_id );
		if ( empty( $queue ) ) {
			return array();
		}

		$start = 0;
		if ( null !== $since_event_id && '' !== $since_event_id ) {
			foreach ( $queue as $index => $raw ) {
				if ( ( $raw['id'] ?? '' ) === $since_event_id ) {
					$start = $index + 1;
					break;
				}
			}
		}

		$slice = array_slice( $queue, $start );
		return array_map( array( RealtimeEvent::class, 'fromArray' ), $slice );
	}

	public function ackUpTo( int $user_id, string $event_id ): void {
		$queue = $this->loadQueue( $user_id );
		if ( empty( $queue ) ) {
			return;
		}
		$keep = array();
		$seen = false;
		foreach ( $queue as $raw ) {
			if ( ! $seen ) {
				if ( ( $raw['id'] ?? '' ) === $event_id ) {
					$seen = true;
				}
				continue;
			}
			$keep[] = $raw;
		}
		update_user_meta( $user_id, self::QUEUE_META_KEY, wp_slash( wp_json_encode( $keep ) ?: '[]' ) );
	}

	public function clearQueue( int $user_id ): void {
		delete_user_meta( $user_id, self::QUEUE_META_KEY );
		delete_user_meta( $user_id, self::QUEUE_CURSOR_META );
	}

	// ── Helpers ──────────────────────────────────────────────────────────────────────
	/** @return array<int, array<string, mixed>> */
	private function loadQueue( int $user_id ): array {
		$raw = get_user_meta( $user_id, self::QUEUE_META_KEY, true );
		if ( ! is_string( $raw ) || '' === $raw ) {
			return array();
		}
		$decoded = json_decode( $raw, true );
		return is_array( $decoded ) ? $decoded : array();
	}

	private function presenceKey( int $user_id ): string {
		return 'zymarg_comm_presence_' . $user_id;
	}

	private function typingKey( int $conversation_id, int $user_id ): string {
		return 'zymarg_comm_typing_' . $conversation_id . '_' . $user_id;
	}
}
