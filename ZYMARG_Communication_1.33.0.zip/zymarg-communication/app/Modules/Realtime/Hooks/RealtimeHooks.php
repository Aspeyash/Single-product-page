<?php
/**
 * Registers Realtime module hooks and REST controller.
 *
 * Wiring:
 *  - Listens to `zymarg_comm_event_message_sent` and pushes to each other
 *    participant's private user channel through the active driver via QueueService.
 *  - Listens to conversation lifecycle events for surface refresh signals.
 *  - Enqueues the frontend realtime.js client for logged-in users.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Realtime\Hooks;

use ZymargCommunication\Bootstrap\ServiceProvider;
use ZymargCommunication\Core\Contracts\HookableInterface;
use ZymargCommunication\Infrastructure\Http\Controllers\RestController;
use ZymargCommunication\Modules\Conversation\Repositories\ParticipantRepository;
use ZymargCommunication\Modules\Realtime\Controllers\RealtimeController;
use ZymargCommunication\Modules\Realtime\Services\QueueService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class RealtimeHooks implements HookableInterface {

	public static function register(): void {
		$instance = new self();
		$instance->registerHooks();
	}

	private function registerHooks(): void {
		$controller = ServiceProvider::get( RealtimeController::class );
		if ( $controller instanceof RealtimeController ) {
			RestController::register( $controller );
		}

		add_action( 'zymarg_comm_event_message_sent',         array( $this, 'onMessageSent' ), 10, 1 );
		add_action( 'zymarg_comm_event_conversation_created', array( $this, 'onConversationCreated' ), 10, 1 );
		add_action( 'zymarg_comm_event_conversation_closed',  array( $this, 'onConversationClosed' ), 10, 1 );
		add_action( 'zymarg_comm_event_participant_joined',   array( $this, 'onParticipantJoined' ), 10, 1 );

		add_action( 'wp_enqueue_scripts',    array( $this, 'enqueueClient' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueueClient' ) );
	}

	public function onMessageSent( array $payload ): void {
		$conversation_id = (int) ( $payload['conversation_id'] ?? 0 );
		$sender_id       = (int) ( $payload['sender_id'] ?? 0 );
		if ( $conversation_id < 1 ) {
			return;
		}

		$queue        = $this->queue();
		$participants = $this->participants();
		if ( ! $queue || ! $participants ) {
			return;
		}

		// Publish to each recipient's private user channel — this is the channel
		// the realtime client subscribes to (see PusherService::userChannel()).
		foreach ( $participants->findForConversation( $conversation_id ) as $participant ) {
			$user_id = (int) $participant->userId;
			if ( $user_id < 1 || $user_id === $sender_id ) {
				continue;
			}
			$queue->publishFor( $user_id, 'private-zymarg-user-' . $user_id, 'message.sent', $payload );
		}
	}

	public function onConversationCreated( array $payload ): void {
		$this->broadcastToParticipants( 'conversation.created', $payload );
	}

	public function onConversationClosed( array $payload ): void {
		$this->broadcastToParticipants( 'conversation.closed', $payload );
	}

	public function onParticipantJoined( array $payload ): void {
		$conversation_id = (int) ( $payload['conversation_id'] ?? 0 );
		$user_id         = (int) ( $payload['user_id'] ?? 0 );
		if ( $conversation_id < 1 || $user_id < 1 ) {
			return;
		}
		$queue = $this->queue();
		if ( $queue ) {
			$queue->publishFor( $user_id, 'private-zymarg-user-' . $user_id, 'participant.joined', $payload );
		}
	}

	public function enqueueClient(): void {
		if ( ! is_user_logged_in() ) {
			return;
		}
		$queue = $this->queue();
		if ( ! $queue ) {
			return;
		}

		$driver = $queue->driver();
		$deps   = array();

		// When Pusher is the active, configured driver, load the official Pusher
		// JS SDK from its CDN and make the realtime client depend on it. Without
		// this, realtime.js sees `typeof Pusher === 'undefined'` and silently
		// falls back to REST polling.
		if ( 'pusher' === $driver->name() && $driver->isConfigured() ) {
			wp_register_script(
				'pusher-js',
				'https://js.pusher.com/8.2.0/pusher.min.js',
				array(),
				'8.2.0',
				true
			);
			wp_enqueue_script( 'pusher-js' );
			$deps[] = 'pusher-js';
		}

		$handle = 'zymarg-comm-realtime';
		wp_register_script(
			$handle,
			ZYMARG_COMM_ASSETS_URL . 'js/frontend/realtime.js',
			$deps,
			ZYMARG_COMM_VERSION,
			true
		);

		wp_localize_script(
			$handle,
			'ZymargCommRealtimeConfig',
			array(
				'restUrl'   => esc_url_raw( rest_url( 'zymarg-comm/v1' ) ),
				'nonce'     => wp_create_nonce( 'wp_rest' ),
				'driver'    => $queue->driver()->name(),
				'userId'    => get_current_user_id(),
				'heartbeat' => 30000,
			)
		);

		wp_enqueue_script( $handle );
	}

	private function broadcastToParticipants( string $event, array $payload ): void {
		$conversation_id = (int) ( $payload['conversation_id'] ?? 0 );
		if ( $conversation_id < 1 ) {
			return;
		}
		$queue        = $this->queue();
		$participants = $this->participants();
		if ( ! $queue || ! $participants ) {
			return;
		}
		foreach ( $participants->findForConversation( $conversation_id ) as $p ) {
			$user_id = (int) $p->userId;
			if ( $user_id > 0 ) {
				$queue->publishFor( $user_id, 'private-zymarg-user-' . $user_id, $event, $payload );
			}
		}
	}

	private function queue(): ?QueueService {
		$q = ServiceProvider::get( QueueService::class );
		return $q instanceof QueueService ? $q : null;
	}

	private function participants(): ?ParticipantRepository {
		$p = ServiceProvider::get( ParticipantRepository::class );
		return $p instanceof ParticipantRepository ? $p : null;
	}
}
