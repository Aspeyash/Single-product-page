<?php
/**
 * Tracks online status, typing indicators, and connection state per user
 * per conversation.
 *
 * All state is short-lived and lives in transients — there is no database
 * table for presence. Both `message.online_status` and
 * `message.typing_indicator` flags gate the observable behaviour; writes
 * are still recorded so the flag can be re-enabled without cold data.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Realtime\Services;

use ZymargCommunication\Core\Abstracts\AbstractService;
use ZymargCommunication\Modules\Realtime\Repositories\RealtimeRepository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class PresenceService extends AbstractService {

	public function __construct(
		private RealtimeRepository $repository,
		private QueueService $queue
	) {}

	public function heartbeat( int $user_id ): void {
		if ( $user_id < 1 ) {
			return;
		}
		$this->repository->heartbeat( $user_id );
		do_action( 'zymarg_comm_presence_heartbeat', $user_id );
	}

	public function goOffline( int $user_id ): void {
		$this->repository->clearPresence( $user_id );
		do_action( 'zymarg_comm_presence_offline', $user_id );
	}

	public function isOnline( int $user_id ): bool {
		if ( ! $this->isEnabled( 'message.online_status' ) ) {
			return false;
		}
		return $this->repository->isOnline( $user_id );
	}

	public function lastSeen( int $user_id ): ?int {
		return $this->repository->lastSeen( $user_id );
	}

	public function setTyping( int $conversation_id, int $user_id, bool $typing ): void {
		if ( ! $this->isEnabled( 'message.typing_indicator' ) ) {
			return;
		}
		$this->repository->markTyping( $conversation_id, $user_id, $typing );

		// The realtime publish for typing lives in RealtimeController::typing(),
		// where the counterpart user id is known. The previous publish here went
		// to a conversation channel with recipient 0, which no client subscribes
		// to, so it never reached anyone and has been removed.
	}

	public function isTyping( int $conversation_id, int $user_id ): bool {
		if ( ! $this->isEnabled( 'message.typing_indicator' ) ) {
			return false;
		}
		return $this->repository->isTyping( $conversation_id, $user_id );
	}
}
