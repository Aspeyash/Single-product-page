<?php
/**
 * Pusher realtime driver. Default driver.
 *
 * Publishes events to Pusher Channels via the HTTP API. Reads credentials
 * from options (Phase 6 will migrate these to the encrypted SettingsService).
 *
 * Exposes `testConnection( array $credentials ): array` used by the admin
 * Settings test button. Returns:
 *   [ 'status' => 'connected'|'failed'|'partial', 'message' => string ]
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Realtime\Services;

use ZymargCommunication\Core\Contracts\RealtimeDriverInterface;
use ZymargCommunication\Core\Contracts\ServiceInterface;
use ZymargCommunication\Modules\Security\Services\EncryptionService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class PusherService implements RealtimeDriverInterface, ServiceInterface {

	private const OPTION_APP_ID    = 'zymarg_comm_pusher_app_id';
	private const OPTION_APP_KEY   = 'zymarg_comm_pusher_app_key';
	private const OPTION_APP_SECRET = 'zymarg_comm_pusher_app_secret';
	private const OPTION_CLUSTER   = 'zymarg_comm_pusher_cluster';

	public function name(): string {
		return 'pusher';
	}

	/** @return array{app_id:string, app_key:string, app_secret:string, cluster:string} */
	public function credentials(): array {
		return array(
			'app_id'     => $this->secret( self::OPTION_APP_ID ),
			'app_key'    => $this->secret( self::OPTION_APP_KEY ),
			'app_secret' => $this->secret( self::OPTION_APP_SECRET ),
			'cluster'    => (string) get_option( self::OPTION_CLUSTER, 'mt1' ),
		);
	}

	/**
	 * Reads a credential option, decrypting it when stored encrypted.
	 *
	 * IMPORTANT: the Settings screen saves these credentials encrypted (values
	 * carry the `zc_enc_v1:` prefix). Previous versions read the raw option here
	 * and never decrypted, so every private-channel signature was signed with
	 * the *ciphertext* as the app secret and stamped with the ciphertext as the
	 * app key -- and every publish authenticated with the same garbage. Pusher
	 * rejected all of it: `subscribed = false` on every client, no realtime
	 * delivery at all, and no error surfaced anywhere. The admin 'Test
	 * Connection' button hid the fault because it decrypts before calling
	 * testConnection(), so it reported success against a dead runtime path.
	 * Never read these options without decrypting.
	 *
	 * Values saved before encryption existed are still plaintext, so pass
	 * those through unchanged.
	 */
	private function secret( string $option ): string {
		$raw = (string) get_option( $option, '' );
		if ( '' === $raw ) {
			return '';
		}

		$encryption = new EncryptionService();
		if ( ! $encryption->isEncrypted( $raw ) ) {
			return $raw;
		}

		// decrypt() returns '' when key material changed or OpenSSL is absent.
		// Returning '' makes isConfigured() false, which drops the stack to the
		// polling fallback instead of silently signing broken tokens.
		return $encryption->decrypt( $raw );
	}

	public function isConfigured(): bool {
		$c = $this->credentials();
		return '' !== $c['app_id'] && '' !== $c['app_key'] && '' !== $c['app_secret'] && '' !== $c['cluster'];
	}

	public function isConnected(): bool {
		return $this->isConfigured();
	}

	public function publish( string $channel, string $event, array $payload ): bool {
		if ( ! $this->isConfigured() ) {
			return false;
		}
		try {
			$result = $this->sendToPusher( $this->credentials(), $channel, $event, $payload );
			return 200 === (int) ( $result['status'] ?? 0 );
		} catch ( \Throwable $e ) {
			return false;
		}
	}

	public function subscribe( string $channel ): void {
		unset( $channel ); // Pusher is stateless server-side; no-op.
	}

	public function authenticate( int $user_id ): string {
		$c = $this->credentials();
		if ( '' === $c['app_key'] || '' === $c['app_secret'] ) {
			return '';
		}
		$socket_id  = isset( $_POST['socket_id'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['socket_id'] ) ) : '';
		$channel    = isset( $_POST['channel_name'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['channel_name'] ) ) : $this->userChannel( $user_id );
		if ( '' === $socket_id ) {
			return '';
		}
		$signature = hash_hmac( 'sha256', $socket_id . ':' . $channel, $c['app_secret'] );
		return wp_json_encode( array( 'auth' => $c['app_key'] . ':' . $signature ) ) ?: '';
	}

	public function issueClientToken( int $user_id ): array {
		$c = $this->credentials();
		return array(
			'driver'     => 'pusher',
			'app_key'    => $c['app_key'],
			'cluster'    => $c['cluster'],
			'channel'    => $this->userChannel( $user_id ),
			'auth_url'   => rest_url( 'zymarg-comm/v1/realtime/auth' ),
			'expires_at' => time() + HOUR_IN_SECONDS,
		);
	}

	public function userChannel( int $user_id ): string {
		return 'private-zymarg-user-' . $user_id;
	}

	/**
	 * Admin "Test Connection" flow. Never saves credentials.
	 *
	 * @param array{app_id?:string, app_key?:string, app_secret?:string, cluster?:string} $credentials
	 * @return array{status:string, message:string}
	 */
	public function testConnection( array $credentials ): array {
		$c = array(
			'app_id'     => (string) ( $credentials['app_id'] ?? '' ),
			'app_key'    => (string) ( $credentials['app_key'] ?? '' ),
			'app_secret' => (string) ( $credentials['app_secret'] ?? '' ),
			'cluster'    => (string) ( $credentials['cluster'] ?? 'mt1' ),
		);

		foreach ( array( 'app_id', 'app_key', 'app_secret', 'cluster' ) as $field ) {
			if ( '' === $c[ $field ] ) {
				return array(
					'status'  => 'failed',
					'message' => __( 'Enter all Pusher credentials first.', 'zymarg-communication' ),
				);
			}
		}

		try {
			$result = $this->sendToPusher( $c, 'private-zymarg-test-channel', 'zymarg_comm.test', array( 'ok' => true ) );
			$status = (int) ( $result['status'] ?? 0 );

			if ( 200 === $status ) {
				return array( 'status' => 'connected', 'message' => __( 'Pusher connected successfully.', 'zymarg-communication' ) );
			}
			if ( 401 === $status || 403 === $status ) {
				return array( 'status' => 'failed', 'message' => __( 'Connection failed. Check your credentials.', 'zymarg-communication' ) );
			}
			return array( 'status' => 'partial', 'message' => __( 'Connected but could not publish. Check channel permissions.', 'zymarg-communication' ) );
		} catch ( \Throwable $e ) {
			return array( 'status' => 'failed', 'message' => __( 'Connection failed. Check your credentials.', 'zymarg-communication' ) );
		}
	}

	/**
	 * @param array{app_id:string, app_key:string, app_secret:string, cluster:string} $c
	 * @return array{status:int, body:string}
	 */
	private function sendToPusher( array $c, string $channel, string $event, array $payload ): array {
		$body = wp_json_encode(
			array(
				'name'     => $event,
				'data'     => (string) wp_json_encode( $payload ),
				'channels' => array( $channel ),
			)
		) ?: '{}';

		$path         = '/apps/' . $c['app_id'] . '/events';
		$body_md5     = md5( $body );
		$timestamp    = time();
		$query_parts  = array(
			'auth_key'       => $c['app_key'],
			'auth_timestamp' => $timestamp,
			'auth_version'   => '1.0',
			'body_md5'       => $body_md5,
		);
		ksort( $query_parts );
		$auth_string  = 'POST' . "\n" . $path . "\n" . http_build_query( $query_parts );
		$signature    = hash_hmac( 'sha256', $auth_string, $c['app_secret'] );
		$query_parts['auth_signature'] = $signature;

		$url = 'https://api-' . $c['cluster'] . '.pusher.com' . $path . '?' . http_build_query( $query_parts );

		$response = wp_remote_post(
			$url,
			array(
				'timeout' => 10,
				'headers' => array( 'Content-Type' => 'application/json' ),
				'body'    => $body,
			)
		);

		if ( is_wp_error( $response ) ) {
			return array( 'status' => 0, 'body' => '' );
		}

		return array(
			'status' => (int) wp_remote_retrieve_response_code( $response ),
			'body'   => (string) wp_remote_retrieve_body( $response ),
		);
	}
}
