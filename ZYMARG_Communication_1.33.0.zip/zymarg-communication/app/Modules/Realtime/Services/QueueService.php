<?php
/**
 * Queues outgoing realtime events for reliable delivery.
 *
 * Every publish goes through the active driver first; if the driver does
 * not accept the event, or the driver is a queueing driver (SSE / Polling),
 * the event is stored in `RealtimeRepository` so the recipient replays it
 * on reconnect.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Realtime\Services;

use ZymargCommunication\Core\Abstracts\AbstractService;
use ZymargCommunication\Core\Contracts\RealtimeDriverInterface;
use ZymargCommunication\Modules\Realtime\Models\RealtimeEvent;
use ZymargCommunication\Modules\Realtime\Repositories\RealtimeRepository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class QueueService extends AbstractService {

	public function __construct(
		private RealtimeRepository $repository,
		private RealtimeDriverInterface $driver
	) {}

	public function driver(): RealtimeDriverInterface {
		return $this->driver;
	}

	/**
	 * Publish to a specific recipient. When the driver cannot deliver (e.g.
	 * misconfigured), the event is queued for replay on next reconnect.
	 *
	 * @param int                  $recipient_user_id  Recipient user ID (0 = broadcast).
	 * @param string               $channel            Channel name.
	 * @param string               $event              Event name.
	 * @param array<string, mixed> $payload            Event body.
	 */
	public function publishFor( int $recipient_user_id, string $channel, string $event, array $payload ): bool {
		$payload['recipient_user_id'] = $recipient_user_id > 0 ? $recipient_user_id : null;

		$driver_ok = false;
		try {
			$driver_ok = $this->driver->publish( $channel, $event, $payload );
		} catch ( \Throwable $e ) {
			$driver_ok = false;
		}

		// Always queue for known recipients so a reconnect can replay.
		if ( $recipient_user_id > 0 ) {
			$this->repository->enqueueFor(
				$recipient_user_id,
				new RealtimeEvent( $channel, $event, $payload, $recipient_user_id )
			);
		}

		do_action( 'zymarg_comm_realtime_published', $channel, $event, $payload, $driver_ok );
		return $driver_ok;
	}

	/**
	 * Drain queued events for a user, optionally starting after a given event id.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function replay( int $user_id, ?string $since_event_id = null ): array {
		$events = $this->repository->drainSince( $user_id, $since_event_id );
		return array_map( static fn( RealtimeEvent $e ) => $e->toArray(), $events );
	}

	public function ack( int $user_id, string $event_id ): void {
		$this->repository->ackUpTo( $user_id, $event_id );
	}

	public function clear( int $user_id ): void {
		$this->repository->clearQueue( $user_id );
	}
}
