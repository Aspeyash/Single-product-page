<?php
/**
 * Server-Sent Events realtime driver.
 *
 * Publishing enqueues per-user events via `RealtimeRepository`; the client
 * receives them through the `/realtime/sse` REST endpoint which streams
 * events using the SSE format. Works on any standard PHP host that permits
 * `flush()` and non-buffered output.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Realtime\Services;

use ZymargCommunication\Core\Contracts\RealtimeDriverInterface;
use ZymargCommunication\Core\Contracts\ServiceInterface;
use ZymargCommunication\Modules\Realtime\Models\RealtimeEvent;
use ZymargCommunication\Modules\Realtime\Repositories\RealtimeRepository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class SseService implements RealtimeDriverInterface, ServiceInterface {

	public const STREAM_MAX_SECONDS  = 25;
	public const STREAM_POLL_SECONDS = 2;

	public function __construct( private RealtimeRepository $repository ) {}

	public function name(): string {
		return 'sse';
	}

	public function isConfigured(): bool {
		return true; // No credentials required.
	}

	public function isConnected(): bool {
		return true;
	}

	public function publish( string $channel, string $event, array $payload ): bool {
		$recipient = isset( $payload['recipient_user_id'] ) ? (int) $payload['recipient_user_id'] : 0;
		if ( 0 === $recipient ) {
			return false;
		}
		$this->repository->enqueueFor(
			$recipient,
			new RealtimeEvent( $channel, $event, $payload, $recipient )
		);
		return true;
	}

	public function subscribe( string $channel ): void {
		unset( $channel );
	}

	public function authenticate( int $user_id ): string {
		return wp_create_nonce( 'zymarg_comm_sse_' . $user_id );
	}

	public function issueClientToken( int $user_id ): array {
		return array(
			'driver'     => 'sse',
			'endpoint'   => rest_url( 'zymarg-comm/v1/realtime/sse' ),
			'channel'    => 'zymarg-user-' . $user_id,
			'auth'       => $this->authenticate( $user_id ),
			'expires_at' => time() + HOUR_IN_SECONDS,
		);
	}

	/**
	 * Streams pending events as SSE to the current PHP output. This runs
	 * inside a REST callback which must not have already sent a JSON body.
	 */
	public function stream( int $user_id ): void {
		if ( ! headers_sent() ) {
			header( 'Content-Type: text/event-stream' );
			header( 'Cache-Control: no-cache' );
			header( 'X-Accel-Buffering: no' );
		}

		@ini_set( 'output_buffering', 'off' );
		@ini_set( 'zlib.output_compression', 'off' );

		$start_time     = time();
		$last_event_id  = null;

		while ( ( time() - $start_time ) < self::STREAM_MAX_SECONDS ) {
			$events = $this->repository->drainSince( $user_id, $last_event_id );
			foreach ( $events as $event ) {
				echo 'id: ' . $event->id . "\n";
				echo 'event: ' . $event->event . "\n";
				echo 'data: ' . wp_json_encode( $event->toArray() ) . "\n\n";
				$last_event_id = $event->id;
			}

			if ( ! empty( $events ) && null !== $last_event_id ) {
				$this->repository->ackUpTo( $user_id, $last_event_id );
			}

			if ( function_exists( 'flush' ) ) {
				flush();
			}
			sleep( self::STREAM_POLL_SECONDS );
		}
	}
}
