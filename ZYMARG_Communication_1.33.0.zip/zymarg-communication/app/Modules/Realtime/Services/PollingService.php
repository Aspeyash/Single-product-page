<?php
/**
 * Long-polling fallback driver.
 *
 * Events published through this driver are queued per user via
 * `RealtimeRepository`. Clients call `GET /realtime/poll` at the configured
 * interval to drain their queue.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Realtime\Services;

use ZymargCommunication\Core\Contracts\RealtimeDriverInterface;
use ZymargCommunication\Core\Contracts\ServiceInterface;
use ZymargCommunication\Modules\Realtime\Models\RealtimeEvent;
use ZymargCommunication\Modules\Realtime\Repositories\RealtimeRepository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class PollingService implements RealtimeDriverInterface, ServiceInterface {

	public const DEFAULT_INTERVAL_MS = 4000;

	public function __construct( private RealtimeRepository $repository ) {}

	public function name(): string {
		return 'polling';
	}

	public function isConfigured(): bool {
		return true;
	}

	public function isConnected(): bool {
		return true;
	}

	public function publish( string $channel, string $event, array $payload ): bool {
		$recipient = isset( $payload['recipient_user_id'] ) ? (int) $payload['recipient_user_id'] : 0;
		if ( 0 === $recipient ) {
			return false;
		}
		$this->repository->enqueueFor(
			$recipient,
			new RealtimeEvent( $channel, $event, $payload, $recipient )
		);
		return true;
	}

	public function subscribe( string $channel ): void {
		unset( $channel );
	}

	public function authenticate( int $user_id ): string {
		return wp_create_nonce( 'zymarg_comm_poll_' . $user_id );
	}

	public function issueClientToken( int $user_id ): array {
		return array(
			'driver'      => 'polling',
			'endpoint'    => rest_url( 'zymarg-comm/v1/realtime/poll' ),
			'channel'     => 'zymarg-user-' . $user_id,
			'interval_ms' => (int) apply_filters( 'zymarg_comm_polling_interval_ms', self::DEFAULT_INTERVAL_MS ),
			'auth'        => $this->authenticate( $user_id ),
			'expires_at'  => time() + HOUR_IN_SECONDS,
		);
	}

	/** @return array<int, RealtimeEvent> */
	public function drain( int $user_id, ?string $since_event_id ): array {
		$events = $this->repository->drainSince( $user_id, $since_event_id );
		if ( ! empty( $events ) ) {
			$last = end( $events );
			if ( $last instanceof RealtimeEvent ) {
				$this->repository->ackUpTo( $user_id, (string) $last->id );
			}
		}
		return $events;
	}
}
