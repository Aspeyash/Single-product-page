<?php
/**
 * WebSocket realtime driver.
 *
 * Publishes events to an operator-provided WebSocket bridge over HTTP.
 * Suitable for self-hosted setups (e.g. Soketi, node-ws relay) that expose
 * a token-protected publish endpoint. When no endpoint is configured the
 * driver reports itself unconfigured and the ServiceProvider falls back
 * to Pusher automatically.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Realtime\Services;

use ZymargCommunication\Core\Contracts\RealtimeDriverInterface;
use ZymargCommunication\Core\Contracts\ServiceInterface;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WebSocketService implements RealtimeDriverInterface, ServiceInterface {

	private const OPTION_ENDPOINT = 'zymarg_comm_websocket_endpoint';
	private const OPTION_TOKEN    = 'zymarg_comm_websocket_token';
	private const OPTION_CLIENT   = 'zymarg_comm_websocket_client_url';

	public function name(): string {
		return 'websocket';
	}

	public function isConfigured(): bool {
		return '' !== (string) get_option( self::OPTION_ENDPOINT, '' );
	}

	public function isConnected(): bool {
		return $this->isConfigured();
	}

	public function publish( string $channel, string $event, array $payload ): bool {
		if ( ! $this->isConfigured() ) {
			return false;
		}

		$response = wp_remote_post(
			(string) get_option( self::OPTION_ENDPOINT, '' ),
			array(
				'timeout' => 5,
				'headers' => array(
					'Content-Type'  => 'application/json',
					'Authorization' => 'Bearer ' . (string) get_option( self::OPTION_TOKEN, '' ),
				),
				'body'    => wp_json_encode(
					array(
						'channel' => $channel,
						'event'   => $event,
						'payload' => $payload,
					)
				) ?: '{}',
			)
		);

		if ( is_wp_error( $response ) ) {
			return false;
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		return $code >= 200 && $code < 300;
	}

	public function subscribe( string $channel ): void {
		unset( $channel );
	}

	public function authenticate( int $user_id ): string {
		$token = (string) get_option( self::OPTION_TOKEN, '' );
		if ( '' === $token ) {
			return '';
		}
		return hash_hmac( 'sha256', 'user:' . $user_id . ':' . time(), $token );
	}

	public function issueClientToken( int $user_id ): array {
		return array(
			'driver'     => 'websocket',
			'endpoint'   => (string) get_option( self::OPTION_CLIENT, '' ),
			'channel'    => 'zymarg-user-' . $user_id,
			'auth'       => $this->authenticate( $user_id ),
			'expires_at' => time() + HOUR_IN_SECONDS,
		);
	}
}
