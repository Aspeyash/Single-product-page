<?php
/**
 * REST endpoints for the Realtime module.
 *
 *  GET    /realtime/token       Issue driver-specific connection token.
 *  GET    /realtime/poll        Long-poll fallback — drains queued events.
 *  GET    /realtime/sse         SSE stream endpoint (server-sent events).
 *  POST   /realtime/auth        Pusher (or WS) private-channel auth callback.
 *  POST   /realtime/heartbeat   Presence heartbeat ping.
 *  POST   /realtime/typing      Set typing indicator on a conversation.
 *  POST   /realtime/ack         Acknowledge processed queued events.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Realtime\Controllers;

use WP_REST_Request;
use WP_REST_Response;
use ZymargCommunication\Bootstrap\ServiceProvider;
use ZymargCommunication\Core\Abstracts\AbstractController;
use ZymargCommunication\Infrastructure\Http\Middleware\AuthMiddleware;
use ZymargCommunication\Infrastructure\Http\Middleware\NonceMiddleware;
use ZymargCommunication\Infrastructure\Http\Middleware\RateLimitMiddleware;
use ZymargCommunication\Modules\Realtime\Services\PollingService;
use ZymargCommunication\Modules\Realtime\Services\PresenceService;
use ZymargCommunication\Modules\Realtime\Services\PusherService;
use ZymargCommunication\Modules\Realtime\Services\QueueService;
use ZymargCommunication\Modules\Realtime\Services\SseService;
use ZymargCommunication\Modules\Conversation\Repositories\ParticipantRepository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class RealtimeController extends AbstractController {

	public function __construct(
		private QueueService $queue,
		private PresenceService $presence,
		private PollingService $polling,
		private SseService $sse,
		private PusherService $pusher,
		private ParticipantRepository $participants
	) {}

	public function registerRoutes(): void {
		register_rest_route(
			self::NAMESPACE,
			'/realtime/token',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( $this, 'token' ),
					'permission_callback' => array( AuthMiddleware::class, 'requireLoggedIn' ),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/realtime/poll',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( $this, 'poll' ),
					'permission_callback' => array( AuthMiddleware::class, 'requireLoggedIn' ),
					'args'                => array(
						'since' => array(
							'type'              => 'string',
							'required'          => false,
							'sanitize_callback' => 'sanitize_text_field',
						),
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/realtime/sse',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( $this, 'sseStream' ),
					'permission_callback' => array( AuthMiddleware::class, 'requireLoggedIn' ),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/realtime/auth',
			array(
				array(
					'methods'             => 'POST',
					'callback'            => array( $this, 'auth' ),
					'permission_callback' => array( AuthMiddleware::class, 'requireLoggedIn' ),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/realtime/heartbeat',
			array(
				array(
					'methods'             => 'POST',
					'callback'            => array( $this, 'heartbeat' ),
					'permission_callback' => array( $this, 'writeGuard' ),
					'args'                => array(
						'conversation_id' => array( 'required' => false, 'type' => 'integer' ),
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/realtime/typing',
			array(
				array(
					'methods'             => 'POST',
					'callback'            => array( $this, 'typing' ),
					'permission_callback' => array( $this, 'writeGuard' ),
					'args'                => array(
						'conversation_id' => array( 'required' => true, 'type' => 'integer' ),
						'typing'          => array( 'required' => true, 'type' => 'boolean' ),
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/realtime/typing-status',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( $this, 'typingStatus' ),
					'permission_callback' => array( AuthMiddleware::class, 'requireLoggedIn' ),
					'args'                => array(
						'conversation_id' => array( 'required' => true, 'type' => 'integer' ),
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/realtime/presence-status',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( $this, 'presenceStatus' ),
					'permission_callback' => array( AuthMiddleware::class, 'requireLoggedIn' ),
					'args'                => array(
						'conversation_id' => array( 'required' => true, 'type' => 'integer' ),
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/realtime/ack',
			array(
				array(
					'methods'             => 'POST',
					'callback'            => array( $this, 'ack' ),
					'permission_callback' => array( $this, 'writeGuard' ),
					'args'                => array(
						'event_id' => array( 'required' => true, 'type' => 'string' ),
					),
				),
			)
		);
	}

	public function writeGuard( WP_REST_Request $request ): bool|\WP_Error {
		$auth = AuthMiddleware::requireLoggedIn( $request );
		if ( $auth instanceof \WP_Error ) {
			return $auth;
		}
		return NonceMiddleware::verify( $request );
	}

	public function token( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle(
			function () use ( $request ) {
				unset( $request );
				$this->requireAuthenticated();
				$driver = $this->queue->driver();
				return array(
					'driver'       => $driver->name(),
					'is_connected' => $driver->isConnected(),
					'token'        => $driver->issueClientToken( $this->currentUserId() ),
				);
			}
		);
	}

	public function poll( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle(
			function () use ( $request ) {
				$this->requireAuthenticated();

				$limit = RateLimitMiddleware::enforce( $request, 'realtime.poll', 120, MINUTE_IN_SECONDS );
				if ( $limit instanceof \WP_Error ) {
					return $this->fail( 'rate_limited', (string) $limit->get_error_message(), 429 );
				}

				$since  = (string) $this->param( $request, 'since', '' );
				$events = $this->polling->drain( $this->currentUserId(), '' === $since ? null : $since );

				return array(
					'events'    => array_map( static fn( $e ) => $e->toArray(), $events ),
					'polled_at' => gmdate( 'Y-m-d\\TH:i:s\\Z' ),
				);
			}
		);
	}

	public function sseStream( WP_REST_Request $request ) {
		unset( $request );
		$this->sse->stream( $this->currentUserId() );
		exit;
	}

	public function auth( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle(
			function () use ( $request ) {
				unset( $request );
				$this->requireAuthenticated();
				$signature = $this->pusher->authenticate( $this->currentUserId() );
				if ( '' === $signature ) {
					return $this->fail( 'realtime_auth_failed', __( 'Realtime auth failed.', 'zymarg-communication' ), 400 );
				}
				$decoded = json_decode( $signature, true );
				$payload = is_array( $decoded ) ? $decoded : array( 'auth' => $signature );

				// IMPORTANT: Pusher's client requires the bare {"auth":"key:sig"}
				// body. Returning a plain array lets handle() wrap it in the standard
				// {success,data} envelope, which Pusher cannot parse -- every private
				// channel subscription then fails and realtime dies silently. A
				// WP_REST_Response passes through handle() untouched. Do not
				// 'simplify' this back into a plain array return.
				return new WP_REST_Response( $payload, 200 );
			}
		);
	}

	public function heartbeat( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle(
			function () use ( $request ) {
				$this->requireAuthenticated();
				$me = $this->currentUserId();
				$this->presence->heartbeat( $me );

				// When the client tells us which conversation it is actively viewing,
				// push a presence "online" event to the counterpart's private user
				// channel so their "Active now" flips instantly over Pusher. The 30s
				// presence poll remains as a fallback; going offline is still detected
				// via presence TTL expiry (which cannot be pushed).
				$conversation_id = (int) $request->get_param( 'conversation_id' );
				if ( $conversation_id > 0 ) {
					$counterpart = $this->participants->counterpartUserId( $conversation_id, $me );
					if ( $counterpart ) {
						$this->queue->publishFor(
							(int) $counterpart,
							'private-zymarg-user-' . (int) $counterpart,
							'presence.update',
							array(
								'conversation_id' => $conversation_id,
								'user_id'         => $me,
								'online'          => true,
							)
						);
					}
				}

				return array( 'ok' => true, 'at' => time() );
			}
		);
	}

	public function typing( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle(
			function () use ( $request ) {
				$this->requireAuthenticated();
				$conversation_id = (int) $request->get_param( 'conversation_id' );
				$typing          = rest_sanitize_boolean( $request->get_param( 'typing' ) );
				if ( $conversation_id < 1 ) {
					return $this->fail( 'invalid_conversation', __( 'Invalid conversation.', 'zymarg-communication' ), 400 );
				}
				$me = $this->currentUserId();
				$this->presence->setTyping( $conversation_id, $me, $typing );

				// Push the typing state straight to the counterpart's private user
				// channel so their indicator updates instantly over Pusher. The 3s
				// typing-status poll remains as a fallback for non-Pusher drivers.
				$counterpart = $this->participants->counterpartUserId( $conversation_id, $me );
				if ( $counterpart ) {
					$payload = array(
						'conversation_id' => $conversation_id,
						'user_id'         => $me,
						'typing'          => $typing,
					);

					// 1.32.15 — carry the persona label with the push, computed for
					// the RECIPIENT. Without it a Pusher-driven indicator would
					// show the generic "Typing…" until the 3s poll caught up and
					// renamed it, which reads as a flicker mid-sentence.
					$label = $this->supportTypingLabel( $conversation_id, (int) $counterpart );
					if ( '' !== $label ) {
						$payload['typing_label'] = $label;
					}

					$this->queue->publishFor(
						(int) $counterpart,
						'private-zymarg-user-' . (int) $counterpart,
						'typing.update',
						$payload
					);
				}

				return array( 'ok' => true, 'typing' => $typing );
			}
		);
	}

	public function typingStatus( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle(
			function () use ( $request ) {
				$this->requireAuthenticated();
				$conversation_id = (int) $request->get_param( 'conversation_id' );
				if ( $conversation_id < 1 ) {
					return $this->fail( 'invalid_conversation', __( 'Invalid conversation.', 'zymarg-communication' ), 400 );
				}
				$me = $this->currentUserId();
				if ( ! $this->participants->isParticipant( $conversation_id, $me ) ) {
					return array( 'typing' => false );
				}
				$counterpart = $this->participants->counterpartUserId( $conversation_id, $me );
				if ( ! $counterpart ) {
					return array( 'typing' => false );
				}
				$out = array(
					'typing'  => $this->presence->isTyping( $conversation_id, (int) $counterpart ),
					'user_id' => (int) $counterpart,
				);

				// 1.32.15 — on a support case the customer is told WHO is typing,
				// using the agent's public name ("Alpha is typing…") instead of a
				// nameless row of dots. Additive: clients that do not know the key
				// keep rendering exactly what they rendered before.
				$label = $this->supportTypingLabel( $conversation_id, $me );
				if ( '' !== $label ) {
					$out['typing_label'] = $label;
				}

				return $out;
			}
		);
	}

	/**
	 * "<public name> is typing…" for a customer watching a support case.
	 *
	 * Returns '' — meaning "render exactly what you rendered before 1.32.15" —
	 * for every other situation: buyer↔vendor chats, agents (who are shown the
	 * real conversation, not a persona), a missing Support module, or any
	 * failure at all.
	 *
	 * The name is the CASE OWNER's, taken from `zc_support_tickets.agent_id`,
	 * which is claimed by the first agent to reply and never reassigned to a
	 * later one. One case therefore keeps one persona for its whole life, so the
	 * customer never sees the person they are talking to appear to change.
	 *
	 * Deliberately resolved lazily rather than through the constructor: adding a
	 * Support dependency to this controller's signature would change how the
	 * whole Realtime module is built, and this is decoration on a polling
	 * endpoint. It must never be able to break typing for anybody.
	 *
	 * @since 1.32.15
	 * @param int $conversation_id Conversation being polled.
	 * @param int $viewer_id       The user who will see the label.
	 */
	private function supportTypingLabel( int $conversation_id, int $viewer_id ): string {
		$support_class  = \ZymargCommunication\Modules\Support\Services\SupportService::class;
		$identity_class = \ZymargCommunication\Modules\Support\Services\SupportIdentitySettings::class;

		if ( ! class_exists( $support_class ) || ! class_exists( $identity_class ) ) {
			return '';
		}

		try {
			if ( ! ServiceProvider::has( $support_class ) ) {
				return '';
			}
			$support = ServiceProvider::get( $support_class );

			if ( ! $support->isSupportConversation( $conversation_id ) ) {
				return '';
			}
			// Agents keep the unnamed indicator: they are looking at the customer,
			// whose real name they already see in the thread header.
			if ( $support->isAgent( $viewer_id ) ) {
				return '';
			}

			$alias = ( new $identity_class() )->aliasForConversation( $conversation_id );
			if ( '' === $alias ) {
				return '';
			}

			return sprintf(
				/* translators: %s: the support agent's public name, e.g. "Alpha". */
				__( '%s is typing…', 'zymarg-communication' ),
				$alias
			);
		} catch ( \Throwable $e ) {
			return '';
		}
	}

	public function presenceStatus( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle(
			function () use ( $request ) {
				$this->requireAuthenticated();
				$conversation_id = (int) $request->get_param( 'conversation_id' );
				if ( $conversation_id < 1 ) {
					return $this->fail( 'invalid_conversation', __( 'Invalid conversation.', 'zymarg-communication' ), 400 );
				}
				$me = $this->currentUserId();
				if ( ! $this->participants->isParticipant( $conversation_id, $me ) ) {
					return array( 'online' => false, 'last_seen' => null );
				}
				$counterpart = $this->participants->counterpartUserId( $conversation_id, $me );
				if ( ! $counterpart ) {
					return array( 'online' => false, 'last_seen' => null );
				}
				return array(
					'online'    => $this->presence->isOnline( (int) $counterpart ),
					'last_seen' => $this->presence->lastSeen( (int) $counterpart ),
					'user_id'   => (int) $counterpart,
				);
			}
		);
	}

	public function ack( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle(
			function () use ( $request ) {
				$this->requireAuthenticated();
				$event_id = (string) $request->get_param( 'event_id' );
				if ( '' === $event_id ) {
					return $this->fail( 'missing_event_id', __( 'Missing event_id.', 'zymarg-communication' ), 400 );
				}
				$this->queue->ack( $this->currentUserId(), $event_id );
				return array( 'ok' => true );
			}
		);
	}
}
