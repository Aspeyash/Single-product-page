<?php
/**
 * Plain data object representing a realtime event to be delivered.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Realtime\Models;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class RealtimeEvent {

	/**
	 * @param array<string, mixed> $payload
	 */
	public function __construct(
		public string $channel,
		public string $event,
		public array $payload,
		public ?int $recipientUserId = null,
		public ?string $createdAt = null,
		public ?string $id = null
	) {
		$this->createdAt = $createdAt ?? gmdate( 'Y-m-d\\TH:i:s\\Z' );
		$this->id        = $id ?? uniqid( 'evt_', true );
	}

	public function toArray(): array {
		return array(
			'id'                 => $this->id,
			'channel'            => $this->channel,
			'event'              => $this->event,
			'payload'            => $this->payload,
			'recipient_user_id'  => $this->recipientUserId,
			'created_at'         => $this->createdAt,
		);
	}

	public static function fromArray( array $data ): self {
		return new self(
			(string) ( $data['channel'] ?? '' ),
			(string) ( $data['event'] ?? '' ),
			is_array( $data['payload'] ?? null ) ? $data['payload'] : array(),
			isset( $data['recipient_user_id'] ) ? (int) $data['recipient_user_id'] : null,
			$data['created_at'] ?? null,
			$data['id'] ?? null
		);
	}
}
