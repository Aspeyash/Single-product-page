<?php
/**
 * DeveloperHooks — registers the Developer REST controller, subscribes
 * WebhookService to the plugin's domain events, enqueues the frontend JS
 * SDK, and enables API-key bearer authentication for REST endpoints.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Developer\Hooks;

use ZymargCommunication\Bootstrap\ServiceProvider;
use ZymargCommunication\Core\Contracts\HookableInterface;
use ZymargCommunication\Infrastructure\Http\Controllers\RestController;
use ZymargCommunication\Modules\Developer\Controllers\DeveloperController;
use ZymargCommunication\Modules\Developer\Services\ApiKeyService;
use ZymargCommunication\Modules\Developer\Services\WebhookService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class DeveloperHooks implements HookableInterface {

	private const RELAYED_EVENTS = array(
		'message_sent',
		'conversation_created',
		'conversation_closed',
		'participant_joined',
		'attachment_uploaded',
		'moderation_reported',
		'moderation_resolved',
	);

	public static function register(): void {
		$instance = new self();
		$instance->registerHooks();
	}

	private function registerHooks(): void {
		if ( ServiceProvider::has( DeveloperController::class ) ) {
			$controller = ServiceProvider::get( DeveloperController::class );
			if ( $controller instanceof DeveloperController ) {
				RestController::register( $controller );
			}
		}

		foreach ( self::RELAYED_EVENTS as $event ) {
			add_action(
				'zymarg_comm_event_' . $event,
				static function ( $payload ) use ( $event ) {
					if ( ! ServiceProvider::has( WebhookService::class ) ) {
						return;
					}
					$service = ServiceProvider::get( WebhookService::class );
					if ( $service instanceof WebhookService ) {
						$service->dispatch( $event, is_array( $payload ) ? $payload : array() );
					}
				},
				30,
				1
			);
		}

		add_action( 'wp_enqueue_scripts', array( $this, 'enqueueSdk' ) );

		// API-key bearer authentication for REST requests. Rejects invalid or
		// revoked keys with 401 before any permission callback runs.
		add_filter( 'rest_authentication_errors', array( $this, 'authenticateApiKey' ), 20 );
	}

	public function enqueueSdk(): void {
		$base    = defined( 'ZYMARG_COMM_URL' ) ? ZYMARG_COMM_URL : plugin_dir_url( ZYMARG_COMM_FILE );
		$version = defined( 'ZYMARG_COMM_VERSION' ) ? ZYMARG_COMM_VERSION : '1.9.0';

		wp_register_script(
			'zymarg-comm-sdk',
			$base . 'assets/js/frontend/sdk.js',
			array(),
			$version,
			true
		);

		wp_localize_script(
			'zymarg-comm-sdk',
			'ZymargCommSdkConfig',
			array(
				'restUrl' => esc_url_raw( rest_url( 'zymarg-comm/v1' ) ),
				'nonce'   => wp_create_nonce( 'wp_rest' ),
				'userId'  => (int) get_current_user_id(),
				'version' => $version,
			)
		);

		wp_enqueue_script( 'zymarg-comm-sdk' );
	}

	/**
	 * REST authentication for `Authorization: Bearer zc_...` tokens.
	 *
	 * Runs on `rest_authentication_errors`. Returning a WP_Error short-circuits
	 * the request. Returning null leaves the value untouched so other auth
	 * methods (cookie/nonce) still run.
	 *
	 * @param mixed $result Existing authentication result.
	 * @return mixed
	 */
	public function authenticateApiKey( $result ) {
		if ( ! empty( $result ) ) {
			return $result;
		}
		$header = $this->readAuthorizationHeader();
		if ( '' === $header || 0 !== stripos( $header, 'bearer ' ) ) {
			return $result;
		}
		$token = trim( substr( $header, 7 ) );
		if ( '' === $token || 0 !== strpos( $token, 'zc_' ) ) {
			return $result;
		}

		if ( ! ServiceProvider::has( ApiKeyService::class ) ) {
			return $result;
		}
		$service = ServiceProvider::get( ApiKeyService::class );
		if ( ! ( $service instanceof ApiKeyService ) ) {
			return $result;
		}

		$row = $service->verify( $token );
		if ( ! $row ) {
			return new \WP_Error(
				'invalid_api_key',
				__( 'Invalid or revoked API key.', 'zymarg-communication' ),
				array( 'status' => 401 )
			);
		}

		$owner_id = (int) $row->owner_id;
		if ( $owner_id > 0 && ! is_user_logged_in() ) {
			wp_set_current_user( $owner_id );
		}
		return true;
	}

	private function readAuthorizationHeader(): string {
		if ( function_exists( 'getallheaders' ) ) {
			$headers = getallheaders();
			if ( is_array( $headers ) ) {
				foreach ( $headers as $name => $value ) {
					if ( 0 === strcasecmp( $name, 'Authorization' ) ) {
						return (string) $value;
					}
				}
			}
		}
		if ( ! empty( $_SERVER['HTTP_AUTHORIZATION'] ) ) {
			return (string) $_SERVER['HTTP_AUTHORIZATION'];
		}
		if ( ! empty( $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ) ) {
			return (string) $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
		}
		return '';
	}
}
