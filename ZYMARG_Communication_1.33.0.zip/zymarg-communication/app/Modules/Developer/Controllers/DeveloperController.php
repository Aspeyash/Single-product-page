<?php
/**
 * REST endpoints for webhook and API-key management, and for listing
 * registered extensions.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Developer\Controllers;

use WP_REST_Request;
use WP_REST_Response;
use ZymargCommunication\Core\Abstracts\AbstractController;
use ZymargCommunication\Infrastructure\Http\Middleware\AuthMiddleware;
use ZymargCommunication\Infrastructure\Http\Middleware\NonceMiddleware;
use ZymargCommunication\Modules\Developer\Services\ApiKeyService;
use ZymargCommunication\Modules\Developer\Services\ExtensionService;
use ZymargCommunication\Modules\Developer\Services\WebhookService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class DeveloperController extends AbstractController {

	public function __construct(
		private WebhookService $webhooks,
		private ApiKeyService $keys,
		private ExtensionService $extensions
	) {}

	public function registerRoutes(): void {
		$ns = self::NAMESPACE;

		register_rest_route( $ns, '/developer/webhooks', array(
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'listWebhooks' ),
				'permission_callback' => array( AuthMiddleware::class, 'requireLoggedIn' ),
			),
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'createWebhook' ),
				'permission_callback' => $this->writeGuard(),
			),
		) );
		register_rest_route( $ns, '/developer/webhooks/(?P<id>\\d+)', array(
			'methods'             => 'DELETE',
			'callback'            => array( $this, 'deleteWebhook' ),
			'permission_callback' => $this->writeGuard(),
		) );

		register_rest_route( $ns, '/developer/keys', array(
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'listKeys' ),
				'permission_callback' => array( AuthMiddleware::class, 'requireLoggedIn' ),
			),
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'createKey' ),
				'permission_callback' => $this->writeGuard(),
			),
		) );
		register_rest_route( $ns, '/developer/keys/(?P<id>\\d+)', array(
			'methods'             => 'DELETE',
			'callback'            => array( $this, 'revokeKey' ),
			'permission_callback' => $this->writeGuard(),
		) );

		register_rest_route( $ns, '/developer/extensions', array(
			'methods'             => 'GET',
			'callback'            => array( $this, 'listExtensions' ),
			'permission_callback' => array( AuthMiddleware::class, 'requireLoggedIn' ),
		) );

		register_rest_route( $ns, '/developer/events', array(
			'methods'             => 'GET',
			'callback'            => array( $this, 'listEvents' ),
			'permission_callback' => array( AuthMiddleware::class, 'requireLoggedIn' ),
		) );
	}

	public function listWebhooks( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle( function () use ( $request ) {
			$this->requireAuthenticated();
			$is_admin = current_user_can( 'manage_options' );
			$scope    = (string) $this->param( $request, 'scope', 'me' );
			$owner_id = ( $is_admin && 'all' === $scope ) ? null : $this->currentUserId();
			return array(
				'webhooks' => null === $owner_id ? $this->webhooks->listAll() : $this->webhooks->listForOwner( $owner_id ),
			);
		} );
	}

	public function createWebhook( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle( function () use ( $request ) {
			$this->requireAuthenticated();
			$input = (array) ( $request->get_json_params() ?: $request->get_params() );
			return array( 'webhook' => $this->webhooks->register( $this->currentUserId(), $input ) );
		} );
	}

	public function deleteWebhook( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle( function () use ( $request ) {
			$this->requireAuthenticated();
			return array(
				'deleted' => $this->webhooks->delete(
					(int) $request->get_param( 'id' ),
					$this->currentUserId(),
					current_user_can( 'manage_options' )
				),
			);
		} );
	}

	public function listKeys( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle( function () use ( $request ) {
			$this->requireAuthenticated();
			return array( 'keys' => $this->keys->listForOwner( $this->currentUserId() ) );
		} );
	}

	public function createKey( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle( function () use ( $request ) {
			$this->requireAuthenticated();
			$input = (array) ( $request->get_json_params() ?: $request->get_params() );
			return array( 'key' => $this->keys->create( $this->currentUserId(), $input ) );
		} );
	}

	public function revokeKey( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle( function () use ( $request ) {
			$this->requireAuthenticated();
			return array(
				'revoked' => $this->keys->revoke(
					(int) $request->get_param( 'id' ),
					$this->currentUserId(),
					current_user_can( 'manage_options' )
				),
			);
		} );
	}

	public function listExtensions( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle( fn () => array( 'extensions' => $this->extensions->list() ) );
	}

	public function listEvents( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle( fn () => array( 'events' => $this->webhooks->allowedEvents() ) );
	}

	private function writeGuard(): callable {
		return static function ( $request ) {
			$auth = AuthMiddleware::requireLoggedIn( $request );
			if ( true !== $auth ) {
				return $auth;
			}
			return NonceMiddleware::verify( $request );
		};
	}
}
