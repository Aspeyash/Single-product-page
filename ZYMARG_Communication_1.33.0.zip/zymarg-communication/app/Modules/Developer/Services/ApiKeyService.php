<?php
/**
 * ApiKeyService — creates, verifies, and revokes API keys.
 *
 * The raw key is returned exactly once on creation. Storage is always the
 * SHA-256 hash of the key. Verification hashes the presented token and
 * compares against the stored hash.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Developer\Services;

use ZymargCommunication\Core\Abstracts\AbstractService;
use ZymargCommunication\Core\Exceptions\NotFoundException;
use ZymargCommunication\Core\Exceptions\ValidationException;
use ZymargCommunication\Modules\Developer\Repositories\DeveloperRepository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ApiKeyService extends AbstractService {

	private const KEY_PREFIX_PLAINTEXT = 'zc_';
	private const KEY_BYTES            = 32;

	public function __construct( private DeveloperRepository $repository ) {}

	public function listForOwner( int $owner_id ): array {
		return array_map(
			static fn( $r ) => array(
				'id'           => (int) $r->id,
				'owner_id'     => (int) $r->owner_id,
				'label'        => (string) $r->label,
				'key_prefix'   => (string) $r->key_prefix,
				'scopes'       => $r->scopes ? (array) json_decode( (string) $r->scopes, true ) : array(),
				'revoked_at'   => $r->revoked_at,
				'last_used_at' => $r->last_used_at,
				'created_at'   => $r->created_at,
			),
			$this->repository->listApiKeys( $owner_id )
		);
	}

	public function create( int $owner_id, array $input ): array {
		$label = trim( (string) ( $input['label'] ?? '' ) );
		if ( '' === $label ) {
			throw new ValidationException( __( 'A label is required.', 'zymarg-communication' ), array( 'label' => 'required' ) );
		}
		$scopes = array_values( array_filter(
			(array) ( $input['scopes'] ?? array() ),
			static fn( $s ) => is_string( $s ) && '' !== $s
		) );

		$raw = self::KEY_PREFIX_PLAINTEXT . bin2hex( random_bytes( self::KEY_BYTES ) );
		$hash   = hash( 'sha256', $raw );
		$prefix = substr( $raw, 0, 10 );

		$id = $this->repository->createApiKey( $owner_id, sanitize_text_field( $label ), $prefix, $hash, $scopes );

		return array(
			'id'         => $id,
			'label'      => $label,
			'key_prefix' => $prefix,
			'key'        => $raw, // Returned exactly once.
			'scopes'     => $scopes,
		);
	}

	public function revoke( int $id, int $actor_id, bool $is_admin ): bool {
		$row = $this->repository->findApiKey( $id );
		if ( ! $row ) {
			throw new NotFoundException( __( 'API key not found.', 'zymarg-communication' ) );
		}
		if ( ! $is_admin && (int) $row->owner_id !== $actor_id ) {
			throw new NotFoundException( __( 'API key not found.', 'zymarg-communication' ) );
		}
		return $this->repository->revokeApiKey( $id );
	}

	public function verify( string $presented ): ?object {
		if ( '' === $presented ) {
			return null;
		}
		$row = $this->repository->findApiKeyByHash( hash( 'sha256', $presented ) );
		if ( ! $row ) {
			return null;
		}
		$this->repository->touchApiKey( (int) $row->id );
		return $row;
	}
}
