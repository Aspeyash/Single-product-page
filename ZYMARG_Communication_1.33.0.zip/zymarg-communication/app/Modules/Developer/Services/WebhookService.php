<?php
/**
 * WebhookService — registers, validates, and dispatches outgoing webhooks.
 *
 * Dispatch is fire-and-forget: `wp_remote_post` with a short timeout, HMAC
 * signature header when a secret is configured, and best-effort status
 * recording. Never throws to the caller — dispatch failures only bump the
 * webhook's `failure_count` and stamp `last_status`.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Developer\Services;

use ZymargCommunication\Core\Abstracts\AbstractService;
use ZymargCommunication\Core\Exceptions\NotFoundException;
use ZymargCommunication\Core\Exceptions\ValidationException;
use ZymargCommunication\Modules\Developer\Models\Webhook;
use ZymargCommunication\Modules\Developer\Repositories\DeveloperRepository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WebhookService extends AbstractService {

	private const ALLOWED_EVENTS = array(
		'message_sent',
		'conversation_created',
		'conversation_closed',
		'participant_joined',
		'attachment_uploaded',
		'moderation_reported',
		'moderation_resolved',
	);

	public function __construct( private DeveloperRepository $repository ) {}

	public function listForOwner( int $owner_id ): array {
		return array_map( static fn( Webhook $w ) => $w->toArray(), $this->repository->listWebhooks( $owner_id ) );
	}

	public function listAll(): array {
		return array_map( static fn( Webhook $w ) => $w->toArray(), $this->repository->listWebhooks() );
	}

	public function register( int $owner_id, array $input ): array {
		$target = trim( (string) ( $input['target_url'] ?? '' ) );
		if ( '' === $target || ! wp_http_validate_url( $target ) ) {
			throw new ValidationException( __( 'A valid target URL is required.', 'zymarg-communication' ), array( 'target_url' => 'invalid' ) );
		}
		if ( 0 !== stripos( $target, 'https://' ) && 0 !== stripos( $target, 'http://' ) ) {
			throw new ValidationException( __( 'Target URL must use http(s).', 'zymarg-communication' ), array( 'target_url' => 'scheme' ) );
		}

		$events = array_values( array_filter(
			(array) ( $input['events'] ?? array() ),
			static fn( $e ) => is_string( $e ) && in_array( $e, self::ALLOWED_EVENTS, true )
		) );
		if ( empty( $events ) ) {
			throw new ValidationException( __( 'Select at least one supported event.', 'zymarg-communication' ), array( 'events' => 'required' ) );
		}

		$secret = (string) ( $input['secret'] ?? '' );
		if ( '' === $secret ) {
			$secret = wp_generate_password( 40, false, false );
		}

		$id      = $this->repository->createWebhook( $owner_id, $target, $events, $secret );
		$webhook = $this->repository->findWebhook( $id );
		if ( ! $webhook ) {
			throw new ValidationException( __( 'Failed to register the webhook.', 'zymarg-communication' ), array( 'store' => 'failed' ) );
		}
		return $webhook->toArray( true );
	}

	public function delete( int $id, int $actor_id, bool $is_admin ): bool {
		$webhook = $this->repository->findWebhook( $id );
		if ( ! $webhook ) {
			throw new NotFoundException( __( 'Webhook not found.', 'zymarg-communication' ) );
		}
		if ( ! $is_admin && $webhook->ownerId !== $actor_id ) {
			throw new NotFoundException( __( 'Webhook not found.', 'zymarg-communication' ) );
		}
		return $this->repository->deleteWebhook( $id );
	}

	public function allowedEvents(): array {
		return self::ALLOWED_EVENTS;
	}

	/**
	 * Fan out an event to every active webhook subscribed to it.
	 */
	public function dispatch( string $event, array $payload ): void {
		if ( ! $this->isEnabled( 'developer.webhooks' ) ) {
			return;
		}
		if ( ! in_array( $event, self::ALLOWED_EVENTS, true ) ) {
			return;
		}
		try {
			$webhooks = $this->repository->listActiveForEvent( $event );
			foreach ( $webhooks as $webhook ) {
				$this->send( $webhook, $event, $payload );
			}
		} catch ( \Throwable $e ) {
			// Dispatch is best-effort; never surface to the caller.
		}
	}

	private function send( Webhook $webhook, string $event, array $payload ): void {
		$body = wp_json_encode(
			array(
				'event'      => $event,
				'payload'    => $payload,
				'webhook_id' => $webhook->id,
				'timestamp'  => time(),
			)
		);
		$headers = array( 'Content-Type' => 'application/json' );
		if ( $webhook->secret ) {
			$headers['X-Zymarg-Signature'] = 'sha256=' . hash_hmac( 'sha256', (string) $body, $webhook->secret );
		}

		$response = wp_remote_post(
			$webhook->targetUrl,
			array(
				'timeout'  => 4,
				'blocking' => (bool) apply_filters( 'zymarg_comm_webhook_blocking', false ),
				'headers'  => $headers,
				'body'     => $body,
			)
		);

		if ( is_wp_error( $response ) ) {
			$this->repository->updateWebhookStatus( $webhook->id, 'error', true );
			return;
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( $code >= 200 && $code < 300 ) {
			$this->repository->updateWebhookStatus( $webhook->id, (string) $code, false );
		} else {
			$this->repository->updateWebhookStatus( $webhook->id, (string) $code, true );
		}
	}
}
