<?php
/**
 * ExtensionService — allows third-party plugins to register as extensions of
 * ZYMARG Communication. Registration is in-memory (per-request) and mirrored
 * through the WordPress filter `zymarg_comm_extensions` so other modules can
 * enumerate registered extensions.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Developer\Services;

use ZymargCommunication\Core\Abstracts\AbstractService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ExtensionService extends AbstractService {

	/** @var array<string, array<string, mixed>> */
	private array $registered = array();

	public function register( string $slug, array $manifest ): void {
		$slug = sanitize_key( $slug );
		if ( '' === $slug ) {
			return;
		}
		$manifest = array_merge(
			array(
				'name'        => $slug,
				'version'     => '0.0.0',
				'author'      => '',
				'homepage'    => '',
				'description' => '',
				'capabilities'=> array(),
			),
			$manifest
		);
		$manifest['slug']         = $slug;
		$manifest['registered_at'] = current_time( 'mysql', true );
		$this->registered[ $slug ] = $manifest;

		/**
		 * Fires when an extension registers with the plugin.
		 *
		 * @param string $slug     Extension slug.
		 * @param array  $manifest Extension manifest.
		 */
		do_action( 'zymarg_comm_extension_registered', $slug, $manifest );
	}

	public function list(): array {
		return (array) apply_filters( 'zymarg_comm_extensions', array_values( $this->registered ) );
	}

	public function find( string $slug ): ?array {
		return $this->registered[ sanitize_key( $slug ) ] ?? null;
	}

	public function unregister( string $slug ): bool {
		$slug = sanitize_key( $slug );
		if ( ! isset( $this->registered[ $slug ] ) ) {
			return false;
		}
		unset( $this->registered[ $slug ] );
		do_action( 'zymarg_comm_extension_unregistered', $slug );
		return true;
	}
}
