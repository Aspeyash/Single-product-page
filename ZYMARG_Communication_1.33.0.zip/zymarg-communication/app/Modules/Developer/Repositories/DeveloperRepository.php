<?php
/**
 * DeveloperRepository — reads and writes for `zc_webhooks` and
 * `zc_api_keys`. Never persists raw API keys — only the SHA-256 hash.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Developer\Repositories;

use ZymargCommunication\Modules\Developer\Models\Webhook;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class DeveloperRepository {

	private \wpdb $wpdb;

	public function __construct() {
		global $wpdb;
		$this->wpdb = $wpdb;
	}

	// ---------- Webhooks ----------

	public function webhooksTable(): string {
		return $this->wpdb->prefix . 'zc_webhooks';
	}

	public function apiKeysTable(): string {
		return $this->wpdb->prefix . 'zc_api_keys';
	}

	public function createWebhook( int $owner_id, string $target_url, array $events, ?string $secret ): int {
		$now = current_time( 'mysql', true );
		$this->wpdb->insert(
			$this->webhooksTable(),
			array(
				'owner_id'   => $owner_id,
				'target_url' => $target_url,
				'events'     => wp_json_encode( array_values( $events ) ),
				'secret'     => $secret,
				'is_active'  => 1,
				'created_at' => $now,
				'updated_at' => $now,
			)
		);
		return (int) $this->wpdb->insert_id;
	}

	public function findWebhook( int $id ): ?Webhook {
		$row = $this->wpdb->get_row(
			$this->wpdb->prepare( 'SELECT * FROM `' . $this->webhooksTable() . '` WHERE id = %d LIMIT 1', $id )
		);
		return $row ? Webhook::fromRow( $row ) : null;
	}

	/** @return Webhook[] */
	public function listWebhooks( ?int $owner_id = null ): array {
		if ( null !== $owner_id ) {
			$rows = $this->wpdb->get_results(
				$this->wpdb->prepare(
					'SELECT * FROM `' . $this->webhooksTable() . '` WHERE owner_id = %d ORDER BY id DESC',
					$owner_id
				)
			);
		} else {
			$rows = $this->wpdb->get_results( 'SELECT * FROM `' . $this->webhooksTable() . '` ORDER BY id DESC' );
		}
		return array_map( static fn( $r ) => Webhook::fromRow( $r ), $rows ?: array() );
	}

	/** @return Webhook[] */
	public function listActiveForEvent( string $event ): array {
		$rows = $this->wpdb->get_results(
			$this->wpdb->prepare(
				'SELECT * FROM `' . $this->webhooksTable() . '` WHERE is_active = 1 AND events LIKE %s',
				'%' . $this->wpdb->esc_like( '"' . $event . '"' ) . '%'
			)
		);
		return array_map( static fn( $r ) => Webhook::fromRow( $r ), $rows ?: array() );
	}

	public function updateWebhookStatus( int $id, string $status, bool $increment_failure = false ): void {
		$sql = 'UPDATE `' . $this->webhooksTable() . '` SET last_status = %s, last_dispatched_at = %s, updated_at = %s';
		if ( $increment_failure ) {
			$sql .= ', failure_count = failure_count + 1';
		} else {
			$sql .= ', failure_count = 0';
		}
		$sql .= ' WHERE id = %d';
		$now  = current_time( 'mysql', true );
		$this->wpdb->query( $this->wpdb->prepare( $sql, $status, $now, $now, $id ) );
	}

	public function setWebhookActive( int $id, bool $active ): bool {
		return false !== $this->wpdb->update(
			$this->webhooksTable(),
			array(
				'is_active'  => $active ? 1 : 0,
				'updated_at' => current_time( 'mysql', true ),
			),
			array( 'id' => $id )
		);
	}

	public function deleteWebhook( int $id ): bool {
		return false !== $this->wpdb->delete( $this->webhooksTable(), array( 'id' => $id ) );
	}

	// ---------- API Keys ----------

	public function createApiKey( int $owner_id, string $label, string $prefix, string $hash, array $scopes = array() ): int {
		$this->wpdb->insert(
			$this->apiKeysTable(),
			array(
				'owner_id'   => $owner_id,
				'label'      => $label,
				'key_prefix' => $prefix,
				'key_hash'   => $hash,
				'scopes'     => wp_json_encode( array_values( $scopes ) ),
				'created_at' => current_time( 'mysql', true ),
			)
		);
		return (int) $this->wpdb->insert_id;
	}

	public function findApiKey( int $id ): ?object {
		return $this->wpdb->get_row(
			$this->wpdb->prepare( 'SELECT * FROM `' . $this->apiKeysTable() . '` WHERE id = %d LIMIT 1', $id )
		);
	}

	public function findApiKeyByHash( string $hash ): ?object {
		return $this->wpdb->get_row(
			$this->wpdb->prepare(
				'SELECT * FROM `' . $this->apiKeysTable() . '` WHERE key_hash = %s AND revoked_at IS NULL LIMIT 1',
				$hash
			)
		);
	}

	public function listApiKeys( ?int $owner_id = null ): array {
		if ( null !== $owner_id ) {
			return $this->wpdb->get_results(
				$this->wpdb->prepare(
					'SELECT id, owner_id, label, key_prefix, scopes, revoked_at, last_used_at, created_at FROM `' . $this->apiKeysTable() . '` WHERE owner_id = %d ORDER BY id DESC',
					$owner_id
				)
			) ?: array();
		}
		return $this->wpdb->get_results(
			'SELECT id, owner_id, label, key_prefix, scopes, revoked_at, last_used_at, created_at FROM `' . $this->apiKeysTable() . '` ORDER BY id DESC'
		) ?: array();
	}

	public function revokeApiKey( int $id ): bool {
		return false !== $this->wpdb->update(
			$this->apiKeysTable(),
			array( 'revoked_at' => current_time( 'mysql', true ) ),
			array( 'id' => $id )
		);
	}

	public function touchApiKey( int $id ): void {
		$this->wpdb->update(
			$this->apiKeysTable(),
			array( 'last_used_at' => current_time( 'mysql', true ) ),
			array( 'id' => $id )
		);
	}
}
