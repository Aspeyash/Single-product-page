<?php
/**
 * Plain data object representing a webhook registration.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Developer\Models;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Webhook {

	/**
	 * @param string[] $events
	 */
	public function __construct(
		public int $id,
		public int $ownerId,
		public string $targetUrl,
		public array $events,
		public ?string $secret,
		public bool $isActive,
		public ?string $lastStatus,
		public ?string $lastDispatchedAt,
		public int $failureCount,
		public string $createdAt,
		public string $updatedAt
	) {}

	public static function fromRow( object $row ): self {
		$events = array();
		if ( isset( $row->events ) && is_string( $row->events ) && '' !== $row->events ) {
			$decoded = json_decode( $row->events, true );
			if ( is_array( $decoded ) ) {
				$events = array_values( array_map( 'strval', $decoded ) );
			}
		}
		return new self(
			(int) ( $row->id ?? 0 ),
			(int) ( $row->owner_id ?? 0 ),
			(string) ( $row->target_url ?? '' ),
			$events,
			isset( $row->secret ) ? (string) $row->secret : null,
			(bool) ( $row->is_active ?? 1 ),
			isset( $row->last_status ) ? (string) $row->last_status : null,
			isset( $row->last_dispatched_at ) ? (string) $row->last_dispatched_at : null,
			(int) ( $row->failure_count ?? 0 ),
			(string) ( $row->created_at ?? '' ),
			(string) ( $row->updated_at ?? '' )
		);
	}

	public function toArray( bool $with_secret = false ): array {
		$out = array(
			'id'                 => $this->id,
			'owner_id'           => $this->ownerId,
			'target_url'         => $this->targetUrl,
			'events'             => $this->events,
			'is_active'          => $this->isActive,
			'last_status'        => $this->lastStatus,
			'last_dispatched_at' => $this->lastDispatchedAt,
			'failure_count'      => $this->failureCount,
			'created_at'         => $this->createdAt,
			'updated_at'         => $this->updatedAt,
			'secret_is_set'      => null !== $this->secret && '' !== $this->secret,
		);
		if ( $with_secret ) {
			$out['secret'] = $this->secret;
		}
		return $out;
	}
}
