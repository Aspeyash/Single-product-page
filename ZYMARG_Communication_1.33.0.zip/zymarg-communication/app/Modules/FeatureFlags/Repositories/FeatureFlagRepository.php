<?php
/**
 * All database reads and writes for the `zc_feature_flags` table.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\FeatureFlags\Repositories;

use ZymargCommunication\Core\Abstracts\AbstractRepository;
use ZymargCommunication\Modules\FeatureFlags\Models\FeatureFlag;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class FeatureFlagRepository extends AbstractRepository {

	protected function tableSuffix(): string {
		return 'zc_feature_flags';
	}

	/** @return array<int, string> */
	public function allKeys(): array {
		$rows = $this->wpdb->get_col( 'SELECT flag_key FROM `' . $this->table() . '`' );
		return is_array( $rows ) ? array_map( 'strval', $rows ) : array();
	}

	/** @return array<int, FeatureFlag> */
	public function findAll(): array {
		$rows = $this->wpdb->get_results( 'SELECT * FROM `' . $this->table() . '` ORDER BY `group` ASC, flag_key ASC' );
		if ( ! is_array( $rows ) ) {
			return array();
		}
		return array_map( array( FeatureFlag::class, 'fromRow' ), $rows );
	}

	/** @return array<int, string> All enabled flag keys. */
	public function allEnabledKeys(): array {
		$rows = $this->wpdb->get_col( 'SELECT flag_key FROM `' . $this->table() . '` WHERE is_enabled = 1' );
		return is_array( $rows ) ? array_map( 'strval', $rows ) : array();
	}

	public function findByKey( string $flag_key ): ?FeatureFlag {
		$row = $this->wpdb->get_row(
			$this->wpdb->prepare( 'SELECT * FROM `' . $this->table() . '` WHERE flag_key = %s LIMIT 1', $flag_key )
		);
		return $row ? FeatureFlag::fromRow( $row ) : null;
	}

	public function create( array $flag ): int {
		$data = array(
			'flag_key'    => $flag['flag_key'],
			'group'       => $flag['group'] ?? '',
			'label'       => $flag['label'] ?? '',
			'description' => $flag['description'] ?? '',
			'is_enabled'  => (int) ( $flag['is_enabled'] ?? 0 ),
			'is_locked'   => (int) ( $flag['is_locked'] ?? 0 ),
			'updated_at'  => current_time( 'mysql', true ),
		);
		return $this->insert( $data );
	}

	public function setEnabled( string $flag_key, bool $enabled ): bool {
		$affected = $this->wpdb->update(
			$this->table(),
			array(
				'is_enabled' => $enabled ? 1 : 0,
				'updated_at' => current_time( 'mysql', true ),
			),
			array( 'flag_key' => $flag_key )
		);
		return false !== $affected;
	}
}
