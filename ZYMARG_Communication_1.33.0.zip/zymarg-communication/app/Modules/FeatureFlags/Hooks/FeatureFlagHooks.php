<?php
/**
 * Registers WordPress actions and filters owned by the FeatureFlags module.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\FeatureFlags\Hooks;

use ZymargCommunication\Bootstrap\ServiceProvider;
use ZymargCommunication\Core\Contracts\HookableInterface;
use ZymargCommunication\Infrastructure\Http\Controllers\RestController;
use ZymargCommunication\Modules\FeatureFlags\Controllers\FeatureFlagController;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class FeatureFlagHooks implements HookableInterface {

	public static function register(): void {
		$instance = new self();
		$instance->registerHooks();
	}

	private function registerHooks(): void {
		$controller = ServiceProvider::get( FeatureFlagController::class );
		if ( $controller instanceof FeatureFlagController ) {
			RestController::register( $controller );
		}
	}
}
