<?php
/**
 * The single `isEnabled()` authority.
 *
 * Reads/writes flag state via the repository and caches enabled keys via
 * `FeatureFlagCacheService` so the database is hit at most once per request.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\FeatureFlags\Services;

use ZymargCommunication\Core\Contracts\FeatureFlagInterface;
use ZymargCommunication\Core\Contracts\ServiceInterface;
use ZymargCommunication\Modules\FeatureFlags\Repositories\FeatureFlagRepository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class FeatureFlagService implements FeatureFlagInterface, ServiceInterface {

	public function __construct(
		private FeatureFlagRepository $repository,
		private FeatureFlagCacheService $cache
	) {}

	public function isEnabled( string $flag_key ): bool {
		if ( '' === $flag_key ) {
			return false;
		}
		return in_array( $flag_key, $this->enabledKeys(), true );
	}

	/**
	 * Whether a row for this flag exists at all.
	 *
	 * Distinguishes "explicitly switched off" from "never seeded", so callers
	 * guarding a feature that ships enabled by default can fail open instead of
	 * staying dark on sites that upgraded without reactivating.
	 */
	public function exists( string $flag_key ): bool {
		if ( '' === $flag_key ) {
			return false;
		}
		return null !== $this->repository->findByKey( $flag_key );
	}

	public function enable( string $flag_key ): bool {
		return $this->setEnabled( $flag_key, true );
	}

	public function disable( string $flag_key ): bool {
		return $this->setEnabled( $flag_key, false );
	}

	/** @return array<int, array<string, mixed>> */
	public function getAll(): array {
		$flags = $this->repository->findAll();
		return array_map( static fn( $f ) => $f->toArray(), $flags );
	}

	/** @return array<int, string> */
	public function enabledKeys(): array {
		$cached = $this->cache->getEnabledKeys();
		if ( null !== $cached ) {
			return $cached;
		}

		$keys = $this->repository->allEnabledKeys();
		$this->cache->setEnabledKeys( $keys );
		return $keys;
	}

	private function setEnabled( string $flag_key, bool $enabled ): bool {
		$flag = $this->repository->findByKey( $flag_key );
		if ( ! $flag ) {
			return false;
		}
		if ( $flag->isLocked ) {
			return false;
		}

		$ok = $this->repository->setEnabled( $flag_key, $enabled );
		if ( $ok ) {
			$this->cache->invalidate();
			do_action( 'zymarg_comm_flag_updated', $flag_key, $enabled );
		}
		return $ok;
	}
}
