<?php
/**
 * Caches flag state so every request does not hit the database.
 * Cache is invalidated on any flag write.
 *
 * Uses WordPress non-persistent object cache so it is scoped to a single request
 * unless a persistent object cache is available.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\FeatureFlags\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class FeatureFlagCacheService {

	private const GROUP = 'zymarg_comm_feature_flags';
	private const KEY   = 'enabled_keys';
	private const TTL   = 300; // 5 minutes ceiling; also invalidated on write.

	/** @var array<int, string>|null */
	private ?array $requestCache = null;

	/** @return array<int, string> */
	public function getEnabledKeys(): ?array {
		if ( null !== $this->requestCache ) {
			return $this->requestCache;
		}

		$cached = wp_cache_get( self::KEY, self::GROUP );
		if ( is_array( $cached ) ) {
			$this->requestCache = $cached;
			return $this->requestCache;
		}

		return null;
	}

	/** @param array<int, string> $keys */
	public function setEnabledKeys( array $keys ): void {
		$this->requestCache = $keys;
		wp_cache_set( self::KEY, $keys, self::GROUP, self::TTL );
	}

	public function invalidate(): void {
		$this->requestCache = null;
		wp_cache_delete( self::KEY, self::GROUP );
	}
}
