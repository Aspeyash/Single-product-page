<?php
/**
 * Surface flag definitions.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\FeatureFlags\Definitions;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class SurfaceFlags {

	public const GROUP = 'surface';

	/** @return array<int, array<string, mixed>> */
	public static function all(): array {
		return array(
			array(
				'flag_key'    => 'surface.popup',
				'label'       => __( 'Store page chat popup', 'zymarg-communication' ),
				'description' => __( 'Disabling hides popup on all store pages.', 'zymarg-communication' ),
				'is_enabled'  => 1,
				'is_locked'   => 0,
			),
			array(
				'flag_key'    => 'surface.buyer_inbox',
				'label'       => __( 'Buyer inbox', 'zymarg-communication' ),
				'description' => __( 'Disabling hides the buyer inbox page.', 'zymarg-communication' ),
				'is_enabled'  => 1,
				'is_locked'   => 0,
			),
			array(
				'flag_key'    => 'surface.vendor_inbox',
				'label'       => __( 'Vendor inbox', 'zymarg-communication' ),
				'description' => __( 'Disabling hides the vendor inbox page.', 'zymarg-communication' ),
				'is_enabled'  => 1,
				'is_locked'   => 0,
			),
			array(
				'flag_key'    => 'surface.popup_draggable',
				'label'       => __( 'Draggable chat popup', 'zymarg-communication' ),
				'description' => __( 'Lets people drag the chat popup by its header and resize it from the top-left corner. Position and size are remembered per device. Ignored below 768px.', 'zymarg-communication' ),
				'is_enabled'  => 1,
				'is_locked'   => 0,
			),
			array(
				'flag_key'    => 'surface.host_native_chrome',
				'label'       => __( 'Match host page heading style', 'zymarg-communication' ),
				'description' => __( 'Off by default. Swaps the inbox\'s own title for the host page\'s section heading (the theme\'s panel header on My Account, the dashboard greeting on the seller side) and puts the inbox back inside the host\'s page frame instead of running edge to edge. Most setups look better edge to edge, so try it on a staging site first.', 'zymarg-communication' ),
				'is_enabled'  => 0,
				'is_locked'   => 0,
			),
			array(
				'flag_key'    => 'surface.support_chat',
				// 1.32.15 — renamed in step with the submenu. NOTE: FlagRegistry::
				// writeDefaults() only INSERTS keys it has never seen, so an install
				// that already has this row keeps the label stored in its database.
				// The wording here therefore only reaches fresh installs; it is
				// updated regardless because the old text pointed at an
				// "Admin⇄User screen" that no longer exists by that name.
				'label'       => __( 'Support messaging', 'zymarg-communication' ),
				'description' => __( 'Direct support chat between your team and your users. Ships disabled; turn it on from the Support screen.', 'zymarg-communication' ),
				'is_enabled'  => 0,
				'is_locked'   => 0,
			),
		);
	}
}
