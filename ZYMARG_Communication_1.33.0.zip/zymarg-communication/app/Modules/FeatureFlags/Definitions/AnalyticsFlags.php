<?php
/**
 * Analytics flag definitions.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\FeatureFlags\Definitions;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AnalyticsFlags {

	public const GROUP = 'analytics';

	/** @return array<int, array<string, mixed>> */
	public static function all(): array {
		return array(
			self::flag(
				'analytics.tracking',
				__( 'Event tracking', 'zymarg-communication' ),
				1,
				__( 'When enabled, plugin events (messages, conversations, moderation, etc.) are recorded to the analytics table.', 'zymarg-communication' )
			),
			self::flag(
				'analytics.admin_dashboard',
				__( 'Admin analytics dashboard', 'zymarg-communication' ),
				1
			),
			self::flag(
				'analytics.user_dashboard',
				__( 'Per-user analytics dashboard', 'zymarg-communication' ),
				1
			),
		);
	}

	private static function flag( string $key, string $label, int $enabled, string $description = '' ): array {
		return array(
			'flag_key'    => $key,
			'label'       => $label,
			'description' => $description,
			'is_enabled'  => $enabled,
			'is_locked'   => 0,
		);
	}
}
