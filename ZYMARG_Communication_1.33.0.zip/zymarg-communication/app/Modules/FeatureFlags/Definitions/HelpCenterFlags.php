<?php
/**
 * HelpCenter flag definitions.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\FeatureFlags\Definitions;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class HelpCenterFlags {

	public const GROUP = 'help_center';

	/** @return array<int, array<string, mixed>> */
	public static function all(): array {
		return array(
			self::flag( 'help_center.guides',   __( 'User and admin guides', 'zymarg-communication' ), 1 ),
			self::flag( 'help_center.docs',     __( 'Developer documentation', 'zymarg-communication' ), 1 ),
			self::flag( 'help_center.faq',      __( 'FAQ articles', 'zymarg-communication' ), 1 ),
			self::flag( 'help_center.changelog',__( 'Changelog viewer', 'zymarg-communication' ), 1 ),
		);
	}

	private static function flag( string $key, string $label, int $enabled, string $description = '' ): array {
		return array(
			'flag_key'    => $key,
			'label'       => $label,
			'description' => $description,
			'is_enabled'  => $enabled,
			'is_locked'   => 0,
		);
	}
}
