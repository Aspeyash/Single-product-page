<?php
/**
 * Marketplace flag definitions.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\FeatureFlags\Definitions;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class MarketplaceFlags {

	public const GROUP = 'marketplace';

	/** @return array<int, array<string, mixed>> */
	public static function all(): array {
		return array(
			self::flag( 'marketplace.product_sharing', __( 'Share products in chat', 'zymarg-communication' ), 1 ),
			self::flag( 'marketplace.category_sharing', __( 'Share categories in chat', 'zymarg-communication' ), 1 ),
			self::flag( 'marketplace.store_link_sharing', __( 'Share store links in chat', 'zymarg-communication' ), 1 ),
			self::flag( 'marketplace.order_chat', __( 'Order chat', 'zymarg-communication' ), 1 ),
			self::flag( 'marketplace.order_timeline', __( 'Order timeline in chat', 'zymarg-communication' ), 0 ),
		);
	}

	private static function flag( string $key, string $label, int $enabled ): array {
		return array(
			'flag_key'    => $key,
			'label'       => $label,
			'description' => '',
			'is_enabled'  => $enabled,
			'is_locked'   => 0,
		);
	}
}
