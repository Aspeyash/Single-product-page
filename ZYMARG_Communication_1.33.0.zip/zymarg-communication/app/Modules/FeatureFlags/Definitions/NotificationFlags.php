<?php
/**
 * Notification flag definitions.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\FeatureFlags\Definitions;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class NotificationFlags {

	public const GROUP = 'notification';

	/** @return array<int, array<string, mixed>> */
	public static function all(): array {
		return array(
			self::flag( 'notification.email', __( 'Email notifications', 'zymarg-communication' ), 1 ),
			self::flag( 'notification.push', __( 'Mobile push notifications', 'zymarg-communication' ), 1 ),
			self::flag( 'notification.browser', __( 'Browser notifications', 'zymarg-communication' ), 1 ),
			self::flag( 'notification.quiet_hours', __( 'Quiet hours', 'zymarg-communication' ), 1 ),
		);
	}

	private static function flag( string $key, string $label, int $enabled ): array {
		return array(
			'flag_key'    => $key,
			'label'       => $label,
			'description' => '',
			'is_enabled'  => $enabled,
			'is_locked'   => 0,
		);
	}
}
