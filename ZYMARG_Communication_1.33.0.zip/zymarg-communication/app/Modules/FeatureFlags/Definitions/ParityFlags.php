<?php
/**
 * Parity flag definitions. Every flag here applies to both sides simultaneously.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\FeatureFlags\Definitions;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ParityFlags {

	public const GROUP = 'parity';

	/** @return array<int, array<string, mixed>> */
	public static function all(): array {
		return array(
			self::flag( 'parity.response_rate', __( 'Response rate visibility', 'zymarg-communication' ), 1 ),
			self::flag( 'parity.last_active', __( 'Last active visibility', 'zymarg-communication' ), 1 ),
			self::flag( 'parity.avatar', __( 'Avatar visibility', 'zymarg-communication' ), 1 ),
			self::flag( 'parity.profile_info', __( 'Profile info visibility', 'zymarg-communication' ), 1 ),
			self::flag( 'parity.join_date', __( 'Join / open date visibility', 'zymarg-communication' ), 0 ),
			self::flag( 'parity.order_count', __( 'Order / sales count visibility', 'zymarg-communication' ), 0 ),
		);
	}

	private static function flag( string $key, string $label, int $enabled ): array {
		return array(
			'flag_key'    => $key,
			'label'       => $label,
			'description' => __( 'Applies to both sides.', 'zymarg-communication' ),
			'is_enabled'  => $enabled,
			'is_locked'   => 0,
		);
	}
}
