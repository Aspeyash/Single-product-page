<?php
/**
 * Message flag definitions.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\FeatureFlags\Definitions;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class MessageFlags {

	public const GROUP = 'message';

	/** @return array<int, array<string, mixed>> */
	public static function all(): array {
		return array(
			self::flag( 'message.attachments', __( 'Image attachments', 'zymarg-communication' ), 1 ),
			self::flag( 'message.replies', __( 'Reply to message', 'zymarg-communication' ), 1 ),
			self::flag( 'message.reactions', __( 'Message reactions', 'zymarg-communication' ), 1 ),
			self::flag( 'message.read_receipts', __( 'Read receipts', 'zymarg-communication' ), 1 ),
			self::flag( 'message.delivered_status', __( 'Delivered status', 'zymarg-communication' ), 1 ),
			self::flag( 'message.typing_indicator', __( 'Typing indicator', 'zymarg-communication' ), 1, __( 'Requires realtime driver.', 'zymarg-communication' ) ),
			self::flag( 'message.online_status', __( 'Online status', 'zymarg-communication' ), 1, __( 'Requires realtime driver.', 'zymarg-communication' ) ),
		);
	}

	private static function flag( string $key, string $label, int $enabled, string $description = '' ): array {
		return array(
			'flag_key'    => $key,
			'label'       => $label,
			'description' => $description,
			'is_enabled'  => $enabled,
			'is_locked'   => 0,
		);
	}
}
