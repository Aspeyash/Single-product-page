<?php
/**
 * Realtime driver flag definitions.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\FeatureFlags\Definitions;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class RealtimeFlags {

	public const GROUP = 'realtime';

	/** @return array<int, array<string, mixed>> */
	public static function all(): array {
		return array(
			self::flag( 'realtime.pusher', __( 'Pusher', 'zymarg-communication' ), 1, __( 'Default driver. Requires Pusher credentials in Settings.', 'zymarg-communication' ) ),
			self::flag( 'realtime.websocket', __( 'WebSocket', 'zymarg-communication' ), 0, __( 'Alternative driver. Requires WebSocket-capable hosting.', 'zymarg-communication' ) ),
			self::flag( 'realtime.sse', __( 'Server-Sent Events fallback', 'zymarg-communication' ), 0 ),
			self::flag( 'realtime.polling', __( 'Long-polling fallback', 'zymarg-communication' ), 0 ),
		);
	}

	private static function flag( string $key, string $label, int $enabled, string $description = '' ): array {
		return array(
			'flag_key'    => $key,
			'label'       => $label,
			'description' => $description,
			'is_enabled'  => $enabled,
			'is_locked'   => 0,
		);
	}
}
