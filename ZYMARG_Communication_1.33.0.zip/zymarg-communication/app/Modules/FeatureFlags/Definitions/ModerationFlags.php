<?php
/**
 * Moderation flag definitions.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\FeatureFlags\Definitions;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ModerationFlags {

	public const GROUP = 'moderation';

	/** @return array<int, array<string, mixed>> */
	public static function all(): array {
		return array(
			self::flag( 'moderation.spam_filter', __( 'Spam detection', 'zymarg-communication' ), 1 ),
			self::flag( 'moderation.profanity_filter', __( 'Profanity filter', 'zymarg-communication' ), 0, __( 'Off by default — admin enables if needed.', 'zymarg-communication' ) ),
			self::flag( 'moderation.reporting', __( 'Conversation reporting', 'zymarg-communication' ), 1 ),
		);
	}

	private static function flag( string $key, string $label, int $enabled, string $description = '' ): array {
		return array(
			'flag_key'    => $key,
			'label'       => $label,
			'description' => $description,
			'is_enabled'  => $enabled,
			'is_locked'   => 0,
		);
	}
}
