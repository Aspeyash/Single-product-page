<?php
/**
 * Developer flag definitions.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\FeatureFlags\Definitions;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class DeveloperFlags {

	public const GROUP = 'developer';

	/** @return array<int, array<string, mixed>> */
	public static function all(): array {
		return array(
			self::flag( 'developer.webhooks',   __( 'Outbound webhooks', 'zymarg-communication' ), 1 ),
			self::flag( 'developer.api_keys',   __( 'API keys', 'zymarg-communication' ), 1 ),
			self::flag( 'developer.extensions', __( 'Third-party extensions', 'zymarg-communication' ), 1 ),
		);
	}

	private static function flag( string $key, string $label, int $enabled, string $description = '' ): array {
		return array(
			'flag_key'    => $key,
			'label'       => $label,
			'description' => $description,
			'is_enabled'  => $enabled,
			'is_locked'   => 0,
		);
	}
}
