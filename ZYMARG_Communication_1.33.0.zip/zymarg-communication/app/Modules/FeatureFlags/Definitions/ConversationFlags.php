<?php
/**
 * Conversation flag definitions.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\FeatureFlags\Definitions;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ConversationFlags {

	public const GROUP = 'conversation';

	/** @return array<int, array<string, mixed>> */
	public static function all(): array {
		return array(
			array(
				'flag_key'    => 'conversation.seller_initiate',
				'label'       => __( 'Seller can start conversations', 'zymarg-communication' ),
				'description' => __( 'When on, requires admin approval if buyer has not messaged first.', 'zymarg-communication' ),
				'is_enabled'  => 1,
				'is_locked'   => 0,
			),
			array(
				'flag_key'    => 'conversation.seller_seller',
				'label'       => __( 'Seller to seller messaging', 'zymarg-communication' ),
				'description' => __( 'Allow sellers to message other sellers.', 'zymarg-communication' ),
				'is_enabled'  => 0,
				'is_locked'   => 0,
			),
			array(
				'flag_key'    => 'conversation.buyer_buyer',
				'label'       => __( 'Buyer to buyer messaging', 'zymarg-communication' ),
				'description' => __( 'Allow buyers to message other buyers.', 'zymarg-communication' ),
				'is_enabled'  => 0,
				'is_locked'   => 0,
			),
			array(
				'flag_key'    => 'conversation.archive',
				'label'       => __( 'Archive conversations', 'zymarg-communication' ),
				'description' => __( 'Enable archiving conversations from the inbox.', 'zymarg-communication' ),
				'is_enabled'  => 1,
				'is_locked'   => 0,
			),
			array(
				'flag_key'    => 'conversation.pin',
				'label'       => __( 'Pin conversations', 'zymarg-communication' ),
				'description' => __( 'Enable pinning important conversations.', 'zymarg-communication' ),
				'is_enabled'  => 1,
				'is_locked'   => 0,
			),
			array(
				'flag_key'    => 'conversation.search',
				'label'       => __( 'Search conversations', 'zymarg-communication' ),
				'description' => __( 'Enable searching conversations.', 'zymarg-communication' ),
				'is_enabled'  => 1,
				'is_locked'   => 0,
			),
			array(
				'flag_key'    => 'conversation.filter',
				'label'       => __( 'Filter conversations', 'zymarg-communication' ),
				'description' => __( 'Enable filtering conversations.', 'zymarg-communication' ),
				'is_enabled'  => 1,
				'is_locked'   => 0,
			),
		);
	}
}
