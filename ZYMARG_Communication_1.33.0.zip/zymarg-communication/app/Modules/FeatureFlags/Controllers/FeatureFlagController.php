<?php
/**
 * REST endpoints for reading and toggling feature flags.
 *
 * GET  /flags          — admin only, returns all flags with state.
 * GET  /flags/public   — no auth, returns only enabled flag keys.
 * PATCH /flags/{key}   — admin only, toggles a flag on or off.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\FeatureFlags\Controllers;

use WP_REST_Request;
use WP_REST_Response;
use ZymargCommunication\Core\Abstracts\AbstractController;
use ZymargCommunication\Core\Exceptions\NotFoundException;
use ZymargCommunication\Core\Exceptions\ValidationException;
use ZymargCommunication\Infrastructure\Http\Middleware\AuthMiddleware;
use ZymargCommunication\Infrastructure\Http\Middleware\NonceMiddleware;
use ZymargCommunication\Modules\FeatureFlags\Services\FeatureFlagService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class FeatureFlagController extends AbstractController {

	public function __construct( private FeatureFlagService $service ) {}

	public function registerRoutes(): void {
		register_rest_route(
			self::NAMESPACE,
			'/flags',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'list' ),
				'permission_callback' => array( AuthMiddleware::class, 'requireAdmin' ),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/flags/public',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'listPublic' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/flags/(?P<key>[a-z0-9._-]+)',
			array(
				'methods'             => 'PATCH',
				'callback'            => array( $this, 'toggle' ),
				'permission_callback' => array( $this, 'toggleGuard' ),
				'args'                => array(
					'key'        => array( 'required' => true, 'type' => 'string' ),
					'is_enabled' => array( 'required' => true, 'type' => 'boolean' ),
				),
			)
		);
	}

	public function toggleGuard( WP_REST_Request $request ): bool|\WP_Error {
		$auth = AuthMiddleware::requireAdmin( $request );
		if ( $auth instanceof \WP_Error ) {
			return $auth;
		}
		return NonceMiddleware::verify( $request );
	}

	public function list( WP_REST_Request $request ): WP_REST_Response {
		unset( $request );
		return $this->handle( fn() => array( 'flags' => $this->service->getAll() ) );
	}

	public function listPublic( WP_REST_Request $request ): WP_REST_Response {
		unset( $request );
		return $this->handle( fn() => array( 'enabled' => $this->service->enabledKeys() ) );
	}

	public function toggle( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle(
			function () use ( $request ) {
				$key = sanitize_text_field( (string) $request->get_param( 'key' ) );
				$raw = $request->get_param( 'is_enabled' );
				if ( null === $raw ) {
					throw new ValidationException( 'is_enabled is required.', array( 'is_enabled' => 'Required.' ) );
				}
				$enabled = rest_sanitize_boolean( $raw );

				$ok = $enabled ? $this->service->enable( $key ) : $this->service->disable( $key );
				if ( ! $ok ) {
					throw new NotFoundException( sprintf( 'Flag "%s" does not exist or is locked.', $key ) );
				}

				return array(
					'flag_key'   => $key,
					'is_enabled' => $enabled,
				);
			}
		);
	}
}
