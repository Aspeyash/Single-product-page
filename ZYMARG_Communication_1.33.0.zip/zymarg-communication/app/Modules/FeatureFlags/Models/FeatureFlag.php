<?php
/**
 * Plain data object representing a feature flag record.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\FeatureFlags\Models;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class FeatureFlag {

	public function __construct(
		public int $id,
		public string $flagKey,
		public string $group,
		public string $label,
		public string $description,
		public bool $isEnabled,
		public bool $isLocked,
		public ?string $updatedAt
	) {}

	public static function fromRow( object $row ): self {
		return new self(
			(int) $row->id,
			(string) $row->flag_key,
			(string) ( $row->group ?? '' ),
			(string) ( $row->label ?? '' ),
			(string) ( $row->description ?? '' ),
			(bool) $row->is_enabled,
			(bool) ( $row->is_locked ?? 0 ),
			$row->updated_at ?? null
		);
	}

	public function toArray(): array {
		return array(
			'id'          => $this->id,
			'flag_key'    => $this->flagKey,
			'group'       => $this->group,
			'label'       => $this->label,
			'description' => $this->description,
			'is_enabled'  => $this->isEnabled,
			'is_locked'   => $this->isLocked,
			'updated_at'  => $this->updatedAt,
		);
	}
}
