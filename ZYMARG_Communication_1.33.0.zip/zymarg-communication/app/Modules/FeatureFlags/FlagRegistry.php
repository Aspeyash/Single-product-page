<?php
/**
 * Loads all Definition classes on boot and writes defaults to the database
 * for any flag key that does not yet exist.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\FeatureFlags;

use ZymargCommunication\Modules\FeatureFlags\Definitions\DeveloperFlags;
use ZymargCommunication\Modules\FeatureFlags\Definitions\HelpCenterFlags;
use ZymargCommunication\Modules\FeatureFlags\Definitions\AnalyticsFlags;
use ZymargCommunication\Modules\FeatureFlags\Definitions\ConversationFlags;
use ZymargCommunication\Modules\FeatureFlags\Definitions\MarketplaceFlags;
use ZymargCommunication\Modules\FeatureFlags\Definitions\MessageFlags;
use ZymargCommunication\Modules\FeatureFlags\Definitions\ModerationFlags;
use ZymargCommunication\Modules\FeatureFlags\Definitions\NotificationFlags;
use ZymargCommunication\Modules\FeatureFlags\Definitions\ParityFlags;
use ZymargCommunication\Modules\FeatureFlags\Definitions\RealtimeFlags;
use ZymargCommunication\Modules\FeatureFlags\Definitions\SurfaceFlags;
use ZymargCommunication\Modules\FeatureFlags\Repositories\FeatureFlagRepository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class FlagRegistry {

	private const DEFINITION_MAP = array(
		SurfaceFlags::class      => SurfaceFlags::GROUP,
		ConversationFlags::class => ConversationFlags::GROUP,
		MessageFlags::class      => MessageFlags::GROUP,
		MarketplaceFlags::class  => MarketplaceFlags::GROUP,
		ParityFlags::class       => ParityFlags::GROUP,
		NotificationFlags::class => NotificationFlags::GROUP,
		ModerationFlags::class   => ModerationFlags::GROUP,
		RealtimeFlags::class     => RealtimeFlags::GROUP,
		AnalyticsFlags::class    => AnalyticsFlags::GROUP,
		DeveloperFlags::class    => DeveloperFlags::GROUP,
		HelpCenterFlags::class   => HelpCenterFlags::GROUP,
	);

	/**
	 * Return every flag from every definition class, tagged with its group.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function all(): array {
		$flags = array();
		foreach ( self::DEFINITION_MAP as $class => $group ) {
			if ( ! class_exists( $class ) ) {
				continue;
			}
			foreach ( $class::all() as $flag ) {
				$flag['group'] = $group;
				$flags[]       = $flag;
			}
		}
		return $flags;
	}

	/**
	 * Write any missing flags to the database with their default state.
	 * Existing flags are never overwritten — admins may have toggled them.
	 */
	public static function writeDefaults( ?FeatureFlagRepository $repository = null ): int {
		$repository = $repository ?? new FeatureFlagRepository();
		$existing   = $repository->allKeys();
		$written    = 0;

		foreach ( self::all() as $flag ) {
			if ( in_array( $flag['flag_key'], $existing, true ) ) {
				continue;
			}
			$repository->create( $flag );
			++$written;
		}

		return $written;
	}
}
