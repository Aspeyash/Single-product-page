<?php
/**
 * All database reads and writes for the `zc_audit_logs` table.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Security\Repositories;

use ZymargCommunication\Core\Abstracts\AbstractRepository;
use ZymargCommunication\Modules\Security\Models\AuditLog;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class SecurityRepository extends AbstractRepository {

	protected function tableSuffix(): string {
		return 'zc_audit_logs';
	}

	public function findModel( int $id ): ?AuditLog {
		$row = $this->find( $id );
		return $row ? AuditLog::fromRow( $row ) : null;
	}

	public function record( int $admin_id, string $action, ?string $target_type = null, ?int $target_id = null, ?string $ip_address = null, array $metadata = array() ): int {
		return $this->insert(
			array(
				'admin_id'    => $admin_id,
				'action'      => $action,
				'target_type' => $target_type,
				'target_id'   => $target_id,
				'ip_address'  => $ip_address,
				'metadata'    => $metadata ? wp_json_encode( $metadata ) : null,
				'created_at'  => current_time( 'mysql', true ),
			)
		);
	}

	/** @return array<int, AuditLog> */
	public function findRecent( int $limit = 50, int $offset = 0 ): array {
		$rows = $this->wpdb->get_results(
			$this->wpdb->prepare(
				'SELECT * FROM `' . $this->table() . '` ORDER BY created_at DESC LIMIT %d OFFSET %d',
				$limit,
				$offset
			)
		);
		if ( ! is_array( $rows ) ) {
			return array();
		}
		return array_map( array( AuditLog::class, 'fromRow' ), $rows );
	}

	/** @return array<int, AuditLog> */
	public function findForTarget( string $target_type, int $target_id, int $limit = 50 ): array {
		$rows = $this->wpdb->get_results(
			$this->wpdb->prepare(
				'SELECT * FROM `' . $this->table() . '` WHERE target_type = %s AND target_id = %d ORDER BY created_at DESC LIMIT %d',
				$target_type,
				$target_id,
				$limit
			)
		);
		if ( ! is_array( $rows ) ) {
			return array();
		}
		return array_map( array( AuditLog::class, 'fromRow' ), $rows );
	}
}
