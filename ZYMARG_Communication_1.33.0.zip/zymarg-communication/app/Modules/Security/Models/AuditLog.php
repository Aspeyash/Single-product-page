<?php
/**
 * Plain data object representing an audit log record.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Security\Models;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AuditLog {

	public function __construct(
		public int $id,
		public int $adminId,
		public string $action,
		public ?string $targetType,
		public ?int $targetId,
		public ?string $ipAddress,
		public array $metadata,
		public string $createdAt
	) {}

	public static function fromRow( object $row ): self {
		$metadata = array();
		if ( isset( $row->metadata ) && is_string( $row->metadata ) && '' !== $row->metadata ) {
			$decoded = json_decode( (string) $row->metadata, true );
			if ( is_array( $decoded ) ) {
				$metadata = $decoded;
			}
		}
		return new self(
			(int) $row->id,
			(int) $row->admin_id,
			(string) $row->action,
			$row->target_type ?? null,
			isset( $row->target_id ) ? (int) $row->target_id : null,
			$row->ip_address ?? null,
			$metadata,
			(string) $row->created_at
		);
	}

	public function toArray(): array {
		return array(
			'id'          => $this->id,
			'admin_id'    => $this->adminId,
			'action'      => $this->action,
			'target_type' => $this->targetType,
			'target_id'   => $this->targetId,
			'ip_address'  => $this->ipAddress,
			'metadata'    => $this->metadata,
			'created_at'  => $this->createdAt,
		);
	}
}
