<?php
/**
 * SecurityService — general security utilities. Coordinates the file
 * pipeline: validate → strip → store. Callers hand a $_FILES-shaped array
 * and receive either an error or the final storage metadata.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Security\Services;

use ZymargCommunication\Core\Abstracts\AbstractService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class SecurityService extends AbstractService {

	public function __construct(
		private FileValidationService $validator,
		private ExifStripService $stripper,
		private FileStorageService $storage
	) {}

	/** @return array{ok:bool,error?:string,file?:array<string,mixed>} */
	public function ingestUpload( array $file ): array {
		$check = $this->validator->validate( $file );
		if ( empty( $check['ok'] ) ) {
			return array( 'ok' => false, 'error' => (string) ( $check['error'] ?? __( 'File rejected.', 'zymarg-communication' ) ) );
		}

		$stripped = $this->stripper->strip( (string) $file['tmp_name'], (string) $check['mime'], (string) $check['ext'] );
		if ( empty( $stripped['ok'] ) ) {
			return array( 'ok' => false, 'error' => (string) ( $stripped['error'] ?? __( 'Failed to strip metadata.', 'zymarg-communication' ) ) );
		}

		$stored = $this->storage->store( (string) $stripped['path'], (string) $stripped['filename'] );
		if ( empty( $stored['ok'] ) ) {
			return array( 'ok' => false, 'error' => (string) ( $stored['error'] ?? __( 'Failed to store file.', 'zymarg-communication' ) ) );
		}

		$original_size = (int) $file['size'];
		$stored_size   = @filesize( (string) $stored['path'] );
		return array(
			'ok'   => true,
			'file' => array(
				'path'      => (string) $stored['path'],
				'url'       => (string) $stored['url'],
				'relative'  => (string) $stored['relative'],
				'filename'  => (string) $stored['filename'],
				'mime'      => (string) $check['mime'],
				'ext'       => (string) $check['ext'],
				'width'     => (int) $check['width'],
				'height'    => (int) $check['height'],
				'file_size' => is_int( $stored_size ) ? $stored_size : $original_size,
			),
		);
	}
}
