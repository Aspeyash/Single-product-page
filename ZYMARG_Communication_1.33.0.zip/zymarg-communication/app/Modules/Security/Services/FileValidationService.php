<?php
/**
 * FileValidationService — validates every uploaded file before storage.
 *
 * Rejects everything except JPG / JPEG / PNG / WebP:
 *   • Extension allowlist.
 *   • MIME type via finfo_file() must match the allowlist.
 *   • File signature (magic bytes) must match the claimed MIME.
 *   • Max file size and max image dimensions enforced.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Security\Services;

use ZymargCommunication\Core\Abstracts\AbstractService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class FileValidationService extends AbstractService {

	private const ALLOWED_MIMES = array( 'image/jpeg', 'image/png', 'image/webp' );
	private const ALLOWED_EXTS  = array( 'jpg', 'jpeg', 'png', 'webp' );

	/** @return array{ok:bool,error?:string,mime?:string,ext?:string,width?:int,height?:int} */
	public function validate( array $file ): array {
		if ( ! isset( $file['tmp_name'], $file['name'], $file['size'] ) ) {
			return array( 'ok' => false, 'error' => __( 'Invalid upload.', 'zymarg-communication' ) );
		}
		if ( ! is_string( $file['tmp_name'] ) || ! is_uploaded_file( $file['tmp_name'] ) ) {
			// Allow direct file paths only in tests (WP_TESTS_DOMAIN) but reject in production.
			if ( ! defined( 'WP_TESTS_DOMAIN' ) ) {
				return array( 'ok' => false, 'error' => __( 'Upload did not arrive via POST.', 'zymarg-communication' ) );
			}
		}

		$max_bytes = (int) apply_filters( 'zymarg_comm_max_upload_bytes', 8 * 1024 * 1024 );
		$size      = (int) $file['size'];
		if ( $size <= 0 || $size > $max_bytes ) {
			return array( 'ok' => false, 'error' => __( 'File exceeds the maximum allowed size.', 'zymarg-communication' ) );
		}

		$ext = strtolower( pathinfo( (string) $file['name'], PATHINFO_EXTENSION ) );
		$allowed_exts = (array) apply_filters( 'zymarg_comm_allowed_upload_exts', self::ALLOWED_EXTS );
		if ( ! in_array( $ext, $allowed_exts, true ) ) {
			return array( 'ok' => false, 'error' => __( 'File type not allowed. Only JPG, JPEG, PNG, and WebP are accepted.', 'zymarg-communication' ) );
		}

		$mime = $this->detectMime( $file['tmp_name'] );
		$allowed_mimes = (array) apply_filters( 'zymarg_comm_allowed_upload_mimes', self::ALLOWED_MIMES );
		if ( ! in_array( $mime, $allowed_mimes, true ) ) {
			return array( 'ok' => false, 'error' => __( 'File contents do not match an allowed image type.', 'zymarg-communication' ) );
		}

		if ( ! $this->extensionMatchesMime( $ext, $mime ) ) {
			return array( 'ok' => false, 'error' => __( 'File extension does not match file contents.', 'zymarg-communication' ) );
		}

		if ( ! $this->magicBytesMatch( $file['tmp_name'], $mime ) ) {
			return array( 'ok' => false, 'error' => __( 'File signature check failed.', 'zymarg-communication' ) );
		}

		$dims = @getimagesize( $file['tmp_name'] );
		if ( ! is_array( $dims ) || empty( $dims[0] ) || empty( $dims[1] ) ) {
			return array( 'ok' => false, 'error' => __( 'File is not a valid image.', 'zymarg-communication' ) );
		}

		$max_dim = (int) apply_filters( 'zymarg_comm_max_image_dimension', 8000 );
		if ( $dims[0] > $max_dim || $dims[1] > $max_dim ) {
			return array( 'ok' => false, 'error' => __( 'Image dimensions exceed the maximum allowed.', 'zymarg-communication' ) );
		}

		return array(
			'ok'     => true,
			'mime'   => $mime,
			'ext'    => 'jpeg' === $ext ? 'jpg' : $ext,
			'width'  => (int) $dims[0],
			'height' => (int) $dims[1],
		);
	}

	private function detectMime( string $path ): string {
		if ( function_exists( 'finfo_open' ) ) {
			$finfo = finfo_open( FILEINFO_MIME_TYPE );
			if ( $finfo ) {
				$mime = finfo_file( $finfo, $path );
				finfo_close( $finfo );
				if ( is_string( $mime ) && '' !== $mime ) {
					return strtolower( $mime );
				}
			}
		}
		return '';
	}

	private function extensionMatchesMime( string $ext, string $mime ): bool {
		return match ( $mime ) {
			'image/jpeg' => in_array( $ext, array( 'jpg', 'jpeg' ), true ),
			'image/png'  => 'png' === $ext,
			'image/webp' => 'webp' === $ext,
			default      => false,
		};
	}

	/**
	 * Verifies file signature bytes match the claimed MIME. Rejects executables,
	 * scripts, and any file whose header does not begin with a valid image signature.
	 */
	private function magicBytesMatch( string $path, string $mime ): bool {
		$handle = @fopen( $path, 'rb' );
		if ( ! $handle ) {
			return false;
		}
		$bytes = fread( $handle, 16 );
		fclose( $handle );
		if ( ! is_string( $bytes ) || strlen( $bytes ) < 4 ) {
			return false;
		}

		return match ( $mime ) {
			'image/jpeg' => 0 === strncmp( $bytes, "\xFF\xD8\xFF", 3 ),
			'image/png'  => 0 === strncmp( $bytes, "\x89PNG\r\n\x1A\n", 8 ),
			'image/webp' => 0 === strncmp( $bytes, 'RIFF', 4 ) && strlen( $bytes ) >= 12 && 0 === strncmp( substr( $bytes, 8, 4 ), 'WEBP', 4 ),
			default      => false,
		};
	}
}
