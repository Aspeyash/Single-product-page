<?php
/**
 * AuditLogService — records admin actions silently to `zc_audit_logs`.
 *
 * Every write is best-effort: exceptions are caught, the response that
 * triggered the log is never affected. The log entry is the only durable
 * record of an admin action — no read receipts, no notifications, no
 * side effects on the target resource.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Security\Services;

use ZymargCommunication\Core\Abstracts\AbstractService;
use ZymargCommunication\Modules\Security\Repositories\SecurityRepository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AuditLogService extends AbstractService {

	public function __construct( private SecurityRepository $repository ) {}

	public function record( string $action, ?string $target_type = null, ?int $target_id = null, array $metadata = array(), ?int $admin_id = null ): int {
		try {
			$admin = $admin_id ?? get_current_user_id();
			if ( $admin <= 0 ) {
				return 0;
			}
			return $this->repository->record(
				$admin,
				$action,
				$target_type,
				$target_id,
				$this->ip(),
				$metadata
			);
		} catch ( \Throwable $e ) {
			return 0;
		}
	}

	public function findRecent( int $limit = 50, int $offset = 0 ): array {
		return array_map( fn( $log ) => $log->toArray(), $this->repository->findRecent( $limit, $offset ) );
	}

	public function findForTarget( string $target_type, int $target_id, int $limit = 50 ): array {
		return array_map( fn( $log ) => $log->toArray(), $this->repository->findForTarget( $target_type, $target_id, $limit ) );
	}

	private function ip(): ?string {
		$candidates = array( 'HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR' );
		foreach ( $candidates as $key ) {
			if ( isset( $_SERVER[ $key ] ) && '' !== $_SERVER[ $key ] ) {
				$raw = is_string( $_SERVER[ $key ] ) ? sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) ) : '';
				if ( '' === $raw ) {
					continue;
				}
				$ip = trim( explode( ',', $raw )[0] );
				if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
					return $ip;
				}
			}
		}
		return null;
	}
}
