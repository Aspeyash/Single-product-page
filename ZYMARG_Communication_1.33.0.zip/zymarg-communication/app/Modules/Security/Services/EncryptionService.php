<?php
/**
 * EncryptionService — AES-256-CBC encryption of sensitive credential fields.
 *
 * The key is derived from WordPress's SECURE_AUTH_KEY / SECURE_AUTH_SALT so
 * the encrypted values are portable across a site's lifetime but not
 * portable to a different WordPress install. Consumers should treat the
 * ciphertext as opaque and never inspect it.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Security\Services;

use ZymargCommunication\Core\Abstracts\AbstractService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class EncryptionService extends AbstractService {

	private const CIPHER = 'aes-256-cbc';
	private const PREFIX = 'zc_enc_v1:';

	/**
	 * Encrypts a plaintext string. Returns the ciphertext prefixed with
	 * `zc_enc_v1:` and Base64-encoded. Passing an empty string returns an
	 * empty string (never encrypt nothing).
	 */
	public function encrypt( string $plaintext ): string {
		if ( '' === $plaintext ) {
			return '';
		}
		if ( ! function_exists( 'openssl_encrypt' ) ) {
			return '';
		}
		$iv = openssl_random_pseudo_bytes( openssl_cipher_iv_length( self::CIPHER ) );
		$ct = openssl_encrypt( $plaintext, self::CIPHER, $this->key(), OPENSSL_RAW_DATA, $iv );
		if ( false === $ct ) {
			return '';
		}
		return self::PREFIX . base64_encode( $iv . $ct );
	}

	/**
	 * Decrypts a ciphertext produced by encrypt(). Returns an empty string
	 * on any failure — callers must treat an empty return as "no value".
	 */
	public function decrypt( string $ciphertext ): string {
		if ( '' === $ciphertext ) {
			return '';
		}
		if ( 0 !== strpos( $ciphertext, self::PREFIX ) ) {
			return '';
		}
		if ( ! function_exists( 'openssl_decrypt' ) ) {
			return '';
		}
		$raw = base64_decode( substr( $ciphertext, strlen( self::PREFIX ) ), true );
		if ( ! is_string( $raw ) || '' === $raw ) {
			return '';
		}
		$iv_len = openssl_cipher_iv_length( self::CIPHER );
		if ( strlen( $raw ) <= $iv_len ) {
			return '';
		}
		$iv = substr( $raw, 0, $iv_len );
		$ct = substr( $raw, $iv_len );
		$pt = openssl_decrypt( $ct, self::CIPHER, $this->key(), OPENSSL_RAW_DATA, $iv );
		return is_string( $pt ) ? $pt : '';
	}

	/** True when the given value looks like a value produced by encrypt(). */
	public function isEncrypted( string $value ): bool {
		return '' !== $value && 0 === strpos( $value, self::PREFIX );
	}

	private function key(): string {
		$material = ( defined( 'SECURE_AUTH_KEY' ) ? SECURE_AUTH_KEY : '' )
			. ( defined( 'SECURE_AUTH_SALT' ) ? SECURE_AUTH_SALT : '' )
			. 'zymarg-communication';
		return hash( 'sha256', $material, true );
	}
}
