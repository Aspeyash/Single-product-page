<?php
/**
 * FileStorageService — moves a validated & stripped file to its final path
 * under uploads/zymarg-communication/{yyyy}/{mm}/, drops an execution-block
 * .htaccess + index.html on first use, and enforces 0644 permissions so the
 * stored file cannot be executed by the web server.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Security\Services;

use ZymargCommunication\Core\Abstracts\AbstractService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class FileStorageService extends AbstractService {

	private const SUBDIR = 'zymarg-communication';

	/** @return array{ok:bool,error?:string,path?:string,url?:string,relative?:string,filename?:string} */
	public function store( string $source_path, string $filename ): array {
		if ( ! file_exists( $source_path ) ) {
			return array( 'ok' => false, 'error' => __( 'Stripped source is missing.', 'zymarg-communication' ) );
		}

		$uploads = wp_upload_dir( null, false );
		if ( isset( $uploads['error'] ) && $uploads['error'] ) {
			return array( 'ok' => false, 'error' => (string) $uploads['error'] );
		}

		$year   = gmdate( 'Y' );
		$month  = gmdate( 'm' );
		$root   = trailingslashit( $uploads['basedir'] ) . self::SUBDIR;
		$folder = trailingslashit( $root ) . $year . '/' . $month;
		if ( ! wp_mkdir_p( $folder ) ) {
			return array( 'ok' => false, 'error' => __( 'Could not create upload directory.', 'zymarg-communication' ) );
		}

		$this->ensureGuard( $root );
		$this->ensureGuard( $folder );

		$safe_name = sanitize_file_name( $filename );
		$dest_path = trailingslashit( $folder ) . $safe_name;

		if ( ! @copy( $source_path, $dest_path ) ) {
			return array( 'ok' => false, 'error' => __( 'Failed to move uploaded file.', 'zymarg-communication' ) );
		}
		@unlink( $source_path );
		@chmod( $dest_path, 0644 );

		$relative = self::SUBDIR . '/' . $year . '/' . $month . '/' . $safe_name;
		$url      = trailingslashit( $uploads['baseurl'] ) . $relative;

		return array(
			'ok'       => true,
			'path'     => $dest_path,
			'url'      => $url,
			'relative' => $relative,
			'filename' => $safe_name,
		);
	}

	private function ensureGuard( string $dir ): void {
		$htaccess = trailingslashit( $dir ) . '.htaccess';
		if ( ! file_exists( $htaccess ) ) {
			$rules  = "# ZYMARG Communication \u2014 block direct PHP execution and force safe MIME types.\n";
			$rules .= "<IfModule mod_rewrite.c>\nRewriteEngine On\nRewriteRule ^.*\\.(php|phtml|phar|pl|py|jsp|asp|aspx|sh|cgi)$ - [F,L,NC]\n</IfModule>\n";
			$rules .= "<FilesMatch \"\\.(php|phtml|phar|pl|py|jsp|asp|aspx|sh|cgi)$\">\nRequire all denied\n</FilesMatch>\n";
			$rules .= "Options -ExecCGI -Indexes\n";
			@file_put_contents( $htaccess, $rules );
		}
		$index = trailingslashit( $dir ) . 'index.html';
		if ( ! file_exists( $index ) ) {
			@file_put_contents( $index, '' );
		}
	}
}
