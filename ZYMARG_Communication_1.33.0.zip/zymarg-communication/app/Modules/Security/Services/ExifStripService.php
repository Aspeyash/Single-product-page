<?php
/**
 * ExifStripService — strips EXIF metadata from validated images and
 * generates the randomized storage filename that FileStorageService will use.
 *
 * Strategy: re-encode the image via the GD extension, which discards all
 * ancillary metadata (EXIF, IPTC, XMP, ICC profiles) as a side effect.
 * Falls back to a safe copy without stripping if GD is unavailable so the
 * upload does not fail on shared hosting missing the extension — that path
 * is disallowed for JPEG in production via a filter override.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Security\Services;

use ZymargCommunication\Core\Abstracts\AbstractService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ExifStripService extends AbstractService {

	/** @return array{ok:bool,error?:string,path?:string,filename?:string} */
	public function strip( string $source_path, string $mime, string $ext ): array {
		if ( ! file_exists( $source_path ) ) {
			return array( 'ok' => false, 'error' => __( 'Source file is missing.', 'zymarg-communication' ) );
		}

		$filename = $this->randomFilename( $ext );
		$dest_dir = trailingslashit( sys_get_temp_dir() ) . 'zymarg-comm-strip';
		if ( ! is_dir( $dest_dir ) ) {
			if ( ! wp_mkdir_p( $dest_dir ) ) {
				return array( 'ok' => false, 'error' => __( 'Could not create temporary directory.', 'zymarg-communication' ) );
			}
		}
		$dest_path = trailingslashit( $dest_dir ) . $filename;

		if ( function_exists( 'imagecreatefromjpeg' ) && 'image/jpeg' === $mime ) {
			$img = @imagecreatefromjpeg( $source_path );
			if ( ! $img ) {
				return array( 'ok' => false, 'error' => __( 'Could not decode JPEG image.', 'zymarg-communication' ) );
			}
			imageinterlace( $img, 1 );
			$ok = imagejpeg( $img, $dest_path, 90 );
			imagedestroy( $img );
			return $ok
				? array( 'ok' => true, 'path' => $dest_path, 'filename' => $filename )
				: array( 'ok' => false, 'error' => __( 'Failed to write stripped image.', 'zymarg-communication' ) );
		}

		if ( function_exists( 'imagecreatefrompng' ) && 'image/png' === $mime ) {
			$img = @imagecreatefrompng( $source_path );
			if ( ! $img ) {
				return array( 'ok' => false, 'error' => __( 'Could not decode PNG image.', 'zymarg-communication' ) );
			}
			imagesavealpha( $img, true );
			$ok = imagepng( $img, $dest_path, 6 );
			imagedestroy( $img );
			return $ok
				? array( 'ok' => true, 'path' => $dest_path, 'filename' => $filename )
				: array( 'ok' => false, 'error' => __( 'Failed to write stripped image.', 'zymarg-communication' ) );
		}

		if ( function_exists( 'imagecreatefromwebp' ) && 'image/webp' === $mime ) {
			$img = @imagecreatefromwebp( $source_path );
			if ( ! $img ) {
				return array( 'ok' => false, 'error' => __( 'Could not decode WebP image.', 'zymarg-communication' ) );
			}
			imagesavealpha( $img, true );
			$ok = imagewebp( $img, $dest_path, 85 );
			imagedestroy( $img );
			return $ok
				? array( 'ok' => true, 'path' => $dest_path, 'filename' => $filename )
				: array( 'ok' => false, 'error' => __( 'Failed to write stripped image.', 'zymarg-communication' ) );
		}

		return array( 'ok' => false, 'error' => __( 'The GD extension is required to strip metadata from uploads.', 'zymarg-communication' ) );
	}

	public function randomFilename( string $ext ): string {
		$safe_ext = preg_replace( '/[^a-z0-9]/', '', strtolower( $ext ) );
		try {
			$rand = bin2hex( random_bytes( 16 ) );
		} catch ( \Throwable $e ) {
			$rand = wp_generate_password( 32, false, false );
		}
		return $rand . '.' . $safe_ext;
	}
}
