<?php
/**
 * REST endpoints for security-related admin actions.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Security\Controllers;

use ZymargCommunication\Core\Abstracts\AbstractController;
use ZymargCommunication\Infrastructure\Http\Middleware\AuthMiddleware;
use ZymargCommunication\Infrastructure\Http\Middleware\NonceMiddleware;
use ZymargCommunication\Modules\Security\Services\AuditLogService;
use WP_REST_Request;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class SecurityController extends AbstractController {

	public function __construct( private AuditLogService $audit ) {}

	public function registerRoutes(): void {
		register_rest_route( self::NAMESPACE, '/security/audit-logs', array(
			'methods'             => 'GET',
			'callback'            => array( $this, 'list' ),
			'permission_callback' => static fn( $request ) => AuthMiddleware::requireAdmin( $request ),
		) );

		register_rest_route( self::NAMESPACE, '/security/audit-logs/target', array(
			'methods'             => 'GET',
			'callback'            => array( $this, 'forTarget' ),
			'permission_callback' => static fn( $request ) => AuthMiddleware::requireAdmin( $request ),
		) );
	}

	public function list( WP_REST_Request $request ) {
		return $this->handle( function () use ( $request ) {
			$limit  = max( 1, min( 200, (int) $this->param( $request, 'limit', 50 ) ) );
			$offset = max( 0, (int) $this->param( $request, 'offset', 0 ) );
			return $this->ok( array( 'items' => $this->audit->findRecent( $limit, $offset ) ) );
		} );
	}

	public function forTarget( WP_REST_Request $request ) {
		return $this->handle( function () use ( $request ) {
			$type = sanitize_key( (string) $this->param( $request, 'type', '' ) );
			$id   = (int) $this->param( $request, 'id', 0 );
			if ( '' === $type || $id <= 0 ) {
				return $this->fail( 'invalid_target', __( 'Missing target type or id.', 'zymarg-communication' ), 400 );
			}
			return $this->ok( array( 'items' => $this->audit->findForTarget( $type, $id ) ) );
		} );
	}
}
