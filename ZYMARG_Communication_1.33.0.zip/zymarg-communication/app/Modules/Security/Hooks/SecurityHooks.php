<?php
/**
 * SecurityHooks — registers the Security REST controller.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Security\Hooks;

use ZymargCommunication\Bootstrap\ServiceProvider;
use ZymargCommunication\Core\Contracts\HookableInterface;
use ZymargCommunication\Infrastructure\Http\Controllers\RestController;
use ZymargCommunication\Modules\Security\Controllers\SecurityController;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class SecurityHooks implements HookableInterface {

	public static function register(): void {
		$instance = new self();
		$instance->registerHooks();
	}

	private function registerHooks(): void {
		if ( ! ServiceProvider::has( SecurityController::class ) ) {
			return;
		}
		$controller = ServiceProvider::get( SecurityController::class );
		if ( $controller instanceof SecurityController ) {
			RestController::register( $controller );
		}
	}
}
