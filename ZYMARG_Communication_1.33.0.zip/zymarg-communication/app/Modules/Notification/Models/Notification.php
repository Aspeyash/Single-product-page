<?php
/**
 * Plain data object representing a notification record.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Notification\Models;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Notification {

	public function __construct(
		public int $id,
		public int $userId,
		public string $type,
		public array $payload,
		public string $channel,
		public bool $isRead,
		public ?string $sentAt,
		public ?string $readAt,
		public string $createdAt
	) {}

	public static function fromRow( object $row ): self {
		$payload = array();
		if ( isset( $row->payload ) && is_string( $row->payload ) && '' !== $row->payload ) {
			$decoded = json_decode( (string) $row->payload, true );
			if ( is_array( $decoded ) ) {
				$payload = $decoded;
			}
		}
		return new self(
			(int) $row->id,
			(int) $row->user_id,
			(string) $row->type,
			$payload,
			(string) $row->channel,
			(bool) ( $row->is_read ?? 0 ),
			$row->sent_at ?? null,
			$row->read_at ?? null,
			(string) $row->created_at
		);
	}

	public function toArray(): array {
		return array(
			'id'         => $this->id,
			'user_id'    => $this->userId,
			'type'       => $this->type,
			'payload'    => $this->payload,
			'channel'    => $this->channel,
			'is_read'    => $this->isRead,
			'sent_at'    => $this->sentAt,
			'read_at'    => $this->readAt,
			'created_at' => $this->createdAt,
		);
	}
}
