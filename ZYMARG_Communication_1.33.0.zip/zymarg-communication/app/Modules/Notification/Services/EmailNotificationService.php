<?php
/**
 * EmailNotificationService — sends email notifications via wp_mail().
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Notification\Services;

use ZymargCommunication\Core\Abstracts\AbstractService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class EmailNotificationService extends AbstractService {

	public function __construct( private NotificationPreferenceService $preferences ) {}

	public function channel(): string {
		return 'email';
	}

	/**
	 * Attempt to send. Returns true on success, false when suppressed or on error.
	 *
	 * @param array<string, mixed> $payload
	 */
	public function send( int $user_id, string $type, array $payload ): bool {
		if ( ! $this->preferences->allows( $user_id, 'email' ) ) {
			return false;
		}
		$user = get_userdata( $user_id );
		if ( ! $user || empty( $user->user_email ) ) {
			return false;
		}

		$subject = $this->subjectFor( $type, $payload );
		$body    = $this->bodyFor( $type, $payload );

		/**
		 * Filters the outgoing email payload right before wp_mail.
		 *
		 * @param array{to:string,subject:string,message:string,headers:array} $email
		 * @param int    $user_id
		 * @param string $type
		 * @param array  $payload
		 */
		$email = apply_filters( 'zymarg_comm_notification_email', array(
			'to'      => $user->user_email,
			'subject' => $subject,
			'message' => $body,
			'headers' => array( 'Content-Type: text/html; charset=UTF-8' ),
		), $user_id, $type, $payload );

		return (bool) wp_mail( $email['to'], $email['subject'], $email['message'], $email['headers'] );
	}

	private function subjectFor( string $type, array $payload ): string {
		$site = wp_specialchars_decode( (string) get_bloginfo( 'name' ), ENT_QUOTES );
		switch ( $type ) {
			case 'new_message':
				return sprintf( '[%s] ' . __( 'You have a new message', 'zymarg-communication' ), $site );
			case 'conversation_request':
				return sprintf( '[%s] ' . __( 'New conversation request', 'zymarg-communication' ), $site );
			case 'moderation_alert':
				return sprintf( '[%s] ' . __( 'Moderation alert', 'zymarg-communication' ), $site );
			default:
				return sprintf( '[%s] ' . __( 'Notification', 'zymarg-communication' ), $site );
		}
	}

	private function bodyFor( string $type, array $payload ): string {
		$inbox_url = esc_url( home_url( '/messages/' ) );
		$preview   = isset( $payload['preview'] ) ? esc_html( (string) $payload['preview'] ) : '';
		$open_link = '<p><a href="' . $inbox_url . '">' . esc_html__( 'Open inbox', 'zymarg-communication' ) . '</a></p>';

		switch ( $type ) {
			case 'new_message':
				return '<p>' . esc_html__( 'You have a new message.', 'zymarg-communication' ) . '</p>'
					. ( $preview ? '<blockquote>' . $preview . '</blockquote>' : '' )
					. $open_link;
			case 'conversation_request':
				return '<p>' . esc_html__( 'Someone requested a conversation with you.', 'zymarg-communication' ) . '</p>' . $open_link;
			default:
				return '<p>' . esc_html__( 'You have a new notification.', 'zymarg-communication' ) . '</p>' . $open_link;
		}
	}
}
