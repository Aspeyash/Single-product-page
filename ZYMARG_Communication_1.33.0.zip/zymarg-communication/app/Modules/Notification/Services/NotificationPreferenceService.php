<?php
/**
 * NotificationPreferenceService — reads and writes per-user notification
 * preferences and enforces quiet hours.
 *
 * Preferences are stored in user_meta at key `_zymarg_comm_notification_prefs`
 * as a JSON structure. Missing values inherit their defaults.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Notification\Services;

use ZymargCommunication\Core\Abstracts\AbstractService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class NotificationPreferenceService extends AbstractService {

	public const META_KEY = '_zymarg_comm_notification_prefs';

	private const DEFAULTS = array(
		'email'       => true,
		'push'        => true,
		'browser'     => true,
		'in_app'      => true,
		'quiet_hours' => array(
			'enabled'  => false,
			'start'    => '22:00',
			'end'      => '07:00',
			'timezone' => '',
		),
	);

	/** @return array<string, mixed> */
	public function get( int $user_id ): array {
		$raw = get_user_meta( $user_id, self::META_KEY, true );
		$prefs = is_array( $raw ) ? $raw : array();
		return $this->merge( self::DEFAULTS, $prefs );
	}

	/**
	 * Update a user's preferences. Unknown keys are ignored.
	 *
	 * @param array<string, mixed> $patch
	 * @return array<string, mixed> The merged preferences after update.
	 */
	public function set( int $user_id, array $patch ): array {
		$current = $this->get( $user_id );
		$merged  = $this->merge( $current, $patch );
		update_user_meta( $user_id, self::META_KEY, $merged );
		return $merged;
	}

	/**
	 * Whether a given channel is allowed for a user right now.
	 * Enforces: global feature flag, per-user preference, and quiet hours.
	 */
	public function allows( int $user_id, string $channel ): bool {
		if ( ! in_array( $channel, array( 'email', 'push', 'browser', 'in_app' ), true ) ) {
			return false;
		}

		// Global flag (in_app has no flag; always allowed unless quiet hours).
		$flag_map = array(
			'email'   => 'notification.email',
			'push'    => 'notification.push',
			'browser' => 'notification.browser',
		);
		if ( isset( $flag_map[ $channel ] ) && ! $this->isEnabled( $flag_map[ $channel ] ) ) {
			return false;
		}

		$prefs = $this->get( $user_id );
		if ( empty( $prefs[ $channel ] ) ) {
			return false;
		}

		if ( $this->isInQuietHours( $prefs ) && $this->isEnabled( 'notification.quiet_hours' ) ) {
			return false;
		}

		return true;
	}

	/** @param array<string, mixed> $prefs */
	public function isInQuietHours( array $prefs ): bool {
		$qh = isset( $prefs['quiet_hours'] ) && is_array( $prefs['quiet_hours'] ) ? $prefs['quiet_hours'] : array();
		if ( empty( $qh['enabled'] ) ) {
			return false;
		}
		$start = isset( $qh['start'] ) ? (string) $qh['start'] : '22:00';
		$end   = isset( $qh['end'] ) ? (string) $qh['end'] : '07:00';
		$tz    = ! empty( $qh['timezone'] ) ? (string) $qh['timezone'] : wp_timezone_string();

		try {
			$now = new \DateTimeImmutable( 'now', new \DateTimeZone( $tz ) );
		} catch ( \Throwable $e ) {
			$now = new \DateTimeImmutable( 'now' );
		}
		$current = (int) $now->format( 'Gi' );
		$s       = $this->hhmmToNumeric( $start );
		$e       = $this->hhmmToNumeric( $end );

		if ( $s === $e ) {
			return false;
		}
		if ( $s < $e ) {
			return $current >= $s && $current < $e;
		}
		// Overnight window (e.g. 22:00 → 07:00).
		return $current >= $s || $current < $e;
	}

	private function hhmmToNumeric( string $hhmm ): int {
		$parts = explode( ':', $hhmm );
		$h = isset( $parts[0] ) ? max( 0, min( 23, (int) $parts[0] ) ) : 0;
		$m = isset( $parts[1] ) ? max( 0, min( 59, (int) $parts[1] ) ) : 0;
		return $h * 100 + $m;
	}

	/**
	 * Shallow merge with quiet_hours merged one level deep.
	 *
	 * @param array<string, mixed> $base
	 * @param array<string, mixed> $overlay
	 * @return array<string, mixed>
	 */
	private function merge( array $base, array $overlay ): array {
		$out = $base;
		foreach ( $overlay as $key => $value ) {
			if ( 'quiet_hours' === $key && is_array( $value ) && isset( $out['quiet_hours'] ) && is_array( $out['quiet_hours'] ) ) {
				$out['quiet_hours'] = array_merge( $out['quiet_hours'], $value );
				continue;
			}
			if ( in_array( $key, array( 'email', 'push', 'browser', 'in_app' ), true ) ) {
				$out[ $key ] = (bool) $value;
				continue;
			}
			$out[ $key ] = $value;
		}
		return $out;
	}
}
