<?php
/**
 * PushNotificationService — sends mobile push notifications.
 *
 * Delivery is delegated to an operator-provided HTTP relay (FCM proxy or
 * equivalent). The plugin never speaks directly to APNs/FCM. Options:
 *   • zymarg_comm_push_endpoint  — relay URL
 *   • zymarg_comm_push_token     — bearer token used to authenticate the relay call
 *
 * Device tokens are stored per user in user_meta at `_zymarg_comm_push_tokens`.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Notification\Services;

use ZymargCommunication\Core\Abstracts\AbstractService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class PushNotificationService extends AbstractService {

	public const TOKEN_META_KEY = '_zymarg_comm_push_tokens';

	public function __construct( private NotificationPreferenceService $preferences ) {}

	public function channel(): string {
		return 'push';
	}

	public function isConfigured(): bool {
		return '' !== (string) get_option( 'zymarg_comm_push_endpoint', '' );
	}

	/**
	 * Attempt to send. Returns true on success, false when suppressed or on error.
	 *
	 * @param array<string, mixed> $payload
	 */
	public function send( int $user_id, string $type, array $payload ): bool {
		if ( ! $this->preferences->allows( $user_id, 'push' ) ) {
			return false;
		}
		if ( ! $this->isConfigured() ) {
			return false;
		}
		$tokens = $this->tokensFor( $user_id );
		if ( empty( $tokens ) ) {
			return false;
		}

		$endpoint = (string) get_option( 'zymarg_comm_push_endpoint', '' );
		$secret   = (string) get_option( 'zymarg_comm_push_token', '' );

		$body = wp_json_encode( array(
			'user_id' => $user_id,
			'type'    => $type,
			'tokens'  => $tokens,
			'title'   => isset( $payload['title'] ) ? (string) $payload['title'] : '',
			'body'    => isset( $payload['preview'] ) ? (string) $payload['preview'] : '',
			'data'    => $payload,
		) );

		$response = wp_remote_post( $endpoint, array(
			'timeout' => 5,
			'headers' => array(
				'Content-Type'  => 'application/json',
				'Authorization' => 'Bearer ' . $secret,
			),
			'body'    => $body,
		) );

		if ( is_wp_error( $response ) ) {
			return false;
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		return $code >= 200 && $code < 300;
	}

	/** Register a device token for a user (called via REST from the mobile client). */
	public function registerToken( int $user_id, string $token ): void {
		$tokens = $this->tokensFor( $user_id );
		if ( ! in_array( $token, $tokens, true ) ) {
			$tokens[] = $token;
			update_user_meta( $user_id, self::TOKEN_META_KEY, array_slice( array_values( $tokens ), -10 ) );
		}
	}

	public function unregisterToken( int $user_id, string $token ): void {
		$tokens = array_values( array_filter( $this->tokensFor( $user_id ), fn( $t ) => $t !== $token ) );
		update_user_meta( $user_id, self::TOKEN_META_KEY, $tokens );
	}

	/** @return array<int, string> */
	private function tokensFor( int $user_id ): array {
		$raw = get_user_meta( $user_id, self::TOKEN_META_KEY, true );
		if ( ! is_array( $raw ) ) {
			return array();
		}
		return array_values( array_filter( array_map( 'strval', $raw ), fn( $t ) => '' !== $t ) );
	}
}
