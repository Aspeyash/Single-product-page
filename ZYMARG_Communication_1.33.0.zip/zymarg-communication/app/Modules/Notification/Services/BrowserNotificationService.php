<?php
/**
 * BrowserNotificationService — sends Web Push API browser notifications.
 *
 * The plugin does not implement VAPID signing directly — it relays to an
 * operator-provided Web Push endpoint. Subscriptions are stored per user in
 * user_meta at `_zymarg_comm_browser_subs`.
 *
 * Options:
 *   • zymarg_comm_browser_push_endpoint
 *   • zymarg_comm_browser_push_token
 *   • zymarg_comm_vapid_public_key   — exposed to the frontend for subscribeUser().
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Notification\Services;

use ZymargCommunication\Core\Abstracts\AbstractService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BrowserNotificationService extends AbstractService {

	public const SUB_META_KEY = '_zymarg_comm_browser_subs';

	public function __construct( private NotificationPreferenceService $preferences ) {}

	public function channel(): string {
		return 'browser';
	}

	public function isConfigured(): bool {
		return '' !== (string) get_option( 'zymarg_comm_browser_push_endpoint', '' );
	}

	public function vapidPublicKey(): string {
		return (string) get_option( 'zymarg_comm_vapid_public_key', '' );
	}

	/**
	 * Attempt to send. Returns true on success, false when suppressed or on error.
	 *
	 * @param array<string, mixed> $payload
	 */
	public function send( int $user_id, string $type, array $payload ): bool {
		if ( ! $this->preferences->allows( $user_id, 'browser' ) ) {
			return false;
		}
		if ( ! $this->isConfigured() ) {
			return false;
		}
		$subs = $this->subscriptionsFor( $user_id );
		if ( empty( $subs ) ) {
			return false;
		}

		$endpoint = (string) get_option( 'zymarg_comm_browser_push_endpoint', '' );
		$secret   = (string) get_option( 'zymarg_comm_browser_push_token', '' );

		$body = wp_json_encode( array(
			'user_id'       => $user_id,
			'type'          => $type,
			'subscriptions' => $subs,
			'title'         => isset( $payload['title'] ) ? (string) $payload['title'] : (string) get_bloginfo( 'name' ),
			'body'          => isset( $payload['preview'] ) ? (string) $payload['preview'] : '',
			'url'           => isset( $payload['url'] ) ? (string) $payload['url'] : (string) home_url( '/messages/' ),
			'data'          => $payload,
		) );

		$response = wp_remote_post( $endpoint, array(
			'timeout' => 5,
			'headers' => array(
				'Content-Type'  => 'application/json',
				'Authorization' => 'Bearer ' . $secret,
			),
			'body'    => $body,
		) );

		if ( is_wp_error( $response ) ) {
			return false;
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		return $code >= 200 && $code < 300;
	}

	public function registerSubscription( int $user_id, array $subscription ): void {
		if ( empty( $subscription['endpoint'] ) ) {
			return;
		}
		$subs = $this->subscriptionsFor( $user_id );
		foreach ( $subs as $existing ) {
			if ( isset( $existing['endpoint'] ) && $existing['endpoint'] === $subscription['endpoint'] ) {
				return;
			}
		}
		$subs[] = $subscription;
		update_user_meta( $user_id, self::SUB_META_KEY, array_slice( array_values( $subs ), -5 ) );
	}

	public function unregisterSubscription( int $user_id, string $endpoint ): void {
		$subs = array_values( array_filter(
			$this->subscriptionsFor( $user_id ),
			fn( $s ) => empty( $s['endpoint'] ) || $s['endpoint'] !== $endpoint
		) );
		update_user_meta( $user_id, self::SUB_META_KEY, $subs );
	}

	/** @return array<int, array<string, mixed>> */
	private function subscriptionsFor( int $user_id ): array {
		$raw = get_user_meta( $user_id, self::SUB_META_KEY, true );
		return is_array( $raw ) ? $raw : array();
	}
}
