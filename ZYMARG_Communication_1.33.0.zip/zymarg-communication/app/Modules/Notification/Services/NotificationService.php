<?php
/**
 * NotificationService — central dispatcher.
 *
 * Receives notification requests, records an in_app row, and routes the same
 * payload to email / push / browser channel services based on user
 * preferences and the recipient's online status (email + mobile push are
 * suppressed when the recipient is currently online via realtime).
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Notification\Services;

use ZymargCommunication\Bootstrap\ServiceProvider;
use ZymargCommunication\Core\Abstracts\AbstractService;
use ZymargCommunication\Modules\Conversation\Repositories\ConversationRepository;
use ZymargCommunication\Modules\Conversation\Repositories\ParticipantRepository;
use ZymargCommunication\Modules\Message\Repositories\MessageRepository;
use ZymargCommunication\Modules\Notification\Models\Notification;
use ZymargCommunication\Modules\Notification\Repositories\NotificationRepository;
use ZymargCommunication\Modules\Realtime\Services\PresenceService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class NotificationService extends AbstractService {

	public function __construct(
		private NotificationRepository $notifications,
		private NotificationPreferenceService $preferences,
		private EmailNotificationService $email,
		private PushNotificationService $push,
		private BrowserNotificationService $browser,
		private PresenceService $presence,
		private ConversationRepository $conversations,
		private ParticipantRepository $participants,
		private MessageRepository $messages
	) {}

	/**
	 * Dispatch a notification to a single user across all eligible channels.
	 *
	 * @param array<string, mixed> $payload
	 * @return array<string, bool>  channel => delivered?
	 */
	public function dispatch( int $user_id, string $type, array $payload ): array {
		if ( $user_id <= 0 ) {
			return array();
		}

		$sender_id = isset( $payload['sender_id'] ) ? (int) $payload['sender_id'] : 0;
		if ( $sender_id > 0 && $sender_id === $user_id ) {
			return array();
		}

		/**
		 * Allow integrators to suppress or rewrite a notification before dispatch.
		 *
		 * @param array|null $payload  Return null to suppress entirely.
		 */
		$payload = apply_filters( 'zymarg_comm_notification_before_dispatch', $payload, $user_id, $type );
		if ( null === $payload ) {
			return array();
		}

		$results = array();
		$is_online = $this->presence->isOnline( $user_id );

		// Always record an in_app row so the badge and /notifications endpoint reflect it.
		if ( $this->preferences->allows( $user_id, 'in_app' ) ) {
			$id = $this->notifications->create( $user_id, $type, $payload, 'in_app' );
			if ( $id > 0 ) {
				$this->notifications->markSent( $id );
			}
			$results['in_app'] = $id > 0;
		} else {
			$results['in_app'] = false;
		}

		// Browser push runs regardless of presence — browsers can be closed or
		// backgrounded while the OS still delivers the toast.
		$results['browser'] = $this->deliver( 'browser', $user_id, $type, $payload, fn() => $this->browser->send( $user_id, $type, $payload ) );

		// Email and mobile push are suppressed when the recipient is currently
		// online in realtime — acceptance criterion for Phase 5.
		if ( ! $is_online ) {
			$results['email'] = $this->deliver( 'email', $user_id, $type, $payload, fn() => $this->email->send( $user_id, $type, $payload ) );
			$results['push']  = $this->deliver( 'push', $user_id, $type, $payload, fn() => $this->push->send( $user_id, $type, $payload ) );
		} else {
			$results['email'] = false;
			$results['push']  = false;
		}

		return $results;
	}

	/**
	 * Handle a `message.sent` event: notify every conversation participant
	 * except the sender.
	 */
	public function handleMessageSent( int $message_id, int $conversation_id, int $sender_id, string $body, ?int $parent_id = null ): void {
		if ( $conversation_id <= 0 || $sender_id <= 0 ) {
			return;
		}
		$participants = $this->participants->findForConversation( $conversation_id );
		if ( ! is_array( $participants ) ) {
			return;
		}

		$sender = get_userdata( $sender_id );
		$sender_name = $sender ? $sender->display_name : __( 'Someone', 'zymarg-communication' );
		$preview = wp_trim_words( wp_strip_all_tags( $body ), 24, '…' );

		$payload = array(
			'title'           => sprintf( __( 'New message from %s', 'zymarg-communication' ), $sender_name ),
			'preview'         => $preview,
			'sender_id'       => $sender_id,
			'sender_name'     => $sender_name,
			'conversation_id' => $conversation_id,
			'message_id'      => $message_id,
			'parent_id'       => $parent_id,
			'url'             => home_url( '/messages/' ),
		);

		foreach ( $participants as $participant ) {
			$uid = 0;
			if ( is_object( $participant ) && isset( $participant->userId ) ) {
				$uid = (int) $participant->userId;
			} elseif ( is_object( $participant ) && isset( $participant->user_id ) ) {
				$uid = (int) $participant->user_id;
			} elseif ( is_array( $participant ) && isset( $participant['user_id'] ) ) {
				$uid = (int) $participant['user_id'];
			}
			if ( $uid > 0 && $uid !== $sender_id ) {
				$this->dispatch( $uid, 'new_message', $this->personalise( $payload, $conversation_id, $sender_id, $uid ) );
			}
		}
	}

	/**
	 * Swap a support agent's real name for their public one, per recipient.
	 *
	 * Before 1.32.15 this payload always carried `display_name`, so a customer
	 * whose chat window said "Support team" could still be emailed and pushed
	 * "New message from admin" about that same case. The window and the
	 * notification now agree.
	 *
	 * Scoped as tightly as possible — the payload is returned UNCHANGED unless
	 * all of the following hold:
	 *   - the Support module is present and answers
	 *   - the conversation really is a support case
	 *   - the sender is an agent (a customer's own message keeps their name, so
	 *     agents still see who wrote to them)
	 *   - the recipient is NOT an agent (colleagues need real names to work)
	 *
	 * Any failure returns the original payload, so a notification can never be
	 * lost to this.
	 *
	 * @since 1.32.15
	 * @param array<string,mixed> $payload         Notification payload.
	 * @param int                 $conversation_id Conversation the message is on.
	 * @param int                 $sender_id       Who wrote it.
	 * @param int                 $recipient_id    Who is being notified.
	 * @return array<string,mixed>
	 */
	private function personalise( array $payload, int $conversation_id, int $sender_id, int $recipient_id ): array {
		$support_class  = \ZymargCommunication\Modules\Support\Services\SupportService::class;
		$identity_class = \ZymargCommunication\Modules\Support\Services\SupportIdentitySettings::class;

		if ( ! class_exists( $support_class ) || ! class_exists( $identity_class ) ) {
			return $payload;
		}

		try {
			if ( ! ServiceProvider::has( $support_class ) ) {
				return $payload;
			}
			$support = ServiceProvider::get( $support_class );

			if ( ! $support->isSupportConversation( $conversation_id ) ) {
				return $payload;
			}
			if ( ! $support->isAgent( $sender_id ) || $support->isAgent( $recipient_id ) ) {
				return $payload;
			}

			$alias = ( new $identity_class() )->aliasForConversation( $conversation_id );
			if ( '' === $alias ) {
				return $payload;
			}

			$payload['sender_name'] = $alias;
			$payload['title']       = sprintf(
				/* translators: %s: the support agent's public name, e.g. "Alpha". */
				__( 'New message from %s', 'zymarg-communication' ),
				$alias
			);
		} catch ( \Throwable $e ) {
			return $payload;
		}

		return $payload;
	}

	/**
	 * Handle a `conversation.created` event: notify the recipient.
	 */
	public function handleConversationCreated( int $conversation_id, int $initiator_id, ?int $recipient_id ): void {
		if ( ! $recipient_id || $recipient_id <= 0 || $recipient_id === $initiator_id ) {
			return;
		}
		$initiator = get_userdata( $initiator_id );
		$name = $initiator ? $initiator->display_name : __( 'Someone', 'zymarg-communication' );
		$this->dispatch(
			$recipient_id,
			'conversation_request',
			array(
				'title'           => sprintf( __( '%s started a conversation', 'zymarg-communication' ), $name ),
				'preview'         => '',
				'sender_id'       => $initiator_id,
				'sender_name'     => $name,
				'conversation_id' => $conversation_id,
				'url'             => home_url( '/messages/' ),
			)
		);
	}

	private function deliver( string $channel, int $user_id, string $type, array $payload, callable $sender ): bool {
		try {
			$delivered = (bool) $sender();
		} catch ( \Throwable $e ) {
			$delivered = false;
		}
		if ( $delivered ) {
			$id = $this->notifications->create( $user_id, $type, $payload, $channel );
			if ( $id > 0 ) {
				$this->notifications->markSent( $id );
			}
		}
		return $delivered;
	}
}
