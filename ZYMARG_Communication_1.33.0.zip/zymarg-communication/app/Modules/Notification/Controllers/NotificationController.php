<?php
/**
 * REST endpoints for reading, dismissing, and configuring notifications.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Notification\Controllers;

use ZymargCommunication\Core\Abstracts\AbstractController;
use ZymargCommunication\Infrastructure\Http\Middleware\AuthMiddleware;
use ZymargCommunication\Infrastructure\Http\Middleware\NonceMiddleware;
use ZymargCommunication\Modules\Notification\Repositories\NotificationRepository;
use ZymargCommunication\Modules\Notification\Services\BrowserNotificationService;
use ZymargCommunication\Modules\Notification\Services\NotificationPreferenceService;
use ZymargCommunication\Modules\Notification\Services\PushNotificationService;
use WP_REST_Request;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class NotificationController extends AbstractController {

	public function __construct(
		private NotificationRepository $notifications,
		private NotificationPreferenceService $preferences,
		private PushNotificationService $push,
		private BrowserNotificationService $browser
	) {}

	public function registerRoutes(): void {
		$ns = self::NAMESPACE;

		register_rest_route( $ns, '/notifications', array(
			'methods'             => 'GET',
			'callback'            => array( $this, 'list' ),
			'permission_callback' => static fn( $request ) => AuthMiddleware::requireLoggedIn( $request ),
		) );

		register_rest_route( $ns, '/notifications/(?P<id>\d+)/read', array(
			'methods'             => 'PATCH',
			'callback'            => array( $this, 'markRead' ),
			'permission_callback' => $this->writeGuard(),
			'args'                => array( 'id' => array( 'required' => true ) ),
		) );

		register_rest_route( $ns, '/notifications/read-all', array(
			'methods'             => 'PATCH',
			'callback'            => array( $this, 'markAllRead' ),
			'permission_callback' => $this->writeGuard(),
		) );

		register_rest_route( $ns, '/notifications/preferences', array(
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'getPreferences' ),
				'permission_callback' => static fn( $request ) => AuthMiddleware::requireLoggedIn( $request ),
			),
			array(
				'methods'             => 'PATCH',
				'callback'            => array( $this, 'updatePreferences' ),
				'permission_callback' => $this->writeGuard(),
			),
		) );

		register_rest_route( $ns, '/notifications/tokens/push', array(
			'methods'             => 'POST',
			'callback'            => array( $this, 'registerPushToken' ),
			'permission_callback' => $this->writeGuard(),
		) );

		register_rest_route( $ns, '/notifications/tokens/push', array(
			'methods'             => 'DELETE',
			'callback'            => array( $this, 'unregisterPushToken' ),
			'permission_callback' => $this->writeGuard(),
		) );

		register_rest_route( $ns, '/notifications/tokens/browser', array(
			'methods'             => 'POST',
			'callback'            => array( $this, 'registerBrowserSubscription' ),
			'permission_callback' => $this->writeGuard(),
		) );

		register_rest_route( $ns, '/notifications/tokens/browser', array(
			'methods'             => 'DELETE',
			'callback'            => array( $this, 'unregisterBrowserSubscription' ),
			'permission_callback' => $this->writeGuard(),
		) );
	}

	public function list( WP_REST_Request $request ) {
		return $this->handle( function () use ( $request ) {
			$user_id = $this->currentUserId();
			$limit   = max( 1, min( 100, (int) $this->param( $request, 'limit', 30 ) ) );
			$offset  = max( 0, (int) $this->param( $request, 'offset', 0 ) );
			$unread  = null;
			if ( null !== $request->get_param( 'unread' ) ) {
				$unread = filter_var( $request->get_param( 'unread' ), FILTER_VALIDATE_BOOLEAN );
			}

			$rows = $this->notifications->findForUser( $user_id, $limit, $offset, $unread );
			return $this->ok( array(
				'items'        => array_map( fn( $n ) => $n->toArray(), $rows ),
				'unread_count' => $this->notifications->unreadCount( $user_id ),
			) );
		} );
	}

	public function markRead( WP_REST_Request $request ) {
		return $this->handle( function () use ( $request ) {
			$id = (int) $request['id'];
			$user_id = $this->currentUserId();
			$ok = $this->notifications->markRead( $id, $user_id );
			if ( ! $ok ) {
				return $this->fail( 'not_found', __( 'Notification not found.', 'zymarg-communication' ), 404 );
			}
			return $this->ok( array( 'id' => $id, 'is_read' => true ) );
		} );
	}

	public function markAllRead( WP_REST_Request $request ) {
		return $this->handle( function () {
			$count = $this->notifications->markAllRead( $this->currentUserId() );
			return $this->ok( array( 'updated' => $count ) );
		} );
	}

	public function getPreferences( WP_REST_Request $request ) {
		return $this->handle( function () {
			$prefs = $this->preferences->get( $this->currentUserId() );
			return $this->ok( array(
				'preferences'      => $prefs,
				'vapid_public_key' => $this->browser->vapidPublicKey(),
			) );
		} );
	}

	public function updatePreferences( WP_REST_Request $request ) {
		return $this->handle( function () use ( $request ) {
			$patch = array();
			foreach ( array( 'email', 'push', 'browser', 'in_app' ) as $key ) {
				if ( null !== $request->get_param( $key ) ) {
					$patch[ $key ] = filter_var( $request->get_param( $key ), FILTER_VALIDATE_BOOLEAN );
				}
			}
			$qh = $request->get_param( 'quiet_hours' );
			if ( is_array( $qh ) ) {
				$patch['quiet_hours'] = array();
				if ( isset( $qh['enabled'] ) ) {
					$patch['quiet_hours']['enabled'] = filter_var( $qh['enabled'], FILTER_VALIDATE_BOOLEAN );
				}
				foreach ( array( 'start', 'end', 'timezone' ) as $k ) {
					if ( isset( $qh[ $k ] ) ) {
						$patch['quiet_hours'][ $k ] = sanitize_text_field( (string) $qh[ $k ] );
					}
				}
			}

			$prefs = $this->preferences->set( $this->currentUserId(), $patch );
			return $this->ok( array( 'preferences' => $prefs ) );
		} );
	}

	public function registerPushToken( WP_REST_Request $request ) {
		return $this->handle( function () use ( $request ) {
			$token = sanitize_text_field( (string) $this->param( $request, 'token', '' ) );
			if ( '' === $token ) {
				return $this->fail( 'invalid_token', __( 'Missing device token.', 'zymarg-communication' ), 400 );
			}
			$this->push->registerToken( $this->currentUserId(), $token );
			return $this->ok( array( 'registered' => true ) );
		} );
	}

	public function unregisterPushToken( WP_REST_Request $request ) {
		return $this->handle( function () use ( $request ) {
			$token = sanitize_text_field( (string) $this->param( $request, 'token', '' ) );
			if ( '' === $token ) {
				return $this->fail( 'invalid_token', __( 'Missing device token.', 'zymarg-communication' ), 400 );
			}
			$this->push->unregisterToken( $this->currentUserId(), $token );
			return $this->ok( array( 'unregistered' => true ) );
		} );
	}

	public function registerBrowserSubscription( WP_REST_Request $request ) {
		return $this->handle( function () use ( $request ) {
			$subscription = $request->get_param( 'subscription' );
			if ( ! is_array( $subscription ) || empty( $subscription['endpoint'] ) ) {
				return $this->fail( 'invalid_subscription', __( 'Missing subscription payload.', 'zymarg-communication' ), 400 );
			}
			$this->browser->registerSubscription( $this->currentUserId(), $subscription );
			return $this->ok( array( 'registered' => true ) );
		} );
	}

	public function unregisterBrowserSubscription( WP_REST_Request $request ) {
		return $this->handle( function () use ( $request ) {
			$endpoint = esc_url_raw( (string) $this->param( $request, 'endpoint', '' ) );
			if ( '' === $endpoint ) {
				return $this->fail( 'invalid_endpoint', __( 'Missing subscription endpoint.', 'zymarg-communication' ), 400 );
			}
			$this->browser->unregisterSubscription( $this->currentUserId(), $endpoint );
			return $this->ok( array( 'unregistered' => true ) );
		} );
	}

	private function writeGuard(): callable {
		return static function ( $request ) {
			$auth = AuthMiddleware::requireLoggedIn( $request );
			if ( true !== $auth ) {
				return $auth;
			}
			$nonce = NonceMiddleware::verify( $request );
			if ( true !== $nonce ) {
				return $nonce;
			}
			return true;
		};
	}
}
