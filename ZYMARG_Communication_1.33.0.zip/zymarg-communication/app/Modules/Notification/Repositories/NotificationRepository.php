<?php
/**
 * All database reads and writes for the `zc_notifications` table.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Notification\Repositories;

use ZymargCommunication\Core\Abstracts\AbstractRepository;
use ZymargCommunication\Modules\Notification\Models\Notification;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class NotificationRepository extends AbstractRepository {

	protected function tableSuffix(): string {
		return 'zc_notifications';
	}

	public function findModel( int $id ): ?Notification {
		$row = $this->find( $id );
		return $row ? Notification::fromRow( $row ) : null;
	}

	public function create( int $user_id, string $type, array $payload, string $channel ): int {
		return $this->insert(
			array(
				'user_id'    => $user_id,
				'type'       => $type,
				'payload'    => wp_json_encode( $payload ),
				'channel'    => $channel,
				'is_read'    => 0,
				'sent_at'    => null,
				'created_at' => current_time( 'mysql', true ),
			)
		);
	}

	public function markSent( int $id ): bool {
		return $this->update( $id, array( 'sent_at' => current_time( 'mysql', true ) ) );
	}

	public function markRead( int $id, int $user_id ): bool {
		$affected = $this->wpdb->update(
			$this->table(),
			array( 'is_read' => 1, 'read_at' => current_time( 'mysql', true ) ),
			array( 'id' => $id, 'user_id' => $user_id )
		);
		return false !== $affected && $affected > 0;
	}

	public function markAllRead( int $user_id ): int {
		$affected = $this->wpdb->query(
			$this->wpdb->prepare(
				'UPDATE `' . $this->table() . '` SET is_read = 1, read_at = %s WHERE user_id = %d AND is_read = 0',
				current_time( 'mysql', true ),
				$user_id
			)
		);
		return (int) $affected;
	}

	/** @return array<int, Notification> */
	public function findForUser( int $user_id, int $limit = 30, int $offset = 0, ?bool $unread_only = null ): array {
		$sql = 'SELECT * FROM `' . $this->table() . '` WHERE user_id = %d';
		$args = array( $user_id );
		if ( true === $unread_only ) {
			$sql .= ' AND is_read = 0';
		}
		$sql .= ' ORDER BY created_at DESC LIMIT %d OFFSET %d';
		$args[] = $limit;
		$args[] = $offset;

		$rows = $this->wpdb->get_results( $this->wpdb->prepare( $sql, ...$args ) );
		if ( ! is_array( $rows ) ) {
			return array();
		}
		return array_map( array( Notification::class, 'fromRow' ), $rows );
	}

	public function unreadCount( int $user_id ): int {
		return (int) $this->wpdb->get_var(
			$this->wpdb->prepare(
				'SELECT COUNT(*) FROM `' . $this->table() . '` WHERE user_id = %d AND is_read = 0',
				$user_id
			)
		);
	}
}
