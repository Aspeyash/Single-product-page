<?php
/**
 * NotificationHooks — listens to events from other modules and triggers
 * notification dispatch.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Notification\Hooks;

use ZymargCommunication\Bootstrap\ServiceProvider;
use ZymargCommunication\Core\Contracts\HookableInterface;
use ZymargCommunication\Infrastructure\Http\Controllers\RestController;
use ZymargCommunication\Modules\Notification\Controllers\NotificationController;
use ZymargCommunication\Modules\Notification\Services\NotificationService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class NotificationHooks implements HookableInterface {

	public static function register(): void {
		$instance = new self();
		$instance->registerHooks();
	}

	private function registerHooks(): void {
		if ( ServiceProvider::has( NotificationController::class ) ) {
			$controller = ServiceProvider::get( NotificationController::class );
			if ( $controller instanceof NotificationController ) {
				RestController::register( $controller );
			}
		}

		add_action( 'zymarg_comm_event_message_sent',         array( __CLASS__, 'onMessageSent' ), 20, 1 );
		add_action( 'zymarg_comm_event_conversation_created', array( __CLASS__, 'onConversationCreated' ), 20, 1 );
	}

	public static function onMessageSent( array $payload ): void {
		if ( ! ServiceProvider::has( NotificationService::class ) ) {
			return;
		}
		$service = ServiceProvider::get( NotificationService::class );
		if ( ! $service instanceof NotificationService ) {
			return;
		}
		$service->handleMessageSent(
			(int) ( $payload['message_id'] ?? 0 ),
			(int) ( $payload['conversation_id'] ?? 0 ),
			(int) ( $payload['sender_id'] ?? 0 ),
			(string) ( $payload['body'] ?? '' ),
			isset( $payload['parent_id'] ) && null !== $payload['parent_id'] ? (int) $payload['parent_id'] : null
		);
	}

	public static function onConversationCreated( array $payload ): void {
		if ( ! ServiceProvider::has( NotificationService::class ) ) {
			return;
		}
		$service = ServiceProvider::get( NotificationService::class );
		if ( ! $service instanceof NotificationService ) {
			return;
		}
		$conversation_id = (int) ( $payload['conversation_id'] ?? 0 );
		$initiator_id    = (int) ( $payload['initiated_by'] ?? 0 );
		$recipient_id    = isset( $payload['recipient_id'] ) ? (int) $payload['recipient_id'] : null;

		// If recipient wasn't in the event, look it up.
		if ( null === $recipient_id && $conversation_id > 0 && $initiator_id > 0 ) {
			$repo = ServiceProvider::has( \ZymargCommunication\Modules\Conversation\Repositories\ParticipantRepository::class )
				? ServiceProvider::get( \ZymargCommunication\Modules\Conversation\Repositories\ParticipantRepository::class )
				: null;
			if ( $repo instanceof \ZymargCommunication\Modules\Conversation\Repositories\ParticipantRepository ) {
				$recipient_id = $repo->counterpartUserId( $conversation_id, $initiator_id );
			}
		}

		$service->handleConversationCreated( $conversation_id, $initiator_id, $recipient_id );
	}
}
