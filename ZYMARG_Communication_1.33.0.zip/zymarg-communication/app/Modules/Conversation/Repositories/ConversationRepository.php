<?php
/**
 * All database reads and writes for the `zc_conversations` table.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Conversation\Repositories;

use ZymargCommunication\Core\Abstracts\AbstractRepository;
use ZymargCommunication\Modules\Conversation\Models\Conversation;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ConversationRepository extends AbstractRepository {

	protected function tableSuffix(): string {
		return 'zc_conversations';
	}

	public function findModel( int $id ): ?Conversation {
		$row = $this->find( $id );
		return $row ? Conversation::fromRow( $row ) : null;
	}

	/**
	 * @return array<int, Conversation>
	 */
	/**
	 * Conversations a user takes part in.
	 *
	 * @param ?string $context_type    Include ONLY this context when given.
	 * @param ?string $exclude_context Omit this context when given (1.32.6).
	 *                                 Used by the buyer and vendor inboxes to
	 *                                 keep helpline threads out of the ordinary
	 *                                 buyer/seller message list. Ignored when
	 *                                 $context_type is set, since an explicit
	 *                                 include already answers the question.
	 */
	public function findForUser( int $user_id, int $limit = 20, int $offset = 0, ?string $context_type = null, ?string $exclude_context = null ): array {
		$participants_table = $this->wpdb->prefix . 'zc_participants';
		$conv_table         = $this->table();

		/*
		 * 1.32.6 — exclusion branch.
		 *
		 * The include filter below has existed since 1.25.0 and is what makes
		 * the support inbox show only support threads. Nothing ever did the
		 * reverse, so the buyer and vendor inboxes — which send no context at
		 * all — listed EVERY conversation the user was part of, support cases
		 * included. Messaging the helpline therefore made the case turn up in
		 * the ordinary buyer/seller message box as well, mixed in with vendor
		 * conversations. The two are different products for different jobs and
		 * must not share a list.
		 *
		 * `context_type <> %s OR IS NULL` matters: ordinary conversations may
		 * carry no context at all, and a plain `<>` comparison drops NULLs in
		 * SQL, which would have emptied the buyer inbox completely.
		 */
		if ( ( null === $context_type || '' === $context_type ) && null !== $exclude_context && '' !== $exclude_context ) {
			$sql = $this->wpdb->prepare(
				'SELECT c.* FROM `' . $conv_table . '` c '
				. 'INNER JOIN `' . $participants_table . '` p ON p.conversation_id = c.id '
				. 'WHERE p.user_id = %d AND ( c.context_type IS NULL OR c.context_type <> %s ) '
				. 'ORDER BY c.is_pinned DESC, COALESCE(c.last_message_at, c.created_at) DESC '
				. 'LIMIT %d OFFSET %d',
				$user_id,
				$exclude_context,
				$limit,
				$offset
			);

			$rows = $this->wpdb->get_results( $sql );
			if ( ! is_array( $rows ) ) {
				return array();
			}
			return array_map( array( Conversation::class, 'fromRow' ), $rows );
		}

		// Optional context filter, added in 1.25.0 for the support inbox.
		// Passing null (the default) keeps the original behaviour exactly:
		// every conversation the user takes part in, unfiltered.
		if ( null !== $context_type && '' !== $context_type ) {
			$sql = $this->wpdb->prepare(
				'SELECT c.* FROM `' . $conv_table . '` c '
				. 'INNER JOIN `' . $participants_table . '` p ON p.conversation_id = c.id '
				. 'WHERE p.user_id = %d AND c.context_type = %s '
				. 'ORDER BY c.is_pinned DESC, COALESCE(c.last_message_at, c.created_at) DESC '
				. 'LIMIT %d OFFSET %d',
				$user_id,
				$context_type,
				$limit,
				$offset
			);

			$rows = $this->wpdb->get_results( $sql );
			if ( ! is_array( $rows ) ) {
				return array();
			}
			return array_map( array( Conversation::class, 'fromRow' ), $rows );
		}

		$sql = $this->wpdb->prepare(
			'SELECT c.* FROM `' . $conv_table . '` c '
			. 'INNER JOIN `' . $participants_table . '` p ON p.conversation_id = c.id '
			. 'WHERE p.user_id = %d '
			. 'ORDER BY c.is_pinned DESC, COALESCE(c.last_message_at, c.created_at) DESC '
			. 'LIMIT %d OFFSET %d',
			$user_id,
			$limit,
			$offset
		);

		$rows = $this->wpdb->get_results( $sql );
		if ( ! is_array( $rows ) ) {
			return array();
		}
		return array_map( array( Conversation::class, 'fromRow' ), $rows );
	}

	public function create( array $data ): int {
		$now = current_time( 'mysql', true );
		return $this->insert(
			array(
				'status'          => $data['status'] ?? 'pending_approval',
				'initiated_by'    => (int) $data['initiated_by'],
				'context_type'    => $data['context_type'] ?? null,
				'context_id'      => isset( $data['context_id'] ) ? (int) $data['context_id'] : null,
				'is_pinned'       => (int) ( $data['is_pinned'] ?? 0 ),
				'last_message_at' => $data['last_message_at'] ?? null,
				'created_at'      => $now,
				'updated_at'      => $now,
			)
		);
	}

	public function updateStatus( int $conversation_id, string $status ): bool {
		return $this->update(
			$conversation_id,
			array(
				'status'     => $status,
				'updated_at' => current_time( 'mysql', true ),
			)
		);
	}

	public function setPinned( int $conversation_id, bool $pinned ): bool {
		return $this->update(
			$conversation_id,
			array(
				'is_pinned'  => $pinned ? 1 : 0,
				'updated_at' => current_time( 'mysql', true ),
			)
		);
	}

	public function touchLastMessageAt( int $conversation_id ): bool {
		return $this->update(
			$conversation_id,
			array(
				'last_message_at' => current_time( 'mysql', true ),
				'updated_at'      => current_time( 'mysql', true ),
			)
		);
	}

	public function listAll( ?string $status = null, int $limit = 50, int $offset = 0 ): array {
		$conv_table = $this->table();
		$where      = '';
		$args       = array();
		if ( null !== $status ) {
			$where  = ' WHERE status = %s';
			$args[] = $status;
		}
		$sql    = 'SELECT * FROM `' . $conv_table . '`' . $where
			. ' ORDER BY COALESCE(last_message_at, created_at) DESC LIMIT %d OFFSET %d';
		$args[] = $limit;
		$args[] = $offset;
		$rows   = $this->wpdb->get_results( $this->wpdb->prepare( $sql, ...$args ) );
		if ( ! is_array( $rows ) ) {
			return array();
		}
		return array_map( array( Conversation::class, 'fromRow' ), $rows );
	}

	public function countAll( ?string $status = null ): int {
		$conv_table = $this->table();
		if ( null !== $status ) {
			return (int) $this->wpdb->get_var(
				$this->wpdb->prepare( 'SELECT COUNT(*) FROM `' . $conv_table . '` WHERE status = %s', $status )
			);
		}
		return (int) $this->wpdb->get_var( 'SELECT COUNT(*) FROM `' . $conv_table . '`' );
	}
}
