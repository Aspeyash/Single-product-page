<?php
/**
 * All database reads and writes for the `zc_participants` table.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Conversation\Repositories;

use ZymargCommunication\Core\Abstracts\AbstractRepository;
use ZymargCommunication\Modules\Conversation\Models\Participant;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ParticipantRepository extends AbstractRepository {

	protected function tableSuffix(): string {
		return 'zc_participants';
	}

	/** @return array<int, Participant> */
	public function findForConversation( int $conversation_id ): array {
		$rows = $this->wpdb->get_results(
			$this->wpdb->prepare( 'SELECT * FROM `' . $this->table() . '` WHERE conversation_id = %d ORDER BY joined_at ASC', $conversation_id )
		);
		if ( ! is_array( $rows ) ) {
			return array();
		}
		return array_map( array( Participant::class, 'fromRow' ), $rows );
	}

	public function findByUserAndConversation( int $user_id, int $conversation_id ): ?Participant {
		$row = $this->wpdb->get_row(
			$this->wpdb->prepare(
				'SELECT * FROM `' . $this->table() . '` WHERE conversation_id = %d AND user_id = %d LIMIT 1',
				$conversation_id,
				$user_id
			)
		);
		return $row ? Participant::fromRow( $row ) : null;
	}

	public function add( int $conversation_id, int $user_id, string $participant_type, string $role ): int {
		// Idempotent join.
		$existing = $this->findByUserAndConversation( $user_id, $conversation_id );
		if ( $existing ) {
			return $existing->id;
		}

		return $this->insert(
			array(
				'conversation_id'  => $conversation_id,
				'user_id'          => $user_id,
				'participant_type' => $participant_type,
				'role'             => $role,
				'joined_at'        => current_time( 'mysql', true ),
			)
		);
	}

	public function updateLastReadAt( int $conversation_id, int $user_id ): bool {
		$affected = $this->wpdb->update(
			$this->table(),
			array( 'last_read_at' => current_time( 'mysql', true ) ),
			array(
				'conversation_id' => $conversation_id,
				'user_id'         => $user_id,
			)
		);
		return false !== $affected;
	}

	public function isParticipant( int $conversation_id, int $user_id ): bool {
		return null !== $this->findByUserAndConversation( $user_id, $conversation_id );
	}

	public function counterpartUserId( int $conversation_id, int $current_user_id ): ?int {
		$row = $this->wpdb->get_row(
			$this->wpdb->prepare(
				'SELECT user_id FROM `' . $this->table() . '` WHERE conversation_id = %d AND user_id <> %d LIMIT 1',
				$conversation_id,
				$current_user_id
			)
		);
		return $row ? (int) $row->user_id : null;
	}
}
