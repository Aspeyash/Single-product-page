<?php
/**
 * REST endpoints for conversation CRUD, archive, pin, search, filter.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Conversation\Controllers;

use WP_REST_Request;
use WP_REST_Response;
use ZymargCommunication\Core\Abstracts\AbstractController;
use ZymargCommunication\Core\Exceptions\ValidationException;
use ZymargCommunication\Infrastructure\Http\Middleware\AuthMiddleware;
use ZymargCommunication\Infrastructure\Http\Middleware\NonceMiddleware;
use ZymargCommunication\Infrastructure\Http\Middleware\RateLimitMiddleware;
use ZymargCommunication\Modules\Conversation\Services\ConversationService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ConversationController extends AbstractController {

	public function __construct( private ConversationService $service ) {}

	public function registerRoutes(): void {
		register_rest_route(
			self::NAMESPACE,
			'/conversations',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( $this, 'index' ),
					'permission_callback' => array( AuthMiddleware::class, 'requireLoggedIn' ),
					'args'                => array(
						'limit'  => array( 'type' => 'integer', 'default' => 20 ),
						'offset' => array( 'type' => 'integer', 'default' => 0 ),
					),
				),
				array(
					'methods'             => 'POST',
					'callback'            => array( $this, 'store' ),
					'permission_callback' => array( $this, 'writeGuard' ),
					'args'                => array(
						'recipient_id' => array( 'required' => true, 'type' => 'integer' ),
						'context_type' => array( 'type' => 'string' ),
						'context_id'   => array( 'type' => 'integer' ),
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/conversations/(?P<id>\\d+)',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( $this, 'show' ),
					'permission_callback' => array( AuthMiddleware::class, 'requireLoggedIn' ),
				),
				array(
					'methods'             => 'PATCH',
					'callback'            => array( $this, 'update' ),
					'permission_callback' => array( $this, 'writeGuard' ),
					'args'                => array(
						'archive'   => array( 'type' => 'boolean' ),
						'is_pinned' => array( 'type' => 'boolean' ),
					),
				),
			)
		);
	}

	public function writeGuard( WP_REST_Request $request ): bool|\WP_Error {
		$auth = AuthMiddleware::requireLoggedIn( $request );
		if ( $auth instanceof \WP_Error ) {
			return $auth;
		}
		return NonceMiddleware::verify( $request );
	}

	public function index( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle(
			function () use ( $request ) {
				$this->requireAuthenticated();
				$limit  = (int) $this->param( $request, 'limit', 20 );
				$offset = (int) $this->param( $request, 'offset', 0 );

				// Optional context filter (1.25.0). Omitted by the buyer and vendor
				// inboxes, so their payloads are unchanged; the support inbox sends
				// context=support to see only support threads.
				$context = sanitize_key( (string) $this->param( $request, 'context', '' ) );
				$context = '' !== $context ? $context : null;

				// Optional exclusion (1.32.6). The buyer and vendor inboxes send
				// exclude_context=support, so a helpline case no longer shows up
				// in the ordinary buyer/seller message list alongside vendor
				// conversations.
				$exclude = sanitize_key( (string) $this->param( $request, 'exclude_context', '' ) );
				$exclude = '' !== $exclude ? $exclude : null;

				return array(
					'conversations' => $this->service->listForUser( $this->currentUserId(), $limit, $offset, $context, $exclude ),
				);
			}
		);
	}

	public function store( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle(
			function () use ( $request ) {
				$this->requireAuthenticated();

				$limit = RateLimitMiddleware::enforce( $request, 'conversation.create', 10, 60 );
				if ( $limit instanceof \WP_Error ) {
					return $this->fail( 'rate_limited', (string) $limit->get_error_message(), 429 );
				}

				$recipient_id = (int) $request->get_param( 'recipient_id' );
				if ( $recipient_id < 1 ) {
					throw new ValidationException( 'recipient_id is required.', array( 'recipient_id' => 'Must be a positive integer.' ) );
				}

				$context_type = $request->get_param( 'context_type' );
				$context_id   = $request->get_param( 'context_id' );

				$conversation = $this->service->create(
					$this->currentUserId(),
					$recipient_id,
					is_string( $context_type ) && '' !== $context_type ? sanitize_key( $context_type ) : null,
					null !== $context_id ? (int) $context_id : null
				);

				return array( 'conversation' => $conversation );
			}
		);
	}

	public function show( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle(
			function () use ( $request ) {
				$this->requireAuthenticated();
				$id = (int) $request->get_param( 'id' );
				return array( 'conversation' => $this->service->view( $id, $this->currentUserId() ) );
			}
		);
	}

	public function update( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle(
			function () use ( $request ) {
				$this->requireAuthenticated();
				$id      = (int) $request->get_param( 'id' );
				$archive = $request->get_param( 'archive' );
				$pinned  = $request->get_param( 'is_pinned' );

				$changed = array();
				if ( null !== $archive && rest_sanitize_boolean( $archive ) ) {
					$changed['archived'] = $this->service->archive( $id, $this->currentUserId() );
				}
				if ( null !== $pinned ) {
					$changed['pinned'] = $this->service->pin( $id, $this->currentUserId(), rest_sanitize_boolean( $pinned ) );
				}

				return array(
					'conversation' => $this->service->view( $id, $this->currentUserId() ),
					'changed'      => $changed,
				);
			}
		);
	}
}
