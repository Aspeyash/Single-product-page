<?php
/**
 * Registers WordPress actions and filters owned by the Conversation module.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Conversation\Hooks;

use ZymargCommunication\Bootstrap\ServiceProvider;
use ZymargCommunication\Core\Contracts\HookableInterface;
use ZymargCommunication\Infrastructure\Http\Controllers\RestController;
use ZymargCommunication\Modules\Conversation\Controllers\ConversationController;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ConversationHooks implements HookableInterface {

	public static function register(): void {
		$instance = new self();
		$instance->registerHooks();
	}

	private function registerHooks(): void {
		$controller = ServiceProvider::get( ConversationController::class );
		if ( $controller instanceof ConversationController ) {
			RestController::register( $controller );
		}
	}
}
