<?php
/**
 * Create, archive, pin, delete, search, and filter conversations.
 * Enforces business rules.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Conversation\Services;

use ZymargCommunication\Bootstrap\ServiceProvider;
use ZymargCommunication\Core\Abstracts\AbstractService;
use ZymargCommunication\Core\Exceptions\NotFoundException;
use ZymargCommunication\Core\Exceptions\UnauthorizedException;
use ZymargCommunication\Core\Exceptions\ValidationException;
use ZymargCommunication\Modules\Conversation\Repositories\ConversationRepository;
use ZymargCommunication\Modules\Conversation\Repositories\ParticipantRepository;
use ZymargCommunication\Modules\Message\Repositories\MessageRepository;
use ZymargCommunication\Shared\Enums\ConversationStatus;
use ZymargCommunication\Shared\Enums\ParticipantRole;
use ZymargCommunication\Shared\Enums\ParticipantType;
use ZymargCommunication\Shared\Events\ConversationClosed;
use ZymargCommunication\Shared\Events\ConversationCreated;
use ZymargCommunication\Shared\Events\EventDispatcher;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ConversationService extends AbstractService {

	public function __construct(
		private ConversationRepository $conversations,
		private ParticipantService $participants,
		private ConversationPermissionService $permissions
	) {}

	/**
	 * Create a conversation between two users.
	 *
	 * @param int         $initiator_id   Current user starting the conversation.
	 * @param int         $recipient_id   The other participant.
	 * @param string|null $context_type   Optional context ("order", "product").
	 * @param int|null    $context_id     Optional context ID.
	 *
	 * @return array<string, mixed> Conversation array + participants.
	 */
	public function create( int $initiator_id, int $recipient_id, ?string $context_type = null, ?int $context_id = null ): array {
		if ( $initiator_id === $recipient_id ) {
			throw new ValidationException(
				__( 'Cannot start a conversation with yourself.', 'zymarg-communication' ),
				array( 'recipient_id' => 'Must differ from initiator.' )
			);
		}
		if ( ! get_userdata( $recipient_id ) ) {
			throw new NotFoundException( __( 'Recipient user not found.', 'zymarg-communication' ) );
		}

		$initiator_type = ParticipantType::fromUserId( $initiator_id );
		$recipient_type = ParticipantType::fromUserId( $recipient_id );
		$status         = $this->permissions->initialStatusFor( $initiator_type, $recipient_type );

		$id = $this->conversations->create(
			array(
				'status'       => $status->value,
				'initiated_by' => $initiator_id,
				'context_type' => $context_type,
				'context_id'   => $context_id,
			)
		);

		if ( 0 === $id ) {
			throw new \ZymargCommunication\Core\Exceptions\DatabaseException( __( 'Failed to create conversation.', 'zymarg-communication' ) );
		}

		$this->participants->add( $id, $initiator_id, $initiator_type, ParticipantRole::Owner );
		$this->participants->add( $id, $recipient_id, $recipient_type, ParticipantRole::Member );

		$this->dispatch(
			new ConversationCreated( $id, $initiator_id, $status->value, $context_type, $context_id )
		);

		return $this->view( $id, $initiator_id );
	}

	/**
	 * List conversations for a user.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function listForUser( int $user_id, int $limit = 20, int $offset = 0, ?string $context_type = null, ?string $exclude_context = null ): array {
		$limit  = max( 1, min( 100, $limit ) );
		$offset = max( 0, $offset );

		$rows = $this->conversations->findForUser( $user_id, $limit, $offset, $context_type, $exclude_context );
		return array_map( fn( $c ) => $this->presentForUser( $c, $user_id ), $rows );
	}

	/**
	 * Decorate a conversation row for a specific user with the display fields the
	 * inbox and popup need: counterpart name (title), last-message preview, and an
	 * unread indicator. Presentation must never break the listing, so any failure
	 * falls back to the base conversation payload.
	 *
	 * @return array<string, mixed>
	 */
	private function presentForUser( \ZymargCommunication\Modules\Conversation\Models\Conversation $conv, int $user_id ): array {
		$data = $conv->toArray();

		try {
			$participant_repo = ServiceProvider::has( ParticipantRepository::class )
				? ServiceProvider::get( ParticipantRepository::class )
				: null;
			$message_repo = ServiceProvider::has( MessageRepository::class )
				? ServiceProvider::get( MessageRepository::class )
				: null;

			// Title = the other participant's display name.
			$title = '';
			if ( $participant_repo instanceof ParticipantRepository ) {
				$counterpart_id = $participant_repo->counterpartUserId( $conv->id, $user_id );
				if ( $counterpart_id ) {
					$user = get_userdata( $counterpart_id );
					if ( $user ) {
						$title = (string) $user->display_name;
					}
				}
			}
			$data['title'] = '' !== $title ? $title : __( 'Conversation', 'zymarg-communication' );

			// 1.32.1 — support conversations show a fixed brand label from the
			// customer's side, never the counterpart's display name. On some
			// installs the participant lookup returned the customer's OWN name
			// for their own view of a support thread, which meant a customer
			// called "Prian" saw a conversation titled "Prian" in their inbox
			// list and popup header. Agents keep seeing the customer's name so
			// they can triage — the override is scoped to customer viewers.
			//
			// The literal is translatable via the standard zymarg-communication
			// text domain.
			try {
				$is_support = false;
				if ( ServiceProvider::has( \ZymargCommunication\Modules\Support\Services\SupportService::class ) ) {
					$support_svc = ServiceProvider::get( \ZymargCommunication\Modules\Support\Services\SupportService::class );
					$is_support  = $support_svc->isSupportConversation( (int) $conv->id );
					$is_agent    = $support_svc->isAgent( $user_id );
					if ( $is_support && ! $is_agent ) {
						$data['title'] = __( 'Support team', 'zymarg-communication' );
					}
				}
			} catch ( \Throwable $e ) {
				// Title override is decorative; never let it break the listing.
			}

			// Preview + unread indicator, derived from the latest message.
			$preview        = '';
			$latest_sender  = 0;
			$latest_created = null;
			if ( $message_repo instanceof MessageRepository ) {
				$total = $message_repo->countForConversation( $conv->id );
				if ( $total > 0 ) {
					$latest = $message_repo->findForConversation( $conv->id, 1, max( 0, $total - 1 ) );
					if ( ! empty( $latest ) ) {
						$preview        = wp_trim_words( wp_strip_all_tags( (string) $latest[0]->body ), 12, '…' );
						$latest_sender  = (int) $latest[0]->senderId;
						$latest_created = (string) $latest[0]->createdAt;
					}
				}
			}
			$data['preview'] = $preview;

			$unread = 0;
			if ( $participant_repo instanceof ParticipantRepository && null !== $latest_created && $latest_sender !== $user_id ) {
				$me        = $participant_repo->findByUserAndConversation( $user_id, $conv->id );
				$last_read = $me ? $me->lastReadAt : null;
				if ( null === $last_read || strtotime( $latest_created ) > strtotime( (string) $last_read ) ) {
					$unread = 1;
				}
			}
			$data['unread_count'] = $unread;
		} catch ( \Throwable $e ) {
			if ( ! isset( $data['title'] ) ) {
				$data['title'] = __( 'Conversation', 'zymarg-communication' );
			}
		}

		return $data;
	}

	/**
	 * Load a single conversation for a user.
	 *
	 * @return array<string, mixed>
	 */
	public function view( int $conversation_id, int $user_id ): array {
		$conv = $this->conversations->findModel( $conversation_id );
		if ( ! $conv ) {
			throw new NotFoundException( __( 'Conversation not found.', 'zymarg-communication' ) );
		}
		$this->assertMemberOrAdmin( $conversation_id, $user_id );

		return array_merge(
			$conv->toArray(),
			array( 'participants' => $this->participants->forConversation( $conversation_id ) )
		);
	}

	public function archive( int $conversation_id, int $user_id ): bool {
		if ( ! $this->isEnabled( 'conversation.archive' ) ) {
			return false;
		}
		$this->assertMemberOrAdmin( $conversation_id, $user_id );
		$ok = $this->conversations->updateStatus( $conversation_id, ConversationStatus::Archived->value );
		if ( $ok ) {
			$this->dispatch( new ConversationClosed( $conversation_id, $user_id, 'archived' ) );
		}
		return $ok;
	}

	public function pin( int $conversation_id, int $user_id, bool $pinned ): bool {
		if ( ! $this->isEnabled( 'conversation.pin' ) ) {
			return false;
		}
		$this->assertMemberOrAdmin( $conversation_id, $user_id );
		return $this->conversations->setPinned( $conversation_id, $pinned );
	}

	public function touchLastMessageAt( int $conversation_id ): void {
		$this->conversations->touchLastMessageAt( $conversation_id );
	}

	public function assertMemberOrAdmin( int $conversation_id, int $user_id ): void {
		if ( user_can( $user_id, 'manage_options' ) ) {
			return;
		}
		if ( ! $this->participants->isParticipant( $conversation_id, $user_id ) ) {
			throw new UnauthorizedException( __( 'You are not a participant of this conversation.', 'zymarg-communication' ) );
		}
	}

	private function dispatch( object $event ): void {
		if ( ! ServiceProvider::has( EventDispatcher::class ) ) {
			return;
		}
		$dispatcher = ServiceProvider::get( EventDispatcher::class );
		if ( $dispatcher instanceof EventDispatcher ) {
			$dispatcher->dispatch( $event );
		}
	}
}
