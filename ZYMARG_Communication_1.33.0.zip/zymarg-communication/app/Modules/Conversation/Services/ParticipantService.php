<?php
/**
 * Add, remove, and query participants within a conversation.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Conversation\Services;

use ZymargCommunication\Bootstrap\ServiceProvider;
use ZymargCommunication\Core\Abstracts\AbstractService;
use ZymargCommunication\Modules\Conversation\Repositories\ParticipantRepository;
use ZymargCommunication\Shared\Enums\ParticipantRole;
use ZymargCommunication\Shared\Enums\ParticipantType;
use ZymargCommunication\Shared\Events\EventDispatcher;
use ZymargCommunication\Shared\Events\ParticipantJoined;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ParticipantService extends AbstractService {

	public function __construct( private ParticipantRepository $repository ) {}

	public function add( int $conversation_id, int $user_id, ParticipantType $type, ParticipantRole $role ): int {
		$id = $this->repository->add( $conversation_id, $user_id, $type->value, $role->value );

		$dispatcher = ServiceProvider::has( EventDispatcher::class )
			? ServiceProvider::get( EventDispatcher::class )
			: null;
		if ( $dispatcher instanceof EventDispatcher ) {
			$dispatcher->dispatch( new ParticipantJoined( $conversation_id, $user_id, $type->value, $role->value ) );
		}

		return $id;
	}

	public function isParticipant( int $conversation_id, int $user_id ): bool {
		return $this->repository->isParticipant( $conversation_id, $user_id );
	}

	/** @return array<int, array<string, mixed>> */
	public function forConversation( int $conversation_id ): array {
		return array_map( fn( $p ) => $p->toArray(), $this->repository->findForConversation( $conversation_id ) );
	}

	public function markRead( int $conversation_id, int $user_id ): bool {
		return $this->repository->updateLastReadAt( $conversation_id, $user_id );
	}
}
