<?php
/**
 * Determines whether a given participant type may initiate or continue a
 * conversation.
 *
 * Rules:
 *   • Buyer → Seller: allowed. Conversation becomes `active`.
 *   • Seller → Buyer: pending admin approval unless the buyer messaged first.
 *   • Buyer → Buyer: gated by `conversation.buyer_buyer` flag.
 *   • Seller → Seller: gated by `conversation.seller_seller` flag.
 *   • Admin → anyone: allowed. Conversation is `active`.
 *   • If `conversation.seller_initiate` is off, sellers cannot initiate at all.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Conversation\Services;

use ZymargCommunication\Core\Abstracts\AbstractService;
use ZymargCommunication\Core\Exceptions\UnauthorizedException;
use ZymargCommunication\Shared\Enums\ConversationStatus;
use ZymargCommunication\Shared\Enums\ParticipantType;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ConversationPermissionService extends AbstractService {

	/**
	 * @return ConversationStatus The initial status for the new conversation.
	 * @throws UnauthorizedException When the pair is not permitted at all.
	 */
	public function initialStatusFor( ParticipantType $initiator, ParticipantType $recipient ): ConversationStatus {
		if ( ParticipantType::Admin === $initiator || ParticipantType::Admin === $recipient ) {
			return ConversationStatus::Active;
		}

		if ( ParticipantType::Buyer === $initiator && ParticipantType::Seller === $recipient ) {
			return ConversationStatus::Active;
		}

		if ( ParticipantType::Seller === $initiator && ParticipantType::Buyer === $recipient ) {
			if ( ! $this->isEnabled( 'conversation.seller_initiate' ) ) {
				throw new UnauthorizedException( __( 'Sellers may not initiate conversations.', 'zymarg-communication' ) );
			}
			// Seller starts → pending until admin approves or buyer messaged first.
			return ConversationStatus::PendingApproval;
		}

		if ( ParticipantType::Buyer === $initiator && ParticipantType::Buyer === $recipient ) {
			if ( ! $this->isEnabled( 'conversation.buyer_buyer' ) ) {
				throw new UnauthorizedException( __( 'Buyer-to-buyer messaging is disabled.', 'zymarg-communication' ) );
			}
			return ConversationStatus::Active;
		}

		if ( ParticipantType::Seller === $initiator && ParticipantType::Seller === $recipient ) {
			if ( ! $this->isEnabled( 'conversation.seller_seller' ) ) {
				throw new UnauthorizedException( __( 'Seller-to-seller messaging is disabled.', 'zymarg-communication' ) );
			}
			return ConversationStatus::Active;
		}

		throw new UnauthorizedException( __( 'Conversation is not permitted between these participants.', 'zymarg-communication' ) );
	}
}
