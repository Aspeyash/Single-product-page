<?php
/**
 * ZYMARG Communication
 *
 * @package    ZymargCommunication
 * @version    1.0.0
 * @author     ZYMARG Team
 */

namespace ZymargCommunication\Modules\Conversation\Services;

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ConversationExportService {
    // TODO: implement
}
