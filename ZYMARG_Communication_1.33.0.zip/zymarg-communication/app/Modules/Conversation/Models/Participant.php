<?php
/**
 * Plain data object representing a participant record.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Conversation\Models;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Participant {

	public function __construct(
		public int $id,
		public int $conversationId,
		public int $userId,
		public string $participantType,
		public string $role,
		public ?string $lastReadAt,
		public string $joinedAt
	) {}

	public static function fromRow( object $row ): self {
		return new self(
			(int) $row->id,
			(int) $row->conversation_id,
			(int) $row->user_id,
			(string) $row->participant_type,
			(string) $row->role,
			$row->last_read_at ?? null,
			(string) $row->joined_at
		);
	}

	public function toArray(): array {
		return array(
			'id'               => $this->id,
			'conversation_id'  => $this->conversationId,
			'user_id'          => $this->userId,
			'participant_type' => $this->participantType,
			'role'             => $this->role,
			'last_read_at'     => $this->lastReadAt,
			'joined_at'        => $this->joinedAt,
		);
	}
}
