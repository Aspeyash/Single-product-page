<?php
/**
 * SupportController — REST endpoints for Admin⇄User messaging.
 *
 * Routes (namespace zymarg-comm/v1):
 *   GET  /support/config    — surface config for web + future mobile app
 *   POST /support/start     — start or resume the caller's support thread
 *   GET  /support/threads   — agent-only list of support threads
 *   GET  /support/agents    — admin-only list of the support agent pool
 *
 * Messaging itself intentionally has NO bespoke endpoints: once a thread
 * exists, clients use the standard /conversations/{id}/messages surface, so a
 * mobile app gets attachments, reactions, replies, typing and read receipts
 * without any support-specific code.
 *
 * @package ZymargCommunication
 * @since   1.25.0
 */

namespace ZymargCommunication\Modules\Support\Controllers;

use WP_REST_Request;
use WP_REST_Response;
use ZymargCommunication\Core\Abstracts\AbstractController;
use ZymargCommunication\Infrastructure\Http\Middleware\AuthMiddleware;
use ZymargCommunication\Infrastructure\Http\Middleware\NonceMiddleware;
use ZymargCommunication\Modules\Support\Repositories\SupportRepository;
use ZymargCommunication\Modules\Support\Repositories\SupportTicketRepository;
use ZymargCommunication\Modules\Support\Services\SupportService;
use ZymargCommunication\Modules\Support\Services\SupportTicketService;
use ZymargCommunication\Shared\Enums\TicketStatus;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class SupportController extends AbstractController {

	public function __construct(
		private SupportService $support,
		private SupportRepository $repository,
		private SupportTicketService $ticketService,
		private SupportTicketRepository $tickets
	) {}

	public function registerRoutes(): void {
		register_rest_route(
			self::NAMESPACE,
			'/support/config',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'config' ),
				'permission_callback' => array( AuthMiddleware::class, 'requireLoggedIn' ),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/support/start',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'start' ),
				'permission_callback' => array( $this, 'writeGuard' ),
				'args'                => array(
					// Agents may open a thread WITH a customer. Customers omit this
					// and get their own thread.
					'user_id'   => array( 'type' => 'integer', 'required' => false ),
					// Smart Intake context (1.27.0). All optional; stored on the
					// new ticket so the agent sees what it is about immediately.
					'topic'     => array( 'type' => 'string', 'required' => false ),
					'subject'   => array( 'type' => 'string', 'required' => false ),
					'order_id'  => array( 'type' => 'integer', 'required' => false ),
					'vendor_id' => array( 'type' => 'integer', 'required' => false ),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/support/threads',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'threads' ),
				'permission_callback' => array( AuthMiddleware::class, 'requireLoggedIn' ),
				'args'                => array(
					'limit'  => array( 'type' => 'integer', 'required' => false ),
					'offset' => array( 'type' => 'integer', 'required' => false ),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/support/agents',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'agents' ),
				'permission_callback' => array( AuthMiddleware::class, 'requireLoggedIn' ),
			)
		);

		// ── Ticket lifecycle (1.27.0) ────────────────────────────────────────

		// Smart Intake data: topic chips + the caller's recent orders + a
		// friendly availability line. Drives the pre-thread intake card.
		register_rest_route(
			self::NAMESPACE,
			'/support/intake',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'intake' ),
				'permission_callback' => array( AuthMiddleware::class, 'requireLoggedIn' ),
			)
		);

		// Agent queue with filters: status=open|awaiting_agent|awaiting_user|
		// resolved|closed, scope=mine|unassigned.
		register_rest_route(
			self::NAMESPACE,
			'/support/queue',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'queue' ),
				'permission_callback' => array( AuthMiddleware::class, 'requireLoggedIn' ),
				'args'                => array(
					'status' => array( 'type' => 'string', 'required' => false ),
					'scope'  => array( 'type' => 'string', 'required' => false ),
					'limit'  => array( 'type' => 'integer', 'required' => false ),
					'offset' => array( 'type' => 'integer', 'required' => false ),
				),
			)
		);

		// Badge counts (open / per-status / total). Agent-only.
		register_rest_route(
			self::NAMESPACE,
			'/support/counts',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'counts' ),
				'permission_callback' => array( AuthMiddleware::class, 'requireLoggedIn' ),
			)
		);

		// Aggregate stats for reporting (avg rating, first-response, reopened,
		// escalated). Admin-only. Consumed by Insights or shown on the admin
		// screen; this plugin only emits.
		register_rest_route(
			self::NAMESPACE,
			'/support/stats',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'stats' ),
				'permission_callback' => array( AuthMiddleware::class, 'requireLoggedIn' ),
			)
		);

		// Full ticket descriptor: status + requester card + context + history.
		register_rest_route(
			self::NAMESPACE,
			'/support/ticket/(?P<id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'ticket' ),
				'permission_callback' => array( AuthMiddleware::class, 'requireLoggedIn' ),
			)
		);

		// Agent lifecycle actions. 1.31.0 adds the helpline session controls:
		// pause holds the auto-close clock, resume restarts it with a full
		// window, and extend pushes the deadline out by ?minutes.
		register_rest_route(
			self::NAMESPACE,
			'/support/ticket/(?P<id>\d+)/(?P<action>resolve|reopen|close|pause|resume|extend)',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'transition' ),
				'permission_callback' => array( $this, 'writeGuard' ),
			)
		);

		// Customer-side keep-alive (1.31.0). Called by the composer ONLY inside
		// the warning window while the customer is actually typing, so somebody
		// mid-sentence is not cut off at the buzzer. Deliberately not a poll: at
		// most a request or two per case, and it is a no-op unless a clock is
		// genuinely running, so it cannot be used to hold a case open forever.
		register_rest_route(
			self::NAMESPACE,
			'/support/ticket/(?P<id>\d+)/heartbeat',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'heartbeat' ),
				'permission_callback' => array( AuthMiddleware::class, 'requireLoggedIn' ),
			)
		);

		// Attach / edit topic, subject, order, vendor.
		register_rest_route(
			self::NAMESPACE,
			'/support/ticket/(?P<id>\d+)/context',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'setContext' ),
				'permission_callback' => array( $this, 'writeGuard' ),
				'args'                => array(
					'topic'     => array( 'type' => 'string', 'required' => false ),
					'subject'   => array( 'type' => 'string', 'required' => false ),
					'order_id'  => array( 'type' => 'integer', 'required' => false ),
					'vendor_id' => array( 'type' => 'integer', 'required' => false ),
				),
			)
		);

		// Customer satisfaction rating for a resolved ticket.
		register_rest_route(
			self::NAMESPACE,
			'/support/ticket/(?P<id>\d+)/rate',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'rate' ),
				'permission_callback' => array( $this, 'writeGuard' ),
				'args'                => array(
					'rating'  => array( 'type' => 'integer', 'required' => true ),
					'comment' => array( 'type' => 'string', 'required' => false ),
				),
			)
		);
	}

	/** Combined auth + nonce guard for POST routes. */
	public function writeGuard( WP_REST_Request $request ) {
		$auth = AuthMiddleware::requireLoggedIn( $request );
		if ( $auth instanceof \WP_Error ) {
			return $auth;
		}
		$nonce = NonceMiddleware::verify( $request );
		if ( $nonce instanceof \WP_Error ) {
			return $nonce;
		}

		return true;
	}

	public function config( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle(
			function () {
				return $this->support->config( $this->currentUserId() );
			}
		);
	}

	public function start( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle(
			function () use ( $request ) {
				$this->requireAuthenticated();

				if ( ! $this->support->enabled() ) {
					return $this->fail(
						'support_disabled',
						__( 'Support messaging is currently unavailable.', 'zymarg-communication' ),
						403
					);
				}

				$me     = $this->currentUserId();
				$target = (int) $this->param( $request, 'user_id', 0 );

				// Only agents may open a thread on someone else's behalf.
				if ( $target > 0 && $target !== $me && ! $this->support->isAgent( $me ) ) {
					return $this->fail(
						'forbidden',
						__( 'You cannot open a support thread for another user.', 'zymarg-communication' ),
						403
					);
				}

				$for_user = $target > 0 ? $target : $me;

				// Smart Intake context, sanitized. An agent opening on someone's
				// behalf may also seed it; a customer supplies it from the intake
				// card before the thread exists.
				$context = array(
					'topic'     => (string) $this->param( $request, 'topic', '' ),
					'subject'   => (string) $this->param( $request, 'subject', '' ),
					'order_id'  => (int) $this->param( $request, 'order_id', 0 ),
					'vendor_id' => (int) $this->param( $request, 'vendor_id', 0 ),
				);

				return $this->support->startOrResume( $for_user, $context );
			}
		);
	}

	public function threads( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle(
			function () use ( $request ) {
				$this->requireAuthenticated();

				if ( ! $this->support->isAgent( $this->currentUserId() ) ) {
					return $this->fail(
						'forbidden',
						__( 'Support agents only.', 'zymarg-communication' ),
						403
					);
				}

				$limit  = (int) $this->param( $request, 'limit', 50 );
				$offset = (int) $this->param( $request, 'offset', 0 );
				$rows   = $this->repository->listAll( $limit, $offset );

				$threads = array();
				foreach ( $rows as $row ) {
					$requester = (int) ( $row['initiated_by'] ?? 0 );
					$user      = $requester > 0 ? get_userdata( $requester ) : null;
					$threads[] = array(
						'conversation_id' => (int) ( $row['id'] ?? 0 ),
						'status'          => (string) ( $row['status'] ?? '' ),
						'user_id'         => $requester,
						'user_name'       => $user ? (string) $user->display_name : '',
						'last_message_at' => (string) ( $row['last_message_at'] ?? '' ),
						'created_at'      => (string) ( $row['created_at'] ?? '' ),
					);
				}

				return array(
					'threads' => $threads,
					'total'   => $this->repository->countAll(),
				);
			}
		);
	}

	public function agents( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle(
			function () {
				$this->requireAdmin();

				$out = array();
				foreach ( $this->support->agentIds() as $id ) {
					$user = get_userdata( (int) $id );
					if ( ! $user ) {
						continue;
					}
					$out[] = array(
						'id'    => (int) $id,
						'name'  => (string) $user->display_name,
						'email' => (string) $user->user_email,
						'load'  => $this->tickets->openCountForAgent( (int) $id ),
					);
				}

				return array( 'agents' => $out );
			}
		);
	}

	/** Smart Intake payload for the current user. */
	public function intake( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle(
			function () {
				$this->requireAuthenticated();

				if ( ! $this->support->enabled() ) {
					return $this->fail( 'support_disabled', __( 'Support is unavailable.', 'zymarg-communication' ), 403 );
				}

				$me = $this->currentUserId();

				return array(
					'topics'       => $this->support->intakeTopics( $me ),
					'orders'       => $this->support->recentOrders( $me ),
					'availability' => $this->support->availability(),
					'has_open'     => null !== $this->tickets->findOpenForUser( $me ),
				);
			}
		);
	}

	/* =====================================================================
	 * Ticket lifecycle (1.27.0)
	 * ===================================================================== */

	/** Agent-only queue, ordered needs-reply first. */
	public function queue( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle(
			function () use ( $request ) {
				$me = $this->requireAgent();

				$args = array(
					'status' => (string) $this->param( $request, 'status', 'open' ),
					'limit'  => (int) $this->param( $request, 'limit', 50 ),
					'offset' => (int) $this->param( $request, 'offset', 0 ),
				);

				$scope = (string) $this->param( $request, 'scope', '' );
				if ( 'mine' === $scope ) {
					$args['agent_id'] = $me;
				} elseif ( 'unassigned' === $scope ) {
					$args['unassigned'] = true;
				}

				$rows    = $this->tickets->queue( $args );
				$tickets = array();
				foreach ( $rows as $row ) {
					$tickets[] = $this->presentQueueRow( $row );
				}

				return array(
					'tickets' => $tickets,
					'counts'  => $this->tickets->counts(),
				);
			}
		);
	}

	/** Badge counts. Agent-only. */
	public function counts( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle(
			function () {
				$this->requireAgent();

				return array( 'counts' => $this->tickets->counts() );
			}
		);
	}

	/** Aggregate support stats. Admin-only. */
	public function stats( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle(
			function () {
				$this->requireAdmin();

				return $this->tickets->stats();
			}
		);
	}

	/** Full descriptor for one ticket: status, who, context, history. */
	public function ticket( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle(
			function () use ( $request ) {
				$this->requireAuthenticated();
				$id = (int) $request['id'];

				$me       = $this->currentUserId();
				$is_agent = $this->support->isAgent( $me );
				$row      = $this->tickets->find( $id );

				// A customer may read only their own ticket; an agent, any.
				$requester = (int) ( $row['requester_id'] ?? 0 );
				if ( ! $is_agent && $requester !== $me ) {
					return $this->fail( 'forbidden', __( 'Not your ticket.', 'zymarg-communication' ), 403 );
				}

				$out = array(
					'conversation_id' => $id,
					'status'          => $this->ticketService->statusDescriptor( $id, $is_agent ),
					'context'         => $this->ticketService->contextCard( $id ),
					'rating'          => (int) ( $row['rating'] ?? 0 ),
				);

				// Agent-only intelligence: who is asking, their past tickets, and
				// how long they have been waiting on us (1.32.15). Deliberately NOT
				// sent to customers — telling somebody "you have been waiting 47
				// minutes" only advertises the delay; their side already carries the
				// measured "we usually reply in about X" estimate.
				if ( $is_agent ) {
					$out['requester'] = $this->ticketService->requesterCard( $requester );
					$out['history']   = $this->ticketService->historyCards( $requester, $id );
					$out['waiting']   = $this->waitingFor( is_array( $row ) ? $row : array() );
				}

				return $out;
			}
		);
	}

	/** resolve | reopen | close — agent only. */
	public function transition( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle(
			function () use ( $request ) {
				$me     = $this->requireAgent();
				$id     = (int) $request['id'];
				$action = (string) $request['action'];

				$ok = match ( $action ) {
					'resolve' => $this->ticketService->resolve( $id, $me ),
					'reopen'  => $this->ticketService->reopen( $id, $me ),
					'close'   => $this->ticketService->close( $id, $me ),
					// 1.31.0 helpline session controls.
					'pause'   => $this->ticketService->pauseAutoclose( $id, $me ),
					'resume'  => $this->ticketService->resumeAutoclose( $id, $me ),
					'extend'  => $this->ticketService->extendAutoclose(
						$id,
						max( 1, (int) ( $request->get_param( 'minutes' ) ?? 10 ) ),
						$me
					),
					default   => false,
				};

				if ( ! $ok ) {
					return $this->fail( 'ticket_action_failed', __( 'Could not update the ticket.', 'zymarg-communication' ), 400 );
				}

				return array(
					'conversation_id' => $id,
					'status'          => $this->ticketService->statusDescriptor( $id, true ),
				);
			}
		);
	}

	/**
	 * Customer keep-alive for the auto-close clock (1.31.0).
	 *
	 * Only the customer whose case it is may push their own deadline out. An
	 * agent has pause/resume/extend for this, and letting anyone else call it
	 * would be a way to keep somebody else's case alive.
	 */
	public function heartbeat( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle(
			function () use ( $request ) {
				$this->requireAuthenticated();
				$id = (int) $request['id'];

				$row       = $this->tickets->find( $id );
				$requester = (int) ( $row['requester_id'] ?? 0 );

				if ( $requester !== $this->currentUserId() ) {
					return $this->fail( 'forbidden', __( 'Not your ticket.', 'zymarg-communication' ), 403 );
				}

				// touchAutoclose() is itself a no-op unless a clock is running, so
				// a stale client cannot resurrect a settled case.
				$this->ticketService->touchAutoclose( $id );

				return array(
					'conversation_id' => $id,
					'autoclose'       => $this->ticketService->autocloseDescriptor( $id ),
				);
			}
		);
	}

	/** Attach or edit ticket context — agent only. */
	public function setContext( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle(
			function () use ( $request ) {
				$this->requireAgent();
				$id = (int) $request['id'];

				$ctx = array();
				foreach ( array( 'topic', 'subject', 'order_id', 'vendor_id' ) as $key ) {
					$val = $this->param( $request, $key, null );
					if ( null !== $val ) {
						$ctx[ $key ] = $val;
					}
				}

				$this->ticketService->setContext( $id, $ctx );

				return array(
					'conversation_id' => $id,
					'context'         => $this->ticketService->contextCard( $id ),
				);
			}
		);
	}

	/** Customer rates their resolved ticket (agents may also record on behalf). */
	public function rate( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle(
			function () use ( $request ) {
				$this->requireAuthenticated();
				$id = (int) $request['id'];

				$me        = $this->currentUserId();
				$row       = $this->tickets->find( $id );
				$requester = (int) ( $row['requester_id'] ?? 0 );

				// Only the person who opened the ticket, or an agent, may rate it.
				if ( $requester !== $me && ! $this->support->isAgent( $me ) ) {
					return $this->fail( 'forbidden', __( 'Not your ticket.', 'zymarg-communication' ), 403 );
				}

				$rating  = (int) $this->param( $request, 'rating', 0 );
				$comment = (string) $this->param( $request, 'comment', '' );
				if ( $rating < 1 || $rating > 5 ) {
					return $this->fail( 'invalid_rating', __( 'Rating must be between 1 and 5.', 'zymarg-communication' ), 400 );
				}

				$this->ticketService->rate( $id, $rating, $comment );

				return array( 'conversation_id' => $id, 'rating' => $rating );
			}
		);
	}

	/** Shape a ticket row for the agent queue. */
	private function presentQueueRow( array $row ): array {
		$id        = (int) ( $row['conversation_id'] ?? 0 );
		$requester = (int) ( $row['requester_id'] ?? 0 );
		$status    = TicketStatus::fromLoose( $row['ticket_status'] ?? null );
		$user      = $requester > 0 ? get_userdata( $requester ) : null;

		return array(
			'conversation_id' => $id,
			'requester_id'    => $requester,
			'requester_name'  => $user ? (string) $user->display_name : __( 'Unknown', 'zymarg-communication' ),
			'agent_id'        => (int) ( $row['agent_id'] ?? 0 ),
			'status'          => $status->value,
			'status_label'    => $status->agentLabel(),
			'tone'            => $status->tone(),
			'topic'           => (string) ( $row['topic'] ?? '' ),
			'subject'         => (string) ( $row['subject'] ?? '' ),
			'order_id'        => (int) ( $row['order_id'] ?? 0 ),
			'rating'          => (int) ( $row['rating'] ?? 0 ),
			'escalation_count'=> (int) ( $row['escalation_count'] ?? 0 ),
			'updated_at'      => (string) ( $row['updated_at'] ?? '' ),
			// 1.32.15 — how long this person has been waiting on the team, so the
			// queue can be triaged by urgency instead of by a raw clock time.
			// Zeros for any case not awaiting an agent.
			'waiting'         => $this->waitingFor( $row ),
		);
	}

	/**
	 * Waiting descriptor for a ticket row, never fatal.
	 *
	 * @since 1.32.15
	 * @param array<string,mixed> $row
	 * @return array{seconds:int,label:string,tone:string}
	 */
	private function waitingFor( array $row ): array {
		try {
			return $this->ticketService->waitingDescriptor( $row );
		} catch ( \Throwable $e ) {
			return array(
				'seconds' => 0,
				'label'   => '',
				'tone'    => 'ok',
			);
		}
	}

	/**
	 * Require the caller to be a support agent, returning their id.
	 *
	 * @throws \ZymargCommunication\Core\Exceptions\UnauthorizedException
	 */
	private function requireAgent(): int {
		$this->requireAuthenticated();
		$me = $this->currentUserId();
		if ( ! $this->support->isAgent( $me ) ) {
			throw new \ZymargCommunication\Core\Exceptions\UnauthorizedException(
				__( 'Support agents only.', 'zymarg-communication' )
			);
		}

		return $me;
	}
}
