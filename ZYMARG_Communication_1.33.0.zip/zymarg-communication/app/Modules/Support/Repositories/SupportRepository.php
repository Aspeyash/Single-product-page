<?php
/**
 * SupportRepository — data access for Admin⇄User (support) conversations.
 *
 * Support threads are ordinary conversations distinguished ONLY by
 * `context_type = 'support'`. Nothing new is stored in the database, which is
 * why this feature needs no migration: it reuses zc_conversations,
 * zc_participants and zc_messages exactly as the buyer/seller surfaces do.
 *
 * @package ZymargCommunication
 * @since   1.25.0
 */

namespace ZymargCommunication\Modules\Support\Repositories;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class SupportRepository {

	/** Context type marking a conversation as an Admin<->User support thread. */
	public const CONTEXT = 'support';

	private function conversations(): string {
		global $wpdb;
		return $wpdb->prefix . 'zc_conversations';
	}

	private function participants(): string {
		global $wpdb;
		return $wpdb->prefix . 'zc_participants';
	}

	/**
	 * Find the user's existing support thread, if any.
	 *
	 * One ongoing thread per user: repeat contacts resume the same conversation
	 * instead of spawning duplicates. Most recent wins if history ever produced
	 * more than one.
	 */
	public function findForUser( int $user_id ): ?int {
		global $wpdb;
		if ( $user_id < 1 ) {
			return null;
		}
		$c  = $this->conversations();
		$p  = $this->participants();
		$id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT c.id FROM {$c} c
				 INNER JOIN {$p} p ON p.conversation_id = c.id
				 WHERE c.context_type = %s AND p.user_id = %d
				 ORDER BY c.last_message_at DESC, c.id DESC
				 LIMIT 1",
				self::CONTEXT,
				$user_id
			)
		);

		return null !== $id ? (int) $id : null;
	}

	/**
	 * Every support thread, newest activity first.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function listAll( int $limit = 50, int $offset = 0 ): array {
		global $wpdb;
		$limit  = max( 1, min( 200, $limit ) );
		$offset = max( 0, $offset );
		$c      = $this->conversations();

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, status, initiated_by, last_message_at, created_at
				 FROM {$c}
				 WHERE context_type = %s
				 ORDER BY last_message_at DESC, id DESC
				 LIMIT %d OFFSET %d",
				self::CONTEXT,
				$limit,
				$offset
			),
			ARRAY_A
		);

		return is_array( $rows ) ? $rows : array();
	}

	/** Total number of support threads. */
	public function countAll(): int {
		global $wpdb;
		$c = $this->conversations();

		return (int) $wpdb->get_var(
			$wpdb->prepare( "SELECT COUNT(*) FROM {$c} WHERE context_type = %s", self::CONTEXT )
		);
	}

	/**
	 * How many open support threads a given agent is currently a participant of.
	 * Used to spread new threads across the agent pool.
	 */
	public function loadForAgent( int $agent_id ): int {
		global $wpdb;
		if ( $agent_id < 1 ) {
			return 0;
		}
		$c = $this->conversations();
		$p = $this->participants();

		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$c} c
				 INNER JOIN {$p} p ON p.conversation_id = c.id
				 WHERE c.context_type = %s AND p.user_id = %d",
				self::CONTEXT,
				$agent_id
			)
		);
	}

	/**
	 * Is this conversation a support thread?
	 *
	 * Cheap single-column lookup, cached per request. Used as the gate before
	 * any ticket work so an ordinary buyer/vendor message never touches the
	 * ticket table.
	 */
	public function isSupportConversation( int $conversation_id ): bool {
		if ( $conversation_id < 1 ) {
			return false;
		}

		static $cache = array();
		if ( isset( $cache[ $conversation_id ] ) ) {
			return $cache[ $conversation_id ];
		}

		global $wpdb;
		$context = $wpdb->get_var(
			$wpdb->prepare( "SELECT context_type FROM {$this->conversations()} WHERE id = %d", $conversation_id )
		);

		$cache[ $conversation_id ] = ( self::CONTEXT === $context );

		return $cache[ $conversation_id ];
	}

	/**
	 * The non-agent participant of a support thread (i.e. the customer).
	 */
	public function requesterFor( int $conversation_id ): ?int {
		global $wpdb;
		if ( $conversation_id < 1 ) {
			return null;
		}
		$c = $this->conversations();

		$id = $wpdb->get_var(
			$wpdb->prepare( "SELECT initiated_by FROM {$c} WHERE id = %d", $conversation_id )
		);

		return null !== $id ? (int) $id : null;
	}
}
