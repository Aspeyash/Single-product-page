<?php
/**
 * SupportTicketRepository — operational state for support conversations.
 *
 * One row per support thread in `zc_support_tickets`, keyed by conversation_id.
 * Holds what the conversation engine has no opinion about: is it solved, who is
 * it waiting on, what is it about, which order it concerns, and the timestamps
 * needed for escalation and reporting.
 *
 * TIME HANDLING: every write and every comparison in this class uses
 * current_time('mysql') — site-local time — consistently. Mixing that with
 * MySQL's CURRENT_TIMESTAMP (server time, frequently UTC) is how "older than
 * two hours" quietly becomes "older than eight hours" on a UTC+6 site, so this
 * table never relies on column defaults for its timestamps.
 *
 * @package ZymargCommunication
 * @since   1.27.0
 */

namespace ZymargCommunication\Modules\Support\Repositories;

use ZymargCommunication\Shared\Enums\TicketStatus;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class SupportTicketRepository {

	private function table(): string {
		global $wpdb;

		return $wpdb->prefix . 'zc_support_tickets';
	}

	private function conversations(): string {
		global $wpdb;

		return $wpdb->prefix . 'zc_conversations';
	}

	private function now(): string {
		return current_time( 'mysql' );
	}

	/**
	 * Does the table exist? Guards every read so a site that upgraded without
	 * the migration having run yet degrades to "no ticket data" instead of
	 * throwing a database error onto a customer-facing page.
	 */
	public function tableReady(): bool {
		static $ready = null;
		if ( null !== $ready ) {
			return $ready;
		}

		global $wpdb;
		$table = $this->table();
		$found = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
		$ready = ( $found === $table );

		return $ready;
	}

	/** Reset the cached table check. Test seam. */
	public function flushReadyCache(): void {
		// Static inside tableReady() cannot be reset directly; callers in tests
		// use a fresh instance. Kept for API symmetry and documentation.
	}

	/**
	 * Fetch a ticket row.
	 *
	 * @return array<string, mixed>|null
	 */
	public function find( int $conversation_id ): ?array {
		if ( $conversation_id < 1 || ! $this->tableReady() ) {
			return null;
		}

		global $wpdb;
		$row = $wpdb->get_row(
			$wpdb->prepare( 'SELECT * FROM `' . $this->table() . '` WHERE conversation_id = %d', $conversation_id ),
			ARRAY_A
		);

		return is_array( $row ) ? $row : null;
	}

	/**
	 * Fetch the ticket row, creating it if this thread predates the ticket table.
	 *
	 * Threads created before 1.27.0 have no row. Rather than a migration pass
	 * over unbounded history, they are adopted the first time anything asks
	 * about them, seeded from the conversation itself.
	 *
	 * @return array<string, mixed>|null
	 */
	public function ensure( int $conversation_id, int $requester_id = 0, int $agent_id = 0, array $seed = array() ): ?array {
		if ( $conversation_id < 1 || ! $this->tableReady() ) {
			return null;
		}

		$existing = $this->find( $conversation_id );
		if ( null !== $existing ) {
			return $existing;
		}

		global $wpdb;

		// Seed from the conversation when the caller did not supply a requester.
		if ( $requester_id < 1 ) {
			$requester_id = (int) $wpdb->get_var(
				$wpdb->prepare( 'SELECT initiated_by FROM `' . $this->conversations() . '` WHERE id = %d', $conversation_id )
			);
		}

		$created = (string) $wpdb->get_var(
			$wpdb->prepare( 'SELECT created_at FROM `' . $this->conversations() . '` WHERE id = %d', $conversation_id )
		);
		if ( '' === $created ) {
			$created = $this->now();
		}

		$data = array(
			'conversation_id' => $conversation_id,
			'requester_id'    => max( 0, $requester_id ),
			'agent_id'        => max( 0, $agent_id ),
			'ticket_status'   => TicketStatus::AwaitingAgent->value,
			'topic'           => substr( (string) ( $seed['topic'] ?? '' ), 0, 40 ),
			'subject'         => substr( (string) ( $seed['subject'] ?? '' ), 0, 200 ),
			'order_id'        => max( 0, (int) ( $seed['order_id'] ?? 0 ) ),
			'vendor_id'       => max( 0, (int) ( $seed['vendor_id'] ?? 0 ) ),
			'created_at'      => $created,
			'updated_at'      => $this->now(),
		);

		// INSERT IGNORE semantics via a guarded insert: two simultaneous first
		// requests would otherwise race on a primary-key collision.
		$wpdb->insert( $this->table(), $data );

		return $this->find( $conversation_id );
	}

	/**
	 * Patch a ticket row. Only known columns are written.
	 *
	 * @param array<string, mixed> $fields
	 */
	public function update( int $conversation_id, array $fields ): bool {
		if ( $conversation_id < 1 || ! $this->tableReady() || empty( $fields ) ) {
			return false;
		}

		$allowed = array(
			'requester_id', 'agent_id', 'ticket_status', 'topic', 'subject',
			'order_id', 'vendor_id', 'first_response_at', 'last_user_reply_at',
			'last_agent_reply_at', 'resolved_at', 'resolved_by', 'reopened_count',
			'escalated_at', 'escalation_count', 'rating', 'rating_comment', 'rated_at',
			// 1.31.0 helpline session columns. Anything absent from this list is
			// silently dropped by array_intersect_key below, so a new column that
			// is not added here appears to save and simply does not.
			'closed_reason', 'autoclose_paused', 'autoclose_until',
		);

		$data = array_intersect_key( $fields, array_flip( $allowed ) );
		if ( empty( $data ) ) {
			return false;
		}
		$data['updated_at'] = $this->now();

		global $wpdb;

		return false !== $wpdb->update( $this->table(), $data, array( 'conversation_id' => $conversation_id ) );
	}

	/** Current status, defaulting to AwaitingAgent for unknown/absent rows. */
	public function status( int $conversation_id ): TicketStatus {
		$row = $this->find( $conversation_id );

		return TicketStatus::fromLoose( $row['ticket_status'] ?? null );
	}

	/**
	 * Move a ticket to a new status, maintaining the derived timestamps.
	 *
	 * Resolving stamps resolved_at/resolved_by. Reopening clears them and
	 * increments reopened_count, so "solved then came back" is visible rather
	 * than being erased by the transition.
	 */
	public function setStatus( int $conversation_id, TicketStatus $status, int $actor_id = 0 ): bool {
		$row = $this->ensure( $conversation_id );
		if ( null === $row ) {
			return false;
		}

		$was    = TicketStatus::fromLoose( $row['ticket_status'] ?? null );
		$fields = array( 'ticket_status' => $status->value );

		if ( TicketStatus::Resolved === $status || TicketStatus::Closed === $status ) {
			$fields['resolved_at'] = $this->now();
			$fields['resolved_by'] = max( 0, $actor_id );
		} elseif ( $was->isSettled() && $status->isOpen() ) {
			// Coming back from settled is a reopen, and worth counting.
			$fields['resolved_at']    = null;
			$fields['resolved_by']    = 0;
			$fields['reopened_count'] = (int) ( $row['reopened_count'] ?? 0 ) + 1;
		}

		return $this->update( $conversation_id, $fields );
	}

	/**
	 * Record that the CUSTOMER wrote. Flips the ticket into the agent queue and
	 * reopens it if it had been resolved.
	 *
	 * @return TicketStatus The status after the transition.
	 */
	public function recordUserReply( int $conversation_id ): TicketStatus {
		$row = $this->ensure( $conversation_id );
		if ( null === $row ) {
			return TicketStatus::AwaitingAgent;
		}

		$was  = TicketStatus::fromLoose( $row['ticket_status'] ?? null );
		$next = $was;

		if ( TicketStatus::Closed === $was ) {
			// Closed is final: a new message does not resurrect it. The caller
			// (SupportService) is responsible for opening a fresh ticket.
			$this->update( $conversation_id, array( 'last_user_reply_at' => $this->now() ) );

			return $was;
		}

		$next   = TicketStatus::AwaitingAgent;
		$fields = array(
			'ticket_status'      => $next->value,
			'last_user_reply_at' => $this->now(),
		);

		if ( $was->reopensOnUserReply() ) {
			$fields['resolved_at']    = null;
			$fields['resolved_by']    = 0;
			$fields['reopened_count'] = (int) ( $row['reopened_count'] ?? 0 ) + 1;
		}

		$this->update( $conversation_id, $fields );

		return $next;
	}

	/**
	 * Record that an AGENT replied. Hands the ticket back to the customer and
	 * stamps first_response_at once, which is the basis of any response-time
	 * reporting later.
	 */
	public function recordAgentReply( int $conversation_id, int $agent_id = 0 ): TicketStatus {
		$row = $this->ensure( $conversation_id );
		if ( null === $row ) {
			return TicketStatus::AwaitingUser;
		}

		$was = TicketStatus::fromLoose( $row['ticket_status'] ?? null );

		// Replying to a settled ticket is a deliberate follow-up, not a reopen by
		// the customer, so it moves to AwaitingUser without touching the counter.
		$fields = array(
			'ticket_status'       => TicketStatus::AwaitingUser->value,
			'last_agent_reply_at' => $this->now(),
		);

		if ( empty( $row['first_response_at'] ) ) {
			$fields['first_response_at'] = $this->now();
		}
		if ( $agent_id > 0 && (int) ( $row['agent_id'] ?? 0 ) < 1 ) {
			$fields['agent_id'] = $agent_id;
		}
		if ( TicketStatus::Closed === $was ) {
			$fields['resolved_at'] = null;
			$fields['resolved_by'] = 0;
		}

		$this->update( $conversation_id, $fields );

		return TicketStatus::AwaitingUser;
	}

	/**
	 * The user's most recent OPEN ticket, if any.
	 *
	 * This is what makes ticket-per-issue possible: a resolved or closed ticket
	 * is not resumed, so a new problem gets a new thread instead of being
	 * appended to a conversation an agent already signed off.
	 *
	 * @return array<string, mixed>|null
	 */
	public function findOpenForUser( int $user_id ): ?array {
		if ( $user_id < 1 || ! $this->tableReady() ) {
			return null;
		}

		global $wpdb;
		$open = TicketStatus::openValues();
		$in   = implode( ',', array_fill( 0, count( $open ), '%s' ) );

		$sql = $wpdb->prepare(
			'SELECT * FROM `' . $this->table() . '`
			 WHERE requester_id = %d AND ticket_status IN (' . $in . ')
			 ORDER BY updated_at DESC, conversation_id DESC LIMIT 1',
			array_merge( array( $user_id ), $open )
		);

		$row = $wpdb->get_row( $sql, ARRAY_A );

		return is_array( $row ) ? $row : null;
	}

	/**
	 * Every ticket for a user, newest first. Powers the agent-side history panel
	 * ("3 previous tickets, last resolved Aug 2").
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function historyForUser( int $user_id, int $limit = 10, int $exclude_conversation = 0 ): array {
		if ( $user_id < 1 || ! $this->tableReady() ) {
			return array();
		}

		global $wpdb;
		$limit = max( 1, min( 50, $limit ) );

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT * FROM `' . $this->table() . '`
				 WHERE requester_id = %d AND conversation_id <> %d
				 ORDER BY updated_at DESC, conversation_id DESC LIMIT %d',
				$user_id,
				max( 0, $exclude_conversation ),
				$limit
			),
			ARRAY_A
		);

		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * The agent queue.
	 *
	 * @param array{status?:string,agent_id?:int,unassigned?:bool,limit?:int,offset?:int} $args
	 * @return array<int, array<string, mixed>>
	 */
	public function queue( array $args = array() ): array {
		if ( ! $this->tableReady() ) {
			return array();
		}

		global $wpdb;
		$limit  = max( 1, min( 200, (int) ( $args['limit'] ?? 50 ) ) );
		$offset = max( 0, (int) ( $args['offset'] ?? 0 ) );

		$where  = array( '1=1' );
		$params = array();

		$status = (string) ( $args['status'] ?? '' );
		if ( 'open' === $status ) {
			$open    = TicketStatus::openValues();
			$where[] = 'ticket_status IN (' . implode( ',', array_fill( 0, count( $open ), '%s' ) ) . ')';
			$params  = array_merge( $params, $open );
		} elseif ( '' !== $status && in_array( $status, TicketStatus::values(), true ) ) {
			$where[]  = 'ticket_status = %s';
			$params[] = $status;
		}

		if ( ! empty( $args['unassigned'] ) ) {
			$where[] = 'agent_id = 0';
		} elseif ( ! empty( $args['agent_id'] ) ) {
			$where[]  = 'agent_id = %d';
			$params[] = (int) $args['agent_id'];
		}

		$sql = 'SELECT * FROM `' . $this->table() . '` WHERE ' . implode( ' AND ', $where )
			. ' ORDER BY FIELD(ticket_status, %s, %s, %s, %s), updated_at DESC LIMIT %d OFFSET %d';

		// Queue order is intentional: things needing a reply first, closed last.
		$params = array_merge(
			$params,
			array(
				TicketStatus::AwaitingAgent->value,
				TicketStatus::AwaitingUser->value,
				TicketStatus::Resolved->value,
				TicketStatus::Closed->value,
				$limit,
				$offset,
			)
		);

		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A );

		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Ticket counts per status, plus an `open` roll-up. Drives badges.
	 *
	 * @return array<string, int>
	 */
	public function counts(): array {
		$out = array_fill_keys( TicketStatus::values(), 0 );
		$out['open']  = 0;
		$out['total'] = 0;

		if ( ! $this->tableReady() ) {
			return $out;
		}

		global $wpdb;
		$rows = $wpdb->get_results(
			'SELECT ticket_status, COUNT(*) AS n FROM `' . $this->table() . '` GROUP BY ticket_status',
			ARRAY_A
		);

		foreach ( (array) $rows as $row ) {
			$key = (string) ( $row['ticket_status'] ?? '' );
			$n   = (int) ( $row['n'] ?? 0 );
			if ( isset( $out[ $key ] ) ) {
				$out[ $key ] = $n;
			}
			$out['total'] += $n;
			if ( in_array( $key, TicketStatus::openValues(), true ) ) {
				$out['open'] += $n;
			}
		}

		return $out;
	}

	/**
	 * Open tickets assigned to an agent. Used to spread new threads across the
	 * pool — counting only OPEN tickets, unlike the historical version which
	 * counted every thread an agent had ever touched and so kept sending new
	 * work to whoever had been there shortest.
	 */
	public function openCountForAgent( int $agent_id ): int {
		if ( $agent_id < 1 || ! $this->tableReady() ) {
			return 0;
		}

		global $wpdb;
		$open = TicketStatus::openValues();
		$in   = implode( ',', array_fill( 0, count( $open ), '%s' ) );

		return (int) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COUNT(*) FROM `' . $this->table() . '` WHERE agent_id = %d AND ticket_status IN (' . $in . ')',
				array_merge( array( $agent_id ), $open )
			)
		);
	}

	/**
	 * Tickets waiting on an agent for longer than $minutes with no reply yet.
	 * Feeds escalation.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function staleAwaitingAgent( int $minutes, int $limit = 25 ): array {
		if ( ! $this->tableReady() ) {
			return array();
		}

		global $wpdb;
		$minutes = max( 5, $minutes );
		$cutoff  = gmdate( 'Y-m-d H:i:s', strtotime( $this->now() ) - ( $minutes * 60 ) );

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT * FROM `' . $this->table() . '`
				 WHERE ticket_status = %s
				   AND last_agent_reply_at IS NULL
				   AND updated_at <= %s
				 ORDER BY updated_at ASC LIMIT %d',
				TicketStatus::AwaitingAgent->value,
				$cutoff,
				max( 1, min( 100, $limit ) )
			),
			ARRAY_A
		);

		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Cases that WERE answered, then abandoned (1.33.0).
	 *
	 * The sibling of staleAwaitingAgent(), and the fix for a hole that has been
	 * live since 1.27.0. That query filters `last_agent_reply_at IS NULL`, so it
	 * only ever rescues cases NOBODY has answered. The moment an agent replies
	 * once, `last_agent_reply_at` is stamped and the case becomes permanently
	 * invisible to the only automatic reassignment the plugin has.
	 *
	 * So: agent replies, customer replies back, agent then goes quiet — quits,
	 * off sick, account deleted — and that case sits in `awaiting_agent` forever.
	 * Auto-close cannot save it either, because that only fires on
	 * `awaiting_user`. This query is what finally rotates those cases.
	 *
	 * ANCHOR: `last_user_reply_at`, NOT `updated_at`. This is the same trap that
	 * SupportTicketService::waitingDescriptor() had to avoid — `updated_at` is
	 * bumped by every write to the row (a status flip, an extension, a previous
	 * escalation), so anchoring here would let the agent's own actions endlessly
	 * postpone the rescue of the case they are neglecting. `updated_at` remains
	 * only as a fallback for rows predating the column being populated.
	 *
	 * @param  int $minutes Idle window in minutes.
	 * @param  int $limit   Rows per sweep.
	 * @return array<int,array<string,mixed>>
	 */
	public function staleAwaitingAgentClaimed( int $minutes, int $limit = 25 ): array {
		if ( ! $this->tableReady() ) {
			return array();
		}

		global $wpdb;
		$minutes = max( 5, $minutes );
		$cutoff  = gmdate( 'Y-m-d H:i:s', strtotime( $this->now() ) - ( $minutes * 60 ) );

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT * FROM `' . $this->table() . '`
				 WHERE ticket_status = %s
				   AND last_agent_reply_at IS NOT NULL
				   AND COALESCE( last_user_reply_at, updated_at ) <= %s
				 ORDER BY COALESCE( last_user_reply_at, updated_at ) ASC LIMIT %d',
				TicketStatus::AwaitingAgent->value,
				$cutoff,
				max( 1, min( 100, $limit ) )
			),
			ARRAY_A
		);

		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Cases waiting on the CUSTOMER whose reply window has run out (1.31.0).
	 *
	 * The mirror image of staleAwaitingAgent(), and deliberately a separate
	 * query rather than a parameter on it, for three reasons that all matter:
	 *
	 *   1. that method clamps `max( 5, $minutes )`, which would silently floor a
	 *      3-minute helpline window at five;
	 *   2. it filters `last_agent_reply_at IS NULL` — the exact opposite of what
	 *      is needed here, since the agent replying is what starts this clock;
	 *   3. it sorts by `updated_at`, which the autoclose_idx index does not cover.
	 *
	 * Paused cases are excluded in SQL, not in PHP, so a held case costs nothing.
	 * `autoclose_until` overrides the derived deadline when an agent has granted
	 * extra time or the customer was mid-sentence at the buzzer.
	 *
	 * @param  int $minutes Wait, in minutes. NOT floored — a 1-minute window is
	 *                      a legitimate setting.
	 * @return array<int, array<string, mixed>>
	 */
	public function staleAwaitingUser( int $minutes, int $limit = 25 ): array {
		if ( ! $this->tableReady() ) {
			return array();
		}

		global $wpdb;
		$minutes = max( 1, $minutes );
		$now     = $this->now();
		$cutoff  = gmdate( 'Y-m-d H:i:s', strtotime( $now ) - ( $minutes * 60 ) );

		// Two ways a case can be overdue: an explicit deadline that has passed,
		// or no explicit deadline and an agent reply older than the cutoff.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT * FROM `' . $this->table() . '`
				 WHERE ticket_status = %s
				   AND autoclose_paused = 0
				   AND last_agent_reply_at IS NOT NULL
				   AND (
				         ( autoclose_until IS NOT NULL AND autoclose_until <= %s )
				         OR ( autoclose_until IS NULL AND last_agent_reply_at <= %s )
				       )
				 ORDER BY last_agent_reply_at ASC LIMIT %d',
				TicketStatus::AwaitingUser->value,
				$now,
				$cutoff,
				max( 1, min( 100, $limit ) )
			),
			ARRAY_A
		);

		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * How long the team ACTUALLY takes to answer, in seconds (1.32.0).
	 *
	 * Returns the MEDIAN rather than the mean: one ticket answered three days
	 * late would drag an average into uselessness, while the median keeps
	 * describing the typical case. `first_response_at` is already stamped on the
	 * agent's first reply, so no new tracking is needed.
	 *
	 * NULL means "not enough evidence" — the caller must then say nothing rather
	 * than inventing a figure.
	 *
	 * @param  int $days        How far back to look.
	 * @param  int $min_samples Refuse to answer below this many data points.
	 * @return int|null Median seconds, or null.
	 */
	public function medianFirstResponseSeconds( int $days = 30, int $min_samples = 3 ): ?int {
		if ( ! $this->tableReady() ) {
			return null;
		}

		global $wpdb;
		$days   = max( 1, $days );
		$cutoff = gmdate( 'Y-m-d H:i:s', strtotime( $this->now() ) - ( $days * DAY_IN_SECONDS ) );

		$rows = $wpdb->get_col(
			$wpdb->prepare(
				'SELECT TIMESTAMPDIFF(SECOND, created_at, first_response_at) AS secs
				 FROM `' . $this->table() . '`
				 WHERE first_response_at IS NOT NULL
				   AND created_at IS NOT NULL
				   AND first_response_at >= created_at
				   AND created_at >= %s
				 ORDER BY created_at DESC
				 LIMIT 500',
				$cutoff
			)
		);

		$samples = array();
		foreach ( (array) $rows as $secs ) {
			$secs = (int) $secs;
			// Zero is legitimate (answered inside the same second); negatives are
			// clock skew and would only distort the picture.
			if ( $secs >= 0 ) {
				$samples[] = $secs;
			}
		}

		if ( count( $samples ) < max( 1, $min_samples ) ) {
			return null;
		}

		sort( $samples );
		$count  = count( $samples );
		$middle = (int) floor( $count / 2 );

		if ( 0 === $count % 2 ) {
			return (int) round( ( $samples[ $middle - 1 ] + $samples[ $middle ] ) / 2 );
		}

		return (int) $samples[ $middle ];
	}

	/** Store a customer satisfaction rating (1-5). */
	public function setRating( int $conversation_id, int $rating, string $comment = '' ): bool {
		$rating = max( 1, min( 5, $rating ) );

		return $this->update(
			$conversation_id,
			array(
				'rating'         => $rating,
				'rating_comment' => mb_substr( $comment, 0, 2000 ),
				'rated_at'       => $this->now(),
			)
		);
	}

	/**
	 * Aggregate stats for reporting / the Insights bridge.
	 *
	 * @return array<string, mixed>
	 */
	public function stats(): array {
		$counts = $this->counts();
		$out    = array(
			'counts'                 => $counts,
			'avg_rating'             => 0.0,
			'rated_count'            => 0,
			'avg_first_response_min' => 0,
			'reopened_total'         => 0,
			'escalated_total'        => 0,
		);

		if ( ! $this->tableReady() ) {
			return $out;
		}

		global $wpdb;
		$row = $wpdb->get_row(
			'SELECT
				AVG(NULLIF(rating,0)) AS avg_rating,
				SUM(CASE WHEN rating > 0 THEN 1 ELSE 0 END) AS rated_count,
				SUM(reopened_count) AS reopened_total,
				SUM(CASE WHEN escalation_count > 0 THEN 1 ELSE 0 END) AS escalated_total,
				AVG(CASE WHEN first_response_at IS NOT NULL
					THEN TIMESTAMPDIFF(MINUTE, created_at, first_response_at) END) AS avg_first
			 FROM `' . $this->table() . '`',
			ARRAY_A
		);

		if ( is_array( $row ) ) {
			$out['avg_rating']             = round( (float) ( $row['avg_rating'] ?? 0 ), 2 );
			$out['rated_count']            = (int) ( $row['rated_count'] ?? 0 );
			$out['reopened_total']         = (int) ( $row['reopened_total'] ?? 0 );
			$out['escalated_total']        = (int) ( $row['escalated_total'] ?? 0 );
			$out['avg_first_response_min'] = (int) round( (float) ( $row['avg_first'] ?? 0 ) );
		}

		return $out;
	}
}
