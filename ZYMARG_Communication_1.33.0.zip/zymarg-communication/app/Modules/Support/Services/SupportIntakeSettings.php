<?php
/**
 * SupportIntakeSettings — owner-editable copy and topics for Smart Intake.
 *
 * Every string a customer reads on the intake card, plus the topic chips
 * themselves, live here rather than being hard-coded, so the marketplace owner
 * can reword the whole flow from Settings without touching PHP or waiting on a
 * release. Nothing is required: any field left blank falls back to the shipped
 * default, so an empty install reads exactly as it always did and a partially
 * customised install only overrides what was actually filled in.
 *
 * Topics are stored as newline-delimited `key|Label` lines because that is the
 * cheapest thing for a human to edit in a textarea while still giving us a
 * stable machine key to store on the ticket. A line with no pipe gets its key
 * derived from the label, so `Refund` alone is valid and becomes `refund`.
 * Keys matter: they are written to zc_support_tickets.topic and appear in the
 * agent view, so renaming a LABEL is safe while changing a KEY starts a new
 * bucket for future tickets.
 *
 * @package ZymargCommunication
 * @since   1.29.0
 */

namespace ZymargCommunication\Modules\Support\Services;

use ZymargCommunication\Modules\Settings\Repositories\SettingsRepository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class SupportIntakeSettings {

	/** Master switch for the intake card. Ships ON. */
	public const ENABLED = 'support_intake_enabled';

	/** Copy keys. */
	public const TITLE               = 'support_intake_title';
	public const TOPIC_LABEL         = 'support_intake_topic_label';
	public const ORDER_LABEL         = 'support_intake_order_label';
	public const SUBJECT_LABEL       = 'support_intake_subject_label';
	public const SUBJECT_PLACEHOLDER = 'support_intake_subject_placeholder';
	public const AVAILABILITY        = 'support_intake_availability';

	/**
	 * Show the reply-time line at all (1.32.0).
	 *
	 * Needed because blank AVAILABILITY means "work it out yourself", so before
	 * this there was no way to say "show nothing". Defaults to on, which keeps
	 * existing sites exactly as they were.
	 */
	public const SHOW_AVAILABILITY   = 'support_intake_show_availability';
	public const START_BUTTON        = 'support_intake_start_button';
	public const CANCEL_BUTTON       = 'support_intake_cancel_button';

	/** Topic lists, newline-delimited `key|Label`. */
	public const TOPICS_BUYER  = 'support_intake_topics_buyer';
	public const TOPICS_VENDOR = 'support_intake_topics_vendor';

	private SettingsRepository $repo;

	public function __construct( ?SettingsRepository $repo = null ) {
		$this->repo = $repo ?? new SettingsRepository();
	}

	/**
	 * Shipped defaults. Kept in one place so the admin screen can show them as
	 * placeholders and a blank field can mean "use the default" rather than
	 * "show nothing".
	 *
	 * @return array<string, string>
	 */
	public function defaults(): array {
		return array(
			self::TITLE               => __( 'How can we help?', 'zymarg-communication' ),
			self::TOPIC_LABEL         => __( 'What is this about?', 'zymarg-communication' ),
			self::ORDER_LABEL         => __( 'Is it about a recent order?', 'zymarg-communication' ),
			self::SUBJECT_LABEL       => __( 'Tell us in one line', 'zymarg-communication' ),
			self::SUBJECT_PLACEHOLDER => __( 'e.g. Wrong size delivered', 'zymarg-communication' ),
			self::AVAILABILITY        => '',
			self::START_BUTTON        => __( 'Start chat', 'zymarg-communication' ),
			self::CANCEL_BUTTON       => __( 'Cancel', 'zymarg-communication' ),
		);
	}

	/** Default topic lines for buyers, in editable `key|Label` form. */
	public function defaultBuyerTopics(): string {
		return implode(
			"\n",
			array(
				'order|' . __( 'An order', 'zymarg-communication' ),
				'refund|' . __( 'Refund', 'zymarg-communication' ),
				'delivery|' . __( 'Delivery', 'zymarg-communication' ),
				'product|' . __( 'A product', 'zymarg-communication' ),
				'payment|' . __( 'Payment', 'zymarg-communication' ),
				'account|' . __( 'My account', 'zymarg-communication' ),
				'other|' . __( 'Something else', 'zymarg-communication' ),
			)
		);
	}

	/** Default topic lines for vendors. */
	public function defaultVendorTopics(): string {
		return implode(
			"\n",
			array(
				'payouts|' . __( 'Payouts', 'zymarg-communication' ),
				'orders|' . __( 'Orders', 'zymarg-communication' ),
				'listings|' . __( 'Product listings', 'zymarg-communication' ),
				'verification|' . __( 'Verification', 'zymarg-communication' ),
				'account|' . __( 'Account', 'zymarg-communication' ),
				'other|' . __( 'Something else', 'zymarg-communication' ),
			)
		);
	}

	/** Is the intake card shown at all? Ships ON. */
	public function enabled(): bool {
		return '0' !== (string) $this->repo->get( self::ENABLED, '1' );
	}

	public function setEnabled( bool $on ): void {
		$this->repo->set( self::ENABLED, $on ? '1' : '0' );
	}

	/**
	 * A single copy value, falling back to the shipped default when blank.
	 */
	public function text( string $key ): string {
		$defaults = $this->defaults();
		$stored   = trim( (string) $this->repo->get( $key, '' ) );

		if ( '' !== $stored ) {
			return $stored;
		}

		return (string) ( $defaults[ $key ] ?? '' );
	}

	/** The raw stored value, unfilled. Used by the admin form. */
	public function raw( string $key, string $fallback = '' ): string {
		return (string) $this->repo->get( $key, $fallback );
	}

	/**
	 * Persist copy. Blank is stored as blank on purpose: it means "revert to the
	 * shipped default", which is how the owner undoes a customisation.
	 *
	 * @param array<string, string> $values
	 */
	public function saveText( array $values ): void {
		$allowed = array_keys( $this->defaults() );
		foreach ( $values as $key => $value ) {
			if ( ! in_array( $key, $allowed, true ) ) {
				continue;
			}
			$this->repo->set( $key, sanitize_text_field( (string) $value ) );
		}
	}

	/**
	 * Parse `key|Label` lines into chips.
	 *
	 * Tolerant by design — a human is editing this in a textarea. Blank lines
	 * are skipped, a missing key is derived from the label, duplicate keys keep
	 * the first occurrence, and a line with no usable label is dropped.
	 *
	 * @return array<int, array{key:string,label:string}>
	 */
	public function parseTopics( string $raw ): array {
		$out  = array();
		$seen = array();

		foreach ( preg_split( '/\r\n|\r|\n/', $raw ) as $line ) {
			$line = trim( (string) $line );
			if ( '' === $line ) {
				continue;
			}

			$key   = '';
			$label = $line;
			if ( false !== strpos( $line, '|' ) ) {
				$parts = explode( '|', $line, 2 );
				$key   = trim( $parts[0] );
				$label = trim( $parts[1] );
			}

			if ( '' === $label ) {
				continue;
			}
			if ( '' === $key ) {
				$key = sanitize_key( $label );
			} else {
				$key = sanitize_key( $key );
			}
			if ( '' === $key || isset( $seen[ $key ] ) ) {
				continue;
			}

			$seen[ $key ] = true;
			$out[]        = array(
				'key'   => substr( $key, 0, 40 ),
				'label' => $label,
			);
		}

		return $out;
	}

	/**
	 * Topic chips for a side ('buyer' | 'vendor'), settings first, defaults when
	 * unset or unparseable.
	 *
	 * @return array<int, array{key:string,label:string}>
	 */
	public function topics( string $side = 'buyer' ): array {
		$is_vendor = 'vendor' === $side;
		$key       = $is_vendor ? self::TOPICS_VENDOR : self::TOPICS_BUYER;
		$stored    = trim( (string) $this->repo->get( $key, '' ) );

		if ( '' !== $stored ) {
			$parsed = $this->parseTopics( $stored );
			if ( ! empty( $parsed ) ) {
				return $parsed;
			}
			// Stored but unparseable (e.g. only blank lines) — do not hand the
			// customer an empty chip row; fall through to the defaults.
		}

		return $this->parseTopics( $is_vendor ? $this->defaultVendorTopics() : $this->defaultBuyerTopics() );
	}

	/** Save a topic list verbatim so the owner's formatting survives a round-trip. */
	public function saveTopics( string $side, string $raw ): void {
		$key = 'vendor' === $side ? self::TOPICS_VENDOR : self::TOPICS_BUYER;
		// textarea content: keep newlines, strip tags, cap length.
		$clean = wp_strip_all_tags( (string) $raw );
		$this->repo->set( $key, mb_substr( $clean, 0, 4000 ) );
	}

	/**
	 * All copy resolved for the front end, ready to merge into the JS i18n map.
	 *
	 * @return array<string, string>
	 */
	public function frontendStrings(): array {
		return array(
			'intakeTitle'        => $this->text( self::TITLE ),
			'whatAbout'          => $this->text( self::TOPIC_LABEL ),
			'whichOrder'         => $this->text( self::ORDER_LABEL ),
			'tellUs'             => $this->text( self::SUBJECT_LABEL ),
			'subjectPlaceholder' => $this->text( self::SUBJECT_PLACEHOLDER ),
			'startChat'          => $this->text( self::START_BUTTON ),
			'cancel'             => $this->text( self::CANCEL_BUTTON ),
		);
	}

	/** Owner-supplied availability line, or '' to let the service compute one. */
	/** Is the reply-time line shown at all? Defaults to yes. */
	public function showAvailability(): bool {
		return '0' !== (string) $this->repo->get( self::SHOW_AVAILABILITY, '1' );
	}

	public function setShowAvailability( bool $on ): void {
		$this->repo->set( self::SHOW_AVAILABILITY, $on ? '1' : '0' );
	}

	public function availabilityOverride(): string {
		return trim( (string) $this->repo->get( self::AVAILABILITY, '' ) );
	}
}
