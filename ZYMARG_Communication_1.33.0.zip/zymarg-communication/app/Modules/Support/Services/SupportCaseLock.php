<?php
/**
 * ZYMARG Communication — support case ownership lock.
 *
 * PROBLEM
 * On a busy marketplace two agents can open the same case and both answer it.
 * The customer gets two replies, often contradicting each other, and neither
 * agent knows the other was there.
 *
 * DESIGN — the lock IS `zc_support_tickets.agent_id`
 * There is deliberately NO `locked_by` column. Ownership is already recorded
 * today: SupportTicketRepository::recordAgentReply() fills `agent_id` for the
 * first agent to reply and never overwrites it. This service adds no new data;
 * it only starts ENFORCING the ownership that the plugin has always tracked.
 *
 * That single decision is what stops cases being stranded. A parallel lock
 * field is the thing that drifts out of sync with reality — if the lock IS the
 * owner, then anything that reassigns the owner (escalation sweep, take-over,
 * manual edit) releases the lock automatically and for free.
 *
 * SAFETY — this guard can DENY a reply, so it is built to fail open
 *   1. The lock is `agent_id`; no second source of truth to get stuck.
 *   2. Fail-open: it blocks ONLY when it can positively confirm a different,
 *      still-valid owner. Missing row, un-migrated table, any exception at all
 *      -> the reply goes through.
 *   3. Liveness at read time: the owner must still exist AND still hold the
 *      agent capability. A deleted account or a revoked capability releases the
 *      case instantly — no cron, no admin action.
 *   4. Administrators are never blocked (`manage_options`), matching the
 *      existing ConversationService::assertMemberOrAdmin() philosophy.
 *   5. takeOver() reassigns ownership for the human cases — on leave, off sick,
 *      simply forgot.
 *
 * The result is a SOFT lock: it prevents two agents colliding, but it can never
 * prevent a case being answered.
 *
 * @package    ZymargCommunication
 * @version    1.33.0
 * @since      1.33.0
 * @author     ZYMARG Team
 */

namespace ZymargCommunication\Modules\Support\Services;

use ZymargCommunication\Modules\Support\Repositories\SupportTicketRepository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class SupportCaseLock {

	/**
	 * Master switch. Filter to false to disable enforcement entirely while
	 * leaving every read model (badges, "owned by" labels) working.
	 */
	public const FILTER_ENABLED = 'zymarg_comm_support_case_lock_enabled';

	private ?SupportTicketRepository $tickets;
	private ?SupportService $support;

	public function __construct(
		?SupportTicketRepository $tickets = null,
		?SupportService $support = null
	) {
		$this->tickets = $tickets;
		$this->support = $support;
	}

	/* =====================================================================
	 * Core resolution
	 * ===================================================================== */

	/**
	 * Is the lock switched on for this site?
	 *
	 * Defaults to true, but an owner who decides the lock is more trouble than
	 * the collisions can turn it off without reverting the release.
	 */
	public function enabled(): bool {
		/** Filter whether case-ownership enforcement is active. @since 1.33.0 */
		return (bool) apply_filters( self::FILTER_ENABLED, true );
	}

	/**
	 * The LIVE owner of a case, or 0 when the case is effectively unowned.
	 *
	 * "Live" is the whole point, and it is why this does not reuse
	 * SupportIdentitySettings::ownerId() — that one checks only that the account
	 * still exists. A lock must ALSO drop when you revoke someone's agent
	 * capability, otherwise a former agent keeps holding cases hostage.
	 *
	 * Returns 0 (= unowned = anyone may reply) on every uncertainty:
	 *   - id out of range
	 *   - ticket table not migrated yet
	 *   - no ticket row for this conversation
	 *   - agent_id is 0 / absent
	 *   - the account has been deleted
	 *   - the account no longer holds the support agent capability
	 *   - anything throws
	 *
	 * @param int $conversation_id Support conversation id.
	 */
	public function ownerId( int $conversation_id ): int {
		if ( $conversation_id < 1 ) {
			return 0;
		}

		try {
			$tickets = $this->tickets ?? new SupportTicketRepository();
			if ( ! $tickets->tableReady() ) {
				return 0;
			}

			$row = $tickets->find( $conversation_id );
			if ( ! is_array( $row ) ) {
				return 0;
			}

			$agent_id = (int) ( $row['agent_id'] ?? 0 );
			if ( $agent_id < 1 ) {
				return 0;
			}

			return $this->isLiveAgent( $agent_id ) ? $agent_id : 0;
		} catch ( \Throwable $e ) {
			// A lock must never be the reason a case cannot be read.
			return 0;
		}
	}

	/**
	 * Safety valve 3 — is this account still a usable agent RIGHT NOW?
	 *
	 * Deleted account or revoked capability both mean "no", which is what makes
	 * the lock self-healing: it cannot outlive the account that set it, and it
	 * releases the moment anyone next opens the case.
	 *
	 * @param int $user_id Candidate owner.
	 */
	public function isLiveAgent( int $user_id ): bool {
		if ( $user_id < 1 ) {
			return false;
		}

		try {
			if ( ! get_userdata( $user_id ) ) {
				return false; // account deleted
			}

			// An administrator always counts as a usable owner even without the
			// explicit agent capability — they can always act on any case.
			if ( user_can( $user_id, 'manage_options' ) ) {
				return true;
			}

			return (bool) user_can( $user_id, SupportService::CAPABILITY );
		} catch ( \Throwable $e ) {
			return false;
		}
	}

	/* =====================================================================
	 * Enforcement
	 * ===================================================================== */

	/**
	 * Why this user may NOT reply, or '' when they may.
	 *
	 * Returning a STRING rather than throwing keeps the fail-open contract
	 * explicit at the call site: the caller throws only on a non-empty reason,
	 * so every internal error path here simply yields '' and the reply lands.
	 *
	 * Order matters — every cheap "allow" is checked before any database work:
	 *   lock off            -> allow
	 *   no sender           -> allow (not our problem to authenticate)
	 *   administrator       -> allow (valve 4)
	 *   not a support case  -> allow (buyer/vendor threads are untouched)
	 *   sender not an agent -> allow (this is the CUSTOMER writing in)
	 *   unowned case        -> allow, and the reply itself claims it
	 *   sender is the owner -> allow
	 *   otherwise           -> DENY, naming who holds it
	 *
	 * @param  int $conversation_id Support conversation id.
	 * @param  int $sender_id       Whoever is trying to reply.
	 * @return string Human-readable denial reason, or '' to allow.
	 */
	public function denialReason( int $conversation_id, int $sender_id ): string {
		try {
			if ( ! $this->enabled() ) {
				return '';
			}
			if ( $conversation_id < 1 || $sender_id < 1 ) {
				return '';
			}

			// Valve 4 — administrators are never blocked. As long as one admin
			// exists, no case on the site is ever unreachable.
			if ( user_can( $sender_id, 'manage_options' ) ) {
				return '';
			}

			$support = $this->support();
			if ( null === $support ) {
				return '';
			}

			// Only support cases have owners. Marketplace buyer/vendor threads
			// must be completely unaffected by this release.
			if ( ! $support->isSupportConversation( $conversation_id ) ) {
				return '';
			}

			// The customer is never locked out of their own case. This is the
			// single most important allow in the method.
			if ( ! $support->isAgent( $sender_id ) ) {
				return '';
			}

			$owner_id = $this->ownerId( $conversation_id );

			// Unowned (or owner is gone / no longer an agent) — replying claims it.
			if ( $owner_id < 1 || $owner_id === $sender_id ) {
				return '';
			}

			return sprintf(
				/* translators: %s: the colleague who owns this case. */
				__( '%s is already handling this case. Ask them to hand it over, or use Take over if they are unavailable.', 'zymarg-communication' ),
				$this->agentLabel( $owner_id )
			);
		} catch ( \Throwable $e ) {
			// Valve 2 — fail open. A broken guard must never block support.
			return '';
		}
	}

	/** Convenience boolean wrapper around denialReason(). */
	public function canReply( int $conversation_id, int $sender_id ): bool {
		return '' === $this->denialReason( $conversation_id, $sender_id );
	}

	/* =====================================================================
	 * Take over (valve 5)
	 * ===================================================================== */

	/**
	 * Hand a case to a new owner.
	 *
	 * Because the lock IS `agent_id`, this single write releases the old lock
	 * and establishes the new one atomically — there is no second field that
	 * could be left behind.
	 *
	 * Permitted for administrators, and for any support agent (a teammate on
	 * shift must be able to rescue a case without hunting down an admin). The
	 * action is hooked so an audit trail can be attached.
	 *
	 * @param int $conversation_id Case to reassign.
	 * @param int $new_agent_id    Incoming owner. 0 releases the case entirely.
	 * @param int $actor_id        Who is performing the take-over.
	 */
	public function takeOver( int $conversation_id, int $new_agent_id, int $actor_id ): bool {
		if ( $conversation_id < 1 || $actor_id < 1 ) {
			return false;
		}

		$is_admin = user_can( $actor_id, 'manage_options' );
		if ( ! $is_admin && ! $this->isLiveAgent( $actor_id ) ) {
			return false;
		}

		// Releasing (0) is allowed; assigning requires a genuinely usable agent,
		// so a take-over can never park a case on a deleted account.
		if ( $new_agent_id > 0 && ! $this->isLiveAgent( $new_agent_id ) ) {
			return false;
		}

		try {
			$tickets = $this->tickets ?? new SupportTicketRepository();
			if ( ! $tickets->tableReady() ) {
				return false;
			}

			$row = $tickets->find( $conversation_id );
			if ( ! is_array( $row ) ) {
				return false;
			}

			$previous = (int) ( $row['agent_id'] ?? 0 );
			if ( $previous === $new_agent_id ) {
				return true; // already there; nothing to do.
			}

			$ok = $tickets->update( $conversation_id, array( 'agent_id' => $new_agent_id ) );
			if ( ! $ok ) {
				return false;
			}

			/**
			 * Fires when a support case changes hands.
			 *
			 * @since 1.33.0
			 * @param int $conversation_id Case id.
			 * @param int $previous_agent  Outgoing owner (0 when unowned).
			 * @param int $new_agent       Incoming owner (0 when released).
			 * @param int $actor_id        Who performed the take-over.
			 */
			do_action( 'zymarg_comm_support_case_taken_over', $conversation_id, $previous, $new_agent_id, $actor_id );

			return true;
		} catch ( \Throwable $e ) {
			return false;
		}
	}

	/* =====================================================================
	 * Read model for the UI
	 * ===================================================================== */

	/**
	 * Everything the agent queue needs to render ownership in one call.
	 *
	 * @param  int $conversation_id Case id.
	 * @param  int $viewer_id       Agent looking at the queue.
	 * @return array{owner_id:int,owner_name:string,is_mine:bool,is_locked:bool,can_reply:bool,can_take_over:bool}
	 */
	public function descriptor( int $conversation_id, int $viewer_id ): array {
		$owner_id = $this->ownerId( $conversation_id );
		$is_mine  = $owner_id > 0 && $owner_id === $viewer_id;

		return array(
			'owner_id'      => $owner_id,
			'owner_name'    => $owner_id > 0 ? $this->agentLabel( $owner_id ) : '',
			'is_mine'       => $is_mine,
			'is_locked'     => $owner_id > 0 && ! $is_mine,
			'can_reply'     => $this->canReply( $conversation_id, $viewer_id ),
			'can_take_over' => $owner_id > 0 && ! $is_mine,
		);
	}

	/* =====================================================================
	 * Internals
	 * ===================================================================== */

	/**
	 * A colleague's REAL name.
	 *
	 * This is an agent-only surface — the customer-facing persona lives in
	 * SupportIdentitySettings and is deliberately not used here: an agent being
	 * told who holds a case needs the actual person, not "Alpha".
	 */
	private function agentLabel( int $user_id ): string {
		$user = $user_id > 0 ? get_userdata( $user_id ) : null;
		if ( ! $user ) {
			return __( 'Another agent', 'zymarg-communication' );
		}

		$name = trim( (string) ( $user->display_name ?? '' ) );

		return '' !== $name ? $name : __( 'Another agent', 'zymarg-communication' );
	}

	/**
	 * SupportService, resolved lazily so this class can be constructed with no
	 * arguments from anywhere without dragging in the whole Support container.
	 */
	private function support(): ?SupportService {
		if ( $this->support instanceof SupportService ) {
			return $this->support;
		}

		try {
			if ( ! \ZymargCommunication\Bootstrap\ServiceProvider::has( SupportService::class ) ) {
				return null;
			}
			$resolved = \ZymargCommunication\Bootstrap\ServiceProvider::get( SupportService::class );
		} catch ( \Throwable $e ) {
			return null;
		}

		if ( $resolved instanceof SupportService ) {
			$this->support = $resolved;

			return $resolved;
		}

		return null;
	}
}
