<?php
/**
 * SupportTicketService — the operational brain of a support thread.
 *
 * The conversation engine moves MESSAGES. This moves the TICKET: who it is
 * waiting on, whether it is solved, what it is about, who is asking, and what
 * happens when nobody replies. It is deliberately a separate service from
 * SupportService (which owns "open or resume a thread") so the transport and
 * the workflow can evolve independently.
 *
 * Status is driven by REAL message events, not by anyone remembering to click
 * a button:
 *   - customer sends  -> AwaitingAgent  (and reopens a Resolved ticket)
 *   - agent sends     -> AwaitingUser   (and stamps first-response time once)
 * Agents additionally get explicit Resolve / Reopen / Close actions.
 *
 * @package ZymargCommunication
 * @since   1.27.0
 */

namespace ZymargCommunication\Modules\Support\Services;

use ZymargCommunication\Core\Abstracts\AbstractService;
use ZymargCommunication\Modules\Support\Repositories\SupportRepository;
use ZymargCommunication\Modules\Support\Repositories\SupportTicketRepository;
use ZymargCommunication\Shared\Enums\TicketStatus;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class SupportTicketService extends AbstractService {

	/** Hours a ticket may sit unanswered before it escalates. Filterable. */
	private const DEFAULT_ESCALATE_HOURS = 2;

	public function __construct(
		private SupportTicketRepository $tickets,
		private SupportRepository $support,
		private SupportService $service
	) {}

	/* =====================================================================
	 * Wiring
	 * ===================================================================== */

	/**
	 * Listen to the message bus and the thread-created hook. Registered from
	 * SupportHooks so all support wiring lives in one place.
	 */
	public function registerListeners(): void {
		// Every stored message flows through this action (see EventDispatcher).
		add_action( 'zymarg_comm_event_message_sent', array( $this, 'onMessageSent' ), 10, 1 );

		// A brand-new support thread: seed its ticket row immediately so the
		// agent queue shows it even before the first reply.
		add_action( 'zymarg_comm_support_started', array( $this, 'onSupportStarted' ), 10, 3 );

		// Daily-ish escalation sweep. The schedule is registered by Scheduler;
		// this is the callback.
		add_action( 'zymarg_comm_support_escalation_scan', array( $this, 'runEscalationScan' ) );

		// Helpline session janitor (1.31.0) rides the SAME hourly hook rather
		// than adding a schedule. Lazy on-read enforcement is the real mechanism;
		// this only mops up cases nobody opened, so being an hour late is fine.
		add_action( 'zymarg_comm_support_escalation_scan', array( $this, 'runSessionScan' ) );
	}

	/* =====================================================================
	 * Event handlers
	 * ===================================================================== */

	/**
	 * @param array<string, mixed> $payload
	 */
	public function onSupportStarted( int $conversation_id, int $user_id, int $agent_id ): void {
		if ( $conversation_id < 1 ) {
			return;
		}
		$this->tickets->ensure( $conversation_id, $user_id, $agent_id );
	}

	/**
	 * Drive ticket status from a stored message.
	 *
	 * @param array<string, mixed> $payload From MessageSent::payload().
	 */
	public function onMessageSent( $payload ): void {
		if ( ! is_array( $payload ) ) {
			return;
		}

		$conversation_id = (int) ( $payload['conversation_id'] ?? 0 );
		$sender_id       = (int) ( $payload['sender_id'] ?? 0 );
		if ( $conversation_id < 1 || $sender_id < 1 ) {
			return;
		}

		// Cheap gate first: only support conversations have tickets. This avoids
		// a table hit for every buyer/vendor message on the site.
		if ( ! $this->support->isSupportConversation( $conversation_id ) ) {
			return;
		}

		$row = $this->tickets->ensure( $conversation_id );
		if ( null === $row ) {
			return; // table not migrated yet — fail quiet, never fatal on send.
		}

		// Settle an expired window BEFORE classifying this message (1.31.0).
		// A reply that lands after the deadline arrives at a case that is already
		// over, and is handled by the closed-ticket path below rather than
		// silently reviving a case the customer was told had closed. Customers
		// typing in good faith are protected by touchAutoclose(), which the
		// composer calls inside the warning window.
		if ( $this->enforceAutoclose( $conversation_id, $row ) ) {
			$fresh = $this->tickets->find( $conversation_id );
			if ( is_array( $fresh ) ) {
				$row = $fresh;
			}
		}

		$requester = (int) ( $row['requester_id'] ?? 0 );
		$was        = TicketStatus::fromLoose( $row['ticket_status'] ?? null );

		// Requester's own message is always a "user reply", even in the unlikely
		// case the requester also holds the agent capability.
		$is_agent = ( $sender_id !== $requester ) && $this->service->isAgent( $sender_id );

		if ( $is_agent ) {
			$this->tickets->recordAgentReply( $conversation_id, $sender_id );
			// A fresh agent reply starts a fresh window, so any explicit deadline
			// left over from an earlier extension must go — otherwise last round's
			// "give them 10 more minutes" would still be governing this round.
			// A pause is deliberately left in place: the agent asked for it.
			$this->tickets->update( $conversation_id, array( 'autoclose_until' => null ) );
			return;
		}

		$now = $this->tickets->recordUserReply( $conversation_id );

		// The customer answered, so the clock is spent. The status flip to
		// awaiting_agent already stops it (no deadline exists off that status),
		// but clearing the explicit deadline keeps the row honest for the sweep.
		$this->tickets->update( $conversation_id, array( 'autoclose_until' => null ) );

		// A message on a CLOSED ticket cannot revive it (closed is final). The
		// customer clearly still needs help, so escalate that fact to a fresh
		// ticket rather than dropping their words into a dead thread.
		if ( TicketStatus::Closed === $was ) {
			/**
			 * Fires when a customer messages a closed support ticket.
			 *
			 * Consumers (e.g. an auto-responder, or a future "reopen as new
			 * ticket" flow) can react. The message is still stored on the old
			 * thread regardless.
			 *
			 * @since 1.27.0
			 */
			do_action( 'zymarg_comm_support_closed_ticket_pinged', $conversation_id, $requester );
		}

		unset( $now );
	}

	/* =====================================================================
	 * Agent actions
	 * ===================================================================== */

	/** Mark solved. Fires the resolved hook exactly once per transition. */
	public function resolve( int $conversation_id, int $agent_id ): bool {
		$row = $this->tickets->ensure( $conversation_id );
		if ( null === $row ) {
			return false;
		}
		if ( TicketStatus::Resolved === TicketStatus::fromLoose( $row['ticket_status'] ?? null ) ) {
			return true; // already there; idempotent.
		}

		$ok = $this->tickets->setStatus( $conversation_id, TicketStatus::Resolved, $agent_id );
		if ( $ok ) {
			/**
			 * Fires when a support ticket is marked resolved.
			 *
			 * @since 1.27.0
			 * @param int $conversation_id Ticket/conversation id.
			 * @param int $agent_id        Agent who resolved it.
			 * @param int $requester_id    Customer.
			 */
			do_action(
				'zymarg_comm_support_resolved',
				$conversation_id,
				$agent_id,
				(int) ( $row['requester_id'] ?? 0 )
			);
		}

		return $ok;
	}

	/** Close for good. Distinct from resolve: closed does not reopen. */
	public function close( int $conversation_id, int $agent_id ): bool {
		$ok = $this->tickets->setStatus( $conversation_id, TicketStatus::Closed, $agent_id );
		if ( $ok ) {
			/** @since 1.27.0 */
			do_action( 'zymarg_comm_support_closed', $conversation_id, $agent_id );
		}

		return $ok;
	}

	/** Reopen a settled ticket by hand (agent decides it was premature). */
	public function reopen( int $conversation_id, int $agent_id ): bool {
		$ok = $this->tickets->setStatus( $conversation_id, TicketStatus::AwaitingAgent, $agent_id );
		if ( $ok ) {
			/** @since 1.27.0 */
			do_action( 'zymarg_comm_support_reopened', $conversation_id, $agent_id );
		}

		return $ok;
	}

	/** Attach an order / vendor / topic to the ticket (Smart Intake, agent edit). */
	public function setContext( int $conversation_id, array $context ): bool {
		$fields = array();
		if ( isset( $context['topic'] ) ) {
			$fields['topic'] = substr( sanitize_text_field( (string) $context['topic'] ), 0, 40 );
		}
		if ( isset( $context['subject'] ) ) {
			$fields['subject'] = substr( sanitize_text_field( (string) $context['subject'] ), 0, 200 );
		}
		if ( isset( $context['order_id'] ) ) {
			$fields['order_id'] = max( 0, (int) $context['order_id'] );
		}
		if ( isset( $context['vendor_id'] ) ) {
			$fields['vendor_id'] = max( 0, (int) $context['vendor_id'] );
		}
		if ( empty( $fields ) ) {
			return false;
		}

		$this->tickets->ensure( $conversation_id );

		return $this->tickets->update( $conversation_id, $fields );
	}

	/** Customer satisfaction rating for a resolved ticket. */
	public function rate( int $conversation_id, int $rating, string $comment = '' ): bool {
		$ok = $this->tickets->setRating( $conversation_id, $rating, $comment );
		if ( $ok ) {
			/** @since 1.27.0 */
			do_action( 'zymarg_comm_support_rated', $conversation_id, max( 1, min( 5, $rating ) ) );
		}

		return $ok;
	}

	/* =====================================================================
	 * Helpline session — auto-close (1.31.0)
	 *
	 * A support case is a helpline call. When the agent has replied and the
	 * customer goes quiet, the case closes itself after an admin-configured
	 * wait, so the customer's single live case never sits half-finished
	 * forever and their next contact starts clean.
	 *
	 * Enforcement is LAZY, on read, and that is a deliberate architectural
	 * choice rather than a shortcut. WP-Cron's shortest schedule here is
	 * hourly and it only fires when somebody visits the site, so a 3-minute
	 * deadline could be honoured up to 57 minutes late — or never, on a quiet
	 * site. Deriving the deadline arithmetically and settling it the moment
	 * anybody looks at the ticket makes correctness independent of cron. The
	 * hourly sweep is then only a janitor for cases nobody opened.
	 * ===================================================================== */

	/** Lazily built so a settings failure can never break ticket reads. */
	private ?SupportSessionSettings $session = null;

	private function session(): SupportSessionSettings {
		if ( null === $this->session ) {
			$this->session = new SupportSessionSettings();
		}

		return $this->session;
	}

	/**
	 * When does this case lapse? NULL when no clock is running.
	 *
	 * A clock runs only when the feature is on, the case is AWAITING_USER (the
	 * agent wrote last), it is not paused, and an agent reply has actually been
	 * recorded. Anything waiting on the TEAM never has a deadline — closing
	 * those would blame the customer for the team's backlog.
	 *
	 * @param array<string, mixed> $row Ticket row.
	 */
	private function autocloseDeadline( array $row ): ?int {
		if ( ! $this->session()->enabled() ) {
			return null;
		}

		$status = TicketStatus::fromLoose( $row['ticket_status'] ?? null );
		if ( TicketStatus::AwaitingUser !== $status ) {
			return null;
		}

		if ( ! empty( $row['autoclose_paused'] ) ) {
			return null;
		}

		// An explicit deadline wins: an agent granted extra time, or the customer
		// was still typing when the clock ran down.
		$until = (string) ( $row['autoclose_until'] ?? '' );
		if ( '' !== $until && '0000-00-00 00:00:00' !== $until ) {
			$ts = strtotime( $until );
			return false === $ts ? null : $ts;
		}

		$last = (string) ( $row['last_agent_reply_at'] ?? '' );
		if ( '' === $last || '0000-00-00 00:00:00' === $last ) {
			return null; // No agent reply recorded, so nothing has started.
		}

		$ts = strtotime( $last );
		if ( false === $ts ) {
			return null;
		}

		return $ts + $this->session()->seconds();
	}

	/**
	 * The countdown, for the panel on both sides.
	 *
	 * Sent once per ticket read and counted down locally by the browser, so the
	 * live timer costs no extra requests — which matters, because the alternative
	 * is a per-second poll.
	 *
	 * @param  array<string, mixed>|null $row
	 * @return array<string, mixed>
	 */
	public function autocloseDescriptor( int $conversation_id, ?array $row = null ): array {
		$row = $row ?? $this->tickets->find( $conversation_id );
		$off = array(
			'active'            => false,
			'paused'            => false,
			'minutes'           => $this->session()->minutes(),
			'warn_seconds'      => $this->session()->warnSeconds(),
			'expires_at'        => null,
			'seconds_remaining' => null,
			'closed_reason'     => is_array( $row ) ? (string) ( $row['closed_reason'] ?? '' ) : '',
		);

		if ( ! is_array( $row ) ) {
			return $off;
		}

		// Paused is reported even though no clock runs, so the customer can be
		// told why the countdown they saw a moment ago has stopped.
		if ( ! empty( $row['autoclose_paused'] ) ) {
			$off['paused'] = true;
			return $off;
		}

		$deadline = $this->autocloseDeadline( $row );
		if ( null === $deadline ) {
			return $off;
		}

		$now = strtotime( current_time( 'mysql' ) );

		return array(
			'active'            => true,
			'paused'            => false,
			'minutes'           => $this->session()->minutes(),
			'warn_seconds'      => $this->session()->warnSeconds(),
			'expires_at'        => gmdate( 'c', $deadline ),
			'seconds_remaining' => max( 0, $deadline - $now ),
			'closed_reason'     => (string) ( $row['closed_reason'] ?? '' ),
		);
	}

	/**
	 * Settle a case whose window has already passed. Returns true if it closed.
	 *
	 * Called from every ticket read and from the message-send path, which is what
	 * makes the deadline authoritative without cron.
	 */
	public function enforceAutoclose( int $conversation_id, ?array $row = null ): bool {
		$row = $row ?? $this->tickets->find( $conversation_id );
		if ( ! is_array( $row ) ) {
			return false;
		}

		$deadline = $this->autocloseDeadline( $row );
		if ( null === $deadline ) {
			return false;
		}

		if ( strtotime( current_time( 'mysql' ) ) < $deadline ) {
			return false; // Still time on the clock.
		}

		return $this->timeout( $conversation_id, $row );
	}

	/**
	 * Apply the timeout to one case.
	 *
	 * `closed` is terminal here, so the customer's next contact opens a fresh
	 * case — the helpline behaviour. `closed_reason` records that a timer did
	 * this and not a person, so resolution metrics do not count a lapse as a
	 * success.
	 *
	 * @param array<string, mixed> $row
	 */
	private function timeout( int $conversation_id, array $row ): bool {
		$mode   = $this->session()->onTimeout();
		$status = 'resolved' === $mode ? TicketStatus::Resolved : TicketStatus::Closed;

		// actor 0 = nobody; the reason column is what distinguishes this from an
		// agent action, since resolved_by would otherwise read as "unknown agent".
		$ok = $this->tickets->setStatus( $conversation_id, $status, 0 );
		if ( ! $ok ) {
			return false;
		}

		$this->tickets->update(
			$conversation_id,
			array(
				'closed_reason'    => 'auto_timeout',
				'autoclose_until'  => null,
				'autoclose_paused' => 0,
			)
		);

		/**
		 * Fires when a helpline case closes itself for want of a customer reply.
		 *
		 * Deliberately NOT a thread message: `zc_messages` has no system-message
		 * kind, and onMessageSent() would read any inserted message as a reply and
		 * flip the case straight back to awaiting_agent — reopening the very case
		 * it just closed. Consumers wanting to notify should use this hook.
		 *
		 * @since 1.31.0
		 * @param int    $conversation_id Case id.
		 * @param int    $requester_id    Customer.
		 * @param int    $minutes         Wait that elapsed.
		 * @param string $mode            closed | resolved.
		 */
		do_action(
			'zymarg_comm_support_session_timeout',
			$conversation_id,
			(int) ( $row['requester_id'] ?? 0 ),
			$this->session()->minutes(),
			$mode
		);

		return true;
	}

	/** Hold the clock for a case where the customer genuinely needs longer. */
	public function pauseAutoclose( int $conversation_id, int $agent_id ): bool {
		$ok = $this->tickets->update(
			$conversation_id,
			array(
				'autoclose_paused' => 1,
				'autoclose_until'  => null,
			)
		);
		if ( $ok ) {
			/** @since 1.31.0 */
			do_action( 'zymarg_comm_support_session_paused', $conversation_id, $agent_id );
		}

		return $ok;
	}

	/**
	 * Restart the clock, giving a full fresh window rather than resuming a
	 * window that expired while the case was held.
	 */
	public function resumeAutoclose( int $conversation_id, int $agent_id ): bool {
		$ok = $this->tickets->update(
			$conversation_id,
			array(
				'autoclose_paused' => 0,
				'autoclose_until'  => gmdate( 'Y-m-d H:i:s', strtotime( current_time( 'mysql' ) ) + $this->session()->seconds() ),
			)
		);
		if ( $ok ) {
			/** @since 1.31.0 */
			do_action( 'zymarg_comm_support_session_resumed', $conversation_id, $agent_id );
		}

		return $ok;
	}

	/**
	 * Push the deadline out. Measured from NOW, not from the old deadline, so
	 * "give them 10 more minutes" means ten minutes from the moment it is
	 * granted even if the case had already lapsed.
	 */
	public function extendAutoclose( int $conversation_id, int $minutes, int $agent_id = 0 ): bool {
		$minutes = max( 1, min( SupportSessionSettings::MAX_MINUTES, $minutes ) );

		$ok = $this->tickets->update(
			$conversation_id,
			array(
				'autoclose_paused' => 0,
				'autoclose_until'  => gmdate( 'Y-m-d H:i:s', strtotime( current_time( 'mysql' ) ) + ( $minutes * 60 ) ),
			)
		);
		if ( $ok ) {
			/** @since 1.31.0 */
			do_action( 'zymarg_comm_support_session_extended', $conversation_id, $minutes, $agent_id );
		}

		return $ok;
	}

	/**
	 * The customer is mid-sentence at the buzzer, so give them the full window
	 * again. Called from the composer, and only inside the warning window, so it
	 * costs at most a request or two per case rather than a running poll.
	 *
	 * Silently does nothing unless a clock is actually running, which keeps it
	 * useless as a way to hold a case open indefinitely from the browser.
	 */
	public function touchAutoclose( int $conversation_id ): bool {
		$row = $this->tickets->find( $conversation_id );
		if ( ! is_array( $row ) || null === $this->autocloseDeadline( $row ) ) {
			return false;
		}

		return $this->tickets->update(
			$conversation_id,
			array(
				'autoclose_until' => gmdate( 'Y-m-d H:i:s', strtotime( current_time( 'mysql' ) ) + $this->session()->seconds() ),
			)
		);
	}

	/**
	 * Janitor sweep for cases nobody opened (1.31.0).
	 *
	 * Lazy evaluation already settles every case somebody looks at, so this only
	 * mops up cases that lapsed while both sides were away. Runs on the existing
	 * hourly support hook — no new schedule, and hourly lateness is harmless
	 * precisely because it is not the source of truth.
	 *
	 * @return int Cases closed this run.
	 */
	public function runSessionScan(): int {
		if ( ! $this->service->enabled() || ! $this->session()->enabled() ) {
			return 0;
		}

		$rows  = $this->tickets->staleAwaitingUser( $this->session()->minutes(), 50 );
		$count = 0;

		foreach ( $rows as $row ) {
			$conversation_id = (int) ( $row['conversation_id'] ?? 0 );
			if ( $conversation_id < 1 ) {
				continue;
			}
			if ( $this->timeout( $conversation_id, $row ) ) {
				$count++;
			}
		}

		return $count;
	}

	/* =====================================================================
	 * Escalation
	 * ===================================================================== */

	/**
	 * How long this case has been waiting on the TEAM.
	 *
	 * Before 1.32.15 the agent queue showed only a raw clock time taken from
	 * `updated_at`, which answers "when was this row last touched" — not "how
	 * long has this person been waiting". Worse, `updated_at` is bumped by every
	 * repository write (a status flip, an extension, an escalation), so an agent
	 * action visibly RESET the apparent wait. The anchor here is deliberately
	 * `last_user_reply_at` — the moment the customer last wrote — falling back to
	 * `created_at` for a brand-new case nobody has answered.
	 *
	 * Returns zeros for anything not waiting on us: a case awaiting the customer
	 * is not a queue problem, and resolved/closed cases are finished.
	 *
	 * Tone thresholds are derived from the escalation window that this site is
	 * already configured with (`zymarg_comm_support_escalate_hours`, default 2h)
	 * rather than inventing a second number to keep in sync:
	 *   ok   — under half the window
	 *   warn — over half
	 *   late — past the window, i.e. overdue for escalation
	 *
	 * @since  1.32.15
	 * @param  array<string,mixed> $row A `zc_support_tickets` row.
	 * @return array{seconds:int,label:string,tone:string}
	 */
	public function waitingDescriptor( array $row ): array {
		$none = array(
			'seconds' => 0,
			'label'   => '',
			'tone'    => 'ok',
		);

		$status = TicketStatus::fromLoose( $row['ticket_status'] ?? null );
		if ( TicketStatus::AwaitingAgent !== $status ) {
			return $none;
		}

		$anchor = (string) ( $row['last_user_reply_at'] ?? '' );
		if ( '' === $anchor ) {
			$anchor = (string) ( $row['created_at'] ?? '' );
		}
		if ( '' === $anchor ) {
			return $none;
		}

		// Both sides parsed in the SAME frame: every timestamp in this table is
		// written with current_time('mysql'), i.e. site-local, never UTC.
		$then = strtotime( $anchor );
		$now  = strtotime( (string) current_time( 'mysql' ) );
		if ( false === $then || false === $now || $now <= $then ) {
			return $none;
		}

		$seconds = $now - $then;
		$window  = max( 1, $this->escalateHours() * HOUR_IN_SECONDS );

		if ( $seconds >= $window ) {
			$tone = 'late';
		} elseif ( $seconds >= (int) ( $window / 2 ) ) {
			$tone = 'warn';
		} else {
			$tone = 'ok';
		}

		return array(
			'seconds' => (int) $seconds,
			'label'   => (string) human_time_diff( $then, $now ),
			'tone'    => $tone,
		);
	}

	/**
	 * Any usable agent other than the one given, or 0 when the pool has nobody
	 * else. Used to rotate an abandoned case off its unresponsive owner.
	 *
	 * Skips accounts that have been deleted, so a sweep can never park a case
	 * on an owner who is even less reachable than the current one.
	 *
	 * @since 1.33.0
	 */
	private function firstOtherAgent( int $exclude_id ): int {
		try {
			foreach ( $this->service->agentIds() as $candidate ) {
				$candidate = (int) $candidate;
				if ( $candidate > 0 && $candidate !== $exclude_id && get_userdata( $candidate ) ) {
					return $candidate;
				}
			}
		} catch ( \Throwable $e ) {
			return 0;
		}

		return 0;
	}

	private function escalateHours(): int {
		/** Filter the no-reply escalation window, in hours. @since 1.27.0 */
		$hours = (int) apply_filters( 'zymarg_comm_support_escalate_hours', self::DEFAULT_ESCALATE_HOURS );

		return max( 1, $hours );
	}

	/**
	 * Sweep for tickets waiting on an agent past the window with no reply yet,
	 * reassign to the least-loaded other agent, and fire an escalation hook that
	 * Automation / SMS / FCM can consume.
	 *
	 * @return int Number of tickets escalated this run.
	 */
	public function runEscalationScan(): int {
		if ( ! $this->service->enabled() ) {
			return 0;
		}

		$minutes = $this->escalateHours() * 60;

		// TWO distinct ways a customer gets stranded, and until 1.33.0 this sweep
		// only ever saw the first:
		//
		//   1. nobody ever answered      -> staleAwaitingAgent()        (1.27.0)
		//   2. answered, then abandoned  -> staleAwaitingAgentClaimed() (1.33.0)
		//
		// (2) was invisible because staleAwaitingAgent() filters
		// `last_agent_reply_at IS NULL`, and replying stamps that column. So one
		// reply from an agent who then quits, falls ill, or loses their account
		// removed the case from the only automatic rescue that exists — forever.
		// Auto-close could not save it either: that fires only on awaiting_user.
		$stale = $this->tickets->staleAwaitingAgentClaimed( $minutes, 25 );

		// Never-answered cases are the more urgent of the two, so they are
		// prepended and processed first when the batch is trimmed.
		$seen = array();
		foreach ( $stale as $row ) {
			$cid = (int) ( $row['conversation_id'] ?? 0 );
			if ( $cid > 0 ) {
				$seen[ $cid ] = true;
			}
		}

		$unanswered = array();
		foreach ( $this->tickets->staleAwaitingAgent( $minutes, 25 ) as $row ) {
			$cid = (int) ( $row['conversation_id'] ?? 0 );
			if ( $cid > 0 && ! isset( $seen[ $cid ] ) ) {
				$seen[ $cid ]  = true;
				$unanswered[]  = $row;
			}
		}

		$stale = array_merge( $unanswered, $stale );
		$count = 0;

		foreach ( $stale as $row ) {
			$conversation_id = (int) ( $row['conversation_id'] ?? 0 );
			$requester       = (int) ( $row['requester_id'] ?? 0 );
			$current_agent   = (int) ( $row['agent_id'] ?? 0 );
			if ( $conversation_id < 1 ) {
				continue;
			}

			$next_agent = $this->service->resolveAgent( $requester );

			// An ABANDONED case (1.33.0) must rotate AWAY from its current owner:
			// that owner is precisely the person who stopped responding, so the
			// least-loaded calculation handing it back to them would re-strand the
			// customer for another full window. A never-answered case has no such
			// constraint. Falls through unchanged when the pool has nobody else.
			if ( $current_agent > 0 && $next_agent === $current_agent && ! empty( $row['last_agent_reply_at'] ) ) {
				$alternative = $this->firstOtherAgent( $current_agent );
				if ( $alternative > 0 ) {
					$next_agent = $alternative;
				}
			}

			// If the pool has an alternative, rotate to it; otherwise re-alert
			// the same agent (better a nudge than silence).
			$this->tickets->update(
				$conversation_id,
				array(
					'agent_id'         => $next_agent > 0 ? $next_agent : $current_agent,
					'escalated_at'     => current_time( 'mysql' ),
					'escalation_count' => (int) ( $row['escalation_count'] ?? 0 ) + 1,
				)
			);

			/**
			 * Fires when a support ticket escalates for want of a reply.
			 *
			 * @since 1.27.0
			 * @param int $conversation_id Ticket id.
			 * @param int $requester_id    Customer.
			 * @param int $from_agent_id   Previously assigned agent.
			 * @param int $to_agent_id     Newly assigned agent (may equal from).
			 */
			do_action(
				'zymarg_comm_support_escalated',
				$conversation_id,
				$requester,
				$current_agent,
				$next_agent > 0 ? $next_agent : $current_agent
			);

			$count++;
		}

		return $count;
	}

	/* =====================================================================
	 * Read models for the UI
	 * ===================================================================== */

	/**
	 * The requester identity card: who is asking, and are they a buyer or a
	 * seller. Answers "how does admin know who needs help".
	 *
	 * @return array<string, mixed>
	 */
	public function requesterCard( int $requester_id ): array {
		$user = $requester_id > 0 ? get_userdata( $requester_id ) : null;
		if ( ! $user ) {
			return array(
				'id'    => 0,
				'name'  => __( 'Unknown user', 'zymarg-communication' ),
				'role'  => 'guest',
			);
		}

		$is_vendor = $this->looksLikeVendor( $requester_id );

		$order_count = 0;
		$spend       = 0.0;
		if ( function_exists( 'wc_get_orders' ) && ! $is_vendor ) {
			$orders = wc_get_orders(
				array(
					'customer_id' => $requester_id,
					'limit'       => 100,
					'return'      => 'objects',
					'status'      => array( 'wc-completed', 'wc-processing', 'wc-on-hold' ),
				)
			);
			$order_count = is_array( $orders ) ? count( $orders ) : 0;
			foreach ( (array) $orders as $order ) {
				if ( is_object( $order ) && method_exists( $order, 'get_total' ) ) {
					$spend += (float) $order->get_total();
				}
			}
		}

		return array(
			'id'           => $requester_id,
			'name'         => (string) $user->display_name,
			'email'        => (string) $user->user_email,
			'avatar'       => get_avatar_url( $requester_id, array( 'size' => 96 ) ),
			'role'         => $is_vendor ? 'vendor' : 'customer',
			'role_label'   => $is_vendor ? __( 'Vendor', 'zymarg-communication' ) : __( 'Customer', 'zymarg-communication' ),
			'member_since' => mysql2date( 'M Y', (string) $user->user_registered ),
			'order_count'  => $order_count,
			'lifetime_spend' => $spend,
			'open_tickets' => $this->openTicketCountForUser( $requester_id ),
		);
	}

	/**
	 * Order / vendor context card for a ticket, when one is attached.
	 *
	 * @return array<string, mixed>|null
	 */
	public function contextCard( int $conversation_id ): ?array {
		$row = $this->tickets->find( $conversation_id );
		if ( null === $row ) {
			return null;
		}

		$order_id  = (int) ( $row['order_id'] ?? 0 );
		$vendor_id = (int) ( $row['vendor_id'] ?? 0 );
		if ( $order_id < 1 && $vendor_id < 1 && '' === (string) ( $row['topic'] ?? '' ) ) {
			return null;
		}

		$card = array(
			'topic'   => (string) ( $row['topic'] ?? '' ),
			'subject' => (string) ( $row['subject'] ?? '' ),
			'order'   => null,
			'vendor'  => null,
		);

		if ( $order_id > 0 && function_exists( 'wc_get_order' ) ) {
			$order = wc_get_order( $order_id );
			if ( $order ) {
				$card['order'] = array(
					'id'        => $order_id,
					'number'    => $order->get_order_number(),
					'total'     => (float) $order->get_total(),
					'currency'  => $order->get_currency(),
					'status'    => $order->get_status(),
					'date'      => $order->get_date_created() ? $order->get_date_created()->date( 'M j, Y' ) : '',
					'admin_url' => admin_url( 'post.php?post=' . $order_id . '&action=edit' ),
				);
			}
		}

		if ( $vendor_id > 0 ) {
			$vendor = get_userdata( $vendor_id );
			if ( $vendor ) {
				$card['vendor'] = array(
					'id'   => $vendor_id,
					'name' => (string) $vendor->display_name,
				);
			}
		}

		return $card;
	}

	/**
	 * Prior tickets for a user, shaped for the agent history panel.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function historyCards( int $requester_id, int $exclude_conversation = 0 ): array {
		$rows = $this->tickets->historyForUser( $requester_id, 10, $exclude_conversation );
		$out  = array();

		foreach ( $rows as $row ) {
			$status    = TicketStatus::fromLoose( $row['ticket_status'] ?? null );
			$out[]     = array(
				'conversation_id' => (int) ( $row['conversation_id'] ?? 0 ),
				'status'          => $status->value,
				'status_label'    => $status->agentLabel(),
				'tone'            => $status->tone(),
				'topic'           => (string) ( $row['topic'] ?? '' ),
				'subject'         => (string) ( $row['subject'] ?? '' ),
				'resolved_at'     => (string) ( $row['resolved_at'] ?? '' ),
				'updated_at'      => (string) ( $row['updated_at'] ?? '' ),
				'rating'          => (int) ( $row['rating'] ?? 0 ),
			);
		}

		return $out;
	}

	/**
	 * Full status descriptor for a ticket, for the pill on both sides.
	 *
	 * @return array<string, mixed>
	 */
	public function statusDescriptor( int $conversation_id, bool $for_agent = false ): array {
		// Reading a ticket is the moment the deadline becomes authoritative
		// (1.31.0). This is what frees the feature from cron: whoever looks
		// first settles it, and the answer they get is already correct.
		$this->enforceAutoclose( $conversation_id );

		$row    = $this->tickets->find( $conversation_id );
		$status = TicketStatus::fromLoose( is_array( $row ) ? ( $row['ticket_status'] ?? null ) : null );

		return array(
			'status'    => $status->value,
			'label'     => $for_agent ? $status->agentLabel() : $status->label(),
			'tone'      => $status->tone(),
			'open'      => $status->isOpen(),
			'autoclose' => $this->autocloseDescriptor( $conversation_id, is_array( $row ) ? $row : null ),
		);
	}

	public function openTicketCountForUser( int $user_id ): int {
		return null === $this->tickets->findOpenForUser( $user_id ) ? 0 : 1;
	}

	/* =====================================================================
	 * Helpers
	 * ===================================================================== */

	/**
	 * Best-effort "is this user a vendor" without hard-coupling to any one
	 * vendor plugin. Checks common roles and a Dokan helper if present.
	 */
	private function looksLikeVendor( int $user_id ): bool {
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return false;
		}

		$vendor_roles = array( 'seller', 'vendor', 'dc_vendor', 'wcfm_vendor', 'shop_manager' );
		foreach ( (array) $user->roles as $role ) {
			if ( in_array( $role, $vendor_roles, true ) ) {
				return true;
			}
		}

		if ( function_exists( 'dokan_is_user_seller' ) ) {
			return (bool) dokan_is_user_seller( $user_id );
		}

		/** Filter whether a support requester is treated as a vendor. @since 1.27.0 */
		return (bool) apply_filters( 'zymarg_comm_support_is_vendor', false, $user_id );
	}
}
