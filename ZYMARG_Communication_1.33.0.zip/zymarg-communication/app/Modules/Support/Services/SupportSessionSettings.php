<?php
/**
 * ZYMARG Communication — helpline session settings.
 *
 * Admin⇄User support is a HELPLINE, not a mailbox. A customer has one live case
 * at a time, so a case that sits half-finished for days blocks them from ever
 * getting a clean start. When the agent has replied and the customer goes quiet,
 * the case closes itself after a configurable wait.
 *
 * The wait is deliberately an ADMIN-EDITABLE FIELD, not a constant. Three
 * minutes is only the shipped default; the owner sets whatever suits the way
 * their team actually works, from one minute up to a full day.
 *
 * Only ever applies while the case is `awaiting_user` — the agent wrote last.
 * A case waiting on the TEAM must never auto-close, or the plugin would be
 * punishing the customer for the team's own backlog. That asymmetry is the
 * whole design.
 *
 * @package    ZymargCommunication
 * @version    1.31.0
 * @author     ZYMARG Team
 */

namespace ZymargCommunication\Modules\Support\Services;

use ZymargCommunication\Modules\Settings\Repositories\SettingsRepository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class SupportSessionSettings {

	/** Master switch for the whole session engine. */
	public const ENABLED = 'support_session_enabled';

	/** Minutes of customer silence before the case closes itself. */
	public const MINUTES = 'support_session_minutes';

	/** How long before the deadline the customer is warned, in seconds. */
	public const WARN_SECONDS = 'support_session_warn_seconds';

	/** What a lapsed case becomes: `closed` or `resolved`. */
	public const ON_TIMEOUT = 'support_session_on_timeout';

	/** Shipped default wait. Overridable from Settings -> Support. */
	public const DEFAULT_MINUTES = 3;

	/** One minute floor, one day ceiling. */
	public const MIN_MINUTES = 1;
	public const MAX_MINUTES = 1440;

	public const DEFAULT_WARN_SECONDS = 60;
	public const MIN_WARN_SECONDS     = 10;
	public const MAX_WARN_SECONDS     = 600;

	/**
	 * `closed` is terminal in this plugin, so the customer's next contact opens a
	 * FRESH case — which is what a helpline wants: each call is its own call.
	 * `resolved` is offered for owners who would rather the customer's next
	 * message revive the same thread with all its context intact.
	 */
	public const TIMEOUT_MODES  = array( 'closed', 'resolved' );
	public const DEFAULT_ON_TIMEOUT = 'closed';

	private SettingsRepository $repo;

	public function __construct( ?SettingsRepository $repo = null ) {
		$this->repo = $repo ?? new SettingsRepository();
	}

	/* =====================================================================
	 * Reads
	 * ===================================================================== */

	/** Ships ENABLED: the helpline model is the point of the feature. */
	public function enabled(): bool {
		return '0' !== (string) $this->repo->get( self::ENABLED, '1' );
	}

	/**
	 * The wait, in minutes. Always clamped, so a hand-edited option or a stale
	 * value from another version can never produce a zero-second deadline that
	 * closes cases the instant an agent replies.
	 */
	public function minutes(): int {
		$raw = (int) $this->repo->get( self::MINUTES, self::DEFAULT_MINUTES );
		if ( $raw < 1 ) {
			$raw = self::DEFAULT_MINUTES;
		}

		/** Filter the helpline auto-close wait, in minutes. @since 1.31.0 */
		$raw = (int) apply_filters( 'zymarg_comm_support_session_minutes', $raw );

		return max( self::MIN_MINUTES, min( self::MAX_MINUTES, $raw ) );
	}

	/** The same wait expressed in seconds, for deadline arithmetic. */
	public function seconds(): int {
		return $this->minutes() * 60;
	}

	/**
	 * Warning lead time. Never allowed to exceed the wait itself — a 60-second
	 * warning on a 1-minute timer would otherwise fire before the clock starts,
	 * so the customer would open the case already being told it is about to end.
	 */
	public function warnSeconds(): int {
		$raw = (int) $this->repo->get( self::WARN_SECONDS, self::DEFAULT_WARN_SECONDS );
		if ( $raw < 1 ) {
			$raw = self::DEFAULT_WARN_SECONDS;
		}
		$raw = max( self::MIN_WARN_SECONDS, min( self::MAX_WARN_SECONDS, $raw ) );

		return min( $raw, max( 1, $this->seconds() - 1 ) );
	}

	/** `closed` (default) or `resolved`. */
	public function onTimeout(): string {
		$mode = strtolower( trim( (string) $this->repo->get( self::ON_TIMEOUT, self::DEFAULT_ON_TIMEOUT ) ) );

		return in_array( $mode, self::TIMEOUT_MODES, true ) ? $mode : self::DEFAULT_ON_TIMEOUT;
	}

	/* =====================================================================
	 * Writes (Settings -> Support)
	 * ===================================================================== */

	public function setEnabled( bool $on ): void {
		$this->repo->set( self::ENABLED, $on ? '1' : '0' );
	}

	/** Clamps before storing, so the stored value is always sane on its own. */
	public function setMinutes( int $minutes ): void {
		$minutes = max( self::MIN_MINUTES, min( self::MAX_MINUTES, $minutes ) );
		$this->repo->set( self::MINUTES, (string) $minutes );
	}

	public function setWarnSeconds( int $seconds ): void {
		$seconds = max( self::MIN_WARN_SECONDS, min( self::MAX_WARN_SECONDS, $seconds ) );
		$this->repo->set( self::WARN_SECONDS, (string) $seconds );
	}

	public function setOnTimeout( string $mode ): void {
		$mode = strtolower( trim( $mode ) );
		if ( ! in_array( $mode, self::TIMEOUT_MODES, true ) ) {
			$mode = self::DEFAULT_ON_TIMEOUT;
		}
		$this->repo->set( self::ON_TIMEOUT, $mode );
	}

	/* =====================================================================
	 * Frontend
	 * ===================================================================== */

	/**
	 * Strings the countdown needs. Merged into the ticket panel's i18n map so the
	 * browser can render the warning without another request.
	 *
	 * `%s` in sessionClosesIn is replaced client-side with a live mm:ss.
	 *
	 * @return array<string, string>
	 */
	public function frontendStrings(): array {
		return array(
			// 1.32.1 — reworded: the customer view no longer shows a status
			// pill, so the historic "Waiting on you —" prefix on the countdown
			// became redundant with the timer itself. Plain, direct copy.
			'sessionClosesIn'   => __( 'This case closes in %s if you do not reply.', 'zymarg-communication' ),
			'sessionClosingSoon'=> __( 'Your support case is about to close', 'zymarg-communication' ),
			'sessionClosedAuto' => __( 'This case was closed automatically because there was no reply.', 'zymarg-communication' ),
			'sessionStartNew'   => __( 'Start a new case', 'zymarg-communication' ),
			'sessionPaused'     => __( 'The countdown is paused by our team.', 'zymarg-communication' ),
			'sessionPause'      => __( 'Pause timer', 'zymarg-communication' ),
			'sessionResume'     => __( 'Resume timer', 'zymarg-communication' ),
			'sessionExtend'     => __( 'Give more time', 'zymarg-communication' ),
		);
	}
}
