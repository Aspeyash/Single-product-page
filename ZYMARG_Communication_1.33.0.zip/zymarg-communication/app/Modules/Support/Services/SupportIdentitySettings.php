<?php
/**
 * ZYMARG Communication — support agent public identity.
 *
 * Customers talk to a PERSONA, not to a WordPress account. Before 1.32.15 the
 * plugin had no concept of a public name at all: headers said the fixed brand
 * label "Support team", the typing indicator said nothing, and the notification
 * payload leaked the agent's raw `display_name` — so a customer could be told
 * "New message from admin" by the very same case whose window said
 * "Support team".
 *
 * This service is the single source of truth for "what does the customer call
 * this agent". It resolves in three tiers, so it can NEVER fall back to a real
 * username:
 *
 *   1. that agent's own public name   (user meta, set per agent by the owner)
 *   2. the site-wide default          (option, ships as "Alpha")
 *   3. the existing brand label       ("Support team")
 *
 * Nothing here writes to the WordPress user account. `display_name`, login and
 * email are untouched — this is a presentation layer only, so every other
 * plugin that reads the user's name is unaffected.
 *
 * @package    ZymargCommunication
 * @version    1.32.15
 * @author     ZYMARG Team
 */

namespace ZymargCommunication\Modules\Support\Services;

use ZymargCommunication\Modules\Support\Repositories\SupportTicketRepository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class SupportIdentitySettings {

	/** Per-agent customer-facing name. User meta on the agent's own account. */
	public const META = '_zymarg_comm_support_alias';

	/** Site-wide fallback used for any agent who has no name of their own. */
	public const OPTION_DEFAULT = 'zymarg_comm_support_agent_alias';

	/** Shipped default. Editable from Communication -> Support. */
	public const DEFAULT_ALIAS = 'Alpha';

	/**
	 * Hard ceiling on a name's length.
	 *
	 * The name lands in a one-row chat header and in a typing line, both of
	 * which are width-constrained on mobile. Cutting at 40 keeps a pasted
	 * paragraph from wrecking the layout of a live conversation.
	 */
	public const MAX_LENGTH = 40;

	private ?SupportTicketRepository $tickets;

	public function __construct( ?SupportTicketRepository $tickets = null ) {
		$this->tickets = $tickets;
	}

	/* =====================================================================
	 * Reads
	 * ===================================================================== */

	/**
	 * Final backstop label.
	 *
	 * Deliberately the SAME literal ConversationService and live-chat.js already
	 * use for a support thread's title, so a customer can never be shown two
	 * different names for the same conversation.
	 */
	public function brandLabel(): string {
		return __( 'Support team', 'zymarg-communication' );
	}

	/** The site-wide fallback name. Never empty. */
	public function defaultAlias(): string {
		$alias = $this->clean( (string) get_option( self::OPTION_DEFAULT, '' ) );

		return '' !== $alias ? $alias : self::DEFAULT_ALIAS;
	}

	/**
	 * One agent's own name as STORED — '' when they have not been given one.
	 *
	 * This is the value the admin field shows, so an empty box honestly means
	 * "no name set, this agent inherits the default" rather than pretending the
	 * default was chosen deliberately.
	 */
	public function rawAliasForAgent( int $user_id ): string {
		if ( $user_id < 1 ) {
			return '';
		}

		return $this->clean( (string) get_user_meta( $user_id, self::META, true ) );
	}

	/**
	 * What the customer calls this agent. Never empty, never a real username.
	 *
	 * @param int $user_id Agent account id.
	 */
	public function aliasForAgent( int $user_id ): string {
		$alias = $this->rawAliasForAgent( $user_id );

		if ( '' === $alias ) {
			$alias = $this->defaultAlias();
		}

		if ( '' === $alias ) {
			$alias = $this->brandLabel();
		}

		/**
		 * Filter the customer-facing name for one support agent.
		 *
		 * @since 1.32.15
		 * @param string $alias   Resolved public name.
		 * @param int    $user_id Agent account id.
		 */
		$alias = (string) apply_filters( 'zymarg_comm_support_agent_alias', $alias, $user_id );

		$alias = $this->clean( $alias );

		return '' !== $alias ? $alias : $this->brandLabel();
	}

	/**
	 * The public name for whoever OWNS this case.
	 *
	 * Ownership is `zc_support_tickets.agent_id`, which the repository claims for
	 * the first agent to reply and never reassigns to a later replier
	 * (SupportTicketRepository::recordAgentReply only fills it while it is 0).
	 * That makes one case = one stable persona for its whole life, which is why
	 * the typing indicator can name the owner without having to discover who is
	 * actually at the keyboard.
	 *
	 * Falls back to the brand label whenever ownership cannot be established —
	 * an unclaimed case, a ticket table that has not migrated yet, or a deleted
	 * account. Never throws: this runs inside a polling endpoint.
	 *
	 * @param int $conversation_id Support conversation id.
	 */
	public function aliasForConversation( int $conversation_id ): string {
		$agent_id = $this->ownerId( $conversation_id );

		return $agent_id > 0 ? $this->aliasForAgent( $agent_id ) : $this->brandLabel();
	}

	/**
	 * Owning agent id for a case, or 0 when nobody owns it.
	 *
	 * @param int $conversation_id Support conversation id.
	 */
	public function ownerId( int $conversation_id ): int {
		if ( $conversation_id < 1 ) {
			return 0;
		}

		try {
			$tickets = $this->tickets ?? new SupportTicketRepository();
			if ( ! $tickets->tableReady() ) {
				return 0;
			}
			$row = $tickets->find( $conversation_id );
			if ( ! is_array( $row ) ) {
				return 0;
			}
			$agent_id = (int) ( $row['agent_id'] ?? 0 );
		} catch ( \Throwable $e ) {
			// Reading ownership must never take a conversation down.
			return 0;
		}

		return $agent_id > 0 && get_userdata( $agent_id ) ? $agent_id : 0;
	}

	/* =====================================================================
	 * Writes
	 * ===================================================================== */

	/**
	 * Set the site-wide fallback name. Passing '' restores the shipped default.
	 */
	public function setDefaultAlias( string $alias ): bool {
		$alias = $this->clean( $alias );

		return (bool) update_option(
			self::OPTION_DEFAULT,
			'' !== $alias ? $alias : self::DEFAULT_ALIAS,
			false
		);
	}

	/**
	 * Give one agent their own public name.
	 *
	 * Passing '' DELETES the override rather than storing an empty string, so
	 * the agent cleanly falls back to the site-wide default.
	 */
	public function setAliasForAgent( int $user_id, string $alias ): bool {
		if ( $user_id < 1 ) {
			return false;
		}

		$alias = $this->clean( $alias );

		if ( '' === $alias ) {
			delete_user_meta( $user_id, self::META );

			return true;
		}

		return (bool) update_user_meta( $user_id, self::META, $alias );
	}

	/* =====================================================================
	 * Internals
	 * ===================================================================== */

	/**
	 * Normalise a name for storage AND for output.
	 *
	 * Runs on the way in and on the way out, so a value written by an older
	 * build, by a filter, or straight into the database by hand still cannot
	 * inject markup into a chat header.
	 */
	private function clean( string $alias ): string {
		$alias = sanitize_text_field( wp_strip_all_tags( $alias ) );
		$alias = trim( preg_replace( '/\s+/u', ' ', $alias ) ?? '' );

		if ( '' === $alias ) {
			return '';
		}

		// mb_substr when available so a multibyte name is not cut mid-character.
		return function_exists( 'mb_substr' )
			? mb_substr( $alias, 0, self::MAX_LENGTH )
			: substr( $alias, 0, self::MAX_LENGTH );
	}
}
