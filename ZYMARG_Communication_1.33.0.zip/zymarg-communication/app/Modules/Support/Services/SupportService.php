<?php
/**
 * SupportService — Admin⇄User messaging.
 *
 * Lets any customer (buyer or seller) open a direct line to the site's support
 * agents, and lets agents reply. Deliberately built on top of the existing
 * conversation engine rather than beside it, so support threads inherit
 * attachments, reactions, replies, read receipts, typing, presence,
 * notifications, moderation and the audit log for free.
 *
 * Design decisions:
 *  - Agents are a POOL, identified by the `zymarg_support_agent` capability,
 *    not a single hardcoded admin. Support survives one person being away.
 *  - ONE ongoing thread per user. Repeat contacts resume the same thread.
 *  - Off by default behind the `surface.support_chat` feature flag.
 *
 * @package ZymargCommunication
 * @since   1.25.0
 */

namespace ZymargCommunication\Modules\Support\Services;

use ZymargCommunication\Core\Abstracts\AbstractService;
use ZymargCommunication\Core\Exceptions\NotFoundException;
use ZymargCommunication\Core\Exceptions\ValidationException;
use ZymargCommunication\Modules\Conversation\Services\ConversationService;
use ZymargCommunication\Modules\Message\Services\MessageService;
use ZymargCommunication\Modules\Support\Repositories\SupportRepository;
use ZymargCommunication\Modules\Support\Repositories\SupportTicketRepository;
use ZymargCommunication\Modules\Support\Services\SupportIntakeSettings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class SupportService extends AbstractService {

	/** Capability that marks a user as a support agent. */
	public const CAPABILITY = 'zymarg_support_agent';

	/**
	 * Cache key for the measured reply-time sentence (1.32.0).
	 *
	 * An hour is plenty: the figure is a 30-day median, so it barely moves, and
	 * recomputing it per intake open would put an aggregate query on a hot path.
	 */
	private const ETA_TRANSIENT = 'zymarg_comm_support_eta_label';

	/** Feature flag gating the whole surface. Ships DISABLED. */
	public const FLAG = 'surface.support_chat';

	/** Option holding the fallback agent user id. */
	public const OPTION_DEFAULT_AGENT = 'zymarg_comm_support_default_agent';

	/** Option holding the customer-facing label. */
	public const OPTION_LABEL = 'zymarg_comm_support_label';

	/**
	 * @param ?MessageService $messages Optional (1.32.0). Used to post the Smart
	 *                                  Intake answers as the thread's opening
	 *                                  message. Optional so a caller that never
	 *                                  opens threads does not have to supply it,
	 *                                  and so the absence degrades to the old
	 *                                  behaviour instead of fataling.
	 */
	public function __construct(
		private SupportRepository $repository,
		private ConversationService $conversations,
		private ?SupportTicketRepository $tickets = null,
		private ?MessageService $messages = null
	) {}

	/** Proxy so callers with only the service can gate on support context. */
	public function isSupportConversation( int $conversation_id ): bool {
		return $this->repository->isSupportConversation( $conversation_id );
	}

	/**
	 * Does this user currently have an OPEN support ticket?
	 *
	 * Cheap, side-effect-free read so the trigger renderer can hide the
	 * "Contact Support" call to action when the customer is already inside a
	 * live case — otherwise the same page shows the CTA above the very
	 * conversation it would open. (1.32.1)
	 *
	 * Silently returns false when the ticket table has not been migrated yet;
	 * the pre-ticket-table code path had no notion of "open vs. closed" so
	 * there is no equivalent lookup to fall back on, and a wrong "true" here
	 * would suppress the trigger for users who need it.
	 */
	public function hasOpenTicketForUser( int $user_id ): bool {
		if ( $user_id < 1 ) {
			return false;
		}
		if ( ! ( $this->tickets instanceof SupportTicketRepository ) || ! $this->tickets->tableReady() ) {
			return false;
		}
		try {
			return null !== $this->tickets->findOpenForUser( $user_id );
		} catch ( \Throwable $e ) {
			return false;
		}
	}

	/** Is the Admin<->User surface switched on? */
	public function enabled(): bool {
		return (bool) $this->isEnabled( self::FLAG );
	}

	/** Customer-facing label. Overridable per placement by the shortcode. */
	public function label(): string {
		$label = trim( (string) get_option( self::OPTION_LABEL, '' ) );
		if ( '' === $label ) {
			$label = __( 'Contact Support', 'zymarg-communication' );
		}

		/**
		 * Filter the default support label.
		 *
		 * @since 1.25.0
		 * @param string $label Current label.
		 */
		return (string) apply_filters( 'zymarg_comm_support_label', $label );
	}

	/**
	 * Every user in the support agent pool.
	 *
	 * @return array<int, int> User ids.
	 */
	public function agentIds(): array {
		$ids = array();

		$users = get_users(
			array(
				'capability__in' => array( self::CAPABILITY ),
				'fields'         => 'ID',
				'number'         => 100,
			)
		);
		foreach ( (array) $users as $id ) {
			$ids[] = (int) $id;
		}

		// Older WordPress builds ignore capability__in for custom caps granted
		// per-user rather than per-role, so verify and backfill with admins.
		$ids = array_values(
			array_filter(
				array_unique( $ids ),
				static fn( $id ) => user_can( $id, self::CAPABILITY )
			)
		);

		if ( empty( $ids ) ) {
			$admins = get_users(
				array(
					'role'    => 'administrator',
					'fields'  => 'ID',
					'number'  => 20,
					'orderby' => 'ID',
				)
			);
			foreach ( (array) $admins as $id ) {
				$ids[] = (int) $id;
			}
		}

		/**
		 * Filter the support agent pool.
		 *
		 * @since 1.25.0
		 * @param array<int,int> $ids Agent user ids.
		 */
		return (array) apply_filters( 'zymarg_comm_support_agents', array_values( array_unique( $ids ) ) );
	}

	/** Is this user allowed to answer support threads? */
	public function isAgent( int $user_id ): bool {
		if ( $user_id < 1 ) {
			return false;
		}
		if ( user_can( $user_id, self::CAPABILITY ) ) {
			return true;
		}

		return in_array( $user_id, $this->agentIds(), true );
	}

	/**
	 * Choose which agent receives a new thread.
	 *
	 * Preference order: the configured default agent, then the agent carrying
	 * the fewest support threads, so load spreads instead of piling on one
	 * person. Never returns the requester themselves.
	 */
	public function resolveAgent( int $for_user = 0 ): int {
		$agents = array_values(
			array_filter( $this->agentIds(), static fn( $id ) => (int) $id !== (int) $for_user )
		);

		if ( empty( $agents ) ) {
			return 0;
		}

		$default = (int) get_option( self::OPTION_DEFAULT_AGENT, 0 );
		if ( $default > 0 && in_array( $default, $agents, true ) ) {
			return $default;
		}

		$use_tickets = $this->tickets instanceof SupportTicketRepository && $this->tickets->tableReady();

		$best      = $agents[0];
		$best_load = PHP_INT_MAX;
		foreach ( $agents as $agent ) {
			// Prefer OPEN-ticket load so work spreads by who is actually busy,
			// not by who has ever been a participant. Falls back to the raw
			// participant count on pre-ticket-table sites.
			$load = $use_tickets
				? $this->tickets->openCountForAgent( (int) $agent )
				: $this->repository->loadForAgent( (int) $agent );
			if ( $load < $best_load ) {
				$best_load = $load;
				$best      = (int) $agent;
			}
		}

		return (int) $best;
	}

	/**
	 * Start a support thread, or resume the user's existing one.
	 *
	 * Works in both directions: a customer contacting support, and an agent
	 * reaching out to a customer first.
	 *
	 * @param int                  $user_id Customer the thread belongs to.
	 * @param array<string, mixed> $context Optional Smart Intake context
	 *                                      (topic, subject, order_id, vendor_id)
	 *                                      seeded onto a newly created ticket.
	 * @return array{conversation_id:int,is_new:bool,agent_id:int,inbox_url:string}
	 */
	public function startOrResume( int $user_id, array $context = array() ): array {
		if ( ! $this->enabled() ) {
			throw new ValidationException(
				__( 'Support messaging is currently unavailable.', 'zymarg-communication' ),
				array( 'support' => 'disabled' )
			);
		}

		if ( $user_id < 1 || ! get_userdata( $user_id ) ) {
			throw new NotFoundException( __( 'User could not be found.', 'zymarg-communication' ) );
		}

		// Ticket-per-issue (1.27.0): resume only an OPEN ticket. A resolved or
		// closed ticket is finished business, so a fresh contact starts a new
		// thread instead of reopening a conversation an agent already signed off.
		// Sites that upgraded before the ticket table existed fall back to the
		// historical "one eternal thread" lookup, so nothing breaks in between.
		if ( $this->tickets instanceof SupportTicketRepository && $this->tickets->tableReady() ) {
			$open = $this->tickets->findOpenForUser( $user_id );
			if ( null !== $open ) {
				return array(
					'conversation_id' => (int) $open['conversation_id'],
					'is_new'          => false,
					'agent_id'        => (int) ( $open['agent_id'] ?? 0 ),
					'inbox_url'       => $this->inboxUrl(),
				);
			}
			// No OPEN ticket -> intentionally fall through and create a new one,
			// even if the user has older resolved/closed threads.
		} else {
			$existing = $this->repository->findForUser( $user_id );
			if ( null !== $existing ) {
				return array(
					'conversation_id' => $existing,
					'is_new'          => false,
					'agent_id'        => 0,
					'inbox_url'       => $this->inboxUrl(),
				);
			}
		}

		$agent_id = $this->resolveAgent( $user_id );
		if ( $agent_id < 1 ) {
			throw new NotFoundException(
				__( 'No support agent is available right now.', 'zymarg-communication' )
			);
		}

		$conversation    = $this->conversations->create( $user_id, $agent_id, SupportRepository::CONTEXT, 0 );
		$conversation_id = (int) ( $conversation['id'] ?? 0 );

		if ( $conversation_id < 1 ) {
			throw new NotFoundException( __( 'Support conversation could not be opened.', 'zymarg-communication' ) );
		}

		// Seed the ticket row WITH the intake context before announcing the
		// thread, so the very first thing the agent sees already says what it is
		// about. ensure() is idempotent, so the onSupportStarted listener that
		// fires from the hook below simply finds this row.
		if ( $this->tickets instanceof SupportTicketRepository && $this->tickets->tableReady() ) {
			$order_id = max( 0, (int) ( $context['order_id'] ?? 0 ) );

			// A customer must not be able to staple someone else's order to a
			// ticket by guessing an id. Only keep the link when the order really
			// belongs to the ticket owner.
			if ( $order_id > 0 && ! $this->orderBelongsTo( $order_id, $user_id ) ) {
				$order_id = 0;
			}

			$seed = array(
				'topic'     => isset( $context['topic'] ) ? sanitize_text_field( (string) $context['topic'] ) : '',
				'subject'   => isset( $context['subject'] ) ? sanitize_text_field( (string) $context['subject'] ) : '',
				'order_id'  => $order_id,
				'vendor_id' => max( 0, (int) ( $context['vendor_id'] ?? 0 ) ),
			);
			$this->tickets->ensure( $conversation_id, $user_id, $agent_id, $seed );
		}

		/**
		 * Fires when a new support thread is opened.
		 *
		 * @since 1.25.0
		 * @param int $conversation_id Conversation id.
		 * @param int $user_id         Customer.
		 * @param int $agent_id        Assigned agent.
		 */
		do_action( 'zymarg_comm_support_started', $conversation_id, $user_id, $agent_id );

		// 1.32.0 — turn the Smart Intake answers into the thread's OPENING
		// MESSAGE. Until now they were written to the ticket row only, so a
		// customer who chose a topic and typed "wrong size delivered" pressed
		// Start chat and landed in a completely blank window: their words were
		// stored but shown nowhere, which reads as if the form threw them away.
		//
		// Posting it before returning matters — the client opens the thread as
		// soon as this responds, so the message has to already be there.
		$this->postOpeningMessage( $conversation_id, $user_id, $context, $order_id ?? 0 );

		return array(
			'conversation_id' => $conversation_id,
			'is_new'          => true,
			'agent_id'        => $agent_id,
			'inbox_url'       => $this->inboxUrl(),
		);
	}

	/**
	 * Machine-readable configuration for the front end and future mobile app.
	 *
	 * @return array<string, mixed>
	 */
	public function config( int $viewer_id = 0 ): array {
		return array(
			'enabled'      => $this->enabled(),
			'label'        => $this->label(),
			'context'      => SupportRepository::CONTEXT,
			'is_agent'     => $viewer_id > 0 && $this->isAgent( $viewer_id ),
			'agent_count'  => count( $this->agentIds() ),
			'has_thread'   => $viewer_id > 0 && null !== $this->repository->findForUser( $viewer_id ),
			'inbox_url'    => $this->inboxUrl(),
			'rest_root'    => esc_url_raw( rest_url( 'zymarg-comm/v1' ) ),
		);
	}

	/**
	 * Topic chips for the Smart Intake card. Sellers and buyers ask about
	 * different things, so the list is tailored. Filterable so a site can add
	 * its own topics without a code change here.
	 *
	 * @return array<int, array{key:string,label:string}>
	 */
	/**
	 * Post the Smart Intake answers as the thread's opening message (1.32.0).
	 *
	 * Sent as the CUSTOMER, through MessageService, which means it behaves like
	 * any other first message: the assigned agent is notified, and the ticket
	 * correctly lands on "waiting on us" rather than sitting in a state that
	 * claims the customer still owes a reply.
	 *
	 * Entirely best-effort. A moderation false positive or a storage hiccup must
	 * never stop the thread opening — the customer would be left with no way to
	 * reach support at all, which is far worse than a missing first line.
	 *
	 * @param array<string, mixed> $context Raw intake context from the client.
	 */
	private function postOpeningMessage( int $conversation_id, int $user_id, array $context, int $order_id ): void {
		if ( ! $this->messages instanceof MessageService ) {
			return;
		}

		$body = $this->composeOpeningMessage( $user_id, $context, $order_id );
		if ( '' === $body ) {
			return; // Nothing was entered, so there is nothing worth showing.
		}

		try {
			$this->messages->send( $conversation_id, $user_id, $body );
		} catch ( \Throwable $e ) {
			// Swallowed on purpose. The thread is already open and usable.
			return;
		}
	}

	/**
	 * Build the opening message from what the customer actually chose.
	 *
	 * Their own words come first and unadorned, because this renders as a message
	 * FROM them and anything else would put words in their mouth. The topic is
	 * only used as the body when nothing was typed, since it otherwise duplicates
	 * the pill already shown on the ticket panel.
	 *
	 * @param array<string, mixed> $context
	 */
	private function composeOpeningMessage( int $user_id, array $context, int $order_id ): string {
		$subject = isset( $context['subject'] ) ? trim( sanitize_text_field( (string) $context['subject'] ) ) : '';
		$topic   = isset( $context['topic'] ) ? trim( sanitize_text_field( (string) $context['topic'] ) ) : '';

		$lines = array();

		if ( '' !== $subject ) {
			$lines[] = $subject;
		} elseif ( '' !== $topic ) {
			// No typed subject: fall back to the human label for the chip they
			// picked, never the raw slug.
			$lines[] = $this->topicLabel( $user_id, $topic );
		}

		if ( $order_id > 0 ) {
			$lines[] = sprintf(
				/* translators: %s: order number. */
				__( 'Regarding order %s', 'zymarg-communication' ),
				$this->orderNumber( $order_id )
			);
		}

		$lines = array_values( array_filter( $lines, static fn ( $l ): bool => '' !== trim( (string) $l ) ) );

		return implode( "\n\n", $lines );
	}

	/** Human label for a topic key, falling back to the key itself. */
	private function topicLabel( int $user_id, string $key ): string {
		foreach ( $this->intakeTopics( $user_id ) as $topic ) {
			if ( isset( $topic['key'] ) && $key === $topic['key'] ) {
				return (string) ( $topic['label'] ?? $key );
			}
		}

		return $key;
	}

	/** Customer-facing order number, which is not always the post ID. */
	private function orderNumber( int $order_id ): string {
		if ( function_exists( 'wc_get_order' ) ) {
			$order = wc_get_order( $order_id );
			if ( $order && method_exists( $order, 'get_order_number' ) ) {
				return '#' . $order->get_order_number();
			}
		}

		return '#' . $order_id;
	}

	public function intakeTopics( int $user_id ): array {
		$is_vendor = $this->userLooksLikeVendor( $user_id );

		// 1.29.0: the chips are owner-editable from Settings -> Support. The
		// settings service resolves stored lines and falls back to the shipped
		// defaults when blank, so this is always a populated list.
		$out = array();
		try {
			$out = ( new SupportIntakeSettings() )->topics( $is_vendor ? 'vendor' : 'buyer' );
		} catch ( \Throwable $e ) {
			$out = array();
		}

		/**
		 * Filter the Smart Intake topic chips.
		 *
		 * @since 1.27.0
		 * @param array<int,array{key:string,label:string}> $out       Topics.
		 * @param int                                        $user_id   Requester.
		 * @param bool                                       $is_vendor Vendor?
		 */
		return (array) apply_filters( 'zymarg_comm_support_intake_topics', $out, $user_id, $is_vendor );
	}

	/**
	 * The caller's recent orders, for the intake "is it about one of these?"
	 * picker. Empty (not an error) when WooCommerce is absent.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function recentOrders( int $user_id ): array {
		if ( $user_id < 1 || ! function_exists( 'wc_get_orders' ) ) {
			return array();
		}

		$orders = wc_get_orders(
			array(
				'customer_id' => $user_id,
				'limit'       => 5,
				'orderby'     => 'date',
				'order'       => 'DESC',
				'return'      => 'objects',
			)
		);

		$out = array();
		foreach ( (array) $orders as $order ) {
			if ( ! is_object( $order ) || ! method_exists( $order, 'get_id' ) ) {
				continue;
			}
			$out[] = array(
				'id'       => $order->get_id(),
				'number'   => $order->get_order_number(),
				'total'    => (float) $order->get_total(),
				'currency' => $order->get_currency(),
				'status'   => $order->get_status(),
				'date'     => $order->get_date_created() ? $order->get_date_created()->date( 'M j, Y' ) : '',
			);
		}

		return $out;
	}

	/**
	 * A friendly availability line for the intake card.
	 *
	 * @return array<string, mixed>
	 */
	/**
	 * What to tell the customer about how soon they will hear back.
	 *
	 * 1.32.0: this used to be the flat claim "We usually reply within a few
	 * hours", which was hard-coded and therefore might simply be untrue. It is
	 * now MEASURED — the median gap between a case opening and the first agent
	 * reply over the last 30 days.
	 *
	 * Resolution order:
	 *   1. an owner-written override (it can reference opening hours we cannot know)
	 *   2. the measured median, if there is enough history to be honest about
	 *   3. nothing at all
	 *
	 * Step 3 is deliberate. A brand-new site has no evidence, and a promise it
	 * cannot keep is worse than no promise: the intake card already hides the
	 * line when this comes back empty.
	 */
	public function availability(): array {
		$agents = count( $this->agentIds() );

		$settings = null;
		try {
			$settings = new SupportIntakeSettings();
		} catch ( \Throwable $e ) {
			$settings = null;
		}

		// Owner switched the line off entirely.
		if ( $settings instanceof SupportIntakeSettings && ! $settings->showAvailability() ) {
			return array( 'agent_count' => $agents, 'eta_label' => '' );
		}

		// An owner-supplied line always wins.
		$override = $settings instanceof SupportIntakeSettings ? $settings->availabilityOverride() : '';
		if ( '' !== $override ) {
			return array( 'agent_count' => $agents, 'eta_label' => $override );
		}

		return array(
			'agent_count' => $agents,
			'eta_label'   => $this->measuredEtaLabel(),
		);
	}

	/**
	 * The measured reply-time sentence, or '' when we cannot back it up.
	 *
	 * Cached for an hour: this is decorative copy on a modal, and it must not put
	 * an aggregate query in front of every customer who clicks Contact Support.
	 */
	private function measuredEtaLabel(): string {
		$cached = get_transient( self::ETA_TRANSIENT );
		if ( is_string( $cached ) ) {
			return $cached;
		}

		$label   = '';
		$seconds = null;

		if ( $this->tickets instanceof SupportTicketRepository ) {
			try {
				$seconds = $this->tickets->medianFirstResponseSeconds( 30, 3 );
			} catch ( \Throwable $e ) {
				$seconds = null;
			}
		}

		if ( null !== $seconds ) {
			$label = $seconds < MINUTE_IN_SECONDS
				? __( 'We usually reply within a minute.', 'zymarg-communication' )
				: sprintf(
					/* translators: %s: a human duration such as "20 mins" or "2 hours". */
					__( 'We usually reply in about %s.', 'zymarg-communication' ),
					human_time_diff( 0, $seconds )
				);
		}

		/**
		 * Filter the measured reply-time sentence.
		 *
		 * @since 1.32.0
		 * @param string   $label   Sentence, or '' when there is not enough data.
		 * @param int|null $seconds Median first-response seconds, or null.
		 */
		$label = (string) apply_filters( 'zymarg_comm_support_eta_label', $label, $seconds );

		set_transient( self::ETA_TRANSIENT, $label, HOUR_IN_SECONDS );

		return $label;
	}

	/** Public vendor check used by intake. Mirrors the ticket-service heuristic. */
	public function userLooksLikeVendor( int $user_id ): bool {
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return false;
		}
		$vendor_roles = array( 'seller', 'vendor', 'dc_vendor', 'wcfm_vendor', 'shop_manager' );
		foreach ( (array) $user->roles as $role ) {
			if ( in_array( $role, $vendor_roles, true ) ) {
				return true;
			}
		}
		if ( function_exists( 'dokan_is_user_seller' ) ) {
			return (bool) dokan_is_user_seller( $user_id );
		}

		return (bool) apply_filters( 'zymarg_comm_support_is_vendor', false, $user_id );
	}

	/** Does this WooCommerce order belong to this user? Safe without WC. */
	private function orderBelongsTo( int $order_id, int $user_id ): bool {
		if ( $order_id < 1 || $user_id < 1 || ! function_exists( 'wc_get_order' ) ) {
			return false;
		}
		$order = wc_get_order( $order_id );
		if ( ! $order || ! method_exists( $order, 'get_customer_id' ) ) {
			return false;
		}

		return (int) $order->get_customer_id() === $user_id;
	}

	/** Where a customer reads their replies. */
	private function inboxUrl(): string {
		$url = '';
		if ( function_exists( 'wc_get_account_endpoint_url' ) ) {
			$url = (string) wc_get_account_endpoint_url( 'messages' );
		}
		if ( '' === $url && function_exists( 'wc_get_page_permalink' ) ) {
			$url = (string) wc_get_page_permalink( 'myaccount' );
		}

		/**
		 * Filter the URL customers are sent to in order to read support replies.
		 *
		 * @since 1.25.0
		 * @param string $url Inbox URL.
		 */
		return (string) apply_filters( 'zymarg_comm_support_inbox_url', $url );
	}
}
