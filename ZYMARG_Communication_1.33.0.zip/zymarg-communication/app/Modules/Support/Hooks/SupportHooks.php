<?php
/**
 * SupportHooks — wires the Admin⇄User module into WordPress.
 *
 * Responsibilities:
 *  - Queue the REST controller so /support/* routes exist.
 *  - Ensure the administrator role holds the support agent capability, once.
 *
 * @package ZymargCommunication
 * @since   1.25.0
 */

namespace ZymargCommunication\Modules\Support\Hooks;

use ZymargCommunication\Bootstrap\ServiceProvider;
use ZymargCommunication\Infrastructure\Http\Controllers\RestController;
use ZymargCommunication\Modules\Support\Controllers\SupportController;
use ZymargCommunication\Modules\Support\Services\SupportService;
use ZymargCommunication\Modules\Support\Services\SupportTicketService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class SupportHooks {

	/** Bumped whenever the capability grant needs to re-run. */
	private const CAP_VERSION        = '1';
	private const CAP_VERSION_OPTION = 'zymarg_comm_support_cap_version';

	public static function register(): void {
		if ( ServiceProvider::has( SupportController::class ) ) {
			RestController::register( ServiceProvider::get( SupportController::class ) );
		}

		// Ticket lifecycle (1.27.0): message-driven status, escalation cron,
		// thread-created seeding. Registered here so all support wiring is in
		// one place.
		if ( ServiceProvider::has( SupportTicketService::class ) ) {
			$ticket_service = ServiceProvider::get( SupportTicketService::class );
			if ( $ticket_service instanceof SupportTicketService ) {
				$ticket_service->registerListeners();
			}
		}

		add_action( 'init', array( self::class, 'ensureCapability' ), 20 );
	}

	/**
	 * Grant the support agent capability to administrators once.
	 *
	 * Additional agents (editors, shop managers, individual users) are granted
	 * the capability from the Admin⇄User screen, so support staff never need
	 * full administrator access just to answer messages.
	 */
	public static function ensureCapability(): void {
		if ( self::CAP_VERSION === (string) get_option( self::CAP_VERSION_OPTION, '' ) ) {
			return;
		}

		$role = get_role( 'administrator' );
		if ( $role && ! $role->has_cap( SupportService::CAPABILITY ) ) {
			$role->add_cap( SupportService::CAPABILITY );
		}

		update_option( self::CAP_VERSION_OPTION, self::CAP_VERSION, false );
	}
}
