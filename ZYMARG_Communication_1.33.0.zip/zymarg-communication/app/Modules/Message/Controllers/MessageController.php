<?php
/**
 * REST endpoints for send, edit, delete, reply, react.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Message\Controllers;

use WP_REST_Request;
use WP_REST_Response;
use ZymargCommunication\Bootstrap\ServiceProvider;
use ZymargCommunication\Core\Abstracts\AbstractController;
use ZymargCommunication\Core\Exceptions\ValidationException;
use ZymargCommunication\Infrastructure\Http\Middleware\AuthMiddleware;
use ZymargCommunication\Infrastructure\Http\Middleware\NonceMiddleware;
use ZymargCommunication\Infrastructure\Http\Middleware\RateLimitMiddleware;
use ZymargCommunication\Modules\Message\Services\AttachmentService;
use ZymargCommunication\Modules\Message\Services\MessageService;
use ZymargCommunication\Modules\Message\Services\ReactionService;
use ZymargCommunication\Modules\Message\Services\ReadReceiptService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class MessageController extends AbstractController {

	public function __construct(
		private MessageService $messages,
		private ReactionService $reactions,
		private ReadReceiptService $receipts
	) {}

	public function registerRoutes(): void {
		register_rest_route(
			self::NAMESPACE,
			'/conversations/(?P<id>\\d+)/messages',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( $this, 'index' ),
					'permission_callback' => array( AuthMiddleware::class, 'requireLoggedIn' ),
					'args'                => array(
						'limit'  => array( 'type' => 'integer', 'default' => 30 ),
						'offset' => array( 'type' => 'integer', 'default' => 0 ),
					),
				),
				array(
					'methods'             => 'POST',
					'callback'            => array( $this, 'store' ),
					'permission_callback' => array( $this, 'writeGuard' ),
					'args'                => array(
						'body'      => array( 'required' => true, 'type' => 'string' ),
						'parent_id' => array( 'type' => 'integer' ),
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/messages/(?P<id>\\d+)',
			array(
				array(
					'methods'             => 'PATCH',
					'callback'            => array( $this, 'update' ),
					'permission_callback' => array( $this, 'writeGuard' ),
					'args'                => array(
						'body' => array( 'required' => true, 'type' => 'string' ),
					),
				),
				array(
					'methods'             => 'DELETE',
					'callback'            => array( $this, 'destroy' ),
					'permission_callback' => array( $this, 'writeGuard' ),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/messages/(?P<id>\\d+)/react',
			array(
				array(
					'methods'             => 'POST',
					'callback'            => array( $this, 'react' ),
					'permission_callback' => array( $this, 'writeGuard' ),
					'args'                => array(
						'emoji' => array( 'required' => true, 'type' => 'string' ),
					),
				),
				array(
					'methods'             => 'DELETE',
					'callback'            => array( $this, 'unreact' ),
					'permission_callback' => array( $this, 'writeGuard' ),
					'args'                => array(
						'emoji' => array( 'required' => true, 'type' => 'string' ),
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/conversations/(?P<id>\\d+)/read',
			array(
				'methods'             => 'PATCH',
				'callback'            => array( $this, 'markRead' ),
				'permission_callback' => array( $this, 'writeGuard' ),
				'args'                => array(
					'before_message_id' => array( 'required' => true, 'type' => 'integer' ),
				),
			)
		);
	}

	public function writeGuard( WP_REST_Request $request ): bool|\WP_Error {
		$auth = AuthMiddleware::requireLoggedIn( $request );
		if ( $auth instanceof \WP_Error ) {
			return $auth;
		}
		return NonceMiddleware::verify( $request );
	}

	public function index( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle(
			function () use ( $request ) {
				$this->requireAuthenticated();

				$conversation_id = (int) $request->get_param( 'id' );
				$limit           = (int) $this->param( $request, 'limit', 30 );

				// The registered 'offset' arg carries a default of 0, so get_param()
				// can never distinguish "give me page 1" from "no preference".
				// Inspect the raw query string instead. When no offset was asked for,
				// serve the NEWEST messages rather than the oldest: serving the oldest
				// froze every thread view once a conversation passed $limit messages,
				// because new messages simply were not in the payload.
				$explicit_offset = array_key_exists( 'offset', (array) $request->get_query_params() );

				$result = $explicit_offset
					? $this->messages->listForConversation(
						$conversation_id,
						$this->currentUserId(),
						$limit,
						(int) $this->param( $request, 'offset', 0 )
					)
					: $this->messages->listLatestForConversation(
						$conversation_id,
						$this->currentUserId(),
						$limit
					);

				return $this->withAgentAttribution(
					$this->withReactions( $this->withAttachments( $result ) ),
					$conversation_id
				);
			}
		);
	}

	/**
	 * Tell one agent which messages a COLLEAGUE wrote.
	 *
	 * The thread renderer only knows "mine" and "not mine" (it compares
	 * `sender_id` to the viewer), so on a support case answered by two people the
	 * second agent's replies were drawn exactly like the customer's own messages.
	 * An owner reading a thread genuinely could not tell whether a left-hand
	 * bubble came from the customer or from a teammate.
	 *
	 * So for AGENT viewers on a SUPPORT case only, every message written by a
	 * different agent gains `agent_name` (their real name — this side is internal,
	 * the customer-facing persona is a separate concern) and `is_teammate`.
	 *
	 * Deliberately NOT sent to customers: it would leak staff names into the
	 * browser of the very person the persona exists to hide them from.
	 *
	 * Fail-safe in the same shape as withAttachments()/withReactions(): any
	 * failure returns the payload untouched, so message listing cannot break.
	 *
	 * @since 1.32.15
	 * @param array<string, mixed> $result          List payload.
	 * @param int                  $conversation_id Conversation being listed.
	 * @return array<string, mixed>
	 */
	private function withAgentAttribution( array $result, int $conversation_id ): array {
		if ( empty( $result['messages'] ) || ! is_array( $result['messages'] ) ) {
			return $result;
		}

		$support_class = \ZymargCommunication\Modules\Support\Services\SupportService::class;
		if ( ! class_exists( $support_class ) || ! ServiceProvider::has( $support_class ) ) {
			return $result;
		}

		try {
			$support = ServiceProvider::get( $support_class );
			$me      = $this->currentUserId();

			// Customers never receive this. Non-support threads are untouched.
			if ( ! $support->isAgent( $me ) || ! $support->isSupportConversation( $conversation_id ) ) {
				return $result;
			}

			$names = array();
			foreach ( $result['messages'] as &$message ) {
				if ( ! is_array( $message ) || empty( $message['sender_id'] ) ) {
					continue;
				}
				$sender = (int) $message['sender_id'];
				if ( $sender === $me ) {
					continue; // "mine" already renders distinctly.
				}

				// Resolve each id at most once per request.
				if ( ! array_key_exists( $sender, $names ) ) {
					$names[ $sender ] = $support->isAgent( $sender )
						? ( ( $u = get_userdata( $sender ) ) ? (string) $u->display_name : '' )
						: '';
				}

				if ( '' !== $names[ $sender ] ) {
					$message['agent_name']  = $names[ $sender ];
					$message['is_teammate'] = true;
				}
			}
			unset( $message );
		} catch ( \Throwable $e ) {
			return $result;
		}

		return $result;
	}

	public function store( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle(
			function () use ( $request ) {
				$this->requireAuthenticated();
				$per_min = (int) apply_filters( 'zymarg_comm_rate_limit_per_minute', 30 );
				$limit   = RateLimitMiddleware::enforce( $request, 'message.send', $per_min > 0 ? $per_min : 30, 60 );
				if ( $limit instanceof \WP_Error ) {
					return $this->fail( 'rate_limited', (string) $limit->get_error_message(), 429 );
				}

				$body = (string) $request->get_param( 'body' );
				if ( '' === trim( wp_unslash( $body ) ) ) {
					throw new ValidationException( 'Body is required.', array( 'body' => 'Required.' ) );
				}

				$parent = $request->get_param( 'parent_id' );
				$parent = null !== $parent ? (int) $parent : null;

				return array(
					'message' => $this->messages->send( (int) $request->get_param( 'id' ), $this->currentUserId(), wp_unslash( $body ), $parent ),
				);
			}
		);
	}

	public function update( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle(
			function () use ( $request ) {
				$this->requireAuthenticated();
				return array(
					'message' => $this->messages->edit(
						(int) $request->get_param( 'id' ),
						$this->currentUserId(),
						(string) wp_unslash( (string) $request->get_param( 'body' ) )
					),
				);
			}
		);
	}

	public function destroy( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle(
			function () use ( $request ) {
				$this->requireAuthenticated();
				return array(
					'deleted' => $this->messages->delete( (int) $request->get_param( 'id' ), $this->currentUserId() ),
				);
			}
		);
	}

	public function react( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle(
			function () use ( $request ) {
				$this->requireAuthenticated();
				$this->reactions->addReaction(
					(int) $request->get_param( 'id' ),
					$this->currentUserId(),
					(string) $request->get_param( 'emoji' )
				);
				return array( 'reactions' => $this->reactions->forMessage( (int) $request->get_param( 'id' ) ) );
			}
		);
	}

	public function unreact( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle(
			function () use ( $request ) {
				$this->requireAuthenticated();
				$this->reactions->removeReaction(
					(int) $request->get_param( 'id' ),
					$this->currentUserId(),
					(string) $request->get_param( 'emoji' )
				);
				return array( 'reactions' => $this->reactions->forMessage( (int) $request->get_param( 'id' ) ) );
			}
		);
	}

	public function markRead( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle(
			function () use ( $request ) {
				$this->requireAuthenticated();
				$count = $this->receipts->markRead(
					(int) $request->get_param( 'id' ),
					$this->currentUserId(),
					(int) $request->get_param( 'before_message_id' )
				);
				return array( 'read_count' => $count );
			}
		);
	}

	/**
	 * Enrich each message in a list payload with its stored attachments,
	 * adding a browsable `url` derived from the stored `file_path` (mapped from
	 * the uploads basedir to baseurl). Fully defensive: any failure leaves the
	 * payload untouched so message listing can never break.
	 *
	 * @param array<string, mixed> $result
	 * @return array<string, mixed>
	 */
	private function withAttachments( array $result ): array {
		if ( empty( $result['messages'] ) || ! is_array( $result['messages'] ) ) {
			return $result;
		}
		if ( ! ServiceProvider::has( AttachmentService::class ) ) {
			return $result;
		}
		$service = ServiceProvider::get( AttachmentService::class );
		if ( ! $service instanceof AttachmentService ) {
			return $result;
		}

		$uploads = wp_upload_dir( null, false );
		$basedir = isset( $uploads['basedir'] ) ? (string) $uploads['basedir'] : '';
		$baseurl = isset( $uploads['baseurl'] ) ? (string) $uploads['baseurl'] : '';

		foreach ( $result['messages'] as &$message ) {
			if ( ! is_array( $message ) || empty( $message['id'] ) ) {
				continue;
			}
			try {
				$items = $service->forMessage( (int) $message['id'] );
			} catch ( \Throwable $e ) {
				$items = array();
			}
			$out = array();
			foreach ( (array) $items as $item ) {
				if ( ! is_array( $item ) ) {
					continue;
				}
				$path = isset( $item['file_path'] ) ? (string) $item['file_path'] : '';
				$url  = '';
				if ( '' !== $path && '' !== $basedir && '' !== $baseurl && 0 === strpos( $path, $basedir ) ) {
					$url = $baseurl . substr( $path, strlen( $basedir ) );
				}
				$out[] = array(
					'id'        => isset( $item['id'] ) ? (int) $item['id'] : 0,
					'file_name' => isset( $item['file_name'] ) ? (string) $item['file_name'] : '',
					'mime_type' => isset( $item['mime_type'] ) ? (string) $item['mime_type'] : '',
					'file_size' => isset( $item['file_size'] ) ? (int) $item['file_size'] : 0,
					'width'     => isset( $item['width'] ) ? (int) $item['width'] : null,
					'height'    => isset( $item['height'] ) ? (int) $item['height'] : null,
					'url'       => $url,
				);
			}
			$message['attachments'] = $out;
		}
		unset( $message );

		return $result;
	}

	private function withReactions( array $result ): array {
		if ( empty( $result['messages'] ) || ! is_array( $result['messages'] ) ) {
			return $result;
		}
		foreach ( $result['messages'] as &$message ) {
			if ( ! is_array( $message ) || empty( $message['id'] ) ) {
				continue;
			}
			try {
				$rows = $this->reactions->forMessage( (int) $message['id'] );
			} catch ( \Throwable $e ) {
				$rows = array();
			}
			$out = array();
			foreach ( (array) $rows as $r ) {
				if ( ! is_array( $r ) || empty( $r['emoji'] ) ) {
					continue;
				}
				$out[] = array(
					'user_id' => isset( $r['user_id'] ) ? (int) $r['user_id'] : 0,
					'emoji'   => (string) $r['emoji'],
				);
			}
			$message['reactions'] = $out;
		}
		unset( $message );

		return $result;
	}
}
