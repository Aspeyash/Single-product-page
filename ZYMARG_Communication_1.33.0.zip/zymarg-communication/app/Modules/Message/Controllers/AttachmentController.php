<?php
/**
 * REST endpoints for uploading and retrieving attachments.
 *
 * With the Security module in place, uploads are open to any authenticated
 * user (nonce-verified). The Security module handles all file validation,
 * magic-byte checks, EXIF stripping, and safe storage.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Message\Controllers;

use WP_REST_Request;
use WP_REST_Response;
use ZymargCommunication\Core\Abstracts\AbstractController;
use ZymargCommunication\Core\Exceptions\NotFoundException;
use ZymargCommunication\Core\Exceptions\ValidationException;
use ZymargCommunication\Infrastructure\Http\Middleware\AuthMiddleware;
use ZymargCommunication\Infrastructure\Http\Middleware\NonceMiddleware;
use ZymargCommunication\Modules\Message\Repositories\AttachmentRepository;
use ZymargCommunication\Modules\Message\Services\AttachmentService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AttachmentController extends AbstractController {

	public function __construct(
		private AttachmentService $service,
		private AttachmentRepository $repository
	) {}

	public function registerRoutes(): void {
		register_rest_route(
			self::NAMESPACE,
			'/attachments',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'store' ),
				'permission_callback' => array( $this, 'writeGuard' ),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/attachments/(?P<id>\\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'show' ),
				'permission_callback' => array( AuthMiddleware::class, 'requireLoggedIn' ),
			)
		);
	}

	public function writeGuard( WP_REST_Request $request ): bool|\WP_Error {
		$auth = AuthMiddleware::requireLoggedIn( $request );
		if ( $auth instanceof \WP_Error ) {
			return $auth;
		}
		return NonceMiddleware::verify( $request );
	}

	public function store( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle(
			function () use ( $request ) {
				$files = $request->get_file_params();
				$file  = $files['file'] ?? null;
				if ( ! is_array( $file ) || empty( $file['tmp_name'] ) ) {
					throw new ValidationException(
						__( 'No file was uploaded.', 'zymarg-communication' ),
						array( 'file' => 'required' )
					);
				}

				return array(
					'attachment' => $this->service->ingest(
						$file,
						array(
							'message_id'  => (int) $request->get_param( 'message_id' ),
							'uploader_id' => $this->currentUserId(),
						)
					),
				);
			}
		);
	}

	public function show( WP_REST_Request $request ): WP_REST_Response {
		return $this->handle(
			function () use ( $request ) {
				$this->requireAuthenticated();
				$model = $this->repository->findModel( (int) $request->get_param( 'id' ) );
				if ( ! $model ) {
					throw new NotFoundException( __( 'Attachment not found.', 'zymarg-communication' ) );
				}
				return array( 'attachment' => $model->toArray() );
			}
		);
	}
}
