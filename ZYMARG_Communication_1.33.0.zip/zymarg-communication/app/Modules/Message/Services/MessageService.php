<?php
/**
 * Send, edit, delete, and retrieve messages. Enforces reply threading.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Message\Services;

use ZymargCommunication\Bootstrap\ServiceProvider;
use ZymargCommunication\Core\Abstracts\AbstractService;
use ZymargCommunication\Core\Exceptions\DatabaseException;
use ZymargCommunication\Core\Exceptions\NotFoundException;
use ZymargCommunication\Core\Exceptions\UnauthorizedException;
use ZymargCommunication\Core\Exceptions\ValidationException;
use ZymargCommunication\Core\Helpers\SanitizeHelper;
use ZymargCommunication\Modules\Conversation\Services\ConversationService;
use ZymargCommunication\Modules\Message\Repositories\MessageRepository;
use ZymargCommunication\Modules\Conversation\Repositories\ParticipantRepository;
use ZymargCommunication\Modules\Moderation\Services\BlocklistService;
use ZymargCommunication\Modules\Moderation\Services\ModerationService;
use ZymargCommunication\Modules\Moderation\Services\SpamFilterService;
use ZymargCommunication\Shared\Events\EventDispatcher;
use ZymargCommunication\Shared\Events\MessageSent;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class MessageService extends AbstractService {

	public function __construct(
		private MessageRepository $repository,
		private ConversationService $conversations,
		private ?BlocklistService $blocklist = null,
		private ?SpamFilterService $spam = null,
		private ?ModerationService $moderation = null,
		private ?ParticipantRepository $participants = null
	) {}

	/**
	 * Send a message.
	 *
	 * @return array<string, mixed>
	 */
	public function send( int $conversation_id, int $sender_id, string $body, ?int $parent_id = null ): array {
		$this->conversations->assertMemberOrAdmin( $conversation_id, $sender_id );

		// 1.33.0 — support case ownership. Enforced BEFORE storage, alongside the
		// moderation gates below, so a blocked reply is never written and then
		// retracted. Fails open on every uncertainty: see the guard method.
		$this->assertSupportCaseUnlocked( $conversation_id, $sender_id );

		$body = SanitizeHelper::messageBody( $body );
		if ( '' === $body ) {
			throw new ValidationException( __( 'Message body cannot be empty.', 'zymarg-communication' ), array( 'body' => 'Required.' ) );
		}

		// Moderation gate: blocklist → spam. Both are enforced BEFORE storage.
		if ( $this->blocklist && $this->participants ) {
			$recipients = array();
			foreach ( $this->participants->findForConversation( $conversation_id ) as $p ) {
				if ( $p->userId !== $sender_id ) {
					$recipients[] = $p->userId;
				}
			}
			if ( $this->blocklist->isSenderBlocked( $sender_id, $recipients ) ) {
				if ( $this->moderation ) {
					$this->moderation->recordSystemFlag( $conversation_id, 'user_blocked' );
				}
				throw new UnauthorizedException( __( 'You cannot send messages to this conversation.', 'zymarg-communication' ) );
			}
			$word = $this->blocklist->firstBlockedWord( $body );
			if ( null !== $word ) {
				if ( $this->moderation ) {
					$this->moderation->recordSystemFlag( $conversation_id, 'profanity_filtered', sprintf( __( 'Blocked word: %s', 'zymarg-communication' ), $word ) );
				}
				throw new ValidationException( __( 'Your message contains a blocked word.', 'zymarg-communication' ), array( 'body' => 'blocked_word' ) );
			}
		}

		if ( $this->spam && $this->isEnabled( 'moderation.spam_filter' ) ) {
			$verdict = $this->spam->analyse( $body, $sender_id );
			if ( ! empty( $verdict['is_spam'] ) ) {
				if ( $this->moderation ) {
					$this->moderation->recordSystemFlag( $conversation_id, 'spam_detected', (string) ( $verdict['reason'] ?? '' ) );
				}
				throw new ValidationException( __( 'Your message was flagged as spam.', 'zymarg-communication' ), array( 'body' => 'spam' ) );
			}
		}

		if ( null !== $parent_id ) {
			if ( ! $this->isEnabled( 'message.replies' ) ) {
				$parent_id = null;
			} else {
				$parent = $this->repository->findModel( $parent_id );
				if ( ! $parent || $parent->conversationId !== $conversation_id ) {
					throw new ValidationException( __( 'Parent message does not belong to this conversation.', 'zymarg-communication' ), array( 'parent_id' => 'Invalid.' ) );
				}
			}
		}

		$id = $this->repository->create(
			array(
				'conversation_id' => $conversation_id,
				'sender_id'       => $sender_id,
				'parent_id'       => $parent_id,
				'body'            => $body,
				'status'          => $this->isEnabled( 'message.delivered_status' ) ? 'delivered' : 'sending',
			)
		);

		if ( 0 === $id ) {
			throw new DatabaseException( __( 'Failed to store message.', 'zymarg-communication' ) );
		}

		$this->conversations->touchLastMessageAt( $conversation_id );

		if ( ServiceProvider::has( EventDispatcher::class ) ) {
			$dispatcher = ServiceProvider::get( EventDispatcher::class );
			if ( $dispatcher instanceof EventDispatcher ) {
				$dispatcher->dispatch( new MessageSent( $id, $conversation_id, $sender_id, $body, $parent_id ) );
			}
		}

		$model = $this->repository->findModel( $id );
		return $model ? $model->toArray() : array();
	}

	/**
	 * Stop a second agent replying to a case a colleague already owns (1.33.0).
	 *
	 * This is the ONLY code path in the plugin that can refuse a reply, so the
	 * fail-open contract is enforced structurally rather than by convention:
	 * SupportCaseLock::denialReason() returns a STRING, and this method throws
	 * only on a non-empty one. Every other outcome — the Support module absent,
	 * the service not registered, the container throwing, the ticket table not
	 * migrated, any exception anywhere inside the lock — yields '' and the reply
	 * proceeds untouched.
	 *
	 * Non-support conversations (the marketplace buyer/vendor threads, which are
	 * the overwhelming majority of traffic) short-circuit inside the lock before
	 * any database work is done.
	 *
	 * @throws UnauthorizedException When a different, still-valid agent owns it.
	 */
	private function assertSupportCaseUnlocked( int $conversation_id, int $sender_id ): void {
		$lock_class = \ZymargCommunication\Modules\Support\Services\SupportCaseLock::class;

		if ( ! class_exists( $lock_class ) ) {
			return;
		}

		$reason = '';

		try {
			if ( ! ServiceProvider::has( $lock_class ) ) {
				return;
			}

			$lock = ServiceProvider::get( $lock_class );
			if ( ! $lock instanceof $lock_class ) {
				return;
			}

			$reason = (string) $lock->denialReason( $conversation_id, $sender_id );
		} catch ( \Throwable $e ) {
			// A broken guard must never be the reason a customer goes unanswered.
			return;
		}

		if ( '' !== $reason ) {
			throw new UnauthorizedException( $reason );
		}
	}

	/**
	 * List messages in a conversation, paginated.
	 *
	 * @return array<string, mixed>
	 */
	public function listForConversation( int $conversation_id, int $user_id, int $limit = 30, int $offset = 0 ): array {
		$this->conversations->assertMemberOrAdmin( $conversation_id, $user_id );

		$limit  = max( 1, min( 100, $limit ) );
		$offset = max( 0, $offset );

		$rows = $this->repository->findForConversation( $conversation_id, $limit, $offset );
		return array(
			'messages' => array_map( fn( $m ) => $m->toArray(), $rows ),
			'total'    => $this->repository->countForConversation( $conversation_id ),
			'limit'    => $limit,
			'offset'   => $offset,
		);
	}

	/**
	 * Load the MOST RECENT page of a conversation, still in chronological order.
	 *
	 * listForConversation() defaults to offset 0, and findForConversation()
	 * orders by created_at ASC -- so the default window is the OLDEST $limit
	 * messages. Every thread view (buyer inbox, vendor inbox and the live-chat
	 * popup) requests messages without an offset, so as soon as a conversation
	 * grew past $limit messages the newest ones fell outside that window and the
	 * thread pane froze permanently. The conversation list kept updating because
	 * it fetches the latest message separately for its preview.
	 *
	 * @return array<string, mixed>
	 */
	public function listLatestForConversation( int $conversation_id, int $user_id, int $limit = 30 ): array {
		$this->conversations->assertMemberOrAdmin( $conversation_id, $user_id );

		$limit  = max( 1, min( 100, $limit ) );
		$total  = $this->repository->countForConversation( $conversation_id );
		$offset = max( 0, $total - $limit );

		$rows = $this->repository->findForConversation( $conversation_id, $limit, $offset );

		return array(
			'messages' => array_map( fn( $m ) => $m->toArray(), $rows ),
			'total'    => $total,
			'limit'    => $limit,
			'offset'   => $offset,
		);
	}

	public function edit( int $message_id, int $editor_id, string $body ): array {
		$message = $this->repository->findModel( $message_id );
		if ( ! $message ) {
			throw new NotFoundException( __( 'Message not found.', 'zymarg-communication' ) );
		}
		if ( $message->senderId !== $editor_id && ! user_can( $editor_id, 'manage_options' ) ) {
			throw new UnauthorizedException( __( 'You may only edit your own messages.', 'zymarg-communication' ) );
		}

		$body = SanitizeHelper::messageBody( $body );
		if ( '' === $body ) {
			throw new ValidationException( __( 'Message body cannot be empty.', 'zymarg-communication' ), array( 'body' => 'Required.' ) );
		}

		$this->repository->updateBody( $message_id, $body );
		$updated = $this->repository->findModel( $message_id );
		return $updated ? $updated->toArray() : array();
	}

	public function delete( int $message_id, int $actor_id ): bool {
		$message = $this->repository->findModel( $message_id );
		if ( ! $message ) {
			throw new NotFoundException( __( 'Message not found.', 'zymarg-communication' ) );
		}
		if ( $message->senderId !== $actor_id && ! user_can( $actor_id, 'manage_options' ) ) {
			throw new UnauthorizedException( __( 'You may only delete your own messages.', 'zymarg-communication' ) );
		}
		return $this->repository->softDelete( $message_id );
	}

	public function findOwned( int $message_id ): \ZymargCommunication\Modules\Message\Models\Message {
		$message = $this->repository->findModel( $message_id );
		if ( ! $message ) {
			throw new NotFoundException( __( 'Message not found.', 'zymarg-communication' ) );
		}
		return $message;
	}
}
