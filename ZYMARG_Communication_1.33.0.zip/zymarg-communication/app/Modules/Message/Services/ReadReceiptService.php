<?php
/**
 * Mark messages as delivered and read.
 *
 * Must never be called for admin reads. Admin conversation reads route through
 * `AdminViewService` (Phase 6) exclusively, and admins are excluded from this
 * service via a defensive short-circuit.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Message\Services;

use ZymargCommunication\Core\Abstracts\AbstractService;
use ZymargCommunication\Modules\Conversation\Services\ConversationService;
use ZymargCommunication\Modules\Conversation\Services\ParticipantService;
use ZymargCommunication\Modules\Message\Repositories\MessageRepository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ReadReceiptService extends AbstractService {

	public function __construct(
		private MessageRepository $messages,
		private ParticipantService $participants,
		private ConversationService $conversations
	) {}

	/**
	 * Mark every message in a conversation up to `$before_message_id` as read
	 * for the given reader. Silent no-op when the reader is an admin or the
	 * `message.read_receipts` flag is disabled.
	 *
	 * @return int Number of messages transitioned to `read`.
	 */
	public function markRead( int $conversation_id, int $reader_id, int $before_message_id ): int {
		if ( ! $this->isEnabled( 'message.read_receipts' ) ) {
			return 0;
		}

		// Admin privacy contract: admin reads never generate receipts.
		if ( user_can( $reader_id, 'manage_options' ) ) {
			return 0;
		}

		if ( ! $this->participants->isParticipant( $conversation_id, $reader_id ) ) {
			return 0;
		}

		$affected = $this->messages->markRead( $conversation_id, $before_message_id, $reader_id );
		$this->participants->markRead( $conversation_id, $reader_id );

		do_action( 'zymarg_comm_messages_read', $conversation_id, $reader_id, $before_message_id, $affected );
		return $affected;
	}
}
