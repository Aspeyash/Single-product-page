<?php
/**
 * AttachmentService — accepts a raw upload, delegates validation and
 * safe storage to SecurityService, and records the attachment metadata.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Message\Services;

use ZymargCommunication\Core\Abstracts\AbstractService;
use ZymargCommunication\Core\Exceptions\ValidationException;
use ZymargCommunication\Modules\Message\Repositories\AttachmentRepository;
use ZymargCommunication\Modules\Security\Services\SecurityService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AttachmentService extends AbstractService {

	public function __construct(
		private AttachmentRepository $repository,
		private ?SecurityService $security = null
	) {}

	/**
	 * Ingest a raw `$_FILES[...]` array. Validates via SecurityService,
	 * strips EXIF, moves to protected storage, then records the row.
	 *
	 * @param array<string,mixed> $file
	 * @param array<string,mixed> $context  message_id, uploader_id
	 */
	public function ingest( array $file, array $context ): array {
		if ( ! $this->isEnabled( 'message.attachments' ) ) {
			throw new ValidationException( __( 'Attachments are disabled.', 'zymarg-communication' ), array( 'attachments' => 'disabled' ) );
		}
		if ( ! $this->security ) {
			throw new ValidationException( __( 'Attachment pipeline is unavailable.', 'zymarg-communication' ), array( 'security' => 'unavailable' ) );
		}

		$result = $this->security->ingestUpload( $file );
		if ( empty( $result['ok'] ) ) {
			throw new ValidationException( (string) ( $result['error'] ?? __( 'Upload rejected.', 'zymarg-communication' ) ), array( 'file' => (string) ( $result['error'] ?? 'rejected' ) ) );
		}

		$stored = $result['file'];
		return $this->record(
			array(
				'message_id'  => (int) ( $context['message_id'] ?? 0 ),
				'uploader_id' => (int) ( $context['uploader_id'] ?? 0 ),
				'file_path'   => (string) $stored['path'],
				'file_name'   => (string) $stored['filename'],
				'mime_type'   => (string) $stored['mime'],
				'file_size'   => (int) $stored['file_size'],
				'width'       => $stored['width'] ?? null,
				'height'      => $stored['height'] ?? null,
				'url'         => (string) ( $stored['url'] ?? '' ),
			)
		);
	}

	public function record( array $attributes ): array {
		if ( ! $this->isEnabled( 'message.attachments' ) ) {
			return array();
		}
		$id    = $this->repository->create( $attributes );
		$model = $this->repository->findModel( $id );
		return $model ? $model->toArray() : array();
	}

	public function forMessage( int $message_id ): array {
		return array_map( fn( $a ) => $a->toArray(), $this->repository->findForMessage( $message_id ) );
	}
}
