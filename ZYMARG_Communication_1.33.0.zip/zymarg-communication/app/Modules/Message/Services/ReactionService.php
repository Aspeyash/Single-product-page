<?php
/**
 * Add and remove emoji reactions on messages.
 *
 * Gated by the `message.reactions` feature flag: when disabled every method
 * is a silent no-op per CONTRIBUTING § 3 and § 15.1.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Message\Services;

use ZymargCommunication\Core\Abstracts\AbstractService;
use ZymargCommunication\Core\Exceptions\NotFoundException;
use ZymargCommunication\Core\Exceptions\UnauthorizedException;
use ZymargCommunication\Core\Helpers\SanitizeHelper;
use ZymargCommunication\Modules\Conversation\Services\ConversationService;
use ZymargCommunication\Modules\Message\Repositories\MessageRepository;
use ZymargCommunication\Modules\Message\Repositories\ReactionRepository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ReactionService extends AbstractService {

	public function __construct(
		private ReactionRepository $reactions,
		private MessageRepository $messages,
		private ConversationService $conversations
	) {}

	public function addReaction( int $message_id, int $user_id, string $emoji ): void {
		if ( ! $this->isEnabled( 'message.reactions' ) ) {
			return; // Silent no-op.
		}

		$message = $this->messages->findModel( $message_id );
		if ( ! $message ) {
			throw new NotFoundException( __( 'Message not found.', 'zymarg-communication' ) );
		}
		$this->conversations->assertMemberOrAdmin( $message->conversationId, $user_id );

		$emoji = SanitizeHelper::emoji( $emoji );
		if ( '' === $emoji ) {
			return;
		}

		$this->reactions->add( $message_id, $user_id, $emoji );
	}

	public function removeReaction( int $message_id, int $user_id, string $emoji ): void {
		if ( ! $this->isEnabled( 'message.reactions' ) ) {
			return;
		}

		$message = $this->messages->findModel( $message_id );
		if ( ! $message ) {
			throw new NotFoundException( __( 'Message not found.', 'zymarg-communication' ) );
		}
		$this->conversations->assertMemberOrAdmin( $message->conversationId, $user_id );

		$emoji = SanitizeHelper::emoji( $emoji );
		if ( '' === $emoji ) {
			return;
		}

		$this->reactions->remove( $message_id, $user_id, $emoji );
	}

	public function forMessage( int $message_id ): array {
		if ( ! $this->isEnabled( 'message.reactions' ) ) {
			return array();
		}
		return array_map( fn( $r ) => $r->toArray(), $this->reactions->findForMessage( $message_id ) );
	}
}
