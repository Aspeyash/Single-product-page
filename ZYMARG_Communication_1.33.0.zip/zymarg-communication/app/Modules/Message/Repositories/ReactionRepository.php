<?php
/**
 * All database reads and writes for the `zc_reactions` table.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Message\Repositories;

use ZymargCommunication\Core\Abstracts\AbstractRepository;
use ZymargCommunication\Modules\Message\Models\Reaction;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ReactionRepository extends AbstractRepository {

	protected function tableSuffix(): string {
		return 'zc_reactions';
	}

	/** @return array<int, Reaction> */
	public function findForMessage( int $message_id ): array {
		$rows = $this->wpdb->get_results(
			$this->wpdb->prepare( 'SELECT * FROM `' . $this->table() . '` WHERE message_id = %d ORDER BY id ASC', $message_id )
		);
		if ( ! is_array( $rows ) ) {
			return array();
		}
		return array_map( array( Reaction::class, 'fromRow' ), $rows );
	}

	public function findOne( int $message_id, int $user_id, string $emoji ): ?Reaction {
		$row = $this->wpdb->get_row(
			$this->wpdb->prepare(
				'SELECT * FROM `' . $this->table() . '` WHERE message_id = %d AND user_id = %d AND emoji = %s LIMIT 1',
				$message_id,
				$user_id,
				$emoji
			)
		);
		return $row ? Reaction::fromRow( $row ) : null;
	}

	public function add( int $message_id, int $user_id, string $emoji ): int {
		$existing = $this->findOne( $message_id, $user_id, $emoji );
		if ( $existing ) {
			return $existing->id;
		}
		return $this->insert(
			array(
				'message_id' => $message_id,
				'user_id'    => $user_id,
				'emoji'      => $emoji,
				'created_at' => current_time( 'mysql', true ),
			)
		);
	}

	public function remove( int $message_id, int $user_id, string $emoji ): bool {
		$affected = $this->wpdb->delete(
			$this->table(),
			array(
				'message_id' => $message_id,
				'user_id'    => $user_id,
				'emoji'      => $emoji,
			)
		);
		return false !== $affected && $affected > 0;
	}
}
