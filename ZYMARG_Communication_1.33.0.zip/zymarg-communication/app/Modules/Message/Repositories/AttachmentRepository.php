<?php
/**
 * All database reads and writes for the `zc_attachments` table.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Message\Repositories;

use ZymargCommunication\Core\Abstracts\AbstractRepository;
use ZymargCommunication\Modules\Message\Models\Attachment;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AttachmentRepository extends AbstractRepository {

	protected function tableSuffix(): string {
		return 'zc_attachments';
	}

	public function findModel( int $id ): ?Attachment {
		$row = $this->find( $id );
		return $row ? Attachment::fromRow( $row ) : null;
	}

	/** @return array<int, Attachment> */
	public function findForMessage( int $message_id ): array {
		$rows = $this->wpdb->get_results(
			$this->wpdb->prepare( 'SELECT * FROM `' . $this->table() . '` WHERE message_id = %d ORDER BY id ASC', $message_id )
		);
		if ( ! is_array( $rows ) ) {
			return array();
		}
		return array_map( array( Attachment::class, 'fromRow' ), $rows );
	}

	public function create( array $data ): int {
		return $this->insert(
			array(
				'message_id'  => (int) $data['message_id'],
				'uploader_id' => (int) $data['uploader_id'],
				'file_path'   => (string) $data['file_path'],
				'file_name'   => (string) $data['file_name'],
				'mime_type'   => (string) $data['mime_type'],
				'file_size'   => (int) $data['file_size'],
				'width'       => isset( $data['width'] ) ? (int) $data['width'] : null,
				'height'      => isset( $data['height'] ) ? (int) $data['height'] : null,
				'created_at'  => current_time( 'mysql', true ),
			)
		);
	}
}
