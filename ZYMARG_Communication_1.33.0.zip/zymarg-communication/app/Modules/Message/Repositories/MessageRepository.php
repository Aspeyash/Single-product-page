<?php
/**
 * All database reads and writes for the `zc_messages` table.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Message\Repositories;

use ZymargCommunication\Core\Abstracts\AbstractRepository;
use ZymargCommunication\Modules\Message\Models\Message;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class MessageRepository extends AbstractRepository {

	protected function tableSuffix(): string {
		return 'zc_messages';
	}

	public function findModel( int $id ): ?Message {
		$row = $this->find( $id );
		return $row ? Message::fromRow( $row ) : null;
	}

	/** @return array<int, Message> */
	public function findForConversation( int $conversation_id, int $limit = 30, int $offset = 0 ): array {
		$sql = $this->wpdb->prepare(
			'SELECT * FROM `' . $this->table() . '` '
			. "WHERE conversation_id = %d AND lifecycle_status <> 'deleted' "
			. 'ORDER BY created_at ASC LIMIT %d OFFSET %d',
			$conversation_id,
			$limit,
			$offset
		);
		$rows = $this->wpdb->get_results( $sql );
		if ( ! is_array( $rows ) ) {
			return array();
		}
		return array_map( array( Message::class, 'fromRow' ), $rows );
	}

	public function countForConversation( int $conversation_id ): int {
		return (int) $this->wpdb->get_var(
			$this->wpdb->prepare(
				'SELECT COUNT(*) FROM `' . $this->table() . "` WHERE conversation_id = %d AND lifecycle_status <> 'deleted'",
				$conversation_id
			)
		);
	}

	public function create( array $data ): int {
		$now = current_time( 'mysql', true );
		return $this->insert(
			array(
				'conversation_id'  => (int) $data['conversation_id'],
				'sender_id'        => (int) $data['sender_id'],
				'parent_id'        => isset( $data['parent_id'] ) ? (int) $data['parent_id'] : null,
				'body'             => (string) $data['body'],
				'status'           => $data['status'] ?? 'delivered',
				'lifecycle_status' => $data['lifecycle_status'] ?? 'active',
				'created_at'       => $now,
				'updated_at'       => $now,
			)
		);
	}

	public function updateBody( int $id, string $body ): bool {
		return $this->update(
			$id,
			array(
				'body'       => $body,
				'updated_at' => current_time( 'mysql', true ),
			)
		);
	}

	public function softDelete( int $id ): bool {
		return $this->update(
			$id,
			array(
				'lifecycle_status' => 'deleted',
				'deleted_at'       => current_time( 'mysql', true ),
				'updated_at'       => current_time( 'mysql', true ),
			)
		);
	}

	public function markRead( int $conversation_id, int $before_message_id, int $reader_id ): int {
		$affected = $this->wpdb->query(
			$this->wpdb->prepare(
				'UPDATE `' . $this->table() . "` SET status = 'read', updated_at = %s "
				. "WHERE conversation_id = %d AND sender_id <> %d AND id <= %d AND status <> 'read'",
				current_time( 'mysql', true ),
				$conversation_id,
				$reader_id,
				$before_message_id
			)
		);
		return (int) $affected;
	}
}
