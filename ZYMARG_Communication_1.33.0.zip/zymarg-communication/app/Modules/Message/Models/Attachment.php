<?php
/**
 * Plain data object representing an attachment record.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Message\Models;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Attachment {

	public function __construct(
		public int $id,
		public int $messageId,
		public int $uploaderId,
		public string $filePath,
		public string $fileName,
		public string $mimeType,
		public int $fileSize,
		public ?int $width,
		public ?int $height,
		public string $createdAt
	) {}

	public static function fromRow( object $row ): self {
		return new self(
			(int) $row->id,
			(int) $row->message_id,
			(int) $row->uploader_id,
			(string) $row->file_path,
			(string) $row->file_name,
			(string) $row->mime_type,
			(int) $row->file_size,
			isset( $row->width ) && null !== $row->width ? (int) $row->width : null,
			isset( $row->height ) && null !== $row->height ? (int) $row->height : null,
			(string) $row->created_at
		);
	}

	public function toArray(): array {
		return array(
			'id'          => $this->id,
			'message_id'  => $this->messageId,
			'uploader_id' => $this->uploaderId,
			'file_path'   => $this->filePath,
			'file_name'   => $this->fileName,
			'mime_type'   => $this->mimeType,
			'file_size'   => $this->fileSize,
			'width'       => $this->width,
			'height'      => $this->height,
			'created_at'  => $this->createdAt,
		);
	}
}
