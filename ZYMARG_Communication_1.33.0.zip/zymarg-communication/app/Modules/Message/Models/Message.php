<?php
/**
 * Plain data object representing a message record.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Message\Models;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Message {

	public function __construct(
		public int $id,
		public int $conversationId,
		public int $senderId,
		public ?int $parentId,
		public string $body,
		public string $status,
		public string $lifecycleStatus,
		public ?string $archivedAt,
		public ?string $deletedAt,
		public string $createdAt,
		public string $updatedAt
	) {}

	public static function fromRow( object $row ): self {
		return new self(
			(int) $row->id,
			(int) $row->conversation_id,
			(int) $row->sender_id,
			isset( $row->parent_id ) && null !== $row->parent_id ? (int) $row->parent_id : null,
			(string) $row->body,
			(string) $row->status,
			(string) $row->lifecycle_status,
			$row->archived_at ?? null,
			$row->deleted_at ?? null,
			(string) $row->created_at,
			(string) $row->updated_at
		);
	}

	public function toArray(): array {
		return array(
			'id'               => $this->id,
			'conversation_id'  => $this->conversationId,
			'sender_id'        => $this->senderId,
			'parent_id'        => $this->parentId,
			'body'             => $this->body,
			'status'           => $this->status,
			'lifecycle_status' => $this->lifecycleStatus,
			'archived_at'      => $this->archivedAt,
			'deleted_at'       => $this->deletedAt,
			'created_at'       => $this->createdAt,
			'updated_at'       => $this->updatedAt,
		);
	}
}
