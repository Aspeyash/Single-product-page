<?php
/**
 * Plain data object representing a reaction record.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Message\Models;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Reaction {

	public function __construct(
		public int $id,
		public int $messageId,
		public int $userId,
		public string $emoji,
		public string $createdAt
	) {}

	public static function fromRow( object $row ): self {
		return new self(
			(int) $row->id,
			(int) $row->message_id,
			(int) $row->user_id,
			(string) $row->emoji,
			(string) $row->created_at
		);
	}

	public function toArray(): array {
		return array(
			'id'         => $this->id,
			'message_id' => $this->messageId,
			'user_id'    => $this->userId,
			'emoji'      => $this->emoji,
			'created_at' => $this->createdAt,
		);
	}
}
