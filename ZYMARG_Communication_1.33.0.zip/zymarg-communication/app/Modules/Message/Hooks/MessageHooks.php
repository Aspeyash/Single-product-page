<?php
/**
 * Registers WordPress actions and filters owned by the Message module.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Modules\Message\Hooks;

use ZymargCommunication\Bootstrap\ServiceProvider;
use ZymargCommunication\Core\Contracts\HookableInterface;
use ZymargCommunication\Infrastructure\Http\Controllers\RestController;
use ZymargCommunication\Modules\Message\Controllers\AttachmentController;
use ZymargCommunication\Modules\Message\Controllers\MessageController;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class MessageHooks implements HookableInterface {

	public static function register(): void {
		$instance = new self();
		$instance->registerHooks();
	}

	private function registerHooks(): void {
		if ( ServiceProvider::has( MessageController::class ) ) {
			$messages = ServiceProvider::get( MessageController::class );
			if ( $messages instanceof MessageController ) {
				RestController::register( $messages );
			}
		}

		if ( ServiceProvider::has( AttachmentController::class ) ) {
			$attachments = ServiceProvider::get( AttachmentController::class );
			if ( $attachments instanceof AttachmentController ) {
				RestController::register( $attachments );
			}
		}
	}
}
