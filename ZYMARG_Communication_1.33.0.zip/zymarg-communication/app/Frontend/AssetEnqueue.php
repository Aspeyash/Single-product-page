<?php
/**
 * ZYMARG Communication — Frontend asset enqueue.
 *
 * Enqueues the inbox + live-chat CSS/JS and exposes the `zymargLiveChat`
 * JavaScript global that the ZYMARG Vendor Dashboard plugin (line 548)
 * already expects.
 *
 * @package    ZymargCommunication
 * @version    1.12.0
 */

namespace ZymargCommunication\Frontend;

use ZymargCommunication\Bootstrap\ServiceProvider;
use ZymargCommunication\Modules\FeatureFlags\Services\FeatureFlagService;
use ZymargCommunication\Modules\Marketplace\Services\StorePopupService;
use ZymargCommunication\Modules\Settings\Services\PopupSettingsService;
use ZymargCommunication\Modules\Support\Services\SupportService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AssetEnqueue {

	public static function register(): void {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
	}

	public static function enqueue(): void {
		if ( ! is_user_logged_in() ) {
			return;
		}

		$base    = defined( 'ZYMARG_COMM_URL' ) ? ZYMARG_COMM_URL : plugin_dir_url( ZYMARG_COMM_FILE );
		$version = defined( 'ZYMARG_COMM_VERSION' ) ? ZYMARG_COMM_VERSION : '1.12.0';

		wp_enqueue_style(
			'zymarg-comm-tokens',
			$base . 'assets/css/frontend/zymarg-comm-tokens.css',
			array(),
			$version
		);
		wp_enqueue_style(
			'zymarg-inbox',
			$base . 'assets/css/frontend/inbox.css',
			array( 'zymarg-comm-tokens' ),
			$version
		);
		wp_enqueue_style(
			'zymarg-live-chat',
			$base . 'assets/css/frontend/live-chat.css',
			array( 'zymarg-comm-tokens' ),
			$version
		);

		wp_enqueue_script(
			'zymarg-inbox',
			$base . 'assets/js/frontend/inbox.js',
			array(),
			$version,
			true
		);
		wp_enqueue_script(
			'zymarg-live-chat',
			$base . 'assets/js/frontend/live-chat.js',
			array(),
			$version,
			true
		);
		// Admin<->User support trigger (1.25.0). Tiny, and a no-op on pages that
		// contain no support control.
		wp_enqueue_script(
			'zymarg-support',
			$base . 'assets/js/frontend/support.js',
			array(),
			$version,
			true
		);

		// Support ticket surface (1.27.0): Smart Intake + in-thread ticket panel.
		// support.js awaits window.zymargSupportIntake, so this must load first.
		wp_enqueue_style(
			'zymarg-support-ticket',
			$base . 'assets/css/frontend/support-ticket.css',
			array( 'zymarg-comm-tokens' ),
			$version
		);
		wp_enqueue_script(
			'zymarg-support-ticket',
			$base . 'assets/js/frontend/support-ticket.js',
			array(),
			$version,
			true
		);
		wp_localize_script(
			'zymarg-support-ticket',
			'zymargSupportTicket',
			self::ticketData()
		);

		wp_localize_script(
			'zymarg-live-chat',
			'zymargLiveChat',
			self::bootstrapData()
		);
	}

	/**
	 * Config for the support-ticket surface (Smart Intake + ticket panel).
	 *
	 * @return array<string, mixed>
	 */
	private static function ticketData(): array {
		$user_id  = get_current_user_id();
		$is_agent = false;
		if ( ServiceProvider::has( SupportService::class ) ) {
			try {
				$svc      = ServiceProvider::get( SupportService::class );
				$is_agent = $svc instanceof SupportService && $svc->isAgent( $user_id );
			} catch ( \Throwable $e ) {
				$is_agent = false;
			}
		}

		$symbol = '';
		if ( function_exists( 'get_woocommerce_currency_symbol' ) ) {
			$symbol = html_entity_decode( (string) get_woocommerce_currency_symbol() );
		}
		$currency = function_exists( 'get_woocommerce_currency' ) ? (string) get_woocommerce_currency() : '';

		// Smart Intake is owner-configurable (1.29.0): it can be switched off
		// entirely, and every string it shows is editable from Settings ->
		// Support. Editable copy overrides the shipped defaults.
		$intake_enabled = true;
		$strings        = self::ticketStrings();
		try {
			$intake         = new \ZymargCommunication\Modules\Support\Services\SupportIntakeSettings();
			$intake_enabled = $intake->enabled();
			$strings        = array_merge( $strings, $intake->frontendStrings() );
		} catch ( \Throwable $e ) {
			// Fall back to the shipped strings; never block asset output.
		}

		// 1.31.0 — helpline countdown copy. Separate try/catch so a failure here
		// cannot cost us the Smart Intake strings resolved just above.
		try {
			$session = new \ZymargCommunication\Modules\Support\Services\SupportSessionSettings();
			$strings = array_merge( $strings, $session->frontendStrings() );
		} catch ( \Throwable $e ) {
			// Shipped fallbacks in support-ticket.js cover this.
		}

		return array(
			'restUrl'         => esc_url_raw( rest_url( 'zymarg-comm/v1' ) ),
			'nonce'           => wp_create_nonce( 'wp_rest' ),
			'isAgent'         => $is_agent,
			'intakeEnabled'   => $intake_enabled,
			'currencySymbols' => $currency ? array( $currency => $symbol ) : array(),
			'i18n'            => $strings,
		);
	}

	/** @return array<string, string> */
	private static function ticketStrings(): array {
		return array(
			'intakeTitle'       => __( 'How can we help?', 'zymarg-communication' ),
			'whatAbout'         => __( 'What is this about?', 'zymarg-communication' ),
			'whichOrder'        => __( 'Is it about a recent order?', 'zymarg-communication' ),
			'tellUs'            => __( 'Tell us in one line', 'zymarg-communication' ),
			'subjectPlaceholder'=> __( 'e.g. Wrong size delivered', 'zymarg-communication' ),
			'startChat'         => __( 'Start chat', 'zymarg-communication' ),
			'cancel'            => __( 'Cancel', 'zymarg-communication' ),
			'close'             => __( 'Close', 'zymarg-communication' ),
			'markResolved'      => __( 'Mark resolved', 'zymarg-communication' ),
			'reopen'            => __( 'Reopen', 'zymarg-communication' ),
			'memberSince'       => __( 'Member since', 'zymarg-communication' ),
			'orders'            => __( 'orders', 'zymarg-communication' ),
			'vendor'            => __( 'Vendor', 'zymarg-communication' ),
			'priorTickets'      => __( 'previous tickets', 'zymarg-communication' ),
			'resolved'          => __( 'resolved', 'zymarg-communication' ),
			'howDidWeDo'        => __( 'How did we do?', 'zymarg-communication' ),
			'thanksRating'      => __( 'Thanks for your feedback!', 'zymarg-communication' ),
		);
	}

	/**
	 * @return array<string, mixed>
	 */
	private static function bootstrapData(): array {
		$user_id = get_current_user_id();
		$data    = array(
			'restUrl'     => esc_url_raw( rest_url( 'zymarg-comm/v1' ) ),
			'nonce'       => wp_create_nonce( 'wp_rest' ),
			'userId'      => $user_id,
			'driver'      => 'polling',
			'pollInterval'=> 15000,
			'enabled'     => self::isEnabled(),
			'reactions'   => self::flagEnabled( 'message.reactions' ),
			'replies'     => self::flagEnabled( 'message.replies' ),
			'typing_indicator'=> self::flagEnabled( 'message.typing_indicator' ),
			'online_status'=> self::flagEnabled( 'message.online_status' ),
			'inboxUrl'    => self::inboxUrl(),
			// Popup auto-open is opt-in per page (Communication -> Settings ->
			// General). Defaults to false so the popup never surprises anyone.
			'autoOpen'    => self::autoOpenHere(),
			// 1.26.0 — where a support thread opens (auto|inline|popup|page) and
			// how an arriving message announces itself (toast|autoopen|badge).
			'supportDelivery'    => self::supportDelivery(),
			'newMessageBehavior' => self::newMessageBehavior(),
			// 1.31.0 — how long an open popup keeps being restored across page
			// loads, in SECONDS. The popup now survives navigation until it is
			// closed on purpose; this only caps genuine abandonment, so a window
			// left open days ago does not reappear out of nowhere.
			'sessionTtl'  => self::popupSessionTtl(),
			'i18n'        => array(
				'send'         => __( 'Send', 'zymarg-communication' ),
				'typing'       => __( 'Typing…', 'zymarg-communication' ),
				'connect'      => __( 'Connecting…', 'zymarg-communication' ),
				'error'        => __( 'Message failed to send.', 'zymarg-communication' ),
				'emptyList'    => __( 'No conversations yet.', 'zymarg-communication' ),
				// 1.32.1 — brand label used in the popup header when the popup
				// is opened for a support thread. Never shown for buyer↔vendor
				// chats, which keep displaying the counterpart's store name.
				'supportTitle' => __( 'Support team', 'zymarg-communication' ),
			),
			// 1.32.7 — so closing the popup can fall back to the full inbox even
			// on a page load where /support/start was never called (a restored
			// popup, for instance).
			'inboxUrl'    => self::inboxUrl(),
		);

		// Allow StorePopupService to layer store‑specific bootstrap fields when
		// the visitor is on a store page.
		if ( ServiceProvider::has( StorePopupService::class ) ) {
			$popup     = ServiceProvider::get( StorePopupService::class );
			$data['popup'] = $popup->bootstrapData();
		}

		/**
		 * Filter the `zymargLiveChat` JS bootstrap payload.
		 *
		 * @param array<string,mixed> $data    Bootstrap payload.
		 * @param int                 $user_id Current user id.
		 */
		return (array) apply_filters( 'zymarg_comm_live_chat_bootstrap', $data, $user_id );
	}

	private static function isEnabled(): bool {
		if ( ! ServiceProvider::has( FeatureFlagService::class ) ) {
			return true;
		}
		$flags = ServiceProvider::get( FeatureFlagService::class );
		return (bool) $flags->isEnabled( 'surface.popup' );
	}

	/**
	 * Whether the live-chat popup is allowed to open by itself on the page
	 * currently being rendered. Driven by the admin page picker.
	 */
	private static function autoOpenHere(): bool {
		try {
			return ( new PopupSettingsService() )->isAutoOpenAllowedHere();
		} catch ( \Throwable $e ) {
			return false;
		}
	}

	/**
	 * Where a support trigger opens its thread. Falls back to the safe default
	 * rather than blocking asset output if settings storage is unavailable.
	 */
	private static function supportDelivery(): string {
		try {
			return ( new PopupSettingsService() )->supportDelivery();
		} catch ( \Throwable $e ) {
			// Read from the constant, not a literal. This fallback said 'auto'
			// while the real default moved to popup_first in 1.30.0, so a settings
			// failure would have quietly shipped a different flow to the browser
			// than the one the server rendered the inbox for.
			return PopupSettingsService::DELIVERY_DEFAULT;
		}
	}

	/**
	 * Seconds an open popup session stays restorable. Default 12 hours.
	 *
	 * Clamped to a minimum of 60s: a zero or negative value would make the
	 * session expire instantly and quietly undo the whole feature.
	 */
	private static function popupSessionTtl(): int {
		/** Filter the popup session lifetime, in seconds. @since 1.31.0 */
		$ttl = (int) apply_filters( 'zymarg_comm_popup_session_ttl', 12 * HOUR_IN_SECONDS );

		return max( 60, $ttl );
	}

	/** How an arriving message announces itself. */
	private static function newMessageBehavior(): string {
		try {
			return ( new PopupSettingsService() )->newMessageBehavior();
		} catch ( \Throwable $e ) {
			return 'toast';
		}
	}

	private static function flagEnabled( string $key ): bool {
		if ( ! ServiceProvider::has( FeatureFlagService::class ) ) {
			return true;
		}
		$flags = ServiceProvider::get( FeatureFlagService::class );
		return (bool) $flags->isEnabled( $key );
	}

	/**
	 * Resolve the "Open full inbox" URL surfaced from the storefront popup.
	 * Prefers the WooCommerce My Account "messages" endpoint; filterable.
	 */
	private static function inboxUrl(): string {
		$url = '';
		if ( function_exists( 'wc_get_account_endpoint_url' ) ) {
			$url = wc_get_account_endpoint_url( 'messages' );
		}
		if ( empty( $url ) && function_exists( 'wc_get_page_permalink' ) ) {
			$url = wc_get_page_permalink( 'myaccount' );
		}

		/** Filter the buyer inbox URL opened from the storefront popup. */
		$url = apply_filters( 'zymarg_comm_inbox_url', $url );

		return is_string( $url ) ? esc_url_raw( $url ) : '';
	}
}
