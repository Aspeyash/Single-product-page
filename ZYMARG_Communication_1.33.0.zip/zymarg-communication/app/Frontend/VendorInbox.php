<?php
/**
 * ZYMARG Communication — Vendor inbox frontend renderer.
 *
 * Renders the vendor Messages panel that the ZYMARG Vendor Dashboard plugin
 * already carves out via the `zymarg_os_vendor_render_section` filter for the
 * `messages` section slug.
 *
 * Also renders the `[zymarg_vendor_messages]` shortcode for standalone use.
 *
 * All markup uses the CSS class `zymarg-inbox` + `zymarg-inbox--vendor`.
 * Vanilla JS hydrates from `assets/js/frontend/inbox.js`.
 *
 * @package    ZymargCommunication
 * @version    1.12.0
 */

namespace ZymargCommunication\Frontend;

use ZymargCommunication\Bootstrap\ServiceProvider;
use ZymargCommunication\Modules\FeatureFlags\Services\FeatureFlagService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class VendorInbox {

	/**
	 * Render the vendor inbox root node. Called by the shortcode.
	 *
	 * @param array<string, mixed>|string $atts Shortcode attributes.
	 */
	public static function render( $atts = array() ): string {
		if ( ! is_user_logged_in() ) {
			return '';
		}

		if ( ! self::isEnabled() ) {
			return '';
		}

		$user_id = get_current_user_id();
		$rest    = esc_url_raw( rest_url( 'zymarg-comm/v1' ) );
		$nonce   = wp_create_nonce( 'wp_rest' );

		/*
		 * True only when rendering INSIDE the vendor dashboard shell, where
		 * hostGreeting() has already supplied the dashboard's own
		 * `.zymarg-vendor-greeting`. The `[zymarg_vendor_messages]` shortcode
		 * never sets it, so a standalone inbox keeps its built-in title.
		 */
		$host_chrome = self::hostChromeRequested( $atts );

		ob_start();
		?>
		<section
			class="zymarg-inbox zymarg-inbox--vendor<?php echo $host_chrome ? ' is-host-chrome' : ''; ?>"
			data-zymarg-inbox="vendor"
			data-user-id="<?php echo esc_attr( (string) $user_id ); ?>"
			data-rest="<?php echo esc_attr( $rest ); ?>"
			data-nonce="<?php echo esc_attr( $nonce ); ?>"
			data-attachments="<?php echo self::attachmentsEnabled() ? '1' : '0'; ?>"
			data-reactions="<?php echo self::reactionsEnabled() ? '1' : '0'; ?>"
			data-replies="<?php echo self::repliesEnabled() ? '1' : '0'; ?>"
			data-typing="<?php echo self::typingIndicatorEnabled() ? '1' : '0'; ?>"
			data-presence="<?php echo self::presenceEnabled() ? '1' : '0'; ?>"
		>
			<header class="zymarg-inbox__header">
				<?php if ( ! $host_chrome ) : ?>
					<h2 class="zymarg-inbox__title"><?php esc_html_e( 'Messages', 'zymarg-communication' ); ?></h2>
				<?php endif; ?>
				<div class="zymarg-inbox__filters" role="tablist">
					<button type="button" class="zymarg-inbox__filter is-active" data-zymarg-inbox-filter="all" role="tab" aria-selected="true"><?php esc_html_e( 'All', 'zymarg-communication' ); ?></button>
					<button type="button" class="zymarg-inbox__filter" data-zymarg-inbox-filter="unread" role="tab" aria-selected="false"><?php esc_html_e( 'Unread', 'zymarg-communication' ); ?></button>
					<button type="button" class="zymarg-inbox__filter" data-zymarg-inbox-filter="orders" role="tab" aria-selected="false"><?php esc_html_e( 'Orders', 'zymarg-communication' ); ?></button>
					<button type="button" class="zymarg-inbox__filter" data-zymarg-inbox-filter="products" role="tab" aria-selected="false"><?php esc_html_e( 'Product', 'zymarg-communication' ); ?></button>
				</div>
				<button
					type="button"
					class="zymarg-inbox__search-toggle"
					data-zymarg-inbox-search-toggle
					aria-expanded="false"
					aria-label="<?php esc_attr_e( 'Search customers', 'zymarg-communication' ); ?>"
				><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true" focusable="false"><circle cx="11" cy="11" r="7"></circle><line x1="16.5" y1="16.5" x2="21" y2="21"></line></svg></button>
				<div class="zymarg-inbox__search">
					<input
						type="search"
						class="zymarg-inbox__search-input"
						data-zymarg-inbox-search
						placeholder="<?php esc_attr_e( 'Search customers…', 'zymarg-communication' ); ?>"
						aria-label="<?php esc_attr_e( 'Search customers', 'zymarg-communication' ); ?>"
					/>
					<button type="button" class="zymarg-inbox__search-close" data-zymarg-inbox-search-close aria-label="<?php esc_attr_e( 'Close search', 'zymarg-communication' ); ?>">&times;</button>
				</div>
			</header>
			<div class="zymarg-inbox__body">
				<aside class="zymarg-inbox__list" data-zymarg-inbox-list aria-label="<?php esc_attr_e( 'Conversations', 'zymarg-communication' ); ?>">
					<div class="zymarg-inbox__list-loading" data-zymarg-inbox-loading><?php esc_html_e( 'Loading…', 'zymarg-communication' ); ?></div>
				</aside>
				<main class="zymarg-inbox__thread" data-zymarg-inbox-thread aria-live="polite">
					<div class="zymarg-inbox__empty">
						<?php esc_html_e( 'Select a customer to view the conversation.', 'zymarg-communication' ); ?>
					</div>
				</main>
			</div>
		</section>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Callback for the vendor plugin's `zymarg_os_vendor_render_section`
	 * filter. If our provided render replaces the default, return non‑empty.
	 *
	 * @param string       $html    Existing HTML (default empty).
	 * @param string       $section Section slug.
	 * @param \WP_User|int $user    Current vendor.
	 */
	public static function renderVendorSection( $html, $section, $user ): string { // phpcs:ignore
		if ( 'messages' !== (string) $section ) {
			return (string) $html;
		}

		$host_chrome = self::hostChromeEnabled();
		$rendered    = self::render( $host_chrome ? array( 'host_chrome' => true ) : array() );

		/*
		 * An empty render means a flag turned this surface off, and we must fall
		 * through to the dashboard's own native messages section — so the greeting
		 * is only prepended when we are genuinely taking the panel over. Otherwise
		 * the native section would render its own greeting under ours.
		 */
		if ( '' === $rendered ) {
			return (string) $html;
		}

		return $host_chrome ? self::hostGreeting() . $rendered : $rendered;
	}

	/**
	 * The vendor dashboard's own section heading, structurally identical to every
	 * native section in the plugin (includes/vendor-dashboard.php) — a
	 * `.zymarg-vendor-greeting` wrapping an `<h1>` title and a `__sub` line.
	 *
	 * The copy deliberately matches the dashboard's native messages section word
	 * for word, so replacing that section with this one is invisible in the
	 * heading. `.zymarg-vendor-greeting` is defined in the vendor plugin's own
	 * vendor-dashboard.css, already enqueued here, so no extra CSS ships. The
	 * vendor plugin itself is never edited.
	 */
	private static function hostGreeting(): string {
		ob_start();
		?>
		<header class="zymarg-vendor-greeting">
			<div>
				<h1 class="zymarg-vendor-greeting__title"><?php esc_html_e( 'Messages', 'zymarg-communication' ); ?></h1>
				<p class="zymarg-vendor-greeting__sub"><?php esc_html_e( 'Chat with your buyers — replies are saved to each conversation.', 'zymarg-communication' ); ?></p>
			</div>
		</header>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Whether the caller asked for host chrome AND the flag allows it.
	 *
	 * @param array<string, mixed>|string $atts Shortcode attributes.
	 */
	private static function hostChromeRequested( $atts ): bool {
		if ( ! is_array( $atts ) || empty( $atts['host_chrome'] ) ) {
			return false;
		}
		return self::hostChromeEnabled();
	}

	/*
	 * Fail-CLOSED — see the note on BuyerInbox::hostChromeEnabled(). Cosmetic and
	 * opt-in, so an unavailable flag service must leave the known-good
	 * edge-to-edge layout in place rather than restyle a live page.
	 */
	private static function hostChromeEnabled(): bool {
		if ( ! ServiceProvider::has( FeatureFlagService::class ) ) {
			return false;
		}
		$flags = ServiceProvider::get( FeatureFlagService::class );
		return (bool) $flags->isEnabled( 'surface.host_native_chrome' );
	}

	private static function isEnabled(): bool {
		if ( ! ServiceProvider::has( FeatureFlagService::class ) ) {
			return true;
		}
		$flags = ServiceProvider::get( FeatureFlagService::class );
		return (bool) $flags->isEnabled( 'surface.vendor_inbox' );
	}

	private static function attachmentsEnabled(): bool {
		if ( ! ServiceProvider::has( FeatureFlagService::class ) ) {
			return true;
		}
		$flags = ServiceProvider::get( FeatureFlagService::class );
		return (bool) $flags->isEnabled( 'message.attachments' );
	}

	private static function reactionsEnabled(): bool {
		if ( ! ServiceProvider::has( FeatureFlagService::class ) ) {
			return true;
		}
		$flags = ServiceProvider::get( FeatureFlagService::class );
		return (bool) $flags->isEnabled( 'message.reactions' );
	}

	private static function repliesEnabled(): bool {
		if ( ! ServiceProvider::has( FeatureFlagService::class ) ) {
			return true;
		}
		$flags = ServiceProvider::get( FeatureFlagService::class );
		return (bool) $flags->isEnabled( 'message.replies' );
	}

	private static function typingIndicatorEnabled(): bool {
		if ( ! ServiceProvider::has( FeatureFlagService::class ) ) {
			return true;
		}
		$flags = ServiceProvider::get( FeatureFlagService::class );
		return (bool) $flags->isEnabled( 'message.typing_indicator' );
	}

	private static function presenceEnabled(): bool {
		if ( ! ServiceProvider::has( FeatureFlagService::class ) ) {
			return true;
		}
		$flags = ServiceProvider::get( FeatureFlagService::class );
		return (bool) $flags->isEnabled( 'message.online_status' );
	}
}
