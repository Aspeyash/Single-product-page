<?php
/**
 * ZYMARG Communication — Floating live-chat widget renderer.
 *
 * Renders the `zymarg-live-chat` container that the vendor plugin's line 548
 * comment expects. Frontend JS reads the global `zymargLiveChat` object for
 * config (REST URL, nonce, driver, etc.).
 *
 * Also renders the `[zymarg_live_chat]` shortcode for pages that want the
 * widget inline.
 *
 * @package    ZymargCommunication
 * @version    1.12.0
 */

namespace ZymargCommunication\Frontend;

use ZymargCommunication\Bootstrap\ServiceProvider;
use ZymargCommunication\Modules\FeatureFlags\Services\FeatureFlagService;
use ZymargCommunication\Modules\Marketplace\Services\StorePopupService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class LiveChat {

	/**
	 * Render the live-chat container. Attached to `wp_footer` and also
	 * available via the `[zymarg_live_chat]` shortcode.
	 *
	 * @param array<string, mixed>|string $atts Shortcode attributes.
	 */
	public static function render( $atts = array() ): string {
		if ( ! self::isEnabled() ) {
			return '';
		}

		ob_start();
		?>
		<div class="zymarg-live-chat" data-zymarg-live-chat aria-live="polite" data-zymarg-geometry="<?php echo self::geometryEnabled() ? '1' : '0'; ?>" data-zymarg-user="<?php echo (int) get_current_user_id(); ?>">
			<button
				type="button"
				class="zymarg-live-chat__launcher"
				data-zymarg-live-chat-launcher
				aria-label="<?php esc_attr_e( 'Open chat', 'zymarg-communication' ); ?>"
				hidden
			>
				<span class="zymarg-live-chat__launcher-icon" aria-hidden="true">
					<svg width="22" height="22" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 5.5A2.5 2.5 0 0 1 6.5 3h11A2.5 2.5 0 0 1 20 5.5v8A2.5 2.5 0 0 1 17.5 16H9l-4 4v-4.5A2.5 2.5 0 0 1 4 13.5v-8Z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>
				</span>
				<span class="zymarg-live-chat__launcher-badge" data-zymarg-live-chat-badge hidden>0</span>
			</button>
			<div class="zymarg-live-chat__panel" data-zymarg-live-chat-panel role="dialog" aria-label="<?php esc_attr_e( 'Chat', 'zymarg-communication' ); ?>" hidden>
				<button type="button" class="zymarg-live-chat__resize" data-zymarg-live-chat-resize aria-label="<?php esc_attr_e( 'Resize chat window', 'zymarg-communication' ); ?>" hidden></button>
				<header class="zymarg-live-chat__header" data-zymarg-live-chat-header>
					<span class="zymarg-live-chat__title" data-zymarg-live-chat-title><?php esc_html_e( 'Chat', 'zymarg-communication' ); ?></span>
					<?php
					/*
					 * 1.26.0 — controls are grouped and the destructive one is
					 * separated. Previously the JS-injected "open full inbox"
					 * link was inserted directly against the close button: same
					 * 24x24 box, same white-at-.9 colour, 2px apart. Users aiming
					 * for close hit the link instead and were navigated to the
					 * Messages page, which read as "the cross reloads the page".
					 * Order is [expand] [minimize] | [close], with a rule and a
					 * wider gap before close. Expand is injected at the front of
					 * this wrapper by live-chat.js.
					 */
					?>
					<span class="zymarg-live-chat__controls" data-zymarg-live-chat-controls>
						<button
							type="button"
							class="zymarg-live-chat__min"
							data-zymarg-live-chat-min
							title="<?php esc_attr_e( 'Minimize — keeps the chat running', 'zymarg-communication' ); ?>"
							aria-label="<?php esc_attr_e( 'Minimize chat', 'zymarg-communication' ); ?>"
						>
							<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" aria-hidden="true" focusable="false"><line x1="6" y1="12" x2="18" y2="12"></line></svg>
						</button>
						<button
							type="button"
							class="zymarg-live-chat__close"
							data-zymarg-live-chat-close
							title="<?php esc_attr_e( 'Close chat', 'zymarg-communication' ); ?>"
							aria-label="<?php esc_attr_e( 'Close chat', 'zymarg-communication' ); ?>"
						>&times;</button>
					</span>
				</header>
				<div class="zymarg-live-chat__messages" data-zymarg-live-chat-messages></div>
				<div class="zymarg-live-chat__typing" data-zymarg-live-chat-typing hidden><?php esc_html_e( 'Typing…', 'zymarg-communication' ); ?></div>
				<form class="zymarg-live-chat__composer" data-zymarg-live-chat-composer>
					<?php if ( self::attachmentsEnabled() ) : ?>
					<button type="button" class="zymarg-live-chat__attach" data-zymarg-live-chat-attach aria-label="<?php esc_attr_e( 'Attach image', 'zymarg-communication' ); ?>">
						<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21.44 11.05l-9.19 9.19a5 5 0 0 1-7.07-7.07l9.19-9.19a3 3 0 0 1 4.24 4.24l-9.2 9.19a1 1 0 0 1-1.41-1.41l8.49-8.49"></path></svg>
					</button>
					<input type="file" class="zymarg-live-chat__file" data-zymarg-live-chat-file accept="image/*" hidden />
					<?php endif; ?>
					<textarea
						class="zymarg-live-chat__input"
						data-zymarg-live-chat-input
						rows="1"
						autocomplete="off"
						placeholder="<?php esc_attr_e( 'Write a message…', 'zymarg-communication' ); ?>"
						aria-label="<?php esc_attr_e( 'Message', 'zymarg-communication' ); ?>"
					></textarea>
					<button type="submit" class="zymarg-live-chat__send" data-zymarg-live-chat-send aria-label="<?php esc_attr_e( 'Send', 'zymarg-communication' ); ?>">
						<svg class="zymarg-live-chat__send-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
					</button>
					<span class="zymarg-live-chat__attach-chip" data-zymarg-live-chat-attach-chip hidden><span class="zymarg-live-chat__attach-chip-name" data-zymarg-live-chat-attach-chip-name></span><button type="button" class="zymarg-live-chat__attach-chip-remove" data-zymarg-live-chat-attach-chip-remove aria-label="<?php esc_attr_e( 'Remove attachment', 'zymarg-communication' ); ?>">&times;</button></span>
				</form>
			</div>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Convenience for `wp_footer` — echoes the container.
	 */
	public static function echoContainer(): void {
		if ( ! is_user_logged_in() ) {
			return;
		}
		echo self::render(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Render an unread‑count badge for menu items. Returns a `<span>` even when
	 * count is zero so the caller can hide/show via CSS. Also exposed via the
	 * `[zymarg_unread_count]` shortcode.
	 */
	public static function renderUnreadCount( $atts = array() ): string {
		if ( ! is_user_logged_in() ) {
			return '';
		}
		return '<span class="zymarg-inbox__unread" data-zymarg-unread-count hidden>0</span>';
	}

	private static function isEnabled(): bool {
		if ( ! ServiceProvider::has( FeatureFlagService::class ) ) {
			return true;
		}
		$flags = ServiceProvider::get( FeatureFlagService::class );
		return (bool) $flags->isEnabled( 'surface.popup' );
	}

	/**
	 * Whether the popup may be dragged and resized. Gated by
	 * `surface.popup_draggable`, which ships enabled.
	 */
	private static function geometryEnabled(): bool {
		if ( ! ServiceProvider::has( FeatureFlagService::class ) ) {
			return true;
		}
		$flags = ServiceProvider::get( FeatureFlagService::class );
		// Ships enabled by default. If the row was never seeded — an in-place
		// upgrade with no reactivation — treat it as on rather than off.
		if ( ! $flags->exists( 'surface.popup_draggable' ) ) {
			return true;
		}
		return (bool) $flags->isEnabled( 'surface.popup_draggable' );
	}

	private static function attachmentsEnabled(): bool {
		if ( ! ServiceProvider::has( FeatureFlagService::class ) ) {
			return true;
		}
		$flags = ServiceProvider::get( FeatureFlagService::class );
		return (bool) $flags->isEnabled( 'message.attachments' );
	}
}
