<?php
/**
 * ZYMARG Communication — Admin⇄User (support) frontend renderer.
 *
 * Renders the customer-facing side of support messaging. Deliberately flexible
 * so the same feature can be dropped anywhere under any name — "Contact
 * Support", "Support", "Alpha", whatever a future page calls for:
 *
 *   [zymarg_support_chat]                              default button
 *   [zymarg_support_chat label="Alpha"]                custom label
 *   [zymarg_support_chat mode="inline"]                full inbox, identical UI
 *   [zymarg_support_chat mode="link" label="Need help?"]
 *   [zymarg_support_chat class="my-btn" icon="no"]
 *
 * The inline mode renders the SAME `.zymarg-inbox` root as the buyer and
 * vendor inboxes, so it inherits every layout, composer, reaction and mobile
 * fix shipped in 1.24.x with zero visual drift.
 *
 * @package ZymargCommunication
 * @since   1.25.0
 */

namespace ZymargCommunication\Frontend;

use ZymargCommunication\Bootstrap\ServiceProvider;
use ZymargCommunication\Modules\FeatureFlags\Services\FeatureFlagService;
use ZymargCommunication\Modules\Support\Repositories\SupportRepository;
use ZymargCommunication\Modules\Support\Services\SupportService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class SupportChat {

	/**
	 * Render the support entry point.
	 *
	 * @param array<string, mixed>|string $atts Shortcode attributes.
	 */
	public static function render( $atts = array() ): string {
		$atts = shortcode_atts(
			array(
				'label'       => '',
				'title'       => '',
				'mode'        => 'button',
				'class'       => '',
				'icon'        => 'yes',
				'logged_out'  => '',
			),
			is_array( $atts ) ? $atts : array(),
			'zymarg_support_chat'
		);

		$service = self::service();
		if ( ! $service instanceof SupportService || ! $service->enabled() ) {
			// Off by default: render nothing at all rather than a dead control.
			return '';
		}

		if ( ! is_user_logged_in() ) {
			$msg = trim( (string) $atts['logged_out'] );
			if ( '' === $msg ) {
				return '';
			}
			return '<div class="zymarg-support zymarg-support--guest">' . esc_html( $msg ) . '</div>';
		}

		$mode = strtolower( trim( (string) $atts['mode'] ) );
		if ( ! in_array( $mode, array( 'button', 'link', 'inline' ), true ) ) {
			$mode = 'button';
		}

		if ( 'inline' === $mode ) {
			return self::renderInline( (string) $atts['title'] );
		}

		return self::renderTrigger( $atts, $mode, $service );
	}

	/**
	 * Button / link that opens (or resumes) the support thread.
	 *
	 * @param array<string, mixed> $atts
	 */
	private static function renderTrigger( array $atts, string $mode, SupportService $service ): string {
		$label = trim( (string) $atts['label'] );
		if ( '' === $label ) {
			$label = $service->label();
		}

		$classes = array( 'zymarg-support-trigger', 'zymarg-support-trigger--' . $mode );
		$extra   = trim( (string) $atts['class'] );
		if ( '' !== $extra ) {
			foreach ( preg_split( '/\s+/', $extra ) as $cls ) {
				if ( '' !== $cls ) {
					$classes[] = sanitize_html_class( $cls );
				}
			}
		}

		$icon = '';
		if ( 'no' !== strtolower( (string) $atts['icon'] ) && 'link' !== $mode ) {
			$icon = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path></svg>';
		}

		// 1.32.1 — if the current user already has an open ticket, the trigger
		// would be a duplicate call to action next to their live conversation.
		// Render it hidden (kept in the DOM so support.js still wires it, so
		// the trigger reappears the moment the case closes / is resolved).
		$hide_trigger = false;
		try {
			$hide_trigger = $service->hasOpenTicketForUser( get_current_user_id() );
		} catch ( \Throwable $e ) {
			$hide_trigger = false;
		}

		ob_start();
		?>
		<button
			type="button"
			class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>"
			data-zymarg-support-start
			data-rest="<?php echo esc_attr( esc_url_raw( rest_url( 'zymarg-comm/v1' ) ) ); ?>"
			data-nonce="<?php echo esc_attr( wp_create_nonce( 'wp_rest' ) ); ?>"
			data-busy-label="<?php esc_attr_e( 'Opening…', 'zymarg-communication' ); ?>"
			data-error-label="<?php esc_attr_e( 'Could not open support. Please try again.', 'zymarg-communication' ); ?>"
			<?php echo $hide_trigger ? 'hidden style="display:none"' : ''; ?>
		><?php echo $icon; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><span class="zymarg-support-trigger__label"><?php echo esc_html( $label ); ?></span></button>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Full inline support inbox — the exact same root node the buyer inbox
	 * uses, narrowed to support threads via data-context.
	 *
	 * 1.30.0: under `popup_first` delivery this inbox is rendered HIDDEN. The
	 * popup opens first, and support.js reveals this node when the customer
	 * closes it, so the two surfaces are never on screen at the same time — the
	 * defect where a customer saw the popup AND a second inbox behind it. It
	 * also gains an "Open in popup" control for the return trip.
	 */
	private static function renderInline( string $title ): string {
		$title = '' !== trim( $title ) ? trim( $title ) : __( 'Support', 'zymarg-communication' );

		$hidden = false;
		try {
			$hidden = ( new \ZymargCommunication\Modules\Settings\Services\PopupSettingsService() )->inlineStartsHidden();
		} catch ( \Throwable $e ) {
			// Reading a setting must never take the support surface down. Fall
			// back to the pre-1.30.0 behaviour: a plainly visible inbox.
			$hidden = false;
		}

		return self::inboxRoot(
			'support',
			$title,
			get_current_user_id(),
			__( 'Select a conversation to view your messages.', 'zymarg-communication' ),
			array(
				'hidden'       => $hidden,
				'popup_toggle' => $hidden,
				'host_chrome'  => self::hostChromeEnabled(),
				'compact_head' => true,
			)
		);
	}

	/**
	 * Whether the "Match host page heading style" flag is on (1.32.9).
	 *
	 * BuyerInbox / VendorInbox both read this same flag to swap in a REAL host
	 * heading they can prove exists (the theme's `.panel-header`, the vendor
	 * dashboard's `.zymarg-vendor-greeting`) and hand the inbox its matching
	 * card tokens. This inbox has no such heading to borrow — the support
	 * surface is dropped into page-author content
	 * (`[zymarg_support_chat mode="inline"]` inside whatever container the
	 * Contact/Support page happens to wrap it in), so there is nothing to swap
	 * the title FOR. It keeps its own "Support" title in both states.
	 *
	 * What DOES carry over from the buyer/vendor pattern is the meaning of the
	 * two states themselves, because that is what the flag's own description
	 * promises regardless of surface:
	 *
	 *   OFF (default) — the inbox owns the visual. inbox.css already squares
	 *   its outer frame once `.is-host-chrome` is absent; this flag additionally
	 *   neutralises the PAGE'S OWN wrapper (`#zymarg-os-support-inbox` /
	 *   `#zymarg-vd-support-inbox`) so a rounded, shadowed container placed
	 *   around the shortcode by the page itself cannot show through as a gap
	 *   around an inbox that is trying to be edge-to-edge.
	 *
	 *   ON — "put the inbox back inside the host's page frame instead of
	 *   running edge to edge", per the flag's own description. Here the "host
	 *   frame" is that same page wrapper; instead of the inbox owning the
	 *   visual, the wrapper's card (whatever radius/shadow/padding the page
	 *   gave it) is left alone and the inbox flattens its OWN border, radius
	 *   and shadow so the two do not layer into two nested cards.
	 *
	 * Fail-CLOSED like the buyer/vendor implementations: cosmetic and opt-in,
	 * so an unavailable flag service must leave the known-good edge-to-edge
	 * layout in place rather than restyle a live page.
	 */
	private static function hostChromeEnabled(): bool {
		if ( ! ServiceProvider::has( FeatureFlagService::class ) ) {
			return false;
		}
		$flags = ServiceProvider::get( FeatureFlagService::class );
		return (bool) $flags->isEnabled( 'surface.host_native_chrome' );
	}

	/**
	 * Shared inbox root builder.
	 *
	 * Kept byte-for-byte in step with BuyerInbox::render() so the support
	 * surface can never drift from the buyer/vendor surfaces. The only
	 * differences are the side token, the heading and data-context, which
	 * restricts the conversation list to support threads.
	 *
	 * @param array<string, mixed> $opts Optional presentation flags:
	 *                                   - hidden       bool Render collapsed. (1.30.0)
	 *                                   - popup_toggle bool Show "Open in popup". (1.30.0)
	 *                                   - host_chrome  bool Flatten the inbox's OWN
	 *                                     border/radius/shadow so it does not
	 *                                     layer a second card inside whatever
	 *                                     frame the host page already drew
	 *                                     around it. (1.32.9)
	 *                                   - compact_head bool One header row instead
	 *                                     of two. (1.32.12)
	 *                                   All three default to false, so the two
	 *                                   AGENT callers (AdminSupportPage and
	 *                                   AgentConsole) are byte-identical to
	 *                                   1.29.0 and can never get a hidden or
	 *                                   host-chrome inbox — neither passes
	 *                                   $opts at all.
	 */
	public static function inboxRoot( string $side, string $title, int $user_id, string $empty, array $opts = array() ): string {
		$rest  = esc_url_raw( rest_url( 'zymarg-comm/v1' ) );
		$nonce = wp_create_nonce( 'wp_rest' );

		$hidden       = ! empty( $opts['hidden'] );
		$popup_toggle = ! empty( $opts['popup_toggle'] );
		$host_chrome  = ! empty( $opts['host_chrome'] );
		$compact_head = ! empty( $opts['compact_head'] );

		/*
		 * 1.32.12 — one header row instead of two.
		 *
		 * The customer support surface was stacking two full-width header rows:
		 * this inbox's own `.zymarg-inbox__header` (its title plus the "Open in
		 * popup" control) and, immediately under it, the thread pane's
		 * `.zymarg-inbox__thread-header` carrying the conversation title, which
		 * inbox.js renders. On a helpline that is one row of pure duplication --
		 * there is a single case, so a section title AND a conversation title
		 * say the same thing twice and cost ~50px of the message log.
		 *
		 * The conversation title is the one worth keeping (it names who the
		 * customer is talking to), so it moves up here and the thread row is
		 * collapsed by CSS. `ConversationService::…` labels a support thread with
		 * this exact string for the customer view, so both ends stay in step and
		 * whatever `title` the host passed to the shortcode is deliberately
		 * ignored on this surface -- it was the duplicate.
		 *
		 * Only reaches the two customer-facing inline surfaces. The agent
		 * console and the admin support screen call inboxRoot() with no $opts at
		 * all, keep their own title, and are byte-identical to 1.29.0.
		 */
		if ( $compact_head ) {
			$title = __( 'Support team', 'zymarg-communication' );
		}

		ob_start();
		?>
		<section
			class="zymarg-inbox zymarg-inbox--support<?php echo $host_chrome ? ' is-host-chrome' : ''; ?><?php echo $compact_head ? ' is-compact-head' : ''; ?>"
			<?php if ( $hidden ) : ?>
				<?php /* Both the attribute AND inline display:none — support.js reveal() clears each, and belt-and-braces means a theme rule that beats [hidden] cannot leak the inbox out from behind the popup. */ ?>
				hidden style="display:none"
			<?php endif; ?>
			data-zymarg-inbox="<?php echo esc_attr( $side ); ?>"
			data-context="<?php echo esc_attr( SupportRepository::CONTEXT ); ?>"
			data-user-id="<?php echo esc_attr( (string) $user_id ); ?>"
			data-rest="<?php echo esc_attr( $rest ); ?>"
			data-nonce="<?php echo esc_attr( $nonce ); ?>"
			data-attachments="<?php echo self::flag( 'message.attachments' ) ? '1' : '0'; ?>"
			data-reactions="<?php echo self::flag( 'message.reactions' ) ? '1' : '0'; ?>"
			data-replies="<?php echo self::flag( 'message.replies' ) ? '1' : '0'; ?>"
			data-typing="<?php echo self::flag( 'message.typing_indicator' ) ? '1' : '0'; ?>"
			data-presence="<?php echo self::flag( 'message.online_status' ) ? '1' : '0'; ?>"
		>
			<header class="zymarg-inbox__header">
				<h2 class="zymarg-inbox__title"><?php echo esc_html( $title ); ?></h2>
				<div class="zymarg-inbox__filters" role="tablist">
					<button type="button" class="zymarg-inbox__filter is-active" data-zymarg-inbox-filter="all" role="tab" aria-selected="true"><?php esc_html_e( 'All', 'zymarg-communication' ); ?></button>
					<button type="button" class="zymarg-inbox__filter" data-zymarg-inbox-filter="unread" role="tab" aria-selected="false"><?php esc_html_e( 'Unread', 'zymarg-communication' ); ?></button>
				</div>
				<?php if ( $popup_toggle ) : ?>
					<?php /* 1.30.0 — the return trip. support.js hides this inbox and reopens the popup on the same conversation. Rendered only for the customer's popup_first surface; agents never see it. */ ?>
					<button
						type="button"
						class="zymarg-inbox__popup-open"
						data-zymarg-support-popup-open
						title="<?php esc_attr_e( 'Show this conversation in the chat popup instead', 'zymarg-communication' ); ?>"
					><svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path></svg><span class="zymarg-inbox__popup-open-label"><?php esc_html_e( 'Open in popup', 'zymarg-communication' ); ?></span></button>
				<?php endif; ?>
				<button
					type="button"
					class="zymarg-inbox__search-toggle"
					data-zymarg-inbox-search-toggle
					aria-expanded="false"
					aria-label="<?php esc_attr_e( 'Search conversations', 'zymarg-communication' ); ?>"
				><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true" focusable="false"><circle cx="11" cy="11" r="7"></circle><line x1="16.5" y1="16.5" x2="21" y2="21"></line></svg></button>
				<div class="zymarg-inbox__search">
					<input
						type="search"
						class="zymarg-inbox__search-input"
						data-zymarg-inbox-search
						placeholder="<?php esc_attr_e( 'Search conversations…', 'zymarg-communication' ); ?>"
						aria-label="<?php esc_attr_e( 'Search conversations', 'zymarg-communication' ); ?>"
					/>
					<button type="button" class="zymarg-inbox__search-close" data-zymarg-inbox-search-close aria-label="<?php esc_attr_e( 'Close search', 'zymarg-communication' ); ?>">&times;</button>
				</div>
			</header>
			<div class="zymarg-inbox__body">
				<aside class="zymarg-inbox__list" data-zymarg-inbox-list aria-label="<?php esc_attr_e( 'Conversations', 'zymarg-communication' ); ?>">
					<div class="zymarg-inbox__list-loading" data-zymarg-inbox-loading><?php esc_html_e( 'Loading…', 'zymarg-communication' ); ?></div>
				</aside>
				<main class="zymarg-inbox__thread" data-zymarg-inbox-thread aria-live="polite">
					<div class="zymarg-inbox__empty"><?php echo esc_html( $empty ); ?></div>
				</main>
			</div>
		</section>
		<?php
		return (string) ob_get_clean();
	}

	private static function service(): ?SupportService {
		if ( ! ServiceProvider::has( SupportService::class ) ) {
			return null;
		}

		return ServiceProvider::get( SupportService::class );
	}

	private static function flag( string $key ): bool {
		$class = \ZymargCommunication\Modules\FeatureFlags\Services\FeatureFlagService::class;
		if ( ! ServiceProvider::has( $class ) ) {
			return true;
		}

		return (bool) ServiceProvider::get( $class )->isEnabled( $key );
	}
}
