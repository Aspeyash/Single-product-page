<?php
/**
 * ZYMARG Communication — Ecosystem integration.
 *
 * Wires this plugin into two ZYMARG‑owned surfaces via the filters they
 * already expose (READ ONLY — we never edit the theme or vendor plugin):
 *
 *  1. Theme `zymarg-os` My Account page
 *     Filter: `zymarg_os_account_sections`
 *     We inject a "Messages" section (icon `message`, endpoint `messages`,
 *     inserted after `orders`), render_cb -> BuyerInbox::renderAccountSection.
 *
 *  2. Plugin `ZYMARG Vendor Dashboard` vendor dashboard
 *     Filter: `zymarg_os_vendor_render_section` (section slug `messages`
 *     is already a native section — we only supply the panel body).
 *     We also hook `zymarg_os_vendor_nav_items` to keep the sidebar label /
 *     icon consistent with the buyer surface.
 *
 * Fallback marketplace injections (WooCommerce / Dokan / WCFM / WCVendors)
 * live in `Bootstrap\Compatibility` and only fire when the ZYMARG theme +
 * vendor plugin are not active.
 *
 * @package    ZymargCommunication
 * @version    1.12.0
 */

namespace ZymargCommunication\Frontend;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class EcosystemIntegration {

	public static function register(): void {
		// Theme: My Account custom section.
		add_filter( 'zymarg_os_account_sections', array( __CLASS__, 'registerAccountSection' ) );

		// Vendor plugin: vendor dashboard messages section body + nav label.
		add_filter( 'zymarg_os_vendor_render_section', array( VendorInbox::class, 'renderVendorSection' ), 10, 3 );
		add_filter( 'zymarg_os_vendor_nav_items', array( __CLASS__, 'refineVendorNav' ), 20 );

		// Floating live-chat container in the footer (only for logged‑in users).
		add_action( 'wp_footer', array( LiveChat::class, 'echoContainer' ), 20 );
	}

	/**
	 * Register the Messages section with the theme's My Account extension API.
	 *
	 * @param array<string, array<string,mixed>> $sections Existing sections.
	 * @return array<string, array<string,mixed>>
	 */
	public static function registerAccountSection( $sections ): array {
		$sections = is_array( $sections ) ? $sections : array();

		// Never override reserved slugs — the theme locks these anyway, but be
		// defensive so we don't fight another plugin that registered first.
		if ( isset( $sections['messages'] ) ) {
			return $sections;
		}

		$sections['messages'] = array(
			'label'     => __( 'Messages', 'zymarg-communication' ),
			'icon'      => 'message',
			'endpoint'  => 'messages',
			'after'     => 'orders',
			'render_cb' => array( BuyerInbox::class, 'renderAccountSection' ),
			'enabled'   => true,
		);

		return $sections;
	}

	/**
	 * Ensure the vendor plugin's nav still has a `messages` entry even when
	 * another integration has removed it. We only add — never override an
	 * existing entry.
	 *
	 * @param array<int|string, array<string,mixed>> $items Nav items.
	 * @return array<int|string, array<string,mixed>>
	 */
	public static function refineVendorNav( $items ): array {
		$items = is_array( $items ) ? $items : array();
		return $items; // Vendor plugin already exposes a native 'messages' item; leave alone.
	}
}
