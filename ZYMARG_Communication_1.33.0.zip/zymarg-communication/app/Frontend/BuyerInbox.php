<?php
/**
 * ZYMARG Communication — Buyer inbox frontend renderer.
 *
 * Renders the `zymarg_my_messages` shortcode and the buyer‑side Messages
 * section that the `zymarg-os` theme injects into its custom My Account page
 * via the `zymarg_os_account_sections` filter.
 *
 * All markup uses the CSS class `zymarg-inbox` (matching the identifiers the
 * theme + vendor plugin already expect). No jQuery. Vanilla JS hydrates the
 * root element from `assets/js/frontend/inbox.js`.
 *
 * @package    ZymargCommunication
 * @version    1.12.0
 */

namespace ZymargCommunication\Frontend;

use ZymargCommunication\Bootstrap\ServiceProvider;
use ZymargCommunication\Modules\Conversation\Services\ConversationService;
use ZymargCommunication\Modules\FeatureFlags\Services\FeatureFlagService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BuyerInbox {

	/**
	 * Render the buyer inbox root node. Called by the `[zymarg_my_messages]`
	 * shortcode and by the theme's My Account section callback.
	 *
	 * @param array<string, mixed>|string $atts Shortcode attributes (unused).
	 * @return string Rendered HTML.
	 */
	public static function render( $atts = array() ): string {
		if ( ! is_user_logged_in() ) {
			return '<div class="zymarg-inbox zymarg-inbox--guest">'
				. esc_html__( 'Please log in to view your messages.', 'zymarg-communication' )
				. '</div>';
		}

		if ( ! self::isEnabled() ) {
			return '';
		}

		$user_id = get_current_user_id();
		$rest    = esc_url_raw( rest_url( 'zymarg-comm/v1' ) );
		$nonce   = wp_create_nonce( 'wp_rest' );

		/*
		 * True only when we are rendering INSIDE the theme's My Account page and
		 * hostPanelHeader() has already supplied the theme's own `.panel-header`.
		 * The hosted callback passes it; the `[zymarg_my_messages]` shortcode
		 * never does, so a standalone inbox keeps its built-in title and stays
		 * byte-identical to 1.25.7.
		 */
		$host_chrome = self::hostChromeRequested( $atts );

		ob_start();
		?>
		<section
			class="zymarg-inbox zymarg-inbox--buyer<?php echo $host_chrome ? ' is-host-chrome' : ''; ?>"
			data-zymarg-inbox="buyer"
			data-user-id="<?php echo esc_attr( (string) $user_id ); ?>"
			data-rest="<?php echo esc_attr( $rest ); ?>"
			data-nonce="<?php echo esc_attr( $nonce ); ?>"
			data-attachments="<?php echo self::attachmentsEnabled() ? '1' : '0'; ?>"
			data-reactions="<?php echo self::reactionsEnabled() ? '1' : '0'; ?>"
			data-replies="<?php echo self::repliesEnabled() ? '1' : '0'; ?>"
			data-typing="<?php echo self::typingIndicatorEnabled() ? '1' : '0'; ?>"
			data-presence="<?php echo self::presenceEnabled() ? '1' : '0'; ?>"
		>
			<header class="zymarg-inbox__header">
				<?php if ( ! $host_chrome ) : ?>
					<h2 class="zymarg-inbox__title"><?php esc_html_e( 'Messages', 'zymarg-communication' ); ?></h2>
				<?php endif; ?>
				<div class="zymarg-inbox__filters" role="tablist">
					<button type="button" class="zymarg-inbox__filter is-active" data-zymarg-inbox-filter="all" role="tab" aria-selected="true"><?php esc_html_e( 'All', 'zymarg-communication' ); ?></button>
					<button type="button" class="zymarg-inbox__filter" data-zymarg-inbox-filter="unread" role="tab" aria-selected="false"><?php esc_html_e( 'Unread', 'zymarg-communication' ); ?></button>
					<button type="button" class="zymarg-inbox__filter" data-zymarg-inbox-filter="orders" role="tab" aria-selected="false"><?php esc_html_e( 'Orders', 'zymarg-communication' ); ?></button>
					<button type="button" class="zymarg-inbox__filter" data-zymarg-inbox-filter="products" role="tab" aria-selected="false"><?php esc_html_e( 'Product', 'zymarg-communication' ); ?></button>
				</div>
				<button
					type="button"
					class="zymarg-inbox__search-toggle"
					data-zymarg-inbox-search-toggle
					aria-expanded="false"
					aria-label="<?php esc_attr_e( 'Search conversations', 'zymarg-communication' ); ?>"
				><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true" focusable="false"><circle cx="11" cy="11" r="7"></circle><line x1="16.5" y1="16.5" x2="21" y2="21"></line></svg></button>
				<div class="zymarg-inbox__search">
					<input
						type="search"
						class="zymarg-inbox__search-input"
						data-zymarg-inbox-search
						placeholder="<?php esc_attr_e( 'Search conversations…', 'zymarg-communication' ); ?>"
						aria-label="<?php esc_attr_e( 'Search conversations', 'zymarg-communication' ); ?>"
					/>
					<button type="button" class="zymarg-inbox__search-close" data-zymarg-inbox-search-close aria-label="<?php esc_attr_e( 'Close search', 'zymarg-communication' ); ?>">&times;</button>
				</div>
			</header>
			<div class="zymarg-inbox__body">
				<aside class="zymarg-inbox__list" data-zymarg-inbox-list aria-label="<?php esc_attr_e( 'Conversations', 'zymarg-communication' ); ?>">
					<div class="zymarg-inbox__list-loading" data-zymarg-inbox-loading><?php esc_html_e( 'Loading…', 'zymarg-communication' ); ?></div>
				</aside>
				<main class="zymarg-inbox__thread" data-zymarg-inbox-thread aria-live="polite">
					<div class="zymarg-inbox__empty">
						<?php esc_html_e( 'Select a conversation to view your messages.', 'zymarg-communication' ); ?>
					</div>
				</main>
			</div>
		</section>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Convenience callback for the theme's `zymarg_os_account_sections` filter.
	 * The theme passes the section slug and the currently viewed user; we ignore
	 * both and always render for the logged‑in buyer.
	 *
	 * @param string       $section Section slug.
	 * @param \WP_User|int $user    Current viewer.
	 */
	public static function renderAccountSection( $section = '', $user = 0 ): string { // phpcs:ignore
		$host_chrome = self::hostChromeEnabled();
		$html        = self::render( $host_chrome ? array( 'host_chrome' => true ) : array() );

		/*
		 * Only crown it with the theme's heading when there is actually a body to
		 * head. render() returns an empty string when the `surface.buyer_inbox`
		 * flag is off, and prepending the header unconditionally would leave an
		 * orphaned "Messages" title sitting above nothing.
		 */
		if ( $host_chrome && '' !== $html ) {
			$html = self::hostPanelHeader() . $html;
		}

		/*
		 * IMPORTANT — the zymarg-os theme invokes this callback via
		 * call_user_func() inside zymarg_os_account_render_section()
		 * (inc/account-sections.php) and DISCARDS the return value. It expects
		 * the section body to be echoed, exactly like the theme's own native
		 * zymarg_os_acc_section_*() functions do.
		 *
		 * Returning the markup therefore rendered an empty
		 * <div class="section-panel active"></div> and the buyer inbox never
		 * reached the page, so inbox.js had no [data-zymarg-inbox] root to
		 * hydrate. The vendor surface is unaffected because it goes through the
		 * zymarg_os_vendor_render_section FILTER, whose return value IS used.
		 *
		 * We echo here, and return an empty string so that any caller which
		 * echoes the return value does not print the markup a second time.
		 */
		echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		return '';
	}

	/**
	 * The theme's own section heading, byte-for-byte the same structure every
	 * native My Account panel uses (inc/account-sections.php): a `.panel-header`
	 * holding the section icon plus an `<h2>`, followed by a `.panel-desc`.
	 *
	 * We only ever CONSUME the theme's markup contract and stylesheet — the
	 * theme is never edited. `.panel-header` / `.panel-desc` are defined in the
	 * theme's own woocommerce/account.css, which is already enqueued on this
	 * page, so no extra CSS ships for the heading itself.
	 *
	 * The icon is optional on purpose: if the theme is absent or renames its
	 * helper, we simply omit the glyph and keep the heading. Nothing fatals.
	 */
	private static function hostPanelHeader(): string {
		$icon = '';
		if ( function_exists( 'zymarg_os_account_icon' ) ) {
			$icon = (string) zymarg_os_account_icon( 'message' );
		}

		ob_start();
		?>
		<div class="panel-header">
			<?php
			if ( '' !== $icon ) {
				echo $icon; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Theme-owned inline SVG.
			}
			?>
			<h2><?php esc_html_e( 'Messages', 'zymarg-communication' ); ?></h2>
		</div>
		<p class="panel-desc"><?php esc_html_e( 'Your conversations with sellers about orders and products.', 'zymarg-communication' ); ?></p>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Whether the caller asked for host chrome AND the flag allows it. Accepts
	 * the raw shortcode `$atts`, which WordPress hands over as a string when the
	 * shortcode is used with no attributes — hence the is_array() guard.
	 *
	 * @param array<string, mixed>|string $atts Shortcode attributes.
	 */
	private static function hostChromeRequested( $atts ): bool {
		if ( ! is_array( $atts ) || empty( $atts['host_chrome'] ) ) {
			return false;
		}
		return self::hostChromeEnabled();
	}

	/*
	 * Fail-CLOSED, unlike the surface flags above. Those fail open because a
	 * missing flag service should never hide an inbox someone is trying to read.
	 * This one is cosmetic and opt-in: the edge-to-edge layout is the known-good
	 * default, so when we cannot confirm the operator asked for host chrome we
	 * must not silently restyle two live customer-facing pages.
	 */
	private static function hostChromeEnabled(): bool {
		if ( ! ServiceProvider::has( FeatureFlagService::class ) ) {
			return false;
		}
		$flags = ServiceProvider::get( FeatureFlagService::class );
		return (bool) $flags->isEnabled( 'surface.host_native_chrome' );
	}

	private static function isEnabled(): bool {
		if ( ! ServiceProvider::has( FeatureFlagService::class ) ) {
			return true; // Fail‑open before flags load.
		}
		$flags = ServiceProvider::get( FeatureFlagService::class );
		return (bool) $flags->isEnabled( 'surface.buyer_inbox' );
	}

	private static function attachmentsEnabled(): bool {
		if ( ! ServiceProvider::has( FeatureFlagService::class ) ) {
			return true;
		}
		$flags = ServiceProvider::get( FeatureFlagService::class );
		return (bool) $flags->isEnabled( 'message.attachments' );
	}

	private static function reactionsEnabled(): bool {
		if ( ! ServiceProvider::has( FeatureFlagService::class ) ) {
			return true;
		}
		$flags = ServiceProvider::get( FeatureFlagService::class );
		return (bool) $flags->isEnabled( 'message.reactions' );
	}

	private static function repliesEnabled(): bool {
		if ( ! ServiceProvider::has( FeatureFlagService::class ) ) {
			return true;
		}
		$flags = ServiceProvider::get( FeatureFlagService::class );
		return (bool) $flags->isEnabled( 'message.replies' );
	}

	private static function typingIndicatorEnabled(): bool {
		if ( ! ServiceProvider::has( FeatureFlagService::class ) ) {
			return true;
		}
		$flags = ServiceProvider::get( FeatureFlagService::class );
		return (bool) $flags->isEnabled( 'message.typing_indicator' );
	}

	private static function presenceEnabled(): bool {
		if ( ! ServiceProvider::has( FeatureFlagService::class ) ) {
			return true;
		}
		$flags = ServiceProvider::get( FeatureFlagService::class );
		return (bool) $flags->isEnabled( 'message.online_status' );
	}
}
