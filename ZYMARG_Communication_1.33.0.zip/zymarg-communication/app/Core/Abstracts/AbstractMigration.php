<?php
/**
 * ZYMARG Communication — Base migration.
 *
 * Provides the `up()` / `down()` contract and shared helpers used by every
 * migration in `Infrastructure/Database/Migrations/`.
 *
 * @package    ZymargCommunication
 * @version    1.1.0
 */

namespace ZymargCommunication\Core\Abstracts;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

abstract class AbstractMigration {

	/**
	 * Apply the migration. Must be idempotent — activation and Updater::check
	 * may call it multiple times.
	 */
	abstract public function up(): void;

	/**
	 * Optional reverse. Migrations are not required to be reversible.
	 */
	public function down(): void {
		// Optional.
	}

	protected function charsetCollate(): string {
		global $wpdb;
		return $wpdb->get_charset_collate();
	}

	protected function tableName( string $suffix ): string {
		global $wpdb;
		return $wpdb->prefix . $suffix;
	}

	protected function dbDelta( string $sql ): void {
		if ( ! function_exists( 'dbDelta' ) ) {
			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		}
		dbDelta( $sql );
	}

	/**
	 * Whether the given column exists on the given table.
	 */
	protected function columnExists( string $table, string $column ): bool {
		global $wpdb;
		$result = $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s AND COLUMN_NAME = %s LIMIT 1',
				$table,
				$column
			)
		);
		return ! empty( $result );
	}
}
