<?php
/**
 * Base REST controller. Handles response formatting. All module controllers extend this.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Core\Abstracts;

use WP_REST_Request;
use WP_REST_Response;
use ZymargCommunication\Core\Exceptions\PluginException;
use ZymargCommunication\Core\Exceptions\ValidationException;
use ZymargCommunication\Infrastructure\Http\Responses\ApiResponse;
use ZymargCommunication\Infrastructure\Http\Responses\ErrorResponse;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

abstract class AbstractController {

	/** REST namespace shared by every module controller. */
	protected const NAMESPACE = 'zymarg-comm/v1';

	/**
	 * Register REST routes owned by this controller.
	 *
	 * Modules override this and call `register_rest_route()` inside it.
	 */
	abstract public function registerRoutes(): void;

	protected function ok( mixed $data = null, int $status = 200 ): WP_REST_Response {
		return ApiResponse::make( $data, $status );
	}

	protected function fail( string $code, string $message, int $status = 400, array $extra = array() ): WP_REST_Response {
		return ErrorResponse::make( $code, $message, $status, $extra );
	}

	/**
	 * Wraps a Service call and converts thrown plugin exceptions into REST error responses.
	 */
	protected function handle( callable $callback ): WP_REST_Response {
		try {
			$result = $callback();
			if ( $result instanceof WP_REST_Response ) {
				return $result;
			}
			return $this->ok( $result );
		} catch ( ValidationException $e ) {
			return $this->fail( $e->errorCode(), $e->getMessage(), $e->statusCode(), array( 'errors' => $e->errors() ) );
		} catch ( PluginException $e ) {
			return $this->fail( $e->errorCode(), $e->getMessage(), $e->statusCode() );
		} catch ( \Throwable $e ) {
			return $this->fail( 'server_error', __( 'Something went wrong.', 'zymarg-communication' ), 500 );
		}
	}

	protected function currentUserId(): int {
		return get_current_user_id();
	}

	protected function requireAdmin(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			throw new \ZymargCommunication\Core\Exceptions\UnauthorizedException( __( 'Admin privileges are required.', 'zymarg-communication' ) );
		}
	}

	protected function requireAuthenticated(): void {
		if ( ! is_user_logged_in() ) {
			throw new \ZymargCommunication\Core\Exceptions\UnauthorizedException( __( 'Authentication is required.', 'zymarg-communication' ) );
		}
	}

	protected function param( WP_REST_Request $request, string $key, mixed $default = null ): mixed {
		$value = $request->get_param( $key );
		return null === $value ? $default : $value;
	}
}
