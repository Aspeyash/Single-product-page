<?php
/**
 * Base service. Holds common utilities. All module services extend this.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Core\Abstracts;

use ZymargCommunication\Core\Contracts\ServiceInterface;
use ZymargCommunication\Shared\Traits\ChecksFeatureFlags;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

abstract class AbstractService implements ServiceInterface {
	use ChecksFeatureFlags;
}
