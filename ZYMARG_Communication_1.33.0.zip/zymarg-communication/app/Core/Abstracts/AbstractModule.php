<?php
/**
 * Base class for module registration.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Core\Abstracts;

use ZymargCommunication\Core\Contracts\ModuleInterface;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

abstract class AbstractModule implements ModuleInterface {

	abstract public function name(): string;

	abstract public function register(): void;
}
