<?php
/**
 * Base repository. Holds the wpdb reference. All module repositories extend this.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Core\Abstracts;

use ZymargCommunication\Core\Contracts\RepositoryInterface;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

abstract class AbstractRepository implements RepositoryInterface {

	protected \wpdb $wpdb;

	public function __construct() {
		global $wpdb;
		$this->wpdb = $wpdb;
	}

	/** Data source table name (without prefix), e.g. `zc_conversations`. */
	abstract protected function tableSuffix(): string;

	protected function table(): string {
		return $this->wpdb->prefix . $this->tableSuffix();
	}

	public function find( int $id ): ?object {
		$row = $this->wpdb->get_row(
			$this->wpdb->prepare( 'SELECT * FROM `' . $this->table() . '` WHERE id = %d LIMIT 1', $id )
		);
		return $row ?: null;
	}

	public function insert( array $data ): int {
		$ok = $this->wpdb->insert( $this->table(), $data );
		if ( false === $ok ) {
			return 0;
		}
		return (int) $this->wpdb->insert_id;
	}

	public function update( int $id, array $data ): bool {
		$affected = $this->wpdb->update( $this->table(), $data, array( 'id' => $id ) );
		return false !== $affected;
	}

	public function delete( int $id ): bool {
		$affected = $this->wpdb->delete( $this->table(), array( 'id' => $id ) );
		return false !== $affected;
	}
}
