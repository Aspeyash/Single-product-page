<?php
/**
 * Thrown when a database operation fails.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Core\Exceptions;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DatabaseException extends PluginException {
	protected int $status_code = 500;
	protected string $error_code = 'database_error';
}
