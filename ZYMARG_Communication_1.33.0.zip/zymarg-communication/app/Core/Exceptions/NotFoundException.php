<?php
/**
 * Thrown when a requested resource does not exist.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Core\Exceptions;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class NotFoundException extends PluginException {
	protected int $status_code = 404;
	protected string $error_code = 'not_found';
}
