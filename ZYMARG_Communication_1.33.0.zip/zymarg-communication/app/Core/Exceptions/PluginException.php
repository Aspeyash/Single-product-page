<?php
/**
 * Base exception for all plugin-thrown exceptions.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Core\Exceptions;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PluginException extends \RuntimeException {

	protected int $status_code = 500;
	protected string $error_code = 'plugin_error';

	public function statusCode(): int {
		return $this->status_code;
	}

	public function errorCode(): string {
		return $this->error_code;
	}
}
