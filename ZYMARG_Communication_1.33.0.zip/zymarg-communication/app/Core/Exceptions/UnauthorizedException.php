<?php
/**
 * Thrown when a user lacks permission for the requested action.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Core\Exceptions;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class UnauthorizedException extends PluginException {
	protected int $status_code = 403;
	protected string $error_code = 'unauthorized';
}
