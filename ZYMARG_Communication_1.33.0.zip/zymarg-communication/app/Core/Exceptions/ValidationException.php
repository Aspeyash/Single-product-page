<?php
/**
 * Thrown when incoming data fails validation.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Core\Exceptions;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ValidationException extends PluginException {

	protected int $status_code = 422;
	protected string $error_code = 'validation_failed';

	/** @var array<string, string> */
	protected array $errors;

	public function __construct( string $message = 'Validation failed', array $errors = array() ) {
		parent::__construct( $message );
		$this->errors = $errors;
	}

	/** @return array<string, string> */
	public function errors(): array {
		return $this->errors;
	}
}
