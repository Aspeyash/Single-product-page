<?php
/**
 * String manipulation utilities.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Core\Helpers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class StringHelper {

	public static function truncate( string $value, int $length, string $suffix = '…' ): string {
		if ( strlen( $value ) <= $length ) {
			return $value;
		}
		return rtrim( substr( $value, 0, $length ) ) . $suffix;
	}

	public static function randomToken( int $bytes = 16 ): string {
		try {
			return bin2hex( random_bytes( max( 4, $bytes ) ) );
		} catch ( \Throwable $e ) {
			return wp_generate_password( $bytes * 2, false, false );
		}
	}
}
