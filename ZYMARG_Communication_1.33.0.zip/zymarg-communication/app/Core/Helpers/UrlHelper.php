<?php
/**
 * URL building and validation utilities.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Core\Helpers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class UrlHelper {

	public static function restUrl( string $path = '' ): string {
		return rest_url( 'zymarg-comm/v1/' . ltrim( $path, '/' ) );
	}

	public static function isSafeRedirect( string $url ): bool {
		$parsed = wp_parse_url( $url );
		if ( ! $parsed || empty( $parsed['host'] ) ) {
			return false;
		}
		return wp_parse_url( home_url(), PHP_URL_HOST ) === $parsed['host'];
	}
}
