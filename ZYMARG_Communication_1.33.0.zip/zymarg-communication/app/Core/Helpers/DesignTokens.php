<?php
/**
 * ZYMARG Communication — Design Tokens (PHP).
 *
 * Mirror of assets/css/frontend/zymarg-comm-tokens.css (§ 16.1 two-file rule).
 * Any change to a token value must be committed to BOTH files.
 *
 * @package    ZymargCommunication
 * @version    1.6.1
 */

namespace ZymargCommunication\Core\Helpers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class DesignTokens {

	/* Primary palette */
	public const ZC_COLOR_PRIMARY            = '#9500A5';
	public const ZC_COLOR_PRIMARY_DEEP       = '#36003D';
	public const ZC_COLOR_PRIMARY_FIXED      = '#ffd6fb';
	public const ZC_COLOR_PRIMARY_CONTAINER  = '#bd00d1';
	public const ZC_COLOR_PRIMARY_INVERSE    = '#fea9ff';
	public const ZC_COLOR_ON_PRIMARY_FIXED   = '#36003d';

	/* Secondary palette */
	public const ZC_COLOR_SECONDARY            = '#505f76';
	public const ZC_COLOR_SECONDARY_CONTAINER  = '#d0e1fb';

	/* Surface & background */
	public const ZC_COLOR_SURFACE            = '#FAF5FB';
	public const ZC_COLOR_SURFACE_CONTAINER  = '#eaedff';
	public const ZC_COLOR_SURFACE_LOWEST     = '#ffffff';
	public const ZC_COLOR_SURFACE_INVERSE    = '#36003D';

	/* Text */
	public const ZC_COLOR_TEXT_BODY  = '#534152';
	public const ZC_COLOR_INK        = '#36003D';
	public const ZC_COLOR_TEXT_MUTED = '#534152';

	/* Outline & border */
	public const ZC_COLOR_OUTLINE         = '#857183';
	public const ZC_COLOR_OUTLINE_VARIANT = '#d8bfd3';

	/* Semantic states */
	public const ZC_COLOR_SUCCESS = '#1A7F37';
	public const ZC_COLOR_WARNING = '#ED8936';
	public const ZC_COLOR_DANGER  = '#B3261E';
	public const ZC_COLOR_INFO    = '#9500A5';

	/* Admin surface tokens (1.14.0) - mirror of zymarg-comm-tokens.css. */
	public const ZC_COLOR_DIVIDER      = '#F3ECF3';
	public const ZC_COLOR_NEUTRAL_BG   = '#F0F0F1';
	public const ZC_COLOR_NEUTRAL_TEXT = '#646970';
	public const ZC_COLOR_SUCCESS_BG   = '#E6F4EA';
	public const ZC_COLOR_WARNING_BG   = '#FFF4E5';
	public const ZC_COLOR_ERROR_BG     = '#FDECEC';
	public const ZC_RADIUS_CONTROL     = '10px';
	public const ZC_CONTAINER_ADMIN    = '1200px';
	public const ZC_SHADOW_SURFACE     = '0 8px 24px rgba(19,27,46,0.06)';
	public const ZC_SHADOW_BTN         = '0 4px 10px rgba(149,0,165,0.25)';
	public const ZC_SHADOW_BTN_HOVER   = '0 6px 14px rgba(149,0,165,0.30)';
	public const ZC_FOCUS_RING_ADMIN   = '0 0 0 3px rgba(149,0,165,0.12)';

	/* Typography */
	public const ZC_FONT_FAMILY           = "'Inter Variable', Inter, sans-serif";
	public const ZC_FONT_SIZE_XS          = '10px';
	public const ZC_FONT_SIZE_SM          = '12px';
	public const ZC_FONT_SIZE_BASE        = '14px';
	public const ZC_FONT_SIZE_MD          = '16px';
	public const ZC_FONT_SIZE_LG          = '18px';
	public const ZC_FONT_SIZE_XL          = '22px';
	public const ZC_FONT_SIZE_2XL         = '26px';
	public const ZC_FONT_SIZE_3XL         = '30px';
	public const ZC_FONT_WEIGHT_MEDIUM    = 500;
	public const ZC_FONT_WEIGHT_SEMIBOLD  = 600;
	public const ZC_FONT_WEIGHT_BOLD      = 700;
	public const ZC_FONT_WEIGHT_EXTRABOLD = 800;
	public const ZC_LINE_HEIGHT_TIGHT     = '1.2';
	public const ZC_LINE_HEIGHT_BASE      = '1.5';
	public const ZC_LINE_HEIGHT_RELAXED   = '1.75';

	/* Spacing */
	public const ZC_SPACE_1 = '2px';
	public const ZC_SPACE_2 = '4px';
	public const ZC_SPACE_3 = '8px';
	public const ZC_SPACE_4 = '12px';
	public const ZC_SPACE_5 = '16px';
	public const ZC_SPACE_6 = '24px';
	public const ZC_SPACE_7 = '32px';
	public const ZC_SPACE_8 = '48px';
	public const ZC_SPACE_9 = '64px';

	/* Border radius */
	public const ZC_RADIUS_SM   = '8px';
	public const ZC_RADIUS_MD   = '10px';
	public const ZC_RADIUS_LG   = '12px';
	public const ZC_RADIUS_XL   = '14px';
	public const ZC_RADIUS_2XL  = '16px';
	public const ZC_RADIUS_3XL  = '24px';
	public const ZC_RADIUS_FULL = '9999px';

	/* Shadows */
	public const ZC_SHADOW_SM    = '0 1px 3px rgba(149,0,165,0.08)';
	public const ZC_SHADOW_CARD  = '0 4px 16px rgba(149,0,165,0.10)';
	public const ZC_SHADOW_HOVER = '0 8px 24px rgba(149,0,165,0.16)';
	public const ZC_SHADOW_POPUP = '0 16px 48px rgba(149,0,165,0.20)';
	public const ZC_SHADOW_FOCUS = '0 0 0 4px rgba(149,0,165,0.15)';

	/* Animation */
	public const ZC_ANIM_FAST     = '100ms';
	public const ZC_ANIM_INPUT    = '180ms';
	public const ZC_ANIM_STANDARD = '300ms';
	public const ZC_ANIM_SLOW     = '500ms';
	public const ZC_ANIM_EASING   = 'ease-in-out';

	/* Component aliases (v1.12.20) — mirror of zymarg-comm-tokens.css. */
	public const ZC_ACCENT        = '#9500a5';
	public const ZC_ACCENT_STRONG = '#bd00d1';
	public const ZC_ACCENT_SOFT   = '#fea9ff';
	public const ZC_BG            = '#ffffff';
	public const ZC_BG_ALT        = '#FAF5FB';
	public const ZC_FG            = '#36003d';
	public const ZC_MUTED         = '#534152';
	public const ZC_BORDER        = '#d8bfd3';
	public const ZC_DANGER        = '#B3261E';
	public const ZC_RADIUS        = '16px';

	/** @return array<string, string|int> Flattened token map (key => value). */
	public static function all(): array {
		$out = array();
		foreach ( ( new \ReflectionClass( self::class ) )->getConstants() as $name => $value ) {
			$out[ $name ] = $value;
		}
		return $out;
	}
}
