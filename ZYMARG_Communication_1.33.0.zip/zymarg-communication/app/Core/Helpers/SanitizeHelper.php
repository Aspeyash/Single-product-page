<?php
/**
 * Shared sanitization utilities beyond core WordPress functions.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Core\Helpers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class SanitizeHelper {

	public static function messageBody( string $body ): string {
		// Preserve line breaks; strip disallowed HTML.
		return wp_kses(
			trim( $body ),
			array(
				'a'      => array( 'href' => array(), 'title' => array(), 'rel' => array(), 'target' => array() ),
				'br'     => array(),
				'strong' => array(),
				'em'     => array(),
				'code'   => array(),
				'p'      => array(),
			)
		);
	}

	public static function flagKey( string $key ): string {
		return preg_replace( '/[^a-z0-9._]/', '', strtolower( $key ) );
	}

	public static function emoji( string $emoji ): string {
		$emoji = trim( $emoji );
		if ( function_exists( 'mb_substr' ) ) {
			return mb_substr( $emoji, 0, 4, 'UTF-8' );
		}
		return substr( $emoji, 0, 16 );
	}
}
