<?php
/**
 * Date formatting and timezone utilities.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Core\Helpers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class DateHelper {

	public static function now(): string {
		return current_time( 'mysql', true );
	}

	public static function daysAgo( int $days ): string {
		return gmdate( 'Y-m-d H:i:s', time() - ( $days * DAY_IN_SECONDS ) );
	}

	public static function toIso8601( ?string $mysql_datetime ): ?string {
		if ( empty( $mysql_datetime ) ) {
			return null;
		}
		$ts = strtotime( $mysql_datetime . ' UTC' );
		return $ts ? gmdate( 'c', $ts ) : null;
	}
}
