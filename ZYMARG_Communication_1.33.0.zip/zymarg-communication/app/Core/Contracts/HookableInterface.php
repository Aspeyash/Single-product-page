<?php
/**
 * Contract all Hooks classes must implement.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Core\Contracts;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

interface HookableInterface {

	/**
	 * Register all WordPress hooks owned by this class.
	 */
	public static function register(): void;
}
