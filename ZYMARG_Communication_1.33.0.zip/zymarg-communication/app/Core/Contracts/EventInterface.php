<?php
/**
 * Contract all event objects must implement.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Core\Contracts;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

interface EventInterface {

	/** Event name / slug used by the dispatcher. */
	public function name(): string;

	/** Event payload as an associative array. */
	public function payload(): array;
}
