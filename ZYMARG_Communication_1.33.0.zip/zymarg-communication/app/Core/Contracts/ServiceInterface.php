<?php
/**
 * Marker contract for all Service classes.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Core\Contracts;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

interface ServiceInterface {
}
