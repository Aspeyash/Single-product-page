<?php
/**
 * Contract the FeatureFlagService must implement.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Core\Contracts;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

interface FeatureFlagInterface {

	public function isEnabled( string $flag_key ): bool;

	public function enable( string $flag_key ): bool;

	public function disable( string $flag_key ): bool;

	/** @return array<int, array<string, mixed>> */
	public function getAll(): array;
}
