<?php
/**
 * Contract all repositories must implement.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Core\Contracts;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

interface RepositoryInterface {

	public function find( int $id ): ?object;

	public function insert( array $data ): int;

	public function update( int $id, array $data ): bool;

	public function delete( int $id ): bool;
}
