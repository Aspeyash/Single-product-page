<?php
/**
 * Contract for cache drivers.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Core\Contracts;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

interface CacheInterface {

	public function get( string $key ): mixed;

	public function set( string $key, mixed $value, int $ttl = 0 ): bool;

	public function delete( string $key ): bool;

	public function flush(): bool;
}
