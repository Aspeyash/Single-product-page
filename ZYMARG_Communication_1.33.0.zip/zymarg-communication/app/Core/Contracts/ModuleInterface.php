<?php
/**
 * Contract all Module classes must implement.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Core\Contracts;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

interface ModuleInterface {

	/** Slug for this module (e.g. "conversation", "message"). */
	public function name(): string;

	/** Register the module with the plugin container / hook loader. */
	public function register(): void;
}
