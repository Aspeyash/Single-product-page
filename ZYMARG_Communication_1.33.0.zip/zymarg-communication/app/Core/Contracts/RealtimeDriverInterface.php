<?php
/**
 * Contract every realtime driver must implement.
 *
 * Aligned with CONTRIBUTING.md § 11 — all drivers expose the same surface so
 * calling code can swap between Pusher / WebSocket / SSE / Polling without
 * touching module code.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Core\Contracts;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

interface RealtimeDriverInterface {

	/** Machine name of this driver (e.g. `pusher`, `websocket`). */
	public function name(): string;

	/** True when driver has enough config to publish. */
	public function isConfigured(): bool;

	/** True when driver is reachable (best-effort; may hit network). */
	public function isConnected(): bool;

	/**
	 * Publish an event to a channel.
	 *
	 * @param string               $channel  Channel name.
	 * @param string               $event    Event name.
	 * @param array<string, mixed> $payload  Event body.
	 * @return bool True on success, false on failure. Must never throw.
	 */
	public function publish( string $channel, string $event, array $payload ): bool;

	/**
	 * Subscribe a server-side channel (no-op for stateless drivers).
	 *
	 * @param string $channel Channel name.
	 */
	public function subscribe( string $channel ): void;

	/**
	 * Return an auth signature for private/presence channels.
	 *
	 * Only drivers that need per-user auth (Pusher, WebSocket) return a
	 * non-empty string. Others may return an empty string.
	 */
	public function authenticate( int $user_id ): string;

	/**
	 * Issue a client-side connection token bundle.
	 *
	 * Returned array shape: [ 'driver' => string, 'endpoint' => string,
	 * 'auth' => string, 'channel' => string, 'expires_at' => int, ... ].
	 *
	 * @return array<string, mixed>
	 */
	public function issueClientToken( int $user_id ): array;
}
