<?php
/**
 * ZYMARG Communication — Uninstaller.
 *
 * Runs on plugin deletion. Drops every plugin-owned database table, deletes
 * every plugin option, removes plugin-owned pages, and clears the plugin
 * uploads directory.
 *
 * @package    ZymargCommunication
 * @version    1.1.0
 */

namespace ZymargCommunication\Bootstrap;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Uninstaller {

	/**
	 * Every plugin-owned table suffix. The `wpdb->prefix` is prepended when
	 * dropping. `zc_audit_logs` is listed here so a future audit-logs
	 * migration is also cleaned up on uninstall.
	 *
	 * @var array<int, string>
	 */
	private const TABLES = [
		'zc_feature_flags',
		'zc_conversations',
		'zc_participants',
		'zc_messages',
		'zc_attachments',
		'zc_reactions',
		'zc_notifications',
		'zc_moderation_logs',
		'zc_analytics_events',
		'zc_audit_logs',
		'zc_support_tickets',
	];

	/**
	 * Option that opts IN to destroying data on uninstall. Absent or falsy — the
	 * default — means deleting the plugin keeps every conversation, message,
	 * ticket, agent and setting exactly where it is.
	 */
	public const OPTION_PURGE = 'zymarg_comm_delete_data_on_uninstall';

	/**
	 * Uninstall. NON-DESTRUCTIVE BY DEFAULT (1.32.5).
	 *
	 * Until 1.32.5 this dropped all eleven plugin tables, deleted every
	 * `zymarg_comm_*` option, destroyed the registered pages and recursively
	 * deleted the uploads directory — unconditionally, with no opt-out and no
	 * warning. Deleting the plugin in order to install a newer zip (which is
	 * how this plugin is distributed — there is no WordPress.org updater)
	 * therefore threw away every support conversation, every message and
	 * attachment, the ticket history with its ratings, the agent list, and the
	 * `surface.support_chat` switch itself. Because that switch ships disabled,
	 * support then came back OFF and the front end answered "Could not open
	 * support" until someone noticed and re-enabled it.
	 *
	 * Reinstalling a plugin must never be a data-loss event, so the destructive
	 * path is now strictly opt-in: set the OPTION_PURGE option, or return true
	 * from the `zymarg_comm_delete_data_on_uninstall` filter. Everything else
	 * that runs here is safe — caches and transients only.
	 */
	public static function run(): void {
		// Always safe: transient/cache cleanup, so a reinstall starts with a
		// clean cache but keeps all real data.
		self::flushCaches();

		if ( ! self::shouldPurge() ) {
			do_action( 'zymarg_comm_uninstalled', false );
			return;
		}

		self::dropTables();
		self::deleteOptions();
		PageRegistrar::destroy();
		self::deleteUploadsDirectory();

		do_action( 'zymarg_comm_uninstalled', true );
	}

	/**
	 * Has the site owner explicitly asked for their data to be destroyed?
	 *
	 * Defaults to false. The filter runs last so a site can force either answer
	 * from code (a staging teardown script, for instance).
	 */
	private static function shouldPurge(): bool {
		$opt = get_option( self::OPTION_PURGE, false );
		$out = ( '1' === $opt || 1 === $opt || true === $opt || 'yes' === $opt || 'true' === $opt );

		return (bool) apply_filters( 'zymarg_comm_delete_data_on_uninstall', $out );
	}

	/**
	 * Clear this plugin's transients. Safe on every uninstall: caches rebuild
	 * themselves, so nothing of value is lost.
	 *
	 * Rate-limit counters and presence keys are deliberately included — leaving
	 * a stale rate-limit counter behind could greet a reinstalled plugin with
	 * an immediate 429.
	 */
	private static function flushCaches(): void {
		global $wpdb;

		foreach ( array( 'zymarg_comm_', 'zymarg_rl_', 'zymarg_presence_' ) as $prefix ) {
			$like = $wpdb->esc_like( '_transient_' . $prefix ) . '%';
			$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $like ) );

			$like = $wpdb->esc_like( '_transient_timeout_' . $prefix ) . '%';
			$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $like ) );
		}

		wp_cache_flush();
	}

	private static function dropTables(): void {
		global $wpdb;
		foreach ( self::TABLES as $suffix ) {
			$table = $wpdb->prefix . $suffix;
			$wpdb->query( "DROP TABLE IF EXISTS `{$table}`" ); // phpcs:ignore WordPress.DB.PreparedSQL
		}
	}

	private static function deleteOptions(): void {
		global $wpdb;
		$like = $wpdb->esc_like( 'zymarg_comm_' ) . '%';
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
				$like
			)
		);
	}

	private static function deleteUploadsDirectory(): void {
		$upload_dir = wp_upload_dir();
		if ( empty( $upload_dir['basedir'] ) ) {
			return;
		}
		$target = trailingslashit( $upload_dir['basedir'] ) . 'zymarg-communication';
		if ( ! is_dir( $target ) ) {
			return;
		}
		self::rmdirRecursive( $target );
	}

	private static function rmdirRecursive( string $dir ): void {
		if ( ! is_dir( $dir ) ) {
			return;
		}
		$entries = @scandir( $dir );
		if ( ! is_array( $entries ) ) {
			@rmdir( $dir );
			return;
		}
		foreach ( $entries as $entry ) {
			if ( '.' === $entry || '..' === $entry ) {
				continue;
			}
			$path = $dir . DIRECTORY_SEPARATOR . $entry;
			if ( is_dir( $path ) ) {
				self::rmdirRecursive( $path );
			} else {
				@unlink( $path );
			}
		}
		@rmdir( $dir );
	}
}
