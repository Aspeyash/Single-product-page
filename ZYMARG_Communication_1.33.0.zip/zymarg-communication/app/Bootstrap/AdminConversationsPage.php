<?php
/**
 * AdminConversationsPage — fully AJAX site-wide conversation browser.
 *
 * Lists every conversation with status filtering and a read-only viewer.
 * All reads go through AdminViewService, so opening a conversation never
 * marks messages as read, never fires notifications, and is always recorded
 * in the audit log (admin privacy contract).
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Bootstrap;

use ZymargCommunication\Modules\Conversation\Repositories\ConversationRepository;
use ZymargCommunication\Modules\Conversation\Repositories\ParticipantRepository;
use ZymargCommunication\Modules\Message\Repositories\MessageRepository;
use ZymargCommunication\Modules\Moderation\Services\AdminViewService;
use ZymargCommunication\Modules\Security\Repositories\SecurityRepository;
use ZymargCommunication\Modules\Security\Services\AuditLogService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdminConversationsPage {

	private static bool $registered = false;
	public const MENU_SLUG     = 'zymarg-comm-conversations';
	private const NONCE_ACTION = 'zymarg_comm_conv_load';

	public static function register(): void {
		if ( self::$registered ) {
			return;
		}
		self::$registered = true;
		add_action( 'admin_menu',                        array( self::class, 'registerMenu' ), 40 );
		add_action( 'wp_ajax_zymarg_comm_conv_list',     array( self::class, 'handleList' ) );
		add_action( 'wp_ajax_zymarg_comm_conv_view',     array( self::class, 'handleView' ) );
	}

	public static function registerMenu(): void {
		add_submenu_page(
			AdminMenu::MENU_SLUG,
			__( 'Conversations', 'zymarg-communication' ),
			__( 'Conversations', 'zymarg-communication' ),
			'manage_options',
			self::MENU_SLUG,
			array( self::class, 'render' )
		);
	}

	// =========================================================================
	// Service builders (self-contained; no container dependency at ajax time)
	// =========================================================================

	private static function conversations(): ConversationRepository {
		return new ConversationRepository();
	}

	private static function adminView(): AdminViewService {
		return new AdminViewService(
			new ConversationRepository(),
			new ParticipantRepository(),
			new MessageRepository(),
			new AuditLogService( new SecurityRepository() )
		);
	}

	/** @return array<string,string> */
	private static function statuses(): array {
		return array(
			''                 => __( 'All', 'zymarg-communication' ),
			'active'           => __( 'Active', 'zymarg-communication' ),
			'reported'         => __( 'Reported', 'zymarg-communication' ),
			'pending_approval' => __( 'Pending', 'zymarg-communication' ),
			'archived'         => __( 'Archived', 'zymarg-communication' ),
		);
	}

	private static function userName( int $user_id ): string {
		if ( $user_id <= 0 ) {
			return __( 'System', 'zymarg-communication' );
		}
		$u = get_userdata( $user_id );
		if ( $u && '' !== (string) $u->display_name ) {
			return (string) $u->display_name;
		}
		return sprintf( 'User #%d', $user_id );
	}

	private static function statusBadge( string $status ): string {
		$colors = array(
			'active'           => '#46b450',
			'reported'         => '#dc3232',
			'pending_approval' => '#dba617',
			'archived'         => '#787c82',
		);
		$c = isset( $colors[ $status ] ) ? $colors[ $status ] : '#787c82';
		return '<span style="display:inline-block;padding:2px 8px;border-radius:10px;font-size:11px;color:var(--zc-color-surface-lowest);background:' . esc_attr( $c ) . ';">' . esc_html( $status ) . '</span>';
	}

	// =========================================================================
	// Render shell
	// =========================================================================

	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$nonce    = wp_create_nonce( self::NONCE_ACTION );
		$ajax_url = admin_url( 'admin-ajax.php' );
		$status   = isset( $_GET['status'] ) ? sanitize_key( (string) wp_unslash( $_GET['status'] ) ) : '';
		$statuses = self::statuses();
		if ( ! array_key_exists( $status, $statuses ) ) {
			$status = '';
		}
		?>
		<div class="wrap zcm-admin-page zymarg-comm-conversations">
		<style>
		.zcm-admin-page{max-width:1180px;}
		.zcm-admin-page > h1{margin:0 0 6px;padding:0;font-size:23px;line-height:1.3;}
		.zcm-admin-page .description{font-size:13px;color:var(--zc-color-neutral-text);margin:0 0 20px;max-width:840px;line-height:1.6;}
		.zcm-admin-page .nav-tab-wrapper{display:flex;flex-wrap:wrap;gap:6px;align-items:flex-end;margin:0 0 24px;padding:0;border-bottom:1px solid var(--zc-color-divider);}
		.zcm-admin-page .nav-tab{float:none;display:inline-block;margin:0;padding:9px 16px;font-size:13px;font-weight:500;line-height:1.5;text-decoration:none;cursor:pointer;color:var(--zc-color-text-muted);background:var(--zc-color-neutral-bg);border:1px solid var(--zc-color-divider);border-bottom:none;border-radius:6px 6px 0 0;}
		.zcm-admin-page .nav-tab:hover{background:#fff;color:var(--zc-color-primary-deep);}
		.zcm-admin-page .nav-tab-active,.zcm-admin-page .nav-tab-active:hover{background:#fff;color:var(--zc-color-primary);font-weight:600;border-bottom:1px solid #fff;margin-bottom:-1px;box-shadow:inset 0 -2px 0 var(--zc-color-primary);}
		.zcm-admin-page .zcm-count{color:var(--zc-color-neutral-text);font-size:13px;margin:0 0 12px;}
		.zcm-admin-page table.wp-list-table{display:table;width:100%;border-collapse:separate;border-spacing:0;table-layout:auto;margin-top:0;background:#fff;border:1px solid var(--zc-color-divider);border-radius:8px;overflow:hidden;}
		.zcm-admin-page table.wp-list-table thead{display:table-header-group;}
		.zcm-admin-page table.wp-list-table tbody{display:table-row-group;}
		.zcm-admin-page table.wp-list-table tr{display:table-row;}
		.zcm-admin-page table.wp-list-table th,.zcm-admin-page table.wp-list-table td{display:table-cell;text-align:left;padding:12px 16px;vertical-align:middle;border-bottom:1px solid var(--zc-color-neutral-bg);font-size:13px;}
		.zcm-admin-page table.wp-list-table thead th{font-weight:600;color:var(--zc-color-ink);background:var(--zc-color-surface);white-space:nowrap;}
		.zcm-admin-page table.wp-list-table tbody tr:last-child td{border-bottom:none;}
		.zcm-admin-page table.wp-list-table tbody tr:hover{background:var(--zc-color-surface);}
		.zcm-admin-page .zcm-conv-viewer{margin:0 0 20px;box-shadow:0 1px 3px rgba(0,0,0,.06);}
		.zcm-admin-page .button + .button{margin-left:6px;}
		</style>
			<?php AdminMenu::renderHeader( __( 'ZYMARG Communication', 'zymarg-communication' ), __( 'Conversations — Browse and audit conversations across your site', 'zymarg-communication' ) ); ?>
			<p class="description" style="margin:8px 0 16px;"><?php esc_html_e( 'Admin views are read-only. Opening a conversation never marks messages as read and is recorded in the audit log.', 'zymarg-communication' ); ?></p>

			<h2 class="nav-tab-wrapper" style="margin-bottom:16px;">
				<?php foreach ( $statuses as $key => $label ) : ?>
				<a href="#" class="nav-tab zcm-conv-filter<?php echo $key === $status ? ' nav-tab-active' : ''; ?>" data-status="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></a>
				<?php endforeach; ?>
			</h2>

			<div id="zcm-conv-view" style="display:none;margin-bottom:20px;"></div>
			<div id="zcm-conv-content"><?php self::renderList( $status ); ?></div>

			<script>
			(function(){
				var AJAX  = <?php echo wp_json_encode( $ajax_url ); ?>;
				var NONCE = <?php echo wp_json_encode( $nonce ); ?>;
				var content = document.getElementById('zcm-conv-content');
				var viewBox = document.getElementById('zcm-conv-view');
				if (!content) return;

				function post(action, extra){
					var d = new URLSearchParams();
					d.append('action', action);
					d.append('_wpnonce', NONCE);
					for (var k in extra){ d.append(k, extra[k]); }
					return fetch(AJAX, {method:'POST', credentials:'same-origin', body:d}).then(function(r){ return r.json(); });
				}

				function loadList(status){
					content.style.opacity = '0.5';
					post('zymarg_comm_conv_list', {status:status}).then(function(res){
						if (res.success){ content.innerHTML = res.data.html; }
						content.style.opacity = '1';
					}).catch(function(){ content.style.opacity = '1'; });
				}

				content.addEventListener('click', function(e){
					var v = e.target.closest('.zcm-conv-view-btn');
					if (v){ e.preventDefault();
						viewBox.style.display = 'block';
						viewBox.innerHTML = '<div class="zymarg-loading" role="status" aria-live="polite" style="padding:16px;"><span class="zymarg-spark zymarg-spark--md"><svg class="zymarg-spark__svg" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="ZYMARG Discovery Spark" focusable="false"><g class="zymarg-spark-group--accent"><path class="zymarg-spark-item--purple" d="M10.4 5.4c0 1.32-0.24 2.4-1.44 2.4 1.2 0 1.44 1.08 1.44 2.4 0-1.32 0.24-2.4 1.44-2.4-1.2 0-1.44-1.08-1.44-2.4z"/><path class="zymarg-spark-item--gold" d="M10.4 6.0c0 0.96-0.18 1.8-1.08 1.8 0.9 0 1.08 0.84 1.08 1.8 0-0.9 0.18-1.8 1.08-1.8-0.9 0-1.08-0.84-1.08-1.8z"/></g><g class="zymarg-spark-group--companion"><path class="zymarg-spark-item--purple" d="M9.5 10.92c0 2.25-0.45 4.12-2.4 4.12 1.95 0 2.4 1.87 2.4 4.12 0-2.25 0.45-4.12 2.4-4.12-1.95 0-2.4-1.87-2.4-4.12z"/><path class="zymarg-spark-item--gold" d="M9.5 11.5c0 1.9-0.38 3.54-2.0 3.54 1.62 0 2.0 1.64 2.0 3.54 0-1.9 0.38-3.54 2.0-3.54-1.62 0-2.0-1.64-2.0-3.54z"/></g><g class="zymarg-spark-group--hero"><path class="zymarg-spark-item--purple" d="M15.2 5.6c0 3.45-0.69 6.3-4.08 6.3 3.39 0 4.08 2.85 4.08 6.3 0-3.45 0.69-6.3 4.08-6.3-3.39 0-4.08-2.85-4.08-6.3z"/><path class="zymarg-spark-item--gold" d="M15.2 6.5c0 2.9-0.58 5.4-3.39 5.4 2.81 0 3.39 2.5 3.39 5.4 0-2.9 0.58-5.4 3.39-5.4-2.81 0-3.39-2.5-3.39-5.4z"/></g></svg></span><span class="zymarg-loading__text">Loading conversation...</span></div>';
						post('zymarg_comm_conv_view', {conversation_id:v.dataset.id}).then(function(res){
							if (res.success){ viewBox.innerHTML = res.data.html; window.scrollTo(0, 0); }
							else { viewBox.innerHTML = '<div class="notice notice-error"><p>' + ((res.data && res.data.message) ? res.data.message : 'Failed to load.') + '</p></div>'; }
						}).catch(function(){ viewBox.innerHTML = '<div class="notice notice-error"><p>Error loading conversation.</p></div>'; });
					}
				});

				viewBox.addEventListener('click', function(e){
					if (e.target.closest('.zcm-conv-close')){ e.preventDefault(); viewBox.style.display='none'; viewBox.innerHTML=''; }
				});

				document.querySelectorAll('.zcm-conv-filter').forEach(function(btn){
					btn.addEventListener('click', function(e){
						e.preventDefault();
						document.querySelectorAll('.zcm-conv-filter').forEach(function(b){ b.classList.toggle('nav-tab-active', b===btn); });
						loadList(this.dataset.status || '');
					});
				});
			})();
			</script>
		</div>
		<?php
	}

	// =========================================================================
	// List (server-rendered + ajax reload)
	// =========================================================================

	private static function renderList( string $status ): void {
		$filter = ( '' === $status ) ? null : $status;
		$repo   = self::conversations();
		$convs  = $repo->listAll( $filter, 50, 0 );
		$total  = $repo->countAll( $filter );
		$msgs   = new MessageRepository();
		$parts  = new ParticipantRepository();
		?>
		<p class="zcm-count"><?php echo esc_html( sprintf( _n( '%d conversation', '%d conversations', $total, 'zymarg-communication' ), $total ) ); ?></p>
		<table class="wp-list-table widefat fixed striped">
			<thead>
				<tr>
					<th style="width:60px;"><?php esc_html_e( 'ID', 'zymarg-communication' ); ?></th>
					<th style="width:120px;"><?php esc_html_e( 'Status', 'zymarg-communication' ); ?></th>
					<th><?php esc_html_e( 'Started by', 'zymarg-communication' ); ?></th>
					<th style="width:110px;"><?php esc_html_e( 'Participants', 'zymarg-communication' ); ?></th>
					<th style="width:90px;"><?php esc_html_e( 'Messages', 'zymarg-communication' ); ?></th>
					<th style="width:170px;"><?php esc_html_e( 'Last activity', 'zymarg-communication' ); ?></th>
					<th style="width:90px;"></th>
				</tr>
			</thead>
			<tbody>
			<?php if ( empty( $convs ) ) : ?>
				<tr><td colspan="7" style="padding:20px;color:var(--zc-color-text-body);"><?php esc_html_e( 'No conversations found.', 'zymarg-communication' ); ?></td></tr>
			<?php else : foreach ( $convs as $conv ) :
				$c        = $conv->toArray();
				$cid      = (int) $c['id'];
				$p_count  = count( $parts->findForConversation( $cid ) );
				$m_count  = $msgs->countForConversation( $cid );
				$last     = ! empty( $c['last_message_at'] ) ? $c['last_message_at'] : $c['created_at'];
				?>
				<tr>
					<td>#<?php echo (int) $cid; ?></td>
					<td><?php echo self::statusBadge( (string) $c['status'] ); ?></td>
					<td><?php echo esc_html( self::userName( (int) $c['initiated_by'] ) ); ?></td>
					<td><?php echo (int) $p_count; ?></td>
					<td><?php echo (int) $m_count; ?></td>
					<td><?php echo esc_html( self::humanTime( (string) $last ) ); ?></td>
					<td><button type="button" class="button button-small zcm-conv-view-btn" data-id="<?php echo (int) $cid; ?>"><?php esc_html_e( 'View', 'zymarg-communication' ); ?></button></td>
				</tr>
			<?php endforeach; endif; ?>
			</tbody>
		</table>
		<?php
	}

	private static function humanTime( string $mysql_utc ): string {
		if ( '' === $mysql_utc ) {
			return '-';
		}
		$ts = strtotime( $mysql_utc . ' UTC' );
		if ( ! $ts ) {
			return $mysql_utc;
		}
		return wp_date( 'M j, Y g:i a', $ts );
	}

	public static function handleList(): void {
		check_ajax_referer( self::NONCE_ACTION );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'zymarg-communication' ) ) );
		}
		$status = isset( $_POST['status'] ) ? sanitize_key( (string) wp_unslash( $_POST['status'] ) ) : '';
		if ( ! array_key_exists( $status, self::statuses() ) ) {
			$status = '';
		}
		ob_start();
		self::renderList( $status );
		wp_send_json_success( array( 'html' => ob_get_clean() ) );
	}

	// =========================================================================
	// Read-only conversation viewer
	// =========================================================================

	public static function handleView(): void {
		check_ajax_referer( self::NONCE_ACTION );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'zymarg-communication' ) ) );
		}
		$cid = isset( $_POST['conversation_id'] ) ? absint( $_POST['conversation_id'] ) : 0;
		if ( $cid <= 0 ) {
			wp_send_json_error( array( 'message' => __( 'Invalid conversation.', 'zymarg-communication' ) ) );
		}
		try {
			ob_start();
			self::renderView( $cid );
			wp_send_json_success( array( 'html' => ob_get_clean() ) );
		} catch ( \Throwable $e ) {
			if ( ob_get_length() ) {
				ob_end_clean();
			}
			wp_send_json_error( array( 'message' => $e->getMessage() ) );
		}
	}

	public static function renderView( int $conversation_id ): void {
		$data = self::adminView()->view( $conversation_id, get_current_user_id(), 200 );
		$conv = $data['conversation'];
		$participants = $data['participants'];
		$messages     = $data['messages'];
		?>
		<div class="zcm-conv-viewer" style="border:1px solid var(--zc-color-divider);border-radius:6px;background:var(--zc-color-surface-lowest);">
			<div style="display:flex;justify-content:space-between;align-items:center;padding:12px 16px;border-bottom:1px solid var(--zc-color-divider);background:var(--zc-color-surface);">
				<strong><?php echo esc_html( sprintf( __( 'Conversation #%d', 'zymarg-communication' ), (int) $conv['id'] ) ); ?></strong>
				<button type="button" class="button button-small zcm-conv-close"><?php esc_html_e( 'Close', 'zymarg-communication' ); ?></button>
			</div>
			<div style="padding:10px 16px;border-bottom:1px solid var(--zc-color-divider);color:var(--zc-color-text-muted);font-size:13px;">
				<?php echo self::statusBadge( (string) $conv['status'] ); ?>
				&nbsp;&middot;&nbsp;
				<?php echo esc_html( sprintf( __( 'Participants: %s', 'zymarg-communication' ), self::participantNames( $participants ) ) ); ?>
			</div>
			<div style="padding:16px;max-height:560px;overflow-y:auto;">
				<?php if ( empty( $messages ) ) : ?>
					<p style="color:var(--zc-color-text-body);"><?php esc_html_e( 'No messages in this conversation.', 'zymarg-communication' ); ?></p>
				<?php else : foreach ( $messages as $m ) : ?>
					<div style="margin-bottom:14px;">
						<div style="font-size:12px;color:var(--zc-color-neutral-text);margin-bottom:2px;">
							<strong style="color:var(--zc-color-ink);"><?php echo esc_html( self::userName( (int) $m['sender_id'] ) ); ?></strong>
							&nbsp;<?php echo esc_html( self::humanTime( (string) $m['created_at'] ) ); ?>
						</div>
						<div style="background:var(--zc-color-neutral-bg);border-radius:8px;padding:8px 12px;display:inline-block;max-width:80%;"><?php echo nl2br( esc_html( (string) $m['body'] ) ); ?></div>
					</div>
				<?php endforeach; endif; ?>
			</div>
		</div>
		<?php
	}

	/** @param array<int,array<string,mixed>> $participants */
	private static function participantNames( array $participants ): string {
		$names = array();
		foreach ( $participants as $p ) {
			$names[] = self::userName( (int) $p['user_id'] );
		}
		return empty( $names ) ? __( 'None', 'zymarg-communication' ) : implode( ', ', $names );
	}
}
