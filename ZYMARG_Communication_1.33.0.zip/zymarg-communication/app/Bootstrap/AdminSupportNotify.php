<?php
/**
 * AdminSupportNotify — tells a support agent, anywhere in wp-admin, that a
 * customer message is waiting.
 *
 * Notification is symmetric by design: live-chat.js notifies the CUSTOMER on the
 * frontend (delegating to the theme's unified toast), and this notifies the
 * ADMIN inside wp-admin, where that toast system does not exist.
 *
 * Loads on every admin screen -- not just the Admin<->User page -- because the
 * whole point is reaching an agent who is doing something else. It is a single
 * small script plus one REST poll, gated to users who can actually answer
 * support, so it costs nothing for everyone else.
 *
 * @package ZymargCommunication
 * @since   1.26.0
 */

namespace ZymargCommunication\Bootstrap;

use ZymargCommunication\Modules\Support\Services\SupportService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdminSupportNotify {

	private static bool $registered = false;

	/** Poll interval in milliseconds. Floor of 15s is enforced client-side. */
	private const POLL_MS = 30000;

	public static function register(): void {
		if ( self::$registered ) {
			return;
		}
		self::$registered = true;

		add_action( 'admin_enqueue_scripts', array( self::class, 'enqueue' ) );
	}

	public static function enqueue(): void {
		if ( ! self::userCanAnswer() || ! self::featureEnabled() ) {
			return;
		}

		$base    = defined( 'ZYMARG_COMM_URL' ) ? ZYMARG_COMM_URL : plugin_dir_url( ZYMARG_COMM_FILE );
		$version = defined( 'ZYMARG_COMM_VERSION' ) ? ZYMARG_COMM_VERSION : '1.26.0';

		wp_enqueue_script(
			'zymarg-comm-support-notify',
			$base . 'assets/js/admin/support-notify.js',
			array(),
			$version,
			true
		);

		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		$page   = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		wp_localize_script(
			'zymarg-comm-support-notify',
			'zymargCommNotify',
			array(
				'restUrl'        => esc_url_raw( rest_url( 'zymarg-comm/v1' ) ),
				'nonce'          => wp_create_nonce( 'wp_rest' ),
				'pollInterval'   => self::POLL_MS,
				'menuSlug'       => AdminSupportPage::MENU_SLUG,
				'supportUrl'     => esc_url_raw( admin_url( 'admin.php?page=' . AdminSupportPage::MENU_SLUG ) ),
				'onSupportPage'  => AdminSupportPage::MENU_SLUG === $page,
				'screenId'       => $screen ? (string) $screen->id : '',
			)
		);
	}

	/**
	 * Only users who can actually reply. `manage_options` covers the site owner;
	 * `zymarg_support_agent` is the delegated capability granted from the
	 * Admin<->User screen, so a support agent who is not an administrator still
	 * gets notified.
	 */
	private static function userCanAnswer(): bool {
		return current_user_can( 'manage_options' ) || current_user_can( 'zymarg_support_agent' );
	}

	/**
	 * Respect the support master switch. The feature ships OFF, and a disabled
	 * feature must not poll.
	 */
	private static function featureEnabled(): bool {
		if ( ! ServiceProvider::has( SupportService::class ) ) {
			return false;
		}

		try {
			$service = ServiceProvider::get( SupportService::class );

			return $service instanceof SupportService && $service->enabled();
		} catch ( \Throwable $e ) {
			return false;
		}
	}
}
