<?php
/**
 * SettingsRuntime — applies stored admin settings to live plugin behavior.
 *
 * Registered on boot. Bridges admin-configurable options (upload size/types,
 * email sender, rate limit, debug logging) into the runtime filters the
 * modules already expose, so Settings changes take effect immediately.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Bootstrap;

use ZymargCommunication\Modules\Settings\Repositories\SettingsRepository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class SettingsRuntime {

	private static bool $registered = false;

	public static function register(): void {
		if ( self::$registered ) {
			return;
		}
		self::$registered = true;

		add_filter( 'zymarg_comm_max_upload_bytes',      array( self::class, 'maxUploadBytes' ) );
		add_filter( 'zymarg_comm_allowed_upload_exts',   array( self::class, 'allowedExts' ) );
		add_filter( 'zymarg_comm_allowed_upload_mimes',  array( self::class, 'allowedMimes' ) );
		add_filter( 'zymarg_comm_notification_email',    array( self::class, 'notificationEmail' ) );
		add_filter( 'zymarg_comm_rate_limit_per_minute', array( self::class, 'ratePerMinute' ) );

		if ( '1' === (string) ( new SettingsRepository() )->get( 'debug_logging_enabled', '0' ) ) {
			add_action( 'rest_request_after_callbacks', array( self::class, 'logRestErrors' ), 10, 3 );
		}
	}

	/** @param mixed $default */
	public static function maxUploadBytes( $default ) {
		$mb = (int) ( new SettingsRepository() )->get( 'attachments_max_size_mb', 0 );
		return $mb > 0 ? $mb * 1024 * 1024 : $default;
	}

	/** @param mixed $default */
	public static function allowedExts( $default ) {
		return self::allowedExtList( (array) $default );
	}

	/** @param mixed $default */
	public static function allowedMimes( $default ) {
		$map   = array( 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp' );
		$exts  = self::allowedExtList( array( 'jpg', 'jpeg', 'png', 'webp' ) );
		$mimes = array();
		foreach ( $exts as $e ) {
			if ( isset( $map[ $e ] ) ) {
				$mimes[] = $map[ $e ];
			}
		}
		$mimes = array_values( array_unique( $mimes ) );
		return ! empty( $mimes ) ? $mimes : $default;
	}

	/**
	 * @param array<int,string> $default
	 * @return array<int,string>
	 */
	private static function allowedExtList( array $default ): array {
		$raw = (string) ( new SettingsRepository() )->get( 'attachments_allowed_types', '' );
		if ( '' === $raw ) {
			return $default;
		}
		$out = array();
		foreach ( explode( ',', strtolower( $raw ) ) as $t ) {
			$t = trim( $t );
			if ( 'jpg' === $t ) {
				$out[] = 'jpg';
				$out[] = 'jpeg';
			} elseif ( in_array( $t, array( 'png', 'webp', 'jpeg' ), true ) ) {
				$out[] = $t;
			}
		}
		$out = array_values( array_unique( $out ) );
		return ! empty( $out ) ? $out : $default;
	}

	/** @param mixed $email */
	public static function notificationEmail( $email ) {
		if ( ! is_array( $email ) ) {
			return $email;
		}
		$repo = new SettingsRepository();
		$name = (string) $repo->get( 'email_from_name', '' );
		$addr = (string) $repo->get( 'email_from_address', '' );
		$subj = (string) $repo->get( 'email_subject_template', '' );
		if ( '' !== $addr ) {
			$from      = '' !== $name ? sprintf( '%s <%s>', $name, $addr ) : $addr;
			$headers   = isset( $email['headers'] ) ? (array) $email['headers'] : array();
			$headers[] = 'From: ' . $from;
			$email['headers'] = $headers;
		}
		if ( '' !== $subj ) {
			$email['subject'] = str_replace( '{site}', (string) get_option( 'blogname' ), $subj );
		}
		return $email;
	}

	/** @param mixed $default */
	public static function ratePerMinute( $default ) {
		$min = (int) ( new SettingsRepository() )->get( 'rate_limit_per_minute', 0 );
		return $min > 0 ? $min : $default;
	}

	/**
	 * @param mixed $response
	 * @param mixed $handler
	 * @param mixed $request
	 * @return mixed
	 */
	public static function logRestErrors( $response, $handler, $request ) {
		$route = ( is_object( $request ) && method_exists( $request, 'get_route' ) ) ? (string) $request->get_route() : '';
		if ( '' === $route || false === strpos( $route, 'zymarg-comm/' ) ) {
			return $response;
		}
		if ( is_wp_error( $response ) ) {
			error_log( '[ZYMARG Communication] REST error on ' . $route . ': ' . $response->get_error_message() );
		} elseif ( $response instanceof \WP_REST_Response && $response->get_status() >= 400 ) {
			error_log( '[ZYMARG Communication] REST ' . (string) $response->get_status() . ' on ' . $route );
		}
		return $response;
	}
}
