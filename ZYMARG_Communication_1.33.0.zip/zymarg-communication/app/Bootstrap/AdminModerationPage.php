<?php
/**
 * AdminModerationPage — fully AJAX moderation queue.
 *
 * Lists moderation cases (reports, system flags) with status filtering,
 * lets an admin act on a case (reviewed / resolved / dismissed), and opens
 * the reported conversation read-only via AdminViewService.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Bootstrap;

use ZymargCommunication\Modules\Conversation\Repositories\ConversationRepository;
use ZymargCommunication\Modules\Conversation\Repositories\ParticipantRepository;
use ZymargCommunication\Modules\Message\Repositories\MessageRepository;
use ZymargCommunication\Modules\Moderation\Repositories\ModerationRepository;
use ZymargCommunication\Modules\Moderation\Services\AdminViewService;
use ZymargCommunication\Modules\Moderation\Services\ModerationService;
use ZymargCommunication\Modules\Security\Repositories\SecurityRepository;
use ZymargCommunication\Modules\Security\Services\AuditLogService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdminModerationPage {

	private static bool $registered = false;
	public const MENU_SLUG     = 'zymarg-comm-moderation';
	private const NONCE_ACTION = 'zymarg_comm_mod_load';

	public static function register(): void {
		if ( self::$registered ) {
			return;
		}
		self::$registered = true;
		add_action( 'admin_menu',                     array( self::class, 'registerMenu' ), 50 );
		add_action( 'wp_ajax_zymarg_comm_mod_queue',  array( self::class, 'handleQueue' ) );
		add_action( 'wp_ajax_zymarg_comm_mod_act',    array( self::class, 'handleAct' ) );
		add_action( 'wp_ajax_zymarg_comm_mod_view',   array( self::class, 'handleView' ) );
	}

	public static function registerMenu(): void {
		add_submenu_page(
			AdminMenu::MENU_SLUG,
			__( 'Moderation', 'zymarg-communication' ),
			__( 'Moderation', 'zymarg-communication' ),
			'manage_options',
			self::MENU_SLUG,
			array( self::class, 'render' )
		);
	}

	// =========================================================================
	// Service builders (self-contained)
	// =========================================================================

	private static function moderation(): ModerationService {
		return new ModerationService(
			new ModerationRepository(),
			new ConversationRepository(),
			new ParticipantRepository(),
			new AuditLogService( new SecurityRepository() )
		);
	}

	private static function adminView(): AdminViewService {
		return new AdminViewService(
			new ConversationRepository(),
			new ParticipantRepository(),
			new MessageRepository(),
			new AuditLogService( new SecurityRepository() )
		);
	}

	/** @return array<string,string> */
	private static function statuses(): array {
		return array(
			'pending'   => __( 'Pending', 'zymarg-communication' ),
			'reviewed'  => __( 'Reviewed', 'zymarg-communication' ),
			'resolved'  => __( 'Resolved', 'zymarg-communication' ),
			'dismissed' => __( 'Dismissed', 'zymarg-communication' ),
			''          => __( 'All', 'zymarg-communication' ),
		);
	}

	private static function actionable(): array {
		return array( 'reviewed', 'resolved', 'dismissed' );
	}

	private static function userName( int $user_id ): string {
		if ( $user_id <= 0 ) {
			return __( 'System', 'zymarg-communication' );
		}
		$u = get_userdata( $user_id );
		if ( $u && '' !== (string) $u->display_name ) {
			return (string) $u->display_name;
		}
		return sprintf( 'User #%d', $user_id );
	}

	private static function humanTime( string $mysql_utc ): string {
		if ( '' === $mysql_utc ) {
			return '-';
		}
		$ts = strtotime( $mysql_utc . ' UTC' );
		return $ts ? wp_date( 'M j, Y g:i a', $ts ) : $mysql_utc;
	}

	private static function statusBadge( string $status ): string {
		$colors = array(
			'pending'   => '#dba617',
			'reviewed'  => '#2271b1',
			'resolved'  => '#46b450',
			'dismissed' => '#787c82',
		);
		$c = isset( $colors[ $status ] ) ? $colors[ $status ] : '#787c82';
		return '<span style="display:inline-block;padding:2px 8px;border-radius:10px;font-size:11px;color:var(--zc-color-surface-lowest);background:' . esc_attr( $c ) . ';">' . esc_html( $status ) . '</span>';
	}

	// =========================================================================
	// Render shell
	// =========================================================================

	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$nonce    = wp_create_nonce( self::NONCE_ACTION );
		$ajax_url = admin_url( 'admin-ajax.php' );
		$status   = isset( $_GET['status'] ) ? sanitize_key( (string) wp_unslash( $_GET['status'] ) ) : 'pending';
		$statuses = self::statuses();
		if ( ! array_key_exists( $status, $statuses ) ) {
			$status = 'pending';
		}
		$pending = self::moderation()->pendingCount();
		?>
		<div class="wrap zcm-admin-page zymarg-comm-moderation">
		<style>
		.zcm-admin-page{max-width:1180px;}
		.zcm-admin-page > h1{margin:0 0 6px;padding:0;font-size:23px;line-height:1.3;}
		.zcm-admin-page .description{font-size:13px;color:var(--zc-color-neutral-text);margin:0 0 20px;max-width:840px;line-height:1.6;}
		.zcm-admin-page .nav-tab-wrapper{display:flex;flex-wrap:wrap;gap:6px;align-items:flex-end;margin:0 0 24px;padding:0;border-bottom:1px solid var(--zc-color-divider);}
		.zcm-admin-page .nav-tab{float:none;display:inline-block;margin:0;padding:9px 16px;font-size:13px;font-weight:500;line-height:1.5;text-decoration:none;cursor:pointer;color:var(--zc-color-text-muted);background:var(--zc-color-neutral-bg);border:1px solid var(--zc-color-divider);border-bottom:none;border-radius:6px 6px 0 0;}
		.zcm-admin-page .nav-tab:hover{background:#fff;color:var(--zc-color-primary-deep);}
		.zcm-admin-page .nav-tab-active,.zcm-admin-page .nav-tab-active:hover{background:#fff;color:var(--zc-color-primary);font-weight:600;border-bottom:1px solid #fff;margin-bottom:-1px;box-shadow:inset 0 -2px 0 var(--zc-color-primary);}
		.zcm-admin-page .zcm-count{color:var(--zc-color-neutral-text);font-size:13px;margin:0 0 12px;}
		.zcm-admin-page table.wp-list-table{display:table;width:100%;border-collapse:separate;border-spacing:0;table-layout:auto;margin-top:0;background:#fff;border:1px solid var(--zc-color-divider);border-radius:8px;overflow:hidden;}
		.zcm-admin-page table.wp-list-table thead{display:table-header-group;}
		.zcm-admin-page table.wp-list-table tbody{display:table-row-group;}
		.zcm-admin-page table.wp-list-table tr{display:table-row;}
		.zcm-admin-page table.wp-list-table th,.zcm-admin-page table.wp-list-table td{display:table-cell;text-align:left;padding:12px 16px;vertical-align:middle;border-bottom:1px solid var(--zc-color-neutral-bg);font-size:13px;}
		.zcm-admin-page table.wp-list-table thead th{font-weight:600;color:var(--zc-color-ink);background:var(--zc-color-surface);white-space:nowrap;}
		.zcm-admin-page table.wp-list-table tbody tr:last-child td{border-bottom:none;}
		.zcm-admin-page table.wp-list-table tbody tr:hover{background:var(--zc-color-surface);}
		.zcm-admin-page .zcm-conv-viewer{margin:0 0 20px;box-shadow:0 1px 3px rgba(0,0,0,.06);}
		.zcm-admin-page .button + .button{margin-left:6px;}
		</style>
			<?php AdminMenu::renderHeader( __( 'ZYMARG Communication', 'zymarg-communication' ), __( 'Moderation — review reported conversations and system flags', 'zymarg-communication' ) ); ?>
			<?php if ( $pending > 0 ) : ?>
			<p><span class="zcm-status zcm-status-danger"><?php echo (int) $pending; ?> <?php esc_html_e( 'pending', 'zymarg-communication' ); ?></span></p>
			<?php endif; ?>
			<p class="description" style="margin:8px 0 16px;"><?php esc_html_e( 'Review reported conversations and system flags. Viewing a conversation is read-only and recorded in the audit log.', 'zymarg-communication' ); ?></p>

			<h2 class="nav-tab-wrapper" style="margin-bottom:16px;">
				<?php foreach ( $statuses as $key => $label ) : ?>
				<a href="#" class="nav-tab zcm-mod-filter<?php echo $key === $status ? ' nav-tab-active' : ''; ?>" data-status="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></a>
				<?php endforeach; ?>
			</h2>

			<div id="zcm-mod-view" style="display:none;margin-bottom:20px;"></div>
			<div id="zcm-mod-content"><?php self::renderQueue( $status ); ?></div>

			<script>
			(function(){
				var AJAX  = <?php echo wp_json_encode( $ajax_url ); ?>;
				var NONCE = <?php echo wp_json_encode( $nonce ); ?>;
				var content = document.getElementById('zcm-mod-content');
				var viewBox = document.getElementById('zcm-mod-view');
				if (!content) return;
				var currentStatus = <?php echo wp_json_encode( $status ); ?>;

				function post(action, extra){
					var d = new URLSearchParams();
					d.append('action', action);
					d.append('_wpnonce', NONCE);
					for (var k in extra){ d.append(k, extra[k]); }
					return fetch(AJAX, {method:'POST', credentials:'same-origin', body:d}).then(function(r){ return r.json(); });
				}

				function loadQueue(status){
					currentStatus = status;
					content.style.opacity = '0.5';
					post('zymarg_comm_mod_queue', {status:status}).then(function(res){
						if (res.success){ content.innerHTML = res.data.html; }
						content.style.opacity = '1';
					}).catch(function(){ content.style.opacity = '1'; });
				}

				content.addEventListener('click', function(e){
					var v = e.target.closest('.zcm-mod-view-btn');
					if (v){ e.preventDefault();
						viewBox.style.display = 'block';
						viewBox.innerHTML = '<div class="zymarg-loading" role="status" aria-live="polite" style="padding:16px;"><span class="zymarg-spark zymarg-spark--md"><svg class="zymarg-spark__svg" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="ZYMARG Discovery Spark" focusable="false"><g class="zymarg-spark-group--accent"><path class="zymarg-spark-item--purple" d="M10.4 5.4c0 1.32-0.24 2.4-1.44 2.4 1.2 0 1.44 1.08 1.44 2.4 0-1.32 0.24-2.4 1.44-2.4-1.2 0-1.44-1.08-1.44-2.4z"/><path class="zymarg-spark-item--gold" d="M10.4 6.0c0 0.96-0.18 1.8-1.08 1.8 0.9 0 1.08 0.84 1.08 1.8 0-0.9 0.18-1.8 1.08-1.8-0.9 0-1.08-0.84-1.08-1.8z"/></g><g class="zymarg-spark-group--companion"><path class="zymarg-spark-item--purple" d="M9.5 10.92c0 2.25-0.45 4.12-2.4 4.12 1.95 0 2.4 1.87 2.4 4.12 0-2.25 0.45-4.12 2.4-4.12-1.95 0-2.4-1.87-2.4-4.12z"/><path class="zymarg-spark-item--gold" d="M9.5 11.5c0 1.9-0.38 3.54-2.0 3.54 1.62 0 2.0 1.64 2.0 3.54 0-1.9 0.38-3.54 2.0-3.54-1.62 0-2.0-1.64-2.0-3.54z"/></g><g class="zymarg-spark-group--hero"><path class="zymarg-spark-item--purple" d="M15.2 5.6c0 3.45-0.69 6.3-4.08 6.3 3.39 0 4.08 2.85 4.08 6.3 0-3.45 0.69-6.3 4.08-6.3-3.39 0-4.08-2.85-4.08-6.3z"/><path class="zymarg-spark-item--gold" d="M15.2 6.5c0 2.9-0.58 5.4-3.39 5.4 2.81 0 3.39 2.5 3.39 5.4 0-2.9 0.58-5.4 3.39-5.4-2.81 0-3.39-2.5-3.39-5.4z"/></g></svg></span><span class="zymarg-loading__text">Loading conversation...</span></div>';
						post('zymarg_comm_mod_view', {conversation_id:v.dataset.cid}).then(function(res){
							if (res.success){ viewBox.innerHTML = res.data.html; window.scrollTo(0, 0); }
							else { viewBox.innerHTML = '<div class="notice notice-error"><p>' + ((res.data && res.data.message) ? res.data.message : 'Failed to load.') + '</p></div>'; }
						}).catch(function(){ viewBox.innerHTML = '<div class="notice notice-error"><p>Error loading conversation.</p></div>'; });
						return;
					}
					var act = e.target.closest('.zcm-mod-act');
					if (act){ e.preventDefault();
						var row   = act.closest('tr');
						var notes = row ? row.querySelector('.zcm-mod-notes') : null;
						act.disabled = true;
						post('zymarg_comm_mod_act', {case_id:act.dataset.case, mod_status:act.dataset.act, notes:notes ? notes.value : ''}).then(function(res){
							if (res.success){ loadQueue(currentStatus); }
							else { act.disabled = false; window.alert((res.data && res.data.message) ? res.data.message : 'Action failed.'); }
						}).catch(function(){ act.disabled = false; window.alert('Action failed.'); });
						return;
					}
				});

				viewBox.addEventListener('click', function(e){
					if (e.target.closest('.zcm-conv-close')){ e.preventDefault(); viewBox.style.display='none'; viewBox.innerHTML=''; }
				});

				document.querySelectorAll('.zcm-mod-filter').forEach(function(btn){
					btn.addEventListener('click', function(e){
						e.preventDefault();
						document.querySelectorAll('.zcm-mod-filter').forEach(function(b){ b.classList.toggle('nav-tab-active', b===btn); });
						loadQueue(this.dataset.status || '');
					});
				});
			})();
			</script>
		</div>
		<?php
	}

	// =========================================================================
	// Queue (server-rendered + ajax reload)
	// =========================================================================

	private static function renderQueue( string $status ): void {
		$filter = ( '' === $status ) ? null : $status;
		$cases  = self::moderation()->queue( $filter, 100, 0 );
		?>
		<table class="wp-list-table widefat fixed striped">
			<thead>
				<tr>
					<th style="width:60px;"><?php esc_html_e( 'Case', 'zymarg-communication' ); ?></th>
					<th style="width:110px;"><?php esc_html_e( 'Type', 'zymarg-communication' ); ?></th>
					<th style="width:100px;"><?php esc_html_e( 'Conversation', 'zymarg-communication' ); ?></th>
					<th style="width:110px;"><?php esc_html_e( 'Status', 'zymarg-communication' ); ?></th>
					<th><?php esc_html_e( 'Reporter', 'zymarg-communication' ); ?></th>
					<th style="width:160px;"><?php esc_html_e( 'Reported', 'zymarg-communication' ); ?></th>
					<th style="width:320px;"><?php esc_html_e( 'Action', 'zymarg-communication' ); ?></th>
				</tr>
			</thead>
			<tbody>
			<?php if ( empty( $cases ) ) : ?>
				<tr><td colspan="7" style="padding:20px;color:var(--zc-color-text-body);"><?php esc_html_e( 'No moderation cases in this view.', 'zymarg-communication' ); ?></td></tr>
			<?php else : foreach ( $cases as $case ) :
				$cid = (int) $case['conversation_id'];
				?>
				<tr>
					<td>#<?php echo (int) $case['id']; ?></td>
					<td><?php echo esc_html( (string) $case['type'] ); ?></td>
					<td><button type="button" class="button-link zcm-mod-view-btn" data-cid="<?php echo (int) $cid; ?>">#<?php echo (int) $cid; ?></button></td>
					<td><?php echo self::statusBadge( (string) $case['status'] ); ?></td>
					<td><?php echo esc_html( self::userName( (int) $case['reporter_id'] ) ); ?></td>
					<td><?php echo esc_html( self::humanTime( (string) $case['created_at'] ) ); ?></td>
					<td>
						<?php if ( 'pending' === (string) $case['status'] || 'reviewed' === (string) $case['status'] ) : ?>
						<input type="text" class="zcm-mod-notes regular-text" style="width:100%;margin-bottom:6px;" placeholder="<?php esc_attr_e( 'Optional notes', 'zymarg-communication' ); ?>" />
						<div style="display:flex;gap:4px;flex-wrap:wrap;">
							<button type="button" class="button button-small zcm-mod-act" data-case="<?php echo (int) $case['id']; ?>" data-act="reviewed"><?php esc_html_e( 'Reviewed', 'zymarg-communication' ); ?></button>
							<button type="button" class="button button-small button-primary zcm-mod-act" data-case="<?php echo (int) $case['id']; ?>" data-act="resolved"><?php esc_html_e( 'Resolve', 'zymarg-communication' ); ?></button>
							<button type="button" class="button button-small zcm-mod-act" data-case="<?php echo (int) $case['id']; ?>" data-act="dismissed"><?php esc_html_e( 'Dismiss', 'zymarg-communication' ); ?></button>
						</div>
						<?php else : ?>
						<span style="color:var(--zc-color-neutral-text);"><?php echo esc_html( sprintf( __( 'Closed by %s', 'zymarg-communication' ), self::userName( (int) $case['moderator_id'] ) ) ); ?></span>
						<?php if ( ! empty( $case['notes'] ) ) : ?>
						<div style="color:var(--zc-color-text-body);font-size:12px;margin-top:4px;"><?php echo esc_html( (string) $case['notes'] ); ?></div>
						<?php endif; ?>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; endif; ?>
			</tbody>
		</table>
		<?php
	}

	public static function handleQueue(): void {
		check_ajax_referer( self::NONCE_ACTION );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'zymarg-communication' ) ) );
		}
		$status = isset( $_POST['status'] ) ? sanitize_key( (string) wp_unslash( $_POST['status'] ) ) : 'pending';
		if ( ! array_key_exists( $status, self::statuses() ) ) {
			$status = 'pending';
		}
		ob_start();
		self::renderQueue( $status );
		wp_send_json_success( array( 'html' => ob_get_clean() ) );
	}

	public static function handleAct(): void {
		check_ajax_referer( self::NONCE_ACTION );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'zymarg-communication' ) ) );
		}
		$case_id = isset( $_POST['case_id'] ) ? absint( $_POST['case_id'] ) : 0;
		$new     = isset( $_POST['mod_status'] ) ? sanitize_key( (string) wp_unslash( $_POST['mod_status'] ) ) : '';
		$notes   = isset( $_POST['notes'] ) ? sanitize_textarea_field( (string) wp_unslash( $_POST['notes'] ) ) : '';
		if ( $case_id <= 0 || ! in_array( $new, self::actionable(), true ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid moderation action.', 'zymarg-communication' ) ) );
		}
		try {
			$result = self::moderation()->actOnCase( $case_id, get_current_user_id(), $new, '' !== $notes ? $notes : null );
			wp_send_json_success( array( 'case' => $result ) );
		} catch ( \Throwable $e ) {
			wp_send_json_error( array( 'message' => $e->getMessage() ) );
		}
	}

	public static function handleView(): void {
		check_ajax_referer( self::NONCE_ACTION );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'zymarg-communication' ) ) );
		}
		$cid = isset( $_POST['conversation_id'] ) ? absint( $_POST['conversation_id'] ) : 0;
		if ( $cid <= 0 ) {
			wp_send_json_error( array( 'message' => __( 'Invalid conversation.', 'zymarg-communication' ) ) );
		}
		try {
			$data = self::adminView()->view( $cid, get_current_user_id(), 200 );
			ob_start();
			self::renderView( $data );
			wp_send_json_success( array( 'html' => ob_get_clean() ) );
		} catch ( \Throwable $e ) {
			if ( ob_get_length() ) {
				ob_end_clean();
			}
			wp_send_json_error( array( 'message' => $e->getMessage() ) );
		}
	}

	/** @param array{conversation:array<string,mixed>,participants:array<int,array<string,mixed>>,messages:array<int,array<string,mixed>>} $data */
	private static function renderView( array $data ): void {
		$conv         = $data['conversation'];
		$participants = $data['participants'];
		$messages     = $data['messages'];
		$names        = array();
		foreach ( $participants as $p ) {
			$names[] = self::userName( (int) $p['user_id'] );
		}
		?>
		<div class="zcm-conv-viewer" style="border:1px solid var(--zc-color-divider);border-radius:6px;background:var(--zc-color-surface-lowest);">
			<div style="display:flex;justify-content:space-between;align-items:center;padding:12px 16px;border-bottom:1px solid var(--zc-color-divider);background:var(--zc-color-surface);">
				<strong><?php echo esc_html( sprintf( __( 'Conversation #%d', 'zymarg-communication' ), (int) $conv['id'] ) ); ?></strong>
				<button type="button" class="button button-small zcm-conv-close"><?php esc_html_e( 'Close', 'zymarg-communication' ); ?></button>
			</div>
			<div style="padding:10px 16px;border-bottom:1px solid var(--zc-color-divider);color:var(--zc-color-text-muted);font-size:13px;">
				<?php echo self::statusBadge( (string) $conv['status'] ); ?>
				&nbsp;&middot;&nbsp;
				<?php echo esc_html( sprintf( __( 'Participants: %s', 'zymarg-communication' ), empty( $names ) ? __( 'None', 'zymarg-communication' ) : implode( ', ', $names ) ) ); ?>
			</div>
			<div style="padding:16px;max-height:560px;overflow-y:auto;">
				<?php if ( empty( $messages ) ) : ?>
					<p style="color:var(--zc-color-text-body);"><?php esc_html_e( 'No messages in this conversation.', 'zymarg-communication' ); ?></p>
				<?php else : foreach ( $messages as $m ) : ?>
					<div style="margin-bottom:14px;">
						<div style="font-size:12px;color:var(--zc-color-neutral-text);margin-bottom:2px;">
							<strong style="color:var(--zc-color-ink);"><?php echo esc_html( self::userName( (int) $m['sender_id'] ) ); ?></strong>
							&nbsp;<?php echo esc_html( self::humanTime( (string) $m['created_at'] ) ); ?>
						</div>
						<div style="background:var(--zc-color-neutral-bg);border-radius:8px;padding:8px 12px;display:inline-block;max-width:80%;"><?php echo nl2br( esc_html( (string) $m['body'] ) ); ?></div>
					</div>
				<?php endforeach; endif; ?>
			</div>
		</div>
		<?php
	}
}
