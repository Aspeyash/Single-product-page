<?php
/**
 * AgentConsole — the frontend support console for agents (1.28.0).
 *
 * Stage 4 of the support surface. Answers "let an agent triage and reply
 * without living in wp-admin", and does it without a floating widget on
 * customer pages: the entry point is a node in the WordPress admin bar, which
 * only logged-in staff ever see, carrying a live open-ticket badge. Clicking it
 * on the frontend opens a slide-out drawer containing the ticket QUEUE
 * (Needs reply / Mine / Waiting on customer / Resolved) and, when a ticket is
 * picked, the full thread with the same composer and the same ticket panel
 * (identity, context, history, Resolve/Reopen/Close) used everywhere else.
 *
 * The drawer reuses the existing machinery end to end: SupportChat::inboxRoot()
 * for the thread markup, window.zymargInbox.openConversation() (added in 1.26.0)
 * to point it at a ticket, and support-ticket.js for the panel. The only new
 * surface is the drawer shell + the queue list.
 *
 * Admin-bar-only was chosen deliberately over a floating pill: a pill sits on
 * every page for the site owner, competing with the customer live-chat popup
 * and the theme toast region. The admin bar is where staff already expect
 * administrative affordances, and it is invisible to shoppers.
 *
 * @package ZymargCommunication
 * @since   1.28.0
 */

namespace ZymargCommunication\Bootstrap;

use ZymargCommunication\Frontend\SupportChat;
use ZymargCommunication\Modules\Support\Repositories\SupportTicketRepository;
use ZymargCommunication\Modules\Support\Services\SupportService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AgentConsole {

	private static bool $registered = false;
	private const NODE_ID = 'zymarg-support-console';

	public static function register(): void {
		if ( self::$registered ) {
			return;
		}
		self::$registered = true;

		add_action( 'admin_bar_menu', array( self::class, 'adminBarNode' ), 90 );
		add_action( 'wp_enqueue_scripts', array( self::class, 'enqueueFrontend' ) );
		add_action( 'wp_footer', array( self::class, 'renderDrawer' ) );
	}

	/**
	 * Only support agents (and admins), and only while support is switched on.
	 * A disabled feature must add nothing to the admin bar and enqueue nothing.
	 */
	private static function canUse(): bool {
		if ( ! is_user_logged_in() ) {
			return false;
		}
		if ( ! current_user_can( 'manage_options' ) && ! current_user_can( SupportService::CAPABILITY ) ) {
			return false;
		}

		if ( ! ServiceProvider::has( SupportService::class ) ) {
			return false;
		}
		try {
			$svc = ServiceProvider::get( SupportService::class );

			return $svc instanceof SupportService && $svc->enabled();
		} catch ( \Throwable $e ) {
			return false;
		}
	}

	private static function openCount(): int {
		if ( ! ServiceProvider::has( SupportTicketRepository::class ) ) {
			return 0;
		}
		try {
			$repo = ServiceProvider::get( SupportTicketRepository::class );
			if ( $repo instanceof SupportTicketRepository ) {
				$counts = $repo->counts();

				return (int) ( $counts['open'] ?? 0 );
			}
		} catch ( \Throwable $e ) {
			// fall through
		}

		return 0;
	}

	/**
	 * @param \WP_Admin_Bar $bar
	 */
	public static function adminBarNode( $bar ): void {
		if ( ! self::canUse() || ! is_object( $bar ) || ! method_exists( $bar, 'add_node' ) ) {
			return;
		}

		$open  = self::openCount();
		$badge = '<span class="zymarg-ac-bar-badge" data-zymarg-ac-badge' . ( $open > 0 ? '' : ' hidden' ) . '>'
			. esc_html( (string) $open ) . '</span>';

		// On wp-admin the link is the real destination; on the frontend the JS
		// intercepts the click and opens the drawer instead of navigating.
		$href = admin_url( 'admin.php?page=' . AdminSupportPage::MENU_SLUG );

		$bar->add_node(
			array(
				'id'    => self::NODE_ID,
				'title' => '<span class="ab-icon dashicons dashicons-sos" aria-hidden="true" style="top:2px;"></span>'
					. '<span class="ab-label">' . esc_html__( 'Support', 'zymarg-communication' ) . '</span> ' . $badge,
				'href'  => $href,
				'meta'  => array(
					'class' => 'zymarg-ac-bar',
					'title' => __( 'Open the support console', 'zymarg-communication' ),
				),
			)
		);
	}

	public static function enqueueFrontend(): void {
		if ( is_admin() || ! self::canUse() ) {
			return;
		}

		$base    = defined( 'ZYMARG_COMM_URL' ) ? ZYMARG_COMM_URL : plugin_dir_url( ZYMARG_COMM_FILE );
		$version = defined( 'ZYMARG_COMM_VERSION' ) ? ZYMARG_COMM_VERSION : '1.28.0';

		wp_enqueue_style(
			'zymarg-agent-console',
			$base . 'assets/css/frontend/agent-console.css',
			array( 'zymarg-comm-tokens', 'zymarg-inbox', 'zymarg-support-ticket' ),
			$version
		);
		// Depends on inbox.js (openConversation) + support-ticket.js (panel),
		// both already enqueued for logged-in users by AssetEnqueue.
		wp_enqueue_script(
			'zymarg-agent-console',
			$base . 'assets/js/frontend/agent-console.js',
			array( 'zymarg-inbox', 'zymarg-support-ticket' ),
			$version,
			true
		);
		wp_localize_script(
			'zymarg-agent-console',
			'zymargAgentConsole',
			array(
				'restUrl'  => esc_url_raw( rest_url( 'zymarg-comm/v1' ) ),
				'nonce'    => wp_create_nonce( 'wp_rest' ),
				'nodeId'   => self::NODE_ID,
				'pollMs'   => 30000,
				'i18n'     => array(
					'title'         => __( 'Support console', 'zymarg-communication' ),
					'close'         => __( 'Close', 'zymarg-communication' ),
					'needsReply'    => __( 'Needs reply', 'zymarg-communication' ),
					'mine'          => __( 'Mine', 'zymarg-communication' ),
					'waiting'       => __( 'Waiting on customer', 'zymarg-communication' ),
					'resolved'      => __( 'Resolved', 'zymarg-communication' ),
					'empty'         => __( 'Nothing here right now.', 'zymarg-communication' ),
					'selectTicket'  => __( 'Select a ticket to view the conversation.', 'zymarg-communication' ),
					'loading'       => __( 'Loading…', 'zymarg-communication' ),
				),
			)
		);
	}

	/**
	 * The drawer shell. Rendered once in the footer, hidden until opened.
	 * Contains the queue column + a support inbox root the console drives via
	 * window.zymargInbox.openConversation().
	 */
	public static function renderDrawer(): void {
		if ( is_admin() || ! self::canUse() ) {
			return;
		}

		$inbox_html = '';
		if ( class_exists( SupportChat::class ) ) {
			$inbox_html = SupportChat::inboxRoot(
				'support',
				__( 'Conversation', 'zymarg-communication' ),
				get_current_user_id(),
				__( 'Select a ticket to view the conversation.', 'zymarg-communication' )
			);
		}
		?>
		<div class="zymarg-ac" data-zymarg-ac hidden aria-hidden="true">
			<div class="zymarg-ac__scrim" data-zymarg-ac-scrim></div>
			<aside class="zymarg-ac__drawer" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e( 'Support console', 'zymarg-communication' ); ?>">
				<header class="zymarg-ac__head">
					<span class="zymarg-ac__title"><?php esc_html_e( 'Support console', 'zymarg-communication' ); ?></span>
					<button type="button" class="zymarg-ac__x" data-zymarg-ac-close aria-label="<?php esc_attr_e( 'Close', 'zymarg-communication' ); ?>">&times;</button>
				</header>
				<div class="zymarg-ac__tabs" data-zymarg-ac-tabs role="tablist">
					<button type="button" class="zymarg-ac__tab is-active" data-ac-filter="needs" role="tab"><?php esc_html_e( 'Needs reply', 'zymarg-communication' ); ?><span class="zymarg-ac__tab-count" data-ac-count="needs"></span></button>
					<button type="button" class="zymarg-ac__tab" data-ac-filter="mine" role="tab"><?php esc_html_e( 'Mine', 'zymarg-communication' ); ?></button>
					<button type="button" class="zymarg-ac__tab" data-ac-filter="waiting" role="tab"><?php esc_html_e( 'Waiting', 'zymarg-communication' ); ?></button>
					<button type="button" class="zymarg-ac__tab" data-ac-filter="resolved" role="tab"><?php esc_html_e( 'Resolved', 'zymarg-communication' ); ?></button>
				</div>
				<div class="zymarg-ac__body">
					<div class="zymarg-ac__queue" data-zymarg-ac-queue aria-label="<?php esc_attr_e( 'Ticket queue', 'zymarg-communication' ); ?>">
						<div class="zymarg-ac__loading"><?php esc_html_e( 'Loading…', 'zymarg-communication' ); ?></div>
					</div>
					<div class="zymarg-ac__thread" data-zymarg-ac-thread>
						<?php echo $inbox_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					</div>
				</div>
			</aside>
		</div>
		<?php
	}
}
