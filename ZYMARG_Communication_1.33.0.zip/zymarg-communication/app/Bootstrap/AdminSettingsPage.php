<?php
/**
 * AdminSettingsPage — Fully AJAX admin settings.
 * Tab switching, saves, and test connection all work without any page reload.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Bootstrap;

use ZymargCommunication\Modules\FeatureFlags\Repositories\FeatureFlagRepository;
use ZymargCommunication\Modules\Settings\Repositories\SettingsRepository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdminSettingsPage {

	private static bool $registered = false;
	public const  MENU_SLUG    = 'zymarg-comm-settings';
	private const NONCE_ACTION = 'zymarg_comm_ajax_save';
	private const FLAG_NONCE   = 'zymarg_comm_flag_toggle';

	public static function register(): void {
		if ( self::$registered ) return;
		self::$registered = true;
		add_action( 'admin_menu',                              array( self::class, 'registerMenu' ), 20 );
		add_action( 'wp_ajax_zymarg_comm_load_tab',            array( self::class, 'handleLoadTab' ) );
		add_action( 'wp_ajax_zymarg_comm_save_general',        array( self::class, 'handleSaveGeneral' ) );
		add_action( 'wp_ajax_zymarg_comm_save_realtime',       array( self::class, 'handleSaveRealtime' ) );
		add_action( 'wp_ajax_zymarg_comm_toggle_flag',         array( self::class, 'handleFlagToggle' ) );
		add_action( 'wp_ajax_zymarg_comm_pusher_test',         array( self::class, 'handlePusherTest' ) );
		add_action( 'wp_ajax_zymarg_comm_save_email',          array( self::class, 'handleSaveEmail' ) );
		add_action( 'wp_ajax_zymarg_comm_save_attachments',    array( self::class, 'handleSaveAttachments' ) );
		add_action( 'wp_ajax_zymarg_comm_save_moderation',     array( self::class, 'handleSaveModeration' ) );
		add_action( 'wp_ajax_zymarg_comm_save_devtools',       array( self::class, 'handleSaveDevtools' ) );
		add_action( 'wp_ajax_zymarg_comm_save_support',        array( self::class, 'handleSaveSupport' ) );
	}

	public static function registerMenu(): void {
		add_submenu_page(
			AdminMenu::MENU_SLUG,
			__( 'Settings', 'zymarg-communication' ),
			__( 'Settings', 'zymarg-communication' ),
			'manage_options',
			self::MENU_SLUG,
			array( self::class, 'render' )
		);
	}

	// =========================================================================
	// Shell — rendered once, content loaded via AJAX
	// =========================================================================

	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) return;
		$tab  = isset( $_GET['tab'] ) ? sanitize_key( (string) wp_unslash( $_GET['tab'] ) ) : 'general';
		$tabs = array(
			'general'  => __( 'General', 'zymarg-communication' ),
			'support'  => __( 'Support', 'zymarg-communication' ),
			'realtime' => __( 'Realtime (Pusher)', 'zymarg-communication' ),
			'flags'    => __( 'Feature Flags', 'zymarg-communication' ),
			'email'       => __( 'Email Notifications', 'zymarg-communication' ),
			'attachments' => __( 'Attachments', 'zymarg-communication' ),
			'moderation'  => __( 'Moderation', 'zymarg-communication' ),
			'devtools'    => __( 'Developer Tools', 'zymarg-communication' ),
		);
		if ( ! array_key_exists( $tab, $tabs ) ) $tab = 'general';
		$nonce    = wp_create_nonce( self::NONCE_ACTION );
		$ajax_url = admin_url( 'admin-ajax.php' );
		?>
		<div class="wrap zcm-admin-page">
			<?php AdminMenu::renderHeader( __( 'ZYMARG Communication', 'zymarg-communication' ), __( 'Settings — Configure messaging, realtime, email and moderation', 'zymarg-communication' ) ); ?>
			<div id="zcm-notice-area"></div>
			<h2 class="nav-tab-wrapper" style="margin-bottom:0;">
				<?php foreach ( $tabs as $key => $label ) : ?>
				<button type="button"
					class="nav-tab zcm-tab-btn<?php echo $key === $tab ? ' nav-tab-active' : ''; ?>"
					data-tab="<?php echo esc_attr( $key ); ?>">
					<?php echo esc_html( $label ); ?>
				</button>
				<?php endforeach; ?>
			</h2>
			<div id="zcm-tab-content" style="max-width:860px;margin-top:24px;">
				<div class="zymarg-loading" role="status" aria-live="polite"><span class="zymarg-spark zymarg-spark--md"><svg class="zymarg-spark__svg" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="ZYMARG Discovery Spark" focusable="false"><g class="zymarg-spark-group--accent"><path class="zymarg-spark-item--purple" d="M10.4 5.4c0 1.32-0.24 2.4-1.44 2.4 1.2 0 1.44 1.08 1.44 2.4 0-1.32 0.24-2.4 1.44-2.4-1.2 0-1.44-1.08-1.44-2.4z"/><path class="zymarg-spark-item--gold" d="M10.4 6.0c0 0.96-0.18 1.8-1.08 1.8 0.9 0 1.08 0.84 1.08 1.8 0-0.9 0.18-1.8 1.08-1.8-0.9 0-1.08-0.84-1.08-1.8z"/></g><g class="zymarg-spark-group--companion"><path class="zymarg-spark-item--purple" d="M9.5 10.92c0 2.25-0.45 4.12-2.4 4.12 1.95 0 2.4 1.87 2.4 4.12 0-2.25 0.45-4.12 2.4-4.12-1.95 0-2.4-1.87-2.4-4.12z"/><path class="zymarg-spark-item--gold" d="M9.5 11.5c0 1.9-0.38 3.54-2.0 3.54 1.62 0 2.0 1.64 2.0 3.54 0-1.9 0.38-3.54 2.0-3.54-1.62 0-2.0-1.64-2.0-3.54z"/></g><g class="zymarg-spark-group--hero"><path class="zymarg-spark-item--purple" d="M15.2 5.6c0 3.45-0.69 6.3-4.08 6.3 3.39 0 4.08 2.85 4.08 6.3 0-3.45 0.69-6.3 4.08-6.3-3.39 0-4.08-2.85-4.08-6.3z"/><path class="zymarg-spark-item--gold" d="M15.2 6.5c0 2.9-0.58 5.4-3.39 5.4 2.81 0 3.39 2.5 3.39 5.4 0-2.9 0.58-5.4 3.39-5.4-2.81 0-3.39-2.5-3.39-5.4z"/></g></svg></span><span class="zymarg-loading__text"><?php esc_html_e( 'Loading...', 'zymarg-communication' ); ?></span></div>
			</div>
		</div>
		<script>
		(function(){
			var AJAX     = <?php echo wp_json_encode( $ajax_url ); ?>;
			var NONCE    = <?php echo wp_json_encode( $nonce ); ?>;
			var current  = <?php echo wp_json_encode( $tab ); ?>;

			window.zcmShowNotice = function(msg, type) {
				var area = document.getElementById('zcm-notice-area');
				if (!area) return;
				var cls  = type === 'error' ? 'notice-error' : 'notice-success';
				area.innerHTML = '<div class="notice '+cls+' is-dismissible"><p>'+msg+'</p>'
					+'<button type="button" class="notice-dismiss" onclick="this.parentNode.remove()">'
					+'<span class="screen-reader-text">Dismiss</span></button></div>';
			};

			function loadTab(tab) {
				var box = document.getElementById('zcm-tab-content');
				box.innerHTML = '<div class="zymarg-loading" role="status" aria-live="polite"><span class="zymarg-spark zymarg-spark--md"><svg class="zymarg-spark__svg" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="ZYMARG Discovery Spark" focusable="false"><g class="zymarg-spark-group--accent"><path class="zymarg-spark-item--purple" d="M10.4 5.4c0 1.32-0.24 2.4-1.44 2.4 1.2 0 1.44 1.08 1.44 2.4 0-1.32 0.24-2.4 1.44-2.4-1.2 0-1.44-1.08-1.44-2.4z"/><path class="zymarg-spark-item--gold" d="M10.4 6.0c0 0.96-0.18 1.8-1.08 1.8 0.9 0 1.08 0.84 1.08 1.8 0-0.9 0.18-1.8 1.08-1.8-0.9 0-1.08-0.84-1.08-1.8z"/></g><g class="zymarg-spark-group--companion"><path class="zymarg-spark-item--purple" d="M9.5 10.92c0 2.25-0.45 4.12-2.4 4.12 1.95 0 2.4 1.87 2.4 4.12 0-2.25 0.45-4.12 2.4-4.12-1.95 0-2.4-1.87-2.4-4.12z"/><path class="zymarg-spark-item--gold" d="M9.5 11.5c0 1.9-0.38 3.54-2.0 3.54 1.62 0 2.0 1.64 2.0 3.54 0-1.9 0.38-3.54 2.0-3.54-1.62 0-2.0-1.64-2.0-3.54z"/></g><g class="zymarg-spark-group--hero"><path class="zymarg-spark-item--purple" d="M15.2 5.6c0 3.45-0.69 6.3-4.08 6.3 3.39 0 4.08 2.85 4.08 6.3 0-3.45 0.69-6.3 4.08-6.3-3.39 0-4.08-2.85-4.08-6.3z"/><path class="zymarg-spark-item--gold" d="M15.2 6.5c0 2.9-0.58 5.4-3.39 5.4 2.81 0 3.39 2.5 3.39 5.4 0-2.9 0.58-5.4 3.39-5.4-2.81 0-3.39-2.5-3.39-5.4z"/></g></svg></span><span class="zymarg-loading__text">Loading...</span></div>';
				document.querySelectorAll('.zcm-tab-btn').forEach(function(b){
					b.classList.toggle('nav-tab-active', b.dataset.tab === tab);
				});
				var d = new URLSearchParams();
				d.append('action','zymarg_comm_load_tab');
				d.append('tab', tab);
				d.append('_wpnonce', NONCE);
				fetch(AJAX,{method:'POST',body:d})
					.then(function(r){return r.json();})
					.then(function(res){
						if (res.success) {
							var frag = document.createRange().createContextualFragment(res.data.html);
							box.innerHTML = '';
							box.appendChild(frag);
							history.replaceState(null,'',location.pathname+'?page=zymarg-comm-settings&tab='+tab);
						} else {
							box.innerHTML = '<p style="color:var(--zc-color-danger);">Failed to load tab.</p>';
						}
					})
					.catch(function(e){
						box.innerHTML = '<p style="color:var(--zc-color-danger);">Error: '+e.message+'</p>';
					});
			}

			document.querySelectorAll('.zcm-tab-btn').forEach(function(btn){
				btn.addEventListener('click', function(){ loadTab(this.dataset.tab); });
			});

			loadTab(current);
		})();
		</script>
		<?php
	}

	// =========================================================================
	// AJAX: load tab HTML
	// =========================================================================

	public static function handleLoadTab(): void {
		check_ajax_referer( self::NONCE_ACTION );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Forbidden' ), 403 );
		}
		$tab     = isset( $_POST['tab'] ) ? sanitize_key( (string) wp_unslash( $_POST['tab'] ) ) : 'general';
		$allowed = array( 'general', 'support', 'realtime', 'flags', 'email', 'attachments', 'moderation', 'devtools' );
		if ( ! in_array( $tab, $allowed, true ) ) $tab = 'general';
		ob_start();
		switch ( $tab ) {
			case 'general':  self::renderGeneral();  break;
			case 'support':  self::renderSupport();  break;
			case 'realtime': self::renderRealtime(); break;
			case 'flags':    self::renderFlags();    break;
			case 'email':       self::renderEmail();       break;
			case 'attachments': self::renderAttachments(); break;
			case 'moderation':  self::renderModeration();  break;
			case 'devtools':    self::renderDevtools();    break;
		}
		wp_send_json_success( array( 'html' => ob_get_clean(), 'tab' => $tab ) );
	}

	// =========================================================================
	// Tab content renderers
	// =========================================================================

	private static function renderGeneral(): void {
		$repo        = new SettingsRepository();
		$menu_label  = (string) get_option( 'zymarg_comm_admin_menu_label', 'Communication' );
		$msgs_page   = (string) $repo->get( 'messages_page_id', '' );
		$vendor_page = (string) $repo->get( 'vendor_messages_page_id', '' );
		$admin_email = (string) $repo->get( 'admin_notification_email', get_option( 'admin_email' ) );
		$popup_on    = '1' === (string) $repo->get( 'popup_autoopen_enabled', '0' );
		$popup_pages = array_values( array_filter( array_map( 'absint', explode( ',', (string) $repo->get( 'popup_autoopen_page_ids', '' ) ) ) ) );
		$nonce       = wp_create_nonce( self::NONCE_ACTION );
		$ajax_url    = admin_url( 'admin-ajax.php' );
		?>
		<form id="zcm-general-form" autocomplete="off">
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="zcm_menu_label"><?php esc_html_e( 'Admin menu label', 'zymarg-communication' ); ?></label></th>
					<td>
						<input type="text" id="zcm_menu_label" name="menu_label" class="regular-text" value="<?php echo esc_attr( $menu_label ); ?>" />
						<p class="description"><?php esc_html_e( 'Label shown in the WordPress admin sidebar.', 'zymarg-communication' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="zcm_admin_email"><?php esc_html_e( 'Admin notification email', 'zymarg-communication' ); ?></label></th>
					<td>
						<input type="email" id="zcm_admin_email" name="admin_email" class="regular-text" value="<?php echo esc_attr( $admin_email ); ?>" />
						<p class="description"><?php esc_html_e( 'Receives moderation alerts and notifications.', 'zymarg-communication' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="zcm_msgs_page"><?php esc_html_e( 'Buyer messages page', 'zymarg-communication' ); ?></label></th>
					<td>
						<?php wp_dropdown_pages( array( 'name' => 'messages_page_id', 'id' => 'zcm_msgs_page', 'selected' => (int) $msgs_page, 'show_option_none' => __( '--- Select a page ---', 'zymarg-communication' ), 'option_none_value' => '' ) ); ?>
						<p class="description"><?php esc_html_e( 'Page with [zymarg_my_messages] shortcode.', 'zymarg-communication' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="zcm_vendor_page"><?php esc_html_e( 'Vendor messages page', 'zymarg-communication' ); ?></label></th>
					<td>
						<?php wp_dropdown_pages( array( 'name' => 'vendor_messages_page_id', 'id' => 'zcm_vendor_page', 'selected' => (int) $vendor_page, 'show_option_none' => __( '--- Select a page ---', 'zymarg-communication' ), 'option_none_value' => '' ) ); ?>
						<p class="description"><?php esc_html_e( 'Page with [zymarg_vendor_messages] shortcode.', 'zymarg-communication' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Popup auto-open', 'zymarg-communication' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="popup_autoopen_enabled" value="1" <?php checked( $popup_on ); ?> />
							<?php esc_html_e( 'Allow the chat popup to open by itself when a new message arrives', 'zymarg-communication' ); ?>
						</label>
						<p class="description"><?php esc_html_e( 'When this is off, the popup never opens on its own. The launcher badge still shows the unread count.', 'zymarg-communication' ); ?></p>
						<div style="margin-top:12px;max-height:260px;overflow-y:auto;border:1px solid #dcdcde;border-radius:6px;padding:10px 12px;background:#fff;">
							<?php
							$all_pages = get_pages( array( 'sort_column' => 'post_title', 'number' => 300 ) );
							if ( empty( $all_pages ) ) {
								echo '<p class="description" style="margin:0;">' . esc_html__( 'No pages found.', 'zymarg-communication' ) . '</p>';
							} else {
								foreach ( $all_pages as $zcm_page ) {
									$zcm_title = '' !== trim( (string) $zcm_page->post_title ) ? (string) $zcm_page->post_title : ( 'Page ' . (int) $zcm_page->ID );
									printf(
										'<label style="display:block;margin:4px 0;"><input type="checkbox" name="popup_pages[]" value="%1$d" %2$s /> %3$s</label>',
										(int) $zcm_page->ID,
										in_array( (int) $zcm_page->ID, $popup_pages, true ) ? 'checked' : '',
										esc_html( $zcm_title )
									);
								}
							}
							?>
						</div>
						<p class="description"><?php esc_html_e( 'Tick the pages where auto-open is allowed. If nothing is ticked, the popup never opens on its own.', 'zymarg-communication' ); ?></p>
					</td>
				</tr>
			</table>
			<button type="submit" id="zcm-general-save" class="button button-primary"><?php esc_html_e( 'Save Settings', 'zymarg-communication' ); ?></button>
			<span id="zcm-general-status" style="margin-left:12px;font-weight:600;"></span>
		</form>
		<script>
		(function(){
			var AJAX  = <?php echo wp_json_encode( $ajax_url ); ?>;
			var NONCE = <?php echo wp_json_encode( $nonce ); ?>;
			document.getElementById('zcm-general-form').addEventListener('submit',function(e){
				e.preventDefault();
				var btn=document.getElementById('zcm-general-save');
				var st=document.getElementById('zcm-general-status');
				btn.disabled=true; st.textContent='Saving…'; st.style.color='#666';
				var d=new URLSearchParams(new FormData(this));
				d.append('action','zymarg_comm_save_general'); d.append('_wpnonce',NONCE);
				fetch(AJAX,{method:'POST',body:d}).then(function(r){return r.json();})
					.then(function(res){
						if(res.success){
							st.textContent='\u2713 Saved'; st.style.color='#46b450';
							if(typeof zcmShowNotice==='function') zcmShowNotice('Settings saved successfully.','success');
						}else{
							st.textContent='\u2717 Error'; st.style.color='#dc3232';
							if(typeof zcmShowNotice==='function') zcmShowNotice((res.data&&res.data.message)||'Save failed.','error');
						}
						btn.disabled=false;
						setTimeout(function(){st.textContent='';},3000);
					}).catch(function(e){
						st.textContent='\u2717 '+e.message; st.style.color='#dc3232'; btn.disabled=false;
					});
			});
		})();
		</script>
		<?php
	}

	/**
	 * Support tab (1.29.0) — where the support surface is actually configured.
	 *
	 * Three groups: where a support thread opens, how an arriving message
	 * announces itself, and the full Smart Intake copy including the topic chips.
	 * Every copy field is optional; blank means "use the shipped default", which
	 * is also how a customisation is undone. Defaults are shown as placeholders
	 * so the owner can see what they are overriding.
	 */
	private static function renderSupport(): void {
		$popup   = new \ZymargCommunication\Modules\Settings\Services\PopupSettingsService();
		$intake  = new \ZymargCommunication\Modules\Support\Services\SupportIntakeSettings();
		$session = new \ZymargCommunication\Modules\Support\Services\SupportSessionSettings();
		$S       = \ZymargCommunication\Modules\Support\Services\SupportIntakeSettings::class;

		$delivery  = $popup->supportDelivery();
		$behaviour = $popup->newMessageBehavior();
		$defaults  = $intake->defaults();
		$nonce     = wp_create_nonce( self::NONCE_ACTION );
		$ajax_url  = admin_url( 'admin-ajax.php' );

		$copy_fields = array(
			$S::TITLE               => array( __( 'Card title', 'zymarg-communication' ), __( 'Heading at the top of the intake card.', 'zymarg-communication' ) ),
			$S::TOPIC_LABEL         => array( __( 'Topic question', 'zymarg-communication' ), __( 'Shown above the topic chips.', 'zymarg-communication' ) ),
			$S::ORDER_LABEL         => array( __( 'Order question', 'zymarg-communication' ), __( 'Shown above the recent-order picker.', 'zymarg-communication' ) ),
			$S::SUBJECT_LABEL       => array( __( 'Subject question', 'zymarg-communication' ), __( 'Shown above the one-line input.', 'zymarg-communication' ) ),
			$S::SUBJECT_PLACEHOLDER => array( __( 'Subject placeholder', 'zymarg-communication' ), __( 'Greyed-out example inside the input.', 'zymarg-communication' ) ),
			$S::AVAILABILITY        => array( __( 'Reply-time line', 'zymarg-communication' ), __( 'Leave blank and the real figure is used — the median time your team actually took to first reply over the last 30 days. Nothing is shown until there are at least 3 answered cases to measure, because a promise you cannot keep is worse than none. Type here to override it with your real hours instead.', 'zymarg-communication' ) ),
			$S::START_BUTTON        => array( __( 'Start button', 'zymarg-communication' ), '' ),
			$S::CANCEL_BUTTON       => array( __( 'Cancel button', 'zymarg-communication' ), '' ),
		);
		?>
		<form id="zcm-support-form" autocomplete="off">
			<h3 style="margin-top:0;"><?php esc_html_e( 'Where support opens', 'zymarg-communication' ); ?></h3>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="zcm_support_delivery"><?php esc_html_e( 'Contact Support opens', 'zymarg-communication' ); ?></label></th>
					<td>
						<select id="zcm_support_delivery" name="support_delivery">
							<option value="popup_first" <?php selected( $delivery, 'popup_first' ); ?>><?php esc_html_e( 'Popup first — full inbox when the popup is closed (recommended)', 'zymarg-communication' ); ?></option>
							<option value="auto"        <?php selected( $delivery, 'auto' ); ?>><?php esc_html_e( 'Auto — full inbox if the page has one, otherwise popup', 'zymarg-communication' ); ?></option>
							<option value="popup"       <?php selected( $delivery, 'popup' ); ?>><?php esc_html_e( 'Popup only — never reveal the in-page inbox', 'zymarg-communication' ); ?></option>
							<option value="page"        <?php selected( $delivery, 'page' ); ?>><?php esc_html_e( 'Full Messages page — always navigate away', 'zymarg-communication' ); ?></option>
							<?php if ( 'inline' === $delivery ) : ?>
								<?php /* Legacy value kept selectable only while it is the saved one, so saving does not silently change behaviour. It resolves like Auto. */ ?>
								<option value="inline" selected><?php esc_html_e( 'In-page inbox (legacy — behaves like Auto)', 'zymarg-communication' ); ?></option>
							<?php endif; ?>
						</select>
						<p class="description">
							<?php esc_html_e( 'Popup first: clicking Contact Support opens the chat popup straight away. Closing the popup reveals the roomy in-page inbox on the same page, and an "Open in popup" button in its header takes the customer back. Only one of the two is ever on screen at a time. Pressing Escape dismisses support entirely.', 'zymarg-communication' ); ?>
						</p>
						<?php if ( $popup->deliveryNeedsPopup() && ! self::flagEnabled( 'surface.popup' ) ) : ?>
							<p class="description" style="color:#b32d2e;font-weight:600;">
								<?php esc_html_e( 'Heads up: the "Store page chat popup" feature flag is currently OFF, so the popup cannot open. This mode will silently fall back to the in-page inbox. Enable that flag on the Flags tab.', 'zymarg-communication' ); ?>
							</p>
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="zcm_msg_behaviour"><?php esc_html_e( 'When a new message arrives', 'zymarg-communication' ); ?></label></th>
					<td>
						<select id="zcm_msg_behaviour" name="new_message_behavior">
							<option value="toast"    <?php selected( $behaviour, 'toast' ); ?>><?php esc_html_e( 'Show a toast notification (recommended)', 'zymarg-communication' ); ?></option>
							<option value="autoopen" <?php selected( $behaviour, 'autoopen' ); ?>><?php esc_html_e( 'Open the chat popup automatically', 'zymarg-communication' ); ?></option>
							<option value="badge"    <?php selected( $behaviour, 'badge' ); ?>><?php esc_html_e( 'Silent — update the unread badge only', 'zymarg-communication' ); ?></option>
						</select>
						<p class="description"><?php esc_html_e( 'Auto-open also respects the per-page allow-list under General.', 'zymarg-communication' ); ?></p>
					</td>
				</tr>
			</table>

			<hr />
			<h3><?php esc_html_e( 'Helpline session', 'zymarg-communication' ); ?></h3>
			<p class="description" style="margin-bottom:12px;">
				<?php esc_html_e( 'Support is a helpline: a customer has one live case at a time. If your team has replied and the customer goes quiet, the case can close itself so their next contact starts clean instead of landing in a half-finished thread. This never applies while a case is waiting on YOUR team.', 'zymarg-communication' ); ?>
			</p>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Close quiet cases', 'zymarg-communication' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="support_session_enabled" value="1" <?php checked( $session->enabled() ); ?> />
							<?php esc_html_e( 'Close a case when the customer stops replying', 'zymarg-communication' ); ?>
						</label>
						<p class="description"><?php esc_html_e( 'Turn this off to let cases stay open indefinitely.', 'zymarg-communication' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="zcm_session_minutes"><?php esc_html_e( 'Wait before closing', 'zymarg-communication' ); ?></label></th>
					<td>
						<input
							type="number"
							id="zcm_session_minutes"
							name="support_session_minutes"
							value="<?php echo esc_attr( (string) $session->minutes() ); ?>"
							min="<?php echo esc_attr( (string) \ZymargCommunication\Modules\Support\Services\SupportSessionSettings::MIN_MINUTES ); ?>"
							max="<?php echo esc_attr( (string) \ZymargCommunication\Modules\Support\Services\SupportSessionSettings::MAX_MINUTES ); ?>"
							step="1"
							class="small-text"
						/>
						<?php esc_html_e( 'minutes', 'zymarg-communication' ); ?>
						<p class="description">
							<?php esc_html_e( 'Counted from your team\'s last reply. Set whatever suits how your team works — anything from 1 minute to 1440 (a full day). A short wait keeps people focused on the conversation; a longer one is kinder if your customers step away mid-chat.', 'zymarg-communication' ); ?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="zcm_session_warn"><?php esc_html_e( 'Warn the customer', 'zymarg-communication' ); ?></label></th>
					<td>
						<input
							type="number"
							id="zcm_session_warn"
							name="support_session_warn_seconds"
							value="<?php echo esc_attr( (string) $session->warnSeconds() ); ?>"
							min="<?php echo esc_attr( (string) \ZymargCommunication\Modules\Support\Services\SupportSessionSettings::MIN_WARN_SECONDS ); ?>"
							max="<?php echo esc_attr( (string) \ZymargCommunication\Modules\Support\Services\SupportSessionSettings::MAX_WARN_SECONDS ); ?>"
							step="5"
							class="small-text"
						/>
						<?php esc_html_e( 'seconds before closing', 'zymarg-communication' ); ?>
						<p class="description"><?php esc_html_e( 'The customer always sees a live countdown, and gets one notification at this point. If they are part-way through typing when the countdown runs low, they are automatically given more time.', 'zymarg-communication' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="zcm_session_timeout"><?php esc_html_e( 'When the time runs out', 'zymarg-communication' ); ?></label></th>
					<td>
						<select id="zcm_session_timeout" name="support_session_on_timeout">
							<option value="closed"   <?php selected( $session->onTimeout(), 'closed' ); ?>><?php esc_html_e( 'Close the case — their next message starts a brand-new one', 'zymarg-communication' ); ?></option>
							<option value="resolved" <?php selected( $session->onTimeout(), 'resolved' ); ?>><?php esc_html_e( 'Mark it resolved — their next message reopens the same case', 'zymarg-communication' ); ?></option>
						</select>
						<p class="description"><?php esc_html_e( 'Closing suits a helpline, where every call is its own call. Resolving is friendlier when customers often come straight back about the same thing. Either way nothing is deleted — the whole conversation is kept.', 'zymarg-communication' ); ?></p>
					</td>
				</tr>
			</table>

			<hr />
			<h3><?php esc_html_e( 'Smart Intake', 'zymarg-communication' ); ?></h3>
			<p class="description" style="margin-bottom:12px;">
				<?php esc_html_e( 'Before a customer opens a support thread, ask what it is about and which order it concerns. The answers are attached to the ticket so your team sees the context immediately. Every word below is yours to change — leave a field blank to use the default shown in grey.', 'zymarg-communication' ); ?>
			</p>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Show reply-time line', 'zymarg-communication' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="support_intake_show_availability" value="1" <?php checked( $intake->showAvailability() ); ?> />
							<?php esc_html_e( 'Tell the customer how soon to expect a reply', 'zymarg-communication' ); ?>
						</label>
						<p class="description"><?php esc_html_e( 'Untick to hide it completely, however the field below is filled in.', 'zymarg-communication' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Enable Smart Intake', 'zymarg-communication' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="support_intake_enabled" value="1" <?php checked( $intake->enabled() ); ?> />
							<?php esc_html_e( 'Ask the customer a couple of questions first', 'zymarg-communication' ); ?>
						</label>
						<p class="description"><?php esc_html_e( 'Turn this off to open the chat immediately with no questions.', 'zymarg-communication' ); ?></p>
					</td>
				</tr>
				<?php foreach ( $copy_fields as $key => $meta ) : ?>
				<tr>
					<th scope="row"><label for="zcm_<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $meta[0] ); ?></label></th>
					<td>
						<input type="text" id="zcm_<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $key ); ?>"
							class="regular-text" value="<?php echo esc_attr( $intake->raw( $key ) ); ?>"
							placeholder="<?php echo esc_attr( (string) ( $defaults[ $key ] ?? '' ) ); ?>" />
						<?php if ( '' !== $meta[1] ) : ?><p class="description"><?php echo esc_html( $meta[1] ); ?></p><?php endif; ?>
					</td>
				</tr>
				<?php endforeach; ?>
			</table>

			<hr />
			<h3><?php esc_html_e( 'Topic chips', 'zymarg-communication' ); ?></h3>
			<p class="description" style="margin-bottom:12px;">
				<?php esc_html_e( 'One topic per line. Use "key|Label" to keep a stable key, or just write the label and a key is made for you. The key is stored on the ticket and shown to your team, so renaming a label is always safe; changing a key starts a fresh bucket for future tickets. Leave a box empty to use the defaults.', 'zymarg-communication' ); ?>
			</p>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="zcm_topics_buyer"><?php esc_html_e( 'Customer topics', 'zymarg-communication' ); ?></label></th>
					<td>
						<textarea id="zcm_topics_buyer" name="<?php echo esc_attr( $S::TOPICS_BUYER ); ?>" rows="8" class="large-text code"
							placeholder="<?php echo esc_attr( $intake->defaultBuyerTopics() ); ?>"><?php echo esc_textarea( $intake->raw( $S::TOPICS_BUYER ) ); ?></textarea>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="zcm_topics_vendor"><?php esc_html_e( 'Vendor topics', 'zymarg-communication' ); ?></label></th>
					<td>
						<textarea id="zcm_topics_vendor" name="<?php echo esc_attr( $S::TOPICS_VENDOR ); ?>" rows="7" class="large-text code"
							placeholder="<?php echo esc_attr( $intake->defaultVendorTopics() ); ?>"><?php echo esc_textarea( $intake->raw( $S::TOPICS_VENDOR ) ); ?></textarea>
						<p class="description"><?php esc_html_e( 'Shown when the person asking is a seller.', 'zymarg-communication' ); ?></p>
					</td>
				</tr>
			</table>

			<p><button type="submit" class="button button-primary"><?php esc_html_e( 'Save Support Settings', 'zymarg-communication' ); ?></button></p>
		</form>
		<script>
		(function(){
			var AJAX  = <?php echo wp_json_encode( $ajax_url ); ?>;
			var NONCE = <?php echo wp_json_encode( $nonce ); ?>;
			var form  = document.getElementById('zcm-support-form');
			if (!form) { return; }
			form.addEventListener('submit', function(e){
				e.preventDefault();
				var btn = form.querySelector('button[type=submit]');
				if (btn) { btn.disabled = true; }
				var d = new URLSearchParams(new FormData(this));
				d.append('action','zymarg_comm_save_support');
				d.append('_wpnonce', NONCE);
				fetch(AJAX, { method:'POST', credentials:'same-origin', body:d })
					.then(function(r){ return r.json(); })
					.then(function(j){
						if (typeof zcmShowNotice === 'function') {
							zcmShowNotice((j && j.data && j.data.message) || 'Saved.', (j && j.success) ? 'success' : 'error');
						}
					})
					.catch(function(){
						if (typeof zcmShowNotice === 'function') { zcmShowNotice('Could not save.', 'error'); }
					})
					.then(function(){ if (btn) { btn.disabled = false; } });
			});
		})();
		</script>
		<?php
	}

	private static function renderRealtime(): void {
		$repo       = new SettingsRepository();
		$encryption = new \ZymargCommunication\Modules\Security\Services\EncryptionService();
		$decrypt = static function( string $k ) use ( $repo, $encryption ): string {
			$raw = (string) $repo->get( $k, '' );
			if ( '' === $raw ) return '';
			return $encryption->isEncrypted( $raw ) ? $encryption->decrypt( $raw ) : $raw;
		};
		$mask = static function( string $v ): string {
			if ( '' === $v ) return '';
			return substr( $v, 0, min( 8, strlen( $v ) ) ) . str_repeat( '*', max( 0, strlen( $v ) - 8 ) );
		};
		$app_id  = $decrypt( 'pusher_app_id' );
		$app_key = $decrypt( 'pusher_app_key' );
		$has_sec = '' !== $decrypt( 'pusher_app_secret' );
		$cluster = (string) $repo->get( 'pusher_cluster', '' );
		$nonce   = wp_create_nonce( self::NONCE_ACTION );
		$t_nonce = wp_create_nonce( self::FLAG_NONCE );
		$ajax_url = admin_url( 'admin-ajax.php' );
		?>
		<p><?php esc_html_e( 'Pusher powers real-time messaging. Get free credentials at pusher.com.', 'zymarg-communication' ); ?></p>
		<form id="zcm-realtime-form" autocomplete="off">
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="zcm_pusher_id"><?php esc_html_e( 'App ID', 'zymarg-communication' ); ?></label></th>
					<td>
						<input type="text" id="zcm_pusher_id" name="pusher_app_id" class="regular-text"
							placeholder="<?php echo '' !== $app_id ? esc_attr__( 'Leave blank to keep current', 'zymarg-communication' ) : esc_attr__( 'Enter App ID', 'zymarg-communication' ); ?>" />
						<?php if ( '' !== $app_id ) : ?>
						<p class="description" style="color:var(--zc-color-success);margin-top:4px;">&#10003; <?php esc_html_e( 'Current App ID:', 'zymarg-communication' ); ?> <strong><code><?php echo esc_html( $app_id ); ?></code></strong></p>
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="zcm_pusher_key"><?php esc_html_e( 'Key', 'zymarg-communication' ); ?></label></th>
					<td>
						<input type="text" id="zcm_pusher_key" name="pusher_app_key" class="regular-text"
							placeholder="<?php echo '' !== $app_key ? esc_attr__( 'Leave blank to keep current', 'zymarg-communication' ) : esc_attr__( 'Enter Key', 'zymarg-communication' ); ?>" />
						<?php if ( '' !== $app_key ) : ?>
						<p class="description" style="color:var(--zc-color-success);margin-top:4px;">&#10003; <?php esc_html_e( 'Current Key:', 'zymarg-communication' ); ?> <strong><code><?php echo esc_html( $mask( $app_key ) ); ?></code></strong></p>
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="zcm_pusher_sec"><?php esc_html_e( 'Secret', 'zymarg-communication' ); ?></label></th>
					<td>
						<input type="password" id="zcm_pusher_sec" name="pusher_app_secret" class="regular-text"
							placeholder="<?php echo $has_sec ? esc_attr__( 'Leave blank to keep current', 'zymarg-communication' ) : esc_attr__( 'Enter Secret', 'zymarg-communication' ); ?>" />
						<?php if ( $has_sec ) : ?>
						<p class="description" style="color:var(--zc-color-success);margin-top:4px;">&#10003; <?php esc_html_e( 'Saved', 'zymarg-communication' ); ?></p>
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="zcm_pusher_cluster"><?php esc_html_e( 'Cluster', 'zymarg-communication' ); ?></label></th>
					<td>
						<select id="zcm_pusher_cluster" name="pusher_cluster">
							<?php
							foreach ( array( 'ap1'=>'ap1 (Singapore)', 'ap2'=>'ap2 (Asia Pacific)', 'ap3'=>'ap3 (Tokyo)', 'eu'=>'eu (Europe)', 'us2'=>'us2 (United States)', 'us3'=>'us3 (United States East)', 'mt1'=>'mt1 (United States, default)' ) as $v => $l ) {
								printf( '<option value="%s"%s>%s</option>', esc_attr($v), selected($cluster,$v,false), esc_html($l) );
							}
							?>
						</select>
					</td>
				</tr>
			</table>
			<button type="submit" id="zcm-rt-save" class="button button-primary"><?php esc_html_e( 'Save Pusher Settings', 'zymarg-communication' ); ?></button>
			<span id="zcm-rt-status" style="margin-left:12px;font-weight:600;"></span>
		</form>
		<hr style="margin-top:32px;"/>
		<h3><?php esc_html_e( 'Test Connection', 'zymarg-communication' ); ?></h3>
		<p><?php esc_html_e( 'Save first, then click Test to verify the Pusher connection.', 'zymarg-communication' ); ?></p>
		<button type="button" id="zcm-pusher-test" class="button button-secondary"><?php esc_html_e( 'Test Pusher Connection', 'zymarg-communication' ); ?></button>
		<span id="zcm-pusher-result" style="margin-left:12px;font-weight:600;"></span>
		<script>
		(function(){
			var AJAX   = <?php echo wp_json_encode( $ajax_url ); ?>;
			var NONCE  = <?php echo wp_json_encode( $nonce ); ?>;
			var TNONCE = <?php echo wp_json_encode( $t_nonce ); ?>;
			document.getElementById('zcm-realtime-form').addEventListener('submit',function(e){
				e.preventDefault();
				var btn=document.getElementById('zcm-rt-save');
				var st=document.getElementById('zcm-rt-status');
				btn.disabled=true; st.textContent='Saving…'; st.style.color='#666';
				var d=new URLSearchParams(new FormData(this));
				d.append('action','zymarg_comm_save_realtime'); d.append('_wpnonce',NONCE);
				fetch(AJAX,{method:'POST',body:d}).then(function(r){return r.json();})
					.then(function(res){
						if(res.success){
							st.textContent='\u2713 Saved'; st.style.color='#46b450';
							['zcm_pusher_id','zcm_pusher_key','zcm_pusher_sec'].forEach(function(id){var el=document.getElementById(id);if(el)el.value='';});
							if(typeof zcmShowNotice==='function') zcmShowNotice('Pusher settings saved. Reload the tab to see updated credential info.','success');
						}else{
							st.textContent='\u2717 Error'; st.style.color='#dc3232';
							if(typeof zcmShowNotice==='function') zcmShowNotice((res.data&&res.data.message)||'Save failed.','error');
						}
						btn.disabled=false; setTimeout(function(){st.textContent='';},3000);
					}).catch(function(e){st.textContent='\u2717 '+e.message; st.style.color='#dc3232'; btn.disabled=false;});
			});
			document.getElementById('zcm-pusher-test').addEventListener('click',function(){
				var btn=this; var res=document.getElementById('zcm-pusher-result');
				btn.disabled=true; res.textContent='Testing…'; res.style.color='#666';
				var d=new URLSearchParams();
				d.append('action','zymarg_comm_pusher_test'); d.append('_wpnonce',TNONCE);
				fetch(AJAX,{method:'POST',body:d}).then(function(r){return r.json();})
					.then(function(data){
						var ok=data.success&&(data.data.status==='connected'||data.data.status==='ok');
						res.textContent=ok?'\u2713 Connected':'\u2717 '+((data.data&&data.data.message)||'Failed');
						res.style.color=ok?'#46b450':'#dc3232'; btn.disabled=false;
					}).catch(function(e){res.textContent='\u2717 '+e.message; res.style.color='#dc3232'; btn.disabled=false;});
			});
		})();
		</script>
		<?php
	}

	private static function renderFlags(): void {
		$flag_repo = new FeatureFlagRepository();
		$flags     = $flag_repo->findAll();
		$nonce     = wp_create_nonce( self::FLAG_NONCE );
		$ajax_url  = admin_url( 'admin-ajax.php' );
		$grouped   = array();
		foreach ( $flags as $flag ) $grouped[ $flag->group ][] = $flag;
		ksort( $grouped );
		if ( empty( $grouped ) ) {
			echo '<p>' . esc_html__( 'No feature flags found.', 'zymarg-communication' ) . '</p>';
			return;
		}
		?>
		<style>.zcm-flag-row{display:flex;align-items:center;padding:12px 0;border-bottom:1px solid var(--zc-color-divider);}.zcm-flag-info{flex:1;}.zcm-flag-label{font-weight:600;}.zcm-flag-desc{color:var(--zc-color-text-muted);font-size:13px;}.zcm-flag-key{font-family:monospace;font-size:12px;color:var(--zc-color-neutral-text);}.zcm-toggle{position:relative;display:inline-block;width:44px;height:24px;flex-shrink:0;}.zcm-toggle input{opacity:0;width:0;height:0;}.zcm-slider{position:absolute;cursor:pointer;top:0;left:0;right:0;bottom:0;background:var(--zc-color-outline);border-radius:24px;transition:.3s;}.zcm-slider:before{position:absolute;content:"";height:18px;width:18px;left:3px;bottom:3px;background:#fff;border-radius:50%;transition:.3s;}input:checked+.zcm-slider{background:var(--zc-color-success);}input:checked+.zcm-slider:before{transform:translateX(20px);}.zcm-saving{color:var(--zc-color-neutral-text);font-size:12px;margin-left:10px;min-width:60px;}</style>
		<p><?php esc_html_e( 'Toggle features on or off. Changes save instantly.', 'zymarg-communication' ); ?></p>
		<?php foreach ( $grouped as $group => $gflags ) : ?>
		<h3 style="text-transform:capitalize;border-bottom:2px solid var(--zc-color-divider);padding-bottom:6px;"><?php echo esc_html( $group ); ?></h3>
		<?php foreach ( $gflags as $flag ) :
			$key = esc_attr( $flag->flagKey ); ?>
		<div class="zcm-flag-row">
			<div class="zcm-flag-info">
				<div class="zcm-flag-label"><?php echo esc_html($flag->label); ?><?php if($flag->isLocked):?> <span style="color:var(--zc-color-danger);font-size:11px;">[locked]</span><?php endif;?></div>
				<?php if($flag->description):?><div class="zcm-flag-desc"><?php echo esc_html($flag->description);?></div><?php endif;?>
				<div class="zcm-flag-key"><?php echo esc_html($flag->flagKey);?></div>
			</div>
			<label class="zcm-toggle">
				<input type="checkbox" class="zcm-flag-toggle" data-key="<?php echo $key;?>" data-nonce="<?php echo esc_attr($nonce);?>" data-ajax="<?php echo esc_attr($ajax_url);?>" <?php checked($flag->isEnabled);?> <?php if($flag->isLocked) echo 'disabled';?>/>
				<span class="zcm-slider"></span>
			</label>
			<span class="zcm-saving" id="zcm-saving-<?php echo $key;?>"></span>
		</div>
		<?php endforeach; endforeach; ?>
		<script>
		document.querySelectorAll('.zcm-flag-toggle').forEach(function(cb){
			cb.addEventListener('change',function(){
				var key=this.dataset.key,nonce=this.dataset.nonce,ajax=this.dataset.ajax,enable=this.checked?'1':'0';
				var el=document.getElementById('zcm-saving-'+key);
				if(el){el.textContent='Saving…';el.style.color='#999';}
				var d=new URLSearchParams();
				d.append('action','zymarg_comm_toggle_flag');d.append('flag_key',key);d.append('enabled',enable);d.append('_wpnonce',nonce);
				fetch(ajax,{method:'POST',body:d}).then(function(r){return r.json();})
					.then(function(res){if(el){el.textContent=res.success?'\u2713 Saved':'\u2717 Error';el.style.color=res.success?'#46b450':'#dc3232';setTimeout(function(){el.textContent='';},2000);}})  
					.catch(function(){if(el){el.textContent='\u2717 Error';el.style.color='#dc3232';}});
			});
		});
		</script>
		<?php
	}

	// =========================================================================
	// AJAX save handlers
	// =========================================================================

	public static function handleSaveGeneral(): void {
		check_ajax_referer( self::NONCE_ACTION );
		if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( array( 'message' => 'Forbidden' ), 403 );
		$repo = new SettingsRepository();
		update_option( 'zymarg_comm_admin_menu_label', isset($_POST['menu_label']) ? sanitize_text_field(wp_unslash((string)$_POST['menu_label'])) : 'Communication', false );
		$repo->set( 'admin_notification_email', isset($_POST['admin_email']) ? sanitize_email(wp_unslash((string)$_POST['admin_email'])) : '' );
		$repo->set( 'messages_page_id', (string) ( isset($_POST['messages_page_id']) ? absint($_POST['messages_page_id']) : 0 ) );
		$repo->set( 'vendor_messages_page_id', (string) ( isset($_POST['vendor_messages_page_id']) ? absint($_POST['vendor_messages_page_id']) : 0 ) );

		// Popup auto-open. An unchecked checkbox is simply absent from the POST,
		// so treat "missing" as off rather than as "leave unchanged".
		$repo->set( 'popup_autoopen_enabled', isset( $_POST['popup_autoopen_enabled'] ) ? '1' : '0' );
		$popup_pages = array();
		if ( isset( $_POST['popup_pages'] ) && is_array( $_POST['popup_pages'] ) ) {
			$popup_pages = array_values( array_unique( array_filter( array_map( 'absint', (array) wp_unslash( $_POST['popup_pages'] ) ) ) ) );
		}
		$repo->set( 'popup_autoopen_page_ids', implode( ',', $popup_pages ) );

		wp_send_json_success( array( 'message' => 'Saved.' ) );
	}

	/**
	 * Save the Support tab (1.29.0).
	 *
	 * Blank copy fields are stored as blank deliberately — that is how the owner
	 * reverts to the shipped default, so "missing" must not mean "leave alone".
	 * The delivery/behaviour setters validate their own values, so an edited
	 * request body cannot poke an unknown mode into the front end.
	 */
	public static function handleSaveSupport(): void {
		check_ajax_referer( self::NONCE_ACTION );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Forbidden' ), 403 );
		}

		$popup   = new \ZymargCommunication\Modules\Settings\Services\PopupSettingsService();
		$intake  = new \ZymargCommunication\Modules\Support\Services\SupportIntakeSettings();
		$session = new \ZymargCommunication\Modules\Support\Services\SupportSessionSettings();
		$S       = \ZymargCommunication\Modules\Support\Services\SupportIntakeSettings::class;

		$popup->setSupportDelivery(
			isset( $_POST['support_delivery'] )
				? sanitize_text_field( wp_unslash( (string) $_POST['support_delivery'] ) )
				: \ZymargCommunication\Modules\Settings\Services\PopupSettingsService::DELIVERY_DEFAULT
		);
		$popup->setNewMessageBehavior(
			isset( $_POST['new_message_behavior'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['new_message_behavior'] ) ) : 'toast'
		);

		// Unchecked checkbox is absent from the POST — that means OFF here.
		$intake->setEnabled( isset( $_POST['support_intake_enabled'] ) );
		$intake->setShowAvailability( isset( $_POST['support_intake_show_availability'] ) );

		// Helpline session (1.31.0). The setters clamp, so a hand-crafted POST
		// cannot store a zero-minute window that would close cases the instant an
		// agent replies. Absent fields fall back to the shipped defaults rather
		// than to zero.
		$session->setEnabled( isset( $_POST['support_session_enabled'] ) );
		$session->setMinutes(
			isset( $_POST['support_session_minutes'] )
				? absint( $_POST['support_session_minutes'] )
				: \ZymargCommunication\Modules\Support\Services\SupportSessionSettings::DEFAULT_MINUTES
		);
		$session->setWarnSeconds(
			isset( $_POST['support_session_warn_seconds'] )
				? absint( $_POST['support_session_warn_seconds'] )
				: \ZymargCommunication\Modules\Support\Services\SupportSessionSettings::DEFAULT_WARN_SECONDS
		);
		$session->setOnTimeout(
			isset( $_POST['support_session_on_timeout'] )
				? sanitize_text_field( wp_unslash( (string) $_POST['support_session_on_timeout'] ) )
				: \ZymargCommunication\Modules\Support\Services\SupportSessionSettings::DEFAULT_ON_TIMEOUT
		);

		$copy = array();
		foreach ( array_keys( $intake->defaults() ) as $key ) {
			$copy[ $key ] = isset( $_POST[ $key ] ) ? wp_unslash( (string) $_POST[ $key ] ) : '';
		}
		$intake->saveText( $copy );

		$intake->saveTopics( 'buyer', isset( $_POST[ $S::TOPICS_BUYER ] ) ? wp_unslash( (string) $_POST[ $S::TOPICS_BUYER ] ) : '' );
		$intake->saveTopics( 'vendor', isset( $_POST[ $S::TOPICS_VENDOR ] ) ? wp_unslash( (string) $_POST[ $S::TOPICS_VENDOR ] ) : '' );

		wp_send_json_success( array( 'message' => __( 'Support settings saved.', 'zymarg-communication' ) ) );
	}

	public static function handleSaveRealtime(): void {
		check_ajax_referer( self::NONCE_ACTION );
		if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( array( 'message' => 'Forbidden' ), 403 );
		$repo       = new SettingsRepository();
		$encryption = new \ZymargCommunication\Modules\Security\Services\EncryptionService();
		foreach ( array( 'pusher_app_id', 'pusher_app_key', 'pusher_app_secret' ) as $key ) {
			$val = isset($_POST[$key]) ? sanitize_text_field(wp_unslash((string)$_POST[$key])) : '';
			if ( '' === $val ) continue;
			$enc = $encryption->encrypt( $val );
			$repo->set( $key, '' !== $enc ? $enc : $val );
		}
		$cluster = isset($_POST['pusher_cluster']) ? sanitize_text_field(wp_unslash((string)$_POST['pusher_cluster'])) : '';
		if ( '' !== $cluster ) $repo->set( 'pusher_cluster', $cluster );
		wp_send_json_success( array( 'message' => 'Saved.' ) );
	}

	/**
	 * Is a feature flag on? (1.30.0)
	 *
	 * Fails OPEN — a missing or throwing flag service returns true — which
	 * matches SupportChat::flag() and, more importantly, means a half-booted
	 * container never makes this screen shout about a flag it cannot read.
	 *
	 * Used for the delivery-mode warning: `popup_first` and `popup` both need
	 * `surface.popup`, because without it live-chat.js returns early and never
	 * publishes open(), so the popup branch silently degrades.
	 */
	private static function flagEnabled( string $key ): bool {
		$svc_class = \ZymargCommunication\Modules\FeatureFlags\Services\FeatureFlagService::class;
		if ( ! ServiceProvider::has( $svc_class ) ) {
			return true;
		}

		try {
			return (bool) ServiceProvider::get( $svc_class )->isEnabled( $key );
		} catch ( \Throwable $e ) {
			return true;
		}
	}

	public static function handleFlagToggle(): void {
		check_ajax_referer( self::FLAG_NONCE );
		if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( array( 'message' => 'Forbidden' ), 403 );
		// NOTE: sanitize_key() strips dots, so every flag key was mangled on the
		// way in ("surface.buyer_inbox" -> "surfacebuyer_inbox") and the UPDATE
		// matched nothing. Mirror the REST route pattern [a-z0-9._-] instead.
		$raw      = isset( $_POST['flag_key'] ) ? (string) wp_unslash( $_POST['flag_key'] ) : '';
		$flag_key = (string) preg_replace( '/[^a-z0-9._-]/', '', strtolower( $raw ) );
		$enabled  = isset($_POST['enabled']) && '1' === $_POST['enabled'];
		if ( '' === $flag_key ) wp_send_json_error( array( 'message' => 'Missing flag_key' ) );

		// Prefer the service: it honours locked flags and invalidates the feature
		// flag cache. Writing straight to the repository left a stale cache for up
		// to 5 minutes on sites with a persistent object cache.
		$svc_class = \ZymargCommunication\Modules\FeatureFlags\Services\FeatureFlagService::class;
		if ( ServiceProvider::has( $svc_class ) ) {
			$svc = ServiceProvider::get( $svc_class );
			$ok  = $enabled ? $svc->enable( $flag_key ) : $svc->disable( $flag_key );
		} else {
			$repo = new FeatureFlagRepository();
			$ok   = $repo->setEnabled( $flag_key, $enabled );
		}
		$ok ? wp_send_json_success( array( 'flag_key' => $flag_key, 'enabled' => $enabled ) ) : wp_send_json_error( array( 'message' => 'Flag not found or locked.' ) );
	}

	public static function handlePusherTest(): void {
		check_ajax_referer( self::FLAG_NONCE );
		if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( array( 'message' => 'Forbidden' ), 403 );
		$repo       = new SettingsRepository();
		$encryption = new \ZymargCommunication\Modules\Security\Services\EncryptionService();
		$decrypt    = static function( string $k ) use ( $repo, $encryption ): string {
			$raw = (string) $repo->get( $k, '' );
			if ( '' === $raw ) return '';
			return $encryption->isEncrypted( $raw ) ? $encryption->decrypt( $raw ) : $raw;
		};
		$creds = array( 'app_id' => $decrypt('pusher_app_id'), 'app_key' => $decrypt('pusher_app_key'), 'app_secret' => $decrypt('pusher_app_secret'), 'cluster' => (string) $repo->get('pusher_cluster','mt1') );
		foreach ( $creds as $k => $v ) {
			if ( '' === $v ) wp_send_json_error( array( 'status' => 'failed', 'message' => 'Credential missing: '.$k ) );
		}
		$pusher = new \ZymargCommunication\Modules\Realtime\Services\PusherService();
		$result = $pusher->testConnection( $creds );
		'connected' === $result['status'] ? wp_send_json_success( $result ) : wp_send_json_error( $result );
	}

	// =========================================================================
	// Shared form-submit script helper
	// =========================================================================

	private static function printFormScript( string $form_id, string $btn_id, string $status_id, string $action, string $nonce, string $ajax_url ): void {
		?>
		<script>
		(function(){
			var AJAX  = <?php echo wp_json_encode( $ajax_url ); ?>;
			var NONCE = <?php echo wp_json_encode( $nonce ); ?>;
			var form  = document.getElementById(<?php echo wp_json_encode( $form_id ); ?>);
			if(!form) return;
			form.addEventListener('submit',function(e){
				e.preventDefault();
				var btn=document.getElementById(<?php echo wp_json_encode( $btn_id ); ?>);
				var st=document.getElementById(<?php echo wp_json_encode( $status_id ); ?>);
				btn.disabled=true; st.textContent='Saving\u2026'; st.style.color='#666';
				var d=new URLSearchParams(new FormData(this));
				d.append('action',<?php echo wp_json_encode( $action ); ?>); d.append('_wpnonce',NONCE);
				fetch(AJAX,{method:'POST',body:d}).then(function(r){return r.json();})
					.then(function(res){
						if(res.success){ st.textContent='\u2713 Saved'; st.style.color='#46b450';
							if(typeof zcmShowNotice==='function') zcmShowNotice('Settings saved successfully.','success');
						}else{ st.textContent='\u2717 Error'; st.style.color='#dc3232';
							if(typeof zcmShowNotice==='function') zcmShowNotice((res.data&&res.data.message)||'Save failed.','error'); }
						btn.disabled=false; setTimeout(function(){st.textContent='';},3000);
					}).catch(function(e){ st.textContent='\u2717 '+e.message; st.style.color='#dc3232'; btn.disabled=false; });
			});
		})();
		</script>
		<?php
	}

	// =========================================================================
	// Email Notifications tab
	// =========================================================================

	private static function renderEmail(): void {
		$repo      = new SettingsRepository();
		$from_name = (string) $repo->get( 'email_from_name', (string) get_option( 'blogname' ) );
		$from_addr = (string) $repo->get( 'email_from_address', (string) get_option( 'admin_email' ) );
		$subject   = (string) $repo->get( 'email_subject_template', '' );
		$nonce     = wp_create_nonce( self::NONCE_ACTION );
		$ajax_url  = admin_url( 'admin-ajax.php' );
		?>
		<p><?php esc_html_e( 'Customize the sender and subject for emails this plugin sends (new-message and moderation notifications).', 'zymarg-communication' ); ?></p>
		<form id="zcm-email-form" autocomplete="off">
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="zcm_from_name"><?php esc_html_e( 'From name', 'zymarg-communication' ); ?></label></th>
					<td><input type="text" id="zcm_from_name" name="email_from_name" class="regular-text" value="<?php echo esc_attr( $from_name ); ?>" />
					<p class="description"><?php esc_html_e( 'Display name shown as the email sender.', 'zymarg-communication' ); ?></p></td>
				</tr>
				<tr>
					<th scope="row"><label for="zcm_from_addr"><?php esc_html_e( 'From address', 'zymarg-communication' ); ?></label></th>
					<td><input type="email" id="zcm_from_addr" name="email_from_address" class="regular-text" value="<?php echo esc_attr( $from_addr ); ?>" />
					<p class="description"><?php esc_html_e( 'Email address used in the From header.', 'zymarg-communication' ); ?></p></td>
				</tr>
				<tr>
					<th scope="row"><label for="zcm_subject"><?php esc_html_e( 'Subject line override', 'zymarg-communication' ); ?></label></th>
					<td><input type="text" id="zcm_subject" name="email_subject_template" class="regular-text" value="<?php echo esc_attr( $subject ); ?>" placeholder="<?php esc_attr_e( 'Leave blank to use default subjects', 'zymarg-communication' ); ?>" />
					<p class="description"><?php esc_html_e( 'Optional. Use {site} for the site name. Leave blank to keep built-in subjects.', 'zymarg-communication' ); ?></p></td>
				</tr>
			</table>
			<button type="submit" id="zcm-email-save" class="button button-primary"><?php esc_html_e( 'Save Settings', 'zymarg-communication' ); ?></button>
			<span id="zcm-email-status" style="margin-left:12px;font-weight:600;"></span>
		</form>
		<?php self::printFormScript( 'zcm-email-form', 'zcm-email-save', 'zcm-email-status', 'zymarg_comm_save_email', $nonce, $ajax_url ); ?>
		<?php
	}

	// =========================================================================
	// Attachments tab
	// =========================================================================

	private static function renderAttachments(): void {
		$repo        = new SettingsRepository();
		$max_mb      = (int) $repo->get( 'attachments_max_size_mb', 8 );
		if ( $max_mb <= 0 ) { $max_mb = 8; }
		$allowed     = (string) $repo->get( 'attachments_allowed_types', 'jpg,png,webp' );
		$allowed_arr = array_filter( array_map( 'trim', explode( ',', strtolower( $allowed ) ) ) );
		$types       = array( 'jpg' => 'JPEG (.jpg / .jpeg)', 'png' => 'PNG (.png)', 'webp' => 'WebP (.webp)' );
		$nonce       = wp_create_nonce( self::NONCE_ACTION );
		$ajax_url    = admin_url( 'admin-ajax.php' );
		?>
		<p><?php esc_html_e( 'Control uploaded image attachments. For security, only image formats validated by magic-byte checks are permitted.', 'zymarg-communication' ); ?></p>
		<form id="zcm-attachments-form" autocomplete="off">
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="zcm_max_mb"><?php esc_html_e( 'Max file size (MB)', 'zymarg-communication' ); ?></label></th>
					<td><input type="number" min="1" max="64" step="1" id="zcm_max_mb" name="attachments_max_size_mb" value="<?php echo esc_attr( (string) $max_mb ); ?>" class="small-text" />
					<p class="description"><?php esc_html_e( 'Maximum size per uploaded file. Also bounded by your server upload_max_filesize.', 'zymarg-communication' ); ?></p></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Allowed file types', 'zymarg-communication' ); ?></th>
					<td>
						<?php foreach ( $types as $ext => $label ) : ?>
						<label style="display:block;margin-bottom:6px;"><input type="checkbox" name="attachments_allowed_types[]" value="<?php echo esc_attr( $ext ); ?>" <?php checked( in_array( $ext, $allowed_arr, true ) ); ?> /> <?php echo esc_html( $label ); ?></label>
						<?php endforeach; ?>
						<p class="description"><?php esc_html_e( 'At least one type must stay enabled. Defaults apply if none selected.', 'zymarg-communication' ); ?></p>
					</td>
				</tr>
			</table>
			<button type="submit" id="zcm-attachments-save" class="button button-primary"><?php esc_html_e( 'Save Settings', 'zymarg-communication' ); ?></button>
			<span id="zcm-attachments-status" style="margin-left:12px;font-weight:600;"></span>
		</form>
		<?php self::printFormScript( 'zcm-attachments-form', 'zcm-attachments-save', 'zcm-attachments-status', 'zymarg_comm_save_attachments', $nonce, $ajax_url ); ?>
		<?php
	}

	// =========================================================================
	// Moderation tab
	// =========================================================================

	private static function renderModeration(): void {
		$repo      = new SettingsRepository();
		$blocklist = new \ZymargCommunication\Modules\Moderation\Services\BlocklistService();
		$words     = implode( "\n", $blocklist->words() );
		$per_min   = (int) $repo->get( 'rate_limit_per_minute', 30 );
		if ( $per_min <= 0 ) { $per_min = 30; }
		$nonce     = wp_create_nonce( self::NONCE_ACTION );
		$ajax_url  = admin_url( 'admin-ajax.php' );
		?>
		<p><?php esc_html_e( 'Configure automated moderation. Blocked words are matched case-insensitively as whole words in outgoing messages.', 'zymarg-communication' ); ?></p>
		<form id="zcm-moderation-form" autocomplete="off">
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="zcm_blocked_words"><?php esc_html_e( 'Blocked words', 'zymarg-communication' ); ?></label></th>
					<td><textarea id="zcm_blocked_words" name="blocked_words" rows="6" class="large-text code" placeholder="<?php esc_attr_e( 'One word or phrase per line', 'zymarg-communication' ); ?>"><?php echo esc_textarea( $words ); ?></textarea>
					<p class="description"><?php esc_html_e( 'One entry per line. Messages containing these are flagged for moderation.', 'zymarg-communication' ); ?></p></td>
				</tr>
				<tr>
					<th scope="row"><label for="zcm_rate_min"><?php esc_html_e( 'Messages per minute', 'zymarg-communication' ); ?></label></th>
					<td><input type="number" min="1" max="600" step="1" id="zcm_rate_min" name="rate_limit_per_minute" value="<?php echo esc_attr( (string) $per_min ); ?>" class="small-text" />
					<p class="description"><?php esc_html_e( 'Maximum messages a user may send per minute before being rate-limited.', 'zymarg-communication' ); ?></p></td>
				</tr>
			</table>
			<button type="submit" id="zcm-moderation-save" class="button button-primary"><?php esc_html_e( 'Save Settings', 'zymarg-communication' ); ?></button>
			<span id="zcm-moderation-status" style="margin-left:12px;font-weight:600;"></span>
		</form>
		<?php self::printFormScript( 'zcm-moderation-form', 'zcm-moderation-save', 'zcm-moderation-status', 'zymarg_comm_save_moderation', $nonce, $ajax_url ); ?>
		<?php
	}

	// =========================================================================
	// Developer Tools tab
	// =========================================================================

	private static function renderDevtools(): void {
		global $wpdb;
		$repo       = new SettingsRepository();
		$debug_on   = '1' === (string) $repo->get( 'debug_logging_enabled', '0' );
		$nonce      = wp_create_nonce( self::NONCE_ACTION );
		$ajax_url   = admin_url( 'admin-ajax.php' );
		$rest_base  = esc_url_raw( rest_url( 'zymarg-comm/v1/' ) );
		$rest_nonce = wp_create_nonce( 'wp_rest' );
		$logs       = $wpdb->get_results( "SELECT admin_id, action, target_type, target_id, ip_address, created_at FROM {$wpdb->prefix}zc_audit_logs ORDER BY id DESC LIMIT 50", ARRAY_A );
		?>
		<h3><?php esc_html_e( 'Debug logging', 'zymarg-communication' ); ?></h3>
		<form id="zcm-devtools-form" autocomplete="off">
			<label><input type="checkbox" name="debug_logging_enabled" value="1" <?php checked( $debug_on ); ?> /> <?php esc_html_e( 'Log REST API errors from this plugin to the PHP error log', 'zymarg-communication' ); ?></label>
			<p class="description"><?php esc_html_e( 'When enabled, failed REST responses from this plugin are written to your server error log for troubleshooting.', 'zymarg-communication' ); ?></p>
			<p><button type="submit" id="zcm-devtools-save" class="button button-primary"><?php esc_html_e( 'Save Settings', 'zymarg-communication' ); ?></button>
			<span id="zcm-devtools-status" style="margin-left:12px;font-weight:600;"></span></p>
		</form>
		<?php self::printFormScript( 'zcm-devtools-form', 'zcm-devtools-save', 'zcm-devtools-status', 'zymarg_comm_save_devtools', $nonce, $ajax_url ); ?>

		<hr style="margin:28px 0;" />
		<h3><?php esc_html_e( 'REST API tester', 'zymarg-communication' ); ?></h3>
		<p><?php esc_html_e( 'Send a request to the plugin REST API (authenticated as you).', 'zymarg-communication' ); ?></p>
		<p style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
			<select id="zcm-rest-method"><option>GET</option><option>POST</option></select>
			<code><?php echo esc_html( $rest_base ); ?></code>
			<input type="text" id="zcm-rest-path" class="regular-text" placeholder="conversations" value="conversations" />
			<button type="button" id="zcm-rest-send" class="button"><?php esc_html_e( 'Send', 'zymarg-communication' ); ?></button>
		</p>
		<textarea id="zcm-rest-body" rows="3" class="large-text code" placeholder="<?php esc_attr_e( 'Optional JSON body for POST', 'zymarg-communication' ); ?>"></textarea>
		<pre id="zcm-rest-out" style="background:var(--zc-color-ink);color:var(--zc-color-success);padding:12px;border-radius:6px;max-height:300px;overflow:auto;margin-top:12px;display:none;"></pre>

		<hr style="margin:28px 0;" />
		<h3><?php esc_html_e( 'Audit log', 'zymarg-communication' ); ?> <span style="font-weight:400;color:var(--zc-color-neutral-text);font-size:13px;">(<?php echo esc_html( (string) count( (array) $logs ) ); ?> <?php esc_html_e( 'most recent', 'zymarg-communication' ); ?>)</span></h3>
		<?php if ( empty( $logs ) ) : ?>
		<p style="color:var(--zc-color-text-body);"><?php esc_html_e( 'No audit log entries yet.', 'zymarg-communication' ); ?></p>
		<?php else : ?>
		<table class="widefat striped" style="max-width:820px;">
			<thead><tr>
				<th><?php esc_html_e( 'When', 'zymarg-communication' ); ?></th>
				<th><?php esc_html_e( 'Admin', 'zymarg-communication' ); ?></th>
				<th><?php esc_html_e( 'Action', 'zymarg-communication' ); ?></th>
				<th><?php esc_html_e( 'Target', 'zymarg-communication' ); ?></th>
				<th><?php esc_html_e( 'IP', 'zymarg-communication' ); ?></th>
			</tr></thead>
			<tbody>
			<?php foreach ( $logs as $row ) : ?>
				<tr>
					<td><?php echo esc_html( (string) $row['created_at'] ); ?></td>
					<td><?php $u = get_userdata( (int) $row['admin_id'] ); echo esc_html( $u ? $u->user_login : ( '#' . (string) $row['admin_id'] ) ); ?></td>
					<td><code><?php echo esc_html( (string) $row['action'] ); ?></code></td>
					<td><?php echo esc_html( trim( (string) $row['target_type'] . ' ' . (string) $row['target_id'] ) ); ?></td>
					<td><?php echo esc_html( (string) $row['ip_address'] ); ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php endif; ?>
		<script>
		(function(){
			var BASE  = <?php echo wp_json_encode( $rest_base ); ?>;
			var NONCE = <?php echo wp_json_encode( $rest_nonce ); ?>;
			var btn = document.getElementById('zcm-rest-send');
			if(!btn) return;
			btn.addEventListener('click',function(){
				var m=document.getElementById('zcm-rest-method').value;
				var p=document.getElementById('zcm-rest-path').value.replace(/^\//,'');
				var b=document.getElementById('zcm-rest-body').value;
				var out=document.getElementById('zcm-rest-out');
				out.style.display='block'; out.textContent='Sending '+m+' '+BASE+p+' \u2026';
				var opts={method:m,headers:{'X-WP-Nonce':NONCE}};
				if(m==='POST'&&b.trim()){ opts.headers['Content-Type']='application/json'; opts.body=b; }
				fetch(BASE+p,opts).then(function(r){return r.text().then(function(t){return {s:r.status,t:t};});})
					.then(function(res){
						var pretty=res.t; try{ pretty=JSON.stringify(JSON.parse(res.t),null,2); }catch(e){}
						out.textContent='HTTP '+res.s+'\n\n'+pretty;
						out.style.color=(res.s>=200&&res.s<300)?'#4bd267':'#ff6b6b';
					}).catch(function(e){ out.textContent='Error: '+e.message; out.style.color='#ff6b6b'; });
			});
		})();
		</script>
		<?php
	}

	// =========================================================================
	// AJAX save handlers (Phase 2 tabs)
	// =========================================================================

	public static function handleSaveEmail(): void {
		check_ajax_referer( self::NONCE_ACTION );
		if ( ! current_user_can( 'manage_options' ) ) { wp_send_json_error( array( 'message' => 'Forbidden' ), 403 ); }
		$repo = new SettingsRepository();
		$repo->set( 'email_from_name', isset( $_POST['email_from_name'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['email_from_name'] ) ) : '' );
		$repo->set( 'email_from_address', isset( $_POST['email_from_address'] ) ? sanitize_email( wp_unslash( (string) $_POST['email_from_address'] ) ) : '' );
		$repo->set( 'email_subject_template', isset( $_POST['email_subject_template'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['email_subject_template'] ) ) : '' );
		wp_send_json_success( array( 'message' => 'Saved.' ) );
	}

	public static function handleSaveAttachments(): void {
		check_ajax_referer( self::NONCE_ACTION );
		if ( ! current_user_can( 'manage_options' ) ) { wp_send_json_error( array( 'message' => 'Forbidden' ), 403 ); }
		$repo = new SettingsRepository();
		$mb   = isset( $_POST['attachments_max_size_mb'] ) ? absint( $_POST['attachments_max_size_mb'] ) : 8;
		if ( $mb < 1 ) { $mb = 1; }
		if ( $mb > 64 ) { $mb = 64; }
		$repo->set( 'attachments_max_size_mb', (string) $mb );
		$valid = array( 'jpg', 'png', 'webp' );
		$types = array();
		if ( isset( $_POST['attachments_allowed_types'] ) && is_array( $_POST['attachments_allowed_types'] ) ) {
			foreach ( wp_unslash( (array) $_POST['attachments_allowed_types'] ) as $t ) {
				$t = sanitize_key( (string) $t );
				if ( in_array( $t, $valid, true ) ) { $types[] = $t; }
			}
		}
		if ( empty( $types ) ) { $types = $valid; }
		$repo->set( 'attachments_allowed_types', implode( ',', array_values( array_unique( $types ) ) ) );
		wp_send_json_success( array( 'message' => 'Saved.' ) );
	}

	public static function handleSaveModeration(): void {
		check_ajax_referer( self::NONCE_ACTION );
		if ( ! current_user_can( 'manage_options' ) ) { wp_send_json_error( array( 'message' => 'Forbidden' ), 403 ); }
		$repo      = new SettingsRepository();
		$blocklist = new \ZymargCommunication\Modules\Moderation\Services\BlocklistService();
		$raw       = isset( $_POST['blocked_words'] ) ? (string) wp_unslash( $_POST['blocked_words'] ) : '';
		$lines     = preg_split( '/[\r\n]+/', $raw );
		$words     = array();
		foreach ( (array) $lines as $line ) {
			$line = sanitize_text_field( $line );
			if ( '' !== trim( $line ) ) { $words[] = trim( $line ); }
		}
		$blocklist->setBlockedWords( $words );
		$min = isset( $_POST['rate_limit_per_minute'] ) ? absint( $_POST['rate_limit_per_minute'] ) : 30;
		if ( $min < 1 ) { $min = 1; }
		if ( $min > 600 ) { $min = 600; }
		$repo->set( 'rate_limit_per_minute', (string) $min );
		wp_send_json_success( array( 'message' => 'Saved.' ) );
	}

	public static function handleSaveDevtools(): void {
		check_ajax_referer( self::NONCE_ACTION );
		if ( ! current_user_can( 'manage_options' ) ) { wp_send_json_error( array( 'message' => 'Forbidden' ), 403 ); }
		$repo = new SettingsRepository();
		$on   = isset( $_POST['debug_logging_enabled'] ) && '1' === (string) $_POST['debug_logging_enabled'];
		$repo->set( 'debug_logging_enabled', $on ? '1' : '0' );
		wp_send_json_success( array( 'message' => 'Saved.' ) );
	}
}
