<?php
/**
 * ZYMARG Communication — Fallback marketplace surface injection.
 *
 * Only fires when the ZYMARG theme + vendor plugin are NOT the ones handling
 * the buyer / vendor dashboard surfaces. Uses the generic third‑party plugin
 * hooks documented in CONTRIBUTING.md §13.
 *
 * Every reference to an external plugin name / class / function must live
 * here or in Compatibility::detect().
 *
 * @package    ZymargCommunication
 * @version    1.12.0
 */

namespace ZymargCommunication\Bootstrap;

use ZymargCommunication\Frontend\BuyerInbox;
use ZymargCommunication\Frontend\VendorInbox;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class EcosystemMarketplaceFallback {

	public static function register(): void {
		add_action( 'wp_loaded', array( __CLASS__, 'wire' ), 20 );
	}

	public static function wire(): void {
		$has_theme  = has_filter( 'zymarg_os_account_sections' ) !== false;
		$has_vendor = has_filter( 'zymarg_os_vendor_render_section' ) !== false;

		if ( ! $has_theme && Compatibility::isActive( 'woocommerce' ) ) {
			self::wireWooCommerceMyAccount();
		}

		if ( ! $has_vendor ) {
			if ( Compatibility::isActive( 'dokan' ) ) {
				self::wireDokanDashboard();
			}
			if ( Compatibility::isActive( 'wcfm' ) ) {
				self::wireWcfmDashboard();
			}
			if ( Compatibility::isActive( 'wcvendors' ) ) {
				self::wireWcVendorsDashboard();
			}
		}
	}

	private static function wireWooCommerceMyAccount(): void {
		add_action( 'init', function () {
			add_rewrite_endpoint( 'messages', EP_ROOT | EP_PAGES );
		} );
		add_filter( 'woocommerce_account_menu_items', function ( $items ) {
			$new = array();
			foreach ( (array) $items as $key => $label ) {
				$new[ $key ] = $label;
				if ( 'orders' === $key ) {
					$new['messages'] = __( 'Messages', 'zymarg-communication' );
				}
			}
			if ( ! isset( $new['messages'] ) ) {
				$new['messages'] = __( 'Messages', 'zymarg-communication' );
			}
			return $new;
		} );
		add_action( 'woocommerce_account_messages_endpoint', function () {
			echo BuyerInbox::render(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		} );
	}

	private static function wireDokanDashboard(): void {
		add_action( 'dokan_dashboard_content_inside_before', function () {
			echo VendorInbox::render(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}, 20 );
	}

	private static function wireWcfmDashboard(): void {
		add_action( 'end_wcfm_dashboard', function () {
			echo VendorInbox::render(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}, 20 );
	}

	private static function wireWcVendorsDashboard(): void {
		add_action( 'wcv_dashboard_end', function () {
			echo VendorInbox::render(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}, 20 );
	}
}
