<?php
/**
 * ZYMARG Communication — Plugin coordinator.
 *
 * Runs the ordered boot sequence on `plugins_loaded`.
 *
 * @package    ZymargCommunication
 * @version    1.3.0
 */

namespace ZymargCommunication\Bootstrap;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Plugin {

	private static bool $initialized = false;

	/**
	 * Boot the plugin. Idempotent — safe to call more than once.
	 */
	public static function init(): void {
		if ( self::$initialized ) {
			return;
		}
		self::$initialized = true;

		// Load translations.
		load_plugin_textdomain(
			'zymarg-communication',
			false,
			dirname( ZYMARG_COMM_BASENAME ) . '/languages/'
		);

		// Run pending database migrations after any version bump.
		Updater::check();

		/*
		 * Self-heal the plugin's own pages (1.32.7).
		 *
		 * The Messages and Vendor Messages pages carry the inbox shortcodes, and
		 * the support popup hands off to the first of them when it cannot show
		 * the inbox in place. Until 1.32.5 deleting the plugin permanently
		 * deleted both pages, and PageRegistrar::create() only ever ran on
		 * activation — so a site that lost them (deleted plugin, emptied trash,
		 * a stray bulk action) had a support flow pointing at a page that no
		 * longer existed, with nothing anywhere reporting the fact.
		 *
		 * repair() is a couple of cheap reads when everything is healthy, and
		 * admin-only so the front end never pays for it. It adopts an existing
		 * page on the same slug rather than creating a duplicate.
		 */
		if ( is_admin() ) {
			add_action(
				'admin_init',
				static function (): void {
					$fixed = PageRegistrar::repair();
					if ( $fixed ) {
						set_transient( 'zymarg_comm_pages_repaired', array_keys( $fixed ), 60 );
					}
				},
				5
			);

			add_action(
				'admin_notices',
				static function (): void {
					$fixed = get_transient( 'zymarg_comm_pages_repaired' );
					if ( ! $fixed || ! is_array( $fixed ) ) {
						return;
					}
					delete_transient( 'zymarg_comm_pages_repaired' );
					printf(
						'<div class="notice notice-warning is-dismissible"><p><strong>%s</strong> %s <code>%s</code></p></div>',
						esc_html__( 'ZYMARG Communication:', 'zymarg-communication' ),
						esc_html__( 'a page this plugin needs was missing and has been recreated:', 'zymarg-communication' ),
						esc_html( implode( ', ', array_map( 'strval', $fixed ) ) )
					);
				}
			);
		}

		// Register services into the container.
		ServiceProvider::register();

		// Load Hooks classes from every module.
		HookLoader::load();

		// Apply stored admin settings to live behavior (uploads, email, rate limits).
		SettingsRuntime::register();

		// Register shortcodes. Callbacks are safe placeholders until Phase 4.
		ShortcodeRegistrar::register();

		// Detect active third-party plugins. Safe when nothing is active.
		Compatibility::register();

		// Register WP-Cron schedules. Callbacks are safe placeholders until Phase 8.
		Scheduler::register();

		// Register the admin sidebar menu (label: "Communication" per Phase 3).
		AdminMenu::register();
		AdminHelpPage::register();
		AdminSettingsPage::register();
		AdminConversationsPage::register();
		AdminModerationPage::register();
		AdminAnalyticsPage::register();
		AdminSupportPage::register();
		// Notifies a support agent anywhere in wp-admin that a customer is
		// waiting (1.26.0). The customer half of the same job is handled on the
		// frontend by live-chat.js via the theme's toast system.
		AdminSupportNotify::register();
		// Frontend agent console (1.28.0): admin-bar badge + slide-out drawer
		// with the ticket queue and inline reply, so an agent can triage without
		// entering wp-admin. Admin-bar-only, so shoppers never see it.
		AgentConsole::register();

		// Ecosystem integration: theme + vendor plugin filter hooks.
		\ZymargCommunication\Frontend\EcosystemIntegration::register();
		\ZymargCommunication\Frontend\AssetEnqueue::register();

		// Fallback marketplace injections (fire only when the ZYMARG
		// theme/vendor plugin have not already registered their filters).
		EcosystemMarketplaceFallback::register();
	}
}
