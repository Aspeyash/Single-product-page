<?php
/**
 * ZYMARG Communication — Updater.
 *
 * Runs pending database migrations when the plugin's version constant does
 * not match the stored installed version. All migrations are idempotent via
 * `dbDelta`, so re-running them is safe.
 *
 * @package    ZymargCommunication
 * @version    1.1.0
 */

namespace ZymargCommunication\Bootstrap;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Updater {

	public static function check(): void {
		$installed = get_option( Installer::VERSION_OPTION );

		if ( ZYMARG_COMM_VERSION === $installed ) {
			return;
		}

		if ( false === $installed ) {
			// Never activated yet. Installer::activate() owns first-run setup.
			return;
		}

		foreach ( Installer::MIGRATIONS as $migration ) {
			/** @var \ZymargCommunication\Core\Abstracts\AbstractMigration $instance */
			$instance = new $migration();
			$instance->up();
		}

		// Seed feature flags introduced by this release. Existing rows are left
		// untouched; only missing keys are inserted. Without this, a flag added
		// in an update never reaches the database on sites that upgrade in place
		// (no deactivate/reactivate), so isEnabled() reports false forever and
		// the feature it guards silently never turns on.
		\ZymargCommunication\Modules\FeatureFlags\FlagRegistry::writeDefaults();
		wp_cache_delete( 'enabled_keys', 'zymarg_comm_feature_flags' );

		update_option( Installer::VERSION_OPTION, ZYMARG_COMM_VERSION );

		do_action( 'zymarg_comm_upgraded', $installed, ZYMARG_COMM_VERSION );
	}
}
