<?php
/**
 * Registers the top-level WordPress admin sidebar menu.
 *
 * The label is read from the `zymarg_comm_admin_menu_label` option (default
 * `Communication` per CONTRIBUTING.md § 6.10 / Phase 3 acceptance). The
 * Settings module (Phase 6) may replace the callback with its own settings
 * page — this bootstrap only guarantees the menu item exists early.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Bootstrap;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdminMenu {

	private static bool $registered = false;

	public const MENU_SLUG = 'zymarg-communication';

	public static function register(): void {
		if ( self::$registered ) {
			return;
		}
		self::$registered = true;

		add_action( 'admin_menu', array( self::class, 'registerMenu' ) );
		add_action( 'admin_enqueue_scripts', array( self::class, 'enqueueAssets' ) );
		add_action( 'admin_enqueue_scripts', array( self::class, 'enqueueMenuBranding' ) );
	}

	/**
	 * Sidebar parent-menu branding (Design Tokens v3 section 2.16).
	 *
	 * Scoped to #toplevel_page_zymarg-communication and enqueued on
	 * every admin page. Brand gradient bar at rest, surface-white
	 * dashicon and label in every state.
	 */
	public static function enqueueMenuBranding(): void {
		if ( ! wp_style_is( 'zymarg-tokens', 'registered' ) ) {
			wp_register_style(
				'zymarg-tokens',
				ZYMARG_COMM_ASSETS_URL . 'css/zymarg-tokens.css',
				array(),
				ZYMARG_COMM_VERSION
			);
		}
		wp_enqueue_style( 'zymarg-tokens' );
		wp_enqueue_style(
			'zymarg-comm-menu',
			ZYMARG_COMM_ASSETS_URL . 'css/zymarg-comm-menu.css',
			array( 'zymarg-tokens' ),
			ZYMARG_COMM_VERSION
		);
	}

	public static function registerMenu(): void {
		$label = (string) get_option( 'zymarg_comm_admin_menu_label', 'Communication' );
		if ( '' === $label ) {
			$label = 'Communication';
		}

		add_menu_page(
			$label,
			$label,
			'manage_options',
			self::MENU_SLUG,
			array( self::class, 'render' ),
			'dashicons-format-chat',
			26
		);
	}

	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		// --- Gather stats safely ---
		global $wpdb;
		$total_conversations = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}zc_conversations" );
		$total_messages      = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}zc_messages WHERE deleted_at IS NULL" );
		$today_messages      = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM {$wpdb->prefix}zc_messages WHERE deleted_at IS NULL AND created_at >= %s",
			gmdate( 'Y-m-d 00:00:00' )
		) );
		$unread_messages     = (int) $wpdb->get_var(
			"SELECT COUNT(*) FROM {$wpdb->prefix}zc_messages WHERE deleted_at IS NULL AND status IN ('sending','delivered')"
		);
		$active_users        = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE %s AND option_value > %d",
			$wpdb->esc_like( '_transient_timeout_zymarg_comm_presence_' ) . '%',
			time()
		) );

		$pending_mod = 0;
		try {
			$mod_repo    = new \ZymargCommunication\Modules\Moderation\Repositories\ModerationRepository();
			$pending_mod = $mod_repo->countPending();
		} catch ( \Throwable $e ) {}

		// --- Pusher status ---
		$repo        = new \ZymargCommunication\Modules\Settings\Repositories\SettingsRepository();
		$encryption  = new \ZymargCommunication\Modules\Security\Services\EncryptionService();
		$decrypt     = static function( string $k ) use ( $repo, $encryption ): string {
			$raw = (string) $repo->get( $k, ''  );
			if ( ''  === $raw ) return '';
			return $encryption->isEncrypted( $raw ) ? $encryption->decrypt( $raw ) : $raw;
		};
		$pusher_configured = ''  !== $decrypt( 'pusher_app_id' )
			&& ''  !== $decrypt( 'pusher_app_key' )
			&& ''  !== $decrypt( 'pusher_app_secret' );
		$pusher_cluster    = (string) $repo->get( 'pusher_cluster', '—' );

		// --- Feature flags count ---
		$flag_repo    = new \ZymargCommunication\Modules\FeatureFlags\Repositories\FeatureFlagRepository();
		$all_flags    = $flag_repo->findAll();
		// The FeatureFlag model declares camelCase properties ($isEnabled); reading
		// $f->is_enabled hit an undefined property and always counted zero.
		$enabled_flags = count( array_filter( $all_flags, static fn( $f ) => $f->isEnabled ) );
		$total_flags   = count( $all_flags );

		$settings_url = admin_url( 'admin.php?page=zymarg-comm-settings' );
		$help_url     = admin_url( 'admin.php?page=zymarg-communication-help' );
		$mod_url      = admin_url( 'admin.php?page=zymarg-comm-settings&tab=flags' );
		?>
		<div class="wrap zcm-admin-page">
		<?php self::renderHeader( __( 'ZYMARG Communication', 'zymarg-communication' ), __( 'Overview, live status and quick links', 'zymarg-communication' ) ); ?>

		<style>
		.zcm-dash{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:16px;margin:24px 0;}
		.zcm-card{background:#fff;border:1px solid var(--zc-color-divider);border-radius:8px;padding:20px 24px;box-shadow:0 1px 3px rgba(0,0,0,.05);}
		.zcm-card-num{font-size:36px;font-weight:700;line-height:1;margin:6px 0 4px;color:var(--zc-color-ink);}
		.zcm-card-label{font-size:13px;color:var(--zc-color-text-muted);}
		.zcm-card-sub{font-size:12px;color:var(--zc-color-neutral-text);margin-top:2px;}
		.zcm-status{display:inline-flex;align-items:center;gap:6px;padding:4px 10px;border-radius:20px;font-size:12px;font-weight:600;}
		.zcm-status-ok{background:var(--zc-color-success-bg);color:var(--zc-color-success);}
		.zcm-status-warn{background:var(--zc-color-warning-bg);color:var(--zc-color-warning);}
		.zcm-actions{display:flex;gap:12px;flex-wrap:wrap;margin-top:24px;}
		.zcm-section-title{font-size:15px;font-weight:600;margin:28px 0 12px;color:var(--zc-color-ink);border-bottom:1px solid var(--zc-color-divider);padding-bottom:8px;}
		</style>

		<!-- Stats -->
		<div class="zcm-section-title"><?php esc_html_e( 'Overview', 'zymarg-communication' ); ?></div>
		<div class="zcm-dash">
			<div class="zcm-card">
				<div class="zcm-card-label"><?php esc_html_e( 'Total Conversations', 'zymarg-communication' ); ?></div>
				<div class="zcm-card-num"><?php echo esc_html( number_format_i18n( $total_conversations ) ); ?></div>
			</div>
			<div class="zcm-card">
				<div class="zcm-card-label"><?php esc_html_e( 'Total Messages', 'zymarg-communication' ); ?></div>
				<div class="zcm-card-num"><?php echo esc_html( number_format_i18n( $total_messages ) ); ?></div>
				<div class="zcm-card-sub"><?php echo esc_html( number_format_i18n( $today_messages ) ); ?> <?php esc_html_e( 'today', 'zymarg-communication' ); ?></div>
			</div>
			<div class="zcm-card">
				<div class="zcm-card-label"><?php esc_html_e( 'Pending Moderation', 'zymarg-communication' ); ?></div>
				<div class="zcm-card-num" style="color:<?php echo $pending_mod > 0 ? 'var(--zc-color-warning)' : 'var(--zc-color-ink)'; ?>"><?php echo esc_html( number_format_i18n( $pending_mod ) ); ?></div>
				<?php if ( $pending_mod > 0 ) : ?>
				<div class="zcm-card-sub"><a href="<?php echo esc_url( $mod_url ); ?>"><?php esc_html_e( 'View queue', 'zymarg-communication' ); ?></a></div>
				<?php endif; ?>
			</div>
			<div class="zcm-card">
				<div class="zcm-card-label"><?php esc_html_e( 'Feature Flags', 'zymarg-communication' ); ?></div>
				<div class="zcm-card-num"><?php echo esc_html( $enabled_flags ); ?><span style="font-size:18px;color:var(--zc-color-neutral-text);"> / <?php echo esc_html( $total_flags ); ?></span></div>
				<div class="zcm-card-sub"><?php esc_html_e( 'enabled', 'zymarg-communication' ); ?></div>
			</div>
			<div class="zcm-card">
				<div class="zcm-card-label"><?php esc_html_e( 'Unread Messages', 'zymarg-communication' ); ?></div>
				<div class="zcm-card-num"><?php echo esc_html( number_format_i18n( $unread_messages ) ); ?></div>
				<div class="zcm-card-sub"><?php esc_html_e( 'delivered, not read', 'zymarg-communication' ); ?></div>
			</div>
			<div class="zcm-card">
				<div class="zcm-card-label"><?php esc_html_e( 'Active Users', 'zymarg-communication' ); ?></div>
				<div class="zcm-card-num" style="color:<?php echo $active_users > 0 ? 'var(--zc-color-success)' : 'var(--zc-color-ink)'; ?>"><?php echo esc_html( number_format_i18n( $active_users ) ); ?></div>
				<div class="zcm-card-sub"><?php esc_html_e( 'online now', 'zymarg-communication' ); ?></div>
			</div>
		</div>

		<!-- System status -->
		<div class="zcm-section-title"><?php esc_html_e( 'System Status', 'zymarg-communication' ); ?></div>
		<table class="widefat striped" style="max-width:600px;">
			<tbody>
				<tr>
					<td style="width:180px;font-weight:600;"><?php esc_html_e( 'Plugin version', 'zymarg-communication' ); ?></td>
					<td><code><?php echo esc_html( ZYMARG_COMM_VERSION ); ?></code></td>
				</tr>
				<tr>
					<td style="font-weight:600;"><?php esc_html_e( 'PHP version', 'zymarg-communication' ); ?></td>
					<td><code><?php echo esc_html( PHP_VERSION ); ?></code></td>
				</tr>
				<tr>
					<td style="font-weight:600;"><?php esc_html_e( 'WordPress version', 'zymarg-communication' ); ?></td>
					<td><code><?php echo esc_html( get_bloginfo( 'version' ) ); ?></code></td>
				</tr>
				<tr>
					<td style="font-weight:600;"><?php esc_html_e( 'Pusher credentials', 'zymarg-communication' ); ?></td>
					<td>
						<?php if ( $pusher_configured ) : ?>
						<span class="zcm-status zcm-status-ok">&#10003; <?php esc_html_e( 'Configured', 'zymarg-communication' ); ?> &mdash; <?php echo esc_html( $pusher_cluster ); ?></span>
						<?php else : ?>
						<span class="zcm-status zcm-status-warn">&#9888; <?php esc_html_e( 'Not configured', 'zymarg-communication' ); ?></span>
						<a href="<?php echo esc_url( $settings_url . '&tab=realtime' ); ?>" style="margin-left:8px;font-size:12px;"><?php esc_html_e( 'Configure now', 'zymarg-communication' ); ?></a>
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<td style="font-weight:600;"><?php esc_html_e( 'OpenSSL encryption', 'zymarg-communication' ); ?></td>
					<td>
						<?php if ( extension_loaded( 'openssl' ) ) : ?>
						<span class="zcm-status zcm-status-ok">&#10003; <?php esc_html_e( 'Available', 'zymarg-communication' ); ?></span>
						<?php else : ?>
						<span class="zcm-status zcm-status-warn">&#9888; <?php esc_html_e( 'Not available', 'zymarg-communication' ); ?></span>
						<?php endif; ?>
					</td>
				</tr>
			</tbody>
		</table>

		<!-- Quick actions -->
		<div class="zcm-section-title"><?php esc_html_e( 'Quick Actions', 'zymarg-communication' ); ?></div>
		<div class="zcm-actions">
			<a href="<?php echo esc_url( $settings_url ); ?>" class="button button-primary">
				<span class="dashicons dashicons-admin-settings" style="margin-top:3px;"></span>
				<?php esc_html_e( 'Settings', 'zymarg-communication' ); ?>
			</a>
			<a href="<?php echo esc_url( $settings_url . '&tab=realtime' ); ?>" class="button button-secondary">
				<span class="dashicons dashicons-rss" style="margin-top:3px;"></span>
				<?php esc_html_e( 'Pusher Settings', 'zymarg-communication' ); ?>
			</a>
			<a href="<?php echo esc_url( $settings_url . '&tab=flags' ); ?>" class="button button-secondary">
				<span class="dashicons dashicons-flag" style="margin-top:3px;"></span>
				<?php esc_html_e( 'Feature Flags', 'zymarg-communication' ); ?>
			</a>
			<a href="<?php echo esc_url( $help_url ); ?>" class="button button-secondary">
				<span class="dashicons dashicons-book" style="margin-top:3px;"></span>
				<?php esc_html_e( 'Help & Docs', 'zymarg-communication' ); ?>
			</a>
		</div>
		</div>
		<?php
	}

	/**
	 * Renders the shared ZYMARG brand header.
	 *
	 * @since 1.15.0
	 * @param string $title    Wordmark text.
	 * @param string $subtitle Section description.
	 */
	public static function renderHeader( string $title, string $subtitle = '' ): void {
		?>
		<div class="zcm-header">
			<div class="zcm-header-inner">
				<div class="zcm-header-left">
					<span class="zcm-logo-spark"><span class="zymarg-spark"><svg class="zymarg-spark__svg" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="ZYMARG Discovery Spark" focusable="false"><g class="zymarg-spark-group--accent"><path class="zymarg-spark-item--purple" d="M10.4 5.4c0 1.32-0.24 2.4-1.44 2.4 1.2 0 1.44 1.08 1.44 2.4 0-1.32 0.24-2.4 1.44-2.4-1.2 0-1.44-1.08-1.44-2.4z"/><path class="zymarg-spark-item--gold" d="M10.4 6.0c0 0.96-0.18 1.8-1.08 1.8 0.9 0 1.08 0.84 1.08 1.8 0-0.9 0.18-1.8 1.08-1.8-0.9 0-1.08-0.84-1.08-1.8z"/></g><g class="zymarg-spark-group--companion"><path class="zymarg-spark-item--purple" d="M9.5 10.92c0 2.25-0.45 4.12-2.4 4.12 1.95 0 2.4 1.87 2.4 4.12 0-2.25 0.45-4.12 2.4-4.12-1.95 0-2.4-1.87-2.4-4.12z"/><path class="zymarg-spark-item--gold" d="M9.5 11.5c0 1.9-0.38 3.54-2.0 3.54 1.62 0 2.0 1.64 2.0 3.54 0-1.9 0.38-3.54 2.0-3.54-1.62 0-2.0-1.64-2.0-3.54z"/></g><g class="zymarg-spark-group--hero"><path class="zymarg-spark-item--purple" d="M15.2 5.6c0 3.45-0.69 6.3-4.08 6.3 3.39 0 4.08 2.85 4.08 6.3 0-3.45 0.69-6.3 4.08-6.3-3.39 0-4.08-2.85-4.08-6.3z"/><path class="zymarg-spark-item--gold" d="M15.2 6.5c0 2.9-0.58 5.4-3.39 5.4 2.81 0 3.39 2.5 3.39 5.4 0-2.9 0.58-5.4 3.39-5.4-2.81 0-3.39-2.5-3.39-5.4z"/></g></svg></span></span>
					<div class="zcm-header-titles">
						<h1 class="zcm-header-title"><?php echo esc_html( $title ); ?></h1>
						<?php if ( '' !== $subtitle ) : ?>
						<p class="zcm-header-sub"><?php echo esc_html( $subtitle ); ?></p>
						<?php endif; ?>
					</div>
				</div>
				<span class="zcm-version-badge">v<?php echo esc_html( ZYMARG_COMM_VERSION ); ?></span>
			</div>
		</div>
		<?php
	}

	public static function enqueueAssets( string $hook = '' ): void {
		$page      = isset( $_GET['page'] ) ? sanitize_key( (string) wp_unslash( $_GET['page'] ) ) : '';
		$our_pages = array( self::MENU_SLUG, 'zymarg-comm-settings', 'zymarg-communication-help', 'zymarg-comm-conversations', 'zymarg-comm-moderation', 'zymarg-comm-analytics', 'zymarg-comm-support' );
		if ( ! in_array( $page, $our_pages, true ) ) {
			return;
		}
		wp_enqueue_style(
			'zymarg-comm-tokens',
			ZYMARG_COMM_ASSETS_URL . 'css/frontend/zymarg-comm-tokens.css',
			array(),
			ZYMARG_COMM_VERSION
		);
		wp_enqueue_style(
			'zymarg-comm-spark',
			ZYMARG_COMM_ASSETS_URL . 'css/admin/spark.css',
			array( 'zymarg-comm-tokens' ),
			ZYMARG_COMM_VERSION
		);
		wp_enqueue_style(
			'zymarg-comm-admin',
			ZYMARG_COMM_ASSETS_URL . 'css/admin/admin.css',
			array( 'zymarg-comm-tokens', 'zymarg-comm-spark' ),
			ZYMARG_COMM_VERSION
		);
		wp_enqueue_script(
			'zymarg-comm-admin',
			ZYMARG_COMM_ASSETS_URL . 'js/admin/admin.js',
			array(),
			ZYMARG_COMM_VERSION,
			true
		);
	}
}
