<?php
/**
 * ZYMARG Communication - WP-Cron scheduler.
 *
 * The ONLY file that registers WP-Cron hooks. Placeholder callbacks are wired
 * here so activation and deactivation cleanly own their schedules.
 *
 * @package    ZymargCommunication
 * @version    1.24.0
 */

namespace ZymargCommunication\Bootstrap;

use ZymargCommunication\Modules\Analytics\Services\UserPerformanceService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Scheduler {

	public const HOOK_MESSAGE_LIFECYCLE = 'zymarg_comm_run_message_lifecycle';
	public const HOOK_USER_PERFORMANCE  = 'zymarg_comm_build_user_performance';
	public const HOOK_SUPPORT_ESCALATION = 'zymarg_comm_support_escalation_scan';
	public const SCHEDULE_SIX_HOURS     = 'zymarg_comm_six_hours';

	public static function register(): void {
		add_filter( 'cron_schedules', array( __CLASS__, 'addSchedules' ) );

		add_action( self::HOOK_MESSAGE_LIFECYCLE, array( __CLASS__, 'runMessageLifecycle' ) );
		add_action( self::HOOK_USER_PERFORMANCE, array( UserPerformanceService::class, 'rebuildScheduled' ) );

		if ( ! wp_next_scheduled( self::HOOK_MESSAGE_LIFECYCLE ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::HOOK_MESSAGE_LIFECYCLE );
		}

		// Support no-reply escalation (1.27.0). Hourly so a 2h window is caught
		// promptly; SupportTicketService::runEscalationScan is a no-op when the
		// support feature is off, so an idle site pays nothing.
		if ( ! wp_next_scheduled( self::HOOK_SUPPORT_ESCALATION ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'hourly', self::HOOK_SUPPORT_ESCALATION );
		}

		self::syncUserPerformance();
	}

	/**
	 * Register the 6-hour interval WordPress does not ship with.
	 *
	 * @param array<string,array{interval:int,display:string}> $schedules
	 * @return array<string,array{interval:int,display:string}>
	 */
	public static function addSchedules( $schedules ) {
		$schedules = is_array( $schedules ) ? $schedules : array();
		$schedules[ self::SCHEDULE_SIX_HOURS ] = array(
			'interval' => 6 * HOUR_IN_SECONDS,
			'display'  => __( 'Every 6 hours', 'zymarg-communication' ),
		);
		return $schedules;
	}

	/**
	 * Make the live schedule match the admin setting. Safe to call on every
	 * request: it only touches WP-Cron when the setting has actually changed.
	 */
	public static function syncUserPerformance(): void {
		$wanted = UserPerformanceService::interval();
		$recurrence = match ( $wanted ) {
			'hourly'     => 'hourly',
			'twicedaily' => 'twicedaily',
			'sixhours'   => self::SCHEDULE_SIX_HOURS,
			'daily'      => 'daily',
			default      => '',
		};

		$next    = wp_next_scheduled( self::HOOK_USER_PERFORMANCE );
		$current = $next ? (string) wp_get_schedule( self::HOOK_USER_PERFORMANCE ) : '';

		if ( '' === $recurrence ) {
			if ( $next ) {
				wp_clear_scheduled_hook( self::HOOK_USER_PERFORMANCE );
			}
			return;
		}

		if ( $current === $recurrence ) {
			return;
		}

		if ( $next ) {
			wp_clear_scheduled_hook( self::HOOK_USER_PERFORMANCE );
		}
		wp_schedule_event( time() + ( 10 * MINUTE_IN_SECONDS ), $recurrence, self::HOOK_USER_PERFORMANCE );
	}

	/**
	 * Clear every schedule this plugin registers. Called on deactivation.
	 */
	public static function clear(): void {
		$timestamp = wp_next_scheduled( self::HOOK_MESSAGE_LIFECYCLE );
		if ( $timestamp ) {
			wp_unschedule_event( $timestamp, self::HOOK_MESSAGE_LIFECYCLE );
		}
		wp_clear_scheduled_hook( self::HOOK_MESSAGE_LIFECYCLE );
		wp_clear_scheduled_hook( self::HOOK_USER_PERFORMANCE );
		wp_clear_scheduled_hook( self::HOOK_SUPPORT_ESCALATION );
	}

	/**
	 * Placeholder - real archive/delete logic is delegated to
	 * MessageLifecycleService in Phase 8.
	 */
	public static function runMessageLifecycle(): void {
		do_action( 'zymarg_comm_message_lifecycle_tick' );
	}
}
