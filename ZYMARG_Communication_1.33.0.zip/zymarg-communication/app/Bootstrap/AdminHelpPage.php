<?php
/**
 * AdminHelpPage — Fully AJAX Help & Documentation admin page.
 * Section switching loads content without any page reload.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Bootstrap;

use ZymargCommunication\Modules\HelpCenter\Services\ChangelogService;
use ZymargCommunication\Modules\HelpCenter\Services\DocumentationService;
use ZymargCommunication\Modules\HelpCenter\Services\HelpCenterService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdminHelpPage {

	private static bool $registered = false;
	public const MENU_SLUG          = 'zymarg-communication-help';
	private const NONCE_ACTION      = 'zymarg_comm_help_load';

	public static function register(): void {
		if ( self::$registered ) return;
		self::$registered = true;
		add_action( 'admin_menu',                          array( self::class, 'registerMenu' ), 30 );
		add_action( 'wp_ajax_zymarg_comm_load_help_section', array( self::class, 'handleLoadSection' ) );
	}

	public static function registerMenu(): void {
		add_submenu_page(
			AdminMenu::MENU_SLUG,
			__( 'Help & Docs', 'zymarg-communication' ),
			__( 'Help & Docs', 'zymarg-communication' ),
			'manage_options',
			self::MENU_SLUG,
			array( self::class, 'render' )
		);
	}

	// =========================================================================
	// Shell — tabs are buttons; content loaded via AJAX
	// =========================================================================

	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) return;
		$section  = isset( $_GET['section'] ) ? sanitize_key( (string) wp_unslash( $_GET['section'] ) ) : 'user-guide';
		$sections = self::sections();
		if ( ! array_key_exists( $section, $sections ) ) $section = 'user-guide';
		$nonce    = wp_create_nonce( self::NONCE_ACTION );
		$ajax_url = admin_url( 'admin-ajax.php' );
		?>
		<div class="wrap zymarg-comm-help">
			<?php AdminMenu::renderHeader( __( 'ZYMARG Communication', 'zymarg-communication' ), __( 'Help & Documentation — Guides, changelog and developer reference', 'zymarg-communication' ) ); ?>

			<div id="zcm-help-nav" style="display:flex;flex-wrap:wrap;gap:4px;margin:16px 0;border-bottom:1px solid var(--zc-color-divider);padding-bottom:0;">
				<?php foreach ( $sections as $key => $label ) : ?>
				<button type="button"
					class="nav-tab zcm-help-btn<?php echo $key === $section ? ' nav-tab-active' : ''; ?>"
					data-section="<?php echo esc_attr( $key ); ?>"
					style="margin-bottom:-1px;">
					<?php echo esc_html( $label ); ?>
				</button>
				<?php endforeach; ?>
			</div>

			<div id="zcm-help-content" class="zymarg-comm-help-body" style="max-width:900px;margin-top:20px;">
				<div class="zymarg-loading" role="status" aria-live="polite"><span class="zymarg-spark zymarg-spark--md"><svg class="zymarg-spark__svg" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="ZYMARG Discovery Spark" focusable="false"><g class="zymarg-spark-group--accent"><path class="zymarg-spark-item--purple" d="M10.4 5.4c0 1.32-0.24 2.4-1.44 2.4 1.2 0 1.44 1.08 1.44 2.4 0-1.32 0.24-2.4 1.44-2.4-1.2 0-1.44-1.08-1.44-2.4z"/><path class="zymarg-spark-item--gold" d="M10.4 6.0c0 0.96-0.18 1.8-1.08 1.8 0.9 0 1.08 0.84 1.08 1.8 0-0.9 0.18-1.8 1.08-1.8-0.9 0-1.08-0.84-1.08-1.8z"/></g><g class="zymarg-spark-group--companion"><path class="zymarg-spark-item--purple" d="M9.5 10.92c0 2.25-0.45 4.12-2.4 4.12 1.95 0 2.4 1.87 2.4 4.12 0-2.25 0.45-4.12 2.4-4.12-1.95 0-2.4-1.87-2.4-4.12z"/><path class="zymarg-spark-item--gold" d="M9.5 11.5c0 1.9-0.38 3.54-2.0 3.54 1.62 0 2.0 1.64 2.0 3.54 0-1.9 0.38-3.54 2.0-3.54-1.62 0-2.0-1.64-2.0-3.54z"/></g><g class="zymarg-spark-group--hero"><path class="zymarg-spark-item--purple" d="M15.2 5.6c0 3.45-0.69 6.3-4.08 6.3 3.39 0 4.08 2.85 4.08 6.3 0-3.45 0.69-6.3 4.08-6.3-3.39 0-4.08-2.85-4.08-6.3z"/><path class="zymarg-spark-item--gold" d="M15.2 6.5c0 2.9-0.58 5.4-3.39 5.4 2.81 0 3.39 2.5 3.39 5.4 0-2.9 0.58-5.4 3.39-5.4-2.81 0-3.39-2.5-3.39-5.4z"/></g></svg></span><span class="zymarg-loading__text"><?php esc_html_e( 'Loading...', 'zymarg-communication' ); ?></span></div>
			</div>
		</div>

		<style>
		.zymarg-comm-help-md h2{font-size:1.3em;margin-top:24px;}
		.zymarg-comm-help-md h3{font-size:1.1em;margin-top:18px;}
		.zymarg-comm-help-md pre{background:var(--zc-color-surface);padding:12px;border-radius:4px;overflow:auto;}
		.zymarg-comm-help-md code{background:var(--zc-color-neutral-bg);padding:1px 4px;border-radius:3px;font-size:13px;}
		.zymarg-comm-help-md ul,.zymarg-comm-help-md ol{padding-left:24px;}
		.zcm-help-btn{background:none;border:1px solid transparent;border-bottom:none;cursor:pointer;}
		.zcm-help-btn:focus{box-shadow:none;outline:2px solid var(--zc-color-primary);outline-offset:2px;}
		</style>

		<script>
		(function(){
			var AJAX    = <?php echo wp_json_encode( $ajax_url ); ?>;
			var NONCE   = <?php echo wp_json_encode( $nonce ); ?>;
			var current = <?php echo wp_json_encode( $section ); ?>;

			function loadSection(sec) {
				var box = document.getElementById('zcm-help-content');
				box.innerHTML = '<div class="zymarg-loading" role="status" aria-live="polite"><span class="zymarg-spark zymarg-spark--md"><svg class="zymarg-spark__svg" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="ZYMARG Discovery Spark" focusable="false"><g class="zymarg-spark-group--accent"><path class="zymarg-spark-item--purple" d="M10.4 5.4c0 1.32-0.24 2.4-1.44 2.4 1.2 0 1.44 1.08 1.44 2.4 0-1.32 0.24-2.4 1.44-2.4-1.2 0-1.44-1.08-1.44-2.4z"/><path class="zymarg-spark-item--gold" d="M10.4 6.0c0 0.96-0.18 1.8-1.08 1.8 0.9 0 1.08 0.84 1.08 1.8 0-0.9 0.18-1.8 1.08-1.8-0.9 0-1.08-0.84-1.08-1.8z"/></g><g class="zymarg-spark-group--companion"><path class="zymarg-spark-item--purple" d="M9.5 10.92c0 2.25-0.45 4.12-2.4 4.12 1.95 0 2.4 1.87 2.4 4.12 0-2.25 0.45-4.12 2.4-4.12-1.95 0-2.4-1.87-2.4-4.12z"/><path class="zymarg-spark-item--gold" d="M9.5 11.5c0 1.9-0.38 3.54-2.0 3.54 1.62 0 2.0 1.64 2.0 3.54 0-1.9 0.38-3.54 2.0-3.54-1.62 0-2.0-1.64-2.0-3.54z"/></g><g class="zymarg-spark-group--hero"><path class="zymarg-spark-item--purple" d="M15.2 5.6c0 3.45-0.69 6.3-4.08 6.3 3.39 0 4.08 2.85 4.08 6.3 0-3.45 0.69-6.3 4.08-6.3-3.39 0-4.08-2.85-4.08-6.3z"/><path class="zymarg-spark-item--gold" d="M15.2 6.5c0 2.9-0.58 5.4-3.39 5.4 2.81 0 3.39 2.5 3.39 5.4 0-2.9 0.58-5.4 3.39-5.4-2.81 0-3.39-2.5-3.39-5.4z"/></g></svg></span><span class="zymarg-loading__text">Loading...</span></div>';
				document.querySelectorAll('.zcm-help-btn').forEach(function(b){
					b.classList.toggle('nav-tab-active', b.dataset.section === sec);
				});
				var d = new URLSearchParams();
				d.append('action',   'zymarg_comm_load_help_section');
				d.append('section',  sec);
				d.append('_wpnonce', NONCE);
				fetch(AJAX, {method:'POST', body:d})
					.then(function(r){ return r.json(); })
					.then(function(res){
						if (res.success) {
							box.innerHTML = res.data.html;
							history.replaceState(null,'',location.pathname+'?page=zymarg-communication-help&section='+sec);
						} else {
							box.innerHTML = '<p style="color:var(--zc-color-danger);">Failed to load section.</p>';
						}
					})
					.catch(function(e){
						box.innerHTML = '<p style="color:var(--zc-color-danger);">Error: '+e.message+'</p>';
					});
			}

			document.querySelectorAll('.zcm-help-btn').forEach(function(btn){
				btn.addEventListener('click', function(){ loadSection(this.dataset.section); });
			});

			loadSection(current);
		})();
		</script>
		<?php
	}

	// =========================================================================
	// AJAX: return section HTML
	// =========================================================================

	public static function handleLoadSection(): void {
		check_ajax_referer( self::NONCE_ACTION );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Forbidden' ), 403 );
		}
		$section  = isset( $_POST['section'] ) ? sanitize_key( (string) wp_unslash( $_POST['section'] ) ) : 'user-guide';
		$sections = self::sections();
		if ( ! array_key_exists( $section, $sections ) ) $section = 'user-guide';
		ob_start();
		self::renderSection( $section );
		wp_send_json_success( array( 'html' => ob_get_clean(), 'section' => $section ) );
	}

	// =========================================================================
	// Section registry
	// =========================================================================

	/** @return array<string,string> */
	private static function sections(): array {
		return array(
			'user-guide'      => __( 'User Guide',         'zymarg-communication' ),
			'admin-guide'     => __( 'Admin Guide',        'zymarg-communication' ),
			'rest-api'        => __( 'REST API',           'zymarg-communication' ),
			'php-api'         => __( 'PHP API',            'zymarg-communication' ),
			'js-sdk'          => __( 'JS SDK',             'zymarg-communication' ),
			'hooks'           => __( 'Hooks & Filters',    'zymarg-communication' ),
			'sdk'             => __( 'Extension SDK',      'zymarg-communication' ),
			'mobile'          => __( 'Mobile Integration', 'zymarg-communication' ),
			'troubleshooting' => __( 'Troubleshooting',    'zymarg-communication' ),
			'changelog'       => __( 'Changelog',          'zymarg-communication' ),
		);
	}

	// =========================================================================
	// Section renderers
	// =========================================================================

	private static function renderSection( string $section ): void {
		echo '<div class="zymarg-comm-help-md">';
		try {
			switch ( $section ) {
				case 'user-guide':
				case 'admin-guide':
					$service  = ServiceProvider::get( HelpCenterService::class );
					$audience = 'admin-guide' === $section ? 'admin' : 'user';
					$data     = $service instanceof HelpCenterService ? $service->guide( $audience ) : array( 'sections' => array() );
					self::renderMarkdownSections( (array) ( $data['sections'] ?? array() ) );
					break;

				case 'troubleshooting':
					$service = ServiceProvider::get( HelpCenterService::class );
					$data    = $service instanceof HelpCenterService ? $service->troubleshooting() : array( 'sections' => array() );
					self::renderMarkdownSections( (array) ( $data['sections'] ?? array() ) );
					break;

				case 'rest-api':
				case 'php-api':
				case 'js-sdk':
				case 'hooks':
				case 'sdk':
				case 'mobile':
					$topic_map = array( 'rest-api'=>'rest','php-api'=>'php','js-sdk'=>'js','hooks'=>'hooks','sdk'=>'sdk','mobile'=>'mobile' );
					$service   = ServiceProvider::get( DocumentationService::class );
					$data      = $service instanceof DocumentationService ? $service->topic( $topic_map[$section] ) : array( 'title'=>'','body'=>'' );
					self::renderMarkdownSections( array( array( 'slug'=>$section, 'title'=>(string)($data['title']??''), 'body'=>(string)($data['body']??'') ) ) );
					break;

				case 'changelog':
					$service = ServiceProvider::get( ChangelogService::class );
					$entries = $service instanceof ChangelogService ? $service->entries( 50 ) : array();
					self::renderChangelog( $entries );
					break;
			}
		} catch ( \Throwable $e ) {
			echo '<p><em>' . esc_html__( 'Documentation is not available.', 'zymarg-communication' ) . '</em></p>';
		}
		echo '</div>';
	}

	/** @param array<int,array{slug?:string,title?:string,body?:string}> $sections */
	private static function renderMarkdownSections( array $sections ): void {
		if ( empty( $sections ) ) {
			echo '<p><em>' . esc_html__( 'No content available yet.', 'zymarg-communication' ) . '</em></p>';
			return;
		}
		foreach ( $sections as $entry ) {
			$title = (string) ( $entry['title'] ?? '' );
			$body  = (string) ( $entry['body'] ?? '' );
			if ( '' !== $title ) echo '<h2>' . esc_html( $title ) . '</h2>';
			echo self::renderMarkdown( $body );
		}
	}

	/** @param array<int,array{version?:string,notes?:array<int,string>}> $entries */
	private static function renderChangelog( array $entries ): void {
		if ( empty( $entries ) ) {
			echo '<p><em>' . esc_html__( 'The changelog is empty.', 'zymarg-communication' ) . '</em></p>';
			return;
		}
		foreach ( $entries as $entry ) {
			echo '<h3>' . esc_html( (string) ( $entry['version'] ?? '' ) ) . '</h3><ul>';
			foreach ( (array) ( $entry['notes'] ?? array() ) as $note ) {
				echo '<li>' . esc_html( (string) $note ) . '</li>';
			}
			echo '</ul>';
		}
	}

	private static function renderMarkdown( string $md ): string {
		if ( '' === $md ) return '<p><em>' . esc_html__( 'No content available.', 'zymarg-communication' ) . '</em></p>';
		$lines = preg_split( '/\r?\n/', $md ) ?: array();
		$html  = ''; $inUl = false; $inOl = false; $inPre = false;
		foreach ( $lines as $line ) {
			if ( 0 === strpos( $line, '```' ) ) {
				if ( $inUl ) { $html .= '</ul>'; $inUl = false; }
				if ( $inOl ) { $html .= '</ol>'; $inOl = false; }
				if ( ! $inPre ) { $html .= '<pre><code>'; $inPre = true; } else { $html .= '</code></pre>'; $inPre = false; }
				continue;
			}
			if ( $inPre ) { $html .= esc_html( $line ) . "\n"; continue; }
			if ( preg_match( '/^(#{1,6})\s+(.+)$/', $line, $m ) ) {
				if ( $inUl ) { $html .= '</ul>'; $inUl = false; } if ( $inOl ) { $html .= '</ol>'; $inOl = false; }
				$lvl = min( 6, strlen( $m[1] ) + 1 );
				$html .= sprintf( '<h%1$d>%2$s</h%1$d>', $lvl, self::inline( $m[2] ) ); continue;
			}
			if ( preg_match( '/^\s*-\s+(.+)$/', $line, $m ) ) {
				if ( $inOl ) { $html .= '</ol>'; $inOl = false; } if ( ! $inUl ) { $html .= '<ul>'; $inUl = true; }
				$html .= '<li>' . self::inline( $m[1] ) . '</li>'; continue;
			}
			if ( preg_match( '/^\s*\d+\.\s+(.+)$/', $line, $m ) ) {
				if ( $inUl ) { $html .= '</ul>'; $inUl = false; } if ( ! $inOl ) { $html .= '<ol>'; $inOl = true; }
				$html .= '<li>' . self::inline( $m[1] ) . '</li>'; continue;
			}
			if ( '' === trim( $line ) ) {
				if ( $inUl ) { $html .= '</ul>'; $inUl = false; } if ( $inOl ) { $html .= '</ol>'; $inOl = false; }
				continue;
			}
			$html .= '<p>' . self::inline( $line ) . '</p>';
		}
		if ( $inUl ) $html .= '</ul>'; if ( $inOl ) $html .= '</ol>'; if ( $inPre ) $html .= '</code></pre>';
		return $html;
	}

	private static function inline( string $text ): string {
		$e = esc_html( $text );
		$e = preg_replace( '/`([^`]+)`/', '<code>$1</code>', $e );
		$e = preg_replace( '/\*\*([^*]+)\*\*/', '<strong>$1</strong>', $e );
		$e = preg_replace_callback( '/\[([^\]]+)\]\(([^)]+)\)/', static function($m){ return '<a href="'.esc_url(filter_var($m[2],FILTER_SANITIZE_URL)).'" target="_blank" rel="noopener">'.$m[1].'</a>'; }, $e );
		return (string) $e;
	}
}
