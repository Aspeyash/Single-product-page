<?php
/**
 * ZYMARG Communication — Service container.
 *
 * A tiny dependency container. Phase 6 adds Security, Moderation, and
 * Settings registrations, and wires SecurityService into AttachmentService
 * and the moderation services into MessageService.
 *
 * @package    ZymargCommunication
 * @version    1.6.0
 */

namespace ZymargCommunication\Bootstrap;

use ZymargCommunication\Modules\Developer\Controllers\DeveloperController;
use ZymargCommunication\Modules\Developer\Repositories\DeveloperRepository;
use ZymargCommunication\Modules\Developer\Services\ApiKeyService;
use ZymargCommunication\Modules\Developer\Services\ExtensionService;
use ZymargCommunication\Modules\Developer\Services\WebhookService;
use ZymargCommunication\Modules\HelpCenter\Controllers\HelpCenterController;
use ZymargCommunication\Modules\HelpCenter\Repositories\HelpCenterRepository;
use ZymargCommunication\Modules\HelpCenter\Services\ChangelogService;
use ZymargCommunication\Modules\HelpCenter\Services\DocumentationService;
use ZymargCommunication\Modules\HelpCenter\Services\FaqService;
use ZymargCommunication\Modules\HelpCenter\Services\HelpCenterService;
use ZymargCommunication\Modules\Analytics\Controllers\AnalyticsController;
use ZymargCommunication\Modules\Analytics\Repositories\AnalyticsRepository;
use ZymargCommunication\Modules\Analytics\Services\AdminReportService;
use ZymargCommunication\Modules\Analytics\Services\AnalyticsService;
use ZymargCommunication\Modules\Analytics\Services\ReportService;
use ZymargCommunication\Modules\Analytics\Services\UserReportService;
use ZymargCommunication\Core\Contracts\RealtimeDriverInterface;
use ZymargCommunication\Modules\Conversation\Controllers\ConversationController;
use ZymargCommunication\Modules\Conversation\Repositories\ConversationRepository;
use ZymargCommunication\Modules\Conversation\Repositories\ParticipantRepository;
use ZymargCommunication\Modules\Conversation\Services\ConversationPermissionService;
use ZymargCommunication\Modules\Conversation\Services\ConversationService;
use ZymargCommunication\Modules\Conversation\Services\ParticipantService;
use ZymargCommunication\Modules\FeatureFlags\Controllers\FeatureFlagController;
use ZymargCommunication\Modules\FeatureFlags\Repositories\FeatureFlagRepository;
use ZymargCommunication\Modules\FeatureFlags\Services\FeatureFlagCacheService;
use ZymargCommunication\Modules\FeatureFlags\Services\FeatureFlagService;
use ZymargCommunication\Modules\Marketplace\Controllers\MarketplaceController;
use ZymargCommunication\Modules\Marketplace\Repositories\MarketplaceRepository;
use ZymargCommunication\Modules\Marketplace\Services\BuyerInboxService;
use ZymargCommunication\Modules\Marketplace\Services\OrderChatService;
use ZymargCommunication\Modules\Marketplace\Services\ProductSharingService;
use ZymargCommunication\Modules\Marketplace\Services\StoreChatService;
use ZymargCommunication\Modules\Marketplace\Services\StorePopupService;
use ZymargCommunication\Modules\Marketplace\Services\VendorInboxService;
use ZymargCommunication\Modules\Support\Controllers\SupportController;
use ZymargCommunication\Modules\Support\Repositories\SupportRepository;
use ZymargCommunication\Modules\Support\Repositories\SupportTicketRepository;
use ZymargCommunication\Modules\Support\Services\SupportService;
use ZymargCommunication\Modules\Support\Services\SupportTicketService;
use ZymargCommunication\Modules\Message\Controllers\AttachmentController;
use ZymargCommunication\Modules\Message\Controllers\MessageController;
use ZymargCommunication\Modules\Message\Repositories\AttachmentRepository;
use ZymargCommunication\Modules\Message\Repositories\MessageRepository;
use ZymargCommunication\Modules\Message\Repositories\ReactionRepository;
use ZymargCommunication\Modules\Message\Services\AttachmentService;
use ZymargCommunication\Modules\Message\Services\MessageService;
use ZymargCommunication\Modules\Message\Services\ReactionService;
use ZymargCommunication\Modules\Message\Services\ReadReceiptService;
use ZymargCommunication\Modules\Moderation\Controllers\ModerationController;
use ZymargCommunication\Modules\Moderation\Repositories\ModerationRepository;
use ZymargCommunication\Modules\Moderation\Services\AdminViewService;
use ZymargCommunication\Modules\Moderation\Services\BlocklistService;
use ZymargCommunication\Modules\Moderation\Services\ModerationService;
use ZymargCommunication\Modules\Moderation\Services\SpamFilterService;
use ZymargCommunication\Modules\Notification\Controllers\NotificationController;
use ZymargCommunication\Modules\Notification\Repositories\NotificationRepository;
use ZymargCommunication\Modules\Notification\Services\BrowserNotificationService;
use ZymargCommunication\Modules\Notification\Services\EmailNotificationService;
use ZymargCommunication\Modules\Notification\Services\NotificationPreferenceService;
use ZymargCommunication\Modules\Notification\Services\NotificationService;
use ZymargCommunication\Modules\Notification\Services\PushNotificationService;
use ZymargCommunication\Modules\Realtime\Controllers\RealtimeController;
use ZymargCommunication\Modules\Realtime\Repositories\RealtimeRepository;
use ZymargCommunication\Modules\Realtime\Services\PollingService;
use ZymargCommunication\Modules\Realtime\Services\PresenceService;
use ZymargCommunication\Modules\Realtime\Services\PusherService;
use ZymargCommunication\Modules\Realtime\Services\QueueService;
use ZymargCommunication\Modules\Realtime\Services\SseService;
use ZymargCommunication\Modules\Realtime\Services\WebSocketService;
use ZymargCommunication\Modules\Security\Controllers\SecurityController;
use ZymargCommunication\Modules\Security\Repositories\SecurityRepository;
use ZymargCommunication\Modules\Security\Services\AuditLogService;
use ZymargCommunication\Modules\Security\Services\EncryptionService;
use ZymargCommunication\Modules\Security\Services\ExifStripService;
use ZymargCommunication\Modules\Security\Services\FileStorageService;
use ZymargCommunication\Modules\Security\Services\FileValidationService;
use ZymargCommunication\Modules\Security\Services\SecurityService;
use ZymargCommunication\Modules\Settings\Controllers\SettingsController;
use ZymargCommunication\Modules\Settings\Repositories\SettingsRepository;
use ZymargCommunication\Modules\Settings\Services\SettingsService;
use ZymargCommunication\Shared\Events\EventDispatcher;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ServiceProvider {

	/** @var array<string, callable> */
	private static array $factories = [];

	/** @var array<string, mixed> */
	private static array $singletons = [];

	public static function register(): void {
		self::registerShared();
		self::registerFeatureFlags();
		self::registerSecurity();
		self::registerConversation();
		self::registerMessage();
		self::registerModeration();
		self::registerRealtime();
		self::registerMarketplace();
		self::registerSupport();
		self::registerNotification();
		self::registerAnalytics();
		self::registerHelpCenter();
		self::registerDeveloper();
		self::registerSettings();

		do_action( 'zymarg_comm_service_provider_register' );
	}

	private static function registerShared(): void {
		self::singleton( EventDispatcher::class, static fn () => new EventDispatcher() );
	}

	private static function registerFeatureFlags(): void {
		self::singleton( FeatureFlagRepository::class, static fn () => new FeatureFlagRepository() );
		self::singleton( FeatureFlagCacheService::class, static fn () => new FeatureFlagCacheService() );
		self::singleton(
			FeatureFlagService::class,
			static fn () => new FeatureFlagService(
				self::get( FeatureFlagRepository::class ),
				self::get( FeatureFlagCacheService::class )
			)
		);
		self::singleton(
			FeatureFlagController::class,
			static fn () => new FeatureFlagController(
				self::get( FeatureFlagService::class )
			)
		);
	}

	private static function registerSecurity(): void {
		self::singleton( SecurityRepository::class, static fn () => new SecurityRepository() );
		self::singleton( EncryptionService::class, static fn () => new EncryptionService() );
		self::singleton( FileValidationService::class, static fn () => new FileValidationService() );
		self::singleton( ExifStripService::class, static fn () => new ExifStripService() );
		self::singleton( FileStorageService::class, static fn () => new FileStorageService() );
		self::singleton(
			SecurityService::class,
			static fn () => new SecurityService(
				self::get( FileValidationService::class ),
				self::get( ExifStripService::class ),
				self::get( FileStorageService::class )
			)
		);
		self::singleton(
			AuditLogService::class,
			static fn () => new AuditLogService( self::get( SecurityRepository::class ) )
		);
		self::singleton(
			SecurityController::class,
			static fn () => new SecurityController( self::get( AuditLogService::class ) )
		);
	}

	private static function registerConversation(): void {
		self::singleton( ConversationRepository::class, static fn () => new ConversationRepository() );
		self::singleton( ParticipantRepository::class, static fn () => new ParticipantRepository() );
		self::singleton(
			ParticipantService::class,
			static fn () => new ParticipantService( self::get( ParticipantRepository::class ) )
		);
		self::singleton( ConversationPermissionService::class, static fn () => new ConversationPermissionService() );
		self::singleton(
			ConversationService::class,
			static fn () => new ConversationService(
				self::get( ConversationRepository::class ),
				self::get( ParticipantService::class ),
				self::get( ConversationPermissionService::class )
			)
		);
		self::singleton(
			ConversationController::class,
			static fn () => new ConversationController( self::get( ConversationService::class ) )
		);
	}

	private static function registerMessage(): void {
		self::singleton( MessageRepository::class, static fn () => new MessageRepository() );
		self::singleton( AttachmentRepository::class, static fn () => new AttachmentRepository() );
		self::singleton( ReactionRepository::class, static fn () => new ReactionRepository() );
		self::singleton(
			MessageService::class,
			static fn () => new MessageService(
				self::get( MessageRepository::class ),
				self::get( ConversationService::class ),
				self::has( BlocklistService::class ) ? self::get( BlocklistService::class ) : null,
				self::has( SpamFilterService::class ) ? self::get( SpamFilterService::class ) : null,
				self::has( ModerationService::class ) ? self::get( ModerationService::class ) : null,
				self::get( ParticipantRepository::class )
			)
		);
		self::singleton(
			AttachmentService::class,
			static fn () => new AttachmentService(
				self::get( AttachmentRepository::class ),
				self::has( SecurityService::class ) ? self::get( SecurityService::class ) : null
			)
		);
		self::singleton(
			ReactionService::class,
			static fn () => new ReactionService(
				self::get( ReactionRepository::class ),
				self::get( MessageRepository::class ),
				self::get( ConversationService::class )
			)
		);
		self::singleton(
			ReadReceiptService::class,
			static fn () => new ReadReceiptService(
				self::get( MessageRepository::class ),
				self::get( ParticipantService::class ),
				self::get( ConversationService::class )
			)
		);
		self::singleton(
			MessageController::class,
			static fn () => new MessageController(
				self::get( MessageService::class ),
				self::get( ReactionService::class ),
				self::get( ReadReceiptService::class )
			)
		);
		self::singleton(
			AttachmentController::class,
			static fn () => new AttachmentController(
				self::get( AttachmentService::class ),
				self::get( AttachmentRepository::class )
			)
		);
	}

	private static function registerModeration(): void {
		self::singleton( ModerationRepository::class, static fn () => new ModerationRepository() );
		self::singleton( BlocklistService::class, static fn () => new BlocklistService() );
		self::singleton( SpamFilterService::class, static fn () => new SpamFilterService() );
		self::singleton(
			ModerationService::class,
			static fn () => new ModerationService(
				self::get( ModerationRepository::class ),
				self::get( ConversationRepository::class ),
				self::get( ParticipantRepository::class ),
				self::get( AuditLogService::class )
			)
		);
		self::singleton(
			AdminViewService::class,
			static fn () => new AdminViewService(
				self::get( ConversationRepository::class ),
				self::get( ParticipantRepository::class ),
				self::get( MessageRepository::class ),
				self::get( AuditLogService::class )
			)
		);
		self::singleton(
			ModerationController::class,
			static fn () => new ModerationController(
				self::get( ModerationService::class ),
				self::get( AdminViewService::class )
			)
		);
	}

	private static function registerRealtime(): void {
		self::singleton( RealtimeRepository::class, static fn () => new RealtimeRepository() );

		self::singleton( PusherService::class,    static fn () => new PusherService() );
		self::singleton( WebSocketService::class, static fn () => new WebSocketService() );
		self::singleton(
			SseService::class,
			static fn () => new SseService( self::get( RealtimeRepository::class ) )
		);
		self::singleton(
			PollingService::class,
			static fn () => new PollingService( self::get( RealtimeRepository::class ) )
		);

		self::singleton(
			RealtimeDriverInterface::class,
			static function () {
				$key = (string) get_option( 'zymarg_comm_realtime_driver', 'pusher' );
				$key = strtolower( $key );
				switch ( $key ) {
					case 'websocket': return self::get( WebSocketService::class );
					case 'sse':       return self::get( SseService::class );
					case 'polling':   return self::get( PollingService::class );
					case 'pusher':
					default:          return self::get( PusherService::class );
				}
			}
		);

		self::singleton(
			QueueService::class,
			static fn () => new QueueService(
				self::get( RealtimeRepository::class ),
				self::get( RealtimeDriverInterface::class )
			)
		);

		self::singleton(
			PresenceService::class,
			static fn () => new PresenceService(
				self::get( RealtimeRepository::class ),
				self::get( QueueService::class )
			)
		);

		self::singleton(
			RealtimeController::class,
			static fn () => new RealtimeController(
				self::get( QueueService::class ),
				self::get( PresenceService::class ),
				self::get( PollingService::class ),
				self::get( SseService::class ),
				self::get( PusherService::class ),
				self::get( ParticipantRepository::class )
			)
		);
	}

	private static function registerMarketplace(): void {
		self::singleton(
			MarketplaceRepository::class,
			static fn () => new MarketplaceRepository(
				self::get( ConversationRepository::class ),
				self::get( MessageRepository::class ),
				self::get( ParticipantRepository::class )
			)
		);
		self::singleton( StorePopupService::class, static fn () => new StorePopupService() );
		self::singleton(
			BuyerInboxService::class,
			static fn () => new BuyerInboxService( self::get( MarketplaceRepository::class ) )
		);
		self::singleton(
			VendorInboxService::class,
			static fn () => new VendorInboxService( self::get( MarketplaceRepository::class ) )
		);
		self::singleton(
			ProductSharingService::class,
			static fn () => new ProductSharingService(
				self::get( MarketplaceRepository::class ),
				self::get( MessageService::class )
			)
		);
		self::singleton(
			OrderChatService::class,
			static fn () => new OrderChatService(
				self::get( MarketplaceRepository::class ),
				self::get( ConversationService::class )
			)
		);
		self::singleton(
			StoreChatService::class,
			static fn () => new StoreChatService(
				self::get( MarketplaceRepository::class ),
				self::get( ConversationService::class )
			)
		);
		self::singleton(
			MarketplaceController::class,
			static fn () => new MarketplaceController(
				self::get( MarketplaceRepository::class ),
				self::get( ProductSharingService::class ),
				self::get( OrderChatService::class ),
				self::get( StoreChatService::class )
			)
		);
	}

	/**
	 * Admin<->User support messaging (1.25.0).
	 *
	 * Sits on top of the conversation module rather than beside it, so support
	 * threads reuse the existing engine end to end.
	 */
	private static function registerSupport(): void {
		self::singleton( SupportRepository::class, static fn () => new SupportRepository() );
		self::singleton( SupportTicketRepository::class, static fn () => new SupportTicketRepository() );
		self::singleton(
			SupportService::class,
			static fn () => new SupportService(
				self::get( SupportRepository::class ),
				self::get( ConversationService::class ),
				self::get( SupportTicketRepository::class ),
				// 1.32.0 — lets startOrResume() post the Smart Intake answers as a
				// real opening message. Resolved lazily inside this closure, so the
				// registration order of the two modules does not matter.
				self::get( MessageService::class )
			)
		);
		self::singleton(
			SupportTicketService::class,
			static fn () => new SupportTicketService(
				self::get( SupportTicketRepository::class ),
				self::get( SupportRepository::class ),
				self::get( SupportService::class )
			)
		);
		// 1.33.0 — case ownership lock. Fully-qualified rather than imported so
		// this binding is self-contained and cannot be broken by import order.
		self::singleton(
			\ZymargCommunication\Modules\Support\Services\SupportCaseLock::class,
			static fn () => new \ZymargCommunication\Modules\Support\Services\SupportCaseLock(
				self::get( SupportTicketRepository::class ),
				self::get( SupportService::class )
			)
		);
		self::singleton(
			SupportController::class,
			static fn () => new SupportController(
				self::get( SupportService::class ),
				self::get( SupportRepository::class ),
				self::get( SupportTicketService::class ),
				self::get( SupportTicketRepository::class )
			)
		);
	}

	private static function registerNotification(): void {
		self::singleton( NotificationRepository::class, static fn () => new NotificationRepository() );
		self::singleton( NotificationPreferenceService::class, static fn () => new NotificationPreferenceService() );
		self::singleton(
			EmailNotificationService::class,
			static fn () => new EmailNotificationService( self::get( NotificationPreferenceService::class ) )
		);
		self::singleton(
			PushNotificationService::class,
			static fn () => new PushNotificationService( self::get( NotificationPreferenceService::class ) )
		);
		self::singleton(
			BrowserNotificationService::class,
			static fn () => new BrowserNotificationService( self::get( NotificationPreferenceService::class ) )
		);
		self::singleton(
			NotificationService::class,
			static fn () => new NotificationService(
				self::get( NotificationRepository::class ),
				self::get( NotificationPreferenceService::class ),
				self::get( EmailNotificationService::class ),
				self::get( PushNotificationService::class ),
				self::get( BrowserNotificationService::class ),
				self::get( PresenceService::class ),
				self::get( ConversationRepository::class ),
				self::get( ParticipantRepository::class ),
				self::get( MessageRepository::class )
			)
		);
		self::singleton(
			NotificationController::class,
			static fn () => new NotificationController(
				self::get( NotificationRepository::class ),
				self::get( NotificationPreferenceService::class ),
				self::get( PushNotificationService::class ),
				self::get( BrowserNotificationService::class )
			)
		);
	}

	private static function registerAnalytics(): void {
		self::singleton( AnalyticsRepository::class, static fn () => new AnalyticsRepository() );
		self::singleton(
			AnalyticsService::class,
			static fn () => new AnalyticsService( self::get( AnalyticsRepository::class ) )
		);
		self::singleton(
			ReportService::class,
			static fn () => new ReportService( self::get( AnalyticsRepository::class ) )
		);
		self::singleton(
			AdminReportService::class,
			static fn () => new AdminReportService( self::get( AnalyticsRepository::class ) )
		);
		self::singleton(
			UserReportService::class,
			static fn () => new UserReportService( self::get( AnalyticsRepository::class ) )
		);
		self::singleton(
			AnalyticsController::class,
			static fn () => new AnalyticsController(
				self::get( AdminReportService::class ),
				self::get( UserReportService::class )
			)
		);
	}

	private static function registerHelpCenter(): void {
		self::singleton( HelpCenterRepository::class, static fn () => new HelpCenterRepository() );
		self::singleton( HelpCenterService::class, static fn () => new HelpCenterService() );
		self::singleton( DocumentationService::class, static fn () => new DocumentationService() );
		self::singleton( ChangelogService::class, static fn () => new ChangelogService() );
		self::singleton(
			FaqService::class,
			static fn () => new FaqService( self::get( HelpCenterRepository::class ) )
		);
		self::singleton(
			HelpCenterController::class,
			static fn () => new HelpCenterController(
				self::get( HelpCenterService::class ),
				self::get( DocumentationService::class ),
				self::get( ChangelogService::class ),
				self::get( FaqService::class )
			)
		);
	}

	private static function registerDeveloper(): void {
		self::singleton( DeveloperRepository::class, static fn () => new DeveloperRepository() );
		self::singleton(
			WebhookService::class,
			static fn () => new WebhookService( self::get( DeveloperRepository::class ) )
		);
		self::singleton(
			ApiKeyService::class,
			static fn () => new ApiKeyService( self::get( DeveloperRepository::class ) )
		);
		self::singleton( ExtensionService::class, static fn () => new ExtensionService() );
		self::singleton(
			DeveloperController::class,
			static fn () => new DeveloperController(
				self::get( WebhookService::class ),
				self::get( ApiKeyService::class ),
				self::get( ExtensionService::class )
			)
		);
	}

	private static function registerSettings(): void {
		self::singleton( SettingsRepository::class, static fn () => new SettingsRepository() );
		self::singleton(
			SettingsService::class,
			static fn () => new SettingsService(
				self::get( SettingsRepository::class ),
				self::get( EncryptionService::class )
			)
		);
		self::singleton(
			SettingsController::class,
			static fn () => new SettingsController(
				self::get( SettingsService::class ),
				self::get( PusherService::class ),
				self::get( AuditLogService::class )
			)
		);
	}

	public static function bind( string $key, callable $factory ): void {
		self::$factories[ $key ] = $factory;
	}

	public static function singleton( string $key, callable $factory ): void {
		self::$factories[ $key ] = static function () use ( $factory, $key ) {
			if ( ! array_key_exists( $key, self::$singletons ) ) {
				self::$singletons[ $key ] = $factory();
			}
			return self::$singletons[ $key ];
		};
	}

	public static function get( string $key ): mixed {
		if ( ! isset( self::$factories[ $key ] ) ) {
			return null;
		}
		return ( self::$factories[ $key ] )();
	}

	public static function has( string $key ): bool {
		return isset( self::$factories[ $key ] );
	}
}
