<?php
/**
 * ZYMARG Communication — Plugin-owned page registrar.
 *
 * The ONLY file that creates or deletes plugin-owned WordPress pages.
 * Creates `/messages/` and `/vendor-messages/` on activation and destroys
 * them on uninstall.
 *
 * @package    ZymargCommunication
 * @version    1.1.0
 */

namespace ZymargCommunication\Bootstrap;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class PageRegistrar {

	public const OPTION_PAGE_IDS = 'zymarg_comm_page_ids';

	/**
	 * @return array<string, array{title:string, slug:string, shortcode:string}>
	 */
	private static function pages(): array {
		return [
			'buyer_inbox'  => [
				'title'     => __( 'Messages', 'zymarg-communication' ),
				'slug'      => 'messages',
				'shortcode' => '[zymarg_comm_buyer_inbox]',
			],
			'vendor_inbox' => [
				'title'     => __( 'Vendor Messages', 'zymarg-communication' ),
				'slug'      => 'vendor-messages',
				'shortcode' => '[zymarg_comm_vendor_inbox]',
			],
		];
	}

	/**
	 * Create plugin-owned pages if they do not already exist.
	 * Stores the resulting page IDs in a plugin option so uninstall can find them.
	 */
	/**
	 * Recreate any missing plugin page, safe to call on every request (1.32.7).
	 *
	 * create() only runs on activation. If the pages this plugin owns go missing
	 * afterwards — most obviously because the plugin was deleted, which used to
	 * permanently delete them via destroy(), but equally if someone empties the
	 * trash — nothing ever noticed, and the "full inbox" the support popup hands
	 * off to simply did not exist any more. Reinstalling did recreate them, but
	 * as NEW posts with new IDs, so menu items and hard-coded links pointing at
	 * the old IDs stayed broken.
	 *
	 * This verifies the stored IDs still resolve to a live page and repairs the
	 * ones that do not, reusing an existing page on the same slug when there is
	 * one so a site that already has /messages is adopted rather than duplicated.
	 *
	 * @return array<string, int> Keys repaired, for reporting.
	 */
	public static function repair(): array {
		$stored  = get_option( self::OPTION_PAGE_IDS, array() );
		$stored  = is_array( $stored ) ? $stored : array();
		$fixed   = array();

		foreach ( self::pages() as $key => $config ) {
			$id   = isset( $stored[ $key ] ) ? (int) $stored[ $key ] : 0;
			$post = $id ? get_post( $id ) : null;

			if ( $post && 'page' === $post->post_type && 'trash' !== $post->post_status ) {
				continue; // Still fine.
			}

			$existing = get_page_by_path( $config['slug'] );
			if ( $existing instanceof \WP_Post && 'trash' !== $existing->post_status ) {
				$stored[ $key ] = (int) $existing->ID;
				$fixed[ $key ]  = (int) $existing->ID;
				continue;
			}

			$new_id = wp_insert_post(
				array(
					'post_title'     => $config['title'],
					'post_name'      => $config['slug'],
					'post_content'   => $config['shortcode'],
					'post_status'    => 'publish',
					'post_type'      => 'page',
					'comment_status' => 'closed',
					'ping_status'    => 'closed',
				)
			);

			if ( $new_id && ! is_wp_error( $new_id ) ) {
				$stored[ $key ] = (int) $new_id;
				$fixed[ $key ]  = (int) $new_id;
			}
		}

		if ( $fixed ) {
			update_option( self::OPTION_PAGE_IDS, $stored );
		}

		return $fixed;
	}

	public static function create(): void {
		$stored = get_option( self::OPTION_PAGE_IDS, [] );
		if ( ! is_array( $stored ) ) {
			$stored = [];
		}

		foreach ( self::pages() as $key => $config ) {
			// Skip if we already own a valid page for this key.
			if ( ! empty( $stored[ $key ] ) ) {
				$existing = get_post( (int) $stored[ $key ] );
				if ( $existing instanceof \WP_Post && $existing->post_type === 'page' && $existing->post_status !== 'trash' ) {
					continue;
				}
			}

			// Reuse an existing page at the same slug if one exists.
			$existing_page = get_page_by_path( $config['slug'] );
			if ( $existing_page instanceof \WP_Post ) {
				$stored[ $key ] = (int) $existing_page->ID;
				continue;
			}

			$page_id = wp_insert_post( [
				'post_title'     => $config['title'],
				'post_name'      => $config['slug'],
				'post_content'   => $config['shortcode'],
				'post_status'    => 'publish',
				'post_type'      => 'page',
				'comment_status' => 'closed',
				'ping_status'    => 'closed',
			] );

			if ( $page_id && ! is_wp_error( $page_id ) ) {
				$stored[ $key ] = (int) $page_id;
			}
		}

		update_option( self::OPTION_PAGE_IDS, $stored );
	}

	/**
	 * Permanently delete every page this plugin owns.
	 */
	public static function destroy(): void {
		$stored = get_option( self::OPTION_PAGE_IDS, [] );
		if ( is_array( $stored ) ) {
			foreach ( $stored as $page_id ) {
				if ( $page_id ) {
					wp_delete_post( (int) $page_id, true );
				}
			}
		}
		delete_option( self::OPTION_PAGE_IDS );
	}

	public static function getPageId( string $key ): ?int {
		$stored = get_option( self::OPTION_PAGE_IDS, [] );
		return is_array( $stored ) && ! empty( $stored[ $key ] ) ? (int) $stored[ $key ] : null;
	}
}
