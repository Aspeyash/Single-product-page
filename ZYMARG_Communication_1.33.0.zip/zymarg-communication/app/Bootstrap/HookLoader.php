<?php
/**
 * ZYMARG Communication — Hook loader.
 *
 * Instantiates and registers each module's Hooks class in the correct order.
 * Also boots the REST controller registry so every controller queued via
 * `RestController::register()` is attached to `rest_api_init`.
 *
 * @package    ZymargCommunication
 * @version    1.6.0
 */

namespace ZymargCommunication\Bootstrap;

use ZymargCommunication\Infrastructure\Http\Controllers\RestController;
use ZymargCommunication\Modules\Conversation\Hooks\ConversationHooks;
use ZymargCommunication\Modules\FeatureFlags\Hooks\FeatureFlagHooks;
use ZymargCommunication\Modules\Marketplace\Hooks\MarketplaceHooks;
use ZymargCommunication\Modules\Message\Hooks\MessageHooks;
use ZymargCommunication\Modules\Moderation\Hooks\ModerationHooks;
use ZymargCommunication\Modules\Notification\Hooks\NotificationHooks;
use ZymargCommunication\Modules\Developer\Hooks\DeveloperHooks;
use ZymargCommunication\Modules\HelpCenter\Hooks\HelpCenterHooks;
use ZymargCommunication\Modules\Analytics\Hooks\AnalyticsHooks;
use ZymargCommunication\Modules\Realtime\Hooks\RealtimeHooks;
use ZymargCommunication\Modules\Security\Hooks\SecurityHooks;
use ZymargCommunication\Modules\Settings\Hooks\SettingsHooks;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class HookLoader {

	/**
	 * Ordered list of module Hooks classes. Each class must expose a static
	 * ::register() method. Entries are added as their owning phase ships.
	 *
	 * @var array<int, class-string>
	 */
	private const MODULE_HOOKS = [
		FeatureFlagHooks::class,
		SecurityHooks::class,
		ConversationHooks::class,
		MessageHooks::class,
		ModerationHooks::class,
		RealtimeHooks::class,
		MarketplaceHooks::class,
		NotificationHooks::class,
		AnalyticsHooks::class,
		HelpCenterHooks::class,
		DeveloperHooks::class,
		SettingsHooks::class,
		\ZymargCommunication\Modules\Support\Hooks\SupportHooks::class,
	];

	public static function load(): void {
		foreach ( self::MODULE_HOOKS as $class ) {
			if ( class_exists( $class ) && method_exists( $class, 'register' ) ) {
				$class::register();
			}
		}

		RestController::boot();

		do_action( 'zymarg_comm_hooks_loaded' );
	}
}
