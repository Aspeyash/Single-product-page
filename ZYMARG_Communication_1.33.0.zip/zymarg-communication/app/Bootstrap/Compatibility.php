<?php
/**
 * ZYMARG Communication — Third-party plugin compatibility.
 *
 * The ONLY file in the plugin permitted to reference external plugin names,
 * classes, or functions. Detects which supported third-party plugins are
 * active and selects the best injection method per surface.
 *
 * Safe when no supported third-party plugins are active.
 *
 * @package    ZymargCommunication
 * @version    1.1.0
 */

namespace ZymargCommunication\Bootstrap;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Compatibility {

	/**
	 * @var array<string, bool>
	 */
	private static array $detected = [];

	public static function register(): void {
		// Run detection after all plugins have finished loading themselves.
		add_action( 'plugins_loaded', [ __CLASS__, 'detect' ], 20 );
	}

	/**
	 * Detect active third-party plugins. Every reference to an external plugin
	 * name, class, or function must live inside this method.
	 */
	public static function detect(): void {
		self::$detected = [
			'woocommerce' => class_exists( 'WooCommerce' ),
			'dokan'       => class_exists( 'WeDevs_Dokan' ),
			'wcfm'        => function_exists( 'wcfm_get_option' ),
			'wcvendors'   => class_exists( 'WCVendors' ),
		];

		/**
		 * Fires after third-party plugin detection completes.
		 *
		 * @param array<string, bool> $detected Detected plugin map.
		 */
		do_action( 'zymarg_comm_compatibility_detected', self::$detected );
	}

	public static function isActive( string $plugin_key ): bool {
		return ! empty( self::$detected[ $plugin_key ] );
	}

	/**
	 * @return array<string, bool>
	 */
	public static function all(): array {
		return self::$detected;
	}
}
