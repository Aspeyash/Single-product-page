<?php
/**
 * AdminAnalyticsPage — fully AJAX platform analytics dashboard.
 *
 * Renders totals, response metrics, a daily activity chart, and a moderation
 * backlog indicator for a selectable range (7d / 30d / 90d / all), all driven
 * by AdminReportService.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Bootstrap;

use ZymargCommunication\Modules\Analytics\Repositories\AnalyticsRepository;
use ZymargCommunication\Modules\Analytics\Services\AdminReportService;
use ZymargCommunication\Modules\Analytics\Services\UserPerformanceService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdminAnalyticsPage {

	private static bool $registered = false;
	public const MENU_SLUG     = 'zymarg-comm-analytics';
	private const NONCE_ACTION = 'zymarg_comm_analytics_load';

	public static function register(): void {
		if ( self::$registered ) {
			return;
		}
		self::$registered = true;
		add_action( 'admin_menu',                          array( self::class, 'registerMenu' ), 60 );
		add_action( 'wp_ajax_zymarg_comm_analytics_report', array( self::class, 'handleReport' ) );
		add_action( 'wp_ajax_zymarg_comm_user_perf',         array( self::class, 'handleUserPerf' ) );
		add_action( 'wp_ajax_zymarg_comm_user_perf_rebuild', array( self::class, 'handleUserPerfRebuild' ) );
		add_action( 'wp_ajax_zymarg_comm_user_perf_timer',   array( self::class, 'handleUserPerfTimer' ) );
	}

	public static function registerMenu(): void {
		add_submenu_page(
			AdminMenu::MENU_SLUG,
			__( 'Analytics', 'zymarg-communication' ),
			__( 'Analytics', 'zymarg-communication' ),
			'manage_options',
			self::MENU_SLUG,
			array( self::class, 'render' )
		);
	}

	private static function reports(): AdminReportService {
		return new AdminReportService( new AnalyticsRepository() );
	}

	/** @return array<string,string> */
	private static function ranges(): array {
		return array(
			'7d'  => __( 'Last 7 days', 'zymarg-communication' ),
			'30d' => __( 'Last 30 days', 'zymarg-communication' ),
			'90d' => __( 'Last 90 days', 'zymarg-communication' ),
			'all' => __( 'All time', 'zymarg-communication' ),
		);
	}

	// =========================================================================
	// Render shell
	// =========================================================================

	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$nonce    = wp_create_nonce( self::NONCE_ACTION );
		$ajax_url = admin_url( 'admin-ajax.php' );
		$range    = isset( $_GET['range'] ) ? sanitize_key( (string) wp_unslash( $_GET['range'] ) ) : '30d';
		$ranges   = self::ranges();
		if ( ! array_key_exists( $range, $ranges ) ) {
			$range = '30d';
		}
		?>
		<div class="wrap zcm-admin-page zymarg-comm-analytics">
		<style>
		.zcm-admin-page{max-width:1180px;}
		.zcm-admin-page > h1{margin:0 0 6px;padding:0;font-size:23px;line-height:1.3;}
		.zcm-admin-page .description{font-size:13px;color:var(--zc-color-neutral-text);margin:0 0 20px;max-width:840px;line-height:1.6;}
		.zcm-admin-page .nav-tab-wrapper{display:flex;flex-wrap:wrap;gap:6px;align-items:flex-end;margin:0 0 24px;padding:0;border-bottom:1px solid var(--zc-color-divider);}
		.zcm-admin-page .nav-tab{float:none;display:inline-block;margin:0;padding:9px 16px;font-size:13px;font-weight:500;line-height:1.5;text-decoration:none;cursor:pointer;color:var(--zc-color-text-muted);background:var(--zc-color-neutral-bg);border:1px solid var(--zc-color-divider);border-bottom:none;border-radius:6px 6px 0 0;}
		.zcm-admin-page .nav-tab:hover{background:#fff;color:var(--zc-color-primary-deep);}
		.zcm-admin-page .nav-tab-active,.zcm-admin-page .nav-tab-active:hover{background:#fff;color:var(--zc-color-primary);font-weight:600;border-bottom:1px solid #fff;margin-bottom:-1px;box-shadow:inset 0 -2px 0 var(--zc-color-primary);}
		.zcm-admin-page .zcm-count{color:var(--zc-color-neutral-text);font-size:13px;margin:0 0 12px;}
		.zcm-admin-page table.wp-list-table{display:table;width:100%;border-collapse:separate;border-spacing:0;table-layout:auto;margin-top:0;background:#fff;border:1px solid var(--zc-color-divider);border-radius:8px;overflow:hidden;}
		.zcm-admin-page table.wp-list-table thead{display:table-header-group;}
		.zcm-admin-page table.wp-list-table tbody{display:table-row-group;}
		.zcm-admin-page table.wp-list-table tr{display:table-row;}
		.zcm-admin-page table.wp-list-table th,.zcm-admin-page table.wp-list-table td{display:table-cell;text-align:left;padding:12px 16px;vertical-align:middle;border-bottom:1px solid var(--zc-color-neutral-bg);font-size:13px;}
		.zcm-admin-page table.wp-list-table thead th{font-weight:600;color:var(--zc-color-ink);background:var(--zc-color-surface);white-space:nowrap;}
		.zcm-admin-page table.wp-list-table tbody tr:last-child td{border-bottom:none;}
		.zcm-admin-page table.wp-list-table tbody tr:hover{background:var(--zc-color-surface);}
		.zcm-admin-page .zcm-conv-viewer{margin:0 0 20px;box-shadow:0 1px 3px rgba(0,0,0,.06);}
		.zcm-admin-page .button + .button{margin-left:6px;}
		</style>
			<?php AdminMenu::renderHeader( __( 'ZYMARG Communication', 'zymarg-communication' ), __( 'Analytics — Message volume, engagement and delivery insight', 'zymarg-communication' ) ); ?>
			<p class="description" style="margin:8px 0 16px;"><?php esc_html_e( 'Platform-wide messaging activity. Figures are derived from recorded analytics events.', 'zymarg-communication' ); ?></p>

			<h2 class="nav-tab-wrapper" style="margin-bottom:10px;">
				<a href="#" class="nav-tab nav-tab-active zcm-analytics-section" data-section="platform"><?php esc_html_e( 'Platform overview', 'zymarg-communication' ); ?></a>
				<a href="#" class="nav-tab zcm-analytics-section" data-section="users"><?php esc_html_e( 'Per user', 'zymarg-communication' ); ?></a>
			</h2>

			<h2 class="nav-tab-wrapper" style="margin-bottom:16px;">
				<?php foreach ( $ranges as $key => $label ) : ?>
				<a href="#" class="nav-tab zcm-analytics-range<?php echo $key === $range ? ' nav-tab-active' : ''; ?>" data-range="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></a>
				<?php endforeach; ?>
			</h2>

			<div id="zcm-analytics-content"><?php self::renderReport( $range ); ?></div>
			<div id="zcm-userperf" style="display:none;"></div>

			<script>
			(function(){
				var AJAX  = <?php echo wp_json_encode( $ajax_url ); ?>;
				var NONCE = <?php echo wp_json_encode( $nonce ); ?>;
				var content = document.getElementById('zcm-analytics-content');
				if (!content) return;

				function loadReport(range){
					content.style.opacity = '0.5';
					var d = new URLSearchParams();
					d.append('action', 'zymarg_comm_analytics_report');
					d.append('_wpnonce', NONCE);
					d.append('range', range);
					fetch(AJAX, {method:'POST', credentials:'same-origin', body:d})
						.then(function(r){ return r.json(); })
						.then(function(res){
							if (res.success){ content.innerHTML = res.data.html; }
							content.style.opacity = '1';
						})
						.catch(function(){ content.style.opacity = '1'; });
				}

				document.querySelectorAll('.zcm-analytics-range').forEach(function(btn){
					btn.addEventListener('click', function(e){
						e.preventDefault();
						document.querySelectorAll('.zcm-analytics-range').forEach(function(b){ b.classList.toggle('nav-tab-active', b===btn); });
						if (window.__zcmSection === 'users') { window.__zcmLoadUserPerf({ range: this.dataset.range || '30d' }); }
						else { loadReport(this.dataset.range || '30d'); }
					});
				});
			})();
			</script>

			<script>
			(function(){
				var AJAX  = <?php echo wp_json_encode( $ajax_url ); ?>;
				var NONCE = <?php echo wp_json_encode( $nonce ); ?>;
				var platform = document.getElementById('zcm-analytics-content');
				var pane     = document.getElementById('zcm-userperf');
				if (!platform || !pane) return;

				window.__zcmSection = 'platform';
				var st = { range: <?php echo wp_json_encode( $range ); ?>, role: 'all', page: 1, sort: 'slow', search: '' };

				function post(action, extra, done){
					var d = new URLSearchParams();
					d.append('action', action);
					d.append('_wpnonce', NONCE);
					Object.keys(extra || {}).forEach(function(k){ d.append(k, extra[k]); });
					fetch(AJAX, {method:'POST', credentials:'same-origin', body:d})
						.then(function(r){ return r.json(); })
						.then(function(res){ done(res); })
						.catch(function(){ pane.style.opacity = '1'; });
				}

				function load(over){
					Object.keys(over || {}).forEach(function(k){ st[k] = over[k]; });
					pane.style.opacity = '0.5';
					post('zymarg_comm_user_perf', st, function(res){
						if (res && res.success) { pane.innerHTML = res.data.html; }
						pane.style.opacity = '1';
					});
				}
				window.__zcmLoadUserPerf = load;

				document.querySelectorAll('.zcm-analytics-section').forEach(function(tab){
					tab.addEventListener('click', function(e){
						e.preventDefault();
						document.querySelectorAll('.zcm-analytics-section').forEach(function(b){ b.classList.toggle('nav-tab-active', b === tab); });
						var sec = tab.getAttribute('data-section') || 'platform';
						window.__zcmSection = sec;
						if (sec === 'users') {
							platform.style.display = 'none';
							pane.style.display = '';
							if (!pane.getAttribute('data-loaded')) { pane.setAttribute('data-loaded','1'); load({}); }
						} else {
							pane.style.display = 'none';
							platform.style.display = '';
						}
					});
				});

				pane.addEventListener('click', function(e){
					var el = e.target && e.target.closest ? e.target.closest('[data-perf]') : null;
					if (!el) return;
					e.preventDefault();
					var act = el.getAttribute('data-perf');
					if (act === 'page') { load({ page: parseInt(el.getAttribute('data-page'), 10) || 1 }); }
					else if (act === 'sort') { load({ sort: el.getAttribute('data-sort'), page: 1 }); }
					else if (act === 'rebuild') {
						el.disabled = true;
						el.textContent = <?php echo wp_json_encode( __( 'Calculating, please wait...', 'zymarg-communication' ) ); ?>;
						post('zymarg_comm_user_perf_rebuild', { range: st.range }, function(){ load({ page: 1 }); });
					}
				});

				pane.addEventListener('change', function(e){
					var el = e.target;
					if (!el) return;
					if (el.hasAttribute('data-perf-role')) { load({ role: el.value, page: 1 }); }
					if (el.hasAttribute('data-perf-timer')) { post('zymarg_comm_user_perf_timer', { interval: el.value }, function(){}); }
				});

				pane.addEventListener('keydown', function(e){
					if (e.key === 'Enter' && e.target && e.target.hasAttribute && e.target.hasAttribute('data-perf-search')) {
						e.preventDefault();
						load({ search: e.target.value, page: 1 });
					}
				});
			})();
			</script>
		</div>
		<?php
	}

	public static function handleReport(): void {
		check_ajax_referer( self::NONCE_ACTION );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'zymarg-communication' ) ) );
		}
		$range = isset( $_POST['range'] ) ? sanitize_key( (string) wp_unslash( $_POST['range'] ) ) : '30d';
		if ( ! array_key_exists( $range, self::ranges() ) ) {
			$range = '30d';
		}
		try {
			ob_start();
			self::renderReport( $range );
			wp_send_json_success( array( 'html' => ob_get_clean() ) );
		} catch ( \Throwable $e ) {
			if ( ob_get_length() ) {
				ob_end_clean();
			}
			wp_send_json_error( array( 'message' => $e->getMessage() ) );
		}
	}

	// =========================================================================
	// Report body
	// =========================================================================

	private static function renderReport( string $range ): void {
		$data   = self::reports()->dashboard( $range );
		$totals = isset( $data['totals'] ) ? (array) $data['totals'] : array();
		$resp   = isset( $data['response'] ) ? (array) $data['response'] : array();
		$mod    = isset( $data['moderation'] ) ? (array) $data['moderation'] : array();
		$daily  = isset( $data['daily']['messages_sent'] ) ? (array) $data['daily']['messages_sent'] : array();

		$cards = array(
			array( 'label' => __( 'Messages sent', 'zymarg-communication' ),         'key' => 'messages_sent',         'icon' => 'dashicons-email-alt' ),
			array( 'label' => __( 'Conversations started', 'zymarg-communication' ), 'key' => 'conversations_started', 'icon' => 'dashicons-format-chat' ),
			array( 'label' => __( 'Conversations closed', 'zymarg-communication' ),  'key' => 'conversations_closed',  'icon' => 'dashicons-yes-alt' ),
			array( 'label' => __( 'Active users', 'zymarg-communication' ),          'key' => 'active_users',          'icon' => 'dashicons-groups' ),
			array( 'label' => __( 'Attachments uploaded', 'zymarg-communication' ),  'key' => 'attachments_uploaded',  'icon' => 'dashicons-paperclip' ),
			array( 'label' => __( 'Reports filed', 'zymarg-communication' ),         'key' => 'reports_filed',         'icon' => 'dashicons-flag' ),
			array( 'label' => __( 'Spam flagged', 'zymarg-communication' ),          'key' => 'spam_flagged',          'icon' => 'dashicons-shield' ),
		);
		?>
		<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:14px;margin-bottom:24px;">
			<?php foreach ( $cards as $card ) :
				$value = isset( $totals[ $card['key'] ] ) ? (int) $totals[ $card['key'] ] : 0;
				?>
				<div style="background:var(--zc-color-surface-lowest);border:1px solid var(--zc-color-divider);border-radius:8px;padding:16px;">
					<div style="display:flex;align-items:center;gap:8px;color:var(--zc-color-primary);margin-bottom:8px;">
						<span class="dashicons <?php echo esc_attr( $card['icon'] ); ?>"></span>
						<span style="font-size:13px;color:var(--zc-color-text-muted);"><?php echo esc_html( $card['label'] ); ?></span>
					</div>
					<div style="font-size:28px;font-weight:700;color:var(--zc-color-ink);"><?php echo esc_html( number_format_i18n( $value ) ); ?></div>
				</div>
			<?php endforeach; ?>
		</div>

		<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:14px;margin-bottom:24px;">
			<div style="background:var(--zc-color-surface-lowest);border:1px solid var(--zc-color-divider);border-radius:8px;padding:16px;">
				<div style="font-size:13px;color:var(--zc-color-text-muted);margin-bottom:8px;"><?php esc_html_e( 'Average response time', 'zymarg-communication' ); ?></div>
				<div style="font-size:24px;font-weight:700;color:var(--zc-color-ink);"><?php echo esc_html( self::humanDuration( isset( $resp['average_seconds'] ) ? $resp['average_seconds'] : null ) ); ?></div>
			</div>
			<div style="background:var(--zc-color-surface-lowest);border:1px solid var(--zc-color-divider);border-radius:8px;padding:16px;">
				<div style="font-size:13px;color:var(--zc-color-text-muted);margin-bottom:8px;"><?php esc_html_e( 'Response rate', 'zymarg-communication' ); ?></div>
				<div style="font-size:24px;font-weight:700;color:var(--zc-color-ink);"><?php echo esc_html( self::formatRate( isset( $resp['response_rate'] ) ? $resp['response_rate'] : null ) ); ?></div>
			</div>
			<div style="background:var(--zc-color-surface-lowest);border:1px solid var(--zc-color-divider);border-radius:8px;padding:16px;">
				<div style="font-size:13px;color:var(--zc-color-text-muted);margin-bottom:8px;"><?php esc_html_e( 'Pending moderation', 'zymarg-communication' ); ?></div>
				<div style="font-size:24px;font-weight:700;color:<?php echo ( isset( $mod['pending'] ) && (int) $mod['pending'] > 0 ) ? 'var(--zc-color-danger)' : 'var(--zc-color-ink)'; ?>;"><?php echo esc_html( number_format_i18n( isset( $mod['pending'] ) ? (int) $mod['pending'] : 0 ) ); ?></div>
			</div>
		</div>

		<?php self::renderChart( $daily ); ?>
		<?php
	}

	/** @param array<int,array{date:string,count:int}> $daily */
	private static function renderChart( array $daily ): void {
		$max = 0;
		foreach ( $daily as $d ) {
			$max = max( $max, (int) ( $d['count'] ?? 0 ) );
		}
		?>
		<div style="background:var(--zc-color-surface-lowest);border:1px solid var(--zc-color-divider);border-radius:8px;padding:16px 20px;">
			<div style="font-size:14px;font-weight:600;color:var(--zc-color-ink);margin-bottom:16px;"><?php esc_html_e( 'Messages sent per day', 'zymarg-communication' ); ?></div>
			<?php if ( empty( $daily ) || 0 === $max ) : ?>
				<p style="color:var(--zc-color-neutral-text);"><?php esc_html_e( 'No activity recorded for this range yet.', 'zymarg-communication' ); ?></p>
			<?php else : ?>
				<div style="display:flex;align-items:flex-end;gap:3px;height:140px;overflow-x:auto;padding-bottom:4px;">
					<?php foreach ( $daily as $d ) :
						$count  = (int) ( $d['count'] ?? 0 );
						$height = $max > 0 ? max( 2, (int) round( ( $count / $max ) * 130 ) ) : 2;
						$date   = (string) ( $d['date'] ?? '' );
						?>
						<div title="<?php echo esc_attr( $date . ': ' . $count ); ?>" style="flex:0 0 auto;width:14px;height:<?php echo (int) $height; ?>px;background:linear-gradient(180deg,var(--zc-color-primary),var(--zc-color-primary-deep));border-radius:3px 3px 0 0;"></div>
					<?php endforeach; ?>
				</div>
				<div style="display:flex;justify-content:space-between;color:var(--zc-color-neutral-text);font-size:11px;margin-top:8px;">
					<span><?php echo esc_html( (string) ( $daily[0]['date'] ?? '' ) ); ?></span>
					<span><?php echo esc_html( (string) ( $daily[ count( $daily ) - 1 ]['date'] ?? '' ) ); ?></span>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	/** @param mixed $seconds */
	private static function humanDuration( $seconds ): string {
		if ( null === $seconds ) {
			return __( 'Not enough data', 'zymarg-communication' );
		}
		$s = (int) round( (float) $seconds );
		if ( $s < 60 ) {
			return sprintf( _n( '%d second', '%d seconds', $s, 'zymarg-communication' ), $s );
		}
		if ( $s < 3600 ) {
			$m = (int) round( $s / 60 );
			return sprintf( _n( '%d minute', '%d minutes', $m, 'zymarg-communication' ), $m );
		}
		if ( $s < 86400 ) {
			$h = round( $s / 3600, 1 );
			return sprintf( __( '%s hours', 'zymarg-communication' ), $h );
		}
		$days = round( $s / 86400, 1 );
		return sprintf( __( '%s days', 'zymarg-communication' ), $days );
	}

	/** @param mixed $rate */
	private static function formatRate( $rate ): string {
		if ( null === $rate ) {
			return __( 'Not enough data', 'zymarg-communication' );
		}
		return number_format_i18n( (float) $rate, 1 ) . '%';
	}

	// =========================================================================
	// Per-user performance (added 1.24.0)
	//
	// Reads ONLY the cached table built by UserPerformanceService. Rendering
	// never queries the message table, so opening this tab costs the same as
	// any other admin page. The expensive walk happens on explicit refresh or
	// on the optional timer.
	// =========================================================================

	private static function perfService(): UserPerformanceService {
		return new UserPerformanceService();
	}

	/** @return array<string,string> */
	private static function perfSorts(): array {
		return array(
			'slow'     => __( 'Slowest repliers first', 'zymarg-communication' ),
			'fast'     => __( 'Fastest repliers first', 'zymarg-communication' ),
			'worst'    => __( 'Lowest reply rate first', 'zymarg-communication' ),
			'messages' => __( 'Most messages first', 'zymarg-communication' ),
			'recent'   => __( 'Most recently active', 'zymarg-communication' ),
		);
	}

	public static function handleUserPerf(): void {
		check_ajax_referer( self::NONCE_ACTION );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'zymarg-communication' ) ) );
		}
		$range = isset( $_POST['range'] ) ? sanitize_key( (string) wp_unslash( $_POST['range'] ) ) : '30d';
		if ( ! array_key_exists( $range, self::ranges() ) ) {
			$range = '30d';
		}
		$role   = isset( $_POST['role'] ) ? sanitize_key( (string) wp_unslash( $_POST['role'] ) ) : 'all';
		$sort   = isset( $_POST['sort'] ) ? sanitize_key( (string) wp_unslash( $_POST['sort'] ) ) : 'slow';
		$paged  = isset( $_POST['page'] ) ? max( 1, (int) $_POST['page'] ) : 1;
		$search = isset( $_POST['search'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['search'] ) ) : '';

		try {
			ob_start();
			self::renderUserPerf( $range, $role, $sort, $paged, $search );
			wp_send_json_success( array( 'html' => ob_get_clean() ) );
		} catch ( \Throwable $e ) {
			if ( ob_get_length() ) {
				ob_end_clean();
			}
			wp_send_json_error( array( 'message' => $e->getMessage() ) );
		}
	}

	public static function handleUserPerfRebuild(): void {
		check_ajax_referer( self::NONCE_ACTION );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'zymarg-communication' ) ) );
		}
		$range = isset( $_POST['range'] ) ? sanitize_key( (string) wp_unslash( $_POST['range'] ) ) : '30d';
		if ( ! array_key_exists( $range, self::ranges() ) ) {
			$range = '30d';
		}
		try {
			$report = self::perfService()->rebuild( $range );
			wp_send_json_success(
				array(
					'took_ms' => isset( $report['took_ms'] ) ? (int) $report['took_ms'] : 0,
					'users'   => isset( $report['rows'] ) ? count( (array) $report['rows'] ) : 0,
				)
			);
		} catch ( \Throwable $e ) {
			wp_send_json_error( array( 'message' => $e->getMessage() ) );
		}
	}

	public static function handleUserPerfTimer(): void {
		check_ajax_referer( self::NONCE_ACTION );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'zymarg-communication' ) ) );
		}
		$val = isset( $_POST['interval'] ) ? sanitize_key( (string) wp_unslash( $_POST['interval'] ) ) : 'daily';
		if ( ! array_key_exists( $val, UserPerformanceService::intervals() ) ) {
			$val = 'daily';
		}
		update_option( UserPerformanceService::OPTION_INTERVAL, $val, false );
		Scheduler::syncUserPerformance();
		wp_send_json_success( array( 'interval' => $val ) );
	}

	/**
	 * Null-safe comparison that always sorts "no data" to the bottom.
	 *
	 * @param mixed $a
	 * @param mixed $b
	 */
	private static function perfCmp( $a, $b, bool $ascending ): int {
		$a_null = ( null === $a );
		$b_null = ( null === $b );
		if ( $a_null && $b_null ) {
			return 0;
		}
		if ( $a_null ) {
			return 1;
		}
		if ( $b_null ) {
			return -1;
		}
		return $ascending ? ( (float) $a <=> (float) $b ) : ( (float) $b <=> (float) $a );
	}

	private static function renderUserPerf( string $range, string $role, string $sort, int $paged, string $search ): void {
		$report   = self::perfService()->cached( $range );
		$sorts    = self::perfSorts();
		$intervals = UserPerformanceService::intervals();
		$interval = UserPerformanceService::interval();
		if ( ! array_key_exists( $sort, $sorts ) ) {
			$sort = 'slow';
		}
		?>
		<div style="display:flex;flex-wrap:wrap;gap:10px;align-items:center;justify-content:space-between;background:var(--zc-color-surface-lowest);border:1px solid var(--zc-color-divider);border-radius:8px;padding:12px 16px;margin-bottom:16px;">
			<div style="display:flex;flex-wrap:wrap;gap:10px;align-items:center;">
				<select data-perf-role="1">
					<option value="all"<?php selected( 'all', $role ); ?>><?php esc_html_e( 'Everyone', 'zymarg-communication' ); ?></option>
					<option value="seller"<?php selected( 'seller', $role ); ?>><?php esc_html_e( 'Sellers only', 'zymarg-communication' ); ?></option>
					<option value="buyer"<?php selected( 'buyer', $role ); ?>><?php esc_html_e( 'Buyers only', 'zymarg-communication' ); ?></option>
				</select>
				<select data-perf="sort-select" onchange="this.blur();" style="display:none;"></select>
				<input type="search" data-perf-search="1" value="<?php echo esc_attr( $search ); ?>" placeholder="<?php esc_attr_e( 'Search name or email, then press Enter', 'zymarg-communication' ); ?>" style="min-width:260px;" />
			</div>
			<div style="display:flex;flex-wrap:wrap;gap:10px;align-items:center;">
				<label style="font-size:12px;color:var(--zc-color-text-muted);"><?php esc_html_e( 'Recalculate:', 'zymarg-communication' ); ?></label>
				<select data-perf-timer="1">
					<?php foreach ( $intervals as $k => $label ) : ?>
					<option value="<?php echo esc_attr( $k ); ?>"<?php selected( $k, $interval ); ?>><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select>
				<button type="button" class="button button-primary" data-perf="rebuild"><?php esc_html_e( 'Refresh now', 'zymarg-communication' ); ?></button>
			</div>
		</div>
		<?php
		if ( null === $report ) {
			?>
			<div style="background:var(--zc-color-surface-lowest);border:1px solid var(--zc-color-divider);border-radius:8px;padding:28px;text-align:center;">
				<p style="font-size:14px;color:var(--zc-color-ink);margin:0 0 6px;"><strong><?php esc_html_e( 'Not calculated yet', 'zymarg-communication' ); ?></strong></p>
				<p style="color:var(--zc-color-neutral-text);margin:0;"><?php esc_html_e( 'Press "Refresh now" above to build the table for this date range. Nothing is calculated in the background until you choose a schedule.', 'zymarg-communication' ); ?></p>
			</div>
			<?php
			return;
		}

		$rows = isset( $report['rows'] ) ? (array) $report['rows'] : array();

		$rows = array_values(
			array_filter(
				$rows,
				static function ( $r ) use ( $role, $search ) {
					if ( 'all' !== $role && ( ! isset( $r['role'] ) || $r['role'] !== $role ) ) {
						return false;
					}
					if ( '' === $search ) {
						return true;
					}
					$hay = (string) ( $r['name'] ?? '' ) . ' ' . (string) ( $r['email'] ?? '' );
					return false !== stripos( $hay, $search );
				}
			)
		);

		usort(
			$rows,
			static function ( $a, $b ) use ( $sort ) {
				switch ( $sort ) {
					case 'fast':
						return self::perfCmp( $a['reply_med'] ?? null, $b['reply_med'] ?? null, true );
					case 'worst':
						return self::perfCmp( $a['rate'] ?? null, $b['rate'] ?? null, true );
					case 'messages':
						return ( (int) ( $b['messages'] ?? 0 ) ) <=> ( (int) ( $a['messages'] ?? 0 ) );
					case 'recent':
						return ( (int) ( $b['last_active'] ?? 0 ) ) <=> ( (int) ( $a['last_active'] ?? 0 ) );
					default:
						return self::perfCmp( $a['reply_med'] ?? null, $b['reply_med'] ?? null, false );
				}
			}
		);

		$total    = count( $rows );
		$per_page = 50;
		$pages    = max( 1, (int) ceil( $total / $per_page ) );
		$paged    = min( $paged, $pages );
		$slice    = array_slice( $rows, ( $paged - 1 ) * $per_page, $per_page );
		$built    = isset( $report['generated_at'] ) ? (int) $report['generated_at'] : 0;
		$took     = isset( $report['took_ms'] ) ? (int) $report['took_ms'] : 0;
		?>
		<p class="zcm-count">
			<?php
			printf(
				/* translators: 1: user count, 2: relative time, 3: milliseconds */
				esc_html__( '%1$s people with messaging activity. Last calculated %2$s and took %3$s ms.', 'zymarg-communication' ),
				esc_html( number_format_i18n( $total ) ),
				esc_html( $built > 0 ? human_time_diff( $built, time() ) . ' ' . __( 'ago', 'zymarg-communication' ) : __( 'never', 'zymarg-communication' ) ),
				esc_html( number_format_i18n( $took ) )
			);
			?>
		</p>

		<p style="margin:0 0 12px;display:flex;flex-wrap:wrap;gap:6px;align-items:center;">
			<span style="font-size:12px;color:var(--zc-color-text-muted);"><?php esc_html_e( 'Sort:', 'zymarg-communication' ); ?></span>
			<?php foreach ( $sorts as $key => $label ) : ?>
			<a href="#" data-perf="sort" data-sort="<?php echo esc_attr( $key ); ?>" class="button<?php echo $key === $sort ? ' button-primary' : ''; ?>" style="font-size:12px;height:auto;padding:2px 10px;"><?php echo esc_html( $label ); ?></a>
			<?php endforeach; ?>
		</p>

		<table class="wp-list-table widefat fixed striped">
			<thead>
				<tr>
					<th style="width:20%;"><?php esc_html_e( 'Person', 'zymarg-communication' ); ?></th>
					<th style="width:8%;"><?php esc_html_e( 'Role', 'zymarg-communication' ); ?></th>
					<th style="width:8%;"><?php esc_html_e( 'Messages', 'zymarg-communication' ); ?></th>
					<th style="width:8%;"><?php esc_html_e( 'Chats', 'zymarg-communication' ); ?></th>
					<th style="width:11%;"><?php esc_html_e( 'Typical reply', 'zymarg-communication' ); ?></th>
					<th style="width:9%;"><?php esc_html_e( 'Reply rate', 'zymarg-communication' ); ?></th>
					<th style="width:11%;"><?php esc_html_e( 'Longest wait', 'zymarg-communication' ); ?></th>
					<th style="width:25%;"><?php esc_html_e( 'Suggestions', 'zymarg-communication' ); ?></th>
				</tr>
			</thead>
			<tbody>
			<?php if ( empty( $slice ) ) : ?>
				<tr><td colspan="8"><?php esc_html_e( 'Nobody matches that filter.', 'zymarg-communication' ); ?></td></tr>
			<?php else : ?>
				<?php
				foreach ( $slice as $r ) :
					$tones = array(
						'bad'  => 'var(--zc-color-danger)',
						'warn' => '#b26a00',
						'good' => '#1a7f37',
						'ok'   => 'var(--zc-color-neutral-text)',
					);
					$role_label = 'seller' === ( $r['role'] ?? '' )
						? __( 'Seller', 'zymarg-communication' )
						: ( 'gone' === ( $r['role'] ?? '' ) ? __( 'Removed', 'zymarg-communication' ) : __( 'Buyer', 'zymarg-communication' ) );
					$last = (int) ( $r['last_active'] ?? 0 );
					?>
					<tr>
						<td>
							<strong><?php echo esc_html( (string) ( $r['name'] ?? '' ) ); ?></strong>
							<?php if ( ! empty( $r['email'] ) ) : ?>
							<div style="font-size:11px;color:var(--zc-color-neutral-text);"><?php echo esc_html( (string) $r['email'] ); ?></div>
							<?php endif; ?>
							<?php if ( $last > 0 ) : ?>
							<div style="font-size:11px;color:var(--zc-color-neutral-text);"><?php printf( esc_html__( 'active %s ago', 'zymarg-communication' ), esc_html( human_time_diff( $last, time() ) ) ); ?></div>
							<?php endif; ?>
						</td>
						<td><?php echo esc_html( $role_label ); ?></td>
						<td><?php echo esc_html( number_format_i18n( (int) ( $r['messages'] ?? 0 ) ) ); ?></td>
						<td><?php echo esc_html( number_format_i18n( (int) ( $r['convs'] ?? 0 ) ) ); ?></td>
						<td><?php echo esc_html( self::humanDuration( $r['reply_med'] ?? null ) ); ?></td>
						<td><?php echo esc_html( self::formatRate( $r['rate'] ?? null ) ); ?></td>
						<td><?php echo esc_html( self::humanDuration( $r['longest'] ?? null ) ); ?></td>
						<td>
							<?php foreach ( UserPerformanceService::suggestions( (array) $r ) as $tip ) : ?>
							<div style="font-size:12px;color:<?php echo esc_attr( $tones[ $tip['tone'] ] ?? $tones['ok'] ); ?>;margin-bottom:2px;"><?php echo esc_html( $tip['text'] ); ?></div>
							<?php endforeach; ?>
						</td>
					</tr>
				<?php endforeach; ?>
			<?php endif; ?>
			</tbody>
		</table>

		<?php if ( $pages > 1 ) : ?>
		<div style="margin-top:14px;display:flex;gap:6px;align-items:center;flex-wrap:wrap;">
			<?php for ( $i = 1; $i <= $pages; $i++ ) : ?>
			<a href="#" data-perf="page" data-page="<?php echo (int) $i; ?>" class="button<?php echo $i === $paged ? ' button-primary' : ''; ?>" style="font-size:12px;height:auto;padding:2px 10px;"><?php echo (int) $i; ?></a>
			<?php endfor; ?>
		</div>
		<?php endif; ?>
		<?php
	}

}
