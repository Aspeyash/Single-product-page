<?php
/**
 * ZYMARG Communication — Installer.
 *
 * Runs on plugin activation and deactivation. Owns first-run schema setup,
 * default feature flag state, default options, and creation of plugin-owned
 * pages. Never deletes data on deactivation.
 *
 * @package    ZymargCommunication
 * @version    1.2.0
 */

namespace ZymargCommunication\Bootstrap;

use ZymargCommunication\Infrastructure\Database\Migrations\AddArchivedAtToMessagesTable;
use ZymargCommunication\Infrastructure\Database\Migrations\CreateApiKeysTable;
use ZymargCommunication\Infrastructure\Database\Migrations\CreateWebhooksTable;
use ZymargCommunication\Infrastructure\Database\Migrations\CreateAnalyticsEventsTable;
use ZymargCommunication\Infrastructure\Database\Migrations\CreateAttachmentsTable;
use ZymargCommunication\Infrastructure\Database\Migrations\CreateAuditLogsTable;
use ZymargCommunication\Infrastructure\Database\Migrations\CreateConversationsTable;
use ZymargCommunication\Infrastructure\Database\Migrations\CreateFeatureFlagsTable;
use ZymargCommunication\Infrastructure\Database\Migrations\CreateMessagesTable;
use ZymargCommunication\Infrastructure\Database\Migrations\CreateModerationLogsTable;
use ZymargCommunication\Infrastructure\Database\Migrations\CreateNotificationsTable;
use ZymargCommunication\Infrastructure\Database\Migrations\CreateParticipantsTable;
use ZymargCommunication\Infrastructure\Database\Migrations\CreateReactionsTable;
use ZymargCommunication\Infrastructure\Database\Migrations\AddSessionColumnsToSupportTickets;
use ZymargCommunication\Infrastructure\Database\Migrations\CreateSupportTicketsTable;
use ZymargCommunication\Modules\FeatureFlags\FlagRegistry;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Installer {

	public const VERSION_OPTION = 'zymarg_comm_version';

	/**
	 * Ordered list of migrations. Order matters — `AddArchivedAtToMessagesTable`
	 * must run after `CreateMessagesTable`.
	 *
	 * @var array<int, class-string>
	 */
	public const MIGRATIONS = [
		CreateFeatureFlagsTable::class,
		CreateConversationsTable::class,
		CreateParticipantsTable::class,
		CreateMessagesTable::class,
		CreateAttachmentsTable::class,
		CreateReactionsTable::class,
		CreateNotificationsTable::class,
		CreateModerationLogsTable::class,
		CreateAnalyticsEventsTable::class,
		CreateAuditLogsTable::class,
		CreateWebhooksTable::class,
		CreateApiKeysTable::class,
		AddArchivedAtToMessagesTable::class,
		CreateSupportTicketsTable::class,
		// Must run after CreateSupportTicketsTable — it alters that table.
		AddSessionColumnsToSupportTickets::class,
	];

	// ── Activation ───────────────────────────────────────────────────────────
	public static function activate(): void {
		self::assertEnvironment();

		self::runMigrations();
		self::writeDefaultFeatureFlags();
		self::writeDefaultSettings();

		PageRegistrar::create();

		update_option( self::VERSION_OPTION, ZYMARG_COMM_VERSION );

		flush_rewrite_rules();

		do_action( 'zymarg_comm_activated' );
	}

	public static function deactivate(): void {
		Scheduler::clear();
		flush_rewrite_rules();

		do_action( 'zymarg_comm_deactivated' );
		// Never delete data on deactivation.
	}

	// ── Migration runner ────────────────────────────────────────────────────────
	private static function runMigrations(): void {
		foreach ( self::MIGRATIONS as $migration ) {
			/** @var \ZymargCommunication\Core\Abstracts\AbstractMigration $instance */
			$instance = new $migration();
			$instance->up();
		}
	}

	// ── Environment guards ───────────────────────────────────────────────────────
	private static function assertEnvironment(): void {
		if ( version_compare( PHP_VERSION, ZYMARG_COMM_MIN_PHP, '<' ) ) {
			deactivate_plugins( ZYMARG_COMM_BASENAME );
			wp_die(
				esc_html__( 'ZYMARG Communication requires PHP 8.1 or higher.', 'zymarg-communication' ),
				esc_html__( 'Plugin activation error', 'zymarg-communication' ),
				[ 'back_link' => true ]
			);
		}

		global $wp_version;
		if ( version_compare( (string) $wp_version, ZYMARG_COMM_MIN_WP, '<' ) ) {
			deactivate_plugins( ZYMARG_COMM_BASENAME );
			wp_die(
				esc_html__( 'ZYMARG Communication requires WordPress 6.0 or higher.', 'zymarg-communication' ),
				esc_html__( 'Plugin activation error', 'zymarg-communication' ),
				[ 'back_link' => true ]
			);
		}
	}

	// ── Default settings ─────────────────────────────────────────────────────────
	private static function writeDefaultSettings(): void {
		$defaults = [
			'realtime_driver'          => 'pusher',
			'admin_menu_label'         => 'Communication',
			'buyer_inbox_slug'         => 'messages',
			'vendor_inbox_slug'        => 'vendor-messages',
			'max_upload_size_bytes'    => 5 * 1024 * 1024,
			'max_image_dimension'      => 4096,
			'message_archive_days'     => 90,
			'message_delete_days'      => 365,
		];

		foreach ( $defaults as $key => $value ) {
			$option_name = 'zymarg_comm_' . $key;
			if ( get_option( $option_name, null ) === null ) {
				add_option( $option_name, $value );
			}
		}
	}

	// ── Feature flag defaults ──────────────────────────────────────────────────────
	/**
	 * Insert the default state for every feature flag on first activation.
	 * Existing rows are preserved.
	 *
	 * Phase 2: delegates to `FlagRegistry::writeDefaults()`, which reads each
	 * `Modules/FeatureFlags/Definitions/*` class as the single source of truth.
	 */
	private static function writeDefaultFeatureFlags(): void {
		FlagRegistry::writeDefaults();
	}
}
