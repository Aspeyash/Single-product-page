<?php
/**
 * AdminSupportPage — the "Support" submenu (named "Admin⇄User" before 1.32.15).
 *
 * One screen that owns the whole support surface:
 *  - master on/off switch (the feature ships OFF)
 *  - the support agent pool (grant/revoke without handing out admin access)
 *  - copy-paste shortcode reference for placing it anywhere, any name
 *  - the live inbox, rendered with the SAME markup and the SAME
 *    inbox.css / inbox.js as the buyer and vendor inboxes, so the chatbox is
 *    identical by construction rather than by imitation.
 *
 * @package ZymargCommunication
 * @since   1.25.0
 */

namespace ZymargCommunication\Bootstrap;

use ZymargCommunication\Frontend\SupportChat;
use ZymargCommunication\Modules\FeatureFlags\Repositories\FeatureFlagRepository;
use ZymargCommunication\Modules\Support\Repositories\SupportRepository;
use ZymargCommunication\Modules\Support\Services\SupportIdentitySettings;
use ZymargCommunication\Modules\Support\Services\SupportService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdminSupportPage {

	private static bool $registered = false;
	public const MENU_SLUG     = 'zymarg-comm-support';
	private const NONCE_ACTION = 'zymarg_comm_support_admin';

	public static function register(): void {
		if ( self::$registered ) {
			return;
		}
		self::$registered = true;

		add_action( 'admin_menu', array( self::class, 'registerMenu' ), 50 );
		add_action( 'admin_enqueue_scripts', array( self::class, 'enqueueInbox' ) );
		add_action( 'wp_ajax_zymarg_comm_support_toggle', array( self::class, 'handleToggle' ) );
		add_action( 'wp_ajax_zymarg_comm_support_agent', array( self::class, 'handleAgent' ) );
		add_action( 'wp_ajax_zymarg_comm_support_default', array( self::class, 'handleDefault' ) );
		add_action( 'wp_ajax_zymarg_comm_support_alias', array( self::class, 'handleAlias' ) );
	}

	public static function registerMenu(): void {
		// 1.32.15 — the label is plainly "Support". The old "Admin⇄User" read as
		// "Admin User" in the sidebar (the ⇄ glyph is easy to miss at 13px), which
		// looked like a user account rather than a place to answer customers.
		// The SLUG is deliberately unchanged, so every existing bookmark,
		// redirect and admin.php?page= link keeps working.
		add_submenu_page(
			AdminMenu::MENU_SLUG,
			__( 'Support', 'zymarg-communication' ),
			__( 'Support', 'zymarg-communication' ),
			'manage_options',
			self::MENU_SLUG,
			array( self::class, 'render' )
		);
	}

	/**
	 * Load the REAL frontend inbox assets on this screen only.
	 *
	 * This is what guarantees the chatbox is 100% identical to the buyer and
	 * vendor inboxes: same stylesheet, same script, same markup. Every fix from
	 * 1.24.x carries over automatically and can never drift.
	 */
	public static function enqueueInbox( string $hook = '' ): void {
		$page = isset( $_GET['page'] ) ? sanitize_key( (string) wp_unslash( $_GET['page'] ) ) : '';
		if ( self::MENU_SLUG !== $page ) {
			return;
		}

		$base    = defined( 'ZYMARG_COMM_URL' ) ? ZYMARG_COMM_URL : plugin_dir_url( ZYMARG_COMM_FILE );
		$version = defined( 'ZYMARG_COMM_VERSION' ) ? ZYMARG_COMM_VERSION : '1.25.0';

		// Brand tokens power both the inbox and the ticket panel. The frontend
		// gets these via AssetEnqueue; wp-admin does not, so enqueue explicitly
		// or the ticket panel would fall back to its hard-coded palette only.
		wp_enqueue_style(
			'zymarg-comm-tokens',
			$base . 'assets/css/frontend/zymarg-comm-tokens.css',
			array(),
			$version
		);
		wp_enqueue_style(
			'zymarg-inbox',
			$base . 'assets/css/frontend/inbox.css',
			array( 'zymarg-comm-tokens' ),
			$version
		);
		wp_enqueue_script(
			'zymarg-inbox',
			$base . 'assets/js/frontend/inbox.js',
			array(),
			$version,
			true
		);

		// Ticket panel (1.27.0): status pill, requester identity, order/vendor
		// context, history and Resolve/Reopen/Close — this is where the agent
		// actually works, so it must be here as well as on the frontend.
		wp_enqueue_style(
			'zymarg-support-ticket',
			$base . 'assets/css/frontend/support-ticket.css',
			array( 'zymarg-comm-tokens' ),
			$version
		);
		wp_enqueue_script(
			'zymarg-support-ticket',
			$base . 'assets/js/frontend/support-ticket.js',
			array(),
			$version,
			true
		);
		wp_localize_script(
			'zymarg-support-ticket',
			'zymargSupportTicket',
			array(
				'restUrl'         => esc_url_raw( rest_url( 'zymarg-comm/v1' ) ),
				'nonce'           => wp_create_nonce( 'wp_rest' ),
				// Anyone who can reach this screen and answer is an agent here.
				'isAgent'         => true,
				'currencySymbols' => self::currencyMap(),
				'i18n'            => self::ticketStrings(),
			)
		);
	}

	/** @return array<string, string> */
	private static function currencyMap(): array {
		if ( ! function_exists( 'get_woocommerce_currency' ) || ! function_exists( 'get_woocommerce_currency_symbol' ) ) {
			return array();
		}
		$currency = (string) get_woocommerce_currency();

		return $currency ? array( $currency => html_entity_decode( (string) get_woocommerce_currency_symbol() ) ) : array();
	}

	/** @return array<string, string> */
	private static function ticketStrings(): array {
		return array(
			'markResolved' => __( 'Mark resolved', 'zymarg-communication' ),
			'reopen'       => __( 'Reopen', 'zymarg-communication' ),
			'close'        => __( 'Close', 'zymarg-communication' ),
			'memberSince'  => __( 'Member since', 'zymarg-communication' ),
			'orders'       => __( 'orders', 'zymarg-communication' ),
			'vendor'       => __( 'Vendor', 'zymarg-communication' ),
			'priorTickets' => __( 'previous tickets', 'zymarg-communication' ),
			'resolved'     => __( 'resolved', 'zymarg-communication' ),
			'howDidWeDo'   => __( 'How did we do?', 'zymarg-communication' ),
			'thanksRating' => __( 'Thanks for your feedback!', 'zymarg-communication' ),
			// 1.31.0 helpline session controls. This map is a deliberate duplicate
			// of AssetEnqueue::ticketStrings() because the agent panel is rendered
			// in wp-admin as well as on the frontend — new labels must be added to
			// BOTH or the agent screen falls back to the English literals in JS.
			'sessionPause'  => __( 'Pause timer', 'zymarg-communication' ),
			'sessionResume' => __( 'Resume timer', 'zymarg-communication' ),
			'sessionExtend' => __( 'Give more time', 'zymarg-communication' ),
			'sessionPaused' => __( 'The countdown is paused by our team.', 'zymarg-communication' ),
			// 1.32.1 — kept in sync with SupportSessionSettings::frontendStrings().
			'sessionClosesIn' => __( 'This case closes in %s if you do not reply.', 'zymarg-communication' ),
		);
	}

	private static function support(): ?SupportService {
		if ( ! ServiceProvider::has( SupportService::class ) ) {
			return null;
		}

		return ServiceProvider::get( SupportService::class );
	}

	// =========================================================================
	// Render
	// =========================================================================

	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$support = self::support();
		$enabled = $support instanceof SupportService ? $support->enabled() : false;
		$agents  = $support instanceof SupportService ? $support->agentIds() : array();
		$default = (int) get_option( SupportService::OPTION_DEFAULT_AGENT, 0 );
		$label   = $support instanceof SupportService ? $support->label() : '';
		$nonce    = wp_create_nonce( self::NONCE_ACTION );
		$ajax     = admin_url( 'admin-ajax.php' );
		$repo     = new SupportRepository();
		$total    = $repo->countAll();
		$identity = new SupportIdentitySettings();
		?>
		<div class="wrap zcm-admin-page">
		<?php
		AdminMenu::renderHeader(
			__( 'Support', 'zymarg-communication' ),
			__( 'Direct messaging between your team and your users', 'zymarg-communication' )
		);
		?>

		<style>
		.zcs-card{background:var(--zc-color-surface-lowest,#fff);border:1px solid var(--zc-color-divider);border-radius:8px;padding:20px 24px;margin:20px 0;box-shadow:0 1px 3px rgba(0,0,0,.05);}
		.zcs-row{display:flex;align-items:center;gap:16px;flex-wrap:wrap;}
		.zcs-row-main{flex:1;min-width:240px;}
		.zcs-title{font-size:15px;font-weight:600;margin:0 0 4px;color:var(--zc-color-ink);}
		.zcs-desc{color:var(--zc-color-text-muted);font-size:13px;margin:0;}
		.zcs-toggle{position:relative;display:inline-block;width:44px;height:24px;flex-shrink:0;}
		.zcs-toggle input{opacity:0;width:0;height:0;}
		.zcs-slider{position:absolute;cursor:pointer;inset:0;background:var(--zc-color-outline);border-radius:24px;transition:.3s;}
		.zcs-slider:before{position:absolute;content:"";height:18px;width:18px;left:3px;bottom:3px;background:#fff;border-radius:50%;transition:.3s;}
		.zcs-toggle input:checked+.zcs-slider{background:var(--zc-color-success);}
		.zcs-toggle input:checked+.zcs-slider:before{transform:translateX(20px);}
		.zcs-code{font-family:monospace;font-size:12px;background:var(--zc-color-surface-low,#f6f7f7);border:1px solid var(--zc-color-divider);border-radius:4px;padding:3px 7px;display:inline-block;}
		.zcs-off{opacity:.55;pointer-events:none;}
		.zcs-note{font-size:12px;color:var(--zc-color-neutral-text);margin-top:6px;}
		.zcs-inbox-wrap{margin-top:8px;border:1px solid var(--zc-color-divider);border-radius:8px;overflow:hidden;}
		</style>

		<!-- Master switch -->
		<div class="zcs-card">
			<div class="zcs-row">
				<div class="zcs-row-main">
					<p class="zcs-title"><?php esc_html_e( 'Enable support messaging', 'zymarg-communication' ); ?></p>
					<p class="zcs-desc"><?php esc_html_e( 'Off by default. While off, the shortcodes render nothing and the support API returns 403 — nothing else on your site is affected.', 'zymarg-communication' ); ?></p>
				</div>
				<label class="zcs-toggle">
					<input type="checkbox" id="zcs-master" <?php checked( $enabled ); ?> />
					<span class="zcs-slider"></span>
				</label>
				<span id="zcs-master-state" class="zcs-note"></span>
			</div>
			<p class="zcs-note">
				<?php esc_html_e( 'Feature flag:', 'zymarg-communication' ); ?>
				<span class="zcs-code"><?php echo esc_html( SupportService::FLAG ); ?></span>
				&nbsp;•&nbsp;
				<?php
				printf(
					/* translators: %d: number of support threads. */
					esc_html__( '%d support thread(s) so far', 'zymarg-communication' ),
					(int) $total
				);
				?>
			</p>
		</div>

		<!-- Agent pool -->
		<div class="zcs-card">
			<p class="zcs-title"><?php esc_html_e( 'Support agents', 'zymarg-communication' ); ?></p>
			<p class="zcs-desc">
				<?php esc_html_e( 'Anyone listed here can answer support threads from this screen or from their own Messages inbox. Granting this does not give WordPress admin access.', 'zymarg-communication' ); ?>
			</p>

			<p class="zcs-desc" style="margin-top:10px;">
				<?php
				printf(
					/* translators: %s: the site-wide default public name, e.g. "Alpha". */
					esc_html__( 'Public name is what CUSTOMERS see — on the typing indicator and in notifications. Leave a row blank and that agent is shown as %s. Real names and emails here are only ever visible to you.', 'zymarg-communication' ),
					'<strong>' . esc_html( $identity->defaultAlias() ) . '</strong>'
				);
				?>
			</p>

			<table class="widefat striped" style="margin-top:14px;max-width:980px;">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Agent', 'zymarg-communication' ); ?></th>
						<th><?php esc_html_e( 'Email', 'zymarg-communication' ); ?></th>
						<th><?php esc_html_e( 'Public name', 'zymarg-communication' ); ?></th>
						<th><?php esc_html_e( 'Threads', 'zymarg-communication' ); ?></th>
						<th><?php esc_html_e( 'Default', 'zymarg-communication' ); ?></th>
						<th><?php esc_html_e( 'Action', 'zymarg-communication' ); ?></th>
					</tr>
				</thead>
				<tbody>
				<?php if ( empty( $agents ) ) : ?>
					<tr><td colspan="6"><?php esc_html_e( 'No agents yet.', 'zymarg-communication' ); ?></td></tr>
				<?php else : ?>
					<?php foreach ( $agents as $agent_id ) : ?>
						<?php
						$user = get_userdata( (int) $agent_id );
						if ( ! $user ) {
							continue;
						}
						?>
						<tr>
							<td><strong><?php echo esc_html( (string) $user->display_name ); ?></strong></td>
							<td><?php echo esc_html( (string) $user->user_email ); ?></td>
							<td>
								<input
									type="text"
									class="zcs-alias"
									data-user="<?php echo esc_attr( (string) (int) $agent_id ); ?>"
									value="<?php echo esc_attr( $identity->rawAliasForAgent( (int) $agent_id ) ); ?>"
									placeholder="<?php echo esc_attr( $identity->defaultAlias() ); ?>"
									maxlength="<?php echo esc_attr( (string) \ZymargCommunication\Modules\Support\Services\SupportIdentitySettings::MAX_LENGTH ); ?>"
									style="width:150px;"
								/>
								<span class="zcs-alias-state zcs-note"></span>
							</td>
							<td><?php echo esc_html( (string) $repo->loadForAgent( (int) $agent_id ) ); ?></td>
							<td>
								<input type="radio" name="zcs-default" class="zcs-default" value="<?php echo esc_attr( (string) (int) $agent_id ); ?>" <?php checked( $default, (int) $agent_id ); ?> />
							</td>
							<td>
								<button type="button" class="button button-small zcs-revoke" data-user="<?php echo esc_attr( (string) (int) $agent_id ); ?>"><?php esc_html_e( 'Remove', 'zymarg-communication' ); ?></button>
							</td>
						</tr>
					<?php endforeach; ?>
				<?php endif; ?>
				</tbody>
			</table>

			<p style="margin-top:14px;">
				<label for="zcs-add-agent"><?php esc_html_e( 'Add an agent:', 'zymarg-communication' ); ?></label>
				<input type="text" id="zcs-add-agent" class="regular-text" placeholder="<?php esc_attr_e( 'username or email', 'zymarg-communication' ); ?>" />
				<button type="button" class="button" id="zcs-add-btn"><?php esc_html_e( 'Grant access', 'zymarg-communication' ); ?></button>
				<span id="zcs-add-state" class="zcs-note"></span>
			</p>

			<p style="margin-top:18px;padding-top:14px;border-top:1px solid var(--zc-color-divider);">
				<label for="zcs-alias-default"><strong><?php esc_html_e( 'Default public name:', 'zymarg-communication' ); ?></strong></label>
				<input
					type="text"
					id="zcs-alias-default"
					value="<?php echo esc_attr( $identity->defaultAlias() ); ?>"
					placeholder="<?php echo esc_attr( \ZymargCommunication\Modules\Support\Services\SupportIdentitySettings::DEFAULT_ALIAS ); ?>"
					maxlength="<?php echo esc_attr( (string) \ZymargCommunication\Modules\Support\Services\SupportIdentitySettings::MAX_LENGTH ); ?>"
					style="width:150px;"
				/>
				<button type="button" class="button" id="zcs-alias-default-btn"><?php esc_html_e( 'Save', 'zymarg-communication' ); ?></button>
				<span id="zcs-alias-default-state" class="zcs-note"></span>
			</p>
			<p class="zcs-note">
				<?php esc_html_e( 'Used for any agent without a name of their own. Leaving every agent blank gives your whole team one shared public persona, which is usually what you want on a helpline.', 'zymarg-communication' ); ?>
			</p>
		</div>

		<!-- Placement -->
		<div class="zcs-card">
			<p class="zcs-title"><?php esc_html_e( 'Where to put it', 'zymarg-communication' ); ?></p>
			<p class="zcs-desc"><?php esc_html_e( 'Drop the shortcode on any page, in any widget, under any name you like. Every attribute is optional.', 'zymarg-communication' ); ?></p>
			<table class="widefat striped" style="margin-top:12px;max-width:820px;">
				<tbody>
					<tr>
						<td style="width:44%;"><span class="zcs-code">[zymarg_support_chat]</span></td>
						<td><?php echo esc_html( sprintf( __( 'Button labelled "%s".', 'zymarg-communication' ), $label ) ); ?></td>
					</tr>
					<tr>
						<td><span class="zcs-code">[zymarg_support_chat label="Alpha"]</span></td>
						<td><?php esc_html_e( 'Same button, your wording.', 'zymarg-communication' ); ?></td>
					</tr>
					<tr>
						<td><span class="zcs-code">[zymarg_support_chat mode="inline"]</span></td>
						<td><?php esc_html_e( 'Full inbox embedded in the page, identical to the buyer inbox.', 'zymarg-communication' ); ?></td>
					</tr>
					<tr>
						<td><span class="zcs-code">[zymarg_support_chat mode="link" label="Need help?"]</span></td>
						<td><?php esc_html_e( 'Plain text link instead of a button.', 'zymarg-communication' ); ?></td>
					</tr>
					<tr>
						<td><span class="zcs-code">[zymarg_contact_support]</span> / <span class="zcs-code">[zymarg_support]</span></td>
						<td><?php esc_html_e( 'Aliases — identical behaviour, friendlier names.', 'zymarg-communication' ); ?></td>
					</tr>
				</tbody>
			</table>
			<p class="zcs-note">
				<?php esc_html_e( 'For a future app, the REST surface is: GET /support/config, POST /support/start, GET /support/threads, GET /support/agents — under', 'zymarg-communication' ); ?>
				<span class="zcs-code">zymarg-comm/v1</span>.
			</p>
		</div>

		<!-- Live inbox -->
		<div class="zcs-card">
			<p class="zcs-title"><?php esc_html_e( 'Support inbox', 'zymarg-communication' ); ?></p>
			<?php if ( ! $enabled ) : ?>
				<p class="zcs-desc"><?php esc_html_e( 'Turn the feature on above to start receiving messages.', 'zymarg-communication' ); ?></p>
			<?php else : ?>
				<p class="zcs-desc"><?php esc_html_e( 'Replies you send here come from your own account and appear in the user’s Messages inbox.', 'zymarg-communication' ); ?></p>
				<div class="zcs-inbox-wrap">
					<?php
					// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo SupportChat::inboxRoot(
						'support',
						__( 'Support', 'zymarg-communication' ),
						get_current_user_id(),
						__( 'Select a conversation to view your messages.', 'zymarg-communication' )
					);
					?>
				</div>
			<?php endif; ?>
		</div>

		<script>
		(function(){
			var ajax  = <?php echo wp_json_encode( $ajax ); ?>;
			var nonce = <?php echo wp_json_encode( $nonce ); ?>;

			function post(action, fields, done){
				var d = new FormData();
				d.append('action', action);
				d.append('_wpnonce', nonce);
				Object.keys(fields || {}).forEach(function(k){ d.append(k, fields[k]); });
				fetch(ajax, { method:'POST', credentials:'same-origin', body:d })
					.then(function(r){ return r.json(); })
					.then(function(j){ done(j && j.success, j && j.data); })
					.catch(function(){ done(false, null); });
			}

			var master = document.getElementById('zcs-master');
			var mstate = document.getElementById('zcs-master-state');
			if (master) {
				master.addEventListener('change', function(){
					var on = master.checked ? '1' : '0';
					master.disabled = true;
					if (mstate) mstate.textContent = <?php echo wp_json_encode( __( 'Saving…', 'zymarg-communication' ) ); ?>;
					post('zymarg_comm_support_toggle', { enabled: on }, function(ok){
						master.disabled = false;
						if (mstate) mstate.textContent = '';
						if (ok) { window.location.reload(); }
						else { master.checked = !master.checked; }
					});
				});
			}

			var addBtn = document.getElementById('zcs-add-btn');
			if (addBtn) {
				addBtn.addEventListener('click', function(){
					var input = document.getElementById('zcs-add-agent');
					var state = document.getElementById('zcs-add-state');
					var who = input ? input.value.trim() : '';
					if (!who) return;
					addBtn.disabled = true;
					post('zymarg_comm_support_agent', { who: who, grant: '1' }, function(ok, data){
						addBtn.disabled = false;
						if (ok) { window.location.reload(); return; }
						if (state) state.textContent = (data && data.message) ? data.message : 'Error';
					});
				});
			}

			document.querySelectorAll('.zcs-revoke').forEach(function(btn){
				btn.addEventListener('click', function(){
					btn.disabled = true;
					post('zymarg_comm_support_agent', { who: btn.getAttribute('data-user'), grant: '0' }, function(ok){
						btn.disabled = false;
						if (ok) window.location.reload();
					});
				});
			});

			document.querySelectorAll('.zcs-default').forEach(function(radio){
				radio.addEventListener('change', function(){
					if (!radio.checked) return;
					post('zymarg_comm_support_default', { user_id: radio.value }, function(){});
				});
			});

			// 1.32.15 — per-agent public name. Saves on blur and on Enter, so the
			// owner never has to hunt for a button. No reload: the value is only
			// read by the customer-facing surfaces, so nothing on this screen
			// needs to be repainted.
			var savedTxt = <?php echo wp_json_encode( __( 'Saved', 'zymarg-communication' ) ); ?>;
			var errTxt   = <?php echo wp_json_encode( __( 'Not saved', 'zymarg-communication' ) ); ?>;

			document.querySelectorAll('.zcs-alias').forEach(function(input){
				var last  = input.value;
				var state = input.parentNode.querySelector('.zcs-alias-state');

				function save(){
					if (input.value === last) return;
					last = input.value;
					if (state) state.textContent = '…';
					post('zymarg_comm_support_alias', {
						user_id: input.getAttribute('data-user'),
						alias:   input.value
					}, function(ok, data){
						if (ok && data && typeof data.alias === 'string') {
							// Echo the SERVER's cleaned value, so a trimmed or
							// truncated name is visible immediately rather than
							// looking saved-as-typed.
							input.value = data.alias;
							last = data.alias;
						}
						if (state) state.textContent = ok ? savedTxt : errTxt;
						setTimeout(function(){ if (state) state.textContent = ''; }, 2000);
					});
				}

				input.addEventListener('blur', save);
				input.addEventListener('keydown', function(e){
					if (e.key === 'Enter') { e.preventDefault(); input.blur(); }
				});
			});

			var dBtn   = document.getElementById('zcs-alias-default-btn');
			var dInput = document.getElementById('zcs-alias-default');
			var dState = document.getElementById('zcs-alias-default-state');
			if (dBtn && dInput) {
				dBtn.addEventListener('click', function(){
					dBtn.disabled = true;
					if (dState) dState.textContent = '…';
					post('zymarg_comm_support_alias', { scope: 'default', alias: dInput.value }, function(ok, data){
						dBtn.disabled = false;
						if (ok && data && typeof data.alias === 'string') dInput.value = data.alias;
						if (dState) dState.textContent = ok ? savedTxt : errTxt;
						setTimeout(function(){ if (dState) dState.textContent = ''; }, 2000);
					});
				});
			}
		})();
		</script>
		</div>
		<?php
	}

	// =========================================================================
	// AJAX handlers
	// =========================================================================

	public static function handleToggle(): void {
		check_ajax_referer( self::NONCE_ACTION );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'zymarg-communication' ) ) );
		}

		$enabled = isset( $_POST['enabled'] ) && '1' === (string) wp_unslash( $_POST['enabled'] );

		$repo = new FeatureFlagRepository();
		$repo->setEnabled( SupportService::FLAG, $enabled );

		wp_send_json_success( array( 'enabled' => $enabled ) );
	}

	public static function handleAgent(): void {
		check_ajax_referer( self::NONCE_ACTION );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'zymarg-communication' ) ) );
		}

		$who   = isset( $_POST['who'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['who'] ) ) : '';
		$grant = isset( $_POST['grant'] ) && '1' === (string) wp_unslash( $_POST['grant'] );

		$user = null;
		if ( ctype_digit( $who ) ) {
			$user = get_userdata( (int) $who );
		}
		if ( ! $user && is_email( $who ) ) {
			$user = get_user_by( 'email', $who );
		}
		if ( ! $user ) {
			$user = get_user_by( 'login', $who );
		}
		if ( ! $user ) {
			wp_send_json_error( array( 'message' => __( 'User not found.', 'zymarg-communication' ) ) );
		}

		if ( $grant ) {
			$user->add_cap( SupportService::CAPABILITY );
		} else {
			$user->remove_cap( SupportService::CAPABILITY );

			// Administrators inherit the capability from their role, so a
			// per-user removal alone would not stick. Record an explicit deny.
			if ( user_can( $user->ID, SupportService::CAPABILITY ) ) {
				$user->add_cap( SupportService::CAPABILITY, false );
			}

			if ( (int) get_option( SupportService::OPTION_DEFAULT_AGENT, 0 ) === (int) $user->ID ) {
				update_option( SupportService::OPTION_DEFAULT_AGENT, 0, false );
			}
		}

		wp_send_json_success( array( 'user_id' => (int) $user->ID, 'granted' => $grant ) );
	}

	/**
	 * Save a public name — one agent's, or the site-wide default.
	 *
	 * `scope=default` writes the fallback; otherwise `user_id` must be a real
	 * account. Returns the CLEANED value so the field can show exactly what was
	 * stored (trimmed, collapsed, truncated) instead of what was typed.
	 *
	 * @since 1.32.15
	 */
	public static function handleAlias(): void {
		check_ajax_referer( self::NONCE_ACTION );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'zymarg-communication' ) ) );
		}

		$alias    = isset( $_POST['alias'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['alias'] ) ) : '';
		$scope    = isset( $_POST['scope'] ) ? sanitize_key( wp_unslash( (string) $_POST['scope'] ) ) : '';
		$identity = new SupportIdentitySettings();

		if ( 'default' === $scope ) {
			$identity->setDefaultAlias( $alias );

			wp_send_json_success( array( 'alias' => $identity->defaultAlias() ) );
		}

		$user_id = isset( $_POST['user_id'] ) ? absint( wp_unslash( $_POST['user_id'] ) ) : 0;
		if ( $user_id < 1 || ! get_userdata( $user_id ) ) {
			wp_send_json_error( array( 'message' => __( 'User not found.', 'zymarg-communication' ) ) );
		}

		$identity->setAliasForAgent( $user_id, $alias );

		wp_send_json_success(
			array(
				'user_id' => $user_id,
				// The stored override, which is '' when the agent inherits the
				// default — so clearing the box visibly clears it.
				'alias'   => $identity->rawAliasForAgent( $user_id ),
			)
		);
	}

	public static function handleDefault(): void {
		check_ajax_referer( self::NONCE_ACTION );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'zymarg-communication' ) ) );
		}

		$user_id = isset( $_POST['user_id'] ) ? absint( wp_unslash( $_POST['user_id'] ) ) : 0;
		update_option( SupportService::OPTION_DEFAULT_AGENT, $user_id, false );

		wp_send_json_success( array( 'user_id' => $user_id ) );
	}
}
