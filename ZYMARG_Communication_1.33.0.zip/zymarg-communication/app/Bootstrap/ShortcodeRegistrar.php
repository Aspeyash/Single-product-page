<?php
/**
 * ZYMARG Communication — Shortcode registrar.
 *
 * The ONLY file that calls `add_shortcode()`. Registers every plugin
 * shortcode and delegates rendering to the Frontend classes.
 *
 * Ecosystem-facing names (v1.12.0):
 *   [zymarg_my_messages]        Buyer inbox   (name expected by ZYMARG
 *                                              Vendor Dashboard plugin).
 *   [zymarg_vendor_messages]    Vendor inbox  (standalone use).
 *   [zymarg_live_chat]          Floating live-chat widget.
 *   [zymarg_unread_count]       Unread badge (for menu items etc.).
 *
 * Legacy aliases kept for backwards compatibility with older Phase 1–11
 * installs:
 *   [zymarg_comm_buyer_inbox]
 *   [zymarg_comm_vendor_inbox]
 *   [zymarg_comm_popup]
 *   [zymarg_comm_chat]
 *   [zymarg_comm_unread_count]
 *
 * @package    ZymargCommunication
 * @version    1.12.0
 */

namespace ZymargCommunication\Bootstrap;

use ZymargCommunication\Frontend\BuyerInbox;
use ZymargCommunication\Frontend\LiveChat;
use ZymargCommunication\Frontend\SupportChat;
use ZymargCommunication\Frontend\VendorInbox;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ShortcodeRegistrar {

	public static function register(): void {
		// Ecosystem-facing shortcodes.
		add_shortcode( 'zymarg_my_messages',     array( BuyerInbox::class,  'render' ) );
		add_shortcode( 'zymarg_vendor_messages', array( VendorInbox::class, 'render' ) );
		add_shortcode( 'zymarg_live_chat',       array( LiveChat::class,    'render' ) );
		add_shortcode( 'zymarg_unread_count',    array( LiveChat::class,    'renderUnreadCount' ) );

		// Admin<->User support. Renders nothing while the feature is off, so it
		// is safe to place these before deciding where support should live.
		// Aliases exist so the same feature can be called whatever suits the
		// page: "Contact Support", "Support", "Alpha", anything.
		add_shortcode( 'zymarg_support_chat',    array( SupportChat::class, 'render' ) );
		add_shortcode( 'zymarg_contact_support', array( SupportChat::class, 'render' ) );
		add_shortcode( 'zymarg_support',         array( SupportChat::class, 'render' ) );

		// Legacy aliases (Phase 1–11). Kept so upgrades don't break pages.
		add_shortcode( 'zymarg_comm_buyer_inbox',  array( BuyerInbox::class,  'render' ) );
		add_shortcode( 'zymarg_comm_vendor_inbox', array( VendorInbox::class, 'render' ) );
		add_shortcode( 'zymarg_comm_popup',        array( LiveChat::class,    'render' ) );
		add_shortcode( 'zymarg_comm_chat',         array( LiveChat::class,    'render' ) );
		add_shortcode( 'zymarg_comm_unread_count', array( LiveChat::class,    'renderUnreadCount' ) );
	}

	/**
	 * Legacy placeholder — kept because integration tests reference it.
	 * Now delegates to LiveChat::render() for parity.
	 */
	public static function renderPlaceholder( $atts = array(), $content = null, $tag = '' ): string {
		return LiveChat::render( is_array( $atts ) ? $atts : array() );
	}
}
