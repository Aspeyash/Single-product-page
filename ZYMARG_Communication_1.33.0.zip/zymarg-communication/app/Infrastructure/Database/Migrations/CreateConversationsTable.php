<?php
/**
 * ZYMARG Communication — Migration: create `zc_conversations` table.
 *
 * @package    ZymargCommunication
 * @version    1.1.0
 */

namespace ZymargCommunication\Infrastructure\Database\Migrations;

use ZymargCommunication\Core\Abstracts\AbstractMigration;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class CreateConversationsTable extends AbstractMigration {

	public function up(): void {
		$table   = $this->tableName( 'zc_conversations' );
		$charset = $this->charsetCollate();

		$sql = "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			status VARCHAR(20) NOT NULL DEFAULT 'pending_approval',
			initiated_by BIGINT UNSIGNED NOT NULL,
			context_type VARCHAR(50) NULL,
			context_id BIGINT UNSIGNED NULL,
			is_pinned TINYINT(1) NOT NULL DEFAULT 0,
			last_message_at DATETIME NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY status_idx (status),
			KEY initiated_by_idx (initiated_by),
			KEY context_idx (context_type, context_id),
			KEY last_message_at_idx (last_message_at)
		) {$charset};";

		$this->dbDelta( $sql );
	}
}
