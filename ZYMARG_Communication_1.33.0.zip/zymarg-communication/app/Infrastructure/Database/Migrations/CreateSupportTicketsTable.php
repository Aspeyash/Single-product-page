<?php
/**
 * ZYMARG Communication — Migration: create `zc_support_tickets` table.
 *
 * WHY A TABLE IS NEEDED AT ALL
 *
 * Support threads were "ordinary conversations distinguished only by
 * context_type = 'support'", which needed no schema. That worked until support
 * had to answer operational questions, and it breaks on two of them:
 *
 *  1. "Is this solved?" — zc_conversations.status is a MODERATION lifecycle
 *     (pending_approval / active / reported / archived). There is nowhere to
 *     record that a problem was fixed.
 *
 *  2. "What is it about?" — zc_conversations has exactly ONE
 *     (context_type, context_id) pair, and support already spends context_type
 *     on the literal string 'support'. A support ticket therefore CANNOT also
 *     be linked to an order in that column; the slot is taken.
 *
 * One row per support conversation, keyed by conversation_id, carrying the
 * operational facts the conversation engine has no opinion about. Nothing in
 * zc_conversations changes, so every existing surface keeps working untouched
 * and a site with no support traffic just has an empty table.
 *
 * Rows are created lazily — see SupportTicketRepository::ensure() — so threads
 * that predate this release are adopted the first time they are touched rather
 * than needing a backfill pass over unbounded history.
 *
 * @package    ZymargCommunication
 * @since      1.27.0
 */

namespace ZymargCommunication\Infrastructure\Database\Migrations;

use ZymargCommunication\Core\Abstracts\AbstractMigration;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class CreateSupportTicketsTable extends AbstractMigration {

	public function up(): void {
		$table   = $this->tableName( 'zc_support_tickets' );
		$charset = $this->charsetCollate();

		// conversation_id is the PRIMARY KEY rather than a surrogate id: the
		// relationship is strictly 1:1 with a conversation, so a second key
		// would only create a way for the two to disagree.
		$sql = "CREATE TABLE {$table} (
			conversation_id BIGINT UNSIGNED NOT NULL,
			requester_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			agent_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			ticket_status VARCHAR(20) NOT NULL DEFAULT 'awaiting_agent',
			topic VARCHAR(40) NOT NULL DEFAULT '',
			subject VARCHAR(200) NOT NULL DEFAULT '',
			order_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			vendor_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			first_response_at DATETIME NULL,
			last_user_reply_at DATETIME NULL,
			last_agent_reply_at DATETIME NULL,
			resolved_at DATETIME NULL,
			resolved_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			reopened_count SMALLINT UNSIGNED NOT NULL DEFAULT 0,
			escalated_at DATETIME NULL,
			escalation_count SMALLINT UNSIGNED NOT NULL DEFAULT 0,
			rating TINYINT UNSIGNED NOT NULL DEFAULT 0,
			rating_comment TEXT NULL,
			rated_at DATETIME NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (conversation_id),
			KEY ticket_status_idx (ticket_status),
			KEY requester_idx (requester_id),
			KEY agent_idx (agent_id),
			KEY order_idx (order_id),
			KEY vendor_idx (vendor_id),
			KEY updated_at_idx (updated_at),
			KEY queue_idx (ticket_status, updated_at)
		) {$charset};";

		$this->dbDelta( $sql );
	}
}
