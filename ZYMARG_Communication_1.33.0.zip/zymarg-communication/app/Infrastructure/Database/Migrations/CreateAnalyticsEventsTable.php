<?php
/**
 * ZYMARG Communication — Migration: create `zc_analytics_events` table.
 *
 * @package    ZymargCommunication
 * @version    1.1.0
 */

namespace ZymargCommunication\Infrastructure\Database\Migrations;

use ZymargCommunication\Core\Abstracts\AbstractMigration;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class CreateAnalyticsEventsTable extends AbstractMigration {

	public function up(): void {
		$table   = $this->tableName( 'zc_analytics_events' );
		$charset = $this->charsetCollate();

		$sql = "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT UNSIGNED NULL,
			event VARCHAR(100) NOT NULL,
			payload LONGTEXT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY user_idx (user_id),
			KEY event_idx (event),
			KEY created_idx (created_at)
		) {$charset};";

		$this->dbDelta( $sql );
	}
}
