<?php
/**
 * ZYMARG Communication — Migration: create `zc_moderation_logs` table.
 *
 * @package    ZymargCommunication
 * @version    1.1.0
 */

namespace ZymargCommunication\Infrastructure\Database\Migrations;

use ZymargCommunication\Core\Abstracts\AbstractMigration;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class CreateModerationLogsTable extends AbstractMigration {

	public function up(): void {
		$table   = $this->tableName( 'zc_moderation_logs' );
		$charset = $this->charsetCollate();

		$sql = "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			conversation_id BIGINT UNSIGNED NOT NULL,
			reporter_id BIGINT UNSIGNED NULL,
			moderator_id BIGINT UNSIGNED NULL,
			type VARCHAR(100) NOT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'pending',
			notes TEXT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY conversation_idx (conversation_id),
			KEY reporter_idx (reporter_id),
			KEY moderator_idx (moderator_id),
			KEY status_idx (status),
			KEY type_idx (type)
		) {$charset};";

		$this->dbDelta( $sql );
	}
}
