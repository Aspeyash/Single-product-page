<?php
/**
 * ZYMARG Communication — Migration: create `zc_messages` table.
 *
 * NOTE: `archived_at` is added by `AddArchivedAtToMessagesTable` — keeping
 * the initial schema smaller mirrors the migration history intended by
 * CONTRIBUTING.md § 7.6.
 *
 * @package    ZymargCommunication
 * @version    1.1.0
 */

namespace ZymargCommunication\Infrastructure\Database\Migrations;

use ZymargCommunication\Core\Abstracts\AbstractMigration;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class CreateMessagesTable extends AbstractMigration {

	public function up(): void {
		$table   = $this->tableName( 'zc_messages' );
		$charset = $this->charsetCollate();

		$sql = "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			conversation_id BIGINT UNSIGNED NOT NULL,
			sender_id BIGINT UNSIGNED NOT NULL,
			parent_id BIGINT UNSIGNED NULL,
			body LONGTEXT NOT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'sending',
			lifecycle_status VARCHAR(20) NOT NULL DEFAULT 'active',
			deleted_at DATETIME NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY conversation_idx (conversation_id),
			KEY sender_idx (sender_id),
			KEY parent_idx (parent_id),
			KEY status_idx (status),
			KEY lifecycle_idx (lifecycle_status),
			KEY created_idx (created_at)
		) {$charset};";

		$this->dbDelta( $sql );
	}
}
