<?php
/**
 * ZYMARG Communication — Migration: create `zc_attachments` table.
 *
 * @package    ZymargCommunication
 * @version    1.1.0
 */

namespace ZymargCommunication\Infrastructure\Database\Migrations;

use ZymargCommunication\Core\Abstracts\AbstractMigration;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class CreateAttachmentsTable extends AbstractMigration {

	public function up(): void {
		$table   = $this->tableName( 'zc_attachments' );
		$charset = $this->charsetCollate();

		$sql = "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			message_id BIGINT UNSIGNED NOT NULL,
			uploader_id BIGINT UNSIGNED NOT NULL,
			file_path VARCHAR(500) NOT NULL,
			file_name VARCHAR(255) NOT NULL,
			mime_type VARCHAR(100) NOT NULL,
			file_size INT UNSIGNED NOT NULL DEFAULT 0,
			width SMALLINT UNSIGNED NULL,
			height SMALLINT UNSIGNED NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY message_idx (message_id),
			KEY uploader_idx (uploader_id)
		) {$charset};";

		$this->dbDelta( $sql );
	}
}
