<?php
/**
 * ZYMARG Communication — Migration: helpline session columns on
 * `zc_support_tickets`.
 *
 * Supports the auto-close session engine added in 1.31.0. A support case is a
 * helpline call, not a mailbox: when an agent has replied and the customer goes
 * quiet, the case closes itself after a configurable number of minutes.
 *
 * Three columns, and one index that makes the sweep cheap:
 *
 *   closed_reason     WHY a case ended — agent | auto_timeout | user. Without
 *                     it an auto-closed case is indistinguishable from one an
 *                     agent signed off, which makes resolution metrics lie.
 *   autoclose_paused  An agent can hold the clock for a case where the customer
 *                     legitimately needs to go and find an invoice.
 *   autoclose_until   An explicit deadline. Set when an agent grants extra time,
 *                     and when the customer is mid-sentence at the buzzer. NULL
 *                     means "derive it from last_agent_reply_at".
 *
 * The existing `queue_idx (ticket_status, updated_at)` cannot serve the sweep,
 * which filters on `last_agent_reply_at`, so a dedicated index is added.
 *
 * @package    ZymargCommunication
 * @version    1.31.0
 */

namespace ZymargCommunication\Infrastructure\Database\Migrations;

use ZymargCommunication\Core\Abstracts\AbstractMigration;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AddSessionColumnsToSupportTickets extends AbstractMigration {

	public function up(): void {
		global $wpdb;
		$table = $this->tableName( 'zc_support_tickets' );

		// Each column is guarded independently so a partially-applied migration
		// (an earlier run that died halfway) still completes on the next pass.
		if ( ! $this->columnExists( $table, 'closed_reason' ) ) {
			$wpdb->query( "ALTER TABLE `{$table}` ADD COLUMN closed_reason VARCHAR(20) NOT NULL DEFAULT '' AFTER resolved_by" ); // phpcs:ignore WordPress.DB.PreparedSQL
		}

		if ( ! $this->columnExists( $table, 'autoclose_paused' ) ) {
			$wpdb->query( "ALTER TABLE `{$table}` ADD COLUMN autoclose_paused TINYINT(1) NOT NULL DEFAULT 0 AFTER closed_reason" ); // phpcs:ignore WordPress.DB.PreparedSQL
		}

		if ( ! $this->columnExists( $table, 'autoclose_until' ) ) {
			$wpdb->query( "ALTER TABLE `{$table}` ADD COLUMN autoclose_until DATETIME NULL AFTER autoclose_paused" ); // phpcs:ignore WordPress.DB.PreparedSQL
		}

		// The sweep is WHERE ticket_status = 'awaiting_user' AND
		// last_agent_reply_at <= cutoff, which the updated_at index cannot cover.
		if ( ! $this->indexExists( $table, 'autoclose_idx' ) ) {
			$wpdb->query( "ALTER TABLE `{$table}` ADD KEY autoclose_idx (ticket_status, last_agent_reply_at)" ); // phpcs:ignore WordPress.DB.PreparedSQL
		}
	}

	/**
	 * Is an index already present?
	 *
	 * AbstractMigration ships columnExists() but no index equivalent, and
	 * re-adding a key is a hard error rather than a no-op, so this guard is
	 * required for the migration to stay idempotent.
	 */
	private function indexExists( string $table, string $index ): bool {
		global $wpdb;

		$found = $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COUNT(1) FROM information_schema.statistics
				 WHERE table_schema = DATABASE() AND table_name = %s AND index_name = %s',
				$table,
				$index
			)
		);

		return (int) $found > 0;
	}
}
