<?php
/**
 * ZYMARG Communication — Migration: create `zc_audit_logs` table.
 *
 * @package    ZymargCommunication
 * @version    1.6.0
 */

namespace ZymargCommunication\Infrastructure\Database\Migrations;

use ZymargCommunication\Core\Abstracts\AbstractMigration;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class CreateAuditLogsTable extends AbstractMigration {

	public function up(): void {
		$table   = $this->tableName( 'zc_audit_logs' );
		$charset = $this->charsetCollate();

		$sql = "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			admin_id BIGINT UNSIGNED NOT NULL,
			action VARCHAR(100) NOT NULL,
			target_type VARCHAR(50) NULL,
			target_id BIGINT UNSIGNED NULL,
			ip_address VARCHAR(45) NULL,
			metadata LONGTEXT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY admin_idx (admin_id),
			KEY action_idx (action),
			KEY target_idx (target_type, target_id)
		) {$charset};";

		$this->dbDelta( $sql );
	}
}
