<?php
/**
 * ZYMARG Communication — Migration: create `zc_feature_flags` table.
 *
 * @package    ZymargCommunication
 * @version    1.1.0
 */

namespace ZymargCommunication\Infrastructure\Database\Migrations;

use ZymargCommunication\Core\Abstracts\AbstractMigration;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class CreateFeatureFlagsTable extends AbstractMigration {

	public function up(): void {
		$table   = $this->tableName( 'zc_feature_flags' );
		$charset = $this->charsetCollate();

		$sql = "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			flag_key VARCHAR(100) NOT NULL,
			`group` VARCHAR(50) NOT NULL,
			label VARCHAR(150) NOT NULL,
			description TEXT NULL,
			is_enabled TINYINT(1) NOT NULL DEFAULT 0,
			is_locked TINYINT(1) NOT NULL DEFAULT 0,
			updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			UNIQUE KEY flag_key (flag_key),
			KEY group_idx (`group`)
		) {$charset};";

		$this->dbDelta( $sql );
	}
}
