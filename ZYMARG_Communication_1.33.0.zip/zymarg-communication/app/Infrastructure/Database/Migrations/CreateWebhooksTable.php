<?php
/**
 * ZYMARG Communication — Migration: create `zc_webhooks` table.
 *
 * Stores outbound webhook registrations owned by the Developer module.
 *
 * @package    ZymargCommunication
 * @version    1.8.0
 */

namespace ZymargCommunication\Infrastructure\Database\Migrations;

use ZymargCommunication\Core\Abstracts\AbstractMigration;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class CreateWebhooksTable extends AbstractMigration {

	public function up(): void {
		$table   = $this->tableName( 'zc_webhooks' );
		$charset = $this->charsetCollate();

		$sql = "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			owner_id BIGINT UNSIGNED NOT NULL,
			target_url VARCHAR(500) NOT NULL,
			events LONGTEXT NOT NULL,
			secret VARCHAR(128) NULL,
			is_active TINYINT(1) NOT NULL DEFAULT 1,
			last_status VARCHAR(32) NULL,
			last_dispatched_at DATETIME NULL,
			failure_count INT UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY owner_idx (owner_id),
			KEY active_idx (is_active)
		) {$charset};";

		$this->dbDelta( $sql );
	}
}
