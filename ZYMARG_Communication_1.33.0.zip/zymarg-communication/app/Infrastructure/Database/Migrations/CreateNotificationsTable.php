<?php
/**
 * ZYMARG Communication — Migration: create `zc_notifications` table.
 *
 * @package    ZymargCommunication
 * @version    1.1.0
 */

namespace ZymargCommunication\Infrastructure\Database\Migrations;

use ZymargCommunication\Core\Abstracts\AbstractMigration;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class CreateNotificationsTable extends AbstractMigration {

	public function up(): void {
		$table   = $this->tableName( 'zc_notifications' );
		$charset = $this->charsetCollate();

		$sql = "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT UNSIGNED NOT NULL,
			type VARCHAR(100) NOT NULL,
			payload LONGTEXT NULL,
			channel VARCHAR(20) NOT NULL DEFAULT 'in_app',
			is_read TINYINT(1) NOT NULL DEFAULT 0,
			sent_at DATETIME NULL,
			read_at DATETIME NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY user_idx (user_id),
			KEY type_idx (type),
			KEY channel_idx (channel),
			KEY is_read_idx (is_read)
		) {$charset};";

		$this->dbDelta( $sql );
	}
}
