<?php
/**
 * ZYMARG Communication — Migration: create `zc_reactions` table.
 *
 * @package    ZymargCommunication
 * @version    1.1.0
 */

namespace ZymargCommunication\Infrastructure\Database\Migrations;

use ZymargCommunication\Core\Abstracts\AbstractMigration;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class CreateReactionsTable extends AbstractMigration {

	public function up(): void {
		$table   = $this->tableName( 'zc_reactions' );
		$charset = $this->charsetCollate();

		$sql = "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			message_id BIGINT UNSIGNED NOT NULL,
			user_id BIGINT UNSIGNED NOT NULL,
			emoji VARCHAR(16) NOT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			UNIQUE KEY reaction_unique (message_id, user_id, emoji),
			KEY message_idx (message_id),
			KEY user_idx (user_id)
		) {$charset};";

		$this->dbDelta( $sql );
	}
}
