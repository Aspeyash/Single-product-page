<?php
/**
 * ZYMARG Communication — Migration: create `zc_participants` table.
 *
 * @package    ZymargCommunication
 * @version    1.1.0
 */

namespace ZymargCommunication\Infrastructure\Database\Migrations;

use ZymargCommunication\Core\Abstracts\AbstractMigration;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class CreateParticipantsTable extends AbstractMigration {

	public function up(): void {
		$table   = $this->tableName( 'zc_participants' );
		$charset = $this->charsetCollate();

		$sql = "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			conversation_id BIGINT UNSIGNED NOT NULL,
			user_id BIGINT UNSIGNED NOT NULL,
			participant_type VARCHAR(20) NOT NULL,
			`role` VARCHAR(20) NOT NULL DEFAULT 'member',
			last_read_at DATETIME NULL,
			joined_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			UNIQUE KEY conversation_user (conversation_id, user_id),
			KEY conversation_idx (conversation_id),
			KEY user_idx (user_id),
			KEY type_idx (participant_type)
		) {$charset};";

		$this->dbDelta( $sql );
	}
}
