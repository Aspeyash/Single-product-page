<?php
/**
 * ZYMARG Communication — Migration: create `zc_api_keys` table.
 *
 * Stores hashed API keys for third-party consumers of the plugin's REST
 * and PHP APIs. Raw keys are never persisted — only a SHA-256 hash.
 *
 * @package    ZymargCommunication
 * @version    1.8.0
 */

namespace ZymargCommunication\Infrastructure\Database\Migrations;

use ZymargCommunication\Core\Abstracts\AbstractMigration;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class CreateApiKeysTable extends AbstractMigration {

	public function up(): void {
		$table   = $this->tableName( 'zc_api_keys' );
		$charset = $this->charsetCollate();

		$sql = "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			owner_id BIGINT UNSIGNED NOT NULL,
			label VARCHAR(160) NOT NULL,
			key_prefix VARCHAR(12) NOT NULL,
			key_hash CHAR(64) NOT NULL,
			scopes LONGTEXT NULL,
			revoked_at DATETIME NULL,
			last_used_at DATETIME NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY owner_idx (owner_id),
			KEY hash_idx (key_hash),
			KEY prefix_idx (key_prefix)
		) {$charset};";

		$this->dbDelta( $sql );
	}
}
