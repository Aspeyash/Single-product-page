<?php
/**
 * ZYMARG Communication — Migration: add `archived_at` to `zc_messages`.
 *
 * Split from the initial `CreateMessagesTable` migration to mirror the
 * migration history intended by CONTRIBUTING.md § 7.6.
 *
 * @package    ZymargCommunication
 * @version    1.1.0
 */

namespace ZymargCommunication\Infrastructure\Database\Migrations;

use ZymargCommunication\Core\Abstracts\AbstractMigration;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AddArchivedAtToMessagesTable extends AbstractMigration {

	public function up(): void {
		global $wpdb;
		$table = $this->tableName( 'zc_messages' );

		if ( $this->columnExists( $table, 'archived_at' ) ) {
			return;
		}

		$wpdb->query( "ALTER TABLE `{$table}` ADD COLUMN archived_at DATETIME NULL AFTER lifecycle_status" ); // phpcs:ignore WordPress.DB.PreparedSQL
		$wpdb->query( "ALTER TABLE `{$table}` ADD KEY archived_idx (archived_at)" ); // phpcs:ignore WordPress.DB.PreparedSQL
	}
}
