<?php
/**
 * ZYMARG Communication
 *
 * @package    ZymargCommunication
 * @version    1.0.0
 * @author     ZYMARG Team
 */

namespace ZymargCommunication\Infrastructure\Database\Repositories;

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class BaseRepository {
    // TODO: implement
}
