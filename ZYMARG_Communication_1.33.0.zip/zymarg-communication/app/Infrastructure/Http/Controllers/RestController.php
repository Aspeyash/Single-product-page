<?php
/**
 * Base REST controller. Registers routes and applies middleware.
 *
 * Concrete module controllers extend `AbstractController` (which handles
 * response envelope helpers). This file exists as the routing bootstrap
 * that collects and registers routes from every module controller on the
 * `rest_api_init` hook.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Infrastructure\Http\Controllers;

use ZymargCommunication\Core\Abstracts\AbstractController;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class RestController {

	/** @var array<int, AbstractController> */
	private static array $controllers = array();

	public static function register( AbstractController $controller ): void {
		self::$controllers[] = $controller;
	}

	public static function boot(): void {
		add_action( 'rest_api_init', array( self::class, 'registerAll' ) );
	}

	public static function registerAll(): void {
		foreach ( self::$controllers as $controller ) {
			$controller->registerRoutes();
		}
	}
}
