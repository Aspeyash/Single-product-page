<?php
/**
 * Verifies user is authenticated before request proceeds.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Infrastructure\Http\Middleware;

use WP_Error;
use WP_REST_Request;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AuthMiddleware {

	/**
	 * REST `permission_callback` for authenticated endpoints.
	 */
	public static function requireLoggedIn( WP_REST_Request $request ): bool|WP_Error {
		unset( $request );
		if ( ! is_user_logged_in() ) {
			return new WP_Error(
				'unauthenticated',
				__( 'Authentication is required.', 'zymarg-communication' ),
				array( 'status' => 401 )
			);
		}
		return true;
	}

	public static function requireAdmin( WP_REST_Request $request ): bool|WP_Error {
		unset( $request );
		if ( ! is_user_logged_in() ) {
			return new WP_Error(
				'unauthenticated',
				__( 'Authentication is required.', 'zymarg-communication' ),
				array( 'status' => 401 )
			);
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return new WP_Error(
				'forbidden',
				__( 'Admin privileges are required.', 'zymarg-communication' ),
				array( 'status' => 403 )
			);
		}
		return true;
	}

	public static function public( WP_REST_Request $request ): bool {
		unset( $request );
		return true;
	}
}
