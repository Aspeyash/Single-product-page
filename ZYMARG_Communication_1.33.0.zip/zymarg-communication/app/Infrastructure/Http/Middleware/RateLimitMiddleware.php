<?php
/**
 * Enforces per-user and per-endpoint rate limits.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Infrastructure\Http\Middleware;

use WP_Error;
use WP_REST_Request;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class RateLimitMiddleware {

	private const TRANSIENT_PREFIX = 'zymarg_comm_rl_';

	/** Default limits per bucket. Overridden per-route via `check()`. */
	private const DEFAULT_LIMIT  = 60;
	private const DEFAULT_WINDOW = 60;

	/**
	 * Enforces a rate limit for the current user + route bucket.
	 *
	 * @param WP_REST_Request $request Current REST request.
	 * @param string          $bucket  Logical bucket name, e.g. "messages.send".
	 * @param int             $limit   Max requests within window.
	 * @param int             $window  Window size in seconds.
	 */
	public static function check( WP_REST_Request $request, string $bucket, int $limit = self::DEFAULT_LIMIT, int $window = self::DEFAULT_WINDOW ): bool|WP_Error {
		unset( $request );
		$identity = get_current_user_id();
		if ( 0 === $identity ) {
			// Fallback to hashed IP for unauthenticated requests.
			$identity = 'ip_' . substr( md5( (string) ( $_SERVER['REMOTE_ADDR'] ?? '' ) ), 0, 12 );
		}

		$key = self::TRANSIENT_PREFIX . $bucket . '_' . $identity;
		$now = time();

		/*
		 * FIXED window, carried inside the stored value (1.32.5).
		 *
		 * Two earlier shapes of this code were both wrong:
		 *
		 * 1. Originally `set_transient( $key, $count + 1, $window )` rewrote the
		 *    expiry on every accepted request, so a steadily polling client
		 *    could never let the window roll and the tally only climbed.
		 *    Realtime polling runs every 4s (15/min) against a 120/min cap, so
		 *    after about eight minutes of ordinary use the cap was reached and
		 *    the endpoint returned 429 for a full window before resetting — a
		 *    sawtooth lockout caused by normal traffic, not abuse. It surfaced
		 *    as repeated "GET /realtime/poll 429 (Too Many Requests)".
		 *
		 * 2. The first fix kept the expiry by reading the
		 *    `_transient_timeout_{key}` OPTION. That only exists when
		 *    transients live in the options table. With a persistent object
		 *    cache — Redis on Pantheon, Memcached elsewhere — transients never
		 *    touch options, the lookup returned nothing, and the code fell back
		 *    to the full window on every increment: silently sliding again, and
		 *    precisely on the hosts most likely to be polling hardest.
		 *
		 * The window end now lives INSIDE the cached value, so correctness no
		 * longer depends on where transients are stored. A legacy integer value
		 * from an older version simply fails the is_array() check and starts a
		 * fresh window.
		 */
		$state = get_transient( $key );

		if ( ! is_array( $state ) || ! isset( $state['count'], $state['reset'] ) || (int) $state['reset'] <= $now ) {
			$state = array(
				'count' => 0,
				'reset' => $now + $window,
			);
		}

		$reset     = (int) $state['reset'];
		$remaining = max( 1, $reset - $now );

		if ( (int) $state['count'] >= $limit ) {
			return new WP_Error(
				'rate_limited',
				__( 'Too many requests. Please slow down.', 'zymarg-communication' ),
				array(
					'status'      => 429,
					// Seconds until the window actually rolls, so a client can
					// back off accurately instead of guessing.
					'retry_after' => $remaining,
				)
			);
		}

		++$state['count'];
		set_transient( $key, $state, $remaining );

		return true;
	}

	/**
	 * Convenience helper for use inside REST callbacks.
	 * Returns a WP_Error via `rest_ensure_response()` when exceeded.
	 */
	public static function enforce( WP_REST_Request $request, string $bucket, int $limit = self::DEFAULT_LIMIT, int $window = self::DEFAULT_WINDOW ): ?WP_Error {
		$result = self::check( $request, $bucket, $limit, $window );
		return $result instanceof WP_Error ? $result : null;
	}
}
