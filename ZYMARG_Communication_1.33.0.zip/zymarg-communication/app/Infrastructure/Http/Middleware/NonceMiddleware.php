<?php
/**
 * Verifies nonce on state-changing requests.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Infrastructure\Http\Middleware;

use WP_Error;
use WP_REST_Request;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class NonceMiddleware {

	public const NONCE_ACTION = 'wp_rest';

	/**
	 * Verify the WP REST cookie nonce is present on state-changing requests.
	 *
	 * Compatible with the JS SDK when it sets `X-WP-Nonce`. External clients
	 * that authenticate via application passwords / OAuth are allowed through
	 * as long as they are authenticated — nonces exist to prevent CSRF and
	 * are unnecessary for stateless auth.
	 */
	public static function verify( WP_REST_Request $request ): bool|WP_Error {
		$method = strtoupper( $request->get_method() );
		if ( in_array( $method, array( 'GET', 'HEAD', 'OPTIONS' ), true ) ) {
			return true;
		}

		$nonce = $request->get_header( 'X_WP_Nonce' );
		if ( null === $nonce ) {
			$nonce = $request->get_header( 'x-wp-nonce' );
		}

		// Cookie-authenticated requests must present a valid nonce.
		if ( is_user_logged_in() && ! empty( $_COOKIE ) ) {
			if ( empty( $nonce ) || ! wp_verify_nonce( (string) $nonce, self::NONCE_ACTION ) ) {
				// Allow if using non-cookie auth (application password, OAuth).
				if ( self::isCookieAuthenticated() ) {
					return new WP_Error(
						'invalid_nonce',
						__( 'Invalid or missing nonce.', 'zymarg-communication' ),
						array( 'status' => 401 )
					);
				}
			}
		}

		return true;
	}

	private static function isCookieAuthenticated(): bool {
		return ! empty( $_COOKIE[ LOGGED_IN_COOKIE ] ?? '' );
	}
}
