<?php
/**
 * Standardized success response shape.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Infrastructure\Http\Responses;

use WP_REST_Response;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ApiResponse {

	public static function make( mixed $data = null, int $status = 200 ): WP_REST_Response {
		return new WP_REST_Response(
			array(
				'success' => true,
				'data'    => $data,
			),
			$status
		);
	}
}
