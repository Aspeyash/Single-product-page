<?php
/**
 * Standardized error response shape.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Infrastructure\Http\Responses;

use WP_REST_Response;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ErrorResponse {

	public static function make( string $code, string $message, int $status = 400, array $extra = array() ): WP_REST_Response {
		$body = array(
			'success' => false,
			'error'   => array(
				'code'    => $code,
				'message' => $message,
			),
		);

		if ( ! empty( $extra ) ) {
			$body['error'] = array_merge( $body['error'], $extra );
		}

		return new WP_REST_Response( $body, $status );
	}
}
