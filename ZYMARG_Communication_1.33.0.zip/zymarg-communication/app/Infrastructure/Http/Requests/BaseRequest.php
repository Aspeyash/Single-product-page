<?php
/**
 * Base request validator. Sanitizes and validates incoming request data.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Infrastructure\Http\Requests;

use WP_REST_Request;
use ZymargCommunication\Core\Exceptions\ValidationException;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

abstract class BaseRequest {

	protected WP_REST_Request $request;
	/** @var array<string, string> */
	protected array $errors = array();

	public function __construct( WP_REST_Request $request ) {
		$this->request = $request;
	}

	public static function from( WP_REST_Request $request ): static {
		return new static( $request );
	}

	public function validate(): void {
		$this->errors = array();
		$this->rules();
		if ( ! empty( $this->errors ) ) {
			throw new ValidationException( __( 'The submitted data is invalid.', 'zymarg-communication' ), $this->errors );
		}
	}

	/** Subclass hook: perform validation and populate `$this->errors`. */
	abstract protected function rules(): void;

	protected function requireString( string $key, int $min = 1, int $max = 65535 ): ?string {
		$raw = $this->request->get_param( $key );
		if ( ! is_string( $raw ) ) {
			$this->errors[ $key ] = sprintf( 'Field "%s" must be a string.', $key );
			return null;
		}
		$value = trim( wp_unslash( $raw ) );
		$len   = function_exists( 'mb_strlen' ) ? mb_strlen( $value, 'UTF-8' ) : strlen( $value );
		if ( $len < $min ) {
			$this->errors[ $key ] = sprintf( 'Field "%s" must be at least %d characters.', $key, $min );
			return null;
		}
		if ( $len > $max ) {
			$this->errors[ $key ] = sprintf( 'Field "%s" may not exceed %d characters.', $key, $max );
			return null;
		}
		return $value;
	}

	protected function requireInt( string $key, ?int $min = null ): ?int {
		$raw = $this->request->get_param( $key );
		if ( null === $raw || '' === $raw ) {
			$this->errors[ $key ] = sprintf( 'Field "%s" is required.', $key );
			return null;
		}
		if ( ! is_numeric( $raw ) ) {
			$this->errors[ $key ] = sprintf( 'Field "%s" must be numeric.', $key );
			return null;
		}
		$value = (int) $raw;
		if ( null !== $min && $value < $min ) {
			$this->errors[ $key ] = sprintf( 'Field "%s" must be >= %d.', $key, $min );
			return null;
		}
		return $value;
	}

	protected function optionalString( string $key, int $max = 65535 ): ?string {
		$raw = $this->request->get_param( $key );
		if ( null === $raw || '' === $raw ) {
			return null;
		}
		return $this->requireString( $key, 0, $max );
	}

	protected function optionalInt( string $key ): ?int {
		$raw = $this->request->get_param( $key );
		if ( null === $raw || '' === $raw ) {
			return null;
		}
		return $this->requireInt( $key );
	}

	protected function optionalBool( string $key ): ?bool {
		$raw = $this->request->get_param( $key );
		if ( null === $raw ) {
			return null;
		}
		return (bool) rest_sanitize_boolean( $raw );
	}
}
