<?php
/**
 * Immutable typed wrapper for a message ID.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Shared\ValueObjects;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class MessageId {

	private function __construct( public readonly int $value ) {}

	public static function from( int $value ): self {
		if ( $value < 1 ) {
			throw new \InvalidArgumentException( 'Message ID must be positive.' );
		}
		return new self( $value );
	}

	public function __toString(): string {
		return (string) $this->value;
	}
}
