<?php
/**
 * Event fired after a participant is added to a conversation.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Shared\Events;

use ZymargCommunication\Core\Contracts\EventInterface;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ParticipantJoined implements EventInterface {

	public const NAME = 'participant_joined';

	public function __construct(
		public readonly int $conversationId,
		public readonly int $userId,
		public readonly string $participantType,
		public readonly string $role
	) {}

	public function name(): string {
		return self::NAME;
	}

	public function payload(): array {
		return array(
			'conversation_id'  => $this->conversationId,
			'user_id'          => $this->userId,
			'participant_type' => $this->participantType,
			'role'             => $this->role,
		);
	}
}
