<?php
/**
 * Event fired after a conversation is archived or deleted.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Shared\Events;

use ZymargCommunication\Core\Contracts\EventInterface;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ConversationClosed implements EventInterface {

	public const NAME = 'conversation_closed';

	public function __construct(
		public readonly int $conversationId,
		public readonly int $actorId,
		public readonly string $reason
	) {}

	public function name(): string {
		return self::NAME;
	}

	public function payload(): array {
		return array(
			'conversation_id' => $this->conversationId,
			'actor_id'        => $this->actorId,
			'reason'          => $this->reason,
		);
	}
}
