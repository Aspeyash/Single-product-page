<?php
/**
 * Central event dispatcher.
 *
 * Fires WordPress actions and notifies internal listeners from one place.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Shared\Events;

use ZymargCommunication\Core\Contracts\EventInterface;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class EventDispatcher {

	/** @var array<string, array<int, callable>> */
	private array $listeners = array();

	public function on( string $event, callable $callback ): void {
		$this->listeners[ $event ][] = $callback;
	}

	public function fire( string $event, array $payload = array() ): void {
		foreach ( $this->listeners[ $event ] ?? array() as $listener ) {
			try {
				$listener( $payload );
			} catch ( \Throwable $e ) {
				// Listeners are best-effort; a broken listener must not break the caller.
			}
		}

		/**
		 * WordPress hook fired for every plugin event. External integrations
		 * can listen via `add_action( 'zymarg_comm_event_{event}', ... )`.
		 */
		do_action( 'zymarg_comm_event_' . $event, $payload );
		do_action( 'zymarg_comm_event', $event, $payload );
	}

	public function dispatch( EventInterface $event ): void {
		$this->fire( $event->name(), $event->payload() );
	}
}
