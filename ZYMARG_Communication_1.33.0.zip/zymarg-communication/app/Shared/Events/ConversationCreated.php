<?php
/**
 * Event fired after a new conversation is created.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Shared\Events;

use ZymargCommunication\Core\Contracts\EventInterface;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ConversationCreated implements EventInterface {

	public const NAME = 'conversation_created';

	public function __construct(
		public readonly int $conversationId,
		public readonly int $initiatedBy,
		public readonly string $status,
		public readonly ?string $contextType = null,
		public readonly ?int $contextId = null
	) {}

	public function name(): string {
		return self::NAME;
	}

	public function payload(): array {
		return array(
			'conversation_id' => $this->conversationId,
			'initiated_by'    => $this->initiatedBy,
			'status'          => $this->status,
			'context_type'    => $this->contextType,
			'context_id'      => $this->contextId,
		);
	}
}
