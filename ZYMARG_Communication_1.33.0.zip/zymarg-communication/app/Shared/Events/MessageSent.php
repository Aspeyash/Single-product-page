<?php
/**
 * Event fired after a message is successfully stored.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Shared\Events;

use ZymargCommunication\Core\Contracts\EventInterface;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class MessageSent implements EventInterface {

	public const NAME = 'message_sent';

	public function __construct(
		public readonly int $messageId,
		public readonly int $conversationId,
		public readonly int $senderId,
		public readonly string $body,
		public readonly ?int $parentId = null
	) {}

	public function name(): string {
		return self::NAME;
	}

	public function payload(): array {
		return array(
			'message_id'      => $this->messageId,
			'conversation_id' => $this->conversationId,
			'sender_id'       => $this->senderId,
			'body'            => $this->body,
			'parent_id'       => $this->parentId,
		);
	}
}
