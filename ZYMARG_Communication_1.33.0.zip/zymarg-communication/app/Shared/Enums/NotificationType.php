<?php
/**
 * Notification type slugs.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Shared\Enums;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

enum NotificationType: string {
	case NewMessage           = 'new_message';
	case ConversationRequest  = 'conversation_request';
	case ModerationAlert      = 'moderation_alert';
	case ParticipantJoined    = 'participant_joined';
	case Mention              = 'mention';
}
