<?php
/**
 * Message lifecycle status (retention pipeline).
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Shared\Enums;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

enum MessageLifecycleStatus: string {
	case Active   = 'active';
	case Archived = 'archived';
	case Deleted  = 'deleted';
}
