<?php
/**
 * Conversation lifecycle status.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Shared\Enums;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

enum ConversationStatus: string {
	case PendingApproval = 'pending_approval';
	case Active          = 'active';
	case Reported        = 'reported';
	case Archived        = 'archived';
}
