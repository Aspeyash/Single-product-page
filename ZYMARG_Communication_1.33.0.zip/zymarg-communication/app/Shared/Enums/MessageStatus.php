<?php
/**
 * Message delivery status.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Shared\Enums;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

enum MessageStatus: string {
	case Sending   = 'sending';
	case Delivered = 'delivered';
	case Read      = 'read';
	case Failed    = 'failed';
}
