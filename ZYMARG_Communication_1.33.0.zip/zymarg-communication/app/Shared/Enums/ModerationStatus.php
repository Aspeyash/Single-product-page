<?php
/**
 * Moderation case status.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Shared\Enums;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

enum ModerationStatus: string {
	case Pending   = 'pending';
	case Reviewed  = 'reviewed';
	case Resolved  = 'resolved';
	case Dismissed = 'dismissed';
}
