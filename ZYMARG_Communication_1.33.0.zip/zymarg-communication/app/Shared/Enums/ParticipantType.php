<?php
/**
 * Participant type (WordPress user role bucket).
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Shared\Enums;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

enum ParticipantType: string {
	case Buyer  = 'buyer';
	case Seller = 'seller';
	case Admin  = 'admin';

	public static function fromUserId( int $user_id ): self {
		if ( user_can( $user_id, 'manage_options' ) ) {
			return self::Admin;
		}

		// Support agents act on behalf of the site, so they pair as Admin even
		// without full administrator rights. Without this a support agent would
		// resolve to Buyer/Seller and a customer contacting support would be
		// treated as a buyer-to-buyer chat, which is gated off by default.
		// Capability string is inlined to keep this enum dependency-free.
		if ( user_can( $user_id, 'zymarg_support_agent' ) ) {
			return self::Admin;
		}

		$user = get_userdata( $user_id );
		if ( $user && is_array( $user->roles ) ) {
			$roles = array_map( 'strtolower', $user->roles );
			$seller_roles = array( 'seller', 'vendor', 'wcfm_vendor', 'dc_vendor', 'shop_manager' );
			foreach ( $seller_roles as $r ) {
				if ( in_array( $r, $roles, true ) ) {
					return self::Seller;
				}
			}
		}

		return self::Buyer;
	}
}
