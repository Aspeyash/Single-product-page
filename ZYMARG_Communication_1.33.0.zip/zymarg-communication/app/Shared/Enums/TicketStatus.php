<?php
/**
 * Support ticket lifecycle status.
 *
 * DISTINCT FROM ConversationStatus, deliberately. That enum
 * (pending_approval / active / reported / archived) is a MODERATION lifecycle:
 * it answers "should this thread be visible". It has no notion of whether the
 * customer's problem was actually solved, which meant an agent's only way to
 * mark a ticket done was to Archive it -- a moderation action that, with one
 * eternal thread per user, would have buried their entire support history.
 *
 * This enum answers the operational question instead: who is this waiting on,
 * and is it finished?
 *
 *   AwaitingAgent — the customer wrote last. This is the work queue.
 *   AwaitingUser  — an agent replied and is waiting on the customer.
 *   Resolved      — an agent marked it solved. Reopens if the customer writes.
 *   Closed        — final. Does not reopen; a new message starts a new ticket.
 *
 * @package ZymargCommunication
 * @since   1.27.0
 */

namespace ZymargCommunication\Shared\Enums;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

enum TicketStatus: string {
	case AwaitingAgent = 'awaiting_agent';
	case AwaitingUser  = 'awaiting_user';
	case Resolved      = 'resolved';
	case Closed        = 'closed';

	/** Still needs someone to act. Drives the agent queue and the open count. */
	public function isOpen(): bool {
		return self::AwaitingAgent === $this || self::AwaitingUser === $this;
	}

	/** Finished, from the agent's point of view. */
	public function isSettled(): bool {
		return ! $this->isOpen();
	}

	/**
	 * A customer message reopens a resolved ticket -- people reply "actually it
	 * is still broken", and that must not be silently swallowed into a thread
	 * nobody is watching. Closed is final by design.
	 */
	public function reopensOnUserReply(): bool {
		return self::Resolved === $this;
	}

	/** Human label for both the customer pill and the agent queue. */
	public function label(): string {
		return match ( $this ) {
			self::AwaitingAgent => __( 'Waiting on us', 'zymarg-communication' ),
			self::AwaitingUser  => __( 'Waiting on you', 'zymarg-communication' ),
			self::Resolved      => __( 'Resolved', 'zymarg-communication' ),
			self::Closed        => __( 'Closed', 'zymarg-communication' ),
		};
	}

	/**
	 * Label from the AGENT's perspective. "Waiting on you" means opposite
	 * things to the two sides of the same thread, so the pill cannot share one
	 * string without lying to somebody.
	 */
	public function agentLabel(): string {
		return match ( $this ) {
			self::AwaitingAgent => __( 'Needs reply', 'zymarg-communication' ),
			self::AwaitingUser  => __( 'Waiting on customer', 'zymarg-communication' ),
			self::Resolved      => __( 'Resolved', 'zymarg-communication' ),
			self::Closed        => __( 'Closed', 'zymarg-communication' ),
		};
	}

	/** Token consumed by CSS for the pill colour. */
	public function tone(): string {
		return match ( $this ) {
			self::AwaitingAgent => 'warn',
			self::AwaitingUser  => 'info',
			self::Resolved      => 'success',
			self::Closed        => 'muted',
		};
	}

	/** Tolerant parse for values arriving from storage or REST. */
	public static function fromLoose( ?string $value, self $fallback = self::AwaitingAgent ): self {
		$value = strtolower( trim( (string) $value ) );

		return self::tryFrom( $value ) ?? $fallback;
	}

	/** @return array<int, string> */
	public static function values(): array {
		return array_map( static fn ( self $c ): string => $c->value, self::cases() );
	}

	/** @return array<int, string> Statuses that count as an open ticket. */
	public static function openValues(): array {
		return array( self::AwaitingAgent->value, self::AwaitingUser->value );
	}
}
