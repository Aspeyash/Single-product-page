<?php
/**
 * Participant role within a conversation.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Shared\Enums;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

enum ParticipantRole: string {
	case Owner  = 'owner';
	case Member = 'member';
}
