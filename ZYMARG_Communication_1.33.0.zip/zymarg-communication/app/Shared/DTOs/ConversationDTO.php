<?php
/**
 * Typed carrier for conversation data between layers.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Shared\DTOs;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ConversationDTO {

	public function __construct(
		public int $id,
		public string $status,
		public int $initiatedBy,
		public ?string $contextType,
		public ?int $contextId,
		public bool $isPinned,
		public ?string $lastMessageAt,
		public string $createdAt,
		public string $updatedAt
	) {}

	public static function fromRow( object $row ): self {
		return new self(
			(int) $row->id,
			(string) $row->status,
			(int) $row->initiated_by,
			isset( $row->context_type ) ? (string) $row->context_type : null,
			isset( $row->context_id ) ? (int) $row->context_id : null,
			(bool) ( $row->is_pinned ?? 0 ),
			$row->last_message_at ?? null,
			(string) $row->created_at,
			(string) $row->updated_at
		);
	}

	public function toArray(): array {
		return array(
			'id'              => $this->id,
			'status'          => $this->status,
			'initiated_by'    => $this->initiatedBy,
			'context_type'    => $this->contextType,
			'context_id'      => $this->contextId,
			'is_pinned'       => $this->isPinned,
			'last_message_at' => $this->lastMessageAt,
			'created_at'      => $this->createdAt,
			'updated_at'      => $this->updatedAt,
		);
	}
}
