<?php
/**
 * Typed carrier for notification data between layers.
 *
 * Populated fully by the Notification module (Phase 5). Phase 2 ships the shape only.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Shared\DTOs;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class NotificationDTO {

	public function __construct(
		public int $id,
		public int $userId,
		public string $type,
		public array $payload,
		public string $channel,
		public bool $isRead,
		public ?string $sentAt,
		public ?string $readAt,
		public string $createdAt
	) {}

	public function toArray(): array {
		return array(
			'id'         => $this->id,
			'user_id'    => $this->userId,
			'type'       => $this->type,
			'payload'    => $this->payload,
			'channel'    => $this->channel,
			'is_read'    => $this->isRead,
			'sent_at'    => $this->sentAt,
			'read_at'    => $this->readAt,
			'created_at' => $this->createdAt,
		);
	}
}
