<?php
/**
 * Provides `created_at` and `updated_at` management.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Shared\Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

trait HasTimestamps {

	protected function now(): string {
		return current_time( 'mysql', true );
	}

	protected function withTimestamps( array $data, bool $isNew = true ): array {
		$now = $this->now();
		if ( $isNew && ! isset( $data['created_at'] ) ) {
			$data['created_at'] = $now;
		}
		$data['updated_at'] = $now;
		return $data;
	}
}
