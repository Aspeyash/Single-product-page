<?php
/**
 * Provides singleton pattern for classes that require it.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Shared\Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

trait Singleton {

	private static ?self $instance = null;

	public static function instance(): static {
		if ( null === self::$instance ) {
			self::$instance = new static();
		}
		return self::$instance;
	}

	private function __construct() {}
	private function __clone() {}
	public function __wakeup(): void {
		throw new \LogicException( 'Cannot unserialize singleton.' );
	}
}
