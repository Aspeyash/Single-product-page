<?php
/**
 * Provides `toArray()` and `toJson()` methods.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Shared\Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

trait Serializable {

	public function toArray(): array {
		return get_object_vars( $this );
	}

	public function toJson(): string {
		return wp_json_encode( $this->toArray() );
	}
}
