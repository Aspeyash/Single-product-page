<?php
/**
 * Convenience trait for Hooks classes.
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Shared\Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

trait Hookable {

	protected function addAction( string $hook, callable $callback, int $priority = 10, int $accepted_args = 1 ): void {
		add_action( $hook, $callback, $priority, $accepted_args );
	}

	protected function addFilter( string $hook, callable $callback, int $priority = 10, int $accepted_args = 1 ): void {
		add_filter( $hook, $callback, $priority, $accepted_args );
	}
}
