<?php
/**
 * Provides `isEnabled( string $flag )` helper to every Service.
 *
 * Usage:
 *   if ( ! $this->isEnabled( 'message.reactions' ) ) { return; }
 *
 * @package ZymargCommunication
 */

namespace ZymargCommunication\Shared\Traits;

use ZymargCommunication\Bootstrap\ServiceProvider;
use ZymargCommunication\Modules\FeatureFlags\Services\FeatureFlagService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

trait ChecksFeatureFlags {

	protected function isEnabled( string $flag_key ): bool {
		$service = $this->featureFlagService();
		if ( ! $service instanceof FeatureFlagService ) {
			return true; // Fail-open before FeatureFlags module is registered.
		}
		return $service->isEnabled( $flag_key );
	}

	private function featureFlagService(): ?FeatureFlagService {
		static $resolved = null;
		if ( null !== $resolved ) {
			return $resolved ?: null;
		}

		if ( ServiceProvider::has( FeatureFlagService::class ) ) {
			$resolved = ServiceProvider::get( FeatureFlagService::class );
			return $resolved;
		}

		$resolved = false;
		return null;
	}
}
