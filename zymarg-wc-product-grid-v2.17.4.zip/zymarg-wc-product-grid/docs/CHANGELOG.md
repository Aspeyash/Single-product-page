# Changelog

All notable changes to ZYMARG WC Product Grid are documented here.

Format: [Semantic Versioning](https://semver.org)
`MAJOR.MINOR.PATCH` — PATCH = bug fixes; MINOR = new features (backward-compatible);
MAJOR = breaking changes.

---

## [2.17.4] - 2026-08-14

### Fixed
- Infinite scroll / Load More on a `current_vendor` grid stopped after the
  first page and reported "all products loaded" regardless of how many
  products the vendor actually had. `Source_Current_Vendor` resolves the
  vendor from `get_query_var('author')` / `dokan_is_store_page()`, both of
  which are empty during an `admin-ajax.php` request, so every paginated
  request silently resolved to no vendor and returned nothing.
- `assets/js/frontend.js`'s Load More click handler now falls back to the
  widget wrapper's own `data-vendor-id` attribute (already rendered since
  1.5.23 for the Vendor Category Filter widget's AJAX flow) whenever no VCF
  vendor ID was already supplied, so plain pagination on a `current_vendor`
  grid works with no companion widget required. `Handler_Load_More` already
  read `current_vendor_id` from `$_POST` unconditionally — only the browser
  side was missing this value outside the VCF flow.

---

## [2.17.3] - 2026-08-14

### Added
- `current_vendor_subset` shortcode attribute (`all` | `featured` | `trending` |
  `best_selling`). The Elementor widget and `Public_API::render()` config array
  could already select a `current_vendor` subset; the `[zymarg_products]`
  shortcode could not, because the attribute was absent from `default_atts()`
  and `shortcode_atts()` drops anything not declared there. Every shortcode
  using `source="current_vendor"` therefore always rendered the `all` subset,
  silently, regardless of what the author typed.
- `current_vendor_include_staff` shortcode attribute (`yes` | `no`), matching
  the existing Elementor widget control. Left unset by default so an untouched
  shortcode keeps `Source_Current_Vendor`'s own default (include staff).

Both attributes only affect the `current_vendor` source; every other source
ignores them, matching the existing `flash_*` attribute convention.

## [2.17.0] - 2026-08-07

### Added
- **Guide page** (ZYMARG -> Guide): a complete in-admin manual covering the render
  pipeline, all 14 sources, the four `current_vendor` subsets, Flash Deals setup for
  homepage and store pages, the full shortcode attribute reference, slider/marquee
  behaviour and loop requirements, cards and templates, slots, pagination, countdowns,
  the PHP API for standalone plugins, hooks, caching and troubleshooting.
  Live sections read the real registries, so third-party sources and cards appear
  automatically.
- **Live Render Log** (Engine Diagnostics v8): records every real front-end render --
  which page, which source and subset/scope, layout and card, product count, HTML size
  and status (ok / cached / empty / blank / error). Rows are deduplicated with a hit
  counter and written once per request on shutdown, in a non-autoloaded option.
- **Source Test Bench** (Engine Diagnostics v9): run any source through the real
  pipeline on demand, with optional live preview of the rendered output.
- **Issue badge** on the top-level ZYMARG menu, counting render and query failures.

### Changed
- Diagnostics now documents v8 and v9 alongside the existing v1-v7 sections.

### Removed
- The duplicate **Product Grid** submenu under ZYMARG. It pointed at the Engine
  Diagnostics callback, so it rendered the same page unstyled. No functionality lost.

## [2.16.1] - 2026-08-07

### Fixed
- **Marquee stopped at the end of the track on desktop only.** The loop clone
  runway spent Swiper's entire slide budget. That passes Swiper's own loop check
  (`slides.length >= ceil(slidesPerView) + slidesPerGroup + loopAdditionalSlides`
  is a `>=`), but it leaves the appended clone pool empty, and `loopFix()` is a
  silent no-op in that state -- its next-side branch is guarded by
  `appendedClones.length > 0`. The drift reached the end and parked until the
  user dragged, which re-seated the track through Swiper's own touch path.
  One slide of runway is now left unspent at every breakpoint.
- Why desktop only: wider breakpoints spend more of the budget. With 10 products
  the spare was 5 slides at 2 columns and 3 at 3 columns, but exactly 0 at 5.
- Added a stall guard: if `loopFix()` fails to move the track for several
  consecutive frames, the marquee re-seats itself instead of freezing. This
  covers slide counts that change after init, such as Load More.
- Added a timeout on the coast flag. A zero-duration transition emits
  `transitionStart` without a matching `transitionend`, which could otherwise
  latch the drift off permanently.

## [2.16.0] - 2026-08-07

### Changed
- **Marquee rebuilt as a frame-driven drift engine.** v2.15.0 implemented
  marquee as Swiper autoplay with `delay: 0`. That was the wrong primitive:
  autoplay moves in slide-sized transitions and can only be interrupted between
  them, so `pauseOnMouseEnter` did not visibly stop anything until the current
  advance completed. The drift is now advanced one animation frame at a time in
  `slider.js` by writing the translate directly.
- **Marquee now works with `free_scroll`.** The previous build forced free mode
  off because autoplay transitions and free-mode momentum competed for the
  translate. The frame loop simply stands down while Swiper owns the track, so
  both can be enabled together.

### Fixed
- Hovering a marquee slider now freezes it on the exact pixel and resumes from
  the same position, instead of continuing to the next slide boundary.
- Holding a marquee slider on touch freezes it in place and releasing resumes
  it, with any free-mode momentum honoured first.

### Notes
- `slider_marquee_speed` keeps its meaning (milliseconds per slide advance).
  It is converted to a pixels-per-second rate at runtime from the measured
  slide width, so drift speed stays consistent across breakpoints.
- Wrapping reuses Swiper's own `loopFix()` edge test, so marquee inherits the
  loop slide-count budget: slide count must exceed the desktop column count.
- `prefers-reduced-motion: reduce` still disables the drift while leaving the
  slider draggable.

## [2.15.0] - 2026-08-07

### Added
- **Slider marquee mode.** `slider_marquee="yes"` turns the slider into a
  continuous edge-to-edge drift instead of the step-pause-step motion of
  autoplay. Implemented as autoplay with `delay: 0` and a long per-slide
  transition, with the Swiper wrapper easing switched to `linear` via the
  `--swiper-wrapper-transition-timing-function` custom property, so consecutive
  transitions chain into one constant glide.
- `slider_marquee_speed` (500-20000 ms, default 4000) controls how long a single
  slide advance takes, and therefore the drift speed.
- Marquee pauses on hover (`pauseOnMouseEnter`) and while the user holds/drags a
  card (`disableOnInteraction: false`), resuming on release. Both are native
  Swiper 11 behaviours; no custom event wiring.
- Marquee sliders respect `prefers-reduced-motion: reduce` by stopping autoplay
  at init. The slider stays fully draggable.

### Notes
- Marquee requires loop, and therefore the same slide-count budget:
  `slide count > desktop columns`. When loop is unavailable marquee disables
  itself and logs the reason under `WP_DEBUG`.
- Marquee forces free scroll off. Swiper's free-mode momentum competes with
  autoplay transitions and produces a stutter, so the two are mutually
  exclusive by design rather than by accident.

## [2.14.0] - 2026-08-07

### Added

- **`slider_pagination="none"` turns slider pagination off from the shortcode.**
  Previously the only way to hide the pagination was a `zymarg_product_grid_config`
  snippet or a CSS `display:none` override, because the shortcode silently
  discarded any value outside `bullets` / `progress`.

  `slider-wrapper.php` already treated an empty `pagination_type` as "render
  nothing" -- it skips both the Swiper `pagination` config and the
  `.swiper-pagination` element -- so no template work was needed. Two gates were
  removed instead:

  - the shortcode whitelist now maps `none`, `off`, `hide`, `no`, `false` and
    `0` to `''`;
  - `Config_Normalizer::validate()` now accepts `''` as a valid
    `pagination_type`, where it previously rewrote it back to `bullets`.

  Unrecognised values are still ignored rather than applied, so a typo falls
  back to the template default instead of breaking the slider.

  This also overrides the ZYMARG Template Pack's progress-bar default without a
  Template Pack update. `capture_explicit()` flags the setting via
  `array_key_exists( 'pagination_type', $slider )`, and `apply_defaults()` only
  fills values that were not set explicitly -- so an explicit `''` from the
  shortcode wins.

---

## [2.13.1] - 2026-08-07

### Fixed

- **Slider loop was still discarded with free scroll on -- regression introduced
  by 2.13.0.** Removing the `&& ! $free_scroll` guard was correct, but the
  `loopAdditionalSlides` runway added alongside it was sized far beyond what
  Swiper permits, so Swiper disabled looping on its own and the slider still
  dead-ended on the last card.

  From `loopFix()` in the bundled Swiper 11.2.10:

  ```js
  w = Math.ceil(parseFloat(h.slidesPerView, 10));
  const b = h.slidesPerGroupAuto ? w : h.slidesPerGroup;   // 1 by default
  let y = b; y += h.loopAdditionalSlides; d.loopedSlides = y;
  if (c.length < w + y) g("Swiper Loop Warning: The number of slides is not
    enough for loop mode, it will be disabled or not function properly...");
  ```

  The budget is therefore:

  ```
  slide count >= ceil(slidesPerView) + slidesPerGroup + loopAdditionalSlides
  ```

  2.13.0 requested `desktop columns x 2` of runway, so 8 products at 4 columns
  demanded `8 >= 4 + 1 + 8 = 13`. The check failed on any ordinary catalogue and
  Swiper switched loop off -- reproducing the exact symptom the release was
  meant to fix.

  The runway is now derived from the budget rather than guessed:

  ```php
  $zymarg_loop_runway = $zymarg_slide_count - $cols_d - 1;
  $swiper_config['loopAdditionalSlides'] = max( 0, min( $cols_d, $zymarg_loop_runway ) );
  ```

- **Minimum-slide guard corrected.** 2.13.0 disabled loop below
  `desktop columns x 2`, which was arbitrary and needlessly strict -- it turned
  looping off for valid configurations such as 8 products at 5 columns. The
  real requirement is one spare slide beyond the widest breakpoint
  (`slide count > desktop columns`), and that is what is enforced now. The
  `WP_DEBUG` notice reports the true required count.

### Added

- **Runtime budget clamp in `slider.js`.** The runway is re-derived from the
  actual `.swiper-slide` count and the largest `slidesPerView` across all
  breakpoints immediately before `new Swiper()`, then trimmed to fit -- or loop
  is switched off when even zero runway will not fit. This keeps looping correct
  when the slide count changes after render (Load More appending slides) and
  when a grid is re-used at column counts the PHP side did not size for.

---

## [2.13.0] - 2026-08-07

### Changed

- **Slider loop now works while Smooth free scroll is on.** Previously
  `slider-wrapper.php` force-disabled loop whenever free scroll was active
  (`&& ! $free_scroll`), so `slider_loop="yes" free_scroll="yes"` silently
  produced a non-looping slider that dead-ended on the last card. The two are
  now independent settings.

  Root cause: Swiper 11 wraps a looping slider with `loopFix()`. While the user
  is dragging, `touchMove` already calls `loopFix({ setTranslate: true })`
  continuously, so drag-wrapping always worked. The failure was the momentum
  coast after release -- Swiper only registers a post-momentum
  `loopFix()` when `centeredSlides` is enabled:

  ```js
  p = t.maxTranslate(), r.loop && r.centeredSlides && (f = !0);
  ...
  if (f && i("transitionEnd", (() => { t.loopFix() })), 0 !== t.velocity) {
  ```

  Our slides are left-aligned, so the fling clamped at `maxTranslate()` and
  stopped. Fixed with three coordinated changes:

  - `loopAdditionalSlides` is now set to `min( slide count, desktop columns x 2 )`,
    giving the fling enough cloned runway that it lands mid-track instead of on
    the clamp.
  - `slider.js` re-runs `loopFix()` on `transitionEnd` for looping free-scroll
    sliders, re-centring the clones so every subsequent fling has runway.
    Re-entrancy guarded; `loopFix()` compensates the translate, so nothing
    moves on screen.
  - Edge resistance (`resistanceRatio: 0.85`) is dropped when looping, since a
    looping track has no real edge to rubber-band against. Non-looping sliders
    keep the existing resistance.

- **`loopPreventsSliding` set to `false`** for looping sliders, so arrow clicks
  are not swallowed mid-wrap.

### Added

- **Minimum-slide guard for loop mode.** Swiper needs more slides than one
  viewport plus its clone buffer or it logs *"The number of slides is not
  enough for loop mode"* and disables looping itself, leaving a visible gap at
  the wrap point. Loop is now switched off automatically when the product count
  is below `desktop columns x 2`, with a `WP_DEBUG` notice naming the actual and
  required counts instead of a bare Swiper console warning.

---

## [2.12.0] - 2026-08-06

### Added

- **`Public_API::query()`** -- fetch products for a source without rendering
  any markup. Consumers that own their own layout, filters and card loop
  previously had two options, and both were wrong: duplicate the source logic,
  or call `Query_Builder` directly, which is internal and free to change under
  them. Returns `WC_Product[]`, or `HIDE_WIDGET` when the source asked for no
  output or the key is unavailable. Never throws. Accepts `limit` and `offset`
  so a consumer can paginate through a source.
- **`Public_API::has_source()`** -- whether a source key is registered *and*
  its class is loadable. The second half is the point: a key can be registered
  while the class ships later, and `resolve_source()` silently substitutes
  `Source_All` in that case, so an ungated caller would render a "Flash Deals"
  page full of unrelated products and see no error anywhere.
- **`Query_Builder::get_registry()`** and **`Query_Builder::has_source()`** --
  the registry array was previously built inline inside `resolve_source()`,
  which made "what sources exist?" unanswerable without instantiating one.
  Consumers were therefore keeping private hardcoded copies of the list, which
  go stale silently in both directions. Behaviour of `resolve_source()` is
  unchanged, including its deliberate `Source_All` fallback.
- New `zymarg_query_failed` action, mirroring `zymarg_render_failed`.

### Notes

- Purely additive. No existing method, signature or behaviour changed, so no
  existing caller can observe this release.
- `query()` inherits the source layer's limits: `MAX_PRODUCTS` (100) and the
  `UNLIMITED_DEFAULT_CAP` (500) still apply, and sources return bounded arrays
  with no total count. A consumer paginating a source must infer "has more"
  from a full batch, as `Handler_Load_More` does.

---

## [2.11.0] - 2026-08-06

### Fixed

- **Section cache could serve the wrong markup.** `build_key()` hashed layout
  type, card template, source, columns, limit and ordering, but none of the 17
  card `show_*` flags, `layout.gap`, the slider sub-array, pagination, the
  responsive overrides or the heading block. Two grids running the same query
  with different display settings produced an identical key. The key now
  fingerprints every config block, so keys added later -- or injected by the
  `zymarg_product_grid_config` filter -- are covered automatically.
- **Load More cards did not match the first page.** Twelve settings the cards
  read were absent from the POST whitelist, and `Countdown_Renderer` learns the
  active source from `zymarg_product_grid_before_render`, which only
  `Render_Engine` fires -- so in AJAX the source stayed empty and
  `show_countdown = 'auto'` always resolved to off. Routing Load More through
  the full pipeline remains the longer-term goal.
- **Debug overlay could leak to visitors.** It was appended inside
  `Render_Engine::render()` and the result cached under a key with no viewer
  dimension. Debug renders now bypass the cache.
- **Rate limits could be bypassed with a forged header.** `get_client_ip()`
  read `HTTP_X_FORWARDED_FOR` / `HTTP_CF_CONNECTING_IP` unconditionally. They
  are now consulted only via `ZYMARG_WCPG_TRUST_PROXY` or the new
  `zymarg_wcpg_trust_proxy_headers` filter. Fixed in both copies.
- **Add to Cart mutex was not atomic.** `get_transient()` + `set_transient()`
  is check-then-act. Acquisition now uses `add_option()` against a UNIQUE index,
  with stale-lock reclamation after 10 seconds.
- **Empty product shells on category and search pages.**
- **`HIDE_WIDGET` was never cached**, so the most expensive outcome was the
  only one repeated in full on every page load.
- **Guest wishlist cookie could exceed the browser limit** and silently stop
  persisting. Capped via `zymarg_wcpg_wishlist_cookie_max_ids`.
- **Late-injected sliders never initialised.**
- **Flash sale window was filterable on read but not on write.**
- **Enum drift silently reset valid selections.** `percent`, `sold_n`,
  `n_sold` and `sold_n_plus` are now aliased. `both` and `count_indicator` have
  no engine equivalent and still fall back to the default.

### Notes

- The Elementor slider adapter still emits `show_arrows` and
  `pagination_type` unconditionally, so Template Pack slider defaults cannot
  apply to Elementor widget renders. Deliberately out of scope.

---

## [2.10.3] - 2026-08-06

### Added

- Slider wrappers now emit `data-card-template="<slug>"` alongside the existing
  `data-widget-id` / `data-zymarg-hydrate` attributes. Slider chrome -- the
  pagination element and the navigation arrows -- is rendered by the engine
  OUTSIDE `.zymarg-wcpg__card`, so a card template's stylesheet, which is scoped
  to its own card class, had no selector that could reach it. Card templates can
  now style their own slider chrome via
  `.zymarg-wcpg--slider[data-card-template="<slug>"]` without the engine having
  to know anything about them. Purely additive: no existing selector, template
  or config key changes behaviour.

---

## [2.10.2] - 2026-08-06

### Fixed

- Slider still painted as a single full-width card on first load after 2.10.1,
  because the sizing rules shipped in 2.10.1 live in `slider.css` -- and on a
  page that renders the grid from a shortcode, that stylesheet is not in
  `<head>` at all. Shortcodes render inside `the_content()`, after `wp_head()`
  has printed, so WordPress prints every stylesheet enqueued during the render
  in the FOOTER. The entire grid painted unstyled, not just unsized. Two
  independent fixes:
  - `Shortcode_Asset_Preloader` now detects `[zymarg_products]` (it previously
    knew only about the wishlist and recently-viewed shortcodes) and resolves
    its assets through `Asset_Manager::enqueue_for_render()`, so the frontend
    CSS, the slider bundle, Swiper's CSS, and the card template's own
    stylesheet all land in `<head>`. Its hook priority moved 5 -> 6 so handle
    registration at 5 is guaranteed to have happened rather than depending on
    class instantiation order.
  - `slider/slider-wrapper.php` additionally inlines the slide-sizing rules as
    critical CSS, once per request, on pages that contain a slider. Inline CSS
    is parsed immediately and needs no request, so slide sizing is correct at
    first paint even where the preloader cannot help -- shortcodes inside
    widgets, popups, reusable blocks, or template parts, none of which appear
    in `post_content`.

---

## [2.10.1] - 2026-08-06

### Fixed

- Slider layout shift on first load: every slider rendered as a single
  full-width card until Swiper initialised, then snapped into its real column
  layout. Swiper's stylesheet sizes `.swiper-slide` at `width:100%` and only
  writes per-slide widths from JS, and the slider wrapper published nothing CSS
  could size from -- its `slidesPerView` is the mobile count with breakpoints
  resolved in JS. `slider-wrapper.php` now emits the resolved desktop/tablet/
  mobile counts and the slide spacing as custom properties (`--zc-spv-d/t/m`,
  `--zc-slide-gap`) and `slider.css` sizes slides from them at first paint.
  Fixed in the engine rather than per template, so it applies to every card
  template -- bundled, Template Pack, or third-party.
- As a side effect, a slider whose JS never initialises (page builder preview
  that does not fire the init hooks, or a Swiper load failure) now lays out with
  the correct number of columns instead of one full-width card.

---

## [2.10.0] - 2026-08-03

### Added

- **Flash Deals is now admin-curated.** A product appears in the source only when an admin has explicitly flagged it *and* it satisfies the full data contract. Scheduling a sale no longer places a product in the grid on its own.
  - New **Flash Deal** checkbox on Product data -> General.
  - New **Add to / Remove from Flash Deals** bulk actions on the products list.
  - Both surfaces are gated on `manage_woocommerce`, so Dokan vendors never see them and cannot self-promote into the grid.
- **New `Flash_Deals_Validator`** — the single source of truth for eligibility. The source gate and every admin surface read from this one class, so a product can never be silently excluded by one and reported as healthy by the other.
  - Requires: published and catalog-visible, featured image, regular price, lower sale price, sale end date, stock management on, stock quantity above zero, backorders off.
  - Variable products: **every on-sale variation** must independently manage stock, since the card renders one aggregate scarcity bar for the parent.
- **New Flash Deals column** on the products list, reporting per product exactly why it is or is not live.
- **New `Flash_Sales_Counter`** — tracks units sold *within the current sale window*, keyed to the window start so each run of a sale counts from zero. WooCommerce only tracks lifetime sales, which would make a long-selling product open its flash sale already looking sold out.

### Why the contract is strict

Every flash card renders a scarcity bar and a countdown. A product missing the data behind either one would render a visibly different card, which is precisely the inconsistency the gate exists to prevent. Products failing the contract are excluded — but never silently: the products list states the reason.

Configuration errors (no stock management, no image) are reported. Lifecycle states (sale ended on schedule, sale not started yet) are shown as neutral and never flagged as problems — a warning that fires on every completed sale is one nobody reads.

### Upgrade note

**No products will appear in Flash Deals until an admin flags them.** This is intentional: the previous behaviour promoted any scheduled sale automatically. Flag products via the checkbox or the bulk action, then check the Flash Deals column for anything still reported as not live.

## [2.9.0] — 2026-08-01

**Theme of this release: making the deadline visible.** v2.8.0 taught the engine
which sales are genuinely time-limited, but a shopper looking at the grid still
had no idea how much time was left. This release renders that deadline.

Two constraints shaped the whole design:

1. **Rendered HTML is cached.** Any digits formatted in PHP would freeze at the
   moment the cache entry was written, and a visitor could be served a grid
   claiming "Ends in 3h" long after the sale finished. So the server prints
   *only* an absolute UTC end timestamp and every visible digit is produced in
   the browser.
2. **A card template must never have to know about this.** The countdown is
   rendered through the card action hooks that every card already fires, so the
   bundled `classic` card, the Template Pack's `zymarg` card, and any card added
   in future all get the timer with no template edit and no engine change.

### Added

- **`Render\Countdown_Renderer`** (new file `includes/Render/class-countdown-renderer.php`).
  Subscribes to `zymarg_after_card_price`, `zymarg_after_card_image`, and
  `zymarg_before_card_title`, and renders at whichever one matches the
  configured position. Nothing in it inspects the template slug.
- **`card.show_countdown`** — `'auto'` (default) | `'yes'` | `'no'`. `'auto'`
  enables the timer for the `flash_deals` source only, so existing grids are
  completely unaffected by the upgrade.
- **`card.countdown_position`** — `'below_price'` (default) | `'over_image'`
  | `'before_title'`.
- **Elementor:** a *Countdown Timer* section in the Settings tab (mode +
  position) and one in the Style tab (text colour, background, ended-state
  colour, responsive font size).
- **Shortcode:** `show_countdown` and `countdown_position` attributes. Both are
  only applied when explicitly supplied, so omitting them leaves `'auto'` to
  decide per source.
- **`Source_Flash_Deals::get_end_ts( $product_id )`** and
  **`::end_ts_for( \WC_Product $product )`**. The source already walks variations
  to find each product's real sale window while querying, so it now publishes
  that map for the renderer instead of making it repeat the work. `end_ts_for()`
  is the on-demand path used when the countdown is enabled on a non-Flash-Deals
  source, and it deliberately reuses `resolve_sale_window()` — reading the
  parent's `_sale_price_dates_to` directly would silently drop every variable
  product.
- New filters `zymarg_wcpg_countdown_end_ts` (return `0` to suppress a timer),
  `zymarg_wcpg_countdown_html`, and `zymarg_wcpg_countdown_auto_sources` (which
  sources `'auto'` covers).
- New i18n keys: `countdownEndsIn`, `countdownEnded`, `countdownSrFormat`, and
  translatable short unit suffixes `countdownDay` / `Hour` / `Minute` / `Second`.

### Behavior

- **Self-suppressing.** If no *future* sale end date resolves for a product, no
  markup is emitted at all. This is what makes `'yes'` safe to set on a Featured
  or Best Selling grid: qualifying products get a timer, the rest are untouched.
- **Expiry keeps the card in place.** At zero, the digits are replaced with
  "Deal ended" and the card stays exactly where it is. Removing or re-flowing
  the card would shift the grid under the visitor's pointer and corrupt slider
  geometry mid-view.
- **Adaptive format.** Days appear only when at least one full day remains;
  seconds appear only inside the final hour, where they actually convey urgency.
- **Clock-skew correction.** `data-now` carries the server clock. A large gap
  against the device clock means the visitor's clock is genuinely wrong and is
  corrected; a gap under a minute is treated as cache age and ignored, so a
  cached page is never distorted by mistaking its own age for skew.
- **One shared ticker.** A single one-second interval drives every timer on the
  page rather than one interval per card. Each tick recomputes from the absolute
  end time, so the display cannot drift however many ticks are throttled or
  missed. The interval stops while the tab is hidden and while no live timer
  remains, and re-scans on `zymarg:loadmore:done` so cards arriving via Load
  More or infinite scroll are adopted.
- **Accessibility.** `role="timer"`, with a visually-hidden companion string
  updated once per minute; a per-second live region would be unusable with
  assistive technology.
- A `zymarg:countdown:ended` DOM event fires on each timer as it expires.

### Notes

- **No Template Pack release is required.** An earlier draft of this plan
  assumed the ZYMARG card would need editing; it does not — it already fires the
  shared card hooks. The Template Pack stays at v1.4.5.
- A future dedicated flash-sales card template will inherit the countdown
  automatically, provided it fires the standard card hooks like the existing
  cards do.
- `'over_image'` positioning assumes the card's image wrapper is positioned,
  which is true of both shipped cards.

---

## [2.8.0] — 2026-08-01

**Theme of this release: a source for genuinely time-limited deals.** The engine
had thirteen sources but no way to answer "what is on sale *right now, for a
limited time*". `Source_All` with `orderby=date` cannot express it, and
WooCommerce's own on-sale list deliberately mixes permanent markdowns in with
scheduled campaigns. Flash Deals draws that line explicitly.

### Added

- **`flash_deals` source** — `includes/Query/class-source-flash-deals.php`,
  registered in `Query_Builder::resolve_source()` and therefore available to
  every consumer at once: `[zymarg_products source="flash_deals"]`, the
  `Public_API::render()` config array, and the Elementor Source dropdown
  ("Flash Deals (time-limited sales)").
- **Qualifying rule.** A product qualifies only when *all* of the following
  hold: it appears in `wc_get_product_ids_on_sale()`; it has a sale end date
  (`get_date_on_sale_to()`); that end date is still in the future; it is
  visible; it is in stock (unless `show_oos`); and it passes the shared
  include/exclude filters. **A sale with no end date is excluded** — that is a
  permanent price change, not a flash deal. This is intentional and is the one
  behaviour to be aware of before reporting an empty grid.
- **`query.flash_orderby`** (default `sale_end`) — `sale_end` (ending soonest
  first), `discount` (biggest percentage first), plus `price`, `title`, `date`,
  `popularity`, `rating`, `rand`. This deliberately shadows the global
  `orderby` for this source, because the global default (`date`) would
  otherwise defeat the entire point of the source. `sale_end` also ignores the
  global `order` flag — "ending soonest" has only one meaningful direction.
- **`query.flash_min_discount`** (0-100, default 0) — drop deals below a
  minimum discount percentage.
- **`query.flash_vendor_scope`** (`auto` | `site` | `vendor`, default `auto`) —
  Dokan scoping. `auto` is site-wide everywhere but narrows to the vendor whose
  store page is being viewed, which is exactly the "homepage now, store pages
  later" behaviour this was requested for. `vendor` returns `HIDE_WIDGET` away
  from a store page rather than silently falling back to site-wide.
- Shortcode attributes `flash_vendor_scope`, `flash_min_discount`,
  `flash_orderby`; matching Elementor controls in a "Flash Deals settings"
  section conditional on `source = flash_deals`, with an explanatory notice
  about the sale-end-date requirement.
- Filters `zymarg_wcpg_flash_deals_vendor_id` (override the resolved vendor)
  and `zymarg_wcpg_wishlist_url`.
- Wishlist localisation the engine had never exposed to JS:
  `i18n.removedFromWishlist`, `i18n.viewWishlist`, and top-level
  `wishlistUrl`. Template Pack 1.4.4+ already reads all three, so its
  "View wishlist" toast action lights up once both plugins are on these
  versions.

### Fixed

- **Variable products are no longer dropped from on-sale lists.** WooCommerce
  stores `_sale_price_dates_to` on the *variation*, never on the parent, so any
  implementation that filters the on-sale ID list by parent meta silently
  discards every variable product. `resolve_sale_window()` walks
  `get_children()` and lets the soonest-ending qualifying variation represent
  the product.

### Changed

- **Cache TTL is clamped to the soonest sale end.** A grid of deals ending in
  90 seconds would otherwise sit in the render cache for the full 300-second
  default TTL and keep advertising a finished sale. The source attaches a
  one-shot `zymarg_cache_ttl` filter bounded by the remaining window.
- `detect_current_vendor_id()` moved from `Source_Current_Vendor` (where it was
  `private`) up to `Source_Base` as `protected`, so vendor-aware sources share
  one resolution path. The now-redundant subclass copy was removed — leaving a
  `private` override of a `protected` parent method is a PHP fatal error, not a
  style preference. No behavioural change.
- Empty result sets return `Source_Base::HIDE_WIDGET`, so a page with no active
  flash deal hides the section instead of rendering an empty row.

### Notes

- **Data prerequisite:** products need *Product data > General > Sale price
  dates > to* filled in. For variable products the dates live on the
  variations. Without an end date the grid is legitimately empty — that is the
  rule working, not a bug.
- No countdown timer yet; the card templates are unchanged this release.

---

## [2.7.0] — 2026-07-31

**Theme of this release: Elementor becomes optional.** The engine already rendered
through three consumers (Elementor widgets, `[zymarg_products]`, and
`Public_API::render()`), but two hard couplings still forced Elementor to stay
installed. Both are removed, and the gaps that only Elementor was filling
(Swiper, icons, widget-only controls) are now filled by the plugin itself.

### Removed (dependency)

- `Requires Plugins: woocommerce, elementor` in the main plugin header is now
  `Requires Plugins: woocommerce`. On WP 6.5+ the old value made WordPress
  refuse to deactivate or delete Elementor while this plugin was active
  ("Required by: ZYMARG WC Product Grid").
- `Compatibility::is_environment_ready()` no longer registers an Elementor
  blocker. The 3.18+ check (`ZYMARG_WCPG_MIN_ELEMENTOR`) still runs, but only
  when Elementor is actually present, and it reports through the optional
  notices channel instead of blocking activation.

### Changed

- `Plugin::init()` registers `Elementor\ElementorLoader` only when
  `Compatibility::is_elementor_active()` is true, so no Elementor class is
  referenced on a site without it.
- `Assets::resolve_swiper_handle()` now resolves in this order: already-registered
  `zymarg-wcpg-swiper` handle, bundled local copy, `swiper`, `elementor-swiper`,
  jsDelivr CDN. Previously an Elementor-provided handle won over the local copy,
  which meant a site could silently run Elementor's older Swiper build.
- Swiper version string updated from `11.0.0` to `11.2.10` in all four places.
- Plugin header description rewritten to describe an engine with an optional
  Elementor consumer rather than an Elementor widget pack.

### Added

- **Bundled Swiper 11.2.10** (MIT) at `assets/js/swiper-bundle.min.js` and
  `assets/css/swiper-bundle.min.css`. Slider layouts now work with no Elementor
  and no outbound internet request. The `sourceMappingURL` comment is stripped
  so the browser does not request a missing `.map` file.
- **Inline SVG icon fallbacks.** `Product_Data::render_icon()` now resolves in
  three steps: an Elementor icons-control array, then a bundled inline SVG, then
  a raw `<i>` tag. Six icons are bundled with Font Awesome 6 geometry:
  `fas fa-plus`, `far fa-eye`, `far fa-heart`, `fas fa-heart`,
  `fas fa-chevron-left`, `fas fa-chevron-right` - i.e. add to cart, quick view,
  wishlist idle, wishlist active, and both slider arrows. Without this, those
  controls rendered as blank squares on a site with no Font Awesome.
- New helpers `Product_Data::inline_svg()` and `Product_Data::icon_svg_map()`,
  plus filters `zymarg_wcpg_inline_svg_icon` (markup, key) and
  `zymarg_wcpg_icon_svg_map` (the whole map).
- CSS rule `.zymarg-wcpg__svg-icon` (1em square, `currentColor`, `-0.125em`
  baseline shift) so inline SVGs sit exactly where the icon font used to.
- **Shortcode parity with the Elementor widget.** `[zymarg_products]` gained ten
  attributes that previously existed only as widget controls:
  - Slider: `slider_arrows`, `slider_pagination` (`bullets` | `progress`),
    `slider_loop`, `slider_autoplay`, `slider_autoplay_delay` (100-30000),
    `slider_speed` (100-10000), `slider_space_between` (0-100).
  - Heading: `heading_subtext`, `heading_alignment` (`left` | `center` | `right`).
  - Pagination: `load_more_text`.
- Every new attribute defaults to an empty string and is applied only when
  explicitly provided, so `Config_Defaults` and template-pack overrides (for
  example the ZYMARG pack forcing progressbar pagination and hidden arrows)
  remain authoritative for anyone who does not set them.

### Security

- `Rate_Limiter::defaults()` re-adds `load_more` at 120 requests per 60 seconds
  per visitor. It was dropped in 1.5.8 as a click-driven, read-only action, but
  infinite scroll (2.6.0) drives the same AJAX action from an IntersectionObserver.
  A stuck sentinel, a resize loop, or a scripted scroll could issue product
  queries far faster than a human ever clicked. The ceiling is deliberately high:
  the largest configured desktop run is a 100-product cap in 20-product batches,
  i.e. five auto-requests, so a legitimate shopper cannot reach it.

### Upgrade notes

- **Install and activate 2.7.0 BEFORE removing Elementor.** If Elementor is
  deleted first, WP 6.5+ will refuse to activate the older build, and there is no
  admin UI for building grids to recover with.
- Elementor Style-tab settings live in Elementor's own data and are lost when
  Elementor is removed. Screenshot them first, then reproduce the equivalent
  values through shortcode attributes or CSS.
- Find pages that still embed the widget with:
  `SELECT post_id FROM wp_postmeta WHERE meta_key = '_elementor_data' AND meta_value LIKE '%zymarg_product_grid%';`

---

## [2.6.1] — 2026-07-31

### Added

- `[zymarg_products]` now supports the heading "View All" link through five new attributes: `show_view_all`, `view_all_text`, `view_all_url`, `view_all_auto_vendor`, and `view_all_vendor_product_id`.
- Shortcode docblock examples for the View All link and for infinite scroll.

### Changed

- `default_atts()` gained the five View All keys, all defaulting to an empty string.
- `build_heading()` translates the new attributes into canonical `heading.*` config, matching the keys the Elementor settings adapter already emits.

### Behavior

- `view_all_url` accepts a plain URL string, sanitized with `esc_url_raw()`. `Config_Normalizer` expands it into the `{ url, is_external, nofollow }` array shape the wrapper templates read.
- Setting `view_all_auto_vendor="true"` with no `view_all_url` lets `Public_API::maybe_apply_auto_vendor_view_all()` resolve the vendor store URL, exactly as the Elementor path does.
- `view_all_vendor_product_id` is clamped to a non-negative integer; `0` means auto-detect the current product.

### Compatibility

- Fully backward compatible. Every new attribute is opt-in, and an omitted attribute leaves the corresponding config key untouched.
- No engine, template, asset, or Template Pack changes. Template Pack stays at v1.4.3.

## [2.6.0] — 2026-07-31

### Added
- **Infinite scroll pagination mode** for the grid layout, selectable in Elementor alongside `None` and `Load more button`, and via the shortcode as `pagination="infinite"`.
- **Per-device auto-load batch sizes** (`infinite_batch_size`, `_tablet`, `_mobile`; defaults 20 / 20 / 10), separate from the widget's Number of products setting.
- **Per-device auto-load caps** (`infinite_max_products`, `_tablet`, `_mobile`; defaults 100 / 100 / 50). The cap counts auto-loaded products only, never the first page.
- **Frosted-glass loader pill** ported 1:1 from the approved mockup: fixed-position pill, pulsing dots, waving label, and a check-mark confirmation state when the catalog is exhausted.
- Shortcode attributes `batch_size`, `batch_size_tablet`, `batch_size_mobile`, `max_products`, `max_products_tablet`, `max_products_mobile`.
- Custom jQuery events on the widget element: `zymarg:loadmore:start`, `zymarg:loadmore:done`, `zymarg:loadmore:fail`.

### Changed
- The Load more AJAX handler now accepts an explicit `offset` and `batch`. When present, the offset drives the query directly instead of page-number math, so a batch size that differs from the first-page size can never skip or duplicate products. `batch` is clamped to 48 server-side.
- `Load more button text` now also applies to infinite scroll, since the button is revealed once the cap is reached.

### Behavior
- Once the cap is reached the pill fades out, the Load more button appears, and automatic loading does not resume for that page view.
- When the catalog runs out, the pill switches to "All products loaded" and the observer disconnects.
- A failed or rate-limited request stops automatic loading and restores the manual button, so scrolling can never produce a retry loop.

### Compatibility
- Existing `none` and `load_more` widgets are untouched: without a batch value the request payload is byte-for-byte identical to v2.5.0.
- Infinite scroll is progressive enhancement. The button is rendered server-side and only hidden by script, so browsers without IntersectionObserver keep working manual pagination.
- Device values are resolved in the browser from viewport width (768 / 1025 breakpoints), keeping cached HTML correct for every device.
- Works with all sources, including Algolia search, category, and Dokan vendor contexts, because it reuses the existing request path.

## [2.5.0] — 2026-07-31
### Added
- Smooth free-mode scrolling for the slider layout on BOTH templates: continuous, momentum-based dragging (`freeMode` + `grabCursor` + `resistanceRatio`) instead of snapping one product per swipe. Default on.
- Mouse wheel / trackpad horizontal scrolling (`mousewheel` with `forceToAxis` + `releaseOnEdges`). Default on.
- Elementor controls `slider_free_scroll` and `slider_mousewheel` (default yes); shortcode attributes `free_scroll` and `mousewheel`; config keys `layout.slider.free_scroll` / `layout.slider.mousewheel`.
### Changed
- Loop is automatically disabled while free scroll is on (Swiper loop + freeMode is unstable). The Loop control is hidden in that mode; disable free scroll to use looping.
- Step-based autoplay behavior is unchanged.

## [2.4.4] — 2026-07-30
### Fixed
- Slider layout ignored `layout.gap`. Swiper `spaceBetween` defaulted to a hardcoded 20px and never read the grid gap, so sliders (classic and ZYMARG) did not respond to the gap setting. `spaceBetween` now inherits `layout.gap` when slide spacing is unset, so one gap value drives both grid and slider across all consumers.
### Changed
- Elementor "Slide spacing (px)" control now defaults to empty, meaning "match the grid gap". An explicit value still overrides per instance.
- `layout.slider.space_between` default changed from `20` to `null` (inherit the grid gap).

## [2.4.3] — 2026-07-30

### Changed

- **Default grid gap reduced to 6px** (from 14px in 2.4.2; originally a hardcoded 20px). Applies globally via the `--grid-gap` custom property to the Elementor widget, the `[zymarg_products]` shortcode, and standalone plugins. Fully overridable per instance.

### Notes

- The ZYMARG Template Pack v1.4.2 sets its own 8px gap default for ZYMARG-branded grids (`.zymarg-wcpg--card-zymarg`). Classic and other templates use the 6px engine default.

---

## [2.4.2] — 2026-07-30

### Fixed

- Grid gap knob was dead: the grid CSS hardcoded `gap: 20px`, so `layout.gap` and Elementor's Grid gap control never reached the front end.

### Added

- Grid gap emitted as a `--grid-gap` CSS custom property on the grid wrapper; stylesheet uses `gap: var(--grid-gap, …)`. Consistent across all consumers (Elementor, shortcode, standalone).
- `gap` attribute for the `[zymarg_products]` shortcode (e.g. `gap="12"`), clamped 0–100px.

### Changed

- Default grid gap set to 14px.

---

## [2.4.1] — 2026-07-30

### Fixed

- Slider progress-bar pagination did not render — the wrapper passed Swiper the type `progress` instead of Swiper 11's `progressbar`. `slider-wrapper.php` now maps to the correct Swiper pagination type.

---

## [2.4.0] — 2026-07-30

### Added

- Automatic **Current Vendor** resolution: the `vendor` source auto-detects the vendor from the current product/store context when no explicit ID is given (an explicit ID still wins). Usable on Single Product / Single Store templates without manual config.
- Configurable slider defaults (pagination type, navigation arrows) that template packs can set and that remain per-instance overridable in Elementor.
- Heading **View All** link support for non-Elementor (shortcode / standalone) consumers.

---

## [2.3.0] — 2026-07-29

### Fixed

- Card templates now render consistently for non-Elementor consumers. Shortcode and `Public_API` (standalone) renders previously missed setup performed only by the Elementor widget, so cards could render incomplete outside Elementor. The render path was unified so all consumers produce identical card output.

---

## [2.2.0] — 2026-07-29

Closes the last gap in the template-pack story. v2.1.0 made externally
registered card templates *render*; this makes them *selectable* by someone
building a page visually.

### Added

- **Card template selector in the Elementor widget** — *Content → Layout →
  Card template*.

  The widget had no card template control of any kind. `build_card()` in
  `Elementor_Settings_Adapter` mapped 22 card properties but never `template`,
  so the widget always rendered `classic` no matter which templates were
  registered. A card template could only be selected via the shortcode or a PHP
  call, which made the entire template-pack system unreachable for anyone
  building pages in Elementor.

  Options are read from `Template_Manager::get_registered_cards()`. Elementor
  registers controls on `elementor/widgets/register`, which runs long after
  `plugins_loaded`, so every template plugin has already called
  `register_card()` by then — activating a template plugin makes its template
  appear in the dropdown with no change to this widget.

- **`zymarg_card_template_labels` filter.**

  ```php
  add_filter( 'zymarg_card_template_labels', function ( array $labels ) {
      $labels['zymarg'] = 'ZYMARG Branded';
      return $labels;
  } );
  ```

  The registry stores `slug => path` and carries no display name, so labels are
  derived from the slug (`my_fancy-card` → "My Fancy Card"). This filter lets
  the plugin that owns a template present a proper name.

  The filter can **rename** an option but cannot **add or remove** one — the
  return value is intersected against the registry, so a filter cannot
  introduce a template that was never registered or hide one that was.

### Changed

- `classic` is always listed first and labelled "Classic (default)"; the
  remaining slugs are sorted alphabetically, so dropdown order does not depend
  on plugin load order.

### Compatibility

No behaviour change for existing content:

| Scenario | Result |
|---|---|
| Widget saved before 2.2.0 (no `card_template` setting) | Control default applies → `classic`, exactly as before |
| `card_template` saved as an empty string | `classic` |
| Template plugin deactivated after selection | `Config_Normalizer` validates against the registry and falls back to `classic`; page keeps rendering |
| Shortcode / PHP / filter usage | Untouched |

Because `card.template` became part of the cache key in v2.1.0, two widgets on
one page using different card templates cache independently.

### Documentation

- **Corrected a wrong example in `docs/09-templates.md`.** It showed:

  ```php
  'config' => [ 'template' => 'fashion' ],   // never worked
  ```

  `Config_Normalizer` only reads `$config['card']['template']`. A top-level
  `template` inside `config` is silently ignored and the render falls back to
  `classic`, so anyone following the documentation would have concluded the
  feature was broken. Both occurrences fixed, with the constraint called out
  explicitly. This is the same wrong-key family as the three defects fixed in
  v2.1.0.

- **`docs/02-shortcode.md` did not document `card_template` at all**, despite
  it shipping in v2.0.7. Added, including the distinction between `template`
  (a Template Registry appearance preset) and `card_template` (the design of
  each product card) — two similarly named attributes doing different things.

- Removed the obsolete "when the widget exposes a template selector in a future
  release" note, and added `card_template` → `card.template` to the Elementor
  control mapping tables in `ARCHITECTURE.md`.

### Still not addressed

Unchanged from v2.1.0: `register_layout()` does not exist, the Context Engine
is unimplemented, and native search has no source. See **Known Gaps** in
`ARCHITECTURE.md`.

---

## [2.1.0] — 2026-07-29

Audit release. Every item below is a defect found by tracing the render
pipeline against the documented architecture, not a reported issue.

### Fixed

- **Externally registered card templates rendered as empty cards.** The blocker.
  `Template_Manager::register_card()` stores an **absolute** path — the documented
  usage is `plugin_dir_path( __FILE__ ) . 'templates/product-card.php'` — but
  `Template_Loader::get_template()` unconditionally treated every path as
  relative to this plugin's own `templates/` directory:

  ```php
  $template_name = ltrim( $template_name, '/' );                  // strips the leading /
  $located = locate_template( [ 'zymarg-wcpg/' . $template_name ] ); // → ''
  $located = ZYMARG_WCPG_DIR . 'templates/' . $template_name;      // concatenated!
  ```

  An external path became
  `…/zymarg-wc-product-grid/templates/var/www/…/zymarg-template-pack/templates/product-card.php`.
  `file_exists()` failed, `get_template()` returned void, and `render_card()`
  returned `''` for every product — the grid emitted its wrapper containing no
  cards, with no warning. The core `classic` template was unaffected only
  because `CARD_TEMPLATES` stores a *relative* path.

  No path form could work: a relative path from an external plugin would have
  resolved inside this plugin's directory instead. `Template_Loader` now
  detects absolute paths and loads them directly.

  This is the **second** defect to have blocked external template packs. v2.0.8
  fixed the missing `zymarg_wcpg_init` hook so registration could run; this
  fixes the path resolution that made a successful registration useless.

- **Theme overrides did not work for external templates.** An absolute path
  outside this plugin carries no meaningful override key, so `render_card()`
  now derives one from the slug. Themes get one predictable location that
  behaves identically for bundled and external templates:
  `theme/zymarg-wcpg/cards/{slug}/product-card.php`.

- **A card template's companion `style.css` / `script.js` never loaded for
  external templates.** Two independent faults in
  `Asset_Manager::maybe_enqueue_card_template_assets()`: it read the slug from
  `$config['template']`, which does not exist in a normalized config (canonical
  location: `$config['card']['template']`), so it always resolved to `classic`;
  and it only ever searched `ZYMARG_WCPG_DIR . 'templates/cards/{slug}/'`,
  inside this plugin. Since core ships no `templates/cards/classic/style.css`,
  the method enqueued nothing at all. Asset lookup is now performed relative to
  the template's own directory.

- **All four page consumers queried the wrong source.** v2.0.3 deliberately
  removed `query.source` from every built-in template config on the principle
  that the consumer owns source selection — but the four consumers were never
  updated to pass one. Each sent only `slot` + `context`, so `Config_Defaults`
  supplied `source => 'all'` in every case:

  | Page | Intended | Actual before 2.1.0 |
  |---|---|---|
  | Single product → Related | `similar` | `all` |
  | Dokan store page | `current_vendor` | `all` |
  | Product category archive | `category` | `all` |
  | Search results | `algolia` | `all` |

  Because each consumer first removes WooCommerce's default loop, this replaced
  correct output with incorrect output rather than merely doing nothing. Each
  consumer now declares its source explicitly.

- **Render cache key collisions.** `Cache_Manager::build_key()` read
  `$config['template']` and `$config['query']['total_products']`. Neither key
  exists in a normalized config — the canonical keys are `card.template` and
  `query.limit` — so both silently fell back to their defaults (`classic`, `8`).
  Two renders differing only by card template, or only by product limit,
  produced an identical cache key and served each other's HTML for the lifetime
  of the entry (default 300s).

- **`ZYMARG_DEBUG` overlay misreported the card template.** It read the same
  nonexistent `$config['template']` key and therefore always printed `classic`,
  meaning the only tool for diagnosing template problems actively misreported
  them.

- **`zymarg_products` and `zymarg_render_config` received no context.** Both
  passed a literal `[]` as the `$context` argument while documenting it as
  "Resolved context". In `Public_API` the real `$context` was in scope on the
  same line. Context-aware extensions — the filters' most obvious use case —
  were impossible to write. Both now receive the resolved context.

- **Broken indentation** in `Public_API::render()` (spaces mixed into a
  tab-indented file) normalised.

### Added

- **`zymarg_render_failed` action**, fired when a render throws:

  ```php
  do_action( 'zymarg_render_failed', \Throwable $e, array $args );
  ```

  `Public_API::render()` still fails soft and returns an empty string, but the
  throwable is no longer discarded. It is logged when `WP_DEBUG` is enabled and
  exposed to monitoring extensions. Previously any failure inside the pipeline
  was indistinguishable from "no products found", which is precisely why the
  template path blocker above went unnoticed.

- **`Template_Manager::get_card_assets( string $slug ): array`** — returns the
  filesystem path, public URL and cache-busting version for a card template's
  companion `style.css` and `script.js`. Template_Manager remains the only class
  that knows where template files live (Rule #6); Asset_Manager consumes the
  result and only decides how to enqueue it. Resolution is relative to the
  template's own directory, so it works for bundled and external templates
  alike. External assets are versioned by file modification time, because a
  template plugin ships updates independently of this engine's version.

- **Missing-template diagnostics.** A template that cannot be located logs
  under `WP_DEBUG` instead of failing silently.

### Changed

- **`Template_Loader::get_template()` / `get_template_html()`** gain an optional
  third parameter `string $theme_override = ''`. Fully backward-compatible.
- **`Config_Normalizer::normalize()`** gains an optional third parameter
  `array $context = []`, forwarded to the config filters. Fully
  backward-compatible — the existing two-argument call in
  `Engine_Diagnostics` is unaffected.

### Documentation

- **`readme.txt`** — `Stable tag` corrected from `1.6.4` to `2.1.0`, and the
  missing 1.6.5–2.0.8 changelog entries backfilled from this file. The readme
  changelog had drifted for roughly twenty releases while this document stayed
  current.
- **`ARCHITECTURE.md`** — three corrections and two additions. The per-template
  asset section described intended rather than actual behaviour. The
  Slot → Template map's "Default source" column documented behaviour removed in
  v2.0.3. Milestones 7 and 10 were marked complete while the external template
  path was non-functional. Added a **Template Path Contract** section and a
  **Known Gaps** section recording that layout templates remain hardcoded with
  no `register_layout()` equivalent, that the Context Engine is unimplemented
  and six source classes still read global WordPress state directly, and that
  native search has no source so search results fall back unfiltered when
  Algolia is not configured.

### Known limitations not addressed here

- `register_layout()` does not exist; `LAYOUT_TEMPLATES` still hardcodes `grid`
  and `slider`. The path work in this release is the prerequisite.
- `Source_All` has no search-term support, so the Algolia fallback returns
  unfiltered products on search pages. Pre-existing and unchanged by this
  release: the search consumer previously resolved to `all` anyway, so the
  outcome is identical rather than worse.

---

## [2.0.8] — 2026-07-29

### Fixed

- **`zymarg_wcpg_init` hook was never fired** — the critical bug that prevented
  the ZYMARG Template Pack (and any standalone template plugin) from registering
  card templates. The template pack hooked into `zymarg_wcpg_init` but `Plugin::init()`
  only fired `zymarg_wcpg_loaded`. Template registration was therefore never called,
  causing the engine to always fall back to `classic`. Fixed by adding
  `do_action( 'zymarg_wcpg_init' )` to `Plugin::init()` immediately before the
  existing `zymarg_wcpg_loaded` action. Both hooks are now fired in sequence:
  `zymarg_wcpg_init` → `zymarg_wcpg_loaded`.

### Changed

- **`Plugin::init()`** — `zymarg_wcpg_init` action added with full docblock
  documenting it as the official hook for template registration. This is the
  hook standalone template plugins should use.

- **`ARCHITECTURE.md`** — updated to v2.0.8. Progress table updated: Milestone 7
  (Template Registry API) marked complete; Milestone 10 (Independent Template
  Plugins) marked architecture-proven. Milestone 7 section added documenting the
  full bootstrap sequence, key classes, rules, and per-template asset loading.

- **`docs/05-extension-development.md`** — bootstrap hook section added explaining
  that `zymarg_wcpg_init` is the correct hook for template registration and why
  earlier hooks (`plugins_loaded`, `init`) must not be used.

---

## [2.0.7] — 2026-07-27

### Added

- **`card_template` shortcode attribute** (`Product_Grid_Shortcode`).
  `[zymarg_products card_template="zymarg"]` now passes the slug into
  `config['card']['template']`. `Config_Normalizer` validates it against
  `Template_Manager::is_registered_card()` and falls back to `'classic'` if
  the slug is unknown — the shortcode itself does no extra validation.
  Empty string (attribute omitted) leaves the key unset so `Config_Defaults`
  applies the `'classic'` default as normal.

  This completes the shortcode half of the template selection pipeline:

  ```
  [zymarg_products card_template="zymarg" source="similar"]
          │
          ▼
  Shortcode → config['card']['template'] = 'zymarg'
          │
          ▼
  Config_Normalizer → Template_Manager::is_registered_card('zymarg') → true
          │
          ▼
  Render_Engine → grid-wrapper → Template_Manager::render_card('zymarg', ...)
          │
          ▼
  zymarg/product-card.php (registered by standalone template pack)
  ```

- **Shortcode usage example** added to file docblock:
  `[zymarg_products card_template="zymarg" source="similar"]`

### Changed

- **`Product_Grid_Shortcode::default_atts()`** — `'card_template' => ''` added
  to the attribute defaults. Empty string means "not provided"; engine default
  (`'classic'`) applies.

- **`Product_Grid_Shortcode::build_card()`** — when `card_template` is non-empty,
  `$card['template']` is set to `sanitize_key( $atts['card_template'] )`.
  Validation is intentionally left to `Config_Normalizer` — the shortcode is
  a thin translator, not a gatekeeper.

---

## [2.0.6] — 2026-07-27

### Added

- **`card.template` config key** (`Config_Defaults`).
  The canonical location for the card template slug is now `config['card']['template']`,
  defaulting to `'classic'`. This was the final missing piece connecting the
  `register_card()` API to the renderer — without this default, the engine had
  no way to know which registered card template to use.

- **`Template_Manager::is_registered_card( string $slug ): bool`**
  Lightweight helper that returns true if a slug exists in `get_registered_cards()`
  (core or runtime). Used by `Config_Normalizer` to validate the template slug
  without inspecting `CARD_TEMPLATES` or `$registered_cards` directly.
  Template_Manager remains the only class that knows what templates exist.

### Changed

- **`Config_Normalizer::validate()`** — new card template validation block.
  Sanitizes `card.template` via `sanitize_key()`, then checks it against
  `Template_Manager::is_registered_card()`. Falls back to `'classic'` if the
  slug is empty, invalid, or not yet registered. The renderer always receives
  a valid slug after normalization.

- **`templates/grid/grid-wrapper.php`** — reads card template slug from
  `$config['card']['template']` instead of `$config['template']` (top-level).
  Matches the canonical config location established in `Config_Defaults`.

- **`templates/slider/slider-wrapper.php`** — same fix as grid-wrapper.

### Architecture note

The full pipeline is now connected end to end:

```
standalone plugin
        │
        │  Template_Manager::register_card( 'fashion', $path )
        ▼
Template_Manager  →  $registered_cards['fashion'] = $path
        │
        │  Public_API::render([
        │      'config' => [ 'card' => [ 'template' => 'fashion' ] ],
        │      'query'  => [ 'source' => 'vendor' ],
        │  ])
        ▼
Config_Defaults     →  card.template = 'classic'  (default seed)
        ▼
Config_Normalizer   →  sanitize + is_registered_card() → 'fashion' ✅
        ▼
Render_Engine
        ▼
grid-wrapper / slider-wrapper
        │
        │  Template_Manager::render_card( $config['card']['template'], $args )
        ▼
Template_Manager::resolve_card_path( 'fashion' )
        │
        │  get_registered_cards() → 'fashion' => '/path/to/product-card.php'
        ▼
Template_Loader  →  renders fashion/product-card.php
```

Template and source are fully independent. The same card template renders
any source; the same source renders with any registered card template.

---

## [2.0.5] — 2026-07-26

### Added

- **`Template_Manager::register_card( string $slug, string $path ): void`**
  Public API for standalone plugins and template packs to register card templates
  without modifying core files. Registration should happen on `zymarg_wcpg_init`.
  Validation: rejects empty slugs, slugs not matching `[a-z0-9_-]+`, empty paths,
  attempts to override core templates, and duplicate registrations. All rejections
  emit `E_USER_WARNING` to `debug.log` (visible when `WP_DEBUG_LOG` is enabled).
  First registration wins — no silent overrides between competing plugins.

- **`Template_Manager::unregister_card( string $slug ): void`**
  Removes a runtime-registered card template. Core templates (`classic`) cannot
  be unregistered. Primarily useful for resetting state between automated tests
  and for future admin-level template management features.

- **`Template_Manager::get_registered_cards(): array`**
  Returns the complete map of available card templates: the immutable
  `CARD_TEMPLATES` constant (core seed) merged with runtime-registered templates.
  Core entries always take priority. All internal lookups now go through this
  method rather than reading `CARD_TEMPLATES` directly.

- **`private static array $registered_cards = []`**
  Runtime registry populated by `register_card()`. Separate from the
  `CARD_TEMPLATES` constant so core templates are always distinguishable from
  externally registered ones.

### Changed

- **`Template_Manager::CARD_TEMPLATES` constant** — `'zymarg'` entry removed.
  Core now ships exactly one card template: `classic`. The constant is the
  immutable seed; all external templates go through `register_card()`.

- **`Template_Manager::resolve_card_path()`** — now calls `get_registered_cards()`
  instead of reading `CARD_TEMPLATES` directly, so runtime-registered templates
  are included in every slug resolution.

- **`Template_Manager` class docblock** updated to document the registry API,
  the core-immutability rule, and a complete standalone plugin example.

### Removed

- **`templates/cards/zymarg/`** removed from core.
  The ZYMARG card template (`product-card.php` + `style.css`) is no longer
  bundled with the core plugin. It will be distributed as a standalone template
  plugin (`zymarg-card-template`) that registers itself via `register_card()`.
  This establishes the architectural separation: the core engine ships one
  reference template; visual templates live in independent plugins.

### Architecture note

The core plugin now provides:
- Query Engine
- Render Engine
- Template Registry (both grid configs and card templates)
- Asset Manager
- Public API
- Hook system

Card templates are fully independent. A standalone plugin registers its card
template once on `zymarg_wcpg_init` and it is immediately available to every
consumer (Public_API, shortcode, Elementor) without any core changes.

---

## [2.0.4] — 2026-07-26


### Added

- **ZYMARG card template** (`templates/cards/zymarg/`).
  A fully branded alternative to the classic card, registered under the slug
  `'zymarg'` and available everywhere a template slug is accepted
  (`[zymarg_products template_card="zymarg"]`, `Public_API::render()` config,
  Elementor widget). Two files:

  `product-card.php` — layout differences from classic:
  - Image container: strict 1:1 `aspect-ratio`, hover scale on image.
  - Discount badge: top-left corner pill, "−N% off" format.
  - Quick view: top-right corner, no background, desktop hover-only; hidden on tablet + mobile.
  - Wishlist: bottom-right corner, no background, always visible.
  - OOS badge: bottom-left corner pill, "Out of stock" only (in-stock never shown).
  - Content box: compact padding, white background, `position:relative` for ATC anchor.
  - Row 1: title, 2-line clamp.
  - Row 2: full star strip + numeric average + divider + sold count (desktop/tablet);
    single star icon + numeric average + divider + sold count (mobile).
    Divider suppressed when only one element is present; entire row omitted when neither renders.
  - Row 3: current price bold + old price strikethrough subscript inline.
    Bottom padding creates visual gap for the ATC button.
  - ATC button: circular, ZYMARG purple, absolutely positioned between row 3 and
    row 4 via a zero-height `.zymarg-zc__atc-anchor` element. Right-aligned,
    overflows without affecting row flow.
  - Row 4: Dokan vendor avatar (20 px circle) + store name, inline. Vendor
    resolution handled directly in the template (same name-resolution chain as
    `grid/vendor.php` partial). Row omitted entirely when Dokan is inactive or
    no vendor can be resolved.
  - All existing card lifecycle hooks fire (`zymarg_before_card`,
    `zymarg_after_card`, `zymarg_card_html`, `zymarg_card_classes`,
    `zymarg_card_attributes`, and the before/after hooks for image, title,
    price, add-to-cart).

  `style.css` — auto-loaded by `Asset_Manager` when this template renders:
  - ZYMARG brand tokens declared as CSS custom properties on `.zymarg-wcpg__card--zymarg`.
  - Full dark mode support via `[data-theme="dark"]` — matches the ZYMARG theme
    switcher; the complete dark palette applies instantly on toggle.
  - Responsive: tablet (≤1024px) hides quick view; mobile (≤767px) swaps full star
    strip for single-star compact layout and tightens padding.
  - Scoped entirely to `.zymarg-wcpg__card--zymarg` — never affects classic or
    any other card.

- **`Template_Manager::CARD_TEMPLATES`** updated to include
  `'zymarg' => 'cards/zymarg/product-card.php'`.

---

## [2.0.3] — 2026-07-25

### Changed

- **`Template_Registry` built-in templates no longer bind to a source.**
  Previously, built-in templates embedded a `query.source` (e.g. `related-grid`
  had `'source' => 'similar'`, `store-grid` had `'source' => 'current_vendor'`).
  This violated the core architectural principle: templates define visual
  appearance; sources are chosen by the consumer. All five built-in templates
  now contain only visual/structural config (`layout`, `card`, `query.limit`,
  `query.orderby`). Consumers — standalone plugins, shortcodes, Elementor
  widgets — always supply the source explicitly.

- **`grid-wrapper.php` now emits CSS custom properties for column counts.**
  The grid element now carries `style="--columns-desktop:N;--columns-tablet:N;
  --columns-mobile:N;"`. Card template stylesheets can use
  `repeat(var(--columns-desktop), 1fr)` so standalone plugins can change column
  counts via config without editing any CSS file. The existing `data-columns-*`
  attributes are retained for backward compatibility.

### Added

- **Per-card-template CSS and JS auto-loading** (`Asset_Manager`).
  `maybe_enqueue_card_template_assets()` is now called inside
  `enqueue_for_render()`. When a card template folder contains `style.css`
  or `script.js`, those files are registered and enqueued automatically
  whenever that template renders. No manual handle registration is needed.
  File convention: `templates/cards/{slug}/style.css` and `script.js`.
  This makes each card template a self-contained package.

- **`docs/09-templates.md`** — comprehensive guide covering: what a template
  is, the template/source separation rule, per-template CSS/JS, CSS custom
  properties for responsive columns, responsive card visibility config,
  registering custom templates, creating new card templates, slot reassignment,
  and the future Component Library direction.

- **`docs/07-standalone-plugin-integration.md` revised** to demonstrate the
  template + source separation pattern throughout, including the single-product
  page pattern (one template, three sources in three sections) and responsive
  config override examples.

---

## [2.0.2] — 2026-07-25

### Fixed

- **`zymarg_layout_template` filter contract violation** (`Template_Manager`,
  `Render_Engine`). Before this release, `render_layout()` resolved the layout
  path independently from raw constants, meaning the filter correctly modified
  the path passed to lifecycle hooks (`zymarg_product_grid_before_render`) but
  had no effect on the actual template file the renderer loaded. The renderer
  and the hooks were silently using different paths. Fixed by resolving the path
  once in `Render_Engine` and passing it into `render_layout()` via the new
  optional `?string $resolved_path` parameter. The filter now fires exactly once
  per render and the result is used by both hooks and the renderer.

- **Orphaned docblock and PHPDoc escape artifacts** in `Template_Manager`.
  A duplicate `@param \$config` docblock was floating above
  `resolve_layout_path()` with backslash-escaped `$` characters. Both removed.

- **Plugin header `Version:` line formatting artifact** (extra leading space).

- **`class-render-engine.php.bak` removed** from the release package.

### Added

- **`ZYMARG_DEBUG` overlay.** When `define( 'ZYMARG_DEBUG', true )` is set in
  `wp-config.php`, a compact diagnostic overlay is appended under every product
  grid, visible only to logged-in administrators. Displays: Source, Card
  Template, Layout, Products count, Cache status (HIT / MISS / DISABLED),
  Consumer, Slot, Template Slug, Context type, and the resolved layout file
  path. Zero cost in production — the overlay method is never called unless the
  constant is defined.

### Changed

- **`Query_Builder` class docblock** updated to document `vendor` as the
  canonical source key for the "More From Seller" source and to state the
  no-aliases naming convention explicitly.

- **`Render_Engine::render()` signature** gains an optional fifth parameter
  `array $debug_meta = []`. Fully backward-compatible — existing callers
  passing four arguments are unaffected.

- **`Template_Manager::render_layout()` signature** gains an optional third
  parameter `?string $resolved_path = null`. Fully backward-compatible.

---

## [2.0.1] — 2026-07-22

### Added

- Milestone 6 complete: Template Infrastructure.
  - `Template_Manager` introduced as the single class that knows all template
    file locations. `Render_Engine` now has zero knowledge of filenames.
  - `CARD_TEMPLATES` constant maps card template slugs to paths.
  - `LAYOUT_TEMPLATES` constant maps layout types to wrapper files.
  - `resolve_layout_path()` and `render_card()` public methods.
  - `zymarg_layout_template` filter (layout file substitution).
  - `zymarg_card_template` filter (card template substitution per product).
  - Layout wrappers (`grid-wrapper.php`, `slider-wrapper.php`) updated to call
    `Template_Manager::render_card()` instead of direct `Template_Loader` calls.
  - Card template moved to `templates/cards/classic/product-card.php`.
    Legacy path `templates/grid/product-card.php` retained for backward
    compatibility with existing theme overrides.
  - `grid-wrapper.php` and `slider-wrapper.php` now receive `$config` alongside
    `$settings` so templates can consume the canonical config directly.

- Milestone 5 complete: Asset Manager.
  - `Asset_Manager` service introduced. `Render_Engine::enqueue_assets()` removed.
  - `enqueue_for_render( $config )` — enqueues core assets + conditionally
    enqueues Swiper (slider layout) and Quick View assets.
  - `enqueue_for_search_page()` — hooked unconditionally in `Plugin::init()`.

---

## [2.0.0] — 2026-07-20

### Added

- **Cache Manager** (`includes/Services/Cache_Manager`).
  - HTML render cache with version-bump O(1) invalidation.
  - `wp_cache_*` primary backend (Redis/Memcached); transients fallback.
  - `build_key()`, `get()`, `set()`, `delete()`, `invalidate_all()`.
  - `should_cache()` — bypasses cache for admins in preview/editor/Customizer
    and when `WP_DEBUG_DISPLAY` is true.
  - Default TTL: 300 seconds (filterable via `zymarg_cache_ttl`).
  - `Public_API` integrated: cache lookup before render, cache write after.
  - Invalidation hooks registered in `Plugin::init()`.

- Engine Diagnostics admin page (ZYMARG menu position 3).

---

## [1.6.5] — 2026-07-01

### Changed

- Milestone 4 complete: Consumer Migration.
  - All page consumers migrated to call `Public_API::render()`.
  - `Related_Products_Consumer` introduced.
  - Shortcode (`[zymarg_products]`) migrated to canonical config structure.
  - `config_to_settings()` shim in `Render_Engine` for backward-compatible
    template access to flattened `$settings`.
  - CSS media query attribute selectors for responsive column control.

---

## [1.6.0] — 2026-06-15

### Added

- Milestone 1 complete: Engine Foundation.
  - `Public_API` introduced as the stable public contract.
  - `Render_Engine` introduced.
  - `Config_Normalizer` and `Config_Defaults`.
  - `Query_Builder` and `Source_Base`.
  - 13 source classes.
  - `Template_Loader` with theme override support (`zymarg-wcpg/` in active theme).
