# Shortcode

```
[zymarg_products]
```

A thin consumer that translates shortcode attributes into the canonical config
structure and calls `Public_API::render()`. It is the easiest way to place a
product grid on any standard WordPress page or post.

---

## Basic usage

```
[zymarg_products]
```

Renders 8 products from all sources in a 4-column grid using all defaults.

---

## All attributes

### Routing

| Attribute  | Default | Description |
|------------|---------|-------------|
| `slot`     | `''`    | Named slot. Engine resolves slot → template → config. |
| `template` | `''`    | Template slug. Bypasses slot resolution. |

Input priority: `config attributes` > `template` > `slot`.

### Query

| Attribute             | Default | Description |
|-----------------------|---------|-------------|
| `source`              | `all`   | Product source. See sources list below. |
| `limit`               | `8`     | Number of products. Clamped 1–48. |
| `orderby`             | `date`  | `date`, `price`, `rating`, `popularity`, `rand` |
| `order`               | `DESC`  | `ASC` or `DESC` |
| `include_categories`  | `''`    | Comma-separated category IDs to include. |
| `exclude_categories`  | `''`    | Comma-separated category IDs to exclude. |
| `include_products`    | `''`    | Comma-separated product IDs to include. |
| `exclude_products`    | `''`    | Comma-separated product IDs to exclude. |

### Card template

| Attribute | Default | Description |
|-----------|---------|-------------|
| `card_template` | `''` | Slug of a registered card template, e.g. `card_template="zymarg"`. Empty uses the engine default, `classic`. The slug must have been registered via `Template_Manager::register_card()`; an unregistered slug falls back to `classic` rather than erroring. Added in v2.0.7. |

```
[zymarg_products card_template="zymarg" source="trending" limit="8"]
```

Note this is `card_template`, not the `template` routing attribute above —
`template` selects a layout/appearance preset from the Template Registry,
while `card_template` selects the design of each individual product card.

### Layout

| Attribute        | Default | Description |
|------------------|---------|-------------|
| `layout`         | `grid`  | `grid` or `slider` |
| `columns`        | `4`     | Desktop columns. Clamped 1–6. |
| `columns_tablet` | `''`    | Tablet columns override. Clamped 1–6. |
| `columns_mobile` | `''`    | Mobile columns override. Clamped 1–6. |

### Slider

Only applied when `layout="slider"`. Every attribute defaults to an empty
string, meaning "leave it to the engine default, or to a template pack that
overrides it". Passing a value makes it explicit, and an explicit value always
wins over a template pack default.

| Attribute               | Default | Description |
|-------------------------|---------|-------------|
| `slider_arrows`         | `''`    | `true` / `false`. Show the prev/next arrows. |
| `slider_pagination`     | `''`    | `bullets`, `progress`, or `none` to hide it. Also accepts `off`, `hide`, `no`, `false`, `0`. |
| `slider_loop`           | `''`    | `true` / `false`. Wrap from the last card back to the first. |
| `free_scroll`           | `''`    | `true` / `false`. Momentum dragging instead of snapping card by card. |
| `mousewheel`            | `''`    | `true` / `false`. Horizontal wheel/trackpad scrolling. |
| `slider_autoplay`       | `''`    | `true` / `false`. |
| `slider_autoplay_delay` | `''`    | Milliseconds between slides. Clamped 100-30000. |
| `slider_speed`          | `''`    | Transition duration in ms. Clamped 100-10000. |
| `slider_space_between`  | `''`    | Gap between slides in px. Clamped 0-100. Falls back to `gap`. |

An unrecognised `slider_pagination` value is ignored rather than applied, so a
typo falls back to the template default instead of breaking the slider.

**Loop and slide count.** Swiper disables looping when there are not enough
slides to clone, specifically when
`slide count < slidesPerView + slidesPerGroup + loopAdditionalSlides`. The
engine sizes the clone buffer from that budget, but you still need at least one
more product than your desktop column count. Below that, loop is switched off
and a notice is logged when `WP_DEBUG` is on.

**Loop with free scroll.** Supported since 2.13.0. Earlier versions forced loop
off whenever free scroll was on.

### Marquee

Marquee turns the slider into a continuous drift rather than autoplay's
step-pause-step motion. It pauses when the pointer rests on the slider and while
a card is held, then resumes on release.

| Attribute | Values | Default | Notes |
| --- | --- | --- | --- |
| `slider_marquee` | `yes` / `no` | `no` | Requires loop. Works alongside `free_scroll`. |
| `slider_marquee_speed` | `500`-`20000` | `4000` | Milliseconds per slide advance. Higher is slower. |

```
[zymarg_products layout="slider" slider_marquee="yes" slider_marquee_speed="5000"]
```

Marquee needs a wrapped track, so it inherits the loop slide-count budget: the
slider must contain more products than the desktop column count. When loop is
unavailable, marquee disables itself and the slider falls back to a normal
static slider. Enable `WP_DEBUG` to see the reason.

Marquee works with `free_scroll` (v2.16.0). Drag the track at any time: the
drift stands down while you hold it, Swiper's momentum carries the throw, and
the drift resumes from wherever the track came to rest.

Pausing is exact. The drift advances the track one animation frame at a time
rather than in slide-sized steps, so hovering freezes it on the spot instead of
carrying on to the next card, and moving the pointer away resumes it from the
same pixel. Touch behaves identically: hold to freeze, release to resume.

Browsers set to `prefers-reduced-motion: reduce` get a stationary but fully
draggable slider.

### Card visibility

All card flags default to empty string, which means the engine's
`Config_Defaults` decides. Pass `true` or `false` to override explicitly.

| Attribute            | Engine default |
|----------------------|---------------|
| `show_image`         | `true`  |
| `show_title`         | `true`  |
| `show_price`         | `true`  |
| `show_rating`        | `true`  |
| `show_atc`           | `true`  |
| `show_wishlist`      | `true`  |
| `show_quickview`     | `true`  |
| `show_vendor`        | `false` |
| `show_sold_count`    | `false` |
| `show_discount_badge`| `true`  |
| `show_stock_badge`   | `true`  |

### Heading

| Attribute      | Default | Description |
|----------------|---------|-------------|
| `show_heading` | `''`    | `true` to enable the heading block. |
| `heading_text` | `''`    | Heading text. |
| `heading_tag`  | `''`    | `h1`–`h6`, `div`, or `span`. Defaults to `h2`. |

### Pagination

| Attribute    | Default  | Description |
|--------------|----------|-------------|
| `pagination` | `none`   | `none` or `load_more` |

### Empty state

| Attribute       | Default | Description |
|-----------------|---------|-------------|
| `empty_message` | `''`    | Text shown when no products match. Defaults to "No products found." |

---

## Sources

| Value             | Description |
|-------------------|-------------|
| `all`             | All published products |
| `featured`        | Featured products |
| `best_selling`    | Ranked by sales |
| `trending`        | High-velocity recent products |
| `recent`          | Newest by publish date |
| `similar`         | Similar to the current product *(requires product page context)* |
| `vendor`          | More from the same seller *(requires product page context + Dokan)* |
| `current_vendor`  | All products by the vendor on the current store page *(Dokan store pages only)* |
| `category`        | Products in the current or specified category |
| `wishlist`        | Current user's wishlist |
| `recommended`     | Per-visitor personalised feed |
| `algolia`         | Algolia search results |

Context-aware sources (`similar`, `vendor`, `recommended`) silently output
nothing on pages where the required context cannot be resolved.

---

## Examples

```
[zymarg_products]
```

```
[zymarg_products source="featured" limit="4" columns="4"]
```

```
[zymarg_products source="trending" layout="slider" limit="10" columns="5"]
```

```
[zymarg_products source="vendor" show_vendor="true" show_stock_badge="true"]
```

```
[zymarg_products
    source="category"
    include_categories="24,25"
    columns="3"
    columns_tablet="2"
    columns_mobile="1"
    show_heading="true"
    heading_text="Browse this category"
    pagination="load_more"
    limit="12"
]
```

```
[zymarg_products slot="homepage-featured"]
```

```
[zymarg_products template="homepage-grid"]
```

---

## Notes

- The shortcode never echoes — it always returns a string. Safe to use
  inside PHP via `do_shortcode('[zymarg_products]')`.
- When `Public_API::HIDE_WIDGET` is returned by the engine (context-aware
  source with no context), the shortcode silently returns an empty string.
  Nothing is output on the page.
- Fine-grained controls (icon pickers, meta layout, sold count format,
  heading alignment) are only available through the Elementor widget. The
  shortcode exposes the most commonly needed attributes. Slider settings are
  no longer Elementor-only -- see the Slider table above.
