<?php
/**
 * Slider wrapper template.
 *
 * @package Zymarg\WCPG
 *
 * @var array       $settings
 * @var int|string  $widget_id
 * @var array       $products
 */

defined( 'ABSPATH' ) || exit;

// Defensive guard: $config must always be provided by Template_Manager::render_layout().
// If it is missing, this template is being called by a legacy integration that bypasses
// Template_Manager (e.g. a theme or old plugin calling Template_Loader directly).
// We build a minimal fallback so no PHP warning fires, but log a notice so the
// developer knows the old call path needs to be updated to use Template_Manager.
if ( ! isset( $config ) || ! is_array( $config ) ) {
	if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_trigger_error
		trigger_error(
			sprintF(
				'[ZYMARG WCPG] %s loaded without $config. Use Template_Manager::render_layout() instead of calling this template directly.',
				basename( __FILE__ )
			),
			E_USER_NOTICE
		);
	}
	$config = [];
}

// Accepts both Elementor strings ('yes') and canonical booleans (true/1).
$enabled = static function ( $value ) {
	return in_array( (string) $value, array( '1', 'yes', 'true' ), true );
};

$show_heading   = isset( $settings['show_heading'] ) && $enabled( $settings['show_heading'] );
$heading_text   = isset( $settings['heading_text'] ) ? (string) $settings['heading_text'] : '';
$subheading     = isset( $settings['subheading_text'] ) ? (string) $settings['subheading_text'] : '';
$allowed_tags   = array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'div', 'span' );
$heading_tag    = isset( $settings['heading_tag'] ) && in_array( $settings['heading_tag'], $allowed_tags, true ) ? $settings['heading_tag'] : 'h2';
$show_view_all  = isset( $settings['show_view_all'] ) && $enabled( $settings['show_view_all'] );
$view_all_text  = isset( $settings['view_all_text'] ) ? (string) $settings['view_all_text'] : __( 'View All', 'zymarg-wcpg' );
$view_all_url   = isset( $settings['view_all_url']['url'] ) ? (string) $settings['view_all_url']['url'] : '';
$view_all_blank = ! empty( $settings['view_all_url']['is_external'] );
$view_all_nf    = ! empty( $settings['view_all_url']['nofollow'] );

$cols_d  = max( 1, min( 6, (int) ( $settings['columns'] ?? 4 ) ) );
$cols_t  = max( 1, min( 6, (int) ( $settings['columns_tablet'] ?? 3 ) ) );
$cols_m  = max( 1, min( 6, (int) ( $settings['columns_mobile'] ?? 2 ) ) );

// v2.4.4: slide spacing inherits the grid gap (layout.gap) when slider spacing
// is unset, so one `gap` value drives both grid and slider. An explicit
// slider_space_between (Elementor "Slide spacing" control or config) still wins.
$zymarg_grid_gap      = isset( $settings['gap'] ) ? max( 0, min( 100, (int) $settings['gap'] ) ) : 6;
$zymarg_space_between = ( isset( $settings['slider_space_between'] ) && '' !== $settings['slider_space_between'] && null !== $settings['slider_space_between'] )
	? (int) $settings['slider_space_between']
	: $zymarg_grid_gap;

// v2.5.0: smooth (free-mode) horizontal scrolling. Default ON for BOTH templates.
// Free scroll gives continuous, momentum-based dragging instead of snapping one
// product at a time.
//
// v2.13.0: loop is no longer discarded when free scroll is on.
//
// Swiper 11 wraps a looping slider by calling loopFix(), which relocates the
// cloned slides and compensates the translate so the shift is invisible. During
// a drag that already happens continuously -- touchMove calls loopFix() with
// setTranslate:true -- so dragging a free-scroll slider past the last card
// always wrapped correctly. The broken part was the momentum coast after the
// release: Swiper only schedules a post-momentum loopFix() when centeredSlides
// is enabled, so with our left-aligned slides the fling clamped at
// maxTranslate() and the slider dead-ended. That is why loop used to be forced
// off here.
//
// Two changes make the combination work. Below, the fling is given enough
// cloned runway that it lands mid-track instead of on the clamp. In slider.js,
// loopFix() is re-run once the momentum transition ends, which re-centres the
// clones so the next fling has runway again.
$free_scroll  = ! isset( $settings['slider_free_scroll'] ) || $enabled( $settings['slider_free_scroll'] );
$mousewheel   = ! isset( $settings['slider_mousewheel'] ) || $enabled( $settings['slider_mousewheel'] );
$loop_enabled = ! isset( $settings['slider_loop'] ) || $enabled( $settings['slider_loop'] );

// v2.13.1: loop has a hard slide budget in Swiper. From loopFix() in the
// bundle: slidesPerGroup defaults to 1, loopedSlides = slidesPerGroup +
// loopAdditionalSlides, and Swiper disables looping outright when
//
//     slides.length < ceil( slidesPerView ) + loopedSlides
//
// So the most runway we can ask for is:
//
//     slide count - desktop columns - slidesPerGroup
//
// v2.13.0 requested `columns x 2` runway, which blew the budget on any normal
// catalogue (8 products at 4 columns needs 13) and made Swiper switch loop off
// -- the exact symptom it was meant to fix. Size the runway from the budget.
$zymarg_slide_count = is_array( $products ) ? count( $products ) : 0;
$zymarg_loop_group  = 1; // Swiper's slidesPerGroup default; we never override it.
$zymarg_loop_runway = $zymarg_slide_count - $cols_d - $zymarg_loop_group;

// Below one spare slide there is nothing to wrap onto, so loop cannot work at
// the widest breakpoint no matter how the runway is sized.
if ( $loop_enabled && $zymarg_loop_runway < 0 ) {
	$loop_enabled = false;
	if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_trigger_error
		trigger_error(
			sprintf(
				'[ZYMARG WCPG] Slider loop disabled: %1$d products cannot loop at %2$d desktop columns; %3$d are required.',
				(int) $zymarg_slide_count,
				(int) $cols_d,
				(int) ( $cols_d + $zymarg_loop_group )
			),
			E_USER_NOTICE
		);
	}
}

// v2.16.0: Marquee mode -- continuous edge-to-edge drift.
//
// v2.15.0 built this on Swiper autoplay (delay 0 + linear transition). That
// was wrong on two counts: autoplay cannot stop mid-transition, so hovering
// only took effect at the next slide boundary, and it could not coexist with
// free mode. The drift is now driven by a requestAnimationFrame loop in
// slider.js that writes the translate directly, so it can be frozen on any
// frame and resumed from the exact same pixel, and free scroll stays on.
//
// PHP's job is therefore only to validate and hand the parameters to JS.
// Loop is still required: an unwrapped track would drift to a hard edge.
$zymarg_marquee       = isset( $settings['slider_marquee'] ) && $enabled( $settings['slider_marquee'] );
$zymarg_marquee_speed = isset( $settings['slider_marquee_speed'] )
	? max( 500, min( 20000, (int) $settings['slider_marquee_speed'] ) )
	: 4000;

if ( $zymarg_marquee && ! $loop_enabled ) {
	$zymarg_marquee = false;
	if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
		trigger_error(
			esc_html__( '[ZYMARG WCPG] Slider marquee disabled: it requires loop, which is off or unavailable at this slide count.', 'zymarg-wcpg' ),
			E_USER_NOTICE
		);
	}
}

$swiper_config = array(
	'slidesPerView' => $cols_m,
	'spaceBetween'  => $zymarg_space_between,
	'speed'         => isset( $settings['slider_speed'] ) ? (int) $settings['slider_speed'] : 500,
	'loop'          => $loop_enabled,
	'breakpoints'   => array(
		768 => array( 'slidesPerView' => $cols_t ),
		1025 => array( 'slidesPerView' => $cols_d ),
	),
);

// v2.5.0: enable free-mode momentum scrolling + mouse-wheel/trackpad horizontal
// scroll so the slider glides continuously. All are valid Swiper 11 bundle
// options and pass straight through slider.js to `new Swiper()`.
if ( $free_scroll ) {
	$swiper_config['freeMode'] = array(
		'enabled'        => true,
		'momentum'       => true,
		'momentumRatio'  => 1,
		'momentumBounce' => false,
		'sticky'         => false,
	);
	$swiper_config['grabCursor'] = true;
	// A looping track has no true edge, so rubber-band resistance would fight the
	// wrap. Keep it only for non-looping sliders.
	if ( $loop_enabled ) {
		$swiper_config['resistance']      = false;
		$swiper_config['resistanceRatio'] = 0;
	} else {
		$swiper_config['resistanceRatio'] = 0.85;
	}
}

// Cloned runway for the momentum coast. Swiper clones this many extra slides
// beyond the viewport on each side, so a fling that stays inside the clones
// never reaches maxTranslate() and glides straight through the wrap.
//
// v2.16.1: one slide of the runway is deliberately left unspent. Spending the
// entire budget satisfies Swiper's loop warning (it checks >=) but leaves the
// appended clone pool empty, and loopFix() is a silent no-op in that state:
//   if ( appendedClones.length > 0 && ... ) { shift } else if ( prepended... )
// The track then reaches the end and stops until the user drags it. That hit
// desktop only, because wider breakpoints spend more of the budget: 10 slides
// at 5 columns left exactly zero spare, while 3 and 2 columns left 3 and 5.
if ( $loop_enabled ) {
	$swiper_config['loopAdditionalSlides'] = max( 0, min( $cols_d, $zymarg_loop_runway - 1 ) );
	$swiper_config['loopPreventsSliding']  = false;
}
if ( $mousewheel ) {
	$swiper_config['mousewheel'] = array(
		'forceToAxis'    => true,
		'releaseOnEdges' => true,
		'sensitivity'    => 1,
	);
}
if ( $zymarg_marquee ) {
	// The drift itself is driven from slider.js. Swiper autoplay is deliberately
	// NOT used: it cannot be interrupted mid-transition, which is exactly what
	// pause-on-hover needs. Grab cursor is set because the track stays draggable.
	$swiper_config['allowTouchMove'] = true;
	$swiper_config['grabCursor']     = true;
} elseif ( isset( $settings['slider_autoplay'] ) && $enabled( $settings['slider_autoplay'] ) ) {
	$swiper_config['autoplay'] = array(
		'delay'                => isset( $settings['slider_autoplay_delay'] ) ? (int) $settings['slider_autoplay_delay'] : 4000,
		'disableOnInteraction' => false,
	);
}
$pagination_type = isset( $settings['slider_pagination_type'] ) ? (string) $settings['slider_pagination_type'] : 'bullets';
if ( $pagination_type ) {
	// Map the plugin's canonical pagination value to Swiper's expected type.
	// Swiper 11 expects 'progressbar' (not 'progress'); passing an unknown
	// type makes Swiper silently render no pagination element at all, which
	// is why the 'progress' default appeared to show nothing before v2.4.1.
	$swiper_pagination_type = ( 'progress' === $pagination_type ) ? 'progressbar' : $pagination_type;
	$swiper_config['pagination'] = array(
		'type'      => $swiper_pagination_type,
		'clickable' => true,
	);
}
if ( ! isset( $settings['slider_show_arrows'] ) || $enabled( $settings['slider_show_arrows'] ) ) {
	$swiper_config['navigation'] = true;
}

$empty_message = isset( $settings['empty_message'] ) ? (string) $settings['empty_message'] : __( 'No products found.', 'zymarg-wcpg' );

// v2.10.1: pre-init slide sizing.
//
// Swiper's own stylesheet sizes every .swiper-slide at width:100%, and Swiper
// only writes real per-slide widths once its JS has initialised. Between first
// paint and init the wrapper is therefore a flex row of full-width slides
// inside overflow:hidden -- exactly one card fills the container, and the
// layout snaps into place a moment later.
//
// The grid layout already solves this by emitting its resolved columns and gap
// for CSS to consume (see grid-wrapper.php). The slider emitted only the Swiper
// JSON, whose slidesPerView is the MOBILE count with breakpoints resolved in
// JS, so CSS had nothing to size from. Publishing the resolved values as custom
// properties lets CSS size slides from the first paint for ANY card template,
// and Swiper's inline widths cleanly take over at init.
$zymarg_slide_vars = sprintf(
	'--zc-spv-d:%1$d;--zc-spv-t:%2$d;--zc-spv-m:%3$d;--zc-slide-gap:%4$dpx',
	$cols_d,
	$cols_t,
	$cols_m,
	$zymarg_space_between
);

// v2.10.2: emit the sizing rules as critical CSS, once per request.
//
// slider.css cannot be relied on to be in <head>. When a grid is rendered from
// a shortcode, assets are enqueued from inside the_content() -- after wp_head()
// has already printed -- so WordPress prints the stylesheet in the FOOTER and
// the whole grid paints unstyled and unsized first. The preloader now puts the
// stylesheet in <head> for shortcodes it can see in post_content, but it cannot
// see shortcodes inside widgets, popups, reusable blocks, or template parts.
//
// An inline <style> is parsed the moment it is encountered, with no request, so
// slide sizing is correct at first paint no matter how the grid was rendered or
// when slider.css arrives. It is a few hundred bytes and it is emitted only on
// pages that actually contain a slider. Same rules and same values as
// slider.css -- keep the two in sync.
if ( empty( $GLOBALS['zymarg_wcpg_slider_critical_css'] ) ) {
	$GLOBALS['zymarg_wcpg_slider_critical_css'] = true;

	echo '<style id="zymarg-wcpg-slider-critical">'
		. '.zymarg-wcpg--slider .swiper-wrapper{display:flex}'
		. '.zymarg-wcpg--slider .swiper-slide{height:auto;display:flex;box-sizing:border-box;'
		. 'width:calc((100% - (var(--zc-spv-m,2) - 1) * var(--zc-slide-gap,6px)) / var(--zc-spv-m,2));'
		. 'margin-right:var(--zc-slide-gap,6px)}'
		. '@media (min-width:768px){.zymarg-wcpg--slider .swiper-slide{'
		. 'width:calc((100% - (var(--zc-spv-t,3) - 1) * var(--zc-slide-gap,6px)) / var(--zc-spv-t,3))}}'
		. '@media (min-width:1025px){.zymarg-wcpg--slider .swiper-slide{'
		. 'width:calc((100% - (var(--zc-spv-d,4) - 1) * var(--zc-slide-gap,6px)) / var(--zc-spv-d,4))}}'
		. '</style>';
}
?>
<div class="zymarg-wcpg zymarg-wcpg--slider"
	data-widget-id="<?php echo esc_attr( $widget_id ); ?>"
	data-zymarg-hydrate="1"
	data-card-template="<?php echo esc_attr( $config['card']['template'] ?? 'classic' ); ?>"
	data-show-view-cart="<?php echo ( ! isset( $settings['show_view_cart_link'] ) || $enabled( $settings['show_view_cart_link'] ) ) ? '1' : '0'; ?>"
	data-zymarg-marquee="<?php echo $zymarg_marquee ? '1' : '0'; ?>"
	data-zymarg-marquee-speed="<?php echo esc_attr( (string) $zymarg_marquee_speed ); ?>"
	data-swiper-config="<?php echo esc_attr( wp_json_encode( $swiper_config ) ); ?>"
	style="<?php echo esc_attr( $zymarg_slide_vars ); ?>">

	<?php if ( $show_heading && ( '' !== $heading_text || '' !== $subheading || ( $show_view_all && $view_all_url ) ) ) : ?>
		<div class="zymarg-wcpg__heading">
			<div class="zymarg-wcpg__heading-main">
				<?php if ( '' !== $heading_text ) : ?>
					<<?php echo esc_html( $heading_tag ); ?> class="zymarg-wcpg__heading-title"><?php echo esc_html( $heading_text ); ?></<?php echo esc_html( $heading_tag ); ?>>
				<?php endif; ?>
				<?php if ( '' !== $subheading ) : ?>
					<div class="zymarg-wcpg__heading-subtitle"><?php echo esc_html( $subheading ); ?></div>
				<?php endif; ?>
			</div>
			<?php if ( $show_view_all && '' !== $view_all_url ) : ?>
				<a class="zymarg-wcpg__heading-link"
					href="<?php echo esc_url( $view_all_url ); ?>"
					<?php echo $view_all_blank ? 'target="_blank"' : ''; ?>
					<?php echo $view_all_nf ? 'rel="nofollow noopener"' : ( $view_all_blank ? 'rel="noopener"' : '' ); ?>>
					<?php echo esc_html( $view_all_text ); ?>
				</a>
			<?php endif; ?>
		</div>
	<?php endif; ?>

	<?php if ( empty( $products ) ) : ?>
		<?php
		\Zymarg\WCPG\Template_Loader::get_template(
			'parts/empty-state.php',
			array( 'message' => $empty_message )
		);
		?>
	<?php else : ?>
		<div class="zymarg-wcpg__slider swiper">
			<div class="swiper-wrapper">
				<?php
				foreach ( $products as $product ) {
					if ( ! $product instanceof \WC_Product ) {
						continue;
					}
					echo '<div class="swiper-slide">';
					// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- trusted plugin HTML.
					echo \Zymarg\WCPG\Templates\Template_Manager::render_card(
						$config['card']['template'] ?? 'classic',
						array(
							'product'   => $product,
							'settings'  => $settings,
							'config'    => $config,
							'widget_id' => $widget_id,
						)
					);
					echo '</div>';
				}
				?>
			</div>

			<?php if ( ! isset( $settings['slider_show_arrows'] ) || $enabled( $settings['slider_show_arrows'] ) ) : ?>
				<button type="button" class="zymarg-wcpg__slider-arrow zymarg-wcpg__slider-arrow--prev swiper-button-prev" aria-label="<?php esc_attr_e( 'Previous', 'zymarg-wcpg' ); ?>">
					<?php \Zymarg\WCPG\Product_Data::render_icon( $settings['slider_arrow_prev'] ?? null, 'fas fa-chevron-left' ); ?>
				</button>
				<button type="button" class="zymarg-wcpg__slider-arrow zymarg-wcpg__slider-arrow--next swiper-button-next" aria-label="<?php esc_attr_e( 'Next', 'zymarg-wcpg' ); ?>">
					<?php \Zymarg\WCPG\Product_Data::render_icon( $settings['slider_arrow_next'] ?? null, 'fas fa-chevron-right' ); ?>
				</button>
			<?php endif; ?>

			<?php if ( $pagination_type ) : ?>
				<div class="swiper-pagination"></div>
			<?php endif; ?>
		</div>
	<?php endif; ?>
</div>
