<?php
/**
 * Asset registration.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG;

defined( 'ABSPATH' ) || exit;

/**
 * Class Assets
 *
 * Registers all front-end and editor asset handles. Never enqueues them.
 *
 * This class is registration-only. It answers one question:
 * "Does this handle exist?" — not "Should this handle load?"
 *
 * Enqueue decisions belong to:
 *   - Asset_Manager::enqueue_for_render()  — for render surfaces.
 *   - Asset_Manager::enqueue_for_search_page() — for the search FOUC fix.
 *   - Widget_Wishlist_Button::get_style/script_depends() — for that widget.
 *   - Widget_Product_Grid::get_style/script_depends() — Elementor pipeline.
 *
 * Performance notes (v1.3.5):
 *   - All plugin JS is registered with strategy=>'defer' so the browser
 *     parses HTML first, then downloads + executes scripts. Safe because
 *     every handler uses $(document).on() delegation or $(function(){}).
 *   - quickview.js uses defer too — all its handlers are delegated on
 *     $(document), so it doesn't need to run before cards are painted.
 *   - On the Algolia search page (?s= / ?q=) CSS is enqueued in wp_head
 *     (via an early wp_enqueue_scripts hook) to prevent FOUC. JS remains
 *     in the footer with defer.
 *   - Swiper: we prefer Elementor Pro's registered copy. Fallback uses a
 *     LOCAL bundle (assets/js/swiper-bundle.min.js) to avoid an external
 *     CDN round-trip. If the local copy is absent we fall back to jsDelivr
 *     so the plugin never breaks.
 */
class Assets {

	const HANDLE_FRONTEND        = 'zymarg-wcpg-frontend';
	const HANDLE_SLIDER          = 'zymarg-wcpg-slider';
	const HANDLE_QUICKVIEW       = 'zymarg-wcpg-quickview';
	const HANDLE_EDITOR          = 'zymarg-wcpg-editor';
	const HANDLE_SWIPER          = 'zymarg-wcpg-swiper';
	const HANDLE_WISHLIST_BUTTON = 'zymarg-wcpg-wishlist-button';

	/**
	 * Hook registration callbacks.
	 */
	public function register() {
		add_action( 'wp_enqueue_scripts', array( $this, 'register_frontend' ), 5 );
		add_action( 'elementor/editor/after_enqueue_scripts', array( $this, 'register_editor' ) );
	}

	/**
	 * Register front-end handles. Widgets call wp_enqueue_*() themselves.
	 *
	 * Execution strategy for all plugin JS: 'defer'.
	 * WordPress 6.3+ supports the array-form 4th arg for in_footer/strategy.
	 * We use a compat helper so this also works on WP 6.2.
	 */
	public function register_frontend() {

		// ── CSS ────────────────────────────────────────────────────────────
		wp_register_style(
			self::HANDLE_FRONTEND,
			ZYMARG_WCPG_URL . 'assets/css/frontend.css',
			array(),
			ZYMARG_WCPG_VERSION
		);

		wp_register_style(
			self::HANDLE_QUICKVIEW,
			ZYMARG_WCPG_URL . 'assets/css/quickview.css',
			array( self::HANDLE_FRONTEND ),
			ZYMARG_WCPG_VERSION
		);

		// Swiper handle (prefer Elementor's copy, else local bundle).
		$swiper_handle = $this->resolve_swiper_handle();

		wp_register_style(
			self::HANDLE_SLIDER,
			ZYMARG_WCPG_URL . 'assets/css/slider.css',
			array( self::HANDLE_FRONTEND, $swiper_handle ),
			ZYMARG_WCPG_VERSION
		);

		// ── JS (all deferred) ───────────────────────────────────────────────
		//
		// frontend.js — wishlist hydration, ATC, load-more, click tracking.
		// All event listeners use $(document).on() delegation; DOM-ready
		// hydrate() call is also fine under defer (fires after HTML parsed).
		wp_register_script(
			self::HANDLE_FRONTEND,
			ZYMARG_WCPG_URL . 'assets/js/frontend.js',
			array( 'jquery' ),
			ZYMARG_WCPG_VERSION,
			self::defer_args()
		);

		// quickview.js — modal open/close/AJAX. All handlers delegated on
		// $(document); no setup runs at parse time, so defer is safe.
		wp_register_script(
			self::HANDLE_QUICKVIEW,
			ZYMARG_WCPG_URL . 'assets/js/quickview.js',
			array( 'jquery', self::HANDLE_FRONTEND ),
			ZYMARG_WCPG_VERSION,
			self::defer_args()
		);

		// slider.js — Swiper init inside $(function(){}), defer is safe.
		wp_register_script(
			self::HANDLE_SLIDER,
			ZYMARG_WCPG_URL . 'assets/js/slider.js',
			array( 'jquery', $swiper_handle, self::HANDLE_FRONTEND ),
			ZYMARG_WCPG_VERSION,
			self::defer_args()
		);

		// wishlist-button.css + .js — header / standalone Wishlist Button widget.
		wp_register_style(
			self::HANDLE_WISHLIST_BUTTON,
			ZYMARG_WCPG_URL . 'assets/css/wishlist-button.css',
			array(),
			ZYMARG_WCPG_VERSION
		);
		wp_register_script(
			self::HANDLE_WISHLIST_BUTTON,
			ZYMARG_WCPG_URL . 'assets/js/wishlist-button.js',
			array( 'jquery', self::HANDLE_FRONTEND ),
			ZYMARG_WCPG_VERSION,
			self::defer_args()
		);

		// ── Localise shared runtime data onto frontend handle ───────────────
		// v2.8.0: resolve a wishlist URL so consumers (template packs, themes)
		// can render a "View wishlist" action on the wishlist toast.
		$zymarg_wishlist_url = '';
		$zymarg_wishlist_pid = (int) get_option( 'zymarg_wcpg_wishlist_page_id', 0 );
		if ( $zymarg_wishlist_pid > 0 ) {
			$zymarg_wishlist_url = (string) get_permalink( $zymarg_wishlist_pid );
		}
		if ( '' === $zymarg_wishlist_url ) {
			$zymarg_wishlist_page = get_page_by_path( 'wishlist' );
			if ( $zymarg_wishlist_page instanceof \WP_Post ) {
				$zymarg_wishlist_url = (string) get_permalink( $zymarg_wishlist_page );
			}
		}

		/**
		 * Filter the wishlist URL exposed to the frontend as ZYMARGWCPG.wishlistUrl.
		 *
		 * Return an empty string to suppress any "View wishlist" action link.
		 *
		 * @since 2.8.0
		 *
		 * @param string $url Resolved wishlist page URL, or '' when unresolved.
		 */
		$zymarg_wishlist_url = (string) apply_filters( 'zymarg_wcpg_wishlist_url', $zymarg_wishlist_url );

		wp_localize_script(
			self::HANDLE_FRONTEND,
			'ZYMARGWCPG',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'zymarg_wcpg' ),

				// v2.8.0: deliberately top-level, not inside i18n, because
				// consumers read ZYMARGWCPG.wishlistUrl directly.
				'wishlistUrl' => $zymarg_wishlist_url,

				'i18n'    => array(
					'addToWishlist'      => __( 'Add to wishlist', 'zymarg-wcpg' ),
					'removeFromWishlist' => __( 'Remove from wishlist', 'zymarg-wcpg' ),
					'addedToWishlist'    => __( 'Added to wishlist', 'zymarg-wcpg' ),
					// v2.8.0: completes the wishlist toast vocabulary. Wording is
					// kept identical to the PHP-side string in Handler_Wishlist.
					'removedFromWishlist' => __( 'Removed from wishlist', 'zymarg-wcpg' ),
					'viewWishlist'        => __( 'View wishlist', 'zymarg-wcpg' ),
					'addedToCart'        => __( 'Added to cart', 'zymarg-wcpg' ),
					'genericError'       => __( 'Something went wrong. Please try again.', 'zymarg-wcpg' ),
					'rateLimited'        => __( 'Too many requests. Please slow down.', 'zymarg-wcpg' ),
					// v2.6.0: Infinite scroll loader pill.
					'loadingMore'        => __( 'Loading more products', 'zymarg-wcpg' ),
					'allLoaded'          => __( 'All products loaded', 'zymarg-wcpg' ),

					// v2.9.0: Flash Deals countdown. Rendered client-side, so every
					// visible string has to travel through here rather than PHP.
					'countdownEndsIn'    => __( 'Ends in', 'zymarg-wcpg' ),
					'countdownEnded'     => __( 'Deal ended', 'zymarg-wcpg' ),
					// Short unit suffixes, e.g. "2d 04h 11m". Translators may use
					// longer forms; the layout does not depend on their width.
					'countdownDay'       => _x( 'd', 'countdown unit: days', 'zymarg-wcpg' ),
					'countdownHour'      => _x( 'h', 'countdown unit: hours', 'zymarg-wcpg' ),
					'countdownMinute'    => _x( 'm', 'countdown unit: minutes', 'zymarg-wcpg' ),
					'countdownSecond'    => _x( 's', 'countdown unit: seconds', 'zymarg-wcpg' ),
					/* translators: %s: formatted remaining time, e.g. "2d 04h 11m". */
					'countdownSrFormat'  => __( 'Sale ends in %s', 'zymarg-wcpg' ),
				),
			)
		);

	}

	/**
	 * Register editor-only assets inside Elementor's editor iframe.
	 */
	public function register_editor() {
		wp_enqueue_style(
			self::HANDLE_EDITOR,
			ZYMARG_WCPG_URL . 'assets/css/editor.css',
			array(),
			ZYMARG_WCPG_VERSION
		);

		// Editor JS does not need defer — it runs inside the editor iframe
		// which is already fully loaded before script execution matters.
		wp_enqueue_script(
			self::HANDLE_EDITOR,
			ZYMARG_WCPG_URL . 'assets/js/editor.js',
			array( 'jquery' ),
			ZYMARG_WCPG_VERSION,
			true
		);
	}

	// ── Private helpers ────────────────────────────────────────────────────

	/**
	 * Return the correct 5th-argument value for wp_register_script() to
	 * load a script in the footer with defer strategy.
	 *
	 * WordPress 6.3+ supports:
	 *   array( 'in_footer' => true, 'strategy' => 'defer' )
	 *
	 * WordPress 6.2 (our minimum) only accepts a boolean. We detect
	 * support at runtime so the plugin stays compatible with both.
	 *
	 * @return array|true
	 */
	private static function defer_args() {
		static $supports_strategy = null;
		if ( null === $supports_strategy ) {
			// wp_register_script() started accepting array args in WP 6.3.
			$supports_strategy = version_compare( get_bloginfo( 'version' ), '6.3', '>=' );
		}
		if ( $supports_strategy ) {
			return array(
				'in_footer' => true,
				'strategy'  => 'defer',
			);
		}
		// Fallback: in-footer only (same behaviour as before, no regression).
		return true;
	}

	/**
	 * Decide which Swiper handle to use.
	 *
	 * Priority (v2.7.0 — local bundle first):
	 *   1. Local bundle        — assets/js/swiper-bundle.min.js (Swiper 11.2.10).
	 *   2. self::HANDLE_SWIPER  — already registered earlier this request.
	 *   3. 'swiper'             — Elementor Pro core, only if still installed.
	 *   4. 'elementor-swiper'   — older Elementor builds.
	 *   5. jsDelivr CDN         — last resort if the local file is missing.
	 *
	 * v2.7.0: the bundled copy is now preferred over Elementor's. The slider
	 * config (free mode, mousewheel, progressbar pagination) is written
	 * against the Swiper 11 API, while Elementor ships its own — frequently
	 * older — major version. Binding to whichever build Elementor happened
	 * to register made slider behaviour depend on a plugin that is being
	 * removed from the site.
	 *
	 * @return string Registered handle.
	 */
	private function resolve_swiper_handle() {
		if ( wp_script_is( self::HANDLE_SWIPER, 'registered' ) ) {
			return self::HANDLE_SWIPER;
		}

		// Prefer the bundled local Swiper 11 build: no external request, no
		// dependency on Elementor, and a version that matches the config the
		// slider template emits.
		$local_js  = ZYMARG_WCPG_DIR . 'assets/js/swiper-bundle.min.js';
		$local_css = ZYMARG_WCPG_DIR . 'assets/css/swiper-bundle.min.css';

		if ( file_exists( $local_js ) ) {
			wp_register_script(
				self::HANDLE_SWIPER,
				ZYMARG_WCPG_URL . 'assets/js/swiper-bundle.min.js',
				array(),
				'11.2.10',
				self::defer_args()
			);
			if ( file_exists( $local_css ) ) {
				wp_register_style(
					self::HANDLE_SWIPER,
					ZYMARG_WCPG_URL . 'assets/css/swiper-bundle.min.css',
					array(),
					'11.2.10'
				);
			}
			return self::HANDLE_SWIPER;
		}

		// No local bundle shipped: reuse a Swiper registered by another
		// plugin (Elementor Pro, or older Elementor builds) when present.
		if ( wp_script_is( 'swiper', 'registered' ) ) {
			return 'swiper';
		}
		if ( wp_script_is( 'elementor-swiper', 'registered' ) ) {
			return 'elementor-swiper';
		}

		// Last-resort CDN fallback (only if no local file exists).
		wp_register_script(
			self::HANDLE_SWIPER,
			'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js',
			array(),
			'11.2.10',
			self::defer_args()
		);
		wp_register_style(
			self::HANDLE_SWIPER,
			'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css',
			array(),
			'11.2.10'
		);

		return self::HANDLE_SWIPER;
	}
}
