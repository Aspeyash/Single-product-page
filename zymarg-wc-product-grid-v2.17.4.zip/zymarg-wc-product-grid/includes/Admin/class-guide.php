<?php
/**
 * Guide -- the in-admin manual for the Product Grid Engine.
 *
 * Everything here is also on disk under docs/, but a markdown file in the
 * plugin folder is invisible to the person actually building pages. This
 * page is the same knowledge where it can be found.
 *
 * Styled with the ZYMARG brand system, matching Engine Diagnostics:
 *   Primary Purple #9500a5, Magenta #bd00d1, Light Pink #fea9ff
 *   12px cards, 20px pills, 8px inputs, 0 4px 20px rgba(149,0,165,0.1)
 *
 * @package Zymarg\WCPG\Admin
 * @since   2.17.0
 */

namespace Zymarg\WCPG\Admin;

defined( 'ABSPATH' ) || exit;

use Zymarg\WCPG\Query\Query_Builder;
use Zymarg\WCPG\Registry\Slot_Registry;
use Zymarg\WCPG\Registry\Template_Registry;

/**
 * Class Guide
 */
final class Guide {

	const SLUG = 'zymarg-guide';

	public static function init(): void {
		add_action( 'admin_menu', array( __CLASS__, 'register_page' ), 9 );
		add_action( 'admin_head', array( __CLASS__, 'inline_styles' ) );
	}

	public static function register_page(): void {
		add_submenu_page(
			'zymarg',
			__( 'Guide', 'zymarg-wcpg' ),
			__( 'Guide', 'zymarg-wcpg' ),
			'manage_options',
			self::SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Section list -- drives both the sticky nav and the page order.
	 *
	 * @return array<string,string>
	 */
	private static function sections(): array {
		return array(
			'how'         => __( 'How the engine works', 'zymarg-wcpg' ),
			'consume'     => __( 'Ways to use it', 'zymarg-wcpg' ),
			'sources'     => __( 'Sources', 'zymarg-wcpg' ),
			'vendor'      => __( 'Current Vendor (store pages)', 'zymarg-wcpg' ),
			'flash'       => __( 'Flash Deals', 'zymarg-wcpg' ),
			'shortcode'   => __( 'Shortcode reference', 'zymarg-wcpg' ),
			'slider'      => __( 'Slider & marquee', 'zymarg-wcpg' ),
			'cards'       => __( 'Cards & templates', 'zymarg-wcpg' ),
			'slots'       => __( 'Slots & auto placement', 'zymarg-wcpg' ),
			'pagination'  => __( 'Pagination & Load More', 'zymarg-wcpg' ),
			'countdown'   => __( 'Countdown timers', 'zymarg-wcpg' ),
			'php'         => __( 'PHP API', 'zymarg-wcpg' ),
			'hooks'       => __( 'Hooks', 'zymarg-wcpg' ),
			'cache'       => __( 'Caching', 'zymarg-wcpg' ),
			'trouble'     => __( 'Troubleshooting', 'zymarg-wcpg' ),
		);
	}

	public static function render_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$sections = self::sections();
		?>
		<div class="wrap zg-wrap">

			<div class="zg-header">
				<div class="zg-header__left">
					<span class="zg-header__logo">&#128218;</span>
					<div>
						<h1 class="zg-header__title"><?php esc_html_e( 'Product Grid Guide', 'zymarg-wcpg' ); ?></h1>
						<p class="zg-header__sub"><?php esc_html_e( 'Every source, setting and shortcode in one place', 'zymarg-wcpg' ); ?></p>
					</div>
				</div>
				<div class="zg-header__right">
					<span class="zg-pill zg-pill--version">v<?php echo esc_html( ZYMARG_WCPG_VERSION ); ?></span>
				</div>
			</div>

			<div class="zg-nav">
				<?php foreach ( $sections as $id => $label ) : ?>
					<a class="zg-nav__item" href="#zg-<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?></a>
				<?php endforeach; ?>
			</div>

			<?php
			self::section_how();
			self::section_consume();
			self::section_sources();
			self::section_vendor();
			self::section_flash();
			self::section_shortcode();
			self::section_slider();
			self::section_cards();
			self::section_slots();
			self::section_pagination();
			self::section_countdown();
			self::section_php();
			self::section_hooks();
			self::section_cache();
			self::section_trouble();
			?>

		</div>
		<?php
	}

	// -- Small render helpers -------------------------------------------------

	private static function open( string $id, string $title, string $intro = '' ): void {
		?>
		<div class="zg-section" id="zg-<?php echo esc_attr( $id ); ?>">
			<div class="zg-section__header">
				<h2 class="zg-section__title"><?php echo esc_html( $title ); ?></h2>
			</div>
			<?php if ( $intro ) : ?>
				<p class="zg-lede"><?php echo esc_html( $intro ); ?></p>
			<?php endif; ?>
		<?php
	}

	private static function close(): void {
		echo '</div>';
	}

	/**
	 * Fenced example block.
	 *
	 * @param string $code Code to display.
	 * @return void
	 */
	private static function code( string $code ): void {
		echo '<pre class="zg-code"><code>' . esc_html( $code ) . '</code></pre>';
	}

	private static function note( string $text ): void {
		echo '<div class="zg-note">' . esc_html( $text ) . '</div>';
	}

	private static function warn( string $text ): void {
		echo '<div class="zg-note zg-note--warn">' . esc_html( $text ) . '</div>';
	}

	/**
	 * Render a simple table.
	 *
	 * @param array $head Column headings.
	 * @param array $rows Row arrays.
	 * @return void
	 */
	private static function table( array $head, array $rows ): void {
		echo '<table class="zg-table"><thead><tr>';
		foreach ( $head as $h ) {
			echo '<th>' . esc_html( $h ) . '</th>';
		}
		echo '</tr></thead><tbody>';
		foreach ( $rows as $row ) {
			echo '<tr>';
			foreach ( $row as $i => $cell ) {
				$cls = ( 0 === $i ) ? ' class="zg-td--key"' : '';
				echo '<td' . $cls . '>' . wp_kses( $cell, array( 'code' => array(), 'strong' => array(), 'em' => array(), 'br' => array() ) ) . '</td>';
			}
			echo '</tr>';
		}
		echo '</tbody></table>';
	}

	// -- Sections -------------------------------------------------------------

	private static function section_how(): void {
		self::open( 'how', __( 'How the engine works', 'zymarg-wcpg' ), __( 'One pipeline serves every consumer. Shortcodes, PHP calls, the Elementor widget and automatic page placements all funnel through the same six stages.', 'zymarg-wcpg' ) );
		?>
		<ol class="zg-steps">
			<li><strong>Request</strong> &mdash; a caller asks for a grid using a <code>slot</code>, a <code>template</code>, or a full <code>config</code> array. Priority is config &gt; template &gt; slot.</li>
			<li><strong>Config merge</strong> &mdash; framework defaults, then the template's config, then the caller's overrides. Later wins.</li>
			<li><strong>Context</strong> &mdash; the engine works out where it is: current product, vendor, category.</li>
			<li><strong>Query</strong> &mdash; the chosen source runs and returns products, or the hide sentinel.</li>
			<li><strong>Render</strong> &mdash; the layout wrapper (grid or slider) draws the chosen card template for each product.</li>
			<li><strong>Cache</strong> &mdash; the HTML is stored and reused until a product changes or the TTL expires.</li>
		</ol>
		<?php
		self::note( __( 'If a source finds nothing it returns a hide signal and the entire block disappears -- heading included. That is deliberate, not a bug: an empty product row looks broken.', 'zymarg-wcpg' ) );
		self::close();
	}

	private static function section_consume(): void {
		self::open( 'consume', __( 'Ways to use it', 'zymarg-wcpg' ), __( 'Four ways in. They all reach the same engine, so anything you can do in one you can do in the others.', 'zymarg-wcpg' ) );

		echo '<h3 class="zg-h3">1. Shortcode &mdash; the usual choice</h3>';
		echo '<p>Works in posts, pages, widgets, Elementor text/shortcode blocks, and any theme builder. Nothing to code.</p>';
		self::code( '[zymarg_products source="featured" limit="8" columns="4"]' );

		echo '<h3 class="zg-h3">2. PHP &mdash; for themes and other plugins</h3>';
		echo '<p>The stable facade. Use this from a template file, a hook, or a separate plugin.</p>';
		self::code( "echo Zymarg_Product_Grid::render( array(\n    'query'  => array( 'source' => 'featured', 'limit' => 8 ),\n    'config' => array( 'layout' => array( 'columns' => 4 ) ),\n) );" );

		echo '<h3 class="zg-h3">3. Elementor widget</h3>';
		echo '<p>Full visual control including per-card options the shortcode does not expose.</p>';
		self::warn( __( 'The Elementor widget always writes its own arrow and pagination values, so slider_pagination="none", slider_marquee and slider_marquee_speed are shortcode-only for now.', 'zymarg-wcpg' ) );

		echo '<h3 class="zg-h3">4. Automatic page placement</h3>';
		echo '<p>The engine can take over standard WooCommerce product rows with no shortcode at all. See the Slots section below.</p>';

		echo '<h3 class="zg-h3">Which should a standalone plugin use?</h3>';
		self::table(
			array( __( 'Situation', 'zymarg-wcpg' ), __( 'Use', 'zymarg-wcpg' ) ),
			array(
				array( __( 'You want to change the layout later without touching code', 'zymarg-wcpg' ), __( 'Shortcode stored in a settings field', 'zymarg-wcpg' ) ),
				array( __( 'You need the HTML inside your own markup', 'zymarg-wcpg' ), '<code>Zymarg_Product_Grid::render()</code>' ),
				array( __( 'You only need the products, not the HTML', 'zymarg-wcpg' ), '<code>Zymarg_Product_Grid::query()</code>' ),
				array( __( 'You ship your own card design', 'zymarg-wcpg' ), __( 'Register a card template on zymarg_wcpg_init', 'zymarg-wcpg' ) ),
			)
		);
		self::note( __( 'Storing a shortcode string in your own settings field is the loosest coupling available: you can add engine features later and pick them up by editing that string, with no plugin update.', 'zymarg-wcpg' ) );
		self::close();
	}

	private static function section_sources(): void {
		self::open( 'sources', __( 'Sources', 'zymarg-wcpg' ), __( 'The source decides WHICH products appear. Everything else -- layout, card, slider -- only decides how they look. Set it with source="key" and use the exact key below.', 'zymarg-wcpg' ) );

		self::table(
			array( __( 'Key', 'zymarg-wcpg' ), __( 'What it returns', 'zymarg-wcpg' ), __( 'Notes', 'zymarg-wcpg' ) ),
			array(
				array( '<code>all</code>', __( 'Everything in the catalog', 'zymarg-wcpg' ), __( 'The default. Honours orderby / order.', 'zymarg-wcpg' ) ),
				array( '<code>featured</code>', __( 'Products flagged Featured in WooCommerce', 'zymarg-wcpg' ), __( 'Set the star on the products list.', 'zymarg-wcpg' ) ),
				array( '<code>recent</code>', __( 'Newest published products', 'zymarg-wcpg' ), __( 'Publish date, newest first.', 'zymarg-wcpg' ) ),
				array( '<code>best_selling</code>', __( 'Catalog-wide, ranked by lifetime sales', 'zymarg-wcpg' ), __( 'Uses WooCommerce total_sales.', 'zymarg-wcpg' ) ),
				array( '<code>trending</code>', __( 'Ranked by recent engagement', 'zymarg-wcpg' ), __( 'Rolling 30-day score. Falls back to best-selling before it has data.', 'zymarg-wcpg' ) ),
				array( '<code>flash_deals</code>', __( 'Curated, time-limited sales', 'zymarg-wcpg' ), __( 'Strict rules -- see the Flash Deals section.', 'zymarg-wcpg' ) ),
				array( '<code>category</code>', __( 'Products in a category', 'zymarg-wcpg' ), __( 'Auto-detects the category on archive pages.', 'zymarg-wcpg' ) ),
				array( '<code>similar</code>', __( 'Products related to the current one', 'zymarg-wcpg' ), __( 'Needs a single-product context.', 'zymarg-wcpg' ) ),
				array( '<code>recommended</code>', __( 'Personalised per visitor', 'zymarg-wcpg' ), __( 'Built from browsing, wishlist and cart signals.', 'zymarg-wcpg' ) ),
				array( '<code>wishlist</code>', __( "The visitor's saved products", 'zymarg-wcpg' ), __( 'Works for guests via cookie.', 'zymarg-wcpg' ) ),
				array( '<code>vendor</code>', __( 'A specific seller\'s products', 'zymarg-wcpg' ), __( 'Manual selection. Shown as "More From Seller".', 'zymarg-wcpg' ) ),
				array( '<code>current_vendor</code>', __( 'The store owner whose page you are on', 'zymarg-wcpg' ), __( 'Auto-detect only. See its own section.', 'zymarg-wcpg' ) ),
				array( '<code>dynamic</code>', __( 'Switches behaviour by page context', 'zymarg-wcpg' ), __( 'For one reusable block across page types.', 'zymarg-wcpg' ) ),
				array( '<code>algolia</code>', __( 'Algolia search results', 'zymarg-wcpg' ), __( 'Only on an Algolia-powered results page.', 'zymarg-wcpg' ) ),
			)
		);

		self::warn( __( 'An unknown source key does not error -- it silently falls back to "all". If a grid shows the whole catalog when you expected something specific, check the spelling first.', 'zymarg-wcpg' ) );

		$registry = class_exists( Query_Builder::class ) ? Query_Builder::get_registry() : array();
		if ( ! empty( $registry ) ) {
			echo '<h3 class="zg-h3">' . esc_html__( 'Registered on this site right now', 'zymarg-wcpg' ) . '</h3>';
			echo '<div class="zg-pills">';
			foreach ( array_keys( $registry ) as $key ) {
				echo '<span class="zg-chip">' . esc_html( $key ) . '</span>';
			}
			echo '</div>';
			echo '<p class="zg-muted">' . esc_html__( 'This list is live. Another plugin can add sources, and they will appear here.', 'zymarg-wcpg' ) . '</p>';
		}
		self::close();
	}

	private static function section_vendor(): void {
		self::open( 'vendor', __( 'Current Vendor -- for store pages', 'zymarg-wcpg' ), __( 'Place this on a single store template and it renders only the products of the vendor whose storefront the visitor is viewing. No vendor ID to set; it reads the page.', 'zymarg-wcpg' ) );

		echo '<h3 class="zg-h3">' . esc_html__( 'The four subsets', 'zymarg-wcpg' ) . '</h3>';
		echo '<p>' . esc_html__( 'This is the part people miss: current_vendor is not one listing. It contains four, chosen with current_vendor_subset. Each is scoped to that vendor only -- vendor best sellers, not site best sellers.', 'zymarg-wcpg' ) . '</p>';

		self::table(
			array( __( 'Subset', 'zymarg-wcpg' ), __( 'Ordering', 'zymarg-wcpg' ), __( 'Good for', 'zymarg-wcpg' ) ),
			array(
				array( '<code>all</code>', __( 'Newest first', 'zymarg-wcpg' ), __( 'The main store listing. This is the default.', 'zymarg-wcpg' ) ),
				array( '<code>featured</code>', __( 'Newest first, Featured only', 'zymarg-wcpg' ), __( 'A highlight strip at the top of the store.', 'zymarg-wcpg' ) ),
				array( '<code>best_selling</code>', __( 'Lifetime sales, highest first', 'zymarg-wcpg' ), __( 'A "Top from this seller" row.', 'zymarg-wcpg' ) ),
				array( '<code>trending</code>', __( "That vendor's own 30-day engagement", 'zymarg-wcpg' ), __( 'What is hot in this shop right now.', 'zymarg-wcpg' ) ),
			)
		);

		self::note( __( 'Trending degrades gracefully. With no engagement data yet it falls back to best-selling, and if that is empty too, to newest. A new store still looks populated.', 'zymarg-wcpg' ) );

		echo '<h3 class="zg-h3">' . esc_html__( 'Shortcodes to copy', 'zymarg-wcpg' ) . '</h3>';
		self::code( '[zymarg_products source="current_vendor" limit="12" columns="4"]' );
		self::code( '[zymarg_products source="current_vendor" current_vendor_subset="featured" limit="8"]' );
		self::code( '[zymarg_products source="current_vendor" current_vendor_subset="best_selling" limit="10" layout="slider"]' );
		self::code( '[zymarg_products source="current_vendor" current_vendor_subset="trending" limit="10" layout="slider" slider_marquee="yes"]' );

		echo '<h3 class="zg-h3">' . esc_html__( 'Staff products', 'zymarg-wcpg' ) . '</h3>';
		echo '<p>' . esc_html__( 'Products created by a vendor\'s staff accounts are included by default. Exclude them with current_vendor_include_staff="no".', 'zymarg-wcpg' ) . '</p>';

		echo '<h3 class="zg-h3">' . esc_html__( 'When it renders nothing', 'zymarg-wcpg' ) . '</h3>';
		echo '<ul class="zg-list">';
		echo '<li>' . esc_html__( 'Dokan is missing or below the minimum supported version', 'zymarg-wcpg' ) . '</li>';
		echo '<li>' . esc_html__( 'The page is not a store page and no vendor could be resolved', 'zymarg-wcpg' ) . '</li>';
		echo '<li>' . esc_html__( 'The resolved user is not a real vendor', 'zymarg-wcpg' ) . '</li>';
		echo '<li>' . esc_html__( 'The vendor has no visible products matching the chosen subset', 'zymarg-wcpg' ) . '</li>';
		echo '</ul>';
		self::note( __( 'Detection order: Dokan store page, then the author query var, then the author name. Themes with an unusual store template can supply the ID with the zymarg_wcpg_current_vendor_id filter.', 'zymarg-wcpg' ) );
		self::close();
	}

	private static function section_flash(): void {
		self::open( 'flash', __( 'Flash Deals', 'zymarg-wcpg' ), __( 'A curated, genuinely time-limited sale row. A product must be deliberately flagged AND satisfy a strict data contract, because every flash card draws a countdown and a stock bar.', 'zymarg-wcpg' ) );

		echo '<h3 class="zg-h3">' . esc_html__( 'Step 1 -- flag the products', 'zymarg-wcpg' ) . '</h3>';
		echo '<p>' . esc_html__( 'Edit a product and tick Flash Deal, or use the Flash Deals bulk action on the products list. The Flash Deals column shows each product as Live, Scheduled, Sale ended or Not flagged.', 'zymarg-wcpg' ) . '</p>';

		echo '<h3 class="zg-h3">' . esc_html__( 'Step 2 -- meet the requirements', 'zymarg-wcpg' ) . '</h3>';
		echo '<p>' . esc_html__( 'A flagged product still will not appear unless all of these are true:', 'zymarg-wcpg' ) . '</p>';
		echo '<ul class="zg-list">';
		foreach ( array(
			__( 'Published and visible in the catalog', 'zymarg-wcpg' ),
			__( 'Has a featured image', 'zymarg-wcpg' ),
			__( 'Has a regular price, and a lower sale price', 'zymarg-wcpg' ),
			__( 'The sale has an END DATE in the future -- a permanent discount is never a flash deal', 'zymarg-wcpg' ),
			__( 'Stock management is on, with a stock quantity above zero', 'zymarg-wcpg' ),
			__( 'Backorders are not allowed', 'zymarg-wcpg' ),
			__( 'For variable products, on-sale variations must manage stock', 'zymarg-wcpg' ),
		) as $req ) {
			echo '<li>' . esc_html( $req ) . '</li>';
		}
		echo '</ul>';
		self::note( __( 'The sale end date is the single most common reason a product is missing. The Flash Deals column on the products list names the exact reason for each excluded product.', 'zymarg-wcpg' ) );

		echo '<h3 class="zg-h3">' . esc_html__( 'Step 3 -- place it', 'zymarg-wcpg' ) . '</h3>';
		echo '<p><strong>' . esc_html__( 'Homepage -- site-wide deals', 'zymarg-wcpg' ) . '</strong></p>';
		self::code( '[zymarg_products source="flash_deals" flash_vendor_scope="site" limit="10" layout="slider" card_template="flash"]' );
		echo '<p><strong>' . esc_html__( 'Store page -- only this vendor\'s deals', 'zymarg-wcpg' ) . '</strong></p>';
		self::code( '[zymarg_products source="flash_deals" flash_vendor_scope="vendor" limit="8" card_template="flash"]' );
		echo '<p><strong>' . esc_html__( 'One shortcode for both', 'zymarg-wcpg' ) . '</strong></p>';
		self::code( '[zymarg_products source="flash_deals" flash_vendor_scope="auto" limit="10"]' );

		self::table(
			array( __( 'Scope', 'zymarg-wcpg' ), __( 'Behaviour', 'zymarg-wcpg' ) ),
			array(
				array( '<code>auto</code>', __( 'Site-wide normally, but narrows to the vendor on a store page. The default.', 'zymarg-wcpg' ) ),
				array( '<code>site</code>', __( 'Always the whole marketplace, even on a store page.', 'zymarg-wcpg' ) ),
				array( '<code>vendor</code>', __( 'Vendor only. Hides completely if no vendor can be resolved.', 'zymarg-wcpg' ) ),
			)
		);

		echo '<h3 class="zg-h3">' . esc_html__( 'Ordering and filtering', 'zymarg-wcpg' ) . '</h3>';
		self::table(
			array( __( 'Attribute', 'zymarg-wcpg' ), __( 'Values', 'zymarg-wcpg' ), __( 'Default', 'zymarg-wcpg' ) ),
			array(
				array( '<code>flash_orderby</code>', 'sale_end, discount, price, title, date, popularity, rating, rand', '<code>sale_end</code>' ),
				array( '<code>flash_min_discount</code>', __( '0-100, hides anything discounted less', 'zymarg-wcpg' ), '<code>0</code>' ),
			)
		);
		self::note( __( 'sale_end means ending soonest first, and deliberately ignores the order attribute -- a countdown row reads backwards otherwise. Use flash_orderby rather than the generic orderby, which this source ignores.', 'zymarg-wcpg' ) );
		self::code( '[zymarg_products source="flash_deals" flash_orderby="discount" flash_min_discount="25" limit="8"]' );
		self::note( __( 'Cache lifetime is clamped to the soonest ending sale, so an expired deal can never linger in cached HTML.', 'zymarg-wcpg' ) );
		self::close();
	}

	private static function section_shortcode(): void {
		self::open( 'shortcode', __( 'Shortcode reference', 'zymarg-wcpg' ), __( 'Every attribute [zymarg_products] accepts. Anything you leave out keeps its default, so short shortcodes are normal -- only override what you actually want to change.', 'zymarg-wcpg' ) );

		self::code( '[zymarg_products]' );
		echo '<p class="zg-muted">' . esc_html__( 'That alone renders 8 products in a 4-column grid.', 'zymarg-wcpg' ) . '</p>';

		echo '<h3 class="zg-h3">' . esc_html__( 'Choosing products', 'zymarg-wcpg' ) . '</h3>';
		self::table(
			array( __( 'Attribute', 'zymarg-wcpg' ), __( 'Values', 'zymarg-wcpg' ), __( 'Default', 'zymarg-wcpg' ) ),
			array(
				array( '<code>source</code>', __( 'Any source key', 'zymarg-wcpg' ), '<code>all</code>' ),
				array( '<code>limit</code>', __( 'How many products, up to 100', 'zymarg-wcpg' ), '<code>8</code>' ),
				array( '<code>orderby</code>', 'date, title, price, popularity, rating, rand, menu_order', '<code>date</code>' ),
				array( '<code>order</code>', 'ASC, DESC', '<code>DESC</code>' ),
				array( '<code>include_categories</code>', __( 'Category IDs or slugs, comma separated', 'zymarg-wcpg' ), '&mdash;' ),
				array( '<code>exclude_categories</code>', __( 'Category IDs or slugs, comma separated', 'zymarg-wcpg' ), '&mdash;' ),
				array( '<code>include_products</code>', __( 'Product IDs, comma separated', 'zymarg-wcpg' ), '&mdash;' ),
				array( '<code>exclude_products</code>', __( 'Product IDs, comma separated', 'zymarg-wcpg' ), '&mdash;' ),
				array( '<code>current_vendor_subset</code>', 'all, featured, best_selling, trending', '<code>all</code>' ),
				array( '<code>flash_vendor_scope</code>', 'auto, site, vendor', '<code>auto</code>' ),
				array( '<code>flash_orderby</code>', __( 'See the Flash Deals section', 'zymarg-wcpg' ), '<code>sale_end</code>' ),
				array( '<code>flash_min_discount</code>', '0-100', '<code>0</code>' ),
			)
		);

		echo '<h3 class="zg-h3">' . esc_html__( 'Layout', 'zymarg-wcpg' ) . '</h3>';
		self::table(
			array( __( 'Attribute', 'zymarg-wcpg' ), __( 'Values', 'zymarg-wcpg' ), __( 'Default', 'zymarg-wcpg' ) ),
			array(
				array( '<code>layout</code>', 'grid, slider', '<code>grid</code>' ),
				array( '<code>columns</code>', __( '1-6, desktop', 'zymarg-wcpg' ), '<code>4</code>' ),
				array( '<code>columns_tablet</code>', '1-6', '<code>3</code>' ),
				array( '<code>columns_mobile</code>', '1-6', '<code>2</code>' ),
				array( '<code>gap</code>', __( 'Spacing in px, 0-100', 'zymarg-wcpg' ), '<code>6</code>' ),
				array( '<code>card_template</code>', __( 'Registered card slug', 'zymarg-wcpg' ), '<code>classic</code>' ),
				array( '<code>template</code>', __( 'Registered template slug', 'zymarg-wcpg' ), '&mdash;' ),
				array( '<code>slot</code>', __( 'Registered slot name', 'zymarg-wcpg' ), '&mdash;' ),
			)
		);

		echo '<h3 class="zg-h3">' . esc_html__( 'Heading and View All', 'zymarg-wcpg' ) . '</h3>';
		self::table(
			array( __( 'Attribute', 'zymarg-wcpg' ), __( 'Values', 'zymarg-wcpg' ), __( 'Default', 'zymarg-wcpg' ) ),
			array(
				array( '<code>show_heading</code>', 'yes, no', '<code>no</code>' ),
				array( '<code>heading_text</code>', __( 'Any text', 'zymarg-wcpg' ), '&mdash;' ),
				array( '<code>heading_subtext</code>', __( 'Smaller text below', 'zymarg-wcpg' ), '&mdash;' ),
				array( '<code>heading_tag</code>', 'h1-h6', '<code>h2</code>' ),
				array( '<code>heading_alignment</code>', 'left, center, right', '<code>left</code>' ),
				array( '<code>show_view_all</code>', 'yes, no', '<code>no</code>' ),
				array( '<code>view_all_text</code>', __( 'Link label', 'zymarg-wcpg' ), '&mdash;' ),
				array( '<code>view_all_url</code>', __( 'Link target', 'zymarg-wcpg' ), '&mdash;' ),
				array( '<code>view_all_auto_vendor</code>', __( 'yes points View All at the vendor store', 'zymarg-wcpg' ), '<code>no</code>' ),
				array( '<code>view_all_vendor_product_id</code>', __( 'Product ID to resolve the vendor from', 'zymarg-wcpg' ), __( 'auto', 'zymarg-wcpg' ) ),
			)
		);
		self::code( '[zymarg_products source="trending" show_heading="yes" heading_text="Trending now" show_view_all="yes" view_all_text="See all" view_all_url="/shop/"]' );

		echo '<h3 class="zg-h3">' . esc_html__( 'What each card shows', 'zymarg-wcpg' ) . '</h3>';
		echo '<p>' . esc_html__( 'All of these take yes or no.', 'zymarg-wcpg' ) . '</p>';
		self::table(
			array( __( 'Attribute', 'zymarg-wcpg' ), __( 'Shows', 'zymarg-wcpg' ), __( 'Default', 'zymarg-wcpg' ) ),
			array(
				array( '<code>show_image</code>', __( 'Product image', 'zymarg-wcpg' ), '<code>yes</code>' ),
				array( '<code>show_title</code>', __( 'Product name', 'zymarg-wcpg' ), '<code>yes</code>' ),
				array( '<code>show_price</code>', __( 'Price', 'zymarg-wcpg' ), '<code>yes</code>' ),
				array( '<code>show_rating</code>', __( 'Star rating', 'zymarg-wcpg' ), '<code>yes</code>' ),
				array( '<code>show_atc</code>', __( 'Add to cart button', 'zymarg-wcpg' ), '<code>yes</code>' ),
				array( '<code>show_wishlist</code>', __( 'Wishlist heart', 'zymarg-wcpg' ), '<code>yes</code>' ),
				array( '<code>show_quickview</code>', __( 'Quick View button', 'zymarg-wcpg' ), '<code>yes</code>' ),
				array( '<code>show_discount_badge</code>', __( 'Percent-off badge', 'zymarg-wcpg' ), '<code>yes</code>' ),
				array( '<code>show_stock_badge</code>', __( 'Stock status badge', 'zymarg-wcpg' ), '<code>yes</code>' ),
				array( '<code>show_vendor</code>', __( 'Seller name', 'zymarg-wcpg' ), '<code>no</code>' ),
				array( '<code>show_sold_count</code>', __( 'Units sold', 'zymarg-wcpg' ), '<code>no</code>' ),
			)
		);

		echo '<h3 class="zg-h3">' . esc_html__( 'Countdown', 'zymarg-wcpg' ) . '</h3>';
		self::table(
			array( __( 'Attribute', 'zymarg-wcpg' ), __( 'Values', 'zymarg-wcpg' ), __( 'Default', 'zymarg-wcpg' ) ),
			array(
				array( '<code>show_countdown</code>', 'auto, yes, no', '<code>auto</code>' ),
				array( '<code>countdown_position</code>', 'below_price, over_image, before_title', '<code>below_price</code>' ),
			)
		);

		echo '<h3 class="zg-h3">' . esc_html__( 'Pagination', 'zymarg-wcpg' ) . '</h3>';
		self::table(
			array( __( 'Attribute', 'zymarg-wcpg' ), __( 'Values', 'zymarg-wcpg' ), __( 'Default', 'zymarg-wcpg' ) ),
			array(
				array( '<code>pagination</code>', 'none, load_more, infinite', '<code>none</code>' ),
				array( '<code>load_more_text</code>', __( 'Button label', 'zymarg-wcpg' ), __( 'Load More', 'zymarg-wcpg' ) ),
				array( '<code>batch_size</code>', __( 'Products per load, desktop', 'zymarg-wcpg' ), '<code>20</code>' ),
				array( '<code>batch_size_tablet</code>', __( 'Products per load, tablet', 'zymarg-wcpg' ), '<code>20</code>' ),
				array( '<code>batch_size_mobile</code>', __( 'Products per load, mobile', 'zymarg-wcpg' ), '<code>10</code>' ),
				array( '<code>max_products</code>', __( 'Auto-load cap, desktop', 'zymarg-wcpg' ), '<code>100</code>' ),
				array( '<code>max_products_tablet</code>', __( 'Auto-load cap, tablet', 'zymarg-wcpg' ), '<code>100</code>' ),
				array( '<code>max_products_mobile</code>', __( 'Auto-load cap, mobile', 'zymarg-wcpg' ), '<code>50</code>' ),
				array( '<code>empty_message</code>', __( 'Text when nothing matches', 'zymarg-wcpg' ), '&mdash;' ),
			)
		);
		self::close();
	}

	private static function section_slider(): void {
		self::open( 'slider', __( 'Slider and marquee', 'zymarg-wcpg' ), __( 'Add layout="slider" to turn any grid into a carousel. The columns attributes then mean slides visible per screen.', 'zymarg-wcpg' ) );

		self::table(
			array( __( 'Attribute', 'zymarg-wcpg' ), __( 'Values', 'zymarg-wcpg' ), __( 'Default', 'zymarg-wcpg' ) ),
			array(
				array( '<code>slider_arrows</code>', 'yes, no', '<code>yes</code>' ),
				array( '<code>slider_pagination</code>', 'bullets, progress, none', '<code>bullets</code>' ),
				array( '<code>slider_loop</code>', 'yes, no', '<code>yes</code>' ),
				array( '<code>free_scroll</code>', __( 'yes gives momentum scrolling', 'zymarg-wcpg' ), '<code>yes</code>' ),
				array( '<code>mousewheel</code>', __( 'Horizontal wheel / trackpad', 'zymarg-wcpg' ), '<code>yes</code>' ),
				array( '<code>slider_autoplay</code>', 'yes, no', '<code>no</code>' ),
				array( '<code>slider_autoplay_delay</code>', __( '100-30000 ms between slides', 'zymarg-wcpg' ), '<code>4000</code>' ),
				array( '<code>slider_speed</code>', __( '100-10000 ms per transition', 'zymarg-wcpg' ), '<code>500</code>' ),
				array( '<code>slider_space_between</code>', __( '0-100 px between slides', 'zymarg-wcpg' ), __( 'inherits gap', 'zymarg-wcpg' ) ),
				array( '<code>slider_marquee</code>', __( 'yes for continuous drift', 'zymarg-wcpg' ), '<code>no</code>' ),
				array( '<code>slider_marquee_speed</code>', __( '500-20000 ms per slide', 'zymarg-wcpg' ), '<code>4000</code>' ),
			)
		);

		echo '<h3 class="zg-h3">' . esc_html__( 'Marquee', 'zymarg-wcpg' ) . '</h3>';
		echo '<p>' . esc_html__( 'Marquee is a slow continuous drift rather than slide-by-slide movement. It pauses the moment a visitor hovers a card or holds it on touch, and resumes from exactly the same position. Dragging still works while it drifts.', 'zymarg-wcpg' ) . '</p>';
		self::code( '[zymarg_products layout="slider" limit="12" slider_marquee="yes" slider_marquee_speed="5000"]' );
		self::note( __( 'A higher marquee speed number means slower drift -- it is milliseconds per slide, not velocity.', 'zymarg-wcpg' ) );
		self::warn( __( 'Marquee requires loop, so it turns itself off if slider_loop="no".', 'zymarg-wcpg' ) );

		echo '<h3 class="zg-h3">' . esc_html__( 'How many products a loop needs', 'zymarg-wcpg' ) . '</h3>';
		echo '<p>' . esc_html__( 'This is the single most common slider problem. Looping needs spare slides beyond the ones on screen, so the rule is: product count must be greater than desktop columns plus one.', 'zymarg-wcpg' ) . '</p>';
		self::table(
			array( __( 'Desktop columns', 'zymarg-wcpg' ), __( 'Minimum products for loop / marquee', 'zymarg-wcpg' ) ),
			array(
				array( '2', '4' ),
				array( '3', '5' ),
				array( '4', '6' ),
				array( '5', '7' ),
				array( '6', '8' ),
			)
		);
		self::note( __( 'Below the minimum the loop quietly switches off and the slider stops at the last product. Either add products or reduce columns for that block.', 'zymarg-wcpg' ) );
		self::close();
	}

	private static function section_cards(): void {
		self::open( 'cards', __( 'Cards and templates', 'zymarg-wcpg' ), __( 'A card template controls how one product looks. A template controls the whole block. They are independent.', 'zymarg-wcpg' ) );

		echo '<h3 class="zg-h3">' . esc_html__( 'Card templates installed now', 'zymarg-wcpg' ) . '</h3>';
		$cards = apply_filters( 'zymarg_card_template_labels', array() );
		if ( is_array( $cards ) && ! empty( $cards ) ) {
			echo '<div class="zg-pills">';
			foreach ( $cards as $slug => $label ) {
				echo '<span class="zg-chip">' . esc_html( (string) $slug ) . '</span>';
			}
			echo '</div>';
		} else {
			echo '<div class="zg-pills"><span class="zg-chip">classic</span></div>';
		}
		echo '<p class="zg-muted">' . esc_html__( 'classic ships with the engine. zymarg and flash come from the Template Pack plugin. Select one with card_template="slug".', 'zymarg-wcpg' ) . '</p>';
		self::code( '[zymarg_products source="flash_deals" card_template="flash" layout="slider"]' );
		self::note( __( 'A card template can also change slider defaults. The Template Pack cards default to a progress bar and no arrows, which is why a slider can look different just from switching card_template.', 'zymarg-wcpg' ) );

		echo '<h3 class="zg-h3">' . esc_html__( 'Adding your own card', 'zymarg-wcpg' ) . '</h3>';
		self::code( "add_action( 'zymarg_wcpg_init', function () {\n    Zymarg\\\\WCPG\\\\Services\\\\Template_Manager::register_card(\n        'fashion',\n        __DIR__ . '/templates/product-card.php'\n    );\n} );" );
		echo '<p>' . esc_html__( 'You can also override any engine template by copying it into your theme. See docs/04-template-overrides.md in the plugin folder.', 'zymarg-wcpg' ) . '</p>';
		self::close();
	}

	private static function section_slots(): void {
		self::open( 'slots', __( 'Slots and automatic placement', 'zymarg-wcpg' ), __( 'A slot is a named position on the site. The engine can replace the stock WooCommerce product rows in these positions with no shortcode at all.', 'zymarg-wcpg' ) );

		$slots = array();
		if ( class_exists( Slot_Registry::class ) && method_exists( Slot_Registry::class, 'all' ) ) {
			$slots = (array) Slot_Registry::all();
		}
		if ( ! empty( $slots ) ) {
			$rows = array();
			foreach ( $slots as $slug => $def ) {
				$rows[] = array(
					'<code>' . esc_html( (string) $slug ) . '</code>',
					esc_html( isset( $def['description'] ) ? (string) $def['description'] : '' ),
					'<code>' . esc_html( isset( $def['template'] ) ? (string) $def['template'] : '' ) . '</code>',
				);
			}
			self::table( array( __( 'Slot', 'zymarg-wcpg' ), __( 'Where it appears', 'zymarg-wcpg' ), __( 'Template', 'zymarg-wcpg' ) ), $rows );
		} else {
			self::note( __( 'Slot registry not available on this screen.', 'zymarg-wcpg' ) );
		}

		echo '<p>' . esc_html__( 'You can target a slot deliberately from a shortcode too, which picks up that slot\'s configured template:', 'zymarg-wcpg' ) . '</p>';
		self::code( '[zymarg_products slot="homepage-featured"]' );
		self::close();
	}

	private static function section_pagination(): void {
		self::open( 'pagination', __( 'Pagination and Load More', 'zymarg-wcpg' ), __( 'Grids can load more products without a page reload. Sliders ignore this -- they scroll instead.', 'zymarg-wcpg' ) );
		self::table(
			array( __( 'Mode', 'zymarg-wcpg' ), __( 'Behaviour', 'zymarg-wcpg' ) ),
			array(
				array( '<code>none</code>', __( 'Show the limit and stop. The default.', 'zymarg-wcpg' ) ),
				array( '<code>load_more</code>', __( 'A button the visitor clicks to append the next batch.', 'zymarg-wcpg' ) ),
				array( '<code>infinite</code>', __( 'Appends automatically as the visitor scrolls, up to the max cap.', 'zymarg-wcpg' ) ),
			)
		);
		self::code( '[zymarg_products source="all" limit="12" pagination="load_more" batch_size="12" load_more_text="Show more"]' );
		self::note( __( 'batch_size is how many arrive per click. max_products is the ceiling for infinite mode so a long catalog cannot load forever. Both have separate tablet and mobile values.', 'zymarg-wcpg' ) );
		self::close();
	}

	private static function section_countdown(): void {
		self::open( 'countdown', __( 'Countdown timers', 'zymarg-wcpg' ), __( 'A live ticking timer showing when a sale ends. It counts down in the browser, so it stays accurate even when the page is served from cache.', 'zymarg-wcpg' ) );
		self::table(
			array( __( 'show_countdown', 'zymarg-wcpg' ), __( 'Result', 'zymarg-wcpg' ) ),
			array(
				array( '<code>auto</code>', __( 'Shows only where it makes sense -- flash deals and sales with an end date. The default.', 'zymarg-wcpg' ) ),
				array( '<code>yes</code>', __( 'Force it on wherever an end date exists.', 'zymarg-wcpg' ) ),
				array( '<code>no</code>', __( 'Never show it.', 'zymarg-wcpg' ) ),
			)
		);
		echo '<p>' . esc_html__( 'Position it with countdown_position: below_price, over_image or before_title.', 'zymarg-wcpg' ) . '</p>';
		self::code( '[zymarg_products source="flash_deals" show_countdown="yes" countdown_position="over_image"]' );
		self::note( __( 'No countdown on a sale product almost always means the sale has no end date set.', 'zymarg-wcpg' ) );
		self::close();
	}

	private static function section_php(): void {
		self::open( 'php', __( 'PHP API', 'zymarg-wcpg' ), __( 'For themes and standalone plugins. These signatures are stable and will not change without a major version bump.', 'zymarg-wcpg' ) );

		echo '<h3 class="zg-h3">' . esc_html__( 'Render HTML', 'zymarg-wcpg' ) . '</h3>';
		self::code( "echo Zymarg_Product_Grid::render( array(\n    'query'  => array(\n        'source' => 'current_vendor',\n        'limit'  => 12,\n        'current_vendor_subset' => 'best_selling',\n    ),\n    'config' => array(\n        'layout' => array( 'type' => 'slider', 'columns' => 5 ),\n        'card'   => array( 'template' => 'zymarg' ),\n    ),\n) );" );

		echo '<h3 class="zg-h3">' . esc_html__( 'Get products without HTML', 'zymarg-wcpg' ) . '</h3>';
		self::code( "\$result = Zymarg_Product_Grid::query( array(\n    'query'  => array( 'source' => 'flash_deals' ),\n    'limit'  => 8,\n    'offset' => 0,\n) );" );

		echo '<h3 class="zg-h3">' . esc_html__( 'Guard clauses for a standalone plugin', 'zymarg-wcpg' ) . '</h3>';
		self::code( "if ( class_exists( 'Zymarg_Product_Grid' ) ) {\n    echo Zymarg_Product_Grid::render( array( 'slot' => 'store-products' ) );\n}" );
		self::code( "if ( Zymarg_Product_Grid::has_source( 'flash_deals' ) ) {\n    // safe to offer flash deals in your settings UI\n}" );

		echo '<h3 class="zg-h3">' . esc_html__( 'Shortcut function', 'zymarg-wcpg' ) . '</h3>';
		self::code( "echo zymarg_render_grid( array( 'query' => array( 'source' => 'featured' ) ) );" );

		self::warn( __( 'render() returns a hide sentinel rather than HTML when a source finds nothing. Echo the return value directly and the engine handles it; only compare it yourself if you need to hide your own surrounding markup.', 'zymarg-wcpg' ) );

		echo '<h3 class="zg-h3">' . esc_html__( 'Rendering a stored shortcode instead', 'zymarg-wcpg' ) . '</h3>';
		echo '<p>' . esc_html__( 'If your plugin stores a shortcode string in its own settings field, render it like this. You then get new engine features by editing that field, with no plugin update.', 'zymarg-wcpg' ) . '</p>';
		self::code( "echo do_shortcode( get_option( 'my_plugin_grid_shortcode' ) );" );
		self::close();
	}

	private static function section_hooks(): void {
		self::open( 'hooks', __( 'Hooks', 'zymarg-wcpg' ), __( 'The engine exposes filters to change data and actions to observe it. The most useful are listed here; the complete list is in docs/03-hooks.md.', 'zymarg-wcpg' ) );

		self::table(
			array( __( 'Filter', 'zymarg-wcpg' ), __( 'Lets you', 'zymarg-wcpg' ) ),
			array(
				array( '<code>zymarg_products</code>', __( 'Change the final product collection before rendering', 'zymarg-wcpg' ) ),
				array( '<code>zymarg_query_args</code>', __( 'Alter the product query', 'zymarg-wcpg' ) ),
				array( '<code>zymarg_product_grid_config</code>', __( 'Change any setting for every grid', 'zymarg-wcpg' ) ),
				array( '<code>zymarg_product_grid_defaults</code>', __( 'Change the site-wide defaults', 'zymarg-wcpg' ) ),
				array( '<code>zymarg_wcpg_source_registry</code>', __( 'Register your own source', 'zymarg-wcpg' ) ),
				array( '<code>zymarg_product_grid_slots</code>', __( 'Add or repoint slots', 'zymarg-wcpg' ) ),
				array( '<code>zymarg_product_grid_templates</code>', __( 'Add or change templates', 'zymarg-wcpg' ) ),
				array( '<code>zymarg_card_template</code>', __( 'Swap the card per grid', 'zymarg-wcpg' ) ),
				array( '<code>zymarg_wcpg_current_vendor_id</code>', __( 'Supply the vendor ID on unusual store templates', 'zymarg-wcpg' ) ),
				array( '<code>zymarg_wcpg_flash_deals_vendor_id</code>', __( 'Supply the vendor for vendor-scoped flash deals', 'zymarg-wcpg' ) ),
				array( '<code>zymarg_wcpg_flash_deals_validation</code>', __( 'Adjust flash deal eligibility', 'zymarg-wcpg' ) ),
				array( '<code>zymarg_wcpg_countdown_end_ts</code>', __( 'Override the countdown end time', 'zymarg-wcpg' ) ),
				array( '<code>zymarg_cache_enabled</code> / <code>zymarg_cache_ttl</code>', __( 'Control caching', 'zymarg-wcpg' ) ),
			)
		);

		self::table(
			array( __( 'Action', 'zymarg-wcpg' ), __( 'Fires when', 'zymarg-wcpg' ) ),
			array(
				array( '<code>zymarg_wcpg_init</code>', __( 'The engine is ready -- register cards and sources here', 'zymarg-wcpg' ) ),
				array( '<code>zymarg_product_grid_render_request</code>', __( 'A grid render begins', 'zymarg-wcpg' ) ),
				array( '<code>zymarg_product_grid_render_complete</code>', __( 'A grid render finishes', 'zymarg-wcpg' ) ),
				array( '<code>zymarg_render_failed</code> / <code>zymarg_query_failed</code>', __( 'Something threw -- these feed the issue counter', 'zymarg-wcpg' ) ),
				array( '<code>zymarg_cache_hit</code> / <code>zymarg_cache_miss</code>', __( 'Cache lookups', 'zymarg-wcpg' ) ),
				array( '<code>zymarg_wcpg_added_to_cart</code>', __( 'A visitor adds to cart from a card', 'zymarg-wcpg' ) ),
				array( '<code>zymarg_wcpg_wishlist_toggled</code>', __( 'A wishlist heart is clicked', 'zymarg-wcpg' ) ),
				array( '<code>zymarg_wcpg_quick_view_opened</code>', __( 'Quick View opens', 'zymarg-wcpg' ) ),
			)
		);
		self::close();
	}

	private static function section_cache(): void {
		self::open( 'cache', __( 'Caching', 'zymarg-wcpg' ), __( 'Rendered HTML is cached so repeat visitors do not re-run the query. It clears itself automatically -- you should rarely need to think about it.', 'zymarg-wcpg' ) );
		echo '<p>' . esc_html__( 'The cache clears when a product is saved, its stock or price changes, an order completes, or the plugin updates. Flash deal caches additionally expire the moment the soonest sale ends.', 'zymarg-wcpg' ) . '</p>';
		echo '<p>' . esc_html__( 'To disable it temporarily while testing:', 'zymarg-wcpg' ) . '</p>';
		self::code( "add_filter( 'zymarg_cache_enabled', '__return_false' );" );
		self::note( __( 'If a grid seems stuck on old products, the cache is the first thing to rule out. Save any product to flush it.', 'zymarg-wcpg' ) );
		self::close();
	}

	private static function section_trouble(): void {
		self::open( 'trouble', __( 'Troubleshooting', 'zymarg-wcpg' ), __( 'The failures that actually happen, and what they mean.', 'zymarg-wcpg' ) );
		self::table(
			array( __( 'Symptom', 'zymarg-wcpg' ), __( 'Most likely cause', 'zymarg-wcpg' ) ),
			array(
				array( __( 'Nothing renders at all', 'zymarg-wcpg' ), __( 'The source found no products, so the whole block hides itself. Check the Render Log on Engine Diagnostics.', 'zymarg-wcpg' ) ),
				array( __( 'It shows the whole catalog instead of what I asked for', 'zymarg-wcpg' ), __( 'A misspelled source key silently falls back to "all".', 'zymarg-wcpg' ) ),
				array( __( 'Slider does not loop', 'zymarg-wcpg' ), __( 'Not enough products: you need more than columns plus one.', 'zymarg-wcpg' ) ),
				array( __( 'Marquee does nothing', 'zymarg-wcpg' ), __( 'Loop is off, or the product count is below the loop minimum.', 'zymarg-wcpg' ) ),
				array( __( 'Flash deals row is empty', 'zymarg-wcpg' ), __( 'Products lack a sale END DATE, or stock management is off. The products list column names the reason.', 'zymarg-wcpg' ) ),
				array( __( 'Current vendor shows nothing', 'zymarg-wcpg' ), __( 'Not a store page, or the vendor could not be resolved.', 'zymarg-wcpg' ) ),
				array( __( 'No countdown on a sale product', 'zymarg-wcpg' ), __( 'The sale has no end date.', 'zymarg-wcpg' ) ),
				array( __( 'Old products keep showing', 'zymarg-wcpg' ), __( 'Cached HTML. Save any product to flush.', 'zymarg-wcpg' ) ),
				array( __( 'Arrows or pagination look wrong after switching cards', 'zymarg-wcpg' ), __( 'Template Pack cards change slider defaults. Set slider_arrows and slider_pagination explicitly.', 'zymarg-wcpg' ) ),
				array( __( 'A shortcode attribute is ignored in Elementor', 'zymarg-wcpg' ), __( 'The widget writes its own arrow and pagination values. Use the shortcode for those.', 'zymarg-wcpg' ) ),
			)
		);
		echo '<p>' . esc_html__( 'Engine Diagnostics now records every real render: which page, which source, and whether it produced anything. It also includes a test bench where you can render any source on demand.', 'zymarg-wcpg' ) . '</p>';
		self::close();
	}

	/**
	 * Guide styles. Gated to this screen only so nothing leaks into wp-admin.
	 *
	 * @return void
	 */
	public static function inline_styles(): void {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || strpos( $screen->id, self::SLUG ) === false ) {
			return;
		}
		?>
		<style>
		.zg-wrap { max-width: 1200px; padding: 20px 0 60px; }
		.zg-wrap * { box-sizing: border-box; }
		.zg-header { display: flex; align-items: center; justify-content: space-between; gap: 20px;
			background: linear-gradient(135deg, #9500a5 0%, #bd00d1 100%); color: #fff;
			border-radius: 12px; padding: 24px 28px; margin-bottom: 20px;
			box-shadow: 0 4px 20px rgba(149,0,165,0.25); }
		.zg-header__left { display: flex; align-items: center; gap: 16px; }
		.zg-header__logo { font-size: 32px; line-height: 1; }
		.zg-header__title { margin: 0; color: #fff; font-size: 22px; font-weight: 700; line-height: 1.2; }
		.zg-header__sub { margin: 4px 0 0; color: #fea9ff; font-size: 13px; }
		.zg-pill { display: inline-block; border-radius: 20px; padding: 6px 14px; font-size: 12px; font-weight: 600; }
		.zg-pill--version { background: rgba(255,255,255,0.18); color: #fff; }
		.zg-nav { position: sticky; top: 32px; z-index: 20; display: flex; flex-wrap: wrap; gap: 8px;
			background: #fff; border: 1px solid #f0d6f3; border-radius: 12px; padding: 14px 16px;
			margin-bottom: 20px; box-shadow: 0 4px 20px rgba(149,0,165,0.1); }
		.zg-nav__item { display: inline-block; border-radius: 20px; padding: 6px 14px; font-size: 12px;
			font-weight: 600; text-decoration: none; color: #9500a5; background: #faf0fc; }
		.zg-nav__item:hover, .zg-nav__item:focus { background: #9500a5; color: #fff; box-shadow: none; }
		.zg-section { background: #fff; border: 1px solid #f0d6f3; border-radius: 12px; padding: 24px 28px;
			margin-bottom: 20px; box-shadow: 0 4px 20px rgba(149,0,165,0.1); scroll-margin-top: 110px; }
		.zg-section__header { border-bottom: 2px solid #faf0fc; padding-bottom: 12px; margin-bottom: 16px; }
		.zg-section__title { margin: 0; font-size: 18px; font-weight: 700; color: #9500a5; }
		.zg-lede { font-size: 14px; color: #50575e; margin: 0 0 18px; max-width: 900px; line-height: 1.6; }
		.zg-h3 { font-size: 14px; font-weight: 700; color: #1d2327; margin: 26px 0 10px;
			padding-left: 12px; border-left: 3px solid #bd00d1; }
		.zg-section p { font-size: 13px; line-height: 1.7; color: #3c434a; max-width: 900px; }
		.zg-muted { color: #787c82 !important; font-size: 12px !important; }
		.zg-table { width: 100%; border-collapse: collapse; margin: 12px 0 18px; font-size: 13px; }
		.zg-table th { text-align: left; background: #faf0fc; color: #9500a5; font-weight: 700;
			padding: 10px 14px; border-bottom: 2px solid #f0d6f3; font-size: 12px; }
		.zg-table td { padding: 10px 14px; border-bottom: 1px solid #f2f2f4; vertical-align: top;
			color: #3c434a; line-height: 1.6; }
		.zg-table tr:last-child td { border-bottom: none; }
		.zg-table tbody tr:hover { background: #fdf8fe; }
		.zg-td--key { white-space: nowrap; }
		.zg-table code, .zg-section p code, .zg-list code { background: #faf0fc; color: #9500a5;
			border-radius: 4px; padding: 2px 6px; font-size: 12px; }
		.zg-code { background: #1d2327; color: #fea9ff; border-radius: 8px; padding: 14px 16px;
			overflow-x: auto; margin: 10px 0 16px; font-size: 12.5px; line-height: 1.6; max-width: 900px; }
		.zg-code code { background: none; color: inherit; padding: 0; font-size: inherit; }
		.zg-note { border-left: 3px solid #bd00d1; background: #faf0fc; border-radius: 0 8px 8px 0;
			padding: 12px 16px; margin: 12px 0 16px; font-size: 13px; color: #3c434a;
			line-height: 1.6; max-width: 900px; }
		.zg-note--warn { border-left-color: #d63638; background: #fcf0f1; }
		.zg-list, .zg-steps { margin: 8px 0 16px 18px; max-width: 900px; }
		.zg-list li, .zg-steps li { font-size: 13px; line-height: 1.7; color: #3c434a; margin-bottom: 6px; }
		.zg-steps li strong { color: #9500a5; }
		.zg-pills { display: flex; flex-wrap: wrap; gap: 8px; margin: 10px 0 14px; }
		.zg-chip { display: inline-block; background: #faf0fc; color: #9500a5; border: 1px solid #f0d6f3;
			border-radius: 20px; padding: 5px 14px; font-size: 12px; font-weight: 600; }
		@media screen and (max-width: 782px) {
			.zg-nav { position: static; }
			.zg-header { flex-direction: column; align-items: flex-start; }
		}
		</style>
		<?php
	}

	/**
	 * No public construction.
	 */
	private function __construct() {}
}
