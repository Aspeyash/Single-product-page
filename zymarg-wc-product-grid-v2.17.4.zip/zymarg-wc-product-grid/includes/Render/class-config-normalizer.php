<?php
/**
 * Config Normalizer — merges all configuration layers into one complete,
 * validated, renderer-ready configuration array.
 *
 * This class is the configuration brain of the framework. It accepts pieces
 * from different sources and returns one complete configuration that the
 * Render Engine can consume without knowing where any value came from.
 *
 * Merge order (locked — do not change without updating all callers):
 *   1. Framework defaults       (Config_Defaults::get())
 *   2. Card style defaults      (reserved, empty today)
 *   3. Template config          (Template_Registry::get())
 *   4. Caller overrides         (per-call overrides from Public API)
 *   5. Responsive inheritance   (tablet inherits desktop, mobile inherits tablet)
 *   6. Validation + sanitization
 *   7. Filter
 *
 * Output contract:
 *   Every canonical key is guaranteed to be present in the returned array.
 *   The Render Engine never needs to check for key existence.
 *
 * This class must not:
 *   - Query products.
 *   - Resolve context.
 *   - Know about slots.
 *   - Know about template slugs.
 *   - Render HTML.
 *   - Know about Elementor.
 *   - Read from the database.
 *   - Read WordPress globals.
 *
 * @package Zymarg\WCPG\Render
 * @since   1.6.0
 */

namespace Zymarg\WCPG\Render;

defined( 'ABSPATH' ) || exit;

/**
 * Class Config_Normalizer
 */
final class Config_Normalizer {

	/**
	 * Top-level keys whose sub-arrays are merged recursively (deep merge).
	 * Keys not in this list are replaced entirely if overridden.
	 *
	 * @var array<string>
	 */
	private const DEEP_MERGE_KEYS = [ 'query', 'layout', 'card', 'heading', 'pagination', 'responsive' ];

	/**
	 * Valid values for enumerated settings.
	 * Any value not in the list is replaced with the framework default.
	 *
	 * @var array<string, array<string>>
	 */
	private const VALID_VALUES = [
		'layout.type'          => [ 'grid', 'slider' ],
		'query.flash_vendor_scope' => [ 'auto', 'site', 'vendor' ],
		'query.flash_orderby'      => [ 'sale_end', 'discount', 'price', 'title', 'date', 'popularity', 'rating', 'rand' ],
		'pagination.mode'        => [ 'none', 'load_more', 'infinite' ],
		'heading.tag'            => [ 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'div', 'span' ],
		'heading.alignment'      => [ 'left', 'center', 'right' ],
		'card.price_position'  => [ 'above_title', 'above_rating', 'below_rating' ],
		'card.vendor_position' => [ 'above_title', 'below_meta', 'below_price' ],
		'card.atc_position'    => [ 'standalone', 'with_meta', 'with_price', 'with_vendor' ],
		'card.discount_badge_mode' => [ 'percentage', 'amount' ],
		'card.sold_count_format'   => [ 'short', 'full' ],
		'card.meta_layout'         => [ 'stacked', 'inline' ],
		'card.show_countdown'      => [ 'auto', 'yes', 'no' ],
		'card.countdown_position'  => [ 'below_price', 'over_image', 'before_title' ],
	];

	/**
	 * Numeric settings that must stay within bounds.
	 * Format: 'section.key' => [ min, max|null ]
	 *
	 * @var array<string, array{0: int|float, 1: int|float|null}>
	 */
	private const NUMERIC_BOUNDS = [
		'query.limit'    => [ 1, 100 ],
		'query.flash_min_discount' => [ 0, 100 ],
		'layout.columns' => [ 1, 6 ],
		'layout.gap'     => [ 0, 200 ],
		'card.title_lines' => [ 1, 5 ],
	];

	/**
	 * Produce one complete, validated, renderer-ready configuration.
	 *
	 * @param array $template_config Partial config from Template_Registry.
	 * @param array $caller_overrides Per-call overrides from the Public API.
	 * @param array $context Resolved context, forwarded to the config filters
	 *                       so extensions can adjust the config per page,
	 *                       vendor, category or search term. Optional and
	 *                       defaulted, so existing callers keep working.
	 * @return array Complete normalized configuration.
	 */
	public static function normalize(
		array $template_config  = [],
		array $caller_overrides = [],
		array $context          = []
	): array {
		// 1. Framework defaults — the baseline every key is guaranteed from.
		$config = Config_Defaults::get();

		// 2. Card style defaults — reserved slot, empty today.
		//    When card styles are introduced, a Card_Style_Defaults provider
		//    will be called here before the template config is merged.
		$card_style_defaults = self::get_card_style_defaults( $config['card']['style'] ?? 'default' );
		$config = self::deep_merge( $config, [ 'card' => $card_style_defaults ] );

		// 3. Template config — what makes this template unique.
		$config = self::deep_merge( $config, $template_config );

		// 4. Caller overrides — highest priority before responsive resolution.
		$config = self::deep_merge( $config, $caller_overrides );

		// 5. Responsive inheritance:
		//    tablet inherits desktop → mobile inherits tablet.
		//    By the time the renderer runs, each breakpoint has a full config.
		$config = self::resolve_responsive( $config );

		// 6. Validate and sanitize all canonical values.
		$config = self::validate( $config );

		/**
		 * Filter the complete normalized configuration before it is returned
		 * to the Render Engine.
		 *
		 * The config is fully merged and validated at this point. Only use
		 * this filter for advanced adjustments that cannot be expressed as
		 * template configs or caller overrides.
		 *
		 * @since 1.6.0
		 * @param array $config Complete normalized configuration.
		 */
		// Primary filter — existing name kept for backward compatibility.
		$config = (array) apply_filters( 'zymarg_product_grid_config', $config );

		/**
		 * Filter the final normalized render config before the Render Engine runs.
		 *
		 * Canonical Extension API name (Milestone 7). Use this hook to switch
		 * layout, change columns, disable Quick View, change template, or
		 * override any config value without modifying core files.
		 *
		 * @since 1.9.0
		 * @param array $config  Normalized configuration array.
		 * @param array $context Resolved context (page type, vendor id, etc.).
		 */
		// Receives the real resolved context as of v2.1.0; an empty array was
		// passed previously, making context-aware config changes impossible.
		return (array) apply_filters( 'zymarg_render_config', $config, $context );
	}

	// -------------------------------------------------------------------------
	// Merge helpers
	// -------------------------------------------------------------------------

	/**
	 * Deep-merge $overlay onto $base for DEEP_MERGE_KEYS sections.
	 * Top-level keys not in DEEP_MERGE_KEYS are replaced outright.
	 *
	 * @param array $base    Lower-priority config.
	 * @param array $overlay Higher-priority config.
	 * @return array Merged result.
	 */
	private static function deep_merge( array $base, array $overlay ): array {
		foreach ( $overlay as $key => $value ) {
			if ( in_array( $key, self::DEEP_MERGE_KEYS, true ) && is_array( $value ) && isset( $base[ $key ] ) && is_array( $base[ $key ] ) ) {
				$base[ $key ] = array_merge( $base[ $key ], $value );
			} else {
				$base[ $key ] = $value;
			}
		}
		return $base;
	}

	// -------------------------------------------------------------------------
	// Responsive inheritance
	// -------------------------------------------------------------------------

	/**
	 * Resolve responsive inheritance.
	 *
	 * Inheritance chain: desktop → tablet → mobile.
	 *
	 * Each breakpoint in $config['responsive'] contains only the keys that
	 * differ from its parent. After resolution, each breakpoint contains a
	 * complete flat config so the renderer never needs to walk the chain.
	 *
	 * Only 'layout' and 'card' keys are inherited — 'query' and 'responsive'
	 * itself are desktop-only concepts.
	 *
	 * @param array $config Merged config before responsive resolution.
	 * @return array Config with each breakpoint fully resolved.
	 */
	private static function resolve_responsive( array $config ): array {
		$inheritable = [ 'layout', 'card' ];

		// Build the desktop base (only the inheritable sections).
		$desktop = [];
		foreach ( $inheritable as $section ) {
			if ( isset( $config[ $section ] ) && is_array( $config[ $section ] ) ) {
				$desktop[ $section ] = $config[ $section ];
			}
		}

		// Tablet inherits desktop, then applies its own overrides.
		$tablet_overrides = $config['responsive']['tablet'] ?? [];
		$tablet           = self::inherit_breakpoint( $desktop, $tablet_overrides, $inheritable );

		// Mobile inherits tablet (already resolved), then applies its own overrides.
		$mobile_overrides = $config['responsive']['mobile'] ?? [];
		$mobile           = self::inherit_breakpoint( $tablet, $mobile_overrides, $inheritable );

		$config['responsive']['tablet'] = $tablet;
		$config['responsive']['mobile'] = $mobile;

		return $config;
	}

	/**
	 * Produce a fully resolved breakpoint by merging overrides onto a parent.
	 *
	 * @param array $parent    Already-resolved parent breakpoint config.
	 * @param array $overrides Breakpoint-specific overrides (may be empty).
	 * @param array $sections  Which top-level sections to inherit.
	 * @return array Fully resolved breakpoint config.
	 */
	private static function inherit_breakpoint( array $parent, array $overrides, array $sections ): array {
		$resolved = $parent; // start from parent (deep copy via value semantics)

		foreach ( $sections as $section ) {
			if ( isset( $overrides[ $section ] ) && is_array( $overrides[ $section ] ) ) {
				$resolved[ $section ] = array_merge(
					$resolved[ $section ] ?? [],
					$overrides[ $section ]
				);
			}
		}

		return $resolved;
	}

	// -------------------------------------------------------------------------
	// Validation
	// -------------------------------------------------------------------------

	/**
	 * Validate and sanitize the merged configuration.
	 *
	 * Rules:
	 *   - Numeric values are clamped to their declared bounds.
	 *   - Enum values are checked against VALID_VALUES; invalid = reset to default.
	 *   - Boolean card flags are cast to bool.
	 *   - String fields are sanitized.
	 *
	 * @param array $config Merged configuration.
	 * @return array Validated configuration.
	 */
	private static function validate( array $config ): array {
		$defaults = Config_Defaults::get();

		// --- Numeric bounds ------------------------------------------------
		foreach ( self::NUMERIC_BOUNDS as $path => $bounds ) {
			[ $section, $key ] = explode( '.', $path, 2 );
			if ( isset( $config[ $section ][ $key ] ) ) {
				$val = (int) $config[ $section ][ $key ];
				$val = max( $bounds[0], $val );
				if ( null !== $bounds[1] ) {
					$val = min( $bounds[1], $val );
				}
				$config[ $section ][ $key ] = $val;
			}
		}

		// --- Enum aliases (v2.11.0) ----------------------------------------
		//
		// The Elementor controls and the engine grew separate vocabularies for
		// three card keys. A value that is perfectly valid at the control was
		// simply not in VALID_VALUES, so the loop below silently reset it to the
		// default and the chosen option did nothing. Only unambiguous synonyms
		// are mapped here; options with no engine equivalent still fall back to
		// the default, which is the pre-2.11.0 behaviour.
		$aliases = [
			'card.discount_badge_mode' => [ 'percent' => 'percentage' ],
			'card.sold_count_format'   => [
				'sold_n'      => 'short',
				'sold_n_plus' => 'short',
				'n_sold'      => 'full',
			],
		];

		foreach ( $aliases as $path => $map ) {
			[ $section, $key ] = explode( '.', $path, 2 );
			if ( isset( $config[ $section ][ $key ] ) && isset( $map[ $config[ $section ][ $key ] ] ) ) {
				$config[ $section ][ $key ] = $map[ $config[ $section ][ $key ] ];
			}
		}

		// --- Enum validation -----------------------------------------------
		foreach ( self::VALID_VALUES as $path => $allowed ) {
			[ $section, $key ] = explode( '.', $path, 2 );
			if ( isset( $config[ $section ][ $key ] ) ) {
				if ( ! in_array( $config[ $section ][ $key ], $allowed, true ) ) {
					// Reset to framework default.
					$config[ $section ][ $key ] = $defaults[ $section ][ $key ] ?? $allowed[0];
				}
			}
		}

		// --- Boolean card flags -------------------------------------------
		$bool_card_keys = [
			'show_image', 'show_title', 'show_price', 'show_rating',
			'show_sold_count', 'show_vendor', 'show_atc', 'show_wishlist',
			'show_quickview', 'show_discount_badge', 'show_stock_badge',
			'show_sold_text', 'show_stock_in', 'show_stock_out',
			'image_full_resolution', 'image_hover_zoom',
		];
		foreach ( $bool_card_keys as $key ) {
			if ( isset( $config['card'][ $key ] ) ) {
				$config['card'][ $key ] = (bool) $config['card'][ $key ];
			}
		}

		// --- Card template validation ------------------------------------
		// Template_Manager owns the registry — Config_Normalizer asks it
		// whether the slug is known rather than inspecting internals directly.
		// Sanitize first, then validate; fall back to 'classic' if unregistered
		// so the renderer always receives a valid slug.
		$card_tpl = sanitize_key( (string) ( $config['card']['template'] ?? 'classic' ) );
		if ( ! \Zymarg\WCPG\Templates\Template_Manager::is_registered_card( $card_tpl ) ) {
			$card_tpl = 'classic';
		}
		$config['card']['template'] = $card_tpl;

		// --- Source sanitization ------------------------------------------
		if ( isset( $config['query']['source'] ) ) {
			$config['query']['source'] = sanitize_key( (string) $config['query']['source'] );
		}

		// --- String sanitization ------------------------------------------
		if ( isset( $config['query']['order'] ) ) {
			$config['query']['order'] = strtoupper( $config['query']['order'] ) === 'ASC' ? 'ASC' : 'DESC';
		}

		// --- Heading: canonicalize view_all_url --------------------------
		// Accept either a plain string URL (standalone plugins, shortcodes,
		// page builders) or an Elementor-style array { url, is_external,
		// nofollow }, and always emit the array shape the wrapper templates
		// read. Before v2.4.0 a plain-string URL silently failed to render
		// because the templates read $settings['view_all_url']['url'].
		if ( isset( $config['heading'] ) && is_array( $config['heading'] ) ) {
			$raw_va = $config['heading']['view_all_url'] ?? '';
			if ( is_array( $raw_va ) ) {
				$va_url = isset( $raw_va['url'] ) ? (string) $raw_va['url'] : '';
				$config['heading']['view_all_url'] = [
					'url'         => '' === $va_url ? '' : esc_url_raw( $va_url ),
					'is_external' => ! empty( $raw_va['is_external'] ),
					'nofollow'    => ! empty( $raw_va['nofollow'] ),
				];
			} else {
				$va_url = (string) $raw_va;
				$config['heading']['view_all_url'] = [
					'url'         => '' === $va_url ? '' : esc_url_raw( $va_url ),
					'is_external' => false,
					'nofollow'    => false,
				];
			}
		}

		// --- Slider sub-config sanitization ------------------------------
		// layout.slider flows through to the slider template via
		// config_to_settings(). Validate here so bad values never reach it.
		if ( isset( $config['layout']['slider'] ) && is_array( $config['layout']['slider'] ) ) {
			$slider = $config['layout']['slider'];
			// v2.14.0: '' is a valid value meaning "no pagination". It has to be
			// allowed through here or validate() would rewrite an intentional
			// off-switch back to the 'bullets' default before the wrapper sees it.
			if ( isset( $slider['pagination_type'] ) && ! in_array( $slider['pagination_type'], [ '', 'bullets', 'progress' ], true ) ) {
				$slider['pagination_type'] = $defaults['layout']['slider']['pagination_type'] ?? 'bullets';
			}
			foreach ( [ 'show_arrows', 'loop', 'autoplay', 'marquee' ] as $bk ) {
				if ( isset( $slider[ $bk ] ) ) {
					$slider[ $bk ] = (bool) $slider[ $bk ];
				}
			}
			foreach ( [ 'autoplay_delay', 'speed', 'space_between' ] as $nk ) {
				if ( isset( $slider[ $nk ] ) ) {
					$slider[ $nk ] = max( 0, (int) $slider[ $nk ] );
				}
			}
			if ( isset( $slider['marquee_speed'] ) ) {
				$slider['marquee_speed'] = max( 500, min( 20000, (int) $slider['marquee_speed'] ) );
			}
			$config['layout']['slider'] = $slider;
		}

		return $config;
	}

	// -------------------------------------------------------------------------
	// Card style defaults (reserved for future card style system)
	// -------------------------------------------------------------------------

	/**
	 * Return card-style-specific defaults for the given style key.
	 *
	 * Today all styles are empty — the framework card defaults apply.
	 * When card styles are introduced, each style will provide its own
	 * partial overrides that sit between framework defaults and the template.
	 *
	 * @param string $style Card style key (e.g. 'default', 'compact', 'premium').
	 * @return array Partial card config for the style, or empty array.
	 */
	private static function get_card_style_defaults( string $style ): array {
		/**
		 * Filter card style defaults.
		 *
		 * Card style plugins register their defaults here.
		 *
		 * Example:
		 *   add_filter( 'zymarg_product_grid_card_style_defaults', function( $defaults, $style ) {
		 *       if ( 'compact' === $style ) {
		 *           return [ 'show_rating' => false, 'show_sold_count' => false ];
		 *       }
		 *       return $defaults;
		 *   }, 10, 2 );
		 *
		 * @since 1.6.0
		 * @param array  $defaults Empty array today; style plugins populate this.
		 * @param string $style    Card style key.
		 */
		return (array) apply_filters( 'zymarg_product_grid_card_style_defaults', [], $style );
	}

	/**
	 * No public construction — static class only.
	 */
	private function __construct() {}
}
