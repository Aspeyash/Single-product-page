<?php
/**
 * Elementor Settings Adapter.
 *
 * THE ONLY CLASS IN THE CODEBASE THAT KNOWS ELEMENTOR CONTROL KEY NAMES.
 *
 * Converts the flat $settings array returned by
 * Widget_Product_Grid::get_settings_for_display() into the canonical
 * six-section config array consumed by Public_API::render().
 *
 * Architectural contract (locked — see ARCHITECTURE.md rule #11):
 *   - Lives in includes/Elementor/ — Elementor-specific, not a framework adapter.
 *   - After Milestone 4 Step 3, Widget_Product_Grid::render() becomes:
 *       $settings = $this->get_settings_for_display();
 *       $config   = Elementor_Settings_Adapter::to_config( $settings );
 *       echo Public_API::render( [ 'config' => $config ] );
 *   - This class knows NOTHING about rendering. It only translates.
 *   - The Render_Engine's config_to_settings() shim is the opposite
 *     direction (canonical → flat legacy). Once all templates migrate to
 *     $config, the shim is removed but this adapter remains.
 *
 * Responsive controls:
 *   Elementor adds device-suffixed keys for add_responsive_control() calls.
 *   Desktop: the bare key (e.g. 'columns').
 *   Tablet:  key + '_tablet' (e.g. 'columns_tablet').
 *   Mobile:  key + '_mobile' (e.g. 'columns_mobile').
 *   We read all three and build the responsive section explicitly.
 *
 * Switcher controls:
 *   Elementor stores 'yes' for on, '' (empty string) for off.
 *   We normalise to PHP bool throughout.
 *
 * ICONS controls:
 *   Stored as [ 'value' => 'fas fa-plus', 'library' => 'fa-solid' ].
 *   We pass the array through unchanged; the template renders it via
 *   \Elementor\Icons_Manager::render_icon().
 *
 * URL controls:
 *   Stored as [ 'url' => '...', 'is_external' => bool, 'nofollow' => bool ].
 *   We pass the array through unchanged.
 *
 * Style controls (typography, colors, selectors):
 *   These are Elementor's own CSS generation pipeline — they are NOT part
 *   of the canonical config and are NOT translated here. Elementor handles
 *   them automatically via get_unique_selector() and the page builder's
 *   stylesheet engine.
 *
 * @package Zymarg\WCPG\Elementor
 * @since   1.6.5
 */

namespace Zymarg\WCPG\Elementor;

defined( 'ABSPATH' ) || exit;

/**
 * Class Elementor_Settings_Adapter
 */
final class Elementor_Settings_Adapter {

	// -------------------------------------------------------------------------
	// Public API
	// -------------------------------------------------------------------------

	/**
	 * Convert a Widget_Product_Grid $settings array to a canonical config array.
	 *
	 * @param  array $settings From Widget_Product_Grid::get_settings_for_display().
	 * @return array           Canonical config. Pass directly to Public_API::render().
	 */
	public static function to_config( array $settings ): array {
		return [
			'query'      => self::build_query( $settings ),
			'layout'     => self::build_layout( $settings ),
			'card'       => self::build_card( $settings ),
			'heading'    => self::build_heading( $settings ),
			'pagination' => self::build_pagination( $settings ),
			'responsive' => self::build_responsive( $settings ),
		];
	}

	// -------------------------------------------------------------------------
	// Section builders
	// -------------------------------------------------------------------------

	/**
	 * Build the 'query' section.
	 *
	 * Source key is 1:1.
	 * 'total_products' → 'limit'.
	 * 'orderby' / 'order' are 1:1.
	 * 'show_oos' SWITCHER → bool.
	 * Include/exclude IDs arrive as comma-separated strings → int[].
	 * Include/exclude categories arrive as int[] already (SELECT2 multiple).
	 * All source-specific keys are collected into 'source_args'.
	 *
	 * @param array $s Settings.
	 * @return array
	 */
	private static function build_query( array $s ): array {
		$query = [
			'source'   => self::str( $s, 'source', 'all' ),
			'limit'    => self::int( $s, 'total_products', 8 ),
			'orderby'  => self::str( $s, 'orderby', 'date' ),
			'order'    => self::str( $s, 'order', 'DESC' ),
			'show_oos' => self::switcher( $s, 'show_oos' ),

			// Include / exclude product IDs (TEXT control — comma-separated).
			'include_products'   => self::csv_to_int_array( $s, 'include_products' ),
			'exclude_products'   => self::csv_to_int_array( $s, 'exclude_products' ),

			// Include / exclude categories (SELECT2 multiple — already an int[]).
			'include_categories' => self::int_array( $s, 'include_categories' ),
			'exclude_categories' => self::int_array( $s, 'exclude_categories' ),

			// Vendor Category Filter pairing (source = current_vendor only).
			'filter_group_id'    => self::str( $s, 'filter_group_id', '' ),
		];

		// Merge source-specific args so Query_Adapter can pass them through
		// to Query_Builder without this adapter knowing their names.
		$query['source_args'] = self::build_source_args( $s, $query['source'] );

		return $query;
	}

	/**
	 * Build the 'layout' section.
	 *
	 * 'layout_type' → 'type'.
	 * 'columns' is desktop-only here; responsive values live in 'responsive'.
	 * 'gap' has no Elementor control — carry the Config_Defaults value (6).
	 *
	 * @param array $s Settings.
	 * @return array
	 */
	private static function build_layout( array $s ): array {
		return [
			'type'    => self::str( $s, 'layout_type', 'grid' ),
			'columns' => self::int( $s, 'columns', 4 ),
			'gap'     => 6, // No Elementor control; Config_Defaults owns this value.

			// Slider-specific keys. The Render_Engine / slider template reads
			// these from the flat $settings shim today; after templates migrate
			// to $config we can move them here permanently.
			'slider' => self::build_slider_args( $s ),
		];
	}

	/**
	 * Build the 'card' section.
	 *
	 * All keys are 1:1 with the Elementor control names EXCEPT:
	 *   - meta_layout: this is a responsive control; desktop value goes here,
	 *     tablet/mobile go in 'responsive'.
	 *   - show_sold_text: also responsive — desktop here, devices in responsive.
	 *   - discount_badge_mode: 'percent' in Elementor → 'percentage' in schema.
	 *   - sold_count_format: values differ ('sold_n' / 'n_sold' / 'sold_n_plus'
	 *     in Elementor vs 'short' / 'full' in schema). We map to schema values.
	 *
	 * @param array $s Settings.
	 * @return array
	 */
	private static function build_card( array $s ): array {
		return [
			'style' => 'default', // No Elementor control; reserved for Milestone 6.

			// ---- Card template (v2.2.0) ----
			// Until 2.2.0 the widget had no card template control at all, so
			// this key was never set and the widget always rendered 'classic'
			// regardless of which templates were registered. Config_Normalizer
			// validates the slug against Template_Manager::is_registered_card()
			// and falls back to 'classic' if it is unknown, so a saved widget
			// keeps working after its template plugin is deactivated.
			'template'            => self::str( $s, 'card_template', 'classic' ),

			// ---- Visibility ----
			'show_image'          => self::switcher( $s, 'show_image', true ),
			'show_title'          => self::switcher( $s, 'show_title', true ),
			'show_price'          => self::switcher( $s, 'show_price', true ),
			'show_rating'         => self::switcher( $s, 'show_rating', true ),
			'show_sold_count'     => self::switcher( $s, 'show_sold_count' ),
			'show_vendor'         => self::switcher( $s, 'show_vendor' ),
			'show_atc'            => self::switcher( $s, 'show_atc', true ),
			'show_wishlist'       => self::switcher( $s, 'show_wishlist', true ),
			'show_quickview'      => self::switcher( $s, 'show_quickview', true ),
			'show_discount_badge' => self::switcher( $s, 'show_discount_badge', true ),
			'show_stock_badge'    => self::switcher( $s, 'show_stock_badge', true ),
			'show_stock_in'       => self::switcher( $s, 'show_stock_in' ),
			'show_stock_out'      => self::switcher( $s, 'show_stock_out', true ),

			// show_sold_text is responsive — desktop value here.
			'show_sold_text'      => self::switcher( $s, 'show_sold_text', true ),

			// ---- Positioning ----
			'price_position'      => self::str( $s, 'price_position', 'below_rating' ),
			'vendor_position'     => self::str( $s, 'vendor_position', 'below_price' ),
			'atc_position'        => self::str( $s, 'atc_position', 'with_price' ),

			// meta_layout is responsive — desktop value here.
			'meta_layout'         => self::str( $s, 'meta_layout', 'stacked' ),

			// Countdown timer (v2.9.0). 'auto' keeps it to the Flash Deals source.
			'show_countdown'      => self::str( $s, 'show_countdown', 'auto' ),
			'countdown_position'  => self::str( $s, 'countdown_position', 'below_price' ),

			// ---- Display / typography ----
			'title_lines'         => self::int( $s, 'title_lines', 2 ),
			'sold_count_format'   => self::map_sold_count_format( self::str( $s, 'sold_count_format', 'sold_n' ) ),
			'discount_badge_mode' => self::map_discount_badge_mode( self::str( $s, 'discount_badge_mode', 'percent' ) ),

			// ---- Image ----
			'image_full_resolution' => self::switcher( $s, 'image_full_resolution' ),
			'image_hover_zoom'      => self::switcher( $s, 'image_hover_zoom', true ),

			// ---- Icon payloads (ICONS controls — passed through as-is) ----
			'wishlist_icon'           => self::icons( $s, 'wishlist_icon', 'far fa-heart' ),
			'wishlist_icon_active'    => self::icons( $s, 'wishlist_icon_active', 'fas fa-heart' ),
			'quickview_icon'          => self::icons( $s, 'quickview_icon', 'far fa-eye' ),
			'atc_icon'                => self::icons( $s, 'atc_icon', 'fas fa-plus' ),

			// ---- Quickview behaviour ----
			'quickview_visibility'    => self::str( $s, 'quickview_visibility', 'desktop' ),
			'quickview_display'       => self::str( $s, 'quickview_display', 'hover_only' ),

			// ---- ATC behaviour ----
			'show_view_cart_link'     => self::switcher( $s, 'show_view_cart_link', true ),
			'atc_transform'           => self::str( $s, 'atc_transform', 'none' ),

			// ---- Vendor display ----
			'vendor_display'          => self::str( $s, 'vendor_display', 'avatar_name' ),
			'vendor_link'             => self::switcher( $s, 'vendor_link', true ),
			'vendor_avatar_shape'     => self::str( $s, 'vendor_avatar_shape', 'circle' ),
			'vendor_avatar_side'      => self::str( $s, 'vendor_avatar_side', 'left' ),
			'vendor_avatar_border'    => self::switcher( $s, 'vendor_avatar_border' ),

			// ---- Empty state ----
			'empty_message'           => self::str( $s, 'empty_message', '' ),
		];
	}

	/**
	 * Build the 'heading' section.
	 *
	 * Control names:
	 *   show_heading     → heading.show
	 *   heading_text     → heading.text
	 *   subheading_text  → heading.subtext
	 *   heading_tag      → heading.tag
	 *   heading_alignment (responsive CHOOSE) → heading.alignment (desktop)
	 *   show_view_all    → heading.show_view_all
	 *   view_all_text    → heading.view_all_text
	 *   view_all_url     (URL control array) → heading.view_all_url
	 *   view_all_auto_vendor → heading.view_all_auto_vendor
	 *
	 * NOTE: heading_alignment is a responsive CHOOSE control. The desktop
	 * value goes here; tablet/mobile values go in responsive (not currently
	 * in schema — heading is excluded from responsive inheritance per rule #6
	 * in ARCHITECTURE.md, but the alignment override per device IS meaningful
	 * and we carry it in the heading section directly, not in responsive).
	 *
	 * @param array $s Settings.
	 * @return array
	 */
	private static function build_heading( array $s ): array {
		$show = self::switcher( $s, 'show_heading', true );

		// view_all_url is an Elementor URL control: array with 'url', 'is_external', 'nofollow'.
		$va_url_raw = $s['view_all_url'] ?? [];
		$va_url     = is_array( $va_url_raw ) ? $va_url_raw : [ 'url' => '', 'is_external' => false, 'nofollow' => false ];

		return [
			'show'                 => $show,
			'text'                 => self::str( $s, 'heading_text', '' ),
			'subtext'              => self::str( $s, 'subheading_text', '' ),
			'tag'                  => self::str( $s, 'heading_tag', 'h2' ),
			'alignment'            => self::str( $s, 'heading_alignment', 'left' ),
			'alignment_tablet'     => self::str( $s, 'heading_alignment_tablet', '' ),
			'alignment_mobile'     => self::str( $s, 'heading_alignment_mobile', '' ),
			'show_view_all'        => self::switcher( $s, 'show_view_all' ),
			'view_all_text'        => self::str( $s, 'view_all_text', '' ),
			'view_all_url'         => $va_url,
			'view_all_auto_vendor' => self::switcher( $s, 'view_all_auto_vendor', true ),
			'view_all_vendor_product_id' => self::resolve_view_all_vendor_pid( $s ),
		];
	}

	/**
	 * Resolve the explicit product id for the vendor "View All" auto-URL.
	 *
	 * Mirrors the vendor source's product-context controls so the engine
	 * (Public_API) resolves the same vendor for the link as for the grid.
	 * Returns the manual vendor_product_id when auto-detect is off; otherwise
	 * 0, which tells the engine to auto-detect the current product.
	 *
	 * @param array $s Settings.
	 * @return int
	 */
	private static function resolve_view_all_vendor_pid( array $s ): int {
		if ( self::switcher( $s, 'vendor_auto_detect', true ) ) {
			return 0;
		}
		return max( 0, (int) self::int( $s, 'vendor_product_id', 0 ) );
	}

	/**
	 * Build the 'pagination' section.
	 *
	 * The Elementor controls are named 'pagination_mode' and 'load_more_text'
	 * (registered in trait-controls-layout.php inside section_layout).
	 * In the canonical schema they live under the 'pagination' section.
	 *
	 * @param array $s Settings.
	 * @return array
	 */
	private static function build_pagination( array $s ): array {
		return [
			'mode'           => self::str( $s, 'pagination_mode', 'none' ),
			'load_more_text' => self::str( $s, 'load_more_text', '' ),

			// v2.6.0: Infinite scroll batch sizes and auto-load caps. Not part
			// of the responsive pipeline (pagination is excluded by design);
			// the browser picks the right pair from viewport width.
			'batch_size'          => self::int( $s, 'infinite_batch_size', 20 ),
			'batch_size_tablet'   => self::int( $s, 'infinite_batch_size_tablet', 20 ),
			'batch_size_mobile'   => self::int( $s, 'infinite_batch_size_mobile', 10 ),
			'max_products'        => self::int( $s, 'infinite_max_products', 100 ),
			'max_products_tablet' => self::int( $s, 'infinite_max_products_tablet', 100 ),
			'max_products_mobile' => self::int( $s, 'infinite_max_products_mobile', 50 ),
		];
	}

	/**
	 * Build the 'responsive' section.
	 *
	 * Only 'layout' and 'card' participate in responsive inheritance
	 * (ARCHITECTURE.md rule #6: heading and pagination are excluded).
	 *
	 * Responsive Elementor controls use device-suffixed keys:
	 *   desktop → bare key (already in 'layout' / 'card' sections)
	 *   tablet  → key + '_tablet'
	 *   mobile  → key + '_mobile'
	 *
	 * We populate tablet/mobile ONLY with the keys that actually have
	 * a responsive control in the widget. Unknown or empty values are
	 * omitted so Config_Normalizer's inheritance cascade can fill them.
	 *
	 * Responsive controls in the widget:
	 *   Layout:  columns, (gap has no responsive control)
	 *   Card:    meta_layout, show_sold_text
	 *
	 * @param array $s Settings.
	 * @return array
	 */
	private static function build_responsive( array $s ): array {
		$responsive = [
			'tablet' => [
				'layout' => [],
				'card'   => [],
			],
			'mobile' => [
				'layout' => [],
				'card'   => [],
			],
		];

		// ---- Layout: columns ----
		$cols_tablet = self::raw( $s, 'columns_tablet' );
		$cols_mobile = self::raw( $s, 'columns_mobile' );

		if ( $cols_tablet !== null && $cols_tablet !== '' ) {
			$responsive['tablet']['layout']['columns'] = (int) $cols_tablet;
		}
		if ( $cols_mobile !== null && $cols_mobile !== '' ) {
			$responsive['mobile']['layout']['columns'] = (int) $cols_mobile;
		}

		// ---- Card: meta_layout ----
		// Defaults from trait: tablet 'inline', mobile 'count_indicator'.
		$ml_tablet = self::raw( $s, 'meta_layout_tablet' );
		$ml_mobile = self::raw( $s, 'meta_layout_mobile' );

		if ( $ml_tablet !== null && $ml_tablet !== '' ) {
			$responsive['tablet']['card']['meta_layout'] = (string) $ml_tablet;
		}
		if ( $ml_mobile !== null && $ml_mobile !== '' ) {
			$responsive['mobile']['card']['meta_layout'] = (string) $ml_mobile;
		}

		// ---- Card: show_sold_text ----
		// Defaults from trait: tablet 'yes', mobile '' (off).
		$sst_tablet = self::raw( $s, 'show_sold_text_tablet' );
		$sst_mobile = self::raw( $s, 'show_sold_text_mobile' );

		if ( $sst_tablet !== null ) {
			$responsive['tablet']['card']['show_sold_text'] = ( 'yes' === $sst_tablet );
		}
		if ( $sst_mobile !== null ) {
			$responsive['mobile']['card']['show_sold_text'] = ( 'yes' === $sst_mobile );
		}

		return $responsive;
	}

	// -------------------------------------------------------------------------
	// Source-specific args builder
	// -------------------------------------------------------------------------

	/**
	 * Collect all source-specific knobs into a flat 'source_args' array.
	 *
	 * The Query_Adapter passes source_args keys directly to Query_Builder's
	 * settings array, so they MUST use the same key names as the legacy
	 * $settings array the source classes read. Since the source classes were
	 * written to read those keys from the raw Elementor $settings, the key
	 * names here ARE the Elementor control names.
	 *
	 * We switch on $source so only relevant keys are included, avoiding
	 * cross-contamination between sources. Keys that are shared across
	 * multiple sources (e.g. vendor_order_by) appear in each relevant branch.
	 *
	 * @param array  $s      Settings.
	 * @param string $source Canonical source slug.
	 * @return array
	 */
	private static function build_source_args( array $s, string $source ): array {
		switch ( $source ) {

			// ----------------------------------------------------------------
			// all / featured / best_selling / algolia / category
			// (no extra knobs beyond the shared query section)
			// ----------------------------------------------------------------
			case 'all':
			case 'featured':
			case 'best_selling':
			case 'algolia':
				return [];

			// ----------------------------------------------------------------
			// flash_deals — ordering, minimum discount, vendor scoping (v2.8.0)
			// ----------------------------------------------------------------
			case 'flash_deals':
				return [
					'flash_orderby'      => self::str( $s, 'flash_orderby', 'sale_end' ),
					'flash_min_discount' => self::int( $s, 'flash_min_discount', 0 ),
					'flash_vendor_scope' => self::str( $s, 'flash_vendor_scope', 'auto' ),
				];

			// ----------------------------------------------------------------
			// category — orderby + subcategory + shop behavior
			// ----------------------------------------------------------------
			case 'category':
				return [
					'cat_include_subcategories' => self::switcher( $s, 'cat_include_subcategories', true ),
					'cat_shop_behavior'         => self::str( $s, 'cat_shop_behavior', 'all' ),
					'cat_orderby'               => self::str( $s, 'cat_orderby', 'popularity' ),
				];

			// ----------------------------------------------------------------
			// trending — window + weights + sampling
			// ----------------------------------------------------------------
			case 'trending':
				return [
					'trending_window'     => (int) self::str( $s, 'trending_window', '7' ),
					'trending_w_sales'    => self::slider_size( $s, 'trending_w_sales', 50 ),
					'trending_w_engagement' => self::slider_size( $s, 'trending_w_engagement', 30 ),
					'trending_w_recency'  => self::slider_size( $s, 'trending_w_recency', 20 ),
					'trending_sampling'   => self::switcher( $s, 'trending_sampling' ),
					'trending_sampling_n' => self::int( $s, 'trending_sampling_n', 10 ),
				];

			// ----------------------------------------------------------------
			// dynamic — weights + refresh
			// ----------------------------------------------------------------
			case 'dynamic':
				return [
					'dynamic_w_recency' => self::slider_size( $s, 'dynamic_w_recency', 60 ),
					'dynamic_w_rating'  => self::slider_size( $s, 'dynamic_w_rating', 30 ),
					'dynamic_w_sales'   => self::slider_size( $s, 'dynamic_w_sales', 10 ),
					'dynamic_refresh'   => self::str( $s, 'dynamic_refresh', 'hour' ),
				];

			// ----------------------------------------------------------------
			// recommended — 5 weights + 4 behaviour controls
			// ----------------------------------------------------------------
			case 'recommended':
				return [
					'recommended_w_category'       => self::slider_size( $s, 'recommended_w_category', 40 ),
					'recommended_w_purchase'       => self::slider_size( $s, 'recommended_w_purchase', 30 ),
					'recommended_w_brand'          => self::slider_size( $s, 'recommended_w_brand', 15 ),
					'recommended_w_seller'         => self::slider_size( $s, 'recommended_w_seller', 10 ),
					'recommended_w_trending'       => self::slider_size( $s, 'recommended_w_trending', 5 ),
					'recommended_recency_penalty'  => self::switcher( $s, 'recommended_recency_penalty', true ),
					'recommended_vendor_cap'       => self::int( $s, 'recommended_vendor_cap', 3 ),
					'recommended_exclude_purchased' => self::switcher( $s, 'recommended_exclude_purchased', true ),
					'recommended_cold_start'       => self::str( $s, 'recommended_cold_start', 'hybrid' ),
				];

			// ----------------------------------------------------------------
			// similar — strictness + price tolerance + preferences + product ID
			// ----------------------------------------------------------------
			case 'similar':
				return [
					'similar_strictness'       => self::str( $s, 'similar_strictness', 'balanced' ),
					'similar_price_tolerance'  => self::str( $s, 'similar_price_tolerance', '25' ),
					'similar_prefer_in_stock'  => self::switcher( $s, 'similar_prefer_in_stock', true ),
					'similar_prefer_recent'    => self::switcher( $s, 'similar_prefer_recent', true ),
					'similar_auto_detect'      => self::switcher( $s, 'similar_auto_detect', true ),
					'similar_product_id'       => self::int( $s, 'similar_product_id', 0 ),
				];

			// ----------------------------------------------------------------
			// vendor (More From Seller / Dokan)
			// ----------------------------------------------------------------
			case 'vendor':
				return [
					'vendor_order_by'     => self::str( $s, 'vendor_order_by', 'rating' ),
					'vendor_in_stock'     => self::switcher( $s, 'vendor_in_stock', true ),
					'vendor_auto_detect'  => self::switcher( $s, 'vendor_auto_detect', true ),
					'vendor_product_id'   => self::int( $s, 'vendor_product_id', 0 ),
				];

			// ----------------------------------------------------------------
			// current_vendor (Dokan store page)
			// ----------------------------------------------------------------
			case 'current_vendor':
				return [
					'current_vendor_subset'          => self::str( $s, 'current_vendor_subset', 'all' ),
					'current_vendor_include_staff'   => self::switcher( $s, 'current_vendor_include_staff', true ),
				];

			// ----------------------------------------------------------------
			// recent (Recently Viewed)
			// ----------------------------------------------------------------
			case 'recent':
				return [
					'recent_empty_mode' => self::str( $s, 'recent_empty_mode', 'message' ),
				];

			// ----------------------------------------------------------------
			// wishlist
			// ----------------------------------------------------------------
			case 'wishlist':
				return [
					'wishlist_empty_mode' => self::str( $s, 'wishlist_empty_mode', 'message' ),
				];

			default:
				return [];
		}
	}

	/**
	 * Build slider args for layout.slider sub-array.
	 *
	 * The current slider template reads these directly from the flat $settings
	 * shim. Once templates migrate to $config, the Render_Engine can read
	 * $config['layout']['slider'] instead of the shim. No behaviour change yet.
	 *
	 * @param array $s Settings.
	 * @return array
	 */
	private static function build_slider_args( array $s ): array {
		return [
			'autoplay'          => self::switcher( $s, 'slider_autoplay' ),
			'autoplay_delay'    => self::int( $s, 'slider_autoplay_delay', 4000 ),
			'loop'              => self::switcher( $s, 'slider_loop', true ),
			'speed'             => self::int( $s, 'slider_speed', 500 ),
			'show_arrows'       => self::switcher( $s, 'slider_show_arrows', true ),
			'arrow_prev'        => self::icons( $s, 'slider_arrow_prev', 'fas fa-chevron-left' ),
			'arrow_next'        => self::icons( $s, 'slider_arrow_next', 'fas fa-chevron-right' ),
			'pagination_type'   => self::str( $s, 'slider_pagination_type', 'bullets' ),
			// v2.4.4: pass null when the Elementor control is empty so the slider
			// inherits the grid gap; an explicit value still wins.
			'space_between'     => ( array_key_exists( 'slider_space_between', $s ) && '' !== $s['slider_space_between'] && null !== $s['slider_space_between'] ) ? (int) $s['slider_space_between'] : null,
			// v2.5.0: smooth free-mode scroll + mouse-wheel. Default ON for both templates.
			'free_scroll'       => self::switcher( $s, 'slider_free_scroll', true ),
			'mousewheel'        => self::switcher( $s, 'slider_mousewheel', true ),
		];
	}

	// -------------------------------------------------------------------------
	// Value-type helpers
	// -------------------------------------------------------------------------

	/**
	 * Read a raw value without coercion. Returns null when key is absent.
	 *
	 * @param array  $s   Settings.
	 * @param string $key Control key.
	 * @return mixed|null
	 */
	private static function raw( array $s, string $key ) {
		return array_key_exists( $key, $s ) ? $s[ $key ] : null;
	}

	/**
	 * Read a string value.
	 *
	 * @param array  $s       Settings.
	 * @param string $key     Control key.
	 * @param string $default Fallback.
	 * @return string
	 */
	private static function str( array $s, string $key, string $default = '' ): string {
		$v = $s[ $key ] ?? null;
		return ( $v !== null && $v !== '' ) ? (string) $v : $default;
	}

	/**
	 * Read an integer value.
	 *
	 * @param array  $s       Settings.
	 * @param string $key     Control key.
	 * @param int    $default Fallback.
	 * @return int
	 */
	private static function int( array $s, string $key, int $default = 0 ): int {
		$v = $s[ $key ] ?? null;
		return ( $v !== null && $v !== '' ) ? (int) $v : $default;
	}

	/**
	 * Normalise a SWITCHER control to bool.
	 *
	 * Elementor stores 'yes' for on and '' (empty string) for off.
	 * When the key is absent, $default is returned.
	 *
	 * @param array  $s       Settings.
	 * @param string $key     Control key.
	 * @param bool   $default Fallback when key is absent.
	 * @return bool
	 */
	private static function switcher( array $s, string $key, bool $default = false ): bool {
		if ( ! array_key_exists( $key, $s ) ) {
			return $default;
		}
		return 'yes' === $s[ $key ];
	}

	/**
	 * Read a SLIDER control's 'size' field.
	 *
	 * Elementor stores slider values as [ 'size' => N, 'unit' => 'px' ].
	 *
	 * @param array  $s       Settings.
	 * @param string $key     Control key.
	 * @param int    $default Fallback.
	 * @return int
	 */
	private static function slider_size( array $s, string $key, int $default = 0 ): int {
		$v = $s[ $key ] ?? null;
		if ( is_array( $v ) && isset( $v['size'] ) ) {
			return (int) $v['size'];
		}
		return $default;
	}

	/**
	 * Read an ICONS control.
	 *
	 * Elementor stores ICONS as [ 'value' => 'class-string', 'library' => 'fa-solid' ].
	 * We pass the array through unchanged. The template renders via
	 * \Elementor\Icons_Manager::render_icon( $icon_array ).
	 *
	 * @param array  $s             Settings.
	 * @param string $key           Control key.
	 * @param string $default_value Fallback icon class string.
	 * @return array
	 */
	private static function icons( array $s, string $key, string $default_value = '' ): array {
		$v = $s[ $key ] ?? null;
		if ( is_array( $v ) && ! empty( $v['value'] ) ) {
			return $v;
		}
		// Return a minimal icons array so templates don't have to type-check.
		return [ 'value' => $default_value, 'library' => '' ];
	}

	/**
	 * Parse a comma-separated string of product IDs to a sanitised int[].
	 *
	 * @param array  $s   Settings.
	 * @param string $key Control key.
	 * @return int[]
	 */
	private static function csv_to_int_array( array $s, string $key ): array {
		$raw = $s[ $key ] ?? '';
		if ( ! is_string( $raw ) || '' === trim( $raw ) ) {
			return [];
		}
		return array_values(
			array_filter(
				array_map( 'intval', explode( ',', $raw ) ),
				static fn( int $id ) => $id > 0
			)
		);
	}

	/**
	 * Read a SELECT2 multiple control value as a sanitised int[].
	 *
	 * Elementor stores SELECT2 multiple as an array of values (already cast
	 * to string keys from the options array). We cast each to int.
	 *
	 * @param array  $s   Settings.
	 * @param string $key Control key.
	 * @return int[]
	 */
	private static function int_array( array $s, string $key ): array {
		$v = $s[ $key ] ?? [];
		if ( ! is_array( $v ) ) {
			return [];
		}
		return array_values(
			array_filter(
				array_map( 'intval', $v ),
				static fn( int $id ) => $id > 0
			)
		);
	}

	// -------------------------------------------------------------------------
	// Enum-value mapping helpers
	// -------------------------------------------------------------------------

	/**
	 * Map the Elementor 'discount_badge_mode' value to the canonical schema value.
	 *
	 * Elementor control options: 'percent' | 'amount' | 'both'
	 * Canonical schema values:   'percentage' | 'amount' | 'both'
	 *
	 * The Elementor key is 'percent'; the schema uses the full word 'percentage'.
	 *
	 * @param string $v Elementor value.
	 * @return string   Canonical value.
	 */
	private static function map_discount_badge_mode( string $v ): string {
		return 'percent' === $v ? 'percentage' : $v;
	}

	/**
	 * Map the Elementor 'sold_count_format' value to the canonical schema value.
	 *
	 * Elementor control options: 'sold_n' | 'n_sold' | 'sold_n_plus'
	 * Canonical schema values:   'short'  | 'full'
	 *
	 * The Elementor options are richer than the two canonical buckets; we map:
	 *   'sold_n'      → 'short'  (the default compact format)
	 *   'n_sold'      → 'full'   (alternate full format)
	 *   'sold_n_plus' → 'short'  (still a short/compact presentation)
	 *
	 * We also store the original Elementor value as 'sold_count_format_variant'
	 * in card so the template can distinguish 'sold_n' from 'sold_n_plus'
	 * without breaking the schema contract. See note below.
	 *
	 * NOTE: The canonical schema currently defines only 'short' | 'full'.
	 * When the schema is extended to include 'sold_n_plus' as a first-class
	 * value, this map can be simplified to a passthrough.
	 *
	 * @param string $v Elementor value.
	 * @return string   Canonical value.
	 */
	private static function map_sold_count_format( string $v ): string {
		return match ( $v ) {
			'n_sold' => 'full',
			default  => 'short',  // 'sold_n' and 'sold_n_plus' both map to 'short'
		};
	}
}
