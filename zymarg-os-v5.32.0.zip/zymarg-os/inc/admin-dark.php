<?php
/**
 * wp-admin colour scheme policy.
 *
 * wp-admin is pinned to LIGHT, on purpose.
 *
 * WordPress core chrome (body background, list tables, metaboxes, form
 * fields) is core CSS that a theme does not own. Loading dark tokens in
 * admin turned plugin text light while core stayed light grey, which made
 * text unreadable. A partial dark mode is worse than none, so rather than
 * half-applying it we pin admin to light and leave the front end alone.
 *
 * The front end is completely unaffected: this filter only runs in admin.
 *
 * Want a dark wp-admin today? Users -> Your Profile -> Admin Color Scheme
 * -> Midnight. That is core-maintained and complete.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Force the light scheme inside wp-admin only.
 *
 * @param string $scheme Configured scheme.
 * @return string
 */
if ( ! function_exists( 'zymarg_os_force_light_admin' ) ) {
	function zymarg_os_force_light_admin( $scheme ) {
		return is_admin() ? 'light' : $scheme;
	}
}
add_filter( 'zymarg_os_color_scheme', 'zymarg_os_force_light_admin', 99 );

/**
 * Load the LIGHT colour tokens in wp-admin, plus the shared screen chrome.
 *
 * tokens/dark.css is deliberately NOT loaded here.
 *
 * @return void
 */
if ( ! function_exists( 'zymarg_os_admin_screen_assets' ) ) {
	function zymarg_os_admin_screen_assets() {
		$ver = defined( 'ZYMARG_OS_VERSION' ) ? ZYMARG_OS_VERSION : false;

		wp_enqueue_style(
			'zymarg-os-token-colors',
			ZYMARG_OS_URI . '/tokens/colors.css',
			array(),
			$ver
		);

		wp_enqueue_style(
			'zymarg-os-admin-screens',
			ZYMARG_OS_URI . '/assets/css/admin-screens.css',
			array( 'zymarg-os-token-colors' ),
			$ver
		);

		/*
		 * Sidebar width. Bumps desktop from core's 160px to 190px so long
		 * plugin labels ("Connection Engine", "Login & Security", any
		 * future ZYMARG plugin) sit on one line -- matching what WP core
		 * already does on the responsive mobile drawer. No token
		 * dependency: the file only overrides width and margin-left. See
		 * assets/css/admin-sidebar.css for the full note.
		 */
		wp_enqueue_style(
			'zymarg-os-admin-sidebar',
			ZYMARG_OS_URI . '/assets/css/admin-sidebar.css',
			array(),
			$ver
		);

		/*
		 * Shared brand tokens (--zym-*).
		 *
		 * The handle is spelled identically in the theme and in every ZYMARG
		 * plugin, so WordPress deduplicates it and exactly one copy loads no
		 * matter how many are active. Guarded with wp_style_is() so whichever
		 * one registers first wins, per "THE SHARED FILES" in the token doc.
		 *
		 * Required in admin: the back-end token block is declared on
		 * .zymarg-admin inside this file, so without it every back-end-only
		 * token resolves to nothing and the screens fall back to the FRONT
		 * END :root values.
		 */
		if ( ! wp_style_is( 'zymarg-tokens', 'registered' ) ) {
			wp_register_style(
				'zymarg-tokens',
				ZYMARG_OS_URI . '/tokens/zymarg-tokens.css',
				array(),
				defined( 'ZYMARG_OS_TOKENS_VERSION' ) ? ZYMARG_OS_TOKENS_VERSION : $ver
			);
		}
		wp_enqueue_style( 'zymarg-tokens' );

		/*
		 * Back end brand layer (sections 2.8, 2.11, 2.14). Loaded AFTER
		 * admin-screens.css via the dependency array so its header and
		 * version-badge rules win the cascade at equal specificity.
		 */
		wp_enqueue_style(
			'zymarg-os-admin-brand',
			ZYMARG_OS_URI . '/assets/css/admin-brand.css',
			array( 'zymarg-tokens', 'zymarg-os-admin-screens' ),
			$ver
		);

		/*
		 * Branded top-level sidebar item (section 2.16).
		 *
		 * Enqueued unconditionally on every admin page, NOT gated on the
		 * theme's own screens: the sidebar exists everywhere, and gating it
		 * is what makes an item look branded only once you are already
		 * inside the plugin.
		 */
		wp_enqueue_style(
			'zymarg-os-admin-menu-brand',
			ZYMARG_OS_URI . '/assets/css/admin-menu-brand.css',
			array( 'zymarg-tokens' ),
			$ver
		);
	}
}
add_action( 'admin_enqueue_scripts', 'zymarg_os_admin_screen_assets' );
