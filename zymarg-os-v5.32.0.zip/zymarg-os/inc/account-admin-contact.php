<?php
/**
 * ZYMARG Account — Admin contact bridge.
 *
 * A number a customer types into their profile is worthless if nobody on the
 * team can see it. Before this file, `zymarg_whatsapp` was user meta and
 * nothing more: invisible in wp-admin, invisible on the order screen, only
 * reachable by someone willing to query the database.
 *
 * This makes it reachable in the three places support actually works from:
 *
 *   1. Users → list table  — a WhatsApp column with one-tap chat.
 *   2. Users → edit user   — full contact panel, editable by admins.
 *   3. WooCommerce order   — chat link beside the billing address.
 *
 * Everything here is capability-gated. A customer never sees these screens,
 * and only roles that can already `edit_users` (or manage orders) get links.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/* ======================================================================
   1. LINK BUILDERS
   ====================================================================== */

/**
 * Build a click-to-chat WhatsApp URL.
 *
 * wa.me needs the number in international format with no plus and no
 * separators, which is exactly why the profile form now stores E.164.
 *
 * @param string $number  Stored number.
 * @param string $message Optional pre-filled message.
 * @return string Empty string when the number is unusable.
 */
function zymarg_os_whatsapp_link( $number, $message = '' ) {
	$digits = function_exists( 'zymarg_os_phone_digits' )
		? zymarg_os_phone_digits( $number )
		: preg_replace( '/\D/', '', (string) $number );

	if ( strlen( $digits ) < 8 ) {
		return '';
	}

	$url = 'https://wa.me/' . $digits;

	if ( '' !== $message ) {
		$url = add_query_arg( 'text', rawurlencode( $message ), $url );
	}

	return $url;
}

/**
 * The default opening message for staff-initiated chats.
 *
 * @param WP_User|null $user Customer.
 * @return string
 */
function zymarg_os_whatsapp_default_message( $user = null ) {
	$first = ( $user instanceof WP_User ) ? $user->first_name : '';
	$first = '' !== $first ? $first : __( 'there', 'zymarg-os' );
	$last  = ( $user instanceof WP_User ) ? $user->last_name : '';

	// The template is editable at ZYMARG OS -> Account & Security. Falling back
	// to the shipped wording keeps this working if the option is missing.
	$template = function_exists( 'zymarg_os_account_setting' )
		? (string) zymarg_os_account_setting( 'whatsapp_message' )
		: '';

	if ( '' === trim( $template ) ) {
		$template = __( 'Hi {first_name}, this is {store} support.', 'zymarg-os' );
	}

	$message = str_replace(
		array( '{first_name}', '{last_name}', '{store}' ),
		array( $first, $last, get_bloginfo( 'name' ) ),
		$template
	);

	$message = trim( preg_replace( '/\s+/', ' ', $message ) );

	/**
	 * Filter the pre-filled WhatsApp message.
	 *
	 * @param string       $message Message text.
	 * @param WP_User|null $user    Customer.
	 */
	return apply_filters( 'zymarg_os_whatsapp_message', $message, $user );
}

/**
 * Render a chat link, or a dash when there is no number.
 *
 * @param int $user_id User ID.
 * @return string HTML.
 */
function zymarg_os_whatsapp_link_html( $user_id ) {
	$number = function_exists( 'zymarg_os_get_whatsapp_number' )
		? zymarg_os_get_whatsapp_number( $user_id )
		: (string) get_user_meta( $user_id, 'zymarg_whatsapp', true );

	if ( '' === $number ) {
		return '<span aria-hidden="true">—</span><span class="screen-reader-text">' . esc_html__( 'No number on file', 'zymarg-os' ) . '</span>';
	}

	$user = get_userdata( $user_id );
	$url  = zymarg_os_whatsapp_link( $number, zymarg_os_whatsapp_default_message( $user ) );

	if ( '' === $url ) {
		return esc_html( $number );
	}

	// Flag numbers saved before validation existed, so staff know why a
	// chat link might fail rather than assuming the customer is unreachable.
	$legacy = ( 0 !== strpos( $number, '+' ) )
		? ' <span title="' . esc_attr__( 'Saved before country codes were required — may be incomplete.', 'zymarg-os' ) . '" style="color:#b45309;">⚠</span>'
		: '';

	return sprintf(
		'<a href="%1$s" target="_blank" rel="noopener noreferrer">%2$s</a>%3$s',
		esc_url( $url ),
		esc_html( $number ),
		$legacy // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from escaped parts above.
	);
}

/* ======================================================================
   2. USERS LIST TABLE COLUMN
   ====================================================================== */

/**
 * Add the WhatsApp column.
 *
 * @param array $columns Existing columns.
 * @return array
 */
function zymarg_os_users_whatsapp_column( $columns ) {
	$columns['zymarg_whatsapp'] = __( 'WhatsApp', 'zymarg-os' );

	return $columns;
}
if ( ! function_exists( 'zymarg_os_account_setting' ) || zymarg_os_account_setting( 'users_column' ) ) {
	add_filter( 'manage_users_columns', 'zymarg_os_users_whatsapp_column' );
}

/**
 * Fill the WhatsApp column.
 *
 * @param string $output      Current output.
 * @param string $column_name Column key.
 * @param int    $user_id     User ID.
 * @return string
 */
function zymarg_os_users_whatsapp_column_content( $output, $column_name, $user_id ) {
	if ( 'zymarg_whatsapp' !== $column_name ) {
		return $output;
	}

	if ( ! current_user_can( 'edit_users' ) ) {
		return $output;
	}

	return zymarg_os_whatsapp_link_html( $user_id );
}
if ( ! function_exists( 'zymarg_os_account_setting' ) || zymarg_os_account_setting( 'users_column' ) ) {
	add_filter( 'manage_users_custom_column', 'zymarg_os_users_whatsapp_column_content', 10, 3 );
}

/* ======================================================================
   3. USER EDIT SCREEN PANEL
   ====================================================================== */

/**
 * Render the contact panel on the user profile screen.
 *
 * @param WP_User $user User being edited.
 * @return void
 */
function zymarg_os_render_admin_contact_panel( $user ) {
	$can_edit = current_user_can( 'edit_user', $user->ID );

	$phone    = (string) get_user_meta( $user->ID, 'billing_phone', true );
	$whatsapp = (string) get_user_meta( $user->ID, 'zymarg_whatsapp', true );
	?>
	<h2><?php esc_html_e( 'ZYMARG contact', 'zymarg-os' ); ?></h2>
	<table class="form-table" role="presentation">
		<tr>
			<th><label for="zymarg_admin_phone"><?php esc_html_e( 'Phone number', 'zymarg-os' ); ?></label></th>
			<td>
				<?php if ( $can_edit ) : ?>
					<input type="tel" name="zymarg_admin_phone" id="zymarg_admin_phone" class="regular-text"
						value="<?php echo esc_attr( $phone ); ?>" placeholder="+880 1712 345678">
					<p class="description"><?php esc_html_e( 'International format, starting with +.', 'zymarg-os' ); ?></p>
				<?php else : ?>
					<?php echo '' !== $phone ? esc_html( $phone ) : '&mdash;'; ?>
				<?php endif; ?>
			</td>
		</tr>
		<tr>
			<th><label for="zymarg_admin_whatsapp"><?php esc_html_e( 'WhatsApp number', 'zymarg-os' ); ?></label></th>
			<td>
				<?php if ( $can_edit ) : ?>
					<input type="tel" name="zymarg_admin_whatsapp" id="zymarg_admin_whatsapp" class="regular-text"
						value="<?php echo esc_attr( $whatsapp ); ?>" placeholder="+880 1712 345678">
				<?php else : ?>
					<?php echo '' !== $whatsapp ? esc_html( $whatsapp ) : '&mdash;'; ?>
				<?php endif; ?>
				<p class="description">
					<?php esc_html_e( 'Chat:', 'zymarg-os' ); ?>
					<?php echo zymarg_os_whatsapp_link_html( $user->ID ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in the builder. ?>
					<br>
					<?php esc_html_e( 'Empty here means we fall back to the phone number above.', 'zymarg-os' ); ?>
				</p>
			</td>
		</tr>
	</table>
	<?php
	wp_nonce_field( 'zymarg_admin_contact', 'zymarg_admin_contact_nonce' );
}
add_action( 'show_user_profile', 'zymarg_os_render_admin_contact_panel' );
add_action( 'edit_user_profile', 'zymarg_os_render_admin_contact_panel' );

/**
 * Save the contact panel.
 *
 * Runs the same validator as the front end. Staff typing a number into
 * wp-admin should not be able to create data the customer's own form would
 * have rejected — one rule, one place.
 *
 * @param int $user_id User being saved.
 * @return void
 */
function zymarg_os_save_admin_contact_panel( $user_id ) {
	if ( ! isset( $_POST['zymarg_admin_contact_nonce'] ) ) {
		return;
	}

	if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['zymarg_admin_contact_nonce'] ) ), 'zymarg_admin_contact' ) ) {
		return;
	}

	if ( ! current_user_can( 'edit_user', $user_id ) ) {
		return;
	}

	$map = array(
		'zymarg_admin_phone'    => 'billing_phone',
		'zymarg_admin_whatsapp' => 'zymarg_whatsapp',
	);

	foreach ( $map as $field => $meta_key ) {
		if ( ! isset( $_POST[ $field ] ) ) {
			continue;
		}

		$raw = trim( (string) wp_unslash( $_POST[ $field ] ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

		if ( '' === $raw ) {
			delete_user_meta( $user_id, $meta_key );
			continue;
		}

		if ( function_exists( 'zymarg_os_validate_phone' ) ) {
			$checked = zymarg_os_validate_phone( $raw );

			// Invalid input is left untouched rather than silently mangled or
			// silently dropped: the old value stays, so nothing is lost.
			if ( is_wp_error( $checked ) ) {
				continue;
			}

			$raw = $checked;
		}

		update_user_meta( $user_id, $meta_key, $raw );
	}
}
add_action( 'personal_options_update', 'zymarg_os_save_admin_contact_panel' );
add_action( 'edit_user_profile_update', 'zymarg_os_save_admin_contact_panel' );

/* ======================================================================
   4. WOOCOMMERCE ORDER SCREEN
   ====================================================================== */

/**
 * Show the chat link beside the billing address on an order.
 *
 * This is where support actually stands when a delivery goes wrong, so this
 * is where the link has to be.
 *
 * @param WC_Order $order Order object.
 * @return void
 */
function zymarg_os_order_whatsapp_link( $order ) {
	if ( ! is_a( $order, 'WC_Order' ) ) {
		return;
	}

	$user_id = $order->get_customer_id();

	if ( ! $user_id ) {
		return;
	}

	$number = function_exists( 'zymarg_os_get_whatsapp_number' )
		? zymarg_os_get_whatsapp_number( $user_id )
		: '';

	if ( '' === $number ) {
		return;
	}

	$user = get_userdata( $user_id );
	$url  = zymarg_os_whatsapp_link( $number, zymarg_os_whatsapp_default_message( $user ) );

	if ( '' === $url ) {
		return;
	}
	?>
	<p class="form-field form-field-wide">
		<strong><?php esc_html_e( 'WhatsApp', 'zymarg-os' ); ?>:</strong>
		<a href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener noreferrer">
			<?php echo esc_html( $number ); ?>
		</a>
	</p>
	<?php
}
add_action( 'woocommerce_admin_order_data_after_billing_address', 'zymarg_os_order_whatsapp_link' );
