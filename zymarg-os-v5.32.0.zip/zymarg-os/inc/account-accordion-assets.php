<?php
/**
 * ZYMARG Account — accordion asset loading.
 *
 * Kept in its own file so the accordion primitive stays pure markup.
 *
 * IMPORTANT — why this is not gated on the current section:
 *
 * The My Account page swaps sections in over AJAX (assets/js/account.js
 * writes `main.innerHTML`). Only the FIRST section is rendered by PHP, so a
 * condition like "only enqueue when the profile section is showing" would
 * leave the CSS and JS missing for every section the customer navigates to
 * afterwards — dead dropdowns and unstyled cards. The whole account page
 * gets these assets, always.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Enqueue the accordion stylesheet and behaviour script.
 *
 * @return void
 */
function zymarg_os_account_accordion_assets() {
	if ( ! function_exists( 'is_account_page' ) || ! is_account_page() ) {
		return;
	}

	$deps = wp_style_is( 'zymarg-tokens', 'registered' ) ? array( 'zymarg-tokens' ) : array();

	wp_enqueue_style(
		'zymarg-os-account-accordion',
		ZYMARG_OS_URI . '/assets/css/account-accordion.css',
		$deps,
		ZYMARG_OS_VERSION
	);

	wp_enqueue_script(
		'zymarg-os-account-accordion',
		ZYMARG_OS_URI . '/assets/js/account-accordion.js',
		array(),
		ZYMARG_OS_VERSION,
		true
	);
}
add_action( 'wp_enqueue_scripts', 'zymarg_os_account_accordion_assets', 30 );