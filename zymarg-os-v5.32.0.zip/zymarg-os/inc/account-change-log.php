<?php
/**
 * Account change log — what changed, when, and who changed it.
 *
 * The security log answers "did they sign in, did the password change". It
 * does not answer the question that actually settles a dispute: "the customer
 * says they never changed that phone number — did they?"
 *
 * This records the before and after of every tracked account field, whoever
 * makes the change. That last part matters: it hooks WordPress's own
 * `profile_update` and user-meta actions rather than the theme's save handler,
 * so a change made in wp-admin by staff, by the customer on the front end, by
 * WooCommerce at checkout, or by another plugin is caught the same way. A log
 * that only records one route is worse than none, because it reads as proof of
 * absence when it is really just a blind spot.
 *
 * Stored in user meta rather than a custom table: it is a short, capped,
 * per-user list that is only ever read for one user at a time, and it travels
 * with the user on export and erase. No schema to migrate, nothing to clean up
 * if the theme is removed.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Meta key holding the log.
 */
if ( ! defined( 'ZYMARG_OS_CHANGE_LOG_META' ) ) {
	define( 'ZYMARG_OS_CHANGE_LOG_META', '_zymarg_change_log' );
}

/* ======================================================================
   1. WHAT WE WATCH
   ====================================================================== */

/**
 * User-table fields worth recording, and how to name them to a human.
 *
 * @return array<string,string>
 */
function zymarg_os_change_log_user_fields() {
	return (array) apply_filters(
		'zymarg_os_change_log_user_fields',
		array(
			'user_email'   => __( 'Email address', 'zymarg-os' ),
			'display_name' => __( 'Display name', 'zymarg-os' ),
			'first_name'   => __( 'First name', 'zymarg-os' ),
			'last_name'    => __( 'Last name', 'zymarg-os' ),
			'user_url'     => __( 'Website', 'zymarg-os' ),
		)
	);
}

/**
 * User meta worth recording.
 *
 * Deliberately a whitelist. Watching everything would fill the log with
 * session tokens, transients and plugin bookkeeping, and bury the three rows
 * anyone actually needs.
 *
 * @return array<string,string>
 */
function zymarg_os_change_log_meta_fields() {
	return (array) apply_filters(
		'zymarg_os_change_log_meta_fields',
		array(
			'billing_phone'      => __( 'Phone number', 'zymarg-os' ),
			'zymarg_whatsapp'    => __( 'WhatsApp number', 'zymarg-os' ),
			'billing_first_name' => __( 'Billing first name', 'zymarg-os' ),
			'billing_last_name'  => __( 'Billing last name', 'zymarg-os' ),
			'billing_email'      => __( 'Billing email', 'zymarg-os' ),
			'billing_address_1'  => __( 'Billing address', 'zymarg-os' ),
			'billing_address_2'  => __( 'Billing address (line 2)', 'zymarg-os' ),
			'billing_city'       => __( 'Billing city', 'zymarg-os' ),
			'billing_state'      => __( 'Billing district', 'zymarg-os' ),
			'billing_postcode'   => __( 'Billing postcode', 'zymarg-os' ),
			'billing_country'    => __( 'Billing country', 'zymarg-os' ),
			'shipping_address_1' => __( 'Shipping address', 'zymarg-os' ),
			'shipping_city'      => __( 'Shipping city', 'zymarg-os' ),
			'shipping_postcode'  => __( 'Shipping postcode', 'zymarg-os' ),
			'zymarg_dob'         => __( 'Date of birth', 'zymarg-os' ),
			'zymarg_gender'      => __( 'Gender', 'zymarg-os' ),
			'zymarg_language'    => __( 'Language', 'zymarg-os' ),
			'zymarg_currency'    => __( 'Currency', 'zymarg-os' ),
			'zymarg_timezone'    => __( 'Timezone', 'zymarg-os' ),
			'_zymarg_avatar_url' => __( 'Profile photo', 'zymarg-os' ),
		)
	);
}

/**
 * How many entries to keep per user.
 *
 * @return int
 */
function zymarg_os_change_log_size() {
	return (int) apply_filters( 'zymarg_os_change_log_size', 200 );
}

/* ======================================================================
   2. WRITING
   ====================================================================== */

/**
 * Record one change.
 *
 * @param int    $user_id User the change belongs to.
 * @param string $field   Field key.
 * @param string $label   Human label.
 * @param mixed  $old     Previous value.
 * @param mixed  $new     New value.
 * @return void
 */
function zymarg_os_log_change( $user_id, $field, $label, $old, $new ) {
	$user_id = (int) $user_id;

	if ( ! $user_id ) {
		return;
	}

	$old = zymarg_os_change_log_scalar( $old );
	$new = zymarg_os_change_log_scalar( $new );

	if ( $old === $new ) {
		return;
	}

	$actor_id = get_current_user_id();

	if ( ! $actor_id ) {
		$actor = 'system';
	} elseif ( $actor_id === $user_id ) {
		$actor = 'self';
	} else {
		$actor = 'staff';
	}

	$entry = array(
		'time'     => current_time( 'mysql', true ),
		'field'    => (string) $field,
		'label'    => (string) $label,
		'old'      => $old,
		'new'      => $new,
		'actor'    => $actor,
		'actor_id' => (int) $actor_id,
		'ip'       => zymarg_os_change_log_ip(),
	);

	/**
	 * Filter an entry before it is stored. Return an empty value to skip it.
	 *
	 * @param array $entry   Log entry.
	 * @param int   $user_id User ID.
	 */
	$entry = apply_filters( 'zymarg_os_change_log_entry', $entry, $user_id );

	if ( empty( $entry ) ) {
		return;
	}

	$log = get_user_meta( $user_id, ZYMARG_OS_CHANGE_LOG_META, true );
	$log = is_array( $log ) ? $log : array();

	// Newest first, so reading the log never needs a sort.
	array_unshift( $log, $entry );

	$log = array_slice( $log, 0, zymarg_os_change_log_size() );

	update_user_meta( $user_id, ZYMARG_OS_CHANGE_LOG_META, $log );
}

/**
 * Flatten a value into something printable and comparable.
 *
 * Arrays and objects are summarised rather than serialised — nobody reading a
 * dispute needs a serialised blob, and storing one would balloon the meta row.
 *
 * @param mixed $value Raw value.
 * @return string
 */
function zymarg_os_change_log_scalar( $value ) {
	if ( is_bool( $value ) ) {
		return $value ? '1' : '';
	}

	if ( is_scalar( $value ) || null === $value ) {
		$value = (string) $value;
		return ( strlen( $value ) > 255 ) ? substr( $value, 0, 255 ) . '…' : $value;
	}

	if ( is_array( $value ) ) {
		/* translators: %d: number of values. */
		return sprintf( _n( '%d value', '%d values', count( $value ), 'zymarg-os' ), count( $value ) );
	}

	return __( '(complex value)', 'zymarg-os' );
}

/**
 * Best-effort client IP.
 *
 * @return string
 */
function zymarg_os_change_log_ip() {
	if ( empty( $_SERVER['REMOTE_ADDR'] ) ) {
		return '';
	}

	$ip = sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) );

	return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '';
}

/* ======================================================================
   3. HOOKS — catching changes from every direction
   ====================================================================== */

/**
 * Diff the user table on update.
 *
 * @param int     $user_id       User ID.
 * @param WP_User $old_user_data User before the update.
 * @return void
 */
function zymarg_os_change_log_user_update( $user_id, $old_user_data ) {
	if ( ! ( $old_user_data instanceof WP_User ) ) {
		return;
	}

	$new = get_userdata( $user_id );

	if ( ! $new ) {
		return;
	}

	foreach ( zymarg_os_change_log_user_fields() as $field => $label ) {
		zymarg_os_log_change(
			$user_id,
			$field,
			$label,
			isset( $old_user_data->$field ) ? $old_user_data->$field : '',
			isset( $new->$field ) ? $new->$field : ''
		);
	}
}
add_action( 'profile_update', 'zymarg_os_change_log_user_update', 10, 2 );

/**
 * Record a tracked meta value being changed.
 *
 * `update_user_meta` fires BEFORE the write, which is the only reliable moment
 * to read the previous value.
 *
 * @param int    $meta_id    Meta row ID (unused).
 * @param int    $user_id    User ID.
 * @param string $meta_key   Meta key.
 * @param mixed  $meta_value Incoming value.
 * @return void
 */
function zymarg_os_change_log_meta_update( $meta_id, $user_id, $meta_key, $meta_value ) {
	$tracked = zymarg_os_change_log_meta_fields();

	if ( ! isset( $tracked[ $meta_key ] ) ) {
		return;
	}

	zymarg_os_log_change(
		$user_id,
		$meta_key,
		$tracked[ $meta_key ],
		get_user_meta( $user_id, $meta_key, true ),
		$meta_value
	);
}
add_action( 'update_user_meta', 'zymarg_os_change_log_meta_update', 10, 4 );

/**
 * Record a tracked meta value being set for the first time.
 *
 * @param int    $meta_id    Meta row ID (unused).
 * @param int    $user_id    User ID.
 * @param string $meta_key   Meta key.
 * @param mixed  $meta_value New value.
 * @return void
 */
function zymarg_os_change_log_meta_added( $meta_id, $user_id, $meta_key, $meta_value ) {
	$tracked = zymarg_os_change_log_meta_fields();

	if ( ! isset( $tracked[ $meta_key ] ) ) {
		return;
	}

	zymarg_os_log_change( $user_id, $meta_key, $tracked[ $meta_key ], '', $meta_value );
}
add_action( 'added_user_meta', 'zymarg_os_change_log_meta_added', 10, 4 );

/**
 * Record a tracked meta value being cleared.
 *
 * @param array  $meta_ids Meta row IDs (unused).
 * @param int    $user_id  User ID.
 * @param string $meta_key Meta key.
 * @return void
 */
function zymarg_os_change_log_meta_deleted( $meta_ids, $user_id, $meta_key ) {
	$tracked = zymarg_os_change_log_meta_fields();

	if ( ! isset( $tracked[ $meta_key ] ) ) {
		return;
	}

	zymarg_os_log_change( $user_id, $meta_key, $tracked[ $meta_key ], get_user_meta( $user_id, $meta_key, true ), '' );
}
add_action( 'delete_user_meta', 'zymarg_os_change_log_meta_deleted', 10, 3 );

/* ======================================================================
   4. READING
   ====================================================================== */

/**
 * Read a user's change log, newest first.
 *
 * @param int $user_id User ID.
 * @param int $limit   Max entries, 0 for all.
 * @return array<int,array>
 */
function zymarg_os_get_change_log( $user_id, $limit = 0 ) {
	$log = get_user_meta( (int) $user_id, ZYMARG_OS_CHANGE_LOG_META, true );
	$log = is_array( $log ) ? $log : array();

	if ( $limit > 0 ) {
		$log = array_slice( $log, 0, (int) $limit );
	}

	return $log;
}

/**
 * Describe who made a change.
 *
 * @param array $entry Log entry.
 * @return string
 */
function zymarg_os_change_log_actor_label( $entry ) {
	$actor = isset( $entry['actor'] ) ? $entry['actor'] : 'system';

	if ( 'self' === $actor ) {
		return __( 'The customer', 'zymarg-os' );
	}

	if ( 'staff' === $actor ) {
		$actor_id = isset( $entry['actor_id'] ) ? (int) $entry['actor_id'] : 0;
		$staff    = $actor_id ? get_userdata( $actor_id ) : false;

		if ( $staff ) {
			/* translators: %s: staff display name. */
			return sprintf( __( 'Staff — %s', 'zymarg-os' ), $staff->display_name );
		}

		return __( 'Staff', 'zymarg-os' );
	}

	return __( 'System / checkout', 'zymarg-os' );
}
