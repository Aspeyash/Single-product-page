<?php
/**
 * Save ZYMARG OS settings screens over AJAX.
 *
 * WHY THIS FILE EXISTS
 *   The admin router (inc/admin-spa.php) only intercepts sidebar link clicks. It
 *   never touches form submits, so Save reloaded the page on every settings
 *   screen except Slugs & Pages, which had grown its own AJAX save. This gives
 *   the remaining screens the same behaviour from one place.
 *
 * WHY IT IS A SEPARATE FILE
 *   No existing screen file is modified. Each AJAX route calls that screen's own
 *   saver, so there is no second copy of any save logic to drift out of sync,
 *   and the normal post still works: remove this file, or run without
 *   JavaScript, and every screen behaves exactly as it did before.
 *
 * WHAT IS DELIBERATELY LEFT POSTING
 *   Upload Theme and Plugins (real multipart uploads and core install flows),
 *   Import / Export (already has its own batched AJAX), and on Toast the Scan
 *   Plugins and Clear Log buttons — both rebuild the whole screen, so a reload
 *   is the correct outcome rather than a stale table.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * The settings screens that save over AJAX.
 *
 * hook        Substring matched against the current admin page hook.
 * action      admin-ajax action, also the wp_ajax_ hook suffix.
 * nonceField  The form's own nonce field name.
 * nonceAction The form's own nonce action.
 * saver       Existing function that validates and writes. Must return truthy.
 * require     Optional hidden field that identifies the right form when a
 *             screen renders more than one.
 *
 * @return array
 */
function zymarg_os_ajax_save_screens() {
	$screens = array(
		'product_card' => array(
			'hook'        => 'zymarg-os-product-card',
			'action'      => 'zymarg_os_product_card_ajax_save',
			'nonceField'  => 'zymarg_os_product_card_nonce',
			'nonceAction' => 'zymarg_os_product_card_save',
			'saver'       => 'zymarg_os_product_card_maybe_save',
			'saved'       => __( 'Product Card settings saved.', 'zymarg-os' ),
		),
		'account'      => array(
			'hook'        => 'zymarg-os-account',
			'action'      => 'zymarg_os_account_ajax_save',
			'nonceField'  => 'zymarg_os_account_nonce',
			'nonceAction' => 'zymarg_os_account_save',
			'saver'       => 'zymarg_os_account_maybe_save',
			'saved'       => __( 'Account & Security settings saved.', 'zymarg-os' ),
		),
		'toast'        => array(
			'hook'         => 'zymarg-os-toast',
			'action'       => 'zymarg_os_toast_ajax_save',
			'nonceField'   => '_wpnonce',
			'nonceAction'  => 'zymarg_os_toast_admin',
			'saver'        => 'zymarg_os_toast_admin_handle_post',
			'saved'        => __( 'Toast source settings saved.', 'zymarg-os' ),
			'require'      => array(
				'name'  => 'zymarg_toast_admin_action',
				'value' => 'save_sources',
			),
			// This saver reads $_GET['page'], which admin-ajax.php does not set.
			'fakePage'     => 'zymarg-os-toast',
		),
	);

	/**
	 * Filters the screens that save over AJAX. Remove one to send it back to a
	 * normal page post.
	 *
	 * @param array $screens Screen definitions.
	 */
	return (array) apply_filters( 'zymarg_os_ajax_save_screens', $screens );
}

/**
 * Enqueue the shared save script on the screens listed above.
 *
 * @param string $hook Current admin page hook suffix.
 * @return void
 */
function zymarg_os_ajax_save_assets( $hook ) {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$hook = (string) $hook;

	foreach ( zymarg_os_ajax_save_screens() as $screen ) {
		if ( false === strpos( $hook, $screen['hook'] ) ) {
			continue;
		}

		// A missing saver means the screen file was removed; stay out of the way.
		if ( ! function_exists( $screen['saver'] ) ) {
			return;
		}

		$ver = defined( 'ZYMARG_OS_VERSION' ) ? ZYMARG_OS_VERSION : '1.0.0';

		wp_enqueue_script(
			'zymarg-os-admin-ajax-save',
			ZYMARG_OS_URI . '/assets/js/admin-ajax-save.js',
			array(),
			$ver,
			true
		);

		wp_localize_script(
			'zymarg-os-admin-ajax-save',
			'ZymargAjaxSave',
			array(
				'ajaxUrl'      => admin_url( 'admin-ajax.php' ),
				'action'       => $screen['action'],
				'nonce'        => wp_create_nonce( $screen['action'] ),
				'nonceField'   => $screen['nonceField'],
				'requireName'  => isset( $screen['require']['name'] ) ? $screen['require']['name'] : '',
				'requireValue' => isset( $screen['require']['value'] ) ? $screen['require']['value'] : '',
				'saving'       => __( 'Saving...', 'zymarg-os' ),
				'saved'        => $screen['saved'],
				'failed'       => __( 'Could not save. Your changes are still on screen - press Save again.', 'zymarg-os' ),
			)
		);

		$css = '.zymarg-save__status{margin:12px 0 0;font-weight:600;}'
			. '.zymarg-save__status[data-state="ok"]{color:#0a6b33;}'
			. '.zymarg-save__status[data-state="bad"]{color:#b32d2e;}'
			. '.zymarg-save__status[data-state="busy"]{color:#555;}';

		foreach ( array( 'zymarg-os-admin-spa', 'zymarg-os-admin-brand' ) as $handle ) {
			if ( wp_style_is( $handle, 'enqueued' ) ) {
				wp_add_inline_style( $handle, $css );

				break;
			}
		}

		return;
	}
}
add_action( 'admin_enqueue_scripts', 'zymarg_os_ajax_save_assets', 50 );

/**
 * Handle an AJAX save for whichever screen sent it.
 *
 * The browser sends FormData built from the real form, so the screen's own nonce
 * travels with it and its saver validates and writes exactly as it does during a
 * normal post. That keeps one source of truth for what a save means.
 *
 * @param array $screen Screen definition.
 * @return void
 */
function zymarg_os_ajax_save_handle( $screen ) {
	check_ajax_referer( $screen['action'], 'nonce' );

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => __( 'You do not have permission to change these settings.', 'zymarg-os' ) ), 403 );
	}

	if ( ! function_exists( $screen['saver'] ) ) {
		wp_send_json_error( array( 'message' => __( 'That settings screen is unavailable, so nothing was saved.', 'zymarg-os' ) ), 500 );
	}

	/*
	 * The form nonce is verified here first so an expired form returns readable
	 * JSON. Left to the saver's own check_admin_referer() it would die with an
	 * HTML notice that fetch() cannot parse, and the user would see nothing.
	 */
	$posted = isset( $_POST[ $screen['nonceField'] ] )
		? sanitize_text_field( wp_unslash( $_POST[ $screen['nonceField'] ] ) )
		: '';

	if ( '' === $posted || ! wp_verify_nonce( $posted, $screen['nonceAction'] ) ) {
		wp_send_json_error( array( 'message' => __( 'This page has been open a long time and the form expired. Reload the page and save again.', 'zymarg-os' ) ), 400 );
	}

	/*
	 * When a screen renders several forms, refuse anything but the one this route
	 * is for, so a Clear Log or Scan payload can never arrive down the save path.
	 */
	if ( isset( $screen['require']['name'] ) ) {
		$marker = isset( $_POST[ $screen['require']['name'] ] )
			? sanitize_key( wp_unslash( $_POST[ $screen['require']['name'] ] ) )
			: '';

		if ( $marker !== $screen['require']['value'] ) {
			wp_send_json_error( array( 'message' => __( 'That action cannot be saved this way. Reload the page and try again.', 'zymarg-os' ) ), 400 );
		}
	}

	// Some savers read $_GET['page'], which admin-ajax.php never populates.
	if ( ! empty( $screen['fakePage'] ) ) {
		$_GET['page']     = $screen['fakePage'];
		$_REQUEST['page'] = $screen['fakePage'];
	}

	$result = call_user_func( $screen['saver'] );

	/*
	 * Savers that report a boolean are trusted; the Toast handler returns nothing
	 * at all, so reaching this line without an error is the success signal.
	 */
	if ( false === $result ) {
		wp_send_json_error( array( 'message' => __( 'Nothing was saved. Reload the page and try again.', 'zymarg-os' ) ) );
	}

	wp_send_json_success( array( 'message' => $screen['saved'] ) );
}

/**
 * Register one wp_ajax route per screen.
 *
 * @return void
 */
function zymarg_os_ajax_save_register() {
	foreach ( zymarg_os_ajax_save_screens() as $screen ) {
		add_action(
			'wp_ajax_' . $screen['action'],
			static function () use ( $screen ) {
				zymarg_os_ajax_save_handle( $screen );
			}
		);
	}
}
zymarg_os_ajax_save_register();
