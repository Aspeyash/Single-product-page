<?php
/**
 * Customers — the brand's own customer screen.
 *
 * Clicking a customer used to land on WordPress's `user-edit.php`: core's grey
 * form, full of fields that mean nothing to a shop ("Visual Editor", "Admin
 * Colour Scheme", "Nickname"), with the order and account history bolted on at
 * the bottom. That is someone else's screen wearing our content.
 *
 * This is the replacement: ZYMARG OS → Customers, a list and a detail view that
 * answer the question the screen exists for — who is this person, what have
 * they bought, and what has changed on their account. Everything a dispute
 * needs, in one place, in the brand's own menu.
 *
 * What it deliberately does NOT do is re-implement editing. Changing a user's
 * password, role or capabilities is core's job and core does it safely; the
 * detail view links out for that rather than shipping a second, weaker copy.
 *
 * Data helpers live in inc/admin-customer-history.php (orders, security
 * events) and inc/account-change-log.php (field history).
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Capability required to view customers.
 *
 * Not manage_options: a shop manager needs this screen and has no business in
 * general site settings.
 *
 * @return string
 */
function zymarg_os_customers_capability() {
	return (string) apply_filters( 'zymarg_os_customers_capability', 'edit_users' );
}

/**
 * Register the Customers submenu.
 *
 * Priority 25 places it after Account & Security (24).
 *
 * @return void
 */
function zymarg_os_customers_admin_menu() {
	add_submenu_page(
		'zymarg-os',
		__( 'Customers', 'zymarg-os' ),
		__( 'Customers', 'zymarg-os' ),
		zymarg_os_customers_capability(),
		'zymarg-os-customers',
		'zymarg_os_render_customers_admin_page'
	);
}
add_action( 'admin_menu', 'zymarg_os_customers_admin_menu', 25 );

/**
 * URL of the branded detail view for one customer.
 *
 * Every "open this customer" link in the theme goes through here, so the day
 * this screen moves, nothing else has to be found and edited.
 *
 * @param int $user_id User ID.
 * @return string
 */
function zymarg_os_customer_view_url( $user_id ) {
	return admin_url( 'admin.php?page=zymarg-os-customers&customer=' . (int) $user_id );
}

/**
 * Router: list or detail.
 *
 * @return void
 */
function zymarg_os_render_customers_admin_page() {
	/*
	 * Prefer the hardened check from inc/customer-data.php. It applies the same
	 * capability AND refuses vendors outright, so a marketplace plugin that
	 * hands sellers a broad capability can never turn this into a way to browse
	 * the buyer database. Falls back to the original check if that file is gone.
	 */
	$allowed = function_exists( 'zymarg_os_can_view_customer_data' )
		? zymarg_os_can_view_customer_data()
		: current_user_can( zymarg_os_customers_capability() );

	if ( ! $allowed ) {
		wp_die( esc_html__( 'Sorry, you are not allowed to view customers.', 'zymarg-os' ) );
	}

	$customer = isset( $_GET['customer'] ) ? absint( wp_unslash( $_GET['customer'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$view     = isset( $_GET['view'] ) ? sanitize_key( wp_unslash( $_GET['view'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

	if ( $customer ) {
		/*
		 * The console (inc/admin-customer-view.php) is the customer view as of
		 * v5.29.0: two dropdowns, one visible panel, read-only. The original
		 * long-form detail renderer is kept as the fallback.
		 */
		if ( function_exists( 'zymarg_os_render_customer_console' ) ) {
			zymarg_os_render_customer_console( $customer );
		} else {
			zymarg_os_render_customer_detail( $customer );
		}

		return;
	}

	// The long paginated list is now opt-in via &view=list, to keep the landing
	// screen short. Default is the searchable picker.
	if ( 'list' !== $view && function_exists( 'zymarg_os_render_customer_console_picker' ) ) {
		zymarg_os_render_customer_console_picker();

		return;
	}

	zymarg_os_render_customer_list();
}

/* ======================================================================
   1. LIST
   ====================================================================== */

/**
 * The customer list.
 *
 * @return void
 */
function zymarg_os_render_customer_list() {
	$per_page = 25;
	$paged    = isset( $_GET['paged'] ) ? max( 1, absint( wp_unslash( $_GET['paged'] ) ) ) : 1; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$search   = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

	$args = array(
		'number'  => $per_page,
		'paged'   => $paged,
		'orderby' => 'registered',
		'order'   => 'DESC',
	);

	if ( '' !== $search ) {
		/*
		 * v5.29.0: search now goes through the customer index.
		 *
		 * The old form was '*term*', which becomes LIKE '%term%'. A leading
		 * wildcard cannot use an index, so every search was a full scan of
		 * wp_users. The index resolves the term to a capped list of IDs first,
		 * and this query then fetches those rows by primary key.
		 *
		 * count_total is off because SELECT FOUND_ROWS() on a scan of a huge
		 * user table is the other half of the cost, and the result set is
		 * already capped.
		 */
		if ( function_exists( 'zymarg_os_customer_index_search' ) ) {
			$matches = zymarg_os_customer_index_search( $search, 50 );
			$ids     = array();

			foreach ( $matches as $match ) {
				$ids[] = (int) $match->user_id;
			}

			// A non-empty array is required, or WP_User_Query ignores include.
			$args['include']     = ! empty( $ids ) ? $ids : array( 0 );
			$args['number']      = 50;
			$args['paged']       = 1;
			$args['orderby']     = 'include';
			$args['count_total'] = false;
		} else {
			// Wildcard both ends so "rahman" finds an email as readily as a name.
			$args['search']         = '*' . $search . '*';
			$args['search_columns'] = array( 'user_login', 'user_email', 'display_name', 'user_nicename' );
		}
	}

	$query = new WP_User_Query( $args );
	$users = (array) $query->get_results();

	// With count_total off there is no total to read; the capped count is it.
	$total = isset( $args['count_total'] ) && false === $args['count_total']
		? count( $users )
		: (int) $query->get_total();
	?>
	<div class="wrap zymarg-admin zymarg-welcome">
		<h1>
			<?php
			if ( function_exists( 'zymarg_discovery_spark' ) ) {
				echo zymarg_discovery_spark( array( 'size' => 'lg' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			?>
			<?php esc_html_e( 'Customers', 'zymarg-os' ); ?>
			<span class="zymarg-welcome__v">v<?php echo esc_html( ZYMARG_OS_VERSION ); ?></span>
		</h1>
		<p class="zymarg-welcome__intro">
			<?php esc_html_e( 'Everyone with an account, newest first. Open a customer to see their orders, what they have changed on their account, and how to reach them.', 'zymarg-os' ); ?>
		</p>

		<form method="get" style="margin:14px 0;">
			<input type="hidden" name="page" value="zymarg-os-customers">
			<p class="search-box">
				<label class="screen-reader-text" for="zymarg-customer-search"><?php esc_html_e( 'Search customers', 'zymarg-os' ); ?></label>
				<input type="search" id="zymarg-customer-search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="<?php esc_attr_e( 'Name, email or username', 'zymarg-os' ); ?>">
				<?php submit_button( __( 'Search', 'zymarg-os' ), '', '', false ); ?>
			</p>
		</form>

		<?php if ( empty( $users ) ) : ?>
			<p><?php esc_html_e( 'No customers found.', 'zymarg-os' ); ?></p>
		<?php else : ?>
			<table class="widefat striped">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Customer', 'zymarg-os' ); ?></th>
						<th><?php esc_html_e( 'Contact', 'zymarg-os' ); ?></th>
						<th><?php esc_html_e( 'Orders', 'zymarg-os' ); ?></th>
						<th><?php esc_html_e( 'Lifetime value', 'zymarg-os' ); ?></th>
						<th><?php esc_html_e( 'Joined', 'zymarg-os' ); ?></th>
					</tr>
				</thead>
				<tbody>
				<?php foreach ( $users as $user ) : ?>
					<?php
					$count = function_exists( 'wc_get_customer_order_count' ) ? (int) wc_get_customer_order_count( $user->ID ) : 0;
					$spent = function_exists( 'wc_get_customer_total_spent' ) ? wc_get_customer_total_spent( $user->ID ) : 0;
					$phone = function_exists( 'zymarg_os_get_whatsapp_number' ) ? zymarg_os_get_whatsapp_number( $user->ID ) : '';
					?>
					<tr>
						<td>
							<strong>
								<a href="<?php echo esc_url( zymarg_os_customer_view_url( $user->ID ) ); ?>">
									<?php echo esc_html( $user->display_name ); ?>
								</a>
							</strong>
							<div class="description"><?php echo esc_html( $user->user_email ); ?></div>
						</td>
						<td>
							<?php
							if ( $phone && function_exists( 'zymarg_os_whatsapp_link_html' ) ) {
								echo wp_kses_post( zymarg_os_whatsapp_link_html( $user->ID ) );
							} else {
								echo '&mdash;';
							}
							?>
						</td>
						<td><?php echo esc_html( number_format_i18n( $count ) ); ?></td>
						<td><?php echo function_exists( 'wc_price' ) ? wp_kses_post( wc_price( $spent ) ) : '&mdash;'; ?></td>
						<td><?php echo esc_html( mysql2date( get_option( 'date_format' ), $user->user_registered ) ); ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>

			<?php
			$pages = (int) ceil( $total / $per_page );

			if ( $pages > 1 ) {
				echo '<div class="tablenav"><div class="tablenav-pages">';
				echo wp_kses_post(
					paginate_links(
						array(
							'base'      => add_query_arg( 'paged', '%#%' ),
							'format'    => '',
							'current'   => $paged,
							'total'     => $pages,
							'prev_text' => '&laquo;',
							'next_text' => '&raquo;',
						)
					)
				);
				echo '</div></div>';
			}
			?>
		<?php endif; ?>
	</div>
	<?php
}

/* ======================================================================
   2. DETAIL
   ====================================================================== */

/**
 * One customer, everything about them.
 *
 * @param int $user_id User ID.
 * @return void
 */
function zymarg_os_render_customer_detail( $user_id ) {
	$user = get_userdata( $user_id );

	if ( ! $user ) {
		echo '<div class="wrap zymarg-admin zymarg-welcome"><h1>' .
			( function_exists( 'zymarg_discovery_spark' ) ? zymarg_discovery_spark( array( 'size' => 'lg' ) ) : '' ) . // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			esc_html__( 'Customer not found', 'zymarg-os' ) . '</h1><p class="zymarg-welcome__intro">' .
			esc_html__( 'That account no longer exists. It may have been deleted.', 'zymarg-os' ) . '</p></div>';
		return;
	}

	$orders  = function_exists( 'zymarg_os_customer_orders' ) ? zymarg_os_customer_orders( $user_id, 10 ) : array();
	$events  = function_exists( 'zymarg_os_customer_security_events' ) ? zymarg_os_customer_security_events( $user_id, 15 ) : array();
	$changes = function_exists( 'zymarg_os_get_change_log' ) ? zymarg_os_get_change_log( $user_id, 25 ) : array();
	$count   = function_exists( 'wc_get_customer_order_count' ) ? (int) wc_get_customer_order_count( $user_id ) : 0;
	$spent   = function_exists( 'wc_get_customer_total_spent' ) ? wc_get_customer_total_spent( $user_id ) : 0;
	?>
	<div class="wrap zymarg-admin zymarg-welcome">
		<h1>
			<?php
			if ( function_exists( 'zymarg_discovery_spark' ) ) {
				echo zymarg_discovery_spark( array( 'size' => 'lg' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			?>
			<?php echo esc_html( $user->display_name ); ?>
			<span class="zymarg-welcome__v">v<?php echo esc_html( ZYMARG_OS_VERSION ); ?></span>
		</h1>

		<p style="margin:6px 0 18px;">
			<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=zymarg-os-customers' ) ); ?>">
				&larr; <?php esc_html_e( 'All customers', 'zymarg-os' ); ?>
			</a>
			<?php if ( function_exists( 'zymarg_os_customer_orders_url' ) ) : ?>
				<a class="button" href="<?php echo esc_url( zymarg_os_customer_orders_url( $user_id ) ); ?>">
					<?php esc_html_e( 'All orders', 'zymarg-os' ); ?>
				</a>
			<?php endif; ?>
			<a class="button" href="<?php echo esc_url( get_edit_user_link( $user_id ) ); ?>">
				<?php esc_html_e( 'Edit account (WordPress)', 'zymarg-os' ); ?>
			</a>
		</p>

		<?php /* ---- Identity & contact ---- */ ?>
		<h2 class="title"><?php esc_html_e( 'Who they are', 'zymarg-os' ); ?></h2>
		<table class="widefat striped" style="max-width:860px;">
			<tbody>
				<tr>
					<th style="width:200px;"><?php esc_html_e( 'Email', 'zymarg-os' ); ?></th>
					<td>
						<a href="mailto:<?php echo esc_attr( $user->user_email ); ?>"><?php echo esc_html( $user->user_email ); ?></a>
					</td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Phone', 'zymarg-os' ); ?></th>
					<td><?php echo esc_html( get_user_meta( $user_id, 'billing_phone', true ) ? get_user_meta( $user_id, 'billing_phone', true ) : '—' ); ?></td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'WhatsApp', 'zymarg-os' ); ?></th>
					<td>
						<?php
						echo function_exists( 'zymarg_os_whatsapp_link_html' )
							? wp_kses_post( zymarg_os_whatsapp_link_html( $user_id ) )
							: '&mdash;';
						?>
					</td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Customer since', 'zymarg-os' ); ?></th>
					<td>
						<?php echo esc_html( mysql2date( get_option( 'date_format' ), $user->user_registered ) ); ?>
						&nbsp;&middot;&nbsp;
						<?php
						printf(
							/* translators: 1: user ID, 2: role list. */
							esc_html__( 'ID %1$s — %2$s', 'zymarg-os' ),
							esc_html( (string) $user_id ),
							esc_html( implode( ', ', (array) $user->roles ) )
						);
						?>
					</td>
				</tr>
				<?php if ( function_exists( 'wc_price' ) ) : ?>
					<tr>
						<th><?php esc_html_e( 'Value', 'zymarg-os' ); ?></th>
						<td>
							<strong><?php echo esc_html( number_format_i18n( $count ) ); ?></strong>
							<?php esc_html_e( 'order(s)', 'zymarg-os' ); ?>
							&nbsp;&middot;&nbsp;
							<strong><?php echo wp_kses_post( wc_price( $spent ) ); ?></strong>
							<?php esc_html_e( 'lifetime', 'zymarg-os' ); ?>
						</td>
					</tr>
				<?php endif; ?>
			</tbody>
		</table>

		<?php /* ---- Orders ---- */ ?>
		<h2 class="title"><?php esc_html_e( 'Order history', 'zymarg-os' ); ?></h2>
		<?php if ( empty( $orders ) ) : ?>
			<p><?php esc_html_e( 'No orders yet.', 'zymarg-os' ); ?></p>
		<?php else : ?>
			<table class="widefat striped" style="max-width:860px;">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Order', 'zymarg-os' ); ?></th>
						<th><?php esc_html_e( 'Date', 'zymarg-os' ); ?></th>
						<th><?php esc_html_e( 'Status', 'zymarg-os' ); ?></th>
						<th><?php esc_html_e( 'Items', 'zymarg-os' ); ?></th>
						<th><?php esc_html_e( 'Total', 'zymarg-os' ); ?></th>
					</tr>
				</thead>
				<tbody>
				<?php foreach ( $orders as $order ) : ?>
					<?php
					if ( ! is_a( $order, 'WC_Order' ) ) {
						continue;
					}
					$created = $order->get_date_created();
					?>
					<tr>
						<td>
							<a href="<?php echo esc_url( $order->get_edit_order_url() ); ?>">
								#<?php echo esc_html( $order->get_order_number() ); ?>
							</a>
						</td>
						<td><?php echo esc_html( $created ? $created->date_i18n( get_option( 'date_format' ) ) : '—' ); ?></td>
						<td><?php echo esc_html( wc_get_order_status_name( $order->get_status() ) ); ?></td>
						<td><?php echo esc_html( number_format_i18n( $order->get_item_count() ) ); ?></td>
						<td><?php echo wp_kses_post( $order->get_formatted_order_total() ); ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>

		<?php /* ---- Account changes ---- */ ?>
		<h2 class="title"><?php esc_html_e( 'Account changes', 'zymarg-os' ); ?></h2>
		<?php if ( empty( $changes ) ) : ?>
			<p class="description">
				<?php esc_html_e( 'Nothing recorded yet. Changes are logged from the moment this version was installed — anything altered before that is not here.', 'zymarg-os' ); ?>
			</p>
		<?php else : ?>
			<table class="widefat striped" style="max-width:960px;">
				<thead>
					<tr>
						<th><?php esc_html_e( 'What', 'zymarg-os' ); ?></th>
						<th><?php esc_html_e( 'From', 'zymarg-os' ); ?></th>
						<th><?php esc_html_e( 'To', 'zymarg-os' ); ?></th>
						<th><?php esc_html_e( 'Changed by', 'zymarg-os' ); ?></th>
						<th><?php esc_html_e( 'When', 'zymarg-os' ); ?></th>
					</tr>
				</thead>
				<tbody>
				<?php foreach ( $changes as $entry ) : ?>
					<tr>
						<td><?php echo esc_html( isset( $entry['label'] ) ? $entry['label'] : $entry['field'] ); ?></td>
						<td><?php echo esc_html( '' !== $entry['old'] ? $entry['old'] : __( '(empty)', 'zymarg-os' ) ); ?></td>
						<td><strong><?php echo esc_html( '' !== $entry['new'] ? $entry['new'] : __( '(cleared)', 'zymarg-os' ) ); ?></strong></td>
						<td>
							<?php echo esc_html( zymarg_os_change_log_actor_label( $entry ) ); ?>
							<?php if ( ! empty( $entry['ip'] ) ) : ?>
								<div class="description"><?php echo esc_html( $entry['ip'] ); ?></div>
							<?php endif; ?>
						</td>
						<td>
							<?php
							echo esc_html(
								mysql2date(
									get_option( 'date_format' ) . ' ' . get_option( 'time_format' ),
									get_date_from_gmt( $entry['time'] )
								)
							);
							?>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>

		<?php /* ---- Security ---- */ ?>
		<h2 class="title"><?php esc_html_e( 'Sign-ins & security', 'zymarg-os' ); ?></h2>
		<?php if ( ! class_exists( 'ZLS_Audit' ) ) : ?>
			<p class="description">
				<?php esc_html_e( 'ZYMARG Login & Security is not active, so sign-ins are not being recorded.', 'zymarg-os' ); ?>
			</p>
		<?php elseif ( empty( $events ) ) : ?>
			<p class="description"><?php esc_html_e( 'Nothing recorded for this account yet.', 'zymarg-os' ); ?></p>
		<?php else : ?>
			<table class="widefat striped" style="max-width:860px;">
				<thead>
					<tr>
						<th><?php esc_html_e( 'What happened', 'zymarg-os' ); ?></th>
						<th><?php esc_html_e( 'When', 'zymarg-os' ); ?></th>
						<th><?php esc_html_e( 'Where from', 'zymarg-os' ); ?></th>
					</tr>
				</thead>
				<tbody>
				<?php foreach ( $events as $event ) : ?>
					<?php
					$where = array();

					if ( ! empty( $event->device ) ) {
						$where[] = $event->device;
					}
					if ( ! empty( $event->ip ) ) {
						$where[] = $event->ip;
					}
					if ( ! empty( $event->country ) ) {
						$where[] = $event->country;
					}
					?>
					<tr>
						<td><?php echo esc_html( zymarg_os_event_label( isset( $event->event_type ) ? $event->event_type : '' ) ); ?></td>
						<td>
							<?php
							echo esc_html(
								isset( $event->created_at )
									? mysql2date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $event->created_at )
									: '—'
							);
							?>
						</td>
						<td><?php echo esc_html( $where ? implode( ' · ', $where ) : '—' ); ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>
	</div>
	<?php
}
