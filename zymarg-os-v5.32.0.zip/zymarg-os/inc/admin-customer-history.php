<?php
/**
 * Customer history — one place to see who someone is, what they bought and
 * what happened to their account.
 *
 * The question this answers: "which user, what order, and what is their whole
 * history?" Before this, the answer was scattered across four screens — Users
 * for the account, WooCommerce Orders for purchases, the Login & Security
 * audit tab for sign-ins, and nothing at all joining them together.
 *
 * Deliberately NOT a new admin page. WooCommerce already has an orders list
 * and an analytics Customers report, and the Login & Security plugin already
 * has a full audit tab. Rebuilding those would be the duplication the brand
 * keeps saying no to. Instead this bolts a summary onto the screen an admin is
 * already looking at — the user's own profile — and links out to the full
 * lists for anything deeper.
 *
 * Everything degrades: no WooCommerce means no order block, no Login &
 * Security means no security block, and the rest still renders.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/* ======================================================================
   1. DATA
   ====================================================================== */

/**
 * How many rows each block shows before linking out to the full list.
 *
 * @return int
 */
function zymarg_os_customer_history_limit() {
	return (int) apply_filters( 'zymarg_os_customer_history_limit', 10 );
}

/**
 * Recent orders for a customer.
 *
 * Uses wc_get_orders() rather than a direct query so it works on both the
 * legacy post storage and HPOS without a branch.
 *
 * @param int $user_id User ID.
 * @param int $limit   Max orders.
 * @return array<int,WC_Order>
 */
function zymarg_os_customer_orders( $user_id, $limit = 10 ) {
	if ( ! function_exists( 'wc_get_orders' ) ) {
		return array();
	}

	$orders = wc_get_orders(
		array(
			'customer' => (int) $user_id,
			'limit'    => (int) $limit,
			'orderby'  => 'date',
			'order'    => 'DESC',
		)
	);

	return is_array( $orders ) ? $orders : array();
}

/**
 * Link to the full, customer-filtered order list.
 *
 * HPOS moved orders off the posts table and onto their own admin page, so the
 * correct URL depends on which storage the store is using.
 *
 * @param int $user_id User ID.
 * @return string
 */
function zymarg_os_customer_orders_url( $user_id ) {
	$hpos = false;

	if ( class_exists( '\Automattic\WooCommerce\Utilities\OrderUtil' )
		&& method_exists( '\Automattic\WooCommerce\Utilities\OrderUtil', 'custom_orders_table_usage_is_enabled' ) ) {
		$hpos = \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();
	}

	if ( $hpos ) {
		return admin_url( 'admin.php?page=wc-orders&_customer_user=' . (int) $user_id );
	}

	return admin_url( 'edit.php?post_type=shop_order&_customer_user=' . (int) $user_id );
}

/**
 * Recent security events for a customer.
 *
 * @param int $user_id User ID.
 * @param int $limit   Max events.
 * @return array<int,object>
 */
function zymarg_os_customer_security_events( $user_id, $limit = 10 ) {
	if ( ! class_exists( 'ZLS_Audit' ) || ! method_exists( 'ZLS_Audit', 'query' ) ) {
		return array();
	}

	$rows = ZLS_Audit::query(
		array(
			'user_id' => (int) $user_id,
			'limit'   => (int) $limit,
			'order'   => 'desc',
		)
	);

	return is_array( $rows ) ? $rows : array();
}

/**
 * Turn an event key into something a human reads.
 *
 * Covers the theme's own events plus the plugin's. Anything unrecognised is
 * tidied rather than hidden — an unknown event is still evidence.
 *
 * @param string $event_type Raw event key.
 * @return string
 */
function zymarg_os_event_label( $event_type ) {
	$labels = array(
		'PASSWORD_CHANGED'            => __( 'Password changed', 'zymarg-os' ),
		'PASSWORD_CHANGE_BAD_CURRENT' => __( 'Failed password change (wrong current password)', 'zymarg-os' ),
		'PASSWORD_CHANGE_THROTTLED'   => __( 'Password change blocked (too many attempts)', 'zymarg-os' ),
		'EMAIL_CHANGE_REQUESTED'      => __( 'Email change requested', 'zymarg-os' ),
		'EMAIL_CHANGED'               => __( 'Email address changed', 'zymarg-os' ),
		'EMAIL_CHANGE_BAD_PASSWORD'   => __( 'Failed email change (wrong password)', 'zymarg-os' ),
		'EMAIL_CHANGE_BAD_TOKEN'      => __( 'Email change link invalid or expired', 'zymarg-os' ),
		'EMAIL_CHANGE_TAKEN'          => __( 'Email change refused (address in use)', 'zymarg-os' ),
		'LOGIN'                       => __( 'Signed in', 'zymarg-os' ),
		'LOGOUT'                      => __( 'Signed out', 'zymarg-os' ),
		'LOGIN_FAILED'                => __( 'Failed sign-in', 'zymarg-os' ),
		'REGISTER'                    => __( 'Account created', 'zymarg-os' ),
	);

	$key = strtoupper( (string) $event_type );

	if ( isset( $labels[ $key ] ) ) {
		return $labels[ $key ];
	}

	return ucfirst( strtolower( str_replace( '_', ' ', $key ) ) );
}

/* ======================================================================
   2. THE PANEL
   ====================================================================== */

/**
 * Point the WordPress user screen at the brand's own customer view.
 *
 * The full history used to render here. It now lives on ZYMARG OS ->
 * Customers, so this is a signpost rather than a second copy of the same
 * three tables -- one place to read a customer's history, not two that can
 * drift apart.
 *
 * @param WP_User $user User being edited.
 * @return void
 */
function zymarg_os_render_customer_history_panel( $user ) {
	if ( ! current_user_can( 'edit_users' ) || ! ( $user instanceof WP_User ) ) {
		return;
	}

	if ( ! function_exists( 'zymarg_os_customer_view_url' ) ) {
		return;
	}

	$orders = function_exists( 'wc_get_customer_order_count' )
		? (int) wc_get_customer_order_count( $user->ID )
		: 0;
	?>
	<h2 id="zymarg-history"><?php esc_html_e( 'ZYMARG customer history', 'zymarg-os' ); ?></h2>
	<table class="form-table" role="presentation">
		<tr>
			<th scope="row"><?php esc_html_e( 'Full history', 'zymarg-os' ); ?></th>
			<td>
				<p style="margin:0 0 8px;">
					<?php
					printf(
						/* translators: %s: order count. */
						esc_html__( 'Orders, account changes and sign-in activity for this customer (%s order(s) so far).', 'zymarg-os' ),
						esc_html( number_format_i18n( $orders ) )
					);
					?>
				</p>
				<a class="button button-primary" href="<?php echo esc_url( zymarg_os_customer_view_url( $user->ID ) ); ?>">
					<?php esc_html_e( 'Open customer view', 'zymarg-os' ); ?>
				</a>
			</td>
		</tr>
	</table>
	<?php
}
add_action( 'show_user_profile', 'zymarg_os_render_customer_history_panel', 20 );
add_action( 'edit_user_profile', 'zymarg_os_render_customer_history_panel', 20 );

/* ======================================================================
   3. GETTING THERE FROM THE OTHER SCREENS
   ====================================================================== */

/**
 * Add a "History" row action under each user on the Users screen.
 *
 * @param array   $actions Existing row actions.
 * @param WP_User $user    The user.
 * @return array
 */
function zymarg_os_user_row_history_action( $actions, $user ) {
	if ( ! current_user_can( 'edit_users' ) || ! ( $user instanceof WP_User ) ) {
		return $actions;
	}

	$actions['zymarg_history'] = sprintf(
		'<a href="%1$s">%2$s</a>',
		esc_url( zymarg_os_customer_view_url( $user->ID ) ),
		esc_html__( 'History', 'zymarg-os' )
	);

	return $actions;
}
add_filter( 'user_row_actions', 'zymarg_os_user_row_history_action', 10, 2 );

/**
 * On the order screen, link straight to the customer's history.
 *
 * Closes the loop the other way round: from an order, one click to everything
 * else that customer has ever done.
 *
 * @param WC_Order $order Order being edited.
 * @return void
 */
function zymarg_os_order_customer_history_link( $order ) {
	if ( ! is_a( $order, 'WC_Order' ) || ! current_user_can( 'edit_users' ) ) {
		return;
	}

	$user_id = (int) $order->get_customer_id();

	if ( ! $user_id ) {
		echo '<p class="form-field form-field-wide"><em>' . esc_html__( 'Guest order — no customer account to open.', 'zymarg-os' ) . '</em></p>';
		return;
	}

	printf(
		'<p class="form-field form-field-wide"><a class="button" href="%1$s">%2$s</a></p>',
		esc_url( zymarg_os_customer_view_url( $user_id ) ),
		esc_html__( 'Customer history & contact', 'zymarg-os' )
	);
}
add_action( 'woocommerce_admin_order_data_after_billing_address', 'zymarg_os_order_customer_history_link', 20 );
