<?php
/**
 * Account & Security control panel (admin page).
 *
 * A dedicated screen at ZYMARG OS → Account & Security, sitting in the theme's
 * own sidebar menu alongside Welcome, Help, Performance, Toast Notification,
 * Product Card and Slugs & Pages.
 *
 * Before this screen existed, everything the account area does was tuned by
 * PHP filters only — fine for a developer, useless for whoever runs the store
 * on a Tuesday afternoon. Worse, the one setting people actually needed (the
 * password-change alert email) lived in a different plugin's menu entirely,
 * three clicks deep, which is exactly how a toggle becomes impossible to
 * find. This screen puts the theme's own settings in the theme's own menu,
 * and surfaces the plugin's related toggles with a direct link rather than
 * pretending they live here.
 *
 * Settings are stored and read in inc/account-helpers.php (option
 * `zymarg_os_account_settings`), because the front end reads them on every
 * account request. This file only draws the form — the same split the theme
 * already uses for Product Card.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register the submenu.
 *
 * Priority 24 places it directly after Product Card (23).
 *
 * @return void
 */
function zymarg_os_account_admin_menu() {
	// The settings store lives in inc/account-helpers.php, which only loads when
	// WooCommerce is active. Without it there is no account area to configure, so
	// the page hides itself rather than half-working.
	if ( ! function_exists( 'zymarg_os_account_settings' ) ) {
		return;
	}

	add_submenu_page(
		'zymarg-os',
		__( 'Account & Security', 'zymarg-os' ),
		__( 'Account & Security', 'zymarg-os' ),
		'manage_options',
		'zymarg-os-account',
		'zymarg_os_render_account_admin_page'
	);
}
add_action( 'admin_menu', 'zymarg_os_account_admin_menu', 24 );

/**
 * Handle the settings save.
 *
 * @return bool True when settings were just saved.
 */
function zymarg_os_account_maybe_save() {
	if ( ! isset( $_POST['zymarg_os_account_nonce'] ) ) {
		return false;
	}

	if ( ! current_user_can( 'manage_options' ) ) {
		return false;
	}

	check_admin_referer( 'zymarg_os_account_save', 'zymarg_os_account_nonce' );

	$defaults = zymarg_os_account_defaults();

	// Password length: clamped rather than trusted. Anything under 8 is below
	// the NIST floor and anything over 64 locks people out of their own
	// password managers.
	$min = isset( $_POST['zymarg_os_min_password_length'] )
		? absint( wp_unslash( $_POST['zymarg_os_min_password_length'] ) )
		: (int) $defaults['min_password_length'];

	$hours = isset( $_POST['zymarg_os_email_link_hours'] )
		? absint( wp_unslash( $_POST['zymarg_os_email_link_hours'] ) )
		: (int) $defaults['email_link_hours'];

	$cc = isset( $_POST['zymarg_os_default_country_code'] )
		? preg_replace( '/\D/', '', (string) wp_unslash( $_POST['zymarg_os_default_country_code'] ) )
		: (string) $defaults['default_country_code'];

	$message = isset( $_POST['zymarg_os_whatsapp_message'] )
		? sanitize_textarea_field( wp_unslash( $_POST['zymarg_os_whatsapp_message'] ) )
		: (string) $defaults['whatsapp_message'];

	if ( '' === trim( $message ) ) {
		$message = (string) $defaults['whatsapp_message'];
	}

	$settings = array(
		'min_password_length'  => (int) min( 64, max( 8, $min ) ),
		'require_country_code' => isset( $_POST['zymarg_os_require_country_code'] ) ? 1 : 0,
		'default_country_code' => substr( $cc, 0, 4 ),
		'email_link_hours'     => (int) min( 72, max( 1, $hours ) ),
		'users_column'         => isset( $_POST['zymarg_os_users_column'] ) ? 1 : 0,
		'whatsapp_message'     => $message,
	);

	update_option( ZYMARG_OS_ACCOUNT_OPTION, $settings );

	return true;
}

/**
 * Where the Login & Security alert toggles live.
 *
 * Hard-coding this URL is deliberate. The alternative is telling the user to
 * "go and find it", which is what made the toggle invisible in the first
 * place.
 *
 * @return string
 */
function zymarg_os_account_plugin_settings_url() {
	return admin_url( 'admin.php?page=zymarg-login-security&tab=security' );
}

/**
 * Read the plugin's alert settings, when the plugin is there.
 *
 * @return array{active:bool,password:bool,email:bool}
 */
function zymarg_os_account_plugin_alert_state() {
	$state = array(
		'active'   => zymarg_os_has_session_manager(),
		'password' => false,
		'email'    => false,
	);

	// The plugin stores its settings in one option array. Read it directly but
	// defensively: if the plugin renames it, we simply show "unknown" instead
	// of fatalling.
	foreach ( array( 'zls_settings', 'zymarg_login_security_settings' ) as $option ) {
		$saved = get_option( $option, false );

		if ( is_array( $saved ) ) {
			$state['password'] = ! empty( $saved['alert_password_change'] );
			$state['email']    = ! empty( $saved['alert_email_change'] );
			break;
		}
	}

	return $state;
}

/**
 * Render the screen.
 *
 * @return void
 */
function zymarg_os_render_account_admin_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Sorry, you are not allowed to manage these settings.', 'zymarg-os' ) );
	}

	$saved    = zymarg_os_account_maybe_save();
	$settings = zymarg_os_account_settings();
	$alerts   = zymarg_os_account_plugin_alert_state();
	?>
	<div class="wrap zymarg-admin zymarg-welcome">
		<h1>
			<?php
			if ( function_exists( 'zymarg_discovery_spark' ) ) {
				echo zymarg_discovery_spark( array( 'size' => 'lg' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			?>
			<?php esc_html_e( 'Account & Security', 'zymarg-os' ); ?>
			<span class="zymarg-welcome__v">v<?php echo esc_html( ZYMARG_OS_VERSION ); ?></span>
		</h1>
		<p class="zymarg-welcome__intro">
			<?php esc_html_e( 'Everything that governs the customer My Account area: password rules, phone number validation, email changes and how your team reaches customers.', 'zymarg-os' ); ?>
		</p>

		<?php if ( $saved ) : ?>
			<div class="notice notice-success is-dismissible" style="margin:16px 0;max-width:820px;">
				<p><?php esc_html_e( 'Settings saved.', 'zymarg-os' ); ?></p>
			</div>
		<?php endif; ?>

		<?php /* ---- Alert emails: the toggles that live in the plugin ---- */ ?>
		<div class="notice <?php echo ( $alerts['password'] && $alerts['email'] ) ? 'notice-success' : 'notice-warning'; ?> inline" style="margin:16px 0;max-width:820px;">
			<p><strong><?php esc_html_e( 'Security alert emails', 'zymarg-os' ); ?></strong></p>

			<?php if ( ! $alerts['active'] ) : ?>
				<p><?php esc_html_e( 'ZYMARG Login & Security is not active, so no alert emails are sent when a password or email address changes. The account area still works without it.', 'zymarg-os' ); ?></p>
			<?php else : ?>
				<p>
					<?php esc_html_e( 'Password change alert:', 'zymarg-os' ); ?>
					<strong><?php echo $alerts['password'] ? esc_html__( 'On', 'zymarg-os' ) : esc_html__( 'Off', 'zymarg-os' ); ?></strong>
					&nbsp;|&nbsp;
					<?php esc_html_e( 'Email change alert:', 'zymarg-os' ); ?>
					<strong><?php echo $alerts['email'] ? esc_html__( 'On', 'zymarg-os' ) : esc_html__( 'Off', 'zymarg-os' ); ?></strong>
				</p>
				<?php if ( ! $alerts['password'] || ! $alerts['email'] ) : ?>
					<p><?php esc_html_e( 'These two live in the Login & Security plugin and ship switched off. The theme fires them correctly, but nothing is emailed until they are on.', 'zymarg-os' ); ?></p>
				<?php endif; ?>
			<?php endif; ?>

			<p>
				<a class="button" href="<?php echo esc_url( zymarg_os_account_plugin_settings_url() ); ?>">
					<?php esc_html_e( 'Open alert settings', 'zymarg-os' ); ?>
				</a>
			</p>
		</div>

		<form method="post" action="">
			<?php wp_nonce_field( 'zymarg_os_account_save', 'zymarg_os_account_nonce' ); ?>

			<h2 class="title"><?php esc_html_e( 'Passwords', 'zymarg-os' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row">
						<label for="zymarg_os_min_password_length"><?php esc_html_e( 'Minimum length', 'zymarg-os' ); ?></label>
					</th>
					<td>
						<input type="number" min="8" max="64" step="1" class="small-text"
							id="zymarg_os_min_password_length" name="zymarg_os_min_password_length"
							value="<?php echo esc_attr( $settings['min_password_length'] ); ?>">
						<?php esc_html_e( 'characters', 'zymarg-os' ); ?>
						<p class="description">
							<?php esc_html_e( 'Applies to the Security → Change password form. 8 is the recommended floor; the theme also blocks passwords containing the username or email address.', 'zymarg-os' ); ?>
						</p>
					</td>
				</tr>
			</table>

			<h2 class="title"><?php esc_html_e( 'Phone numbers', 'zymarg-os' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Country code', 'zymarg-os' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="zymarg_os_require_country_code" value="1"
								<?php checked( ! empty( $settings['require_country_code'] ) ); ?>>
							<?php esc_html_e( 'Require a country code on phone and WhatsApp numbers', 'zymarg-os' ); ?>
						</label>
						<p class="description">
							<?php esc_html_e( 'Recommended. Numbers without a country code cannot be dialled internationally, cannot be routed by an SMS gateway, and cannot open a WhatsApp chat.', 'zymarg-os' ); ?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="zymarg_os_default_country_code"><?php esc_html_e( 'Assume this country', 'zymarg-os' ); ?></label>
					</th>
					<td>
						+<input type="text" class="small-text" id="zymarg_os_default_country_code"
							name="zymarg_os_default_country_code" inputmode="numeric"
							value="<?php echo esc_attr( $settings['default_country_code'] ); ?>">
						<p class="description">
							<?php esc_html_e( 'When a customer types a local number such as 01712 345678, the theme upgrades it to this country code instead of rejecting it. Leave empty to always demand the code be typed.', 'zymarg-os' ); ?>
						</p>
					</td>
				</tr>
			</table>

			<h2 class="title"><?php esc_html_e( 'Email changes', 'zymarg-os' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row">
						<label for="zymarg_os_email_link_hours"><?php esc_html_e( 'Confirmation link expires after', 'zymarg-os' ); ?></label>
					</th>
					<td>
						<input type="number" min="1" max="72" step="1" class="small-text"
							id="zymarg_os_email_link_hours" name="zymarg_os_email_link_hours"
							value="<?php echo esc_attr( $settings['email_link_hours'] ); ?>">
						<?php esc_html_e( 'hour(s)', 'zymarg-os' ); ?>
						<p class="description">
							<?php esc_html_e( 'A new email address only becomes active once the customer clicks the link sent to it. Shorter is safer; 1 hour suits most stores.', 'zymarg-os' ); ?>
						</p>
					</td>
				</tr>
			</table>

			<h2 class="title"><?php esc_html_e( 'Reaching customers', 'zymarg-os' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Users list', 'zymarg-os' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="zymarg_os_users_column" value="1"
								<?php checked( ! empty( $settings['users_column'] ) ); ?>>
							<?php esc_html_e( 'Show a WhatsApp column on the Users screen', 'zymarg-os' ); ?>
						</label>
						<p class="description">
							<?php
							printf(
								/* translators: %s: link to the Users screen. */
								esc_html__( 'Chat links also appear on each user\'s profile and on the WooCommerce order screen. %s', 'zymarg-os' ),
								'<a href="' . esc_url( admin_url( 'users.php' ) ) . '">' . esc_html__( 'View users', 'zymarg-os' ) . '</a>'
							);
							?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="zymarg_os_whatsapp_message"><?php esc_html_e( 'Opening message', 'zymarg-os' ); ?></label>
					</th>
					<td>
						<textarea id="zymarg_os_whatsapp_message" name="zymarg_os_whatsapp_message"
							rows="3" class="large-text"><?php echo esc_textarea( $settings['whatsapp_message'] ); ?></textarea>
						<p class="description">
							<?php esc_html_e( 'Pre-filled when a team member opens a chat. Available tags:', 'zymarg-os' ); ?>
							<code>{first_name}</code>, <code>{last_name}</code>, <code>{store}</code>
						</p>
					</td>
				</tr>
			</table>

			<?php submit_button( __( 'Save settings', 'zymarg-os' ) ); ?>
		</form>

		<p class="zymarg-welcome__intro" style="margin-top:18px;">
			<?php esc_html_e( 'Customers manage their own details at My Account → Profile and My Account → Login & Security.', 'zymarg-os' ); ?>
		</p>
	</div>
	<?php
}
