<?php
/**
 * Performance report (admin page).
 *
 * A detailed dashboard at ZYMARG OS -> Performance showing the environment,
 * active integrations, every module's on/off state, the theme's asset-loading
 * strategy, and actionable recommendations to keep the site fast. Read-only —
 * it links out to the relevant controls rather than changing anything itself.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register the Performance submenu under the ZYMARG OS menu.
 *
 * @return void
 */
function zymarg_os_performance_admin_menu() {
	add_submenu_page(
		'zymarg-os',
		__( 'Performance', 'zymarg-os' ),
		__( 'Performance', 'zymarg-os' ),
		'manage_options',
		'zymarg-os-performance',
		'zymarg_os_render_performance_page'
	);
}
add_action( 'admin_menu', 'zymarg_os_performance_admin_menu', 21 );

/**
 * Detect a page/edge cache. Returns the provider name, or false if none found.
 *
 * Covers host-level edge caches (which have no plugin constant) and the common
 * caching plugins.
 *
 * @return string|false
 */
function zymarg_os_detect_cache() {
	$checks = array(
		'Pantheon Global CDN' => defined( 'PANTHEON_ENVIRONMENT' ),
		'WP Engine'           => defined( 'WPE_APIKEY' ) || defined( 'IS_WPE' ),
		'Kinsta'              => defined( 'KINSTA_CACHE_ZONE' ),
		'SiteGround'          => defined( 'SG_CACHEPRESS_VERSION' ) || class_exists( '\\SiteGround_Optimizer\\Options\\Options' ),
		'Cloudways Breeze'    => defined( 'BREEZE_VERSION' ),
		'Cloudflare'          => isset( $_SERVER['HTTP_CF_RAY'] ),
		'WP Rocket'           => defined( 'WPROCKET_VERSION' ),
		'W3 Total Cache'      => defined( 'W3TC' ) || defined( 'W3TC_VERSION' ),
		'LiteSpeed Cache'     => defined( 'LSCWP_V' ),
		'WP Super Cache'      => defined( 'WPCACHEHOME' ),
		'WP Fastest Cache'    => defined( 'WPFC_MAIN_PATH' ) || class_exists( 'WpFastestCache' ),
		'Cache Enabler'       => defined( 'CE_FILE' ),
		'Autoptimize'         => class_exists( 'autoptimizeMain' ),
	);

	foreach ( $checks as $name => $present ) {
		if ( $present ) {
			return $name;
		}
	}

	if ( ( defined( 'WP_CACHE' ) && WP_CACHE ) || ( function_exists( 'wp_using_ext_object_cache' ) && wp_using_ext_object_cache() ) ) {
		return __( 'Active', 'zymarg-os' );
	}

	/** Allow hosts/users to declare their cache so the report is accurate. */
	return apply_filters( 'zymarg_os_detected_cache', false );
}

/**
 * A status pill.
 *
 * @param bool   $ok    Good/true state.
 * @param string $label Optional custom label.
 * @return string
 */
function zymarg_os_perf_pill( $ok, $label = '' ) {
	$text = $label ? $label : ( $ok ? __( 'On', 'zymarg-os' ) : __( 'Off', 'zymarg-os' ) );
	$cls  = $ok ? 'is-on' : 'is-off';
	return '<span class="zperf-pill ' . esc_attr( $cls ) . '">' . esc_html( $text ) . '</span>';
}

/**
 * Render the Performance report page.
 *
 * @return void
 */
function zymarg_os_render_performance_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Sorry, you are not allowed to view this.', 'zymarg-os' ) );
	}

	// ---- Environment ----
	$theme        = wp_get_theme();
	$php_v        = PHP_VERSION;
	$wp_v         = get_bloginfo( 'version' );
	$mem          = defined( 'WP_MEMORY_LIMIT' ) ? WP_MEMORY_LIMIT : ini_get( 'memory_limit' );
	$https        = is_ssl();
	$debug        = defined( 'WP_DEBUG' ) && WP_DEBUG;

	// ---- Integrations ----
	// The five required plugins (see inc/recommended-plugins.php). Theme Builder
	// and Elementor are no longer required or reported as of v5.29.2.
	$woo         = function_exists( 'zymarg_os_woocommerce_active' ) ? zymarg_os_woocommerce_active() : class_exists( 'WooCommerce' );
	$dokan       = function_exists( 'zymarg_os_dokan_active' ) ? zymarg_os_dokan_active() : function_exists( 'dokan' );
	$vendor_dash = function_exists( 'zymarg_os_vendor_dashboard_active' ) ? zymarg_os_vendor_dashboard_active() : defined( 'ZYMARG_VD_VERSION' );
	$reviews     = function_exists( 'zymarg_os_reviews_engine_active' ) ? zymarg_os_reviews_engine_active() : false;
	$zls         = function_exists( 'zymarg_os_login_security_active' ) ? zymarg_os_login_security_active() : defined( 'ZLS_VERSION' );

	// ---- Caching detection (host edge caches + plugins) ----
	$cache_name = zymarg_os_detect_cache();
	$cache      = (bool) $cache_name;

	// ---- Modules ----
	$modules = function_exists( 'zymarg_os_default_modules' ) ? zymarg_os_default_modules() : array();
	$state   = function_exists( 'zymarg_os_get_modules_state' ) ? zymarg_os_get_modules_state() : array();
	$mods_url = admin_url( 'customize.php?autofocus[section]=zymarg_os_modules_section' );
	$on_count = 0;
	foreach ( $modules as $key => $meta ) {
		if ( ! empty( $state[ $key ] ) ) {
			$on_count++;
		}
	}

	// ---- Asset-loading map (the theme's strategy) ----
	$assets = array(
		array( __( 'Design tokens + base + components', 'zymarg-os' ), __( 'Every page', 'zymarg-os' ), __( 'Core styling (small, cached).', 'zymarg-os' ) ),
		array( __( 'Navigation / Mega Menu CSS', 'zymarg-os' ), __( 'Only when the Mega Menu module is on', 'zymarg-os' ), '' ),
		array( __( 'WooCommerce CSS (product/cart/checkout/account)', 'zymarg-os' ), __( 'Only on WooCommerce / account pages', 'zymarg-os' ), '' ),
		array( __( 'Single-product CSS + JS', 'zymarg-os' ), __( 'Only on product pages (when enhanced PDP is on)', 'zymarg-os' ), '' ),
		array( __( 'Login card / pop-up assets', 'zymarg-os' ), __( 'Only when the pop-up or [zymarg_login] is used', 'zymarg-os' ), '' ),
		array( __( 'Front-end script bundle', 'zymarg-os' ), __( 'Only when Scroll-to-Top / Mega Menu / Woo needs it', 'zymarg-os' ), '' ),
		array( __( 'Discovery Spark CSS', 'zymarg-os' ), __( 'Only the first time a spark renders', 'zymarg-os' ), '' ),
	);

	// ---- Recommendations ----
	$recs = array();
	if ( ! $cache ) {
		$recs[] = array( false, __( 'No caching detected. A page-cache (e.g. your host cache or a caching plugin) gives the biggest speed win.', 'zymarg-os' ) );
	} else {
		/* translators: %s: cache provider name. */
		$recs[] = array( true, sprintf( __( 'Caching is active (%s) — great.', 'zymarg-os' ), $cache_name ) );
	}
	$recs[] = array(
		! empty( $state['performance'] ),
		! empty( $state['performance'] )
			? __( 'Performance module is on (emoji script removed, jQuery Migrate dropped, scripts deferred).', 'zymarg-os' )
			: __( 'Turn on the Performance module for emoji/script trimming and deferred JS.', 'zymarg-os' )
	);
	$recs[] = array(
		! empty( $state['lazy_images'] ),
		! empty( $state['lazy_images'] )
			? __( 'Lazy Images is on — images/iframes load lazily.', 'zymarg-os' )
			: __( 'Turn on Lazy Images so off-screen images load only when needed.', 'zymarg-os' )
	);
	if ( version_compare( $php_v, '8.0', '<' ) ) {
		$recs[] = array( false, __( 'PHP is below 8.0 — ask your host to upgrade for a meaningful speed boost.', 'zymarg-os' ) );
	} else {
		$recs[] = array( true, sprintf( /* translators: %s php version */ __( 'PHP %s — modern and fast.', 'zymarg-os' ), $php_v ) );
	}
	$recs[] = array(
		true,
		__( 'Switch off any modules you do not use (below) so their CSS/JS never loads.', 'zymarg-os' )
	);
	?>
	<div class="wrap zymarg-admin zymarg-welcome zperf">
		<h1>
			<?php if ( function_exists( 'zymarg_discovery_spark' ) ) { echo zymarg_discovery_spark( array( 'size' => 'lg' ) ); } // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<?php esc_html_e( 'Performance', 'zymarg-os' ); ?>
			<span class="zymarg-welcome__v">v<?php echo esc_html( ZYMARG_OS_VERSION ); ?></span>
		</h1>
		<p class="zymarg-welcome__intro"><?php esc_html_e( 'A detailed look at what your theme loads and how to keep it lightning fast. ZYMARG OS only loads the CSS/JS a page actually needs.', 'zymarg-os' ); ?></p>

		<div class="zperf-grid">

			<!-- Environment -->
			<section class="zperf-card">
				<h2><?php esc_html_e( 'Environment', 'zymarg-os' ); ?></h2>
				<table class="zperf-table">
					<tr><td><?php esc_html_e( 'Theme version', 'zymarg-os' ); ?></td><td><?php echo esc_html( $theme->get( 'Version' ) ); ?></td></tr>
					<tr><td><?php esc_html_e( 'WordPress', 'zymarg-os' ); ?></td><td><?php echo esc_html( $wp_v ); ?></td></tr>
					<tr><td><?php esc_html_e( 'PHP', 'zymarg-os' ); ?></td><td><?php echo esc_html( $php_v ); ?> <?php echo zymarg_os_perf_pill( version_compare( $php_v, '8.0', '>=' ), version_compare( $php_v, '8.0', '>=' ) ? __( 'Modern', 'zymarg-os' ) : __( 'Old', 'zymarg-os' ) ); // phpcs:ignore ?></td></tr>
					<tr><td><?php esc_html_e( 'Memory limit', 'zymarg-os' ); ?></td><td><?php echo esc_html( (string) $mem ); ?></td></tr>
					<tr><td><?php esc_html_e( 'HTTPS', 'zymarg-os' ); ?></td><td><?php echo zymarg_os_perf_pill( $https, $https ? __( 'Yes', 'zymarg-os' ) : __( 'No', 'zymarg-os' ) ); // phpcs:ignore ?></td></tr>
					<tr><td><?php esc_html_e( 'Page caching', 'zymarg-os' ); ?></td><td><?php echo zymarg_os_perf_pill( $cache, $cache ? $cache_name : __( 'Not detected', 'zymarg-os' ) ); // phpcs:ignore ?></td></tr>
					<tr><td><?php esc_html_e( 'WP_DEBUG', 'zymarg-os' ); ?></td><td><?php echo zymarg_os_perf_pill( ! $debug, $debug ? __( 'On (turn off on live)', 'zymarg-os' ) : __( 'Off', 'zymarg-os' ) ); // phpcs:ignore ?></td></tr>
				</table>
			</section>

			<!-- Integrations -->
			<section class="zperf-card">
				<h2><?php esc_html_e( 'Integrations', 'zymarg-os' ); ?></h2>
				<table class="zperf-table">
					<tr><td>WooCommerce</td><td><?php echo zymarg_os_perf_pill( $woo, $woo ? __( 'Active', 'zymarg-os' ) : __( 'Missing', 'zymarg-os' ) ); // phpcs:ignore ?></td></tr>
					<tr><td>Dokan</td><td><?php echo zymarg_os_perf_pill( $dokan, $dokan ? __( 'Active', 'zymarg-os' ) : __( 'Missing', 'zymarg-os' ) ); // phpcs:ignore ?></td></tr>
					<tr><td>ZYMARG Vendor Dashboard</td><td><?php echo zymarg_os_perf_pill( $vendor_dash, $vendor_dash ? __( 'Active', 'zymarg-os' ) : __( 'Missing', 'zymarg-os' ) ); // phpcs:ignore ?></td></tr>
					<tr><td>ZYMARG Reviews Engine</td><td><?php echo zymarg_os_perf_pill( $reviews, $reviews ? __( 'Active', 'zymarg-os' ) : __( 'Missing', 'zymarg-os' ) ); // phpcs:ignore ?></td></tr>
					<tr><td>ZYMARG Login &amp; Security</td><td><?php echo zymarg_os_perf_pill( $zls, $zls ? __( 'Active', 'zymarg-os' ) : __( 'Fallback (theme login)', 'zymarg-os' ) ); // phpcs:ignore ?></td></tr>
				</table>
				<?php if ( ! $woo || ! $dokan || ! $vendor_dash || ! $reviews || ! $zls ) : ?>
					<p style="margin-top:10px;"><a class="button button-primary" href="<?php echo esc_url( self_admin_url( 'plugin-install.php' ) ); ?>"><?php esc_html_e( 'Add the missing plugins', 'zymarg-os' ); ?></a></p>
				<?php endif; ?>
			</section>

			<!-- ZYMARG plugin suite: inventory for support, NOT requirements -->
			<?php
			$suite    = function_exists( 'zymarg_os_zymarg_suite' ) ? zymarg_os_zymarg_suite() : array();
			$suite_on = 0;
			foreach ( $suite as $suite_row ) {
				if ( 'active' === $suite_row['status'] ) {
					$suite_on++;
				}
			}
			?>
			<?php if ( ! empty( $suite ) ) : ?>
			<section class="zperf-card zperf-card--wide">
				<h2>
					<?php esc_html_e( 'ZYMARG plugin suite', 'zymarg-os' ); ?>
					<span class="zperf-sub"><?php echo esc_html( sprintf( /* translators: 1: active count, 2: total count */ __( '%1$d of %2$d active', 'zymarg-os' ), (int) $suite_on, count( $suite ) ) ); ?></span>
				</h2>
				<p class="zperf-desc"><?php esc_html_e( 'Every ZYMARG plugin this site expects, read straight from the installed plugin headers. This is an inventory for support - when a customer reports a bug, this tells you what was installed, what was switched on, and at what version. Only the five under Integrations are required, so "Not installed" here is not an error.', 'zymarg-os' ); ?></p>
				<table class="zperf-table">
					<thead><tr><th><?php esc_html_e( 'Plugin', 'zymarg-os' ); ?></th><th><?php esc_html_e( 'Version', 'zymarg-os' ); ?></th><th><?php esc_html_e( 'Status', 'zymarg-os' ); ?></th></tr></thead>
					<tbody>
					<?php foreach ( $suite as $suite_row ) : ?>
						<tr>
							<td><?php echo esc_html( $suite_row['name'] ); ?><?php if ( ! empty( $suite_row['extra'] ) ) : ?><span class="zperf-mod-desc"><?php esc_html_e( 'Installed, but not on the expected list', 'zymarg-os' ); ?></span><?php endif; ?></td>
							<td><?php echo '' !== $suite_row['version'] ? esc_html( $suite_row['version'] ) : '&mdash;'; ?></td>
							<td>
								<?php
								if ( 'active' === $suite_row['status'] ) {
									echo zymarg_os_perf_pill( true, __( 'Active', 'zymarg-os' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
								} elseif ( 'inactive' === $suite_row['status'] ) {
									echo zymarg_os_perf_pill( false, __( 'Installed, switched off', 'zymarg-os' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
								} else {
									echo zymarg_os_perf_pill( false, __( 'Not installed', 'zymarg-os' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
								}
								?>
							</td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</section>
			<?php endif; ?>

			<!-- Modules -->
			<section class="zperf-card zperf-card--wide">
				<h2>
					<?php esc_html_e( 'Modules', 'zymarg-os' ); ?>
					<span class="zperf-sub"><?php echo esc_html( sprintf( /* translators: 1: on, 2: total */ __( '%1$d of %2$d on', 'zymarg-os' ), (int) $on_count, count( $modules ) ) ); ?></span>
				</h2>
				<p class="zperf-desc"><?php esc_html_e( 'Each module only loads its code when on. Switch off anything you do not use to keep pages lean.', 'zymarg-os' ); ?></p>
				<table class="zperf-table zperf-table--modules">
					<?php foreach ( $modules as $key => $meta ) : ?>
						<tr>
							<td><strong><?php echo esc_html( $meta['label'] ); ?></strong><span class="zperf-mod-desc"><?php echo esc_html( $meta['description'] ); ?></span></td>
							<td><?php echo zymarg_os_perf_pill( ! empty( $state[ $key ] ) ); // phpcs:ignore ?></td>
						</tr>
					<?php endforeach; ?>
				</table>
				<p style="margin-top:12px;"><a class="button" href="<?php echo esc_url( $mods_url ); ?>"><?php esc_html_e( 'Manage modules', 'zymarg-os' ); ?></a></p>
			</section>

			<!-- Asset loading -->
			<section class="zperf-card zperf-card--wide">
				<h2><?php esc_html_e( 'What loads, and when', 'zymarg-os' ); ?></h2>
				<p class="zperf-desc"><?php esc_html_e( 'ZYMARG OS uses conditional (lazy) asset loading — stylesheets and scripts are only enqueued on the pages that need them.', 'zymarg-os' ); ?></p>
				<table class="zperf-table zperf-table--assets">
					<thead><tr><th><?php esc_html_e( 'Asset', 'zymarg-os' ); ?></th><th><?php esc_html_e( 'Loads', 'zymarg-os' ); ?></th></tr></thead>
					<tbody>
					<?php foreach ( $assets as $row ) : ?>
						<tr><td><?php echo esc_html( $row[0] ); ?><?php echo $row[2] ? '<span class="zperf-mod-desc">' . esc_html( $row[2] ) . '</span>' : ''; // phpcs:ignore ?></td><td><?php echo esc_html( $row[1] ); ?></td></tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</section>

			<!-- Recommendations -->
			<section class="zperf-card zperf-card--wide">
				<h2><?php esc_html_e( 'Recommendations', 'zymarg-os' ); ?></h2>
				<ul class="zperf-recs">
					<?php foreach ( $recs as $rec ) : ?>
						<li class="<?php echo $rec[0] ? 'is-ok' : 'is-warn'; ?>"><span class="zperf-rec-ico"><?php echo $rec[0] ? '&#10003;' : '&#33;'; ?></span><?php echo esc_html( $rec[1] ); ?></li>
					<?php endforeach; ?>
				</ul>
			</section>

		</div>
	</div>

	<style>
		/* Header styled by assets/css/admin-brand.css — see v5.27.9. */
		.zperf-grid { display:grid; grid-template-columns:1fr 1fr; gap:20px; margin-top:16px; max-width:1100px; }
		.zperf-card--wide { grid-column:1 / -1; }
		@media (max-width:900px){ .zperf-grid { grid-template-columns:1fr; } }
		.zperf-card { background:#fff; border:1px solid #d8bfd3; border-radius:12px; padding:20px 22px; box-shadow:0 8px 30px rgba(53,0,61,.06); }
		.zperf-card h2 { margin-top:0; color:#36003d; display:flex; align-items:center; gap:10px; }
		.zperf-sub { font-size:12px; font-weight:600; color:#9500a5; background:#faf2fb; border:1px solid #e7c9e6; border-radius:999px; padding:2px 10px; }
		.zperf-desc { color:#534152; font-size:13px; margin:.2em 0 1em; }
		.zperf-table { width:100%; border-collapse:collapse; }
		.zperf-table td, .zperf-table th { padding:9px 6px; border-bottom:1px solid #f0e6ef; text-align:left; vertical-align:top; font-size:14px; }
		.zperf-table th { color:#36003d; }
		.zperf-mod-desc { display:block; color:#857183; font-size:12px; margin-top:2px; }
		.zperf-pill { display:inline-block; font-size:12px; font-weight:600; border-radius:999px; padding:2px 10px; }
		.zperf-pill.is-on { background:#e6f6ec; color:#0a7d33; }
		.zperf-pill.is-off { background:#f3eef2; color:#857183; }
		.zperf-recs { margin:0; padding:0; list-style:none; }
		.zperf-recs li { display:flex; align-items:flex-start; gap:10px; padding:8px 0; border-bottom:1px solid #f0e6ef; color:#36003d; font-size:14px; }
		.zperf-rec-ico { flex:0 0 22px; width:22px; height:22px; display:inline-flex; align-items:center; justify-content:center; border-radius:50%; font-weight:700; font-size:13px; }
		.zperf-recs li.is-ok .zperf-rec-ico { background:#e6f6ec; color:#0a7d33; }
		.zperf-recs li.is-warn .zperf-rec-ico { background:#fcebe9; color:#b3261e; }
	</style>
	<?php
}
