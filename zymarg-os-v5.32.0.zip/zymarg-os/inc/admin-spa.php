<?php
/**
 * ZYMARG OS — AJAX navigation for the ZYMARG OS admin menu.
 *
 * WordPress's admin sidebar is plain links, so every ZYMARG OS screen was a
 * full page load. This file enqueues a small router (assets/js/admin-spa.js)
 * that fetches the next screen and swaps #wpbody-content instead.
 *
 * SAFETY: only the slugs returned by zymarg_os_admin_spa_pages() are routed.
 * Screens that must perform real browser requests are intentionally left out:
 *
 *   - Customize            leaves wp-admin entirely (customize.php)
 *   - Update / Upload Theme  multipart POST to update.php
 *   - Plugins              core plugin install/activate flows
 *   - Import / Export      file uploads and long-running jobs
 *
 * Those four keep loading the normal way. Everything else navigates instantly.
 *
 * @package ZYMARG_OS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin page slugs that are safe to load over AJAX.
 *
 * Filter with 'zymarg_os_admin_spa_pages' to add or remove screens. Return an
 * empty array to switch the router off completely.
 *
 * @return array List of ?page= slugs.
 */
function zymarg_os_admin_spa_pages() {
	$pages = array(
		'zymarg-os',                 // Welcome.
		'zymarg-os-help',            // Help.
		'zymarg-os-performance',     // Performance.
		'zymarg-os-toast',           // Toast Notification.
		'zymarg-os-product-card',    // Product Card.
		'zymarg-os-pages',           // Slugs & Pages.
		'zymarg-os-account',         // Account & Security.
		'zymarg-os-customers',       // Customers.
	);

	/**
	 * Filters the ZYMARG OS screens that use AJAX navigation.
	 *
	 * @param array $pages Admin page slugs.
	 */
	$pages = apply_filters( 'zymarg_os_admin_spa_pages', $pages );

	return array_values( array_unique( array_filter( array_map( 'strval', (array) $pages ) ) ) );
}

/**
 * Enqueue the admin router on ZYMARG OS screens.
 *
 * @param string $hook Current admin page hook suffix.
 * @return void
 */
function zymarg_os_admin_spa_assets( $hook ) {
	if ( false === strpos( (string) $hook, 'zymarg-os' ) ) {
		return;
	}

	$pages = zymarg_os_admin_spa_pages();
	if ( empty( $pages ) ) {
		return;
	}

	$current = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

	/*
	 * Only load the router on a screen it can actually route away from. On the
	 * excluded screens (Upload, Plugins, Import/Export) it stays absent, so
	 * there is no chance of it interfering with their uploads or POSTs.
	 */
	if ( '' === $current || ! in_array( $current, $pages, true ) ) {
		return;
	}

	$ver = defined( 'ZYMARG_OS_VERSION' ) ? ZYMARG_OS_VERSION : '1.0.0';

	wp_enqueue_style(
		'zymarg-os-admin-spa',
		ZYMARG_OS_URI . '/assets/css/admin-spa.css',
		wp_style_is( 'zymarg-os-admin-brand', 'registered' ) ? array( 'zymarg-os-admin-brand' ) : array(),
		$ver
	);

	wp_enqueue_script(
		'zymarg-os-admin-spa',
		ZYMARG_OS_URI . '/assets/js/admin-spa.js',
		array(),
		$ver,
		true
	);

	wp_localize_script(
		'zymarg-os-admin-spa',
		'ZymargAdminSPA',
		array(
			'pages'   => $pages,
			'current' => $current,
		)
	);
}
add_action( 'admin_enqueue_scripts', 'zymarg_os_admin_spa_assets', 40 );
