<?php
/**
 * ZYMARG OS - Custom 404 Design
 *
 * Lets the site owner replace the theme's 404 page with their own hand-written
 * standalone HTML document, the same way the ZYMARG Homepage plugin lets them
 * replace a homepage section.
 *
 * The approach is deliberately the same as that plugin's CustomSection class,
 * because the input is the same thing: a complete HTML file that opens and
 * works on its own in a browser. That is the easiest artefact for a human to
 * produce and preview, but a whole document cannot be dropped into the middle
 * of a WordPress page as-is.
 *
 * Two placement modes are offered, because a 404 page genuinely has two valid
 * shapes and the homepage does not:
 *
 *   FULL PAGE - the pasted document IS the response. Nothing is unwrapped and
 *   no CSS is rewritten, because there is no surrounding page to protect. This
 *   is the honest reading of "standalone", and it is what most handed-over 404
 *   designs expect (they are usually full-viewport, centred layouts).
 *
 *   INSIDE MY LAYOUT - the document is unwrapped and its CSS is confined to a
 *   wrapper, then rendered between the theme's header and footer. Here the
 *   surrounding page DOES need protecting, so the same three destructive
 *   things the homepage plugin guards against are guarded against here:
 *     1. Document scaffolding (<!DOCTYPE>, <html>, <head>, <body>) is removed.
 *     2. A universal reset such as `* { margin: 0 }` is confined to the
 *        wrapper so it cannot strip the site header, menu and footer.
 *     3. `html, body { overflow: hidden; height: 100dvh }` is neutralised,
 *        because otherwise the whole page stops scrolling.
 *
 * Scripts are allowed, matching the homepage plugin: real 404 designs animate,
 * and only users who can already edit theme options may save here, so
 * forbidding <script> would prevent nothing while breaking the use case.
 * Filter zymarg_os_404_allow_scripts to false to strip them anyway.
 *
 * @package ZYMARG_OS
 * @since   5.20.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Option holding the 404 design settings.
 */
const ZYMARG_OS_404_OPTION = 'zymarg_os_404_design';

/**
 * CSS class the pasted design is scoped to in "inside my layout" mode.
 */
const ZYMARG_OS_404_SCOPE = 'zymarg-404-custom';

/**
 * Declarations dropped when they appear on html / body / :root.
 *
 * Everything else on those selectors (background, colour, font) is harmless
 * once it is retargeted at the wrapper. These are the properties that reach
 * outside the design and break the surrounding page.
 *
 * @return array
 */
function zymarg_os_404_unsafe_root_props() {
	return array(
		'overflow',
		'overflow-x',
		'overflow-y',
		'height',
		'min-height',
		'max-height',
		'width',
		'min-width',
		'max-width',
		'position',
		'display',
		'margin',
		'padding',
		'justify-content',
		'align-items',
		'inset',
		'top',
		'right',
		'bottom',
		'left',
	);
}

/**
 * Read the saved 404 design settings.
 *
 * @return array{source:string,mode:string,html:string,css:string}
 */
function zymarg_os_404_settings() {
	$saved = get_option( ZYMARG_OS_404_OPTION, array() );

	if ( ! is_array( $saved ) ) {
		$saved = array();
	}

	return array(
		'source' => ( isset( $saved['source'] ) && 'custom' === $saved['source'] ) ? 'custom' : 'theme',
		'mode'   => ( isset( $saved['mode'] ) && 'inline' === $saved['mode'] ) ? 'inline' : 'full',
		'html'   => isset( $saved['html'] ) ? (string) $saved['html'] : '',
		'css'    => isset( $saved['css'] ) ? (string) $saved['css'] : '',
	);
}

/**
 * Should the custom design render?
 *
 * An empty code box counts as inactive, so switching the dropdown to "my own
 * design" before pasting anything cannot blank out the 404 page.
 *
 * @return bool
 */
function zymarg_os_404_is_active() {
	$settings = zymarg_os_404_settings();

	if ( 'custom' !== $settings['source'] ) {
		return false;
	}

	return '' !== trim( $settings['html'] );
}

/* ---------------------------------------------------------------------- *
 * Document adaptation
 * ---------------------------------------------------------------------- */

/**
 * Collect every stylesheet found in the document, in source order.
 *
 * @param string $code Raw pasted document.
 * @return string
 */
function zymarg_os_404_extract_css( $code ) {
	if ( ! preg_match_all( '#<style\b[^>]*>(.*?)</style>#is', (string) $code, $matches ) ) {
		return '';
	}

	return implode( "\n", $matches[1] );
}

/**
 * Reduce a standalone document to the markup that belongs inside a page.
 *
 * <link rel="stylesheet"> and preconnect tags from the head are kept, because
 * browsers accept those in the body and dropping them would silently break a
 * design that loads its font or icon set that way.
 *
 * @param string $code Raw pasted document.
 * @return string
 */
function zymarg_os_404_extract_markup( $code ) {
	$code  = (string) $code;
	$links = '';

	if ( preg_match( '#<head\b[^>]*>(.*?)</head>#is', $code, $head )
		&& preg_match_all( '#<link\b[^>]*>#i', $head[1], $found )
	) {
		foreach ( $found[0] as $tag ) {
			if ( false !== stripos( $tag, 'stylesheet' ) || false !== stripos( $tag, 'preconnect' ) ) {
				$links .= $tag;
			}
		}
	}

	// Prefer the body contents when the document has one.
	if ( preg_match( '#<body\b[^>]*>(.*)</body>#is', $code, $body ) ) {
		$code = $body[1];
	}

	// Elements whose content must go, not just their tags.
	$code = preg_replace( '#<style\b[^>]*>.*?</style>#is', '', $code );
	$code = preg_replace( '#<title\b[^>]*>.*?</title>#is', '', (string) $code );
	$code = preg_replace( '#<!DOCTYPE[^>]*>#i', '', (string) $code );
	$code = preg_replace( '#<!--\[if.*?<!\[endif\]-->#is', '', (string) $code );

	// Remaining document-level tags carry no meaning inside a page.
	$code = preg_replace( '#</?(?:html|head|body|meta|base|title)\b[^>]*>#i', '', (string) $code );

	return $links . trim( (string) $code );
}

/**
 * Remove script elements and inline event handlers.
 *
 * Only used when zymarg_os_404_allow_scripts is filtered to false.
 *
 * @param string $html Markup.
 * @return string
 */
function zymarg_os_404_strip_scripts( $html ) {
	$html = preg_replace( '#<script\b[^>]*>.*?</script>#is', '', (string) $html );
	$html = preg_replace( '#<script\b[^>]*/?>#i', '', (string) $html );
	$html = preg_replace( '#\son[a-z]+\s*=\s*"[^"]*"#i', '', (string) $html );
	$html = preg_replace( "#\son[a-z]+\s*=\s*'[^']*'#i", '', (string) $html );

	return (string) $html;
}

/**
 * Drop the declarations that would escape the wrapper via html/body/:root.
 *
 * @param string $selector Selector the block belongs to.
 * @param string $body     Declaration block contents.
 * @return string
 */
function zymarg_os_404_filter_declarations( $selector, $body ) {
	$targets_root = (bool) preg_match( '#(^|,)\s*(html|body|:root)\s*(,|$)#i', (string) $selector );

	if ( ! $targets_root ) {
		return (string) $body;
	}

	$unsafe = zymarg_os_404_unsafe_root_props();
	$kept   = array();

	foreach ( explode( ';', (string) $body ) as $declaration ) {
		if ( '' === trim( $declaration ) ) {
			continue;
		}

		$parts = explode( ':', $declaration, 2 );

		if ( count( $parts ) < 2 ) {
			continue;
		}

		$property = strtolower( trim( $parts[0] ) );

		if ( in_array( $property, $unsafe, true ) ) {
			continue;
		}

		$kept[] = trim( $declaration );
	}

	return empty( $kept ) ? '' : implode( '; ', $kept ) . ';';
}

/**
 * Rewrite one selector so it cannot escape the wrapper.
 *
 * html / body / :root become the wrapper itself, because inside the author's
 * standalone file `body` WAS the page - that is what they actually meant.
 *
 * @param string $selector Single selector.
 * @param string $scope    Wrapper class, no leading dot.
 * @return string
 */
function zymarg_os_404_scope_selector( $selector, $scope ) {
	$selector = trim( (string) $selector );

	if ( '' === $selector ) {
		return '';
	}

	// Never rewrite at-rule preludes such as `from`, `to`, `0%`.
	if ( preg_match( '#^(?:from|to|\d+%)$#i', $selector ) ) {
		return $selector;
	}

	if ( preg_match( '#^(?:html|body|:root)$#i', $selector ) ) {
		return '.' . $scope;
	}

	// `body .thing` and `html > .thing` lose their document-level part.
	$selector = preg_replace( '#^\s*(?:html|body|:root)\s*([>+~]?)\s*#i', '', $selector );

	if ( '' === trim( (string) $selector ) ) {
		return '.' . $scope;
	}

	// A universal reset must stop at the wrapper's own subtree.
	if ( '*' === trim( (string) $selector ) ) {
		return '.' . $scope . ', .' . $scope . ' *';
	}

	return '.' . $scope . ' ' . trim( (string) $selector );
}

/**
 * Scope a stylesheet to the wrapper.
 *
 * @param string $css   Raw CSS.
 * @param string $scope Wrapper class, no leading dot.
 * @return string
 */
function zymarg_os_404_scope_css( $css, $scope ) {
	$css = (string) $css;

	if ( '' === trim( $css ) ) {
		return '';
	}

	// Strip comments so braces inside them cannot confuse the parser.
	$css = (string) preg_replace( '#/\*.*?\*/#s', '', $css );

	$out    = '';
	$offset = 0;
	$length = strlen( $css );

	while ( $offset < $length ) {
		$brace = strpos( $css, '{', $offset );

		if ( false === $brace ) {
			break;
		}

		$prelude = trim( substr( $css, $offset, $brace - $offset ) );

		/*
		 * Nested at-rules (@media, @supports, @layer) wrap further rules, so
		 * their contents are scoped recursively. @keyframes and @font-face do
		 * not contain selectors and are copied through untouched.
		 */
		if ( 0 === strpos( $prelude, '@' ) ) {
			$depth = 0;
			$end   = $brace;

			for ( $i = $brace; $i < $length; $i++ ) {
				if ( '{' === $css[ $i ] ) {
					$depth++;
				} elseif ( '}' === $css[ $i ] ) {
					$depth--;

					if ( 0 === $depth ) {
						$end = $i;
						break;
					}
				}
			}

			$inner = substr( $css, $brace + 1, $end - $brace - 1 );

			if ( preg_match( '#^@(?:media|supports|layer|container)#i', $prelude ) ) {
				$out .= $prelude . '{' . zymarg_os_404_scope_css( $inner, $scope ) . '}';
			} else {
				$out .= $prelude . '{' . $inner . '}';
			}

			$offset = $end + 1;

			continue;
		}

		$close = strpos( $css, '}', $brace );

		if ( false === $close ) {
			break;
		}

		$body = substr( $css, $brace + 1, $close - $brace - 1 );
		$body = zymarg_os_404_filter_declarations( $prelude, $body );

		if ( '' !== trim( $body ) ) {
			$scoped = array();

			foreach ( explode( ',', $prelude ) as $single ) {
				$rewritten = zymarg_os_404_scope_selector( $single, $scope );

				if ( '' !== $rewritten ) {
					$scoped[] = $rewritten;
				}
			}

			if ( ! empty( $scoped ) ) {
				$out .= implode( ', ', $scoped ) . '{' . $body . '}';
			}
		}

		$offset = $close + 1;
	}

	return $out;
}

/* ---------------------------------------------------------------------- *
 * Front-end rendering
 * ---------------------------------------------------------------------- */

/**
 * Render the custom 404 design and stop.
 *
 * Runs late on template_redirect so anything that legitimately redirects a
 * missing URL - including the Slugs & Pages rules - has already had its turn.
 * WordPress has already sent the 404 status header by this point, during query
 * parsing, so the status is correct without repeating it.
 *
 * @return void
 */
function zymarg_os_404_render() {
	if ( is_admin() || wp_doing_ajax() || ! is_404() || ! zymarg_os_404_is_active() ) {
		return;
	}

	$settings = zymarg_os_404_settings();
	$code     = $settings['html'];
	$extra    = trim( $settings['css'] );

	// Belt and braces: the header was sent during query parsing, but a plugin
	// may have interfered, and a 404 page returning 200 is an SEO defect.
	status_header( 404 );
	nocache_headers();

	if ( 'full' === $settings['mode'] ) {
		/*
		 * Full page: the document is the response, so it is echoed exactly as
		 * written. No unwrapping and no CSS rewriting, because there is no
		 * surrounding page to protect - which is the whole point of this mode.
		 */
		if ( ! apply_filters( 'zymarg_os_404_allow_scripts', true ) ) {
			$code = zymarg_os_404_strip_scripts( $code );
		}

		if ( '' !== $extra ) {
			// Appended last so the extra box wins any conflict with the file.
			if ( false !== stripos( $code, '</head>' ) ) {
				$code = preg_replace( '#</head>#i', '<style>' . $extra . '</style></head>', $code, 1 );
			} else {
				$code .= '<style>' . $extra . '</style>';
			}
		}

		/**
		 * Filter the full-page 404 document before it is sent.
		 *
		 * @since 5.20.0
		 * @param string $code Complete HTML document.
		 */
		echo apply_filters( 'zymarg_os_404_full_html', $code ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Author-supplied document, saved by a user who can edit theme options.

		exit;
	}

	/*
	 * Inside my layout: unwrap the document and confine its CSS, then render it
	 * between the theme's own header and footer.
	 */
	$css  = zymarg_os_404_extract_css( $code );
	$html = zymarg_os_404_extract_markup( $code );

	if ( '' !== $extra ) {
		$css .= "\n" . $extra;
	}

	if ( ! apply_filters( 'zymarg_os_404_allow_scripts', true ) ) {
		$html = zymarg_os_404_strip_scripts( $html );
	}

	$css = zymarg_os_404_scope_css( $css, ZYMARG_OS_404_SCOPE );

	get_header();

	echo '<div class="' . esc_attr( ZYMARG_OS_404_SCOPE ) . '">';

	if ( '' !== trim( $css ) ) {
		/*
		 * Printed inline rather than enqueued: this CSS is per design, changes
		 * whenever the box is edited, and has no stable file on disk.
		 */
		echo '<style>' . $css . '</style>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Scoped stylesheet built above.
	}

	echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Author-supplied markup, saved by a user who can edit theme options.
	echo '</div>';

	get_footer();

	exit;
}
add_action( 'template_redirect', 'zymarg_os_404_render', 99 );

/* ---------------------------------------------------------------------- *
 * Admin panel (rendered inside the Slugs & Pages screen)
 * ---------------------------------------------------------------------- */

/**
 * Sanitise and store the 404 design from a submitted payload.
 *
 * Called by the Slugs & Pages save handler so both the URL rules and this
 * design are written by one Save button.
 *
 * The HTML and CSS are stored raw on purpose. Running them through
 * sanitize_text_field() or wp_kses_post() would strip <form>, <svg>, <script>
 * and every data-* attribute, which is exactly the markup a handed-over design
 * is made of - the ZYMARG Homepage plugin learned this the hard way with its
 * header_html field.
 *
 * @param array $posted Raw $_POST['zymarg_404'] payload, already unslashed.
 * @return void
 */
function zymarg_os_404_save( $posted ) {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		return;
	}

	if ( ! is_array( $posted ) ) {
		$posted = array();
	}

	update_option(
		ZYMARG_OS_404_OPTION,
		array(
			'source' => ( isset( $posted['source'] ) && 'custom' === $posted['source'] ) ? 'custom' : 'theme',
			'mode'   => ( isset( $posted['mode'] ) && 'inline' === $posted['mode'] ) ? 'inline' : 'full',
			'html'   => isset( $posted['html'] ) ? (string) $posted['html'] : '',
			'css'    => isset( $posted['css'] ) ? (string) $posted['css'] : '',
		),
		false
	);
}

/**
 * Output the 404 design panel.
 *
 * @return void
 */
function zymarg_os_404_render_admin_panel() {
	$settings = zymarg_os_404_settings();
	$active   = zymarg_os_404_is_active();
	?>
	<details class="zymarg-registry__group zymarg-registry__group--404">
		<summary>
			<span class="zymarg-registry__group-name"><?php esc_html_e( '404 page design', 'zymarg-os' ); ?></span>
			<span class="zymarg-registry__state <?php echo $active ? 'is-moved' : 'is-live'; ?>">
				<?php
				if ( $active ) {
					echo esc_html(
						'full' === $settings['mode']
							? __( 'My design - full page', 'zymarg-os' )
							: __( 'My design - in layout', 'zymarg-os' )
					);
				} else {
					esc_html_e( 'Theme design', 'zymarg-os' );
				}
				?>
			</span>
		</summary>

		<p class="zymarg-registry__note zymarg-registry__note--block">
			<?php esc_html_e( 'When a visitor hits a URL that does not exist - including any URL you switched off above and set to "Show 404" - this is what they see.', 'zymarg-os' ); ?>
		</p>

		<div class="zymarg-registry__field">
			<label for="zymarg_404_source"><?php esc_html_e( 'Design', 'zymarg-os' ); ?></label>
			<select id="zymarg_404_source" name="zymarg_404[source]">
				<option value="theme" <?php selected( 'theme', $settings['source'] ); ?>>
					<?php esc_html_e( 'Theme design (404.php)', 'zymarg-os' ); ?>
				</option>
				<option value="custom" <?php selected( 'custom', $settings['source'] ); ?>>
					<?php esc_html_e( 'My own HTML design', 'zymarg-os' ); ?>
				</option>
			</select>
		</div>

		<div class="zymarg-registry__field">
			<label for="zymarg_404_mode"><?php esc_html_e( 'Placement', 'zymarg-os' ); ?></label>
			<select id="zymarg_404_mode" name="zymarg_404[mode]">
				<option value="full" <?php selected( 'full', $settings['mode'] ); ?>>
					<?php esc_html_e( 'Full page - my file is the whole page', 'zymarg-os' ); ?>
				</option>
				<option value="inline" <?php selected( 'inline', $settings['mode'] ); ?>>
					<?php esc_html_e( 'Inside my layout - keep site header and footer', 'zymarg-os' ); ?>
				</option>
			</select>
			<p class="zymarg-registry__hint zymarg-registry__hint--field">
				<?php esc_html_e( 'Full page sends your file exactly as written - nothing is altered, and your site header and footer do not appear. Inside my layout removes the document wrapper and confines your CSS to the 404 area so it cannot affect your header, footer or menu.', 'zymarg-os' ); ?>
			</p>
		</div>

		<div class="zymarg-registry__field">
			<label for="zymarg_404_html"><?php esc_html_e( 'My HTML design', 'zymarg-os' ); ?></label>
			<textarea id="zymarg_404_html"
				name="zymarg_404[html]"
				rows="12"
				spellcheck="false"
				class="zymarg-registry__code"
				placeholder="<?php esc_attr_e( 'Paste your complete HTML file here...', 'zymarg-os' ); ?>"><?php echo esc_textarea( $settings['html'] ); ?></textarea>
			<p class="zymarg-registry__hint zymarg-registry__hint--field">
				<?php esc_html_e( 'Paste a complete HTML file, exactly as your developer wrote it. Leave this empty, or set Design back to the theme design, to restore the built-in 404 page. Your code stays saved either way.', 'zymarg-os' ); ?>
			</p>
		</div>

		<div class="zymarg-registry__field">
			<label for="zymarg_404_css"><?php esc_html_e( 'Extra CSS (optional)', 'zymarg-os' ); ?></label>
			<textarea id="zymarg_404_css"
				name="zymarg_404[css]"
				rows="6"
				spellcheck="false"
				class="zymarg-registry__code"><?php echo esc_textarea( $settings['css'] ); ?></textarea>
			<p class="zymarg-registry__hint zymarg-registry__hint--field">
				<?php esc_html_e( 'Applied after the CSS inside your HTML file, so it wins any conflict.', 'zymarg-os' ); ?>
			</p>
		</div>

		<p class="zymarg-registry__note zymarg-registry__note--block">
			<?php esc_html_e( 'Scripts in your file are kept, because real designs need them. Preview by visiting any address that does not exist on your site.', 'zymarg-os' ); ?>
		</p>
	</details>
	<?php
}
