<?php
/**
 * Customer access log — who looked at whose account.
 *
 * WHY THIS EXISTS
 *   The Customers screen shows one person's email, phone, addresses and order
 *   history to a member of staff. That is exactly the tool a support team needs
 *   and exactly the tool that gets abused: the most common data leak in a large
 *   marketplace is not an attacker, it is a support agent looking up someone
 *   they know personally. A visible log is what deters that, and it is what
 *   lets you answer "who accessed this customer's data" when a customer,
 *   a regulator (PDPA here, GDPR for any EU buyer) or a lawyer asks.
 *
 * DESIGN
 *   A dedicated table, not user meta. Access rows are append-only, are queried
 *   by staff as well as by customer, and will outnumber customers over time —
 *   all three are wrong for a serialised meta blob.
 *
 *   Repeat views are throttled (see zymarg_os_customer_access_throttle) so
 *   clicking between tabs on one customer records one visit, not ten.
 *
 *   Rows are pruned on a daily cron after a retention window. Keeping access
 *   records forever is its own privacy problem.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Schema version. Bump to trigger dbDelta on the next admin request.
 */
const ZYMARG_OS_CUSTOMER_ACCESS_DB_VERSION = '1.0.0';

/**
 * Option holding the installed schema version.
 */
const ZYMARG_OS_CUSTOMER_ACCESS_DB_OPTION = 'zymarg_os_customer_access_db';

/**
 * Fully-prefixed access log table name.
 *
 * @return string
 */
function zymarg_os_customer_access_table() {
	global $wpdb;

	return $wpdb->prefix . 'zymarg_customer_access';
}

/**
 * How many seconds before the same staff member viewing the same customer is
 * recorded again.
 *
 * @return int
 */
function zymarg_os_customer_access_throttle() {
	return (int) apply_filters( 'zymarg_os_customer_access_throttle', 300 );
}

/**
 * How many days of access history to keep.
 *
 * @return int
 */
function zymarg_os_customer_access_retention_days() {
	return (int) apply_filters( 'zymarg_os_customer_access_retention_days', 365 );
}

/* ======================================================================
   1. SCHEMA
   ====================================================================== */

/**
 * Create or upgrade the access log table.
 *
 * @return void
 */
function zymarg_os_customer_access_install() {
	global $wpdb;

	require_once ABSPATH . 'wp-admin/includes/upgrade.php';

	$table   = zymarg_os_customer_access_table();
	$collate = $wpdb->get_charset_collate();

	/*
	 * Indexes are chosen for the two questions actually asked:
	 * "who viewed this customer" (customer_id, viewed_at) and
	 * "what did this staff member look at" (staff_id, viewed_at).
	 */
	$sql = "CREATE TABLE {$table} (
		id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
		customer_id bigint(20) unsigned NOT NULL DEFAULT 0,
		staff_id bigint(20) unsigned NOT NULL DEFAULT 0,
		context varchar(40) NOT NULL DEFAULT 'view',
		ip varchar(100) NOT NULL DEFAULT '',
		viewed_at datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
		PRIMARY KEY  (id),
		KEY customer_viewed (customer_id, viewed_at),
		KEY staff_viewed (staff_id, viewed_at),
		KEY viewed_at (viewed_at)
	) {$collate};";

	dbDelta( $sql );

	update_option( ZYMARG_OS_CUSTOMER_ACCESS_DB_OPTION, ZYMARG_OS_CUSTOMER_ACCESS_DB_VERSION );
}

/**
 * Install the table when missing or out of date.
 *
 * Runs on admin_init rather than on every request: this is admin-only data.
 *
 * @return void
 */
function zymarg_os_customer_access_maybe_install() {
	if ( get_option( ZYMARG_OS_CUSTOMER_ACCESS_DB_OPTION ) === ZYMARG_OS_CUSTOMER_ACCESS_DB_VERSION ) {
		return;
	}

	zymarg_os_customer_access_install();
}
add_action( 'admin_init', 'zymarg_os_customer_access_maybe_install' );
add_action( 'after_switch_theme', 'zymarg_os_customer_access_install' );

/* ======================================================================
   2. WRITING
   ====================================================================== */

/**
 * Record that a staff member viewed a customer's data.
 *
 * @param int    $customer_id Customer whose data was shown.
 * @param string $context     What was viewed, e.g. 'view', 'orders', 'search'.
 * @return bool True when a row was written.
 */
function zymarg_os_log_customer_access( $customer_id, $context = 'view' ) {
	global $wpdb;

	$customer_id = (int) $customer_id;
	$staff_id    = get_current_user_id();

	if ( $customer_id <= 0 || $staff_id <= 0 ) {
		return false;
	}

	// Looking at your own account is not a support access event.
	if ( $customer_id === $staff_id ) {
		return false;
	}

	if ( get_option( ZYMARG_OS_CUSTOMER_ACCESS_DB_OPTION ) !== ZYMARG_OS_CUSTOMER_ACCESS_DB_VERSION ) {
		zymarg_os_customer_access_install();
	}

	$table   = zymarg_os_customer_access_table();
	$context = substr( sanitize_key( $context ), 0, 40 );
	$now     = current_time( 'mysql', true );

	// Throttle: one row per staff/customer/context per window.
	$window = zymarg_os_customer_access_throttle();

	if ( $window > 0 ) {
		$since  = gmdate( 'Y-m-d H:i:s', strtotime( $now ) - $window );
		$recent = $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->prepare(
				"SELECT id FROM {$table} WHERE customer_id = %d AND staff_id = %d AND context = %s AND viewed_at >= %s LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$customer_id,
				$staff_id,
				$context,
				$since
			)
		);

		if ( $recent ) {
			return false;
		}
	}

	$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$table,
		array(
			'customer_id' => $customer_id,
			'staff_id'    => $staff_id,
			'context'     => $context,
			'ip'          => zymarg_os_customer_access_ip(),
			'viewed_at'   => $now,
		),
		array( '%d', '%d', '%s', '%s', '%s' )
	);

	/**
	 * Fires after a customer data access is recorded.
	 *
	 * Use this to forward access events to an external SIEM or alerting rule
	 * (for example, one agent viewing an unusual number of accounts per hour).
	 *
	 * @param int    $customer_id Customer viewed.
	 * @param int    $staff_id    Staff member who viewed.
	 * @param string $context     What was viewed.
	 */
	do_action( 'zymarg_os_customer_accessed', $customer_id, $staff_id, $context );

	return true;
}

/**
 * Requesting IP, trimmed and validated.
 *
 * @return string
 */
function zymarg_os_customer_access_ip() {
	if ( function_exists( 'zymarg_os_change_log_ip' ) ) {
		return (string) zymarg_os_change_log_ip();
	}

	$raw = isset( $_SERVER['REMOTE_ADDR'] ) ? wp_unslash( $_SERVER['REMOTE_ADDR'] ) : '';
	$ip  = filter_var( (string) $raw, FILTER_VALIDATE_IP );

	return $ip ? $ip : '';
}

/* ======================================================================
   3. READING
   ====================================================================== */

/**
 * Who has viewed this customer, newest first.
 *
 * @param int $customer_id Customer ID.
 * @param int $limit       Max rows.
 * @return array<int,object>
 */
function zymarg_os_get_customer_access_log( $customer_id, $limit = 20 ) {
	global $wpdb;

	$customer_id = (int) $customer_id;
	$limit       = max( 1, min( 200, (int) $limit ) );

	if ( $customer_id <= 0 ) {
		return array();
	}

	$table = zymarg_os_customer_access_table();

	$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->prepare(
			"SELECT * FROM {$table} WHERE customer_id = %d ORDER BY viewed_at DESC LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$customer_id,
			$limit
		)
	);

	return is_array( $rows ) ? $rows : array();
}

/**
 * What one staff member has been looking at, newest first.
 *
 * @param int $staff_id Staff user ID.
 * @param int $limit    Max rows.
 * @return array<int,object>
 */
function zymarg_os_get_staff_access_log( $staff_id, $limit = 50 ) {
	global $wpdb;

	$staff_id = (int) $staff_id;
	$limit    = max( 1, min( 500, (int) $limit ) );

	if ( $staff_id <= 0 ) {
		return array();
	}

	$table = zymarg_os_customer_access_table();

	$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->prepare(
			"SELECT * FROM {$table} WHERE staff_id = %d ORDER BY viewed_at DESC LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$staff_id,
			$limit
		)
	);

	return is_array( $rows ) ? $rows : array();
}

/**
 * Human label for an access row's actor.
 *
 * @param object $row Access row.
 * @return string
 */
function zymarg_os_customer_access_actor_label( $row ) {
	$staff_id = isset( $row->staff_id ) ? (int) $row->staff_id : 0;
	$staff    = $staff_id ? get_userdata( $staff_id ) : false;

	if ( ! $staff ) {
		return __( 'Removed account', 'zymarg-os' );
	}

	return $staff->display_name;
}

/* ======================================================================
   4. RETENTION
   ====================================================================== */

/**
 * Delete access rows older than the retention window.
 *
 * @return int Rows removed.
 */
function zymarg_os_customer_access_prune() {
	global $wpdb;

	$days = zymarg_os_customer_access_retention_days();

	if ( $days <= 0 ) {
		return 0;
	}

	$table  = zymarg_os_customer_access_table();
	$cutoff = gmdate( 'Y-m-d H:i:s', time() - ( $days * DAY_IN_SECONDS ) );

	$removed = $wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->prepare(
			"DELETE FROM {$table} WHERE viewed_at < %s LIMIT 5000", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$cutoff
		)
	);

	return (int) $removed;
}
add_action( 'zymarg_os_customer_access_prune_event', 'zymarg_os_customer_access_prune' );

/**
 * Schedule the daily prune.
 *
 * @return void
 */
function zymarg_os_customer_access_schedule() {
	if ( ! wp_next_scheduled( 'zymarg_os_customer_access_prune_event' ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'zymarg_os_customer_access_prune_event' );
	}
}
add_action( 'admin_init', 'zymarg_os_customer_access_schedule' );

/**
 * Clear the schedule when the theme is switched away.
 *
 * @return void
 */
function zymarg_os_customer_access_unschedule() {
	$next = wp_next_scheduled( 'zymarg_os_customer_access_prune_event' );

	if ( $next ) {
		wp_unschedule_event( $next, 'zymarg_os_customer_access_prune_event' );
	}
}
add_action( 'switch_theme', 'zymarg_os_customer_access_unschedule' );
