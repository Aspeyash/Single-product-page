<?php
/**
 * Dedicated ZYMARG OS admin menu.
 *
 * Adds a top-level "ZYMARG OS" menu (with a monochrome Discovery Spark icon) to
 * the dashboard sidebar — its own branded home — containing a Welcome screen,
 * the Help guide, and a quick link to the Customizer. Mirrors how WooCommerce /
 * Dokan / Elementor get their own space.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Return the sidebar menu icon — the official ZYMARG logo.
 *
 * White logo embedded inside an SVG data URI (transparent background). WordPress renders SVG menu
 * icons as a CSS background sized to 20px (same mechanism as the old v2.5.0
 * Spark icon), so it stays correctly sized instead of overflowing the row like
 * a raw PNG <img> does. No extra file ships with the theme.
 *
 * @return string SVG data URI.
 */
function zymarg_os_admin_menu_icon() {
	return 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2aWV3Qm94PSIwIDAgMjAgMjAiPjxpbWFnZSB4PSIxLjkxIiB5PSIxLjkxIiB3aWR0aD0iMTYuMTciIGhlaWdodD0iMTYuMTciIHhsaW5rOmhyZWY9ImRhdGE6aW1hZ2UvcG5nO2Jhc2U2NCxpVkJPUncwS0dnb0FBQUFOU1VoRVVnQUFBRUFBQUFCQUNBWUFBQUNxYVhIZUFBQUFDWEJJV1hNQUFBN0VBQUFPeEFHVkt3NGJBQUFHRGtsRVFWUjQydTJhYTRoVlZSVEhmOTR1Z3d3eURTSWlNUXhDSW1JbEVsTG1CNU9RVVV4TlRDUkVqRUxLSHBKYVJFa0VmakR3ZzVoSkR5SXhOUkV4NldGRG1ZNFZXRXowc0RJbHkvRnRtbHFHT3VZajU5K0hXUmQydTczUFBUUGU1cDZyczJERFBYYy96dm4vOTlwcnI3WDI3aUdKYTFueTN2Tk9ZUEMxUkVDT2ExeTZDZkNlMjdvMW9KdUE3aVhRclFIWHNoOXdOY3M1NEZmZ01IQVNPQTZjelYrRlM2QU4yQVUwQTl1Qkg0RTl3REdnQ2hnSmpBRkdBWVB6VjlIc2ZnQzhBMnl4R1M1SUwyQWljQzh3RnFoMjZyYjVCT3pKNExJWWFETVhrdjNBWW1BVmNOcXJ1eFdZRFV3eEVuejVGSmlBcEN5WHh4V1dNNUxtU2FxU2xMTlM2RE5NMG1ZbHkyWkoxWkxJTXZoSEl4Ky9ROUlBYXpOYTBsTkdRTFdrbHlWZExnSytVVkxQd251eUNuNVdCTWgyU2JVRytIa0RuSlBVVzlKWEtpN3ZtZGFRWlFKbVJzQ2ZrbFJ2YmVvbFRYZlV2eWtGK1BVKytDd1M4R0NDQ3MrSjlCbVhBdndhU2ZsUS95eUJuNUVBdmxWU2piVWJLbW1rMDI5eEVmQXJQU1A1cjVJVlYzZzZzQ0xCTlc5MnRybGh3QVNuN3UrRWNkOEFIa2h5OExKQXdMUWk0QUYrZG42ZkJ1cWQ1NlpJbjFlQWg0dDV0K1VtWUNxd01vWHpkZDc1ZlF3WTRqeHZNUTF4NVVYZ3NUU3VmVGtKbUFLc1NlbDV1bDdlWHFBdjBNZngvWmM0OVY4RGM5TitSSTh5cGNVbkErczZBUDRXNEdCQ20vN0FQaWN1dUw2SWJTaXJCa3dDMW5ZQS9EMUZ3UHM0cW9GK1dVMklqTGVacjByUjlnZmdEZ3RhM0psZURkenN0UjJSWURPU3BRdjMrWEdTTHFSd1dsb2x6UTk0YlFNbHRVaGE0ZjJmay9TTjAzOWZSNzZycThDUGxmUlhDdURMSk4wUTZEL1ZYT0VsQWFkbXZqZk9ncXdSMEZBRS9CRUQwU2ZRdDE3U0JnTi9Yd3J2OFlnRlM1a2dJRzhCUzJzRStKZVNwb1VDRkVmbEc0MkF1a0Q5UEEvOEpRdVBLVGNCVlJiT0hnaUF2bUNCeWZBckdMKzNrZUxLWlF1a0tEVUJOWklPV1JtWDB0RHRqcWo1YzVMNkJmcmtKSTIzK29jU05BSkpVeVFkRFpBNm83T0VodjVjS2VtRWZXeXQ4NklwQ1FQMXRYamJsMS9zNDZvaTVNNHpxMzFJMGpNUk8xQ0lBRU5wcnFOZVpGZ1NBbWFhTmE2eDFORXlLME1qZzB5VTlKdjNZYjliUGk4ZlVlR0ZadGdPMlB0aXN6NUkwdHBJbU53WTBhaVNMWUZwTnF2cnpaS0gxdnJTU1BLaGI2VDkwd2I4bEpQVURMMTdsS1d2UXNCUFhJbktkNFNBUmM1TFozbDExZWFRN1BUVWNXSmtySkdPYlZnZElTZ25hVkpDYnUrU2FXTHZVaHJ0emhMZ2xsWkpHeE5BTGJTWlBHckdMalRHYU0rYjh5MzhldHNXUzc1ckZkc0I2cXdzZFhhRFF2bmNjVVpDL1dzbGJUSVFUWkgxMnQvSWl3SGZrR0I3L25jQzNQSnE0QU5iRXRyWFdmNWVSbDQra3ZjL2srQVczOVVWYmpxbW1vV3lvQVFFOUxldDdiSVp1dEF1c0xGSVREQ3FxNEswdkJjNzExeGh1RnNIZkdJNXUwZUExNzM2UWNCR1lFRENJZWZkWGdoY01mY0Rhb0VQTFdhZkd3Qi9HOURvcExMS0RyNlFFaHZ2UEEreEpJUXJud0VmR1REL2c3YzZSRFlDRFphUTlITnl3NEZOQ1JwV0Z2Q2hoTWljaUdPVDVsRGpnSGxudnNFYllvNlB5bTN3WWphZ0ZMTEtTc2dtTk5yeWlNMzhCRWVUcnFwTFVqM3R4a1pkUXB2N3l3bStGRVp3aE8waSs0RnZ2YnBGZG93VmsvZUJ0OHQrTGhWd1hhdThNdDFpN2tJcHJQRmVGcGpJNG5oLzNSZTdxREE1QzRleW9WdGlGd1AvaGRMWU0yMUwrd040eTZ0N05zWHlPcHVGVTluTzJvQXE0RW5uQlBhY2R5dHJVb294Wm1maFFsYnNhR3lBR2JHY25jNjR4MHlIZ1FlQjVmYi9qZDdKVFlQdCtXbmtKN01ETFo3bTVWSk9WcTREa3hyNi8wOGkyVlpYaGdmc1JDRzJYeGZvUDBlVkl6dHlnZVBxeGM3enJzRFI4MlM3dXdld05NQnFEUlVrK1lEcXU3STgwR2VYT1M4NTRJdUljMU94QkxoeU1XRGRDd1RzU3VpM3A1SUl5QlZ4Vkk1M1lzeHRhYy9tczBoQUxrSDk4OEQzd0c3YTcvVEU1Q1R0RjVjcldnTU9BaDhINHZraFpnQVBGeGwzUWFWb1FVd0RWdkhmQzBaam5OOU5SY2I5emtpb1NBMW9pMWovQnVmMlJYT0tzVjhBWHF0RUFyWmFkT2VudXdxUlhYUEtLeWh0bGhkOG9rTlhWc3BNd0hXUjJSL3RiSmxOSFh6SFM4Qk53SnRaSk1MM0ExcUFkd1B0Ym5lMnhNNGtNUGJTZm1WMUx1MFhwZTQwZzFvUDlBNUVtMjBKV2xYSy84K1g2NTVnWnVRZmtHQjdrMnJ4L0JRQUFBQUFTVVZPUks1Q1lJST0iLz48L3N2Zz4='; // phpcs:ignore
}

/**
 * Register the top-level menu + submenus.
 *
 * @return void
 */
function zymarg_os_register_admin_menu() {
	add_menu_page(
		__( 'ZYMARG OS', 'zymarg-os' ),
		__( 'ZYMARG OS', 'zymarg-os' ),
		'edit_theme_options',
		'zymarg-os',
		'zymarg_os_render_welcome_page',
		zymarg_os_admin_menu_icon(),
		3
	);

	// First submenu mirrors the top-level (rename to "Welcome").
	add_submenu_page(
		'zymarg-os',
		__( 'Welcome', 'zymarg-os' ),
		__( 'Welcome', 'zymarg-os' ),
		'edit_theme_options',
		'zymarg-os',
		'zymarg_os_render_welcome_page'
	);

	// Help (the render lives in inc/admin-help.php).
	if ( function_exists( 'zymarg_os_render_help_page' ) ) {
		add_submenu_page(
			'zymarg-os',
			__( 'Help', 'zymarg-os' ),
			__( 'Help', 'zymarg-os' ),
			'edit_theme_options',
			'zymarg-os-help',
			'zymarg_os_render_help_page'
		);
	}

	// Quick link to the Customizer panel (link-style submenu).
	add_submenu_page(
		'zymarg-os',
		__( 'Customize', 'zymarg-os' ),
		__( 'Customize', 'zymarg-os' ),
		'edit_theme_options',
		'customize.php?autofocus[panel]=zymarg_os_panel'
	);

	// Update / Upload Theme — install a new theme zip without leaving this menu.
	add_submenu_page(
		'zymarg-os',
		__( 'Update / Upload Theme', 'zymarg-os' ),
		__( 'Update / Upload Theme', 'zymarg-os' ),
		'install_themes',
		'zymarg-os-upload',
		'zymarg_os_render_upload_theme_page'
	);

	// Plugins — add a plugin and see what's installed, all in one place.
	add_submenu_page(
		'zymarg-os',
		__( 'Plugins', 'zymarg-os' ),
		__( 'Plugins', 'zymarg-os' ),
		'install_plugins',
		'zymarg-os-plugins',
		'zymarg_os_render_plugins_page'
	);
}
add_action( 'admin_menu', 'zymarg_os_register_admin_menu' );

/**
 * Render the "Update / Upload Theme" screen.
 *
 * Embeds WordPress's own theme-upload form (posting to update.php) right inside
 * the ZYMARG OS menu, so a new theme zip can be installed in one click instead
 * of navigating to Appearance → Themes → Add New → Upload Theme. Uploading a zip
 * of an already-installed theme triggers WordPress's built-in "replace with the
 * uploaded version" flow — i.e. a theme update.
 *
 * @return void
 */
function zymarg_os_render_upload_theme_page() {
	if ( ! current_user_can( 'install_themes' ) || ! current_user_can( 'upload_themes' ) ) {
		wp_die( esc_html__( 'Sorry, you are not allowed to install themes on this site.', 'zymarg-os' ) );
	}

	$mods_disabled = defined( 'DISALLOW_FILE_MODS' ) && DISALLOW_FILE_MODS;
	?>
	<div class="wrap zymarg-admin zymarg-welcome">
		<h1>
			<?php if ( function_exists( 'zymarg_discovery_spark' ) ) { echo zymarg_discovery_spark( array( 'size' => 'lg' ) ); } // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<?php esc_html_e( 'Update / Upload Theme', 'zymarg-os' ); ?>
			<span class="zymarg-welcome__v">v<?php echo esc_html( ZYMARG_OS_VERSION ); ?></span>
		</h1>
		<p class="zymarg-welcome__intro"><?php esc_html_e( 'Got a newer ZYMARG OS zip? Upload it here. If the theme is already installed, WordPress will ask you to confirm replacing it with the uploaded version — that is how an update is applied.', 'zymarg-os' ); ?></p>

		<?php if ( $mods_disabled ) : ?>
			<div class="notice notice-warning inline" style="margin:16px 0;max-width:760px;">
				<p><?php esc_html_e( 'Theme installs are disabled on this site (the DISALLOW_FILE_MODS setting is on). Please ask your host or site administrator, or use Appearance → Themes.', 'zymarg-os' ); ?></p>
			</div>
		<?php else : ?>
			<div class="zymarg-upload-card">
				<form method="post" enctype="multipart/form-data" class="wp-upload-form" action="<?php echo esc_url( self_admin_url( 'update.php?action=upload-theme' ) ); ?>">
					<?php wp_nonce_field( 'theme-upload' ); ?>
					<p class="zymarg-upload-card__label"><label for="themezip"><?php esc_html_e( 'Choose your theme .zip file', 'zymarg-os' ); ?></label></p>
					<input type="file" id="themezip" name="themezip" accept=".zip" required />
					<?php submit_button( __( 'Install / Update Now', 'zymarg-os' ), 'primary', 'install-theme-submit', false ); ?>
				</form>
			</div>
			<p class="zymarg-welcome__intro" style="margin-top:14px;"><?php esc_html_e( 'Tip: after a successful update, this menu and its icon may briefly reload — that is normal.', 'zymarg-os' ); ?></p>
		<?php endif; ?>

		<p style="margin-top:18px;">
			<a class="button" href="<?php echo esc_url( admin_url( 'themes.php' ) ); ?>"><?php esc_html_e( 'Go to all themes', 'zymarg-os' ); ?></a>
		</p>
	</div>

	<style>
		/* Header styled by assets/css/admin-brand.css — see v5.27.9. */
		.zymarg-upload-card { margin-top:16px; padding:22px; background:#fff; border:1px solid #d8bfd3; border-radius:12px; max-width:560px; box-shadow:0 8px 30px rgba(53,0,61,.06); }
		.zymarg-upload-card__label { margin:0 0 8px; font-weight:600; color:#36003d; }
		.zymarg-upload-card input[type="file"] { display:block; margin-bottom:14px; }
	</style>
	<?php
}

/**
 * Render the "Plugins" screen — two columns: Add Plugin + Installed Plugins.
 *
 * Left: upload a plugin .zip (WordPress's own upload flow) and a button to
 * browse the plugin directory. Right: a read-only list of every installed
 * plugin with an Active/Inactive badge and a button to the full Plugins screen
 * for activating/deactivating/deleting. Keeps plugin management one click away
 * from the ZYMARG OS menu without re-implementing (or risking) core actions.
 *
 * @return void
 */
function zymarg_os_render_plugins_page() {
	if ( ! current_user_can( 'install_plugins' ) ) {
		wp_die( esc_html__( 'Sorry, you are not allowed to manage plugins on this site.', 'zymarg-os' ) );
	}

	if ( ! function_exists( 'get_plugins' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}

	$mods_disabled = defined( 'DISALLOW_FILE_MODS' ) && DISALLOW_FILE_MODS;
	$plugins       = get_plugins();
	$active_count  = 0;
	foreach ( array_keys( $plugins ) as $plugin_file ) {
		if ( is_plugin_active( $plugin_file ) ) {
			$active_count++;
		}
	}
	?>
	<div class="wrap zymarg-admin zymarg-welcome">
		<h1>
			<?php if ( function_exists( 'zymarg_discovery_spark' ) ) { echo zymarg_discovery_spark( array( 'size' => 'lg' ) ); } // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<?php esc_html_e( 'Plugins', 'zymarg-os' ); ?>
			<span class="zymarg-welcome__v">v<?php echo esc_html( ZYMARG_OS_VERSION ); ?></span>
		</h1>
		<p class="zymarg-welcome__intro"><?php esc_html_e( 'Add a new plugin or review what is already installed — without leaving the ZYMARG OS menu.', 'zymarg-os' ); ?></p>

		<div class="zymarg-plugins-grid">

			<!-- Column 1: Add Plugin -->
			<section class="zymarg-plugins-col">
				<h2 class="zymarg-plugins-col__title"><?php esc_html_e( 'Add Plugin', 'zymarg-os' ); ?></h2>

				<?php if ( $mods_disabled ) : ?>
					<div class="notice notice-warning inline" style="margin:0 0 12px;">
						<p><?php esc_html_e( 'Plugin installs are disabled on this site (the DISALLOW_FILE_MODS setting is on). Please ask your host or site administrator.', 'zymarg-os' ); ?></p>
					</div>
				<?php elseif ( current_user_can( 'upload_plugins' ) ) : ?>
					<div class="zymarg-upload-card">
						<form method="post" enctype="multipart/form-data" class="wp-upload-form" action="<?php echo esc_url( self_admin_url( 'update.php?action=upload-plugin' ) ); ?>">
							<?php wp_nonce_field( 'plugin-upload' ); ?>
							<p class="zymarg-upload-card__label"><label for="pluginzip"><?php esc_html_e( 'Upload a plugin .zip file', 'zymarg-os' ); ?></label></p>
							<input type="file" id="pluginzip" name="pluginzip" accept=".zip" required />
							<?php submit_button( __( 'Install Now', 'zymarg-os' ), 'primary', 'install-plugin-submit', false ); ?>
						</form>
					</div>
				<?php endif; ?>

				<p style="margin-top:14px;"><?php esc_html_e( 'Prefer to search the official directory?', 'zymarg-os' ); ?></p>
				<p><a class="button button-secondary" href="<?php echo esc_url( admin_url( 'plugin-install.php' ) ); ?>"><?php esc_html_e( 'Browse the plugin directory', 'zymarg-os' ); ?></a></p>
			</section>

			<!-- Column 2: Installed Plugins -->
			<section class="zymarg-plugins-col">
				<h2 class="zymarg-plugins-col__title">
					<?php esc_html_e( 'Installed Plugins', 'zymarg-os' ); ?>
					<span class="zymarg-plugins-count"><?php echo esc_html( sprintf( /* translators: 1: active count, 2: total count */ __( '%1$d active / %2$d total', 'zymarg-os' ), (int) $active_count, count( $plugins ) ) ); ?></span>
				</h2>

				<?php if ( empty( $plugins ) ) : ?>
					<p><?php esc_html_e( 'No plugins are installed yet.', 'zymarg-os' ); ?></p>
				<?php else : ?>
					<ul class="zymarg-plugins-list">
						<?php
						foreach ( $plugins as $plugin_file => $data ) :
							$is_active = is_plugin_active( $plugin_file );
							?>
							<li class="zymarg-plugins-list__item">
								<span class="zymarg-plugins-list__name">
									<?php echo esc_html( $data['Name'] ); ?>
									<span class="zymarg-plugins-list__ver">v<?php echo esc_html( $data['Version'] ); ?></span>
								</span>
								<span class="zymarg-plugins-badge <?php echo $is_active ? 'is-active' : 'is-inactive'; ?>">
									<?php echo $is_active ? esc_html__( 'Active', 'zymarg-os' ) : esc_html__( 'Inactive', 'zymarg-os' ); ?>
								</span>
							</li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>

				<p style="margin-top:14px;"><a class="button button-secondary" href="<?php echo esc_url( admin_url( 'plugins.php' ) ); ?>"><?php esc_html_e( 'Manage all plugins (activate / deactivate / delete)', 'zymarg-os' ); ?></a></p>
			</section>

		</div>
	</div>

	<style>
		/* Header styled by assets/css/admin-brand.css — see v5.27.9. */
		.zymarg-upload-card { padding:18px; background:#fff; border:1px solid #d8bfd3; border-radius:12px; box-shadow:0 8px 30px rgba(53,0,61,.06); }
		.zymarg-upload-card__label { margin:0 0 8px; font-weight:600; color:#36003d; }
		.zymarg-upload-card input[type="file"] { display:block; margin-bottom:14px; }
		.zymarg-plugins-grid { display:grid; grid-template-columns:1fr 1fr; gap:22px; margin-top:18px; max-width:1100px; }
		@media (max-width:782px){ .zymarg-plugins-grid { grid-template-columns:1fr; } }
		.zymarg-plugins-col { background:#fff; border:1px solid #d8bfd3; border-radius:12px; padding:20px; box-shadow:0 8px 30px rgba(53,0,61,.05); }
		.zymarg-plugins-col__title { margin-top:0; color:#36003d; display:flex; align-items:center; justify-content:space-between; gap:10px; }
		.zymarg-plugins-count { font-size:12px; font-weight:600; color:#534152; background:#eaedff; border-radius:999px; padding:3px 10px; }
		.zymarg-plugins-list { margin:0; max-height:420px; overflow:auto; border:1px solid #d8bfd3; border-radius:8px; }
		.zymarg-plugins-list__item { display:flex; align-items:center; justify-content:space-between; gap:12px; padding:10px 12px; border-bottom:1px solid #eaedff; }
		.zymarg-plugins-list__item:last-child { border-bottom:0; }
		.zymarg-plugins-list__name { font-weight:600; color:#36003d; }
		.zymarg-plugins-list__ver { font-weight:400; color:#857183; font-size:12px; margin-left:6px; }
		.zymarg-plugins-badge { font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:.03em; border-radius:999px; padding:3px 10px; white-space:nowrap; }
		.zymarg-plugins-badge.is-active { color:#0a7d33; background:#e6f6ec; }
		.zymarg-plugins-badge.is-inactive { color:#534152; background:#eaedff; }
	</style>
	<?php
}

/**
 * Quick-link tiles shown on the Welcome screen.
 *
 * @return array<int,array{label:string,desc:string,url:string}>
 */
function zymarg_os_welcome_links() {
	$cz = admin_url( 'customize.php?autofocus[section]=' );
	return array(
		array( 'label' => __( 'Site Mode', 'zymarg-os' ), 'desc' => __( 'Live / Coming Soon / Maintenance', 'zymarg-os' ), 'url' => $cz . 'zymarg_os_sitemode_section' ),
		array( 'label' => __( 'Colours & Scheme', 'zymarg-os' ), 'desc' => __( 'Palette, dark/light', 'zymarg-os' ), 'url' => $cz . 'zymarg_os_colors_section' ),
		array( 'label' => __( 'Typography', 'zymarg-os' ), 'desc' => __( 'Fonts & loading', 'zymarg-os' ), 'url' => $cz . 'zymarg_os_typography_section' ),
		array( 'label' => __( 'Modules', 'zymarg-os' ), 'desc' => __( 'Turn features on/off', 'zymarg-os' ), 'url' => $cz . 'zymarg_os_modules_section' ),
	);
}

/**
 * Render the Welcome screen.
 *
 * @return void
 */
function zymarg_os_render_welcome_page() {
	?>
	<div class="wrap zymarg-admin zymarg-welcome">
		<h1>
			<?php if ( function_exists( 'zymarg_discovery_spark' ) ) { echo zymarg_discovery_spark( array( 'size' => 'lg' ) ); } // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<?php esc_html_e( 'ZYMARG OS', 'zymarg-os' ); ?>
			<span class="zymarg-welcome__v">v<?php echo esc_html( ZYMARG_OS_VERSION ); ?></span>
		</h1>
		<p class="zymarg-welcome__intro"><?php esc_html_e( 'Your marketplace command center. Jump to any setting, or open the Help guide for how-tos.', 'zymarg-os' ); ?></p>

		<div class="zymarg-welcome__cta">
			<a class="button button-primary button-hero" href="<?php echo esc_url( admin_url( 'customize.php?autofocus[panel]=zymarg_os_panel' ) ); ?>"><?php esc_html_e( 'Open Customizer', 'zymarg-os' ); ?></a>
			<a class="button button-hero" href="<?php echo esc_url( admin_url( 'admin.php?page=zymarg-os-help' ) ); ?>"><?php esc_html_e( 'Open Help', 'zymarg-os' ); ?></a>
			<?php if ( current_user_can( 'install_themes' ) ) : ?>
				<a class="button button-hero" href="<?php echo esc_url( admin_url( 'admin.php?page=zymarg-os-upload' ) ); ?>"><?php esc_html_e( 'Update / Upload Theme', 'zymarg-os' ); ?></a>
			<?php endif; ?>
		</div>

		<h2 class="zymarg-welcome__h2"><?php esc_html_e( 'Quick settings', 'zymarg-os' ); ?></h2>
		<div class="zymarg-welcome__grid">
			<?php foreach ( zymarg_os_welcome_links() as $link ) : ?>
				<a class="zymarg-welcome__tile" href="<?php echo esc_url( $link['url'] ); ?>">
					<strong><?php echo esc_html( $link['label'] ); ?></strong>
					<span><?php echo esc_html( $link['desc'] ); ?></span>
				</a>
			<?php endforeach; ?>
		</div>
	</div>

	<style>
		/* Header styled by assets/css/admin-brand.css — see v5.27.9. */
		.zymarg-welcome__cta { display:flex; gap:10px; flex-wrap:wrap; margin:16px 0 8px; }
		.zymarg-welcome__h2 { margin-top:26px; color:#36003d; }
		.zymarg-welcome__grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(220px,1fr)); gap:14px; margin-top:10px; max-width:1100px; }
		.zymarg-welcome__tile { display:block; padding:16px 18px; background:#fff; border:1px solid #d8bfd3; border-radius:12px; text-decoration:none; box-shadow:0 8px 30px rgba(53,0,61,.06); transition:transform .2s ease, box-shadow .2s ease, border-color .2s ease; }
		.zymarg-welcome__tile:hover { transform:translateY(-3px); border-color:#9500a5; box-shadow:0 16px 40px rgba(53,0,61,.12); }
		.zymarg-welcome__tile strong { display:block; color:#36003d; font-size:15px; }
		.zymarg-welcome__tile span { display:block; color:#534152; font-size:13px; margin-top:4px; }
	</style>
	<?php
}
