<?php
/**
 * ZYMARG Account — Profile.
 *
 * Replaces the WooCommerce `form-edit-account.php` template that used to be
 * rendered inside the Profile tab. That template was the source of the second
 * password form on the account page, and it is not our code to shape.
 *
 * Instead of overriding a Woo template (which ties the brand to whatever
 * WooCommerce decides that file should look like next release), the theme now
 * renders its own form and fires Woo's own save hooks afterwards. Extensions
 * such as Dokan that listen on `woocommerce_save_account_details` keep working
 * exactly as before, but the markup, the fields and the layout are ours.
 *
 * Sections:
 *   1. Field registry
 *   2. Option sources + value access
 *   3. Completeness + save handler
 *   4. Renderer (accordion)
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/* ======================================================================
   1. FIELD REGISTRY
   ====================================================================== */

/**
 * Every field the Profile screen manages.
 *
 * `store` decides where the value lives: 'user' for wp_users / wp_usermeta
 * fields WordPress knows about, 'meta' for our own user meta.
 *
 * Adding a field anywhere else in the codebase is a filter call, not an edit
 * to this file — that is what keeps this brand-owned rather than fork-owned.
 *
 * @return array<string,array<string,mixed>>
 */
function zymarg_os_profile_fields() {
	$fields = array(
		'first_name'      => array(
			'label'        => __( 'First name', 'zymarg-os' ),
			'type'         => 'text',
			'store'        => 'user',
			'group'        => 'personal',
			'weight'       => 10,
			'half'         => true,
			'required'     => true,
			'autocomplete' => 'given-name',
		),
		'last_name'       => array(
			'label'        => __( 'Last name', 'zymarg-os' ),
			'type'         => 'text',
			'store'        => 'user',
			'group'        => 'personal',
			'weight'       => 10,
			'half'         => true,
			'required'     => true,
			'autocomplete' => 'family-name',
		),
		'display_name'    => array(
			'label'  => __( 'Display name', 'zymarg-os' ),
			'type'   => 'text',
			'store'  => 'user',
			'group'  => 'personal',
			'weight' => 5,
			'hint'   => __( 'This is how your name appears in reviews and messages.', 'zymarg-os' ),
		),
		'description'     => array(
			'label'     => __( 'About you', 'zymarg-os' ),
			'type'      => 'textarea',
			'store'     => 'user',
			'group'     => 'personal',
			'weight'    => 5,
			'maxlength' => 500,
		),
		'billing_phone'   => array(
			'label'        => __( 'Phone number', 'zymarg-os' ),
			'type'         => 'tel',
			'store'        => 'meta',
			'group'        => 'contact',
			'weight'       => 15,
			'half'         => true,
			'autocomplete' => 'tel',
			'placeholder'  => '+880 1712 345678',
			'hint'         => __( 'Include your country code, starting with +. Used for delivery updates.', 'zymarg-os' ),
		),
		'zymarg_whatsapp' => array(
			'label'       => __( 'WhatsApp number', 'zymarg-os' ),
			'type'        => 'tel',
			'store'       => 'meta',
			'group'       => 'contact',
			'weight'      => 5,
			'half'        => true,
			'placeholder' => '+880 1712 345678',
			'hint'        => __( 'Optional, with country code. Our support team will message you here first.', 'zymarg-os' ),
		),
		'zymarg_dob'      => array(
			'label'  => __( 'Date of birth', 'zymarg-os' ),
			// Three selects, not a calendar. A calendar opens on the current month,
			// so entering a birth year means paging back hundreds of months; and the
			// native picker panel is drawn by the browser, so it can never be
			// brought on brand. Selects are one tap each and use our own styling.
			'type'   => 'dob',
			'store'  => 'meta',
			'group'  => 'personal_extra',
			'weight' => 5,
			'half'   => true,
			'hint'   => __( 'So we can send you a birthday treat.', 'zymarg-os' ),
		),
		'zymarg_gender'   => array(
			'label'   => __( 'Gender', 'zymarg-os' ),
			'type'    => 'select',
			'store'   => 'meta',
			'group'   => 'personal_extra',
			'weight'  => 5,
			'half'    => true,
			// "Other" is a label nobody chooses about themselves, so it is replaced
			// by the identities people actually select. The empty key stays first
			// because declining to answer must remain the default, not a gender.
			// Anyone who previously stored 'other' simply sees the field unset
			// until they pick again; no stored data is deleted.
			'options' => array(
				''            => __( 'Prefer not to say', 'zymarg-os' ),
				'female'      => __( 'Female', 'zymarg-os' ),
				'male'        => __( 'Male', 'zymarg-os' ),
				'non-binary'  => __( 'Non-binary', 'zymarg-os' ),
				'transgender' => __( 'Transgender', 'zymarg-os' ),
				'intersex'    => __( 'Intersex', 'zymarg-os' ),
			),
		),
		'zymarg_language' => array(
			'label'            => __( 'Language', 'zymarg-os' ),
			'type'             => 'select',
			'store'            => 'meta',
			'group'            => 'preferences',
			'weight'           => 5,
			'half'             => true,
			'options_callback' => 'zymarg_os_profile_language_options',
		),
		'zymarg_currency' => array(
			'label'            => __( 'Currency', 'zymarg-os' ),
			'type'             => 'select',
			'store'            => 'meta',
			'group'            => 'preferences',
			'weight'           => 5,
			'half'             => true,
			'options_callback' => 'zymarg_os_profile_currency_options',
			// Locked: this is a Bangladesh marketplace, so every price, refund
			// and payout is in Taka. See zymarg_os_profile_locked_fields().
			'hint'             => __( 'All prices, refunds and payouts on this marketplace are in Bangladeshi Taka.', 'zymarg-os' ),
		),
		'zymarg_timezone' => array(
			'label'            => __( 'Time zone', 'zymarg-os' ),
			'type'             => 'select',
			'store'            => 'meta',
			'group'            => 'preferences',
			'weight'           => 5,
			'options_callback' => 'zymarg_os_profile_timezone_options',
			// Locked, like currency: Bangladesh is a single time zone, so a picker
			// here can only ever create disagreement about delivery windows.
			'hint'             => __( 'Order times and delivery windows are shown in Bangladesh Standard Time.', 'zymarg-os' ),
		),
	);

	/**
	 * Filter the Profile field registry.
	 *
	 * @param array $fields Field definitions keyed by field name.
	 */
	return apply_filters( 'zymarg_os_profile_fields', $fields );
}

/* ======================================================================
   1b. LOCKED FIELDS
   ====================================================================== */

/**
 * Fields the customer may see but never change, and the value they are
 * pinned to.
 *
 * WHY LOCK RATHER THAN HIDE
 *
 * Currency is not a preference on a single-market store — it is a fact of
 * the marketplace. Leaving a live dropdown there promises something the
 * store cannot deliver: prices, refunds, coupons and payouts are all in
 * Taka, so a customer who picked USD would be shown a number the checkout
 * would then contradict. Removing the row entirely would be worse, because
 * "which currency am I being charged in?" is a fair question and the answer
 * belongs on this screen. So the row stays, states the answer plainly, and
 * cannot be edited.
 *
 * A locked field is enforced in three places, deliberately:
 *   1. Display   — rendered as a fixed value, not a control.
 *   2. Save      — the handler ignores the key even if a request contains it,
 *                  so a crafted POST cannot set it either.
 *   3. Read      — the stored meta is filtered, so any other code asking for
 *                  the value gets the locked one instead of a stale row left
 *                  behind from before the lock.
 *
 * Locking another field is one line here. Currency and time zone are both
 * pinned: this is a Bangladesh marketplace, and Bangladesh is a single time
 * zone, so a per-customer picker could only ever make the order times on this
 * screen disagree with what the rider, the vendor and support all see.
 *
 * @return array<string,string> Field key => pinned value.
 */
function zymarg_os_profile_locked_fields() {
	/**
	 * Filter the locked Profile fields.
	 *
	 * @param array $locked Field key => pinned value.
	 */
	return (array) apply_filters(
		'zymarg_os_profile_locked_fields',
		array(
			'zymarg_currency' => 'BDT',
			'zymarg_timezone' => 'Asia/Dhaka',
		)
	);
}

/**
 * Whether a field is locked.
 *
 * @param string $key Field key.
 * @return bool
 */
function zymarg_os_profile_is_locked( $key ) {
	$locked = zymarg_os_profile_locked_fields();

	return isset( $locked[ $key ] );
}

/**
 * The value a locked field is pinned to.
 *
 * @param string $key Field key.
 * @return string
 */
function zymarg_os_profile_locked_value( $key ) {
	$locked = zymarg_os_profile_locked_fields();

	return isset( $locked[ $key ] ) ? (string) $locked[ $key ] : '';
}

/**
 * Serve the pinned value to every reader of a locked user meta key.
 *
 * Without this, a customer who had already saved USD before the lock landed
 * would keep being treated as a USD customer by anything reading the meta
 * directly — emails, exports, a vendor plugin — while the screen said Taka.
 * Short-circuiting the read keeps one answer everywhere and needs no
 * migration pass over the users table.
 *
 * @param mixed  $value     Existing short-circuit value.
 * @param int    $object_id User ID.
 * @param string $meta_key  Meta key being read.
 * @return mixed
 */
function zymarg_os_profile_filter_locked_meta( $value, $object_id, $meta_key ) {
	if ( '' === (string) $meta_key || ! zymarg_os_profile_is_locked( $meta_key ) ) {
		return $value;
	}

	// Returning an array satisfies both the single and multi-value paths in
	// get_metadata(); core takes [0] when $single is true.
	return array( zymarg_os_profile_locked_value( $meta_key ) );
}
add_filter( 'get_user_metadata', 'zymarg_os_profile_filter_locked_meta', 10, 3 );

/* ======================================================================
   2. OPTION SOURCES + VALUE ACCESS
   ====================================================================== */

/**
 * Language choices.
 *
 * @return array<string,string>
 */
function zymarg_os_profile_language_options() {
	return apply_filters(
		'zymarg_os_profile_languages',
		array(
			''      => __( 'Site default', 'zymarg-os' ),
			'en_US' => __( 'English', 'zymarg-os' ),
			'bn_BD' => __( 'Bangla', 'zymarg-os' ),
		)
	);
}

/**
 * Currency choices.
 *
 * Pulls the real WooCommerce currency list when available, but floats the
 * currencies this brand actually trades in to the top so a customer on a
 * phone is not scrolling past 160 entries.
 *
 * @return array<string,string>
 */
function zymarg_os_profile_currency_options() {
	$options = array( '' => __( 'Store default', 'zymarg-os' ) );

	if ( ! function_exists( 'get_woocommerce_currencies' ) ) {
		return apply_filters( 'zymarg_os_profile_currencies', $options );
	}

	$all = get_woocommerce_currencies();

	$shortlist = apply_filters(
		'zymarg_os_profile_currency_shortlist',
		array( 'BDT', 'USD', 'EUR', 'GBP', 'INR', 'MYR' )
	);

	foreach ( $shortlist as $code ) {
		if ( isset( $all[ $code ] ) ) {
			$options[ $code ] = $all[ $code ];
			unset( $all[ $code ] );
		}
	}

	$options = $options + $all;

	return apply_filters( 'zymarg_os_profile_currencies', $options );
}

/**
 * Time zone choices.
 *
 * @return array<string,string>
 */
function zymarg_os_profile_timezone_options() {
	$options = array( '' => __( 'Site default', 'zymarg-os' ) );

	foreach ( timezone_identifiers_list() as $zone ) {
		$options[ $zone ] = str_replace( '_', ' ', $zone );
	}

	return apply_filters( 'zymarg_os_profile_timezones', $options );
}

/**
 * Resolve the options for a select field.
 *
 * @param array $field Field definition.
 * @return array<string,string>
 */
function zymarg_os_profile_field_options( $field ) {
	if ( ! empty( $field['options_callback'] ) && is_callable( $field['options_callback'] ) ) {
		return (array) call_user_func( $field['options_callback'] );
	}

	return isset( $field['options'] ) ? (array) $field['options'] : array();
}

/**
 * Read a field's current value.
 *
 * @param string $key     Field key.
 * @param array  $field   Field definition.
 * @param int    $user_id User ID.
 * @return string
 */
function zymarg_os_profile_get_value( $key, $field, $user_id ) {
	// A locked field always reports its pinned value, whatever is in storage.
	if ( zymarg_os_profile_is_locked( $key ) ) {
		return zymarg_os_profile_locked_value( $key );
	}

	if ( isset( $field['store'] ) && 'user' === $field['store'] ) {
		$user = get_userdata( $user_id );

		if ( ! $user ) {
			return '';
		}

		return (string) $user->get( $key );
	}

	return (string) get_user_meta( $user_id, $key, true );
}

/**
 * Profile URL.
 *
 * @return string
 */
function zymarg_os_profile_url() {
	if ( function_exists( 'wc_get_account_endpoint_url' ) ) {
		return wc_get_account_endpoint_url( 'edit-account' );
	}

	return home_url( '/my-account/profile/' );
}

/**
 * Security URL.
 *
 * @return string
 */
function zymarg_os_security_url() {
	if ( function_exists( 'wc_get_account_endpoint_url' ) ) {
		return wc_get_account_endpoint_url( 'security' );
	}

	return home_url( '/my-account/security/' );
}

/* ======================================================================
   2b. PHONE NUMBER VALIDATION (E.164)
   ====================================================================== */

/**
 * International calling codes we accept.
 *
 * A number is only genuinely dialable if its country code actually exists.
 * Checking against this list is what lets us tell "+8801712345678" (real)
 * apart from "+9991712345678" (nonsense) — length alone cannot.
 *
 * Filterable, so a new market never needs a code edit.
 *
 * @return array<int,string>
 */
function zymarg_os_phone_country_codes() {
	$codes = array(
		'1', '7', '20', '27', '30', '31', '32', '33', '34', '36', '39', '40', '41', '43', '44', '45',
		'46', '47', '48', '49', '51', '52', '53', '54', '55', '56', '57', '58', '60', '61', '62', '63',
		'64', '65', '66', '81', '82', '84', '86', '90', '91', '92', '93', '94', '95', '98',
		'211', '212', '213', '216', '218', '220', '221', '222', '223', '224', '225', '226', '227',
		'228', '229', '230', '231', '232', '233', '234', '235', '236', '237', '238', '239', '240',
		'241', '242', '243', '244', '245', '246', '248', '249', '250', '251', '252', '253', '254',
		'255', '256', '257', '258', '260', '261', '262', '263', '264', '265', '266', '267', '268',
		'269', '290', '291', '297', '298', '299',
		'350', '351', '352', '353', '354', '355', '356', '357', '358', '359', '370', '371', '372',
		'373', '374', '375', '376', '377', '378', '380', '381', '382', '383', '385', '386', '387',
		'389', '420', '421', '423',
		'500', '501', '502', '503', '504', '505', '506', '507', '508', '509', '590', '591', '592',
		'593', '594', '595', '596', '597', '598', '599',
		'670', '672', '673', '674', '675', '676', '677', '678', '679', '680', '681', '682', '683',
		'685', '686', '687', '688', '689', '690', '691', '692',
		'800', '808', '850', '852', '853', '855', '856', '870', '880', '886',
		'960', '961', '962', '963', '964', '965', '966', '967', '968', '970', '971', '972', '973',
		'974', '975', '976', '977', '992', '993', '994', '995', '996', '998',
	);

	/**
	 * Filter the accepted international calling codes.
	 *
	 * @param array $codes Calling codes without the leading plus.
	 */
	return apply_filters( 'zymarg_os_phone_country_codes', $codes );
}

/**
 * Validate and normalise a phone number to E.164.
 *
 * Deliberately strict about the country code: a delivery courier in Dhaka
 * dialling a number with no country code from a different network, or our
 * SMS gateway trying to route one, both fail silently. Better to refuse the
 * number at the form than to discover it when an order cannot be delivered.
 *
 * Accepts human formatting (spaces, dashes, brackets, dots) and a leading
 * 00 in place of +, then stores one canonical form: +<code><number>.
 *
 * @param string $raw Raw input.
 * @return string|WP_Error Normalised E.164 number, or an error explaining why not.
 */
function zymarg_os_validate_phone( $raw ) {
	$value = trim( (string) $raw );

	// Strip everything a human might type as separators.
	$value = preg_replace( '/[\s\-\(\)\.]/', '', $value );

	// 00 is the international prefix in most of the world; treat it as +.
	if ( 0 === strpos( $value, '00' ) ) {
		$value = '+' . substr( $value, 2 );
	}

	if ( '' === $value ) {
		return '';
	}

	if ( 0 !== strpos( $value, '+' ) ) {
		$default_cc = function_exists( 'zymarg_os_account_setting' )
			? preg_replace( '/\D/', '', (string) zymarg_os_account_setting( 'default_country_code' ) )
			: '880';

		$require_cc = function_exists( 'zymarg_os_account_setting' )
			? (int) zymarg_os_account_setting( 'require_country_code' )
			: 1;

		// A local number carries a trunk prefix (the 0 in 01712...) that is
		// dropped when the country code goes on: +880 1712..., never +880 01712...
		$local = ltrim( $value, '0' );

		if ( '' !== $default_cc && ctype_digit( $local ) ) {
			// Store configured a home country, so upgrade the number instead of
			// rejecting a customer who typed it the way they always do.
			$value = '+' . $default_cc . $local;
		} elseif ( $require_cc ) {
			return new WP_Error(
				'zymarg_phone_no_country_code',
				__( 'start it with your country code, for example +880 for Bangladesh', 'zymarg-os' )
			);
		} else {
			// Country codes are not required and no home country is set, so the
			// most we can honestly check is the shape of the digits.
			$loose = preg_replace( '/\D/', '', $value );

			if ( strlen( $loose ) < 6 || strlen( $loose ) > 15 ) {
				return new WP_Error(
					'zymarg_phone_length',
					__( 'it looks too short or too long to be a real number', 'zymarg-os' )
				);
			}

			return $loose;
		}
	}

	$digits = substr( $value, 1 );

	if ( ! ctype_digit( $digits ) ) {
		return new WP_Error(
			'zymarg_phone_bad_chars',
			__( 'it can only contain numbers after the country code', 'zymarg-os' )
		);
	}

	// E.164 caps the whole number at 15 digits; nothing real is under 8.
	$length = strlen( $digits );

	if ( $length < 8 || $length > 15 ) {
		return new WP_Error(
			'zymarg_phone_length',
			__( 'it looks too short or too long to be a real number', 'zymarg-os' )
		);
	}

	// Match the longest calling code first, so +1 never shadows +1xx.
	$codes = zymarg_os_phone_country_codes();
	usort(
		$codes,
		function ( $a, $b ) {
			return strlen( $b ) - strlen( $a );
		}
	);

	$matched = '';
	foreach ( $codes as $code ) {
		if ( 0 === strpos( $digits, $code ) ) {
			$matched = $code;
			break;
		}
	}

	if ( '' === $matched ) {
		return new WP_Error(
			'zymarg_phone_unknown_code',
			__( 'that country code does not exist', 'zymarg-os' )
		);
	}

	$national = substr( $digits, strlen( $matched ) );

	if ( strlen( $national ) < 6 ) {
		return new WP_Error(
			'zymarg_phone_short_national',
			__( 'the number after the country code is too short', 'zymarg-os' )
		);
	}

	// A national part that is all one digit is a placeholder, not a person.
	if ( preg_match( '/^(\d)\1+$/', $national ) ) {
		return new WP_Error(
			'zymarg_phone_repeated',
			__( 'that does not look like a real number', 'zymarg-os' )
		);
	}

	// Bangladesh: mobile numbers are 10 digits and always begin with 1.
	if ( '880' === $matched && ! preg_match( '/^1[3-9]\d{8}$/', $national ) ) {
		return new WP_Error(
			'zymarg_phone_bd',
			__( 'a Bangladeshi mobile number should look like +880 1712 345678', 'zymarg-os' )
		);
	}

	/**
	 * Filter the final validation result, for country rules we have not
	 * written yet.
	 *
	 * @param string|WP_Error $result   Normalised number.
	 * @param string          $matched  Country code.
	 * @param string          $national National part.
	 */
	return apply_filters( 'zymarg_os_validate_phone', '+' . $digits, $matched, $national );
}

/**
 * Digits-only form, for wa.me and tel: links.
 *
 * @param string $number Stored number.
 * @return string
 */
function zymarg_os_phone_digits( $number ) {
	return preg_replace( '/\D/', '', (string) $number );
}

/**
 * The WhatsApp number to reach a customer on.
 *
 * Falls back to the phone number, because most customers in this market use
 * the same number for both and will not fill the field twice.
 *
 * @param int $user_id User ID.
 * @return string Empty string when there is nothing to message.
 */
function zymarg_os_get_whatsapp_number( $user_id ) {
	$number = (string) get_user_meta( $user_id, 'zymarg_whatsapp', true );

	if ( '' === trim( $number ) ) {
		$number = (string) get_user_meta( $user_id, 'billing_phone', true );
	}

	return trim( $number );
}

/* ======================================================================
   3. COMPLETENESS + SAVE
   ====================================================================== */

/**
 * Score how complete the profile is.
 *
 * @param int $user_id User ID.
 * @return array{percent:int,missing:array<int,string>}
 */
function zymarg_os_profile_completeness( $user_id ) {
	$earned  = 0;
	$total   = 0;
	$missing = array();

	foreach ( zymarg_os_profile_fields() as $key => $field ) {
		$weight = isset( $field['weight'] ) ? (int) $field['weight'] : 5;
		$total += $weight;

		if ( '' !== trim( zymarg_os_profile_get_value( $key, $field, $user_id ) ) ) {
			$earned += $weight;
		} else {
			$missing[] = $field['label'];
		}
	}

	// A photo and a delivery address matter more than any single text field.
	$total += 20;
	if ( get_user_meta( $user_id, '_zymarg_avatar_url', true ) ) {
		$earned += 20;
	} else {
		$missing[] = __( 'profile photo', 'zymarg-os' );
	}

	$total += 20;
	if ( get_user_meta( $user_id, 'billing_address_1', true ) ) {
		$earned += 20;
	} else {
		$missing[] = __( 'delivery address', 'zymarg-os' );
	}

	$percent = $total > 0 ? (int) round( ( $earned / $total ) * 100 ) : 0;

	return array(
		'percent' => max( 0, min( 100, $percent ) ),
		'missing' => $missing,
	);
}

/**
 * Handle a Profile card submission.
 *
 * @return void
 */
function zymarg_os_handle_profile_save() {
	if ( ! isset( $_POST['zymarg_profile_nonce'] ) ) {
		return;
	}

	if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['zymarg_profile_nonce'] ) ), 'zymarg_save_profile' ) ) {
		return;
	}

	if ( ! is_user_logged_in() ) {
		return;
	}

	$user_id = get_current_user_id();
	$user    = get_userdata( $user_id );
	$fields  = zymarg_os_profile_fields();
	$errors  = new WP_Error();

	$user_updates = array( 'ID' => $user_id );
	$meta_updates = array();

	foreach ( $fields as $key => $field ) {
		// Only touch fields the submitted card actually contained. The UI is
		// an accordion where each card posts on its own, so treating an
		// absent key as an empty string would silently wipe every field the
		// user did not have open. Absent means "not edited", never "clear".
		if ( ! array_key_exists( $key, $_POST ) ) {
			continue;
		}

		// Locked fields are not the customer's to set. Enforced here as well as
		// in the renderer, because a disabled control is a UI courtesy and a
		// hand-crafted POST is not bound by it.
		if ( zymarg_os_profile_is_locked( $key ) ) {
			continue;
		}

		$raw = wp_unslash( $_POST[ $key ] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

		switch ( $field['type'] ) {
			case 'textarea':
				$value = sanitize_textarea_field( $raw );
				if ( ! empty( $field['maxlength'] ) ) {
					$value = mb_substr( $value, 0, (int) $field['maxlength'] );
				}
				break;

			case 'tel':
				// Validated and normalised to E.164 after the switch.
				$value = trim( (string) $raw );
				break;

			case 'date':
				$value = sanitize_text_field( $raw );
				if ( '' !== $value && ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $value ) ) {
					$value = '';
				}
				break;

			case 'dob':
				// Posted as three parts under one key, so the "absent means not
				// edited" rule above still holds for the field as a whole.
				$parts = is_array( $raw ) ? $raw : array();
				$dob_d = isset( $parts['day'] ) ? absint( $parts['day'] ) : 0;
				$dob_m = isset( $parts['month'] ) ? absint( $parts['month'] ) : 0;
				$dob_y = isset( $parts['year'] ) ? absint( $parts['year'] ) : 0;
				$value = '';

				if ( $dob_d && $dob_m && $dob_y ) {
					// checkdate rejects 31 February and 30 February in leap years,
					// which three independent dropdowns will otherwise offer happily.
					if ( ! checkdate( $dob_m, $dob_d, $dob_y ) ) {
						$errors->add( 'dob_' . $key, __( 'That date does not exist. Please check the day and month.', 'zymarg-os' ) );
						continue 2;
					}

					$candidate = sprintf( '%04d-%02d-%02d', $dob_y, $dob_m, $dob_d );

					if ( $candidate > gmdate( 'Y-m-d' ) ) {
						$errors->add( 'dob_' . $key, __( 'Your date of birth cannot be in the future.', 'zymarg-os' ) );
						continue 2;
					}

					$value = $candidate;
				} elseif ( $dob_d || $dob_m || $dob_y ) {
					// A partial date is a mistake, not a request to clear the field.
					$errors->add( 'dob_' . $key, __( 'Please choose a day, a month and a year.', 'zymarg-os' ) );
					continue 2;
				}
				break;

			case 'select':
				$value   = sanitize_text_field( $raw );
				$allowed = array_keys( zymarg_os_profile_field_options( $field ) );
				if ( ! in_array( $value, $allowed, true ) ) {
					$value = '';
				}
				break;

			default:
				$value = sanitize_text_field( $raw );
				break;
		}

		// Phone numbers must be dialable from anywhere, not just locally.
		if ( 'tel' === $field['type'] && '' !== $value ) {
			$phone = zymarg_os_validate_phone( $value );

			if ( is_wp_error( $phone ) ) {
				$errors->add(
					'phone_' . $key,
					sprintf(
						/* translators: 1: field label, 2: reason the number was rejected. */
						__( 'Please check your %1$s — %2$s.', 'zymarg-os' ),
						$field['label'],
						$phone->get_error_message()
					)
				);
				continue;
			}

			$value = $phone;
		}

		if ( ! empty( $field['required'] ) && '' === $value ) {
			$errors->add(
				'required_' . $key,
				sprintf(
					/* translators: %s: field label. */
					__( '%s cannot be empty.', 'zymarg-os' ),
					$field['label']
				)
			);
			continue;
		}

		// A display name that looks like an email address leaks the address
		// publicly on reviews. WordPress allows it; we do not.
		if ( 'display_name' === $key && is_email( $value ) ) {
			$errors->add( 'display_name_email', __( 'Your display name cannot be an email address.', 'zymarg-os' ) );
			continue;
		}

		if ( 'display_name' === $key && '' === $value ) {
			$value = $user->user_login;
		}

		if ( 'user' === $field['store'] ) {
			$user_updates[ $key ] = $value;
		} else {
			$meta_updates[ $key ] = $value;
		}
	}

	/**
	 * Woo's own validation hook, fired so extensions (Dokan and friends)
	 * can veto the save exactly as they would on the native form.
	 *
	 * @param WP_Error $errors  Error collector.
	 * @param stdClass $updates User fields being written.
	 */
	$woo_errors = $errors;
	$woo_user   = (object) $user_updates;
	do_action_ref_array( 'woocommerce_save_account_details_errors', array( &$woo_errors, &$woo_user ) );

	if ( $woo_errors->get_error_messages() ) {
		foreach ( $woo_errors->get_error_messages() as $message ) {
			zymarg_os_notice( $message, 'error' );
		}
		return;
	}

	if ( count( $user_updates ) > 1 ) {
		$result = wp_update_user( $user_updates );

		if ( is_wp_error( $result ) ) {
			zymarg_os_notice( $result->get_error_message(), 'error' );
			return;
		}
	}

	foreach ( $meta_updates as $meta_key => $meta_value ) {
		update_user_meta( $user_id, $meta_key, $meta_value );
	}

	// Keep WooCommerce's billing name in step with the account name.
	if ( isset( $user_updates['first_name'] ) ) {
		update_user_meta( $user_id, 'billing_first_name', $user_updates['first_name'] );
	}
	if ( isset( $user_updates['last_name'] ) ) {
		update_user_meta( $user_id, 'billing_last_name', $user_updates['last_name'] );
	}

	/** Woo's post-save hook, so Dokan and other listeners still fire. */
	do_action( 'woocommerce_save_account_details', $user_id );

	/**
	 * Fires after the theme saves a profile card.
	 *
	 * @param int   $user_id User ID.
	 * @param array $fields  Fields that were written.
	 */
	do_action( 'zymarg_os_profile_saved', $user_id, array_merge( $user_updates, $meta_updates ) );

	zymarg_os_notice( __( 'Your profile is saved.', 'zymarg-os' ), 'success' );

	// Redirect so a refresh does not resubmit the form.
	// Ends the request on a normal POST; on an AJAX submit it unwinds so the
	// caller can re-render the Profile section in place. See
	// inc/account-ajax-forms.php.
	zymarg_os_acc_redirect( zymarg_os_profile_url() );
}
add_action( 'template_redirect', 'zymarg_os_handle_profile_save' );

/* ======================================================================
   4. RENDERER (accordion)
   ====================================================================== */

/**
 * Split a stored Y-m-d date into day / month / year parts.
 *
 * @param string $value Stored value.
 * @return array{day:string,month:string,year:string}
 */
function zymarg_os_profile_dob_parts( $value ) {
	$parts = array(
		'day'   => '',
		'month' => '',
		'year'  => '',
	);

	if ( preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', (string) $value, $m ) ) {
		$parts['year']  = $m[1];
		$parts['month'] = $m[2];
		$parts['day']   = $m[3];
	}

	return $parts;
}

/**
 * Render a date of birth as three dropdowns.
 *
 * The three controls post as one array under the field key, so the save handler
 * still sees a single field and the "absent means not edited" rule keeps working.
 * Years run newest first because a customer is far likelier to be 25 than 95.
 *
 * @param string $key   Field key.
 * @param string $id    DOM id for the first control, so the label still targets one.
 * @param string $value Stored Y-m-d value.
 * @return void
 */
function zymarg_os_profile_render_dob( $key, $id, $value ) {
	global $wp_locale;

	$parts = zymarg_os_profile_dob_parts( $value );
	$now   = (int) gmdate( 'Y' );

	/**
	 * Filter the youngest and oldest selectable birth years.
	 *
	 * @param array $range array( 'min' => int, 'max' => int )
	 */
	$range = (array) apply_filters(
		'zymarg_os_profile_dob_year_range',
		array(
			'min' => $now - 100,
			'max' => $now - 13,
		)
	);
	?>
	<div class="zym-dob">
		<select id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $key ); ?>[day]"
			aria-label="<?php esc_attr_e( 'Day of birth', 'zymarg-os' ); ?>">
			<option value=""><?php esc_html_e( 'Day', 'zymarg-os' ); ?></option>
			<?php
			for ( $d = 1; $d <= 31; $d++ ) :
				$dv = sprintf( '%02d', $d );
				?>
				<option value="<?php echo esc_attr( $dv ); ?>" <?php selected( $parts['day'], $dv ); ?>>
					<?php echo esc_html( (string) $d ); ?>
				</option>
			<?php endfor; ?>
		</select>

		<select name="<?php echo esc_attr( $key ); ?>[month]"
			aria-label="<?php esc_attr_e( 'Month of birth', 'zymarg-os' ); ?>">
			<option value=""><?php esc_html_e( 'Month', 'zymarg-os' ); ?></option>
			<?php
			for ( $m = 1; $m <= 12; $m++ ) :
				$mv = sprintf( '%02d', $m );
				// Month names come from the locale, so Bengali reads in Bengali.
				$ml = isset( $wp_locale ) ? $wp_locale->get_month( $m ) : $mv;
				?>
				<option value="<?php echo esc_attr( $mv ); ?>" <?php selected( $parts['month'], $mv ); ?>>
					<?php echo esc_html( $ml ); ?>
				</option>
			<?php endfor; ?>
		</select>

		<select name="<?php echo esc_attr( $key ); ?>[year]"
			aria-label="<?php esc_attr_e( 'Year of birth', 'zymarg-os' ); ?>">
			<option value=""><?php esc_html_e( 'Year', 'zymarg-os' ); ?></option>
			<?php for ( $y = (int) $range['max']; $y >= (int) $range['min']; $y-- ) : ?>
				<option value="<?php echo esc_attr( (string) $y ); ?>" <?php selected( $parts['year'], (string) $y ); ?>>
					<?php echo esc_html( (string) $y ); ?>
				</option>
			<?php endfor; ?>
		</select>
	</div>
	<?php
}

/**
 * Render one field from the registry.
 *
 * @param string $key     Field key.
 * @param array  $field   Field definition.
 * @param int    $user_id User ID.
 * @return void
 */
function zymarg_os_profile_render_field( $key, $field, $user_id ) {
	$value = zymarg_os_profile_get_value( $key, $field, $user_id );
	$id    = 'zym-pf-' . sanitize_html_class( $key );
	$class = 'zym-field' . ( ! empty( $field['half'] ) ? ' zym-field--half' : '' );

	if ( zymarg_os_profile_is_locked( $key ) ) {
		zymarg_os_profile_render_fixed_field( $field, $value, $class );
		return;
	}
	?>
	<div class="<?php echo esc_attr( $class ); ?>">
		<label class="zym-field__label" for="<?php echo esc_attr( $id ); ?>">
			<?php echo esc_html( $field['label'] ); ?>
			<?php if ( ! empty( $field['required'] ) ) : ?>
				<span class="zym-field__req" aria-hidden="true">*</span>
			<?php endif; ?>
		</label>

		<?php if ( 'textarea' === $field['type'] ) : ?>
			<textarea id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $key ); ?>" rows="3"
				<?php if ( ! empty( $field['maxlength'] ) ) : ?>maxlength="<?php echo esc_attr( $field['maxlength'] ); ?>"<?php endif; ?>
			><?php echo esc_textarea( $value ); ?></textarea>

		<?php elseif ( 'dob' === $field['type'] ) : ?>
			<?php zymarg_os_profile_render_dob( $key, $id, $value ); ?>

		<?php elseif ( 'select' === $field['type'] ) : ?>
			<select id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $key ); ?>">
				<?php foreach ( zymarg_os_profile_field_options( $field ) as $opt_val => $opt_label ) : ?>
					<option value="<?php echo esc_attr( $opt_val ); ?>" <?php selected( $value, $opt_val ); ?>>
						<?php echo esc_html( $opt_label ); ?>
					</option>
				<?php endforeach; ?>
			</select>

		<?php else : ?>
			<input type="<?php echo esc_attr( $field['type'] ); ?>"
				id="<?php echo esc_attr( $id ); ?>"
				name="<?php echo esc_attr( $key ); ?>"
				value="<?php echo esc_attr( $value ); ?>"
				<?php if ( ! empty( $field['autocomplete'] ) ) : ?>autocomplete="<?php echo esc_attr( $field['autocomplete'] ); ?>"<?php endif; ?>
				<?php if ( ! empty( $field['placeholder'] ) ) : ?>placeholder="<?php echo esc_attr( $field['placeholder'] ); ?>"<?php endif; ?>
				<?php if ( 'tel' === $field['type'] ) : ?>inputmode="tel" data-zym-phone<?php endif; ?>
				<?php if ( 'date' === $field['type'] ) : ?>max="<?php echo esc_attr( gmdate( 'Y-m-d' ) ); ?>"<?php endif; ?>
				<?php echo ! empty( $field['required'] ) ? 'required' : ''; ?>>
		<?php endif; ?>

		<?php if ( ! empty( $field['hint'] ) ) : ?>
			<p class="zym-hint"><?php echo esc_html( $field['hint'] ); ?></p>
		<?php endif; ?>
	</div>
	<?php
}

/**
 * Render a locked field as a stated fact rather than a control.
 *
 * No input, no name attribute, nothing to post — there is no disabled
 * `<select>` to re-enable in devtools and no hidden field to tamper with.
 * The customer still sees what the value is and that it is fixed.
 *
 * @param array  $field Field definition.
 * @param string $value Pinned value.
 * @param string $class Field wrapper classes.
 * @return void
 */
function zymarg_os_profile_render_fixed_field( $field, $value, $class ) {
	// Show the human label for a select ('Bangladeshi taka'), not the raw code.
	$display = $value;

	if ( 'select' === $field['type'] ) {
		$options = zymarg_os_profile_field_options( $field );

		if ( isset( $options[ $value ] ) ) {
			$display = $options[ $value ];
		}
	}

	if ( '' === trim( (string) $display ) ) {
		return;
	}
	?>
	<div class="<?php echo esc_attr( $class . ' zym-field--fixed' ); ?>">
		<span class="zym-field__label"><?php echo esc_html( $field['label'] ); ?></span>

		<p class="zym-fixed">
			<span class="zym-fixed__value"><?php echo esc_html( $display ); ?></span>
		</p>

		<?php if ( ! empty( $field['hint'] ) ) : ?>
			<p class="zym-hint"><?php echo esc_html( $field['hint'] ); ?></p>
		<?php endif; ?>
	</div>
	<?php
}

/**
 * Fields belonging to a group.
 *
 * @param string $group Group key.
 * @return array<string,array<string,mixed>>
 */
function zymarg_os_profile_group_fields( $group ) {
	return array_filter(
		zymarg_os_profile_fields(),
		function ( $f ) use ( $group ) {
			return isset( $f['group'] ) && $group === $f['group'];
		}
	);
}

/**
 * How many fields in a group are still empty. Drives the "2 to add" chip in
 * the card header, so a collapsed card still tells the user something.
 *
 * @param string $group   Group key.
 * @param int    $user_id User ID.
 * @return string
 */
function zymarg_os_profile_group_meta( $group, $user_id ) {
	$empty = 0;

	foreach ( zymarg_os_profile_group_fields( $group ) as $key => $field ) {
		if ( '' === trim( zymarg_os_profile_get_value( $key, $field, $user_id ) ) ) {
			$empty++;
		}
	}

	if ( 0 === $empty ) {
		return __( 'Complete', 'zymarg-os' );
	}

	return sprintf(
		/* translators: %d: number of empty fields. */
		_n( '%d to add', '%d to add', $empty, 'zymarg-os' ),
		$empty
	);
}

/**
 * Render a group as a self-contained card body with its own form.
 *
 * Each card posts independently. The save handler ignores any field absent
 * from the request, so saving one card can never blank another.
 *
 * @param string $group   Group key.
 * @param int    $user_id User ID.
 * @return void
 */
function zymarg_os_profile_render_group_form( $group, $user_id ) {
	$fields = zymarg_os_profile_group_fields( $group );

	if ( empty( $fields ) ) {
		return;
	}
	?>
	<form method="post" class="zym-acc-form" data-zym-ajax="profile" novalidate>
		<?php wp_nonce_field( 'zymarg_save_profile', 'zymarg_profile_nonce' ); ?>
		<div class="zym-field-grid">
			<?php
			foreach ( $fields as $key => $field ) {
				zymarg_os_profile_render_field( $key, $field, $user_id );
			}
			?>
		</div>
		<div class="zym-acc-save">
			<button type="submit" class="btn btn-primary btn-sm"><?php esc_html_e( 'Save', 'zymarg-os' ); ?></button>
		</div>
	</form>
	<?php
}

/**
 * Account overview — read-only trust signals.
 *
 * @param WP_User $user User object.
 * @return void
 */
function zymarg_os_profile_render_overview( $user ) {
	$rows = array(
		__( 'Member since', 'zymarg-os' ) => mysql2date( get_option( 'date_format' ), $user->user_registered ),
		__( 'Customer ID', 'zymarg-os' )  => '#' . $user->ID,
	);

	if ( function_exists( 'wc_get_customer_order_count' ) ) {
		$rows[ __( 'Total orders', 'zymarg-os' ) ] = (string) wc_get_customer_order_count( $user->ID );
	}
	if ( function_exists( 'wc_get_customer_total_spent' ) && function_exists( 'wc_price' ) ) {
		$rows[ __( 'Lifetime spend', 'zymarg-os' ) ] = wp_strip_all_tags( wc_price( wc_get_customer_total_spent( $user->ID ) ) );
	}

	/**
	 * Add loyalty tier, points, etc. without touching this file.
	 *
	 * @param array   $rows Label => value.
	 * @param WP_User $user User.
	 */
	$rows = apply_filters( 'zymarg_os_profile_overview_rows', $rows, $user );
	?>
	<dl class="zym-overview-grid">
		<?php foreach ( $rows as $label => $value ) : ?>
			<div class="zym-overview-item">
				<dt><?php echo esc_html( $label ); ?></dt>
				<dd><?php echo esc_html( $value ); ?></dd>
			</div>
		<?php endforeach; ?>
	</dl>
	<?php
}

/**
 * Read-only avatar thumbnail.
 *
 * The editable avatar control lives in the dashboard header and stays there.
 * This is a display-only mirror: no upload button, no file input, no second
 * copy of the AJAX flow. One control, one home.
 *
 * @param int $user_id User ID.
 * @return void
 */
function zymarg_os_profile_render_avatar( $user_id ) {
	$url = function_exists( 'zymarg_os_get_user_avatar_url' )
		? zymarg_os_get_user_avatar_url( $user_id, 96 )
		: get_avatar_url( $user_id, array( 'size' => 96 ) );
	?>
	<div class="zym-identity__avatar">
		<img src="<?php echo esc_url( $url ); ?>" alt="" width="44" height="44" loading="lazy">
	</div>
	<?php
}

/**
 * The Profile section.
 *
 * @return void
 */
function zymarg_os_acc_section_profile() {
	$user    = wp_get_current_user();
	$user_id = $user->ID;
	$score   = zymarg_os_profile_completeness( $user_id );
	?>
	<div class="panel-header">
		<?php echo zymarg_os_account_icon( 'user' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		<h2><?php esc_html_e( 'Profile', 'zymarg-os' ); ?></h2>
	</div>
	<p class="panel-desc"><?php esc_html_e( 'Manage your personal information and preferences.', 'zymarg-os' ); ?></p>

	<?php zymarg_os_print_notices(); ?>

	<div class="zym-completeness">
		<div class="zym-completeness__top">
			<span class="zym-completeness__label"><?php esc_html_e( 'Profile completeness', 'zymarg-os' ); ?></span>
			<span class="zym-completeness__pct"><?php echo esc_html( $score['percent'] . '%' ); ?></span>
		</div>
		<div class="zym-completeness__bar" role="progressbar"
			aria-valuenow="<?php echo esc_attr( $score['percent'] ); ?>" aria-valuemin="0" aria-valuemax="100">
			<span style="width:<?php echo esc_attr( $score['percent'] ); ?>%"></span>
		</div>
		<?php if ( ! empty( $score['missing'] ) ) : ?>
			<p class="zym-completeness__hint">
				<?php
				echo esc_html(
					sprintf(
						/* translators: %s: comma separated list of missing items. */
						__( 'Still missing: %s', 'zymarg-os' ),
						implode( ', ', array_slice( $score['missing'], 0, 3 ) )
					)
				);
				?>
			</p>
		<?php endif; ?>
	</div>

	<?php
	zymarg_os_accordion_open( 'profile' );

		/* -------- 1. Identity & email -------- */
		zymarg_os_accordion_card_start( 'identity', 1, __( 'Identity & email', 'zymarg-os' ), true );
		?>
		<div class="zym-identity__row">
			<?php zymarg_os_profile_render_avatar( $user_id ); ?>
			<div class="zym-identity__meta">
				<div class="zym-identity__name"><?php echo esc_html( $user->display_name ); ?></div>
				<div class="zym-identity__email"><?php echo esc_html( $user->user_email ); ?></div>
				<p class="zym-hint"><?php esc_html_e( 'Change your photo from the avatar at the top of your dashboard.', 'zymarg-os' ); ?></p>
			</div>
		</div>
		<?php
		zymarg_os_render_email_change_ui( $user );
		zymarg_os_accordion_card_end();

		/* -------- 2. Personal information -------- */
		zymarg_os_accordion_card_start(
			'personal',
			2,
			__( 'Personal information', 'zymarg-os' ),
			false,
			zymarg_os_profile_group_meta( 'personal', $user_id )
		);
		zymarg_os_profile_render_group_form( 'personal', $user_id );
		zymarg_os_accordion_card_end();

		/* -------- 3. Contact -------- */
		zymarg_os_accordion_card_start(
			'contact',
			3,
			__( 'Contact', 'zymarg-os' ),
			false,
			zymarg_os_profile_group_meta( 'contact', $user_id )
		);
		zymarg_os_profile_render_group_form( 'contact', $user_id );
		zymarg_os_accordion_card_end();

		/* -------- 4. Personal details -------- */
		zymarg_os_accordion_card_start(
			'details',
			4,
			__( 'Personal details', 'zymarg-os' ),
			false,
			zymarg_os_profile_group_meta( 'personal_extra', $user_id )
		);
		zymarg_os_profile_render_group_form( 'personal_extra', $user_id );
		zymarg_os_accordion_card_end();

		/* -------- 5. Preferences -------- */
		zymarg_os_accordion_card_start( 'preferences', 5, __( 'Preferences', 'zymarg-os' ) );
		zymarg_os_profile_render_group_form( 'preferences', $user_id );
		zymarg_os_accordion_card_end();

		/* -------- 6. Account overview -------- */
		zymarg_os_accordion_card_start( 'overview', 6, __( 'Account overview', 'zymarg-os' ) );
		zymarg_os_profile_render_overview( $user );
		zymarg_os_accordion_card_end();

	zymarg_os_accordion_close();
	?>

	<!-- Password intentionally does NOT live here. One home only. -->
	<p class="zym-profile-xlink">
		<?php echo zymarg_os_account_icon( 'lock' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		<?php esc_html_e( 'Looking for your password or active devices?', 'zymarg-os' ); ?>
		<a href="<?php echo esc_url( zymarg_os_security_url() ); ?>" data-zym-nav="security"><?php esc_html_e( 'Go to Security', 'zymarg-os' ); ?></a>
	</p>
	<?php
}
