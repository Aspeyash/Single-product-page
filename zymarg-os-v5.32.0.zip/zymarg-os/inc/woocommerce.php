<?php
/**
 * WooCommerce + Dokan integration.
 *
 * Adds WooCommerce theme support and the marketplace extras:
 *   - Product gallery zoom / lightbox / slider
 *   - Configurable shop columns
 *   - Quick View (AJAX)
 *   - Off-canvas cart drawer with live fragment updates
 *   - Standard content wrappers (since the theme has no visual header/footer)
 *   - Dokan vendor-store friendliness
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Declare WooCommerce support.
 *
 * @return void
 */
function zymarg_os_woo_setup() {
	add_theme_support( 'woocommerce' );
	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );
}
add_action( 'after_setup_theme', 'zymarg_os_woo_setup' );

/**
 * Number of products per row.
 *
 * @param int $columns Default columns.
 * @return int
 */
function zymarg_os_loop_columns( $columns ) {
	return zymarg_os_shop_columns();
}

/**
 * Resolve the desktop shop column count from ONE source of truth.
 *
 * Before 5.20.10 the loop filter defaulted to 5 while the CSS custom property
 * defaulted to 3 through the same filter name, so markup and styling disagreed
 * and the ZYMARG OS -> Product Card "desktop columns" setting was ignored on
 * the WooCommerce loop entirely. The admin setting now wins, with the filter
 * left in place for code-level overrides.
 *
 * @return int
 */
function zymarg_os_shop_columns() {
	$cols = function_exists( 'zymarg_os_product_card_columns' )
		? zymarg_os_product_card_columns( 'cols_desktop' )
		: 4;

	$cols = (int) apply_filters( 'zymarg_os_shop_columns', $cols );

	return (int) min( 8, max( 1, $cols ) );
}
add_filter( 'loop_shop_columns', 'zymarg_os_loop_columns' );

/**
 * Expose the shop column count to CSS via a custom property.
 *
 * @return void
 */
function zymarg_os_shop_columns_css() {
	if ( ! zymarg_os_is_woo_context() ) {
		return;
	}

	$cols = zymarg_os_shop_columns();
	wp_add_inline_style( 'zymarg-os-woo-product', ':root{--zymarg-shop-columns:' . $cols . ';}' );
}
add_action( 'wp_enqueue_scripts', 'zymarg_os_shop_columns_css', 21 );

/**
 * Products per page.
 *
 * @return int
 */
function zymarg_os_products_per_page() {
	return (int) apply_filters( 'zymarg_os_products_per_page', 12 );
}
add_filter( 'loop_shop_per_page', 'zymarg_os_products_per_page' );

/* ---------------------------------------------------------------------- *
 * Content wrappers
 * The theme ships no visual header/footer, so we provide the standard
 * WooCommerce content wrappers to keep shop pages structured.
 * ---------------------------------------------------------------------- */
remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );

/* ---------------------------------------------------------------------- *
 * No WooCommerce sidebar.
 * The theme owns the shop / product / archive layout end-to-end and ships no
 * sidebar by design. WooCommerce's default `woocommerce_get_sidebar()` calls
 * get_sidebar('shop'), which would otherwise load any sidebar.php sitting in
 * the theme folder (including a stray/legacy one) and print unwanted default
 * widgets. Removing it here guarantees no sidebar is ever loaded on WC pages.
 * ---------------------------------------------------------------------- */
remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );

/**
 * Open the WooCommerce content wrapper.
 *
 * @return void
 */
function zymarg_os_woo_wrapper_start() {
	echo '<div class="zymarg-container zymarg-container--wide zymarg-site-content"><main id="main" class="zymarg-woo-main">';
}
add_action( 'woocommerce_before_main_content', 'zymarg_os_woo_wrapper_start', 10 );

/**
 * Close the WooCommerce content wrapper.
 *
 * @return void
 */
function zymarg_os_woo_wrapper_end() {
	echo '</main></div>';
}
add_action( 'woocommerce_after_main_content', 'zymarg_os_woo_wrapper_end', 10 );

/* ---------------------------------------------------------------------- *
 * Quick View
 * ---------------------------------------------------------------------- */

/**
 * Add a Quick View button to each product in the loop.
 *
 * @return void
 */
function zymarg_os_quick_view_button() {
	if ( ! apply_filters( 'zymarg_os_enable_quick_view', true ) ) {
		return;
	}

	global $product;
	if ( ! $product ) {
		return;
	}

	printf(
		'<button type="button" class="zymarg-quick-view" data-product-id="%d">%s</button>',
		(int) $product->get_id(),
		esc_html__( 'Quick View', 'zymarg-os' )
	);
}
add_action( 'woocommerce_after_shop_loop_item', 'zymarg_os_quick_view_button', 15 );

/**
 * AJAX handler returning the product summary HTML for Quick View.
 *
 * @return void
 */
function zymarg_os_quick_view_ajax() {
	$product_id = isset( $_REQUEST['product_id'] ) ? absint( $_REQUEST['product_id'] ) : 0;

	if ( ! $product_id ) {
		wp_send_json_error( array( 'message' => 'invalid_product' ) );
	}

	$product = wc_get_product( $product_id );
	if ( ! $product ) {
		wp_send_json_error( array( 'message' => 'not_found' ) );
	}

	$post_object = get_post( $product_id );
	setup_postdata( $GLOBALS['post'] = $post_object ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited

	ob_start();
	echo '<div class="zymarg-quick-view-content">';
	echo '<div class="zymarg-quick-view-image">' . $product->get_image( 'woocommerce_single' ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo '<div class="zymarg-quick-view-summary">';
	echo '<h2>' . esc_html( $product->get_name() ) . '</h2>';
	echo '<div class="price">' . $product->get_price_html() . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo '<div class="description">' . wp_kses_post( $product->get_short_description() ) . '</div>';
	woocommerce_template_single_add_to_cart();
	echo '<a class="zymarg-btn zymarg-btn--secondary" href="' . esc_url( get_permalink( $product_id ) ) . '">' . esc_html__( 'View full details', 'zymarg-os' ) . '</a>';
	echo '</div></div>';
	$html = ob_get_clean();

	wp_reset_postdata();

	wp_send_json_success( array( 'html' => $html ) );
}
add_action( 'wp_ajax_zymarg_quick_view', 'zymarg_os_quick_view_ajax' );
add_action( 'wp_ajax_nopriv_zymarg_quick_view', 'zymarg_os_quick_view_ajax' );

/* ---------------------------------------------------------------------- *
 * Off-canvas cart + Quick View modal markup
 * ---------------------------------------------------------------------- */

/**
 * Print the cart drawer, overlay and quick-view modal containers in the footer.
 *
 * @return void
 */
function zymarg_os_woo_footer_markup() {
	if ( ! zymarg_os_is_woo_context() && ! is_front_page() ) {
		// Still print on shop-ish contexts; allow override.
		if ( ! apply_filters( 'zymarg_os_force_cart_markup', false ) ) {
			return;
		}
	}
	?>
	<div class="zymarg-drawer__overlay zymarg-cart-overlay" aria-hidden="true"></div>
	<aside class="zymarg-drawer zymarg-cart-drawer" aria-label="<?php esc_attr_e( 'Shopping cart', 'zymarg-os' ); ?>">
		<div class="zymarg-drawer__head">
			<h2 class="zymarg-drawer__title"><?php esc_html_e( 'Your Cart', 'zymarg-os' ); ?></h2>
			<button type="button" class="zymarg-drawer__close" aria-label="<?php esc_attr_e( 'Close cart', 'zymarg-os' ); ?>">&times;</button>
		</div>
		<div class="zymarg-drawer__body widget_shopping_cart_content">
			<?php
			if ( function_exists( 'woocommerce_mini_cart' ) ) {
				woocommerce_mini_cart();
			}
			?>
		</div>
	</aside>
	<div class="zymarg-modal" id="zymarg-quick-view" aria-hidden="true">
		<div class="zymarg-modal__overlay"></div>
		<div class="zymarg-modal__dialog zymarg-modal__dialog--wide" role="dialog" aria-modal="true">
			<button type="button" class="zymarg-modal__close" aria-label="<?php esc_attr_e( 'Close', 'zymarg-os' ); ?>">&times;</button>
			<div class="zymarg-modal__body"></div>
		</div>
	</div>
	<?php
}
add_action( 'zymarg_os_footer', 'zymarg_os_woo_footer_markup', 20 );

/**
 * Keep the cart-drawer count fragment in sync after AJAX add-to-cart.
 *
 * @param array $fragments Cart fragments.
 * @return array
 */
function zymarg_os_cart_fragments( $fragments ) {
	ob_start();
	?>
	<span class="zymarg-cart-count"><?php echo esc_html( WC()->cart ? WC()->cart->get_cart_contents_count() : 0 ); ?></span>
	<?php
	$fragments['.zymarg-cart-count'] = ob_get_clean();
	return $fragments;
}
add_filter( 'woocommerce_add_to_cart_fragments', 'zymarg_os_cart_fragments' );

/* ---------------------------------------------------------------------- *
 * WCPG Plugin Delegation: Quick View
 *
 * Remove the theme's Quick View button when the plugin is active (the
 * plugin has its own Quick View).
 * ---------------------------------------------------------------------- */

/**
 * Remove the theme's Quick View button when the WCPG plugin is active
 * (the plugin has its own Quick View).
 *
 * @return void
 */
function zymarg_os_wcpg_remove_theme_quick_view() {
	if ( function_exists( 'zymarg_os_wcpg_active' ) && zymarg_os_wcpg_active() ) {
		remove_action( 'woocommerce_after_shop_loop_item', 'zymarg_os_quick_view_button', 15 );
	}
}
add_action( 'wp', 'zymarg_os_wcpg_remove_theme_quick_view' );

/* ---------------------------------------------------------------------- *
 * WCPG Plugin Delegation: Related Products & Upsells
 *
 * Replace WooCommerce's default related/upsell product output with the
 * plugin's grid-wrapper template.
 * ---------------------------------------------------------------------- */

/**
 * Override the related products output on single product pages.
 *
 * @return void
 */
function zymarg_os_wcpg_related_products() {
	if ( ! function_exists( 'zymarg_os_wcpg_active' ) || ! zymarg_os_wcpg_active() ) {
		return;
	}

	// Remove default WooCommerce related products output.
	remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );

	// Add our custom related products renderer.
	add_action( 'woocommerce_after_single_product_summary', 'zymarg_os_wcpg_render_related_products', 20 );
}
add_action( 'wp', 'zymarg_os_wcpg_related_products' );

/**
 * Render related products using the plugin's grid wrapper.
 *
 * @return void
 */
function zymarg_os_wcpg_render_related_products() {
	global $product;

	if ( ! $product instanceof \WC_Product ) {
		return;
	}

	$args = apply_filters( 'woocommerce_output_related_products_args', array(
		'posts_per_page' => 4,
		'columns'        => 4,
		'orderby'        => 'rand',
		'order'          => 'desc',
	) );

	$related_ids = wc_get_related_products( $product->get_id(), $args['posts_per_page'] );

	if ( empty( $related_ids ) ) {
		return;
	}

	$related_products = array_filter( array_map( 'wc_get_product', $related_ids ) );

	if ( empty( $related_products ) ) {
		return;
	}

	echo '<section class="related products">';
	echo '<h2>' . esc_html__( 'Related products', 'woocommerce' ) . '</h2>';
	zymarg_os_render_product_grid( $related_products, $args['columns'] );
	echo '</section>';
}

/**
 * Override the upsells output on single product pages.
 *
 * @return void
 */
function zymarg_os_wcpg_upsells() {
	if ( ! function_exists( 'zymarg_os_wcpg_active' ) || ! zymarg_os_wcpg_active() ) {
		return;
	}

	// Remove default WooCommerce upsells output.
	remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15 );

	// Add our custom upsells renderer.
	add_action( 'woocommerce_after_single_product_summary', 'zymarg_os_wcpg_render_upsells', 15 );
}
add_action( 'wp', 'zymarg_os_wcpg_upsells' );

/**
 * Render upsell products using the plugin's grid wrapper.
 *
 * @return void
 */
function zymarg_os_wcpg_render_upsells() {
	global $product;

	if ( ! $product instanceof \WC_Product ) {
		return;
	}

	$upsell_ids = $product->get_upsell_ids();

	if ( empty( $upsell_ids ) ) {
		return;
	}

	// Respect WooCommerce defaults for upsells count.
	$limit           = apply_filters( 'woocommerce_upsells_total', -1 );
	$columns         = apply_filters( 'woocommerce_upsells_columns', 4 );
	$orderby         = apply_filters( 'woocommerce_upsells_orderby', 'rand' );

	$upsell_products = array_filter( array_map( 'wc_get_product', $upsell_ids ) );

	// Filter to only visible products.
	$upsell_products = array_filter( $upsell_products, function ( $p ) {
		return $p && $p->is_visible();
	} );

	if ( $limit > 0 ) {
		$upsell_products = array_slice( $upsell_products, 0, $limit );
	}

	if ( empty( $upsell_products ) ) {
		return;
	}

	echo '<section class="up-sells upsells products">';
	echo '<h2>' . esc_html__( 'You may also like&hellip;', 'woocommerce' ) . '</h2>';
	zymarg_os_render_product_grid( $upsell_products, $columns );
	echo '</section>';
}
