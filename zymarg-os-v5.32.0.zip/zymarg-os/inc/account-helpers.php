<?php
/**
 * ZYMARG Account — shared helpers.
 *
 * Small abstraction layer so the account modules never call WooCommerce or
 * the Login & Security plugin directly. Every dependency on someone else's
 * code funnels through this file. If Woo changes, or the plugin is
 * deactivated, or we replace either one day, this is the only file that has
 * to change — the feature files stay untouched.
 *
 * That is the whole point: depend on our own interface, not on theirs.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Show a message to the user.
 *
 * Prefers Woo's notice system (it already renders inside the account
 * panels), falls back to our own transient-backed queue so notices still
 * work with WooCommerce switched off.
 *
 * @param string $message Message text.
 * @param string $type    'success' | 'error' | 'notice'.
 * @return void
 */
function zymarg_os_notice( $message, $type = 'success' ) {
	if ( function_exists( 'wc_add_notice' ) ) {
		wc_add_notice( $message, $type );
		return;
	}

	if ( ! is_user_logged_in() ) {
		return;
	}

	$key   = 'zymarg_notices_' . get_current_user_id();
	$queue = get_transient( $key );
	$queue = is_array( $queue ) ? $queue : array();

	$queue[] = array(
		'message' => $message,
		'type'    => $type,
	);

	set_transient( $key, $queue, 5 * MINUTE_IN_SECONDS );
}

/**
 * Print and clear any fallback notices.
 *
 * Only used when WooCommerce is absent; Woo prints its own.
 *
 * @return void
 */
function zymarg_os_print_notices() {
	if ( function_exists( 'wc_add_notice' ) || ! is_user_logged_in() ) {
		return;
	}

	$key   = 'zymarg_notices_' . get_current_user_id();
	$queue = get_transient( $key );

	if ( empty( $queue ) || ! is_array( $queue ) ) {
		return;
	}

	foreach ( $queue as $notice ) {
		printf(
			'<div class="zym-notice zym-notice--%1$s">%2$s</div>',
			esc_attr( $notice['type'] ),
			esc_html( $notice['message'] )
		);
	}

	delete_transient( $key );
}

/**
 * Record a security-relevant event.
 *
 * Writes to the ZYMARG Login & Security audit log when that plugin is
 * active. When it is not, the event is still fired as an action so the
 * brand keeps an extension point and nothing silently disappears.
 *
 * @param int    $user_id User ID.
 * @param string $event   Event key, e.g. 'PASSWORD_CHANGED'.
 * @param array  $meta    Extra context.
 * @return void
 */
function zymarg_os_log_security_event( $user_id, $event, $meta = array() ) {
	$user_id = (int) $user_id;

	if ( class_exists( 'ZLS_Audit' ) && method_exists( 'ZLS_Audit', 'log' ) ) {
		ZLS_Audit::log(
			array(
				'user_id'    => $user_id,
				'event_type' => $event,
				'meta'       => $meta,
			)
		);
	}

	/**
	 * Always fires, plugin or not.
	 *
	 * @param int    $user_id User ID.
	 * @param string $event   Event key.
	 * @param array  $meta    Context.
	 */
	do_action( 'zymarg_os_security_event', $user_id, $event, $meta );
}

/**
 * Is the ZYMARG Login & Security plugin providing session management?
 *
 * @return bool
 */
function zymarg_os_has_session_manager() {
	return shortcode_exists( 'zymarg_security' ) && class_exists( 'ZLS_Sessions' );
}

/* ======================================================================
   SPA ASSET FORWARDING

   The account page swaps sections in over AJAX. That works for markup, but
   a section rendered inside admin-ajax.php cannot add anything to <head>:
   the browser already finished parsing the document. So when a plugin
   shortcode (Devices & sessions, Recent security activity) enqueues its own
   stylesheet at render time, the markup arrived and the CSS did not.

   The symptom is exact: navigate to Security from another menu item and the
   plugin's panels are unstyled; reload the page and they are fine, because
   a real page load runs wp_enqueue_scripts and prints the <link> properly.

   The fix is to notice which handles the render newly enqueued and hand
   their URLs back with the HTML, so the browser can add them itself. Doing
   it by diffing the queue keeps it generic: any future plugin section gets
   the same treatment with no extra code.
   ====================================================================== */

/**
 * Record which style and script handles are already accounted for.
 *
 * Call before rendering a section over AJAX, and pass the result to
 * zymarg_os_acc_asset_diff() afterwards.
 *
 * @return array{styles:array,scripts:array}
 */
function zymarg_os_acc_asset_snapshot() {
	$snapshot = array(
		'styles'  => array(),
		'scripts' => array(),
	);

	if ( function_exists( 'wp_styles' ) ) {
		$styles             = wp_styles();
		$snapshot['styles'] = array_merge( (array) $styles->queue, (array) $styles->done );
	}

	if ( function_exists( 'wp_scripts' ) ) {
		$scripts             = wp_scripts();
		$snapshot['scripts'] = array_merge( (array) $scripts->queue, (array) $scripts->done );
	}

	return $snapshot;
}

/**
 * Resolve one registered dependency to an absolute, versioned URL.
 *
 * @param object $dep         Registered _WP_Dependency.
 * @param string $default_ver Fallback version.
 * @return string URL, or '' when the handle has no src (an alias handle).
 */
function zymarg_os_acc_asset_url( $dep, $default_ver ) {
	$src = isset( $dep->src ) ? (string) $dep->src : '';

	if ( '' === $src ) {
		return '';
	}

	if ( 0 === strpos( $src, '//' ) ) {
		$src = ( is_ssl() ? 'https:' : 'http:' ) . $src;
	} elseif ( 0 === strpos( $src, '/' ) ) {
		$src = site_url( $src );
	}

	$ver = ( isset( $dep->ver ) && null !== $dep->ver && false !== $dep->ver ) ? $dep->ver : $default_ver;

	if ( $ver ) {
		$src = add_query_arg( 'ver', $ver, $src );
	}

	return $src;
}

/**
 * List the assets enqueued since a snapshot, in dependency order.
 *
 * Dependencies are walked as well, because a plugin stylesheet that depends
 * on a base stylesheet is useless without it. Inline CSS added through
 * wp_add_inline_style() is carried along too, since plugins often put their
 * accent colour there.
 *
 * @param array $before Result of zymarg_os_acc_asset_snapshot().
 * @return array{styles:array,scripts:array,inlineStyles:array}
 */
function zymarg_os_acc_asset_diff( $before ) {
	$assets = array(
		'styles'       => array(),
		'scripts'      => array(),
		'inlineStyles' => array(),
	);

	$collect = function ( $registry, $known, $type ) use ( &$assets ) {
		$current = array_merge( (array) $registry->queue, (array) $registry->done );
		$fresh   = array_values( array_diff( $current, $known ) );
		$seen    = array();

		$walk = function ( $handle ) use ( &$walk, &$seen, $registry, $known, $type, &$assets ) {
			if ( isset( $seen[ $handle ] ) || in_array( $handle, $known, true ) ) {
				return;
			}

			$seen[ $handle ] = true;

			if ( ! isset( $registry->registered[ $handle ] ) ) {
				return;
			}

			$dep = $registry->registered[ $handle ];

			// Dependencies first, so CSS lands in cascade order.
			foreach ( (array) $dep->deps as $parent ) {
				$walk( $parent );
			}

			$url = zymarg_os_acc_asset_url( $dep, $registry->default_version );

			if ( '' !== $url ) {
				$assets[ $type ][] = array(
					'handle' => $handle,
					'url'    => $url,
				);
			}

			if ( 'styles' === $type && ! empty( $dep->extra['after'] ) ) {
				$css = implode( "\n", array_filter( (array) $dep->extra['after'] ) );

				if ( '' !== trim( $css ) ) {
					$assets['inlineStyles'][] = array(
						'handle' => $handle,
						'css'    => $css,
					);
				}
			}
		};

		foreach ( $fresh as $handle ) {
			$walk( $handle );
		}
	};

	if ( function_exists( 'wp_styles' ) ) {
		$collect( wp_styles(), (array) $before['styles'], 'styles' );
	}

	if ( function_exists( 'wp_scripts' ) ) {
		$collect( wp_scripts(), (array) $before['scripts'], 'scripts' );
	}

	/**
	 * Filter the assets forwarded alongside an AJAX-rendered account section.
	 *
	 * Escape hatch for a plugin that registers its CSS on wp_enqueue_scripts
	 * only (never during the shortcode), which the diff above cannot see.
	 *
	 * @param array $assets Styles, scripts and inline CSS to forward.
	 */
	return (array) apply_filters( 'zymarg_os_account_ajax_assets', $assets );
}

/**
 * Minimum password length.
 *
 * Raised from WordPress's effectively-unlimited default and from the theme's
 * old 6. Eight is the NIST floor; filter it upward per brand policy.
 *
 * @return int
 */
function zymarg_os_min_password_length() {
	return (int) apply_filters( 'zymarg_os_min_password_length', zymarg_os_account_setting( 'min_password_length' ) );
}

/* ======================================================================
   ACCOUNT SETTINGS (option store)
   ====================================================================== */

/**
 * Option name for the Account & Security settings.
 *
 * Settings live here rather than in the admin file because the front end
 * reads them on every account request — the same reasoning as
 * inc/product-card-delegate.php. inc/admin-account.php only draws the form.
 */
if ( ! defined( 'ZYMARG_OS_ACCOUNT_OPTION' ) ) {
	define( 'ZYMARG_OS_ACCOUNT_OPTION', 'zymarg_os_account_settings' );
}

/**
 * Default settings.
 *
 * These are the values the theme shipped with before there was a settings
 * screen, so an existing site behaves identically until someone changes
 * something.
 *
 * @return array<string,mixed>
 */
function zymarg_os_account_defaults() {
	return array(
		'min_password_length'  => 8,
		'require_country_code' => 1,
		'default_country_code' => '880',
		'email_link_hours'     => 1,
		'users_column'         => 1,
		'whatsapp_message'     => 'Hi {first_name}, this is {store} support.',
	);
}

/**
 * All Account & Security settings, defaults filled in.
 *
 * @return array<string,mixed>
 */
function zymarg_os_account_settings() {
	$saved = get_option( ZYMARG_OS_ACCOUNT_OPTION, array() );
	$saved = is_array( $saved ) ? $saved : array();

	return wp_parse_args( $saved, zymarg_os_account_defaults() );
}

/**
 * One setting.
 *
 * @param string $key Setting key.
 * @return mixed Null when the key is unknown.
 */
function zymarg_os_account_setting( $key ) {
	$settings = zymarg_os_account_settings();

	return isset( $settings[ $key ] ) ? $settings[ $key ] : null;
}

/**
 * Apply the configured lifetime to email-confirmation links.
 *
 * @param int $ttl Default TTL in seconds.
 * @return int
 */
function zymarg_os_account_filter_email_ttl( $ttl ) {
	$hours = (int) zymarg_os_account_setting( 'email_link_hours' );

	if ( $hours < 1 ) {
		return (int) $ttl;
	}

	return $hours * HOUR_IN_SECONDS;
}
add_filter( 'zymarg_os_email_token_ttl', 'zymarg_os_account_filter_email_ttl' );
