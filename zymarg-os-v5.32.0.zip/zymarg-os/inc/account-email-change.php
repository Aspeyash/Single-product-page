<?php
/**
 * ZYMARG Account — email change.
 *
 * WordPress lets a logged-in user rewrite their own email address with no
 * password prompt and no verification of the new address. On a marketplace
 * that is the whole account: change the email, request a reset, own the
 * orders. This adds the two controls that matter — prove you know the
 * current password, and prove you can read the new inbox — before anything
 * is written to the user record.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/** Meta key holding the pending change. */
define( 'ZYMARG_OS_PENDING_EMAIL_META', '_zymarg_pending_email' );

/**
 * How long a confirmation link stays valid.
 *
 * @return int Seconds.
 */
function zymarg_os_email_token_ttl() {
	return (int) apply_filters( 'zymarg_os_email_token_ttl', HOUR_IN_SECONDS );
}

/**
 * Read the pending email change, if it is still valid.
 *
 * @param int $user_id User ID.
 * @return array{email:string,token:string,requested:int}|null
 */
function zymarg_os_get_pending_email( $user_id ) {
	$pending = get_user_meta( $user_id, ZYMARG_OS_PENDING_EMAIL_META, true );

	if ( ! is_array( $pending ) || empty( $pending['email'] ) || empty( $pending['token'] ) ) {
		return null;
	}

	$requested = isset( $pending['requested'] ) ? (int) $pending['requested'] : 0;

	if ( ( time() - $requested ) > zymarg_os_email_token_ttl() ) {
		delete_user_meta( $user_id, ZYMARG_OS_PENDING_EMAIL_META );
		return null;
	}

	return $pending;
}

/* ======================================================================
   REQUEST
   ====================================================================== */

/**
 * Handle a request to change the account email.
 *
 * @return void
 */
function zymarg_os_handle_email_change_request() {
	if ( ! isset( $_POST['zymarg_email_nonce'] ) ) {
		return;
	}

	if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['zymarg_email_nonce'] ) ), 'zymarg_change_email' ) ) {
		return;
	}

	if ( ! is_user_logged_in() ) {
		return;
	}

	$user    = wp_get_current_user();
	$user_id = $user->ID;

	// Throttle: 3 requests per 15 minutes. Without it this endpoint is a
	// free way to send mail to arbitrary addresses from your domain.
	$throttle_key = 'zym_email_req_' . $user_id;
	$attempts     = (int) get_transient( $throttle_key );

	if ( $attempts >= 3 ) {
		zymarg_os_notice( __( 'Too many requests. Please wait 15 minutes before trying again.', 'zymarg-os' ), 'error' );
		return;
	}

	set_transient( $throttle_key, $attempts + 1, 15 * MINUTE_IN_SECONDS );

	$password = isset( $_POST['email_current_password'] ) ? (string) wp_unslash( $_POST['email_current_password'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
	$new      = isset( $_POST['new_email'] ) ? sanitize_email( wp_unslash( $_POST['new_email'] ) ) : '';

	if ( ! wp_check_password( $password, $user->user_pass, $user_id ) ) {
		zymarg_os_notice( __( 'That password is not correct.', 'zymarg-os' ), 'error' );
		zymarg_os_log_security_event( $user_id, 'EMAIL_CHANGE_BAD_PASSWORD' );
		return;
	}

	if ( ! is_email( $new ) ) {
		zymarg_os_notice( __( 'Please enter a valid email address.', 'zymarg-os' ), 'error' );
		return;
	}

	if ( strtolower( $new ) === strtolower( $user->user_email ) ) {
		zymarg_os_notice( __( 'That is already your email address.', 'zymarg-os' ), 'notice' );
		return;
	}

	// If the address belongs to someone else, say the same thing we say on
	// success. Telling the truth here turns the form into a tool for
	// checking which addresses have accounts on the site.
	if ( email_exists( $new ) ) {
		zymarg_os_log_security_event( $user_id, 'EMAIL_CHANGE_TAKEN' );
		zymarg_os_notice(
			__( 'Check your new inbox. If we can use that address, a confirmation link is on its way.', 'zymarg-os' ),
			'success'
		);
		return;
	}

	// Store only the hash. A leaked database row must not be a usable link.
	$token = wp_generate_password( 32, false, false );

	update_user_meta(
		$user_id,
		ZYMARG_OS_PENDING_EMAIL_META,
		array(
			'email'     => $new,
			'token'     => hash( 'sha256', $token ),
			'requested' => time(),
		)
	);

	zymarg_os_send_email_confirmation( $user, $new, $token );
	zymarg_os_log_security_event( $user_id, 'EMAIL_CHANGE_REQUESTED' );

	zymarg_os_notice(
		__( 'Check your new inbox. If we can use that address, a confirmation link is on its way.', 'zymarg-os' ),
		'success'
	);

	zymarg_os_acc_redirect( zymarg_os_profile_url() );
}
add_action( 'template_redirect', 'zymarg_os_handle_email_change_request' );

/**
 * Send the confirmation link to the NEW address.
 *
 * @param WP_User $user  User.
 * @param string  $email New address.
 * @param string  $token Raw token.
 * @return void
 */
function zymarg_os_send_email_confirmation( $user, $email, $token ) {
	$link = add_query_arg(
		array(
			'zymarg_confirm_email' => rawurlencode( $token ),
			'uid'                  => $user->ID,
		),
		zymarg_os_profile_url()
	);

	$site = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );

	$subject = sprintf(
		/* translators: %s: site name. */
		__( 'Confirm your new email address on %s', 'zymarg-os' ),
		$site
	);

	$message  = sprintf(
		/* translators: %s: user display name. */
		__( 'Hi %s,', 'zymarg-os' ),
		$user->display_name
	) . "\r\n\r\n";
	$message .= __( 'You asked to use this address for your account. Confirm it by opening the link below:', 'zymarg-os' ) . "\r\n\r\n";
	$message .= $link . "\r\n\r\n";
	$message .= sprintf(
		/* translators: %d: number of minutes. */
		__( 'This link expires in %d minutes.', 'zymarg-os' ),
		(int) ( zymarg_os_email_token_ttl() / MINUTE_IN_SECONDS )
	) . "\r\n";
	$message .= __( 'If this was not you, ignore this email and change your password.', 'zymarg-os' ) . "\r\n";

	wp_mail( $email, $subject, $message );
}

/* ======================================================================
   CONFIRM
   ====================================================================== */

/**
 * Handle the confirmation link.
 *
 * @return void
 */
function zymarg_os_handle_email_change_confirm() {
	if ( ! isset( $_GET['zymarg_confirm_email'], $_GET['uid'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return;
	}

	$token   = sanitize_text_field( wp_unslash( $_GET['zymarg_confirm_email'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$user_id = absint( wp_unslash( $_GET['uid'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended

	if ( ! $user_id || '' === $token ) {
		return;
	}

	$pending = zymarg_os_get_pending_email( $user_id );

	if ( ! $pending ) {
		zymarg_os_notice( __( 'That confirmation link has expired. Please request the change again.', 'zymarg-os' ), 'error' );
		return;
	}

	if ( ! hash_equals( $pending['token'], hash( 'sha256', $token ) ) ) {
		zymarg_os_log_security_event( $user_id, 'EMAIL_CHANGE_BAD_TOKEN' );
		zymarg_os_notice( __( 'That confirmation link is not valid.', 'zymarg-os' ), 'error' );
		return;
	}

	// Re-check: someone else may have registered the address while this
	// link sat unopened in an inbox.
	if ( email_exists( $pending['email'] ) ) {
		delete_user_meta( $user_id, ZYMARG_OS_PENDING_EMAIL_META );
		zymarg_os_notice( __( 'That address is no longer available. Please try a different one.', 'zymarg-os' ), 'error' );
		return;
	}

	// wp_update_user() so `profile_update` fires and the Login & Security
	// plugin can alert BOTH the old and the new address.
	$result = wp_update_user(
		array(
			'ID'         => $user_id,
			'user_email' => $pending['email'],
		)
	);

	if ( is_wp_error( $result ) ) {
		zymarg_os_notice( $result->get_error_message(), 'error' );
		return;
	}

	// Keep WooCommerce's billing email in step, otherwise order receipts
	// keep going to the old address.
	if ( get_user_meta( $user_id, 'billing_email', true ) ) {
		update_user_meta( $user_id, 'billing_email', $pending['email'] );
	}

	delete_user_meta( $user_id, ZYMARG_OS_PENDING_EMAIL_META );
	zymarg_os_log_security_event( $user_id, 'EMAIL_CHANGED' );
	zymarg_os_notice( __( 'Your email address is confirmed and updated.', 'zymarg-os' ), 'success' );

	zymarg_os_acc_redirect( zymarg_os_profile_url() );
}
add_action( 'template_redirect', 'zymarg_os_handle_email_change_confirm', 5 );

/* ======================================================================
   CANCEL
   ====================================================================== */

/**
 * Cancel a pending email change.
 *
 * @return void
 */
function zymarg_os_handle_email_change_cancel() {
	if ( ! isset( $_POST['zymarg_email_cancel_nonce'] ) ) {
		return;
	}

	if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['zymarg_email_cancel_nonce'] ) ), 'zymarg_cancel_email' ) ) {
		return;
	}

	if ( ! is_user_logged_in() ) {
		return;
	}

	delete_user_meta( get_current_user_id(), ZYMARG_OS_PENDING_EMAIL_META );
	zymarg_os_notice( __( 'The pending email change is cancelled.', 'zymarg-os' ), 'success' );

	zymarg_os_acc_redirect( zymarg_os_profile_url() );
}
add_action( 'template_redirect', 'zymarg_os_handle_email_change_cancel' );

/* ======================================================================
   UI
   ====================================================================== */

/**
 * Render the email block inside the Profile identity card.
 *
 * @param WP_User $user User.
 * @return void
 */
function zymarg_os_render_email_change_ui( $user ) {
	$pending = zymarg_os_get_pending_email( $user->ID );
	?>
	<div class="zym-email-block">

		<?php if ( $pending ) : ?>
			<div class="zym-email-pending">
				<p>
					<?php
					echo esc_html(
						sprintf(
							/* translators: %s: pending email address. */
							__( 'Waiting for confirmation at %s', 'zymarg-os' ),
							$pending['email']
						)
					);
					?>
				</p>
				<p class="zym-hint"><?php esc_html_e( 'Your address changes only after you open the link we sent there.', 'zymarg-os' ); ?></p>
				<form method="post" data-zym-ajax="email_cancel">
					<?php wp_nonce_field( 'zymarg_cancel_email', 'zymarg_email_cancel_nonce' ); ?>
					<button type="submit" class="zym-linkbtn"><?php esc_html_e( 'Cancel this change', 'zymarg-os' ); ?></button>
				</form>
			</div>
		<?php endif; ?>

		<button type="button" class="zym-linkbtn" data-zym-email-toggle>
			<?php esc_html_e( 'Change email address', 'zymarg-os' ); ?>
		</button>

		<form method="post" class="zym-acc-form" data-zym-ajax="email" data-zym-email-form hidden novalidate>
			<?php wp_nonce_field( 'zymarg_change_email', 'zymarg_email_nonce' ); ?>

			<div class="zym-field">
				<label class="zym-field__label" for="zym-new-email"><?php esc_html_e( 'New email address', 'zymarg-os' ); ?></label>
				<input type="email" id="zym-new-email" name="new_email" autocomplete="email" required>
			</div>

			<div class="zym-field">
				<label class="zym-field__label" for="zym-email-pw"><?php esc_html_e( 'Your current password', 'zymarg-os' ); ?></label>
				<div class="zym-pw-wrap">
					<input type="password" id="zym-email-pw" name="email_current_password" autocomplete="current-password" required>
					<?php zymarg_os_pw_toggle_button(); ?>
				</div>
				<p class="zym-hint"><?php esc_html_e( 'We send a confirmation link to the new address. Nothing changes until you open it.', 'zymarg-os' ); ?></p>
			</div>

			<div class="zym-acc-save">
				<button type="submit" class="btn btn-primary btn-sm"><?php esc_html_e( 'Send confirmation', 'zymarg-os' ); ?></button>
				<button type="button" class="zym-linkbtn" data-zym-email-cancel><?php esc_html_e( 'Cancel', 'zymarg-os' ); ?></button>
			</div>
		</form>
	</div>
	<?php
}
