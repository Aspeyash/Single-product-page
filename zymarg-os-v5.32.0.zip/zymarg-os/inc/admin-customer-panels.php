<?php
/**
 * Account <-> Customers parity layer.
 *
 * WHY THIS FILE EXISTS
 * ---------------------------------------------------------------------------
 * The original plan was "make the front-end My Account page and the back-end
 * Customers screen the same". In practice the two drifted, for a reason that
 * is structural rather than sloppy:
 *
 *   - The front-end account page is largely a SHELL that hosts plugin content.
 *     Wishlist, Recently Viewed and Support own no data in this theme; they
 *     render whatever the Product Grid / Insights / Comm plugins provide.
 *   - The back-end Customers console is a THEME-OWNED DATA console. It can
 *     only show what the theme itself can query.
 *
 * So full sameness is impossible. What IS achievable, and what this file does,
 * is parity for every section the theme genuinely owns, plus an explicit,
 * labelled statement of the sections it does not own -- so a gap is never a
 * mystery again.
 *
 * WHAT THIS FILE ADDS TO THE CUSTOMER CONSOLE
 *   1. "Saved preferences"  -- the real notification/email toggles the customer
 *                              saved. This is literally "what the user is saving".
 *   2. "Reviews"            -- reviews the customer has left.
 *   3. "Full history"       -- change log + order/security timeline + staff
 *                              access, merged into ONE chronological stream.
 *   4. "Front-end only"     -- the honest list of plugin-owned sections.
 *   5. Locked profile fields are shown SIDE BY SIDE: the value pinned by the
 *      theme next to the value actually stored in the database, flagged when
 *      they disagree.
 *
 * DESIGN NOTE -- why nothing else was edited
 * ---------------------------------------------------------------------------
 * Everything here attaches through extension points the theme already
 * published: the zymarg_os_customer_console_sections filter, the
 * zymarg_os_customer_snapshot filter, and the zymarg_os_customer_console_panels
 * action. No existing file is modified, so this layer can be deleted again by
 * removing one require line, with zero risk to the account or console code.
 *
 * IMPORTANT -- this layer is READ ONLY.
 * The write path stays on the front end, in zymarg_os_handle_profile_save().
 * That handler owns validation, the locked-field rules and the change-log
 * hooks. A second write path in wp-admin would silently skip the change log
 * and duplicate the validation surface, which is exactly how audit trails rot.
 *
 * @package ZYMARG_OS
 * @since   5.30.0
 */

defined( 'ABSPATH' ) || exit;

/* ======================================================================
   1. WHAT THE THEME OWNS vs WHAT A PLUGIN OWNS
   ====================================================================== */

/**
 * The account sections whose data lives in a plugin, not in this theme.
 *
 * Keyed by the front-end section slug. The value explains where the data
 * actually lives, which is what you need to know when a customer asks a
 * question the console cannot answer.
 *
 * @since 5.30.0
 *
 * @return array<string,array{label:string,owner:string}>
 */
function zymarg_os_parity_plugin_owned_sections() {
	$sections = array(
		// Wishlist and Recently Viewed were listed here until 5.31.0. Both now
		// have real panels, because ZYMARG WC Product Grid turned out to persist
		// them in user meta rather than only in a cookie.
		'support' => array(
			'label' => __( 'Support', 'zymarg-os' ),
			'owner' => __( 'ZYMARG Comm (zymarg_support_chat shortcode). Conversations are stored by that plugin in its own tables, and it ships its own Conversations screen in wp-admin. Deliberately not duplicated here: private correspondence is better read in one place, under that plugin\'s own permissions.', 'zymarg-os' ),
		),
	);

	/**
	 * Filters the list of plugin-owned account sections.
	 *
	 * If one of these plugins later exposes a reader function, remove its entry
	 * here and add a real panel instead.
	 *
	 * @since 5.30.0
	 *
	 * @param array $sections Slug => label/owner.
	 */
	return (array) apply_filters( 'zymarg_os_parity_plugin_owned_sections', $sections );
}

/**
 * The saved-preference toggles the account page writes.
 *
 * These MUST mirror the two arrays inside zymarg_os_acc_section_notifications().
 * Kept as one definition here so the console reads exactly what the front end
 * writes, including each default, because an unsaved toggle and a toggle saved
 * to "off" are different facts and support needs to tell them apart.
 *
 * @since 5.30.0
 *
 * @return array<string,array{label:string,group:string,default:bool}>
 */
function zymarg_os_parity_pref_fields() {
	$fields = array(
		'zymarg_notif_order_updates' => array(
			'label'   => __( 'Order Updates', 'zymarg-os' ),
			'group'   => __( 'Alerts', 'zymarg-os' ),
			'default' => true,
		),
		'zymarg_notif_price_drops'   => array(
			'label'   => __( 'Price Drops', 'zymarg-os' ),
			'group'   => __( 'Alerts', 'zymarg-os' ),
			'default' => true,
		),
		'zymarg_notif_restock'       => array(
			'label'   => __( 'Restock Alerts', 'zymarg-os' ),
			'group'   => __( 'Alerts', 'zymarg-os' ),
			'default' => false,
		),
		'zymarg_pref_newsletter'     => array(
			'label'   => __( 'Newsletter', 'zymarg-os' ),
			'group'   => __( 'Email Communication', 'zymarg-os' ),
			'default' => true,
		),
		'zymarg_pref_promo_emails'   => array(
			'label'   => __( 'Promotional Emails', 'zymarg-os' ),
			'group'   => __( 'Email Communication', 'zymarg-os' ),
			'default' => false,
		),
		'zymarg_pref_order_emails'   => array(
			'label'   => __( 'Order Emails', 'zymarg-os' ),
			'group'   => __( 'Email Communication', 'zymarg-os' ),
			'default' => true,
		),
	);

	/**
	 * Filters the saved-preference fields mirrored into the console.
	 *
	 * @since 5.30.0
	 *
	 * @param array $fields Meta key => label/group/default.
	 */
	return (array) apply_filters( 'zymarg_os_parity_pref_fields', $fields );
}

/* ======================================================================
   2. RAW READS -- SEEING PAST A LOCKED FIELD
   ====================================================================== */

/**
 * Read user meta as it is ACTUALLY stored, ignoring the locked-field override.
 *
 * zymarg_os_profile_filter_locked_meta() short-circuits get_user_metadata for
 * locked keys so every reader on the site agrees on one value (currently BDT
 * and Asia/Dhaka). That is correct for the storefront, but it means the console
 * can never show you the truth -- and the console is the screen you open when
 * something looks wrong.
 *
 * This helper lifts the filter for exactly one read, then puts it back.
 *
 * @since 5.30.0
 *
 * @param int    $user_id  User ID.
 * @param string $meta_key Meta key.
 * @return string Stored value, or '' when nothing was ever saved.
 */
function zymarg_os_parity_raw_meta( $user_id, $meta_key ) {
	$has_filter = has_filter( 'get_user_metadata', 'zymarg_os_profile_filter_locked_meta' );

	if ( $has_filter ) {
		remove_filter( 'get_user_metadata', 'zymarg_os_profile_filter_locked_meta', 10 );
	}

	$value = get_user_meta( (int) $user_id, $meta_key, true );

	if ( $has_filter ) {
		add_filter( 'get_user_metadata', 'zymarg_os_profile_filter_locked_meta', 10, 3 );
	}

	return is_scalar( $value ) ? (string) $value : '';
}

/**
 * Compare every locked field's pinned value against its stored value.
 *
 * @since 5.30.0
 *
 * @param int $user_id User ID.
 * @return array<int,array{key:string,pinned:string,stored:string,differs:bool}>
 */
function zymarg_os_parity_locked_comparison( $user_id ) {
	if ( ! function_exists( 'zymarg_os_profile_locked_fields' ) ) {
		return array();
	}

	$rows = array();

	foreach ( zymarg_os_profile_locked_fields() as $key => $pinned ) {
		$stored = zymarg_os_parity_raw_meta( $user_id, $key );

		$rows[] = array(
			'key'     => (string) $key,
			'pinned'  => (string) $pinned,
			'stored'  => $stored,
			// Never saved is not a conflict, it just means the pin is the only value.
			'differs' => ( '' !== $stored && (string) $pinned !== $stored ),
		);
	}

	return $rows;
}

/* ======================================================================
   3. DATA PROVIDERS -- ADDED TO THE SHARED SNAPSHOT
   ====================================================================== */

/**
 * Saved preference values for one customer.
 *
 * @since 5.30.0
 *
 * @param int $user_id User ID.
 * @return array<int,array{label:string,group:string,value:bool,saved:bool}>
 */
function zymarg_os_parity_saved_prefs( $user_id ) {
	$user_id = (int) $user_id;
	$out     = array();

	foreach ( zymarg_os_parity_pref_fields() as $key => $field ) {
		$saved = get_user_meta( $user_id, $key, true );

		$out[] = array(
			'label' => $field['label'],
			'group' => $field['group'],
			// '' means the customer never touched it, so the default applies.
			'value' => ( '' === $saved ) ? (bool) $field['default'] : (bool) $saved,
			'saved' => ( '' !== $saved ),
		);
	}

	return $out;
}

/**
 * Product reviews left by one customer.
 *
 * @since 5.30.0
 *
 * @param int $user_id User ID.
 * @param int $limit   Maximum rows.
 * @return array<int,array{product:string,url:string,rating:int,time:string,approved:bool,excerpt:string}>
 */
function zymarg_os_parity_reviews( $user_id, $limit = 20 ) {
	$user_id = (int) $user_id;

	if ( ! $user_id || ! function_exists( 'wc_get_product' ) ) {
		return array();
	}

	$comments = get_comments(
		array(
			'user_id'   => $user_id,
			'post_type' => 'product',
			'status'    => 'all',
			'number'    => (int) $limit,
			'orderby'   => 'comment_date_gmt',
			'order'     => 'DESC',
		)
	);

	$out = array();

	foreach ( (array) $comments as $comment ) {
		$rating = get_comment_meta( $comment->comment_ID, 'rating', true );

		$out[] = array(
			'product'  => get_the_title( $comment->comment_post_ID ),
			'url'      => (string) get_comment_link( $comment ),
			'rating'   => (int) $rating,
			'time'     => (string) $comment->comment_date_gmt,
			'approved' => ( '1' === (string) $comment->comment_approved ),
			'excerpt'  => wp_trim_words( (string) $comment->comment_content, 18 ),
		);
	}

	return $out;
}

/**
 * One merged, newest-first history stream for a customer.
 *
 * The theme keeps three separate histories, each answering a different
 * question, and until now you had to read them in three places:
 *
 *   - customer_timeline()      orders + security events
 *   - get_change_log()         what field changed, from what, to what
 *   - get_customer_access_log() which staff member opened the record
 *
 * Disputes are chronological, so this normalises all three to a single shape
 * and sorts once. All timestamps in those sources are GMT, so they are
 * directly comparable.
 *
 * @since 5.30.0
 *
 * @param int   $user_id  User ID.
 * @param array $timeline Timeline already present in the snapshot.
 * @param int   $limit    Maximum rows returned.
 * @return array<int,array{time:string,kind:string,label:string,detail:string,actor:string,url:string}>
 */
function zymarg_os_parity_history( $user_id, $timeline = array(), $limit = 100 ) {
	$user_id = (int) $user_id;
	$events  = array();

	// 1. Orders + security, already assembled by the snapshot.
	foreach ( (array) $timeline as $entry ) {
		$events[] = array(
			'time'   => isset( $entry['time'] ) ? (string) $entry['time'] : '',
			'kind'   => isset( $entry['type'] ) ? (string) $entry['type'] : 'event',
			'label'  => isset( $entry['label'] ) ? (string) $entry['label'] : '',
			'detail' => isset( $entry['detail'] ) ? (string) $entry['detail'] : '',
			'actor'  => isset( $entry['actor'] ) ? (string) $entry['actor'] : '',
			'url'    => isset( $entry['url'] ) ? (string) $entry['url'] : '',
		);
	}

	// 2. Field-level changes -- the "what did they save" record.
	if ( function_exists( 'zymarg_os_get_change_log' ) ) {
		foreach ( zymarg_os_get_change_log( $user_id ) as $entry ) {
			$old = isset( $entry['old'] ) && '' !== $entry['old'] ? $entry['old'] : __( '(empty)', 'zymarg-os' );
			$new = isset( $entry['new'] ) && '' !== $entry['new'] ? $entry['new'] : __( '(empty)', 'zymarg-os' );

			$events[] = array(
				'time'   => isset( $entry['time'] ) ? (string) $entry['time'] : '',
				'kind'   => 'change',
				'label'  => isset( $entry['label'] ) ? (string) $entry['label'] : __( 'Account change', 'zymarg-os' ),
				/* translators: 1: previous value, 2: new value. */
				'detail' => sprintf( __( '%1$s -> %2$s', 'zymarg-os' ), $old, $new ),
				'actor'  => function_exists( 'zymarg_os_change_log_actor_label' )
					? zymarg_os_change_log_actor_label( $entry )
					: '',
				'url'    => '',
			);
		}
	}

	// 3. Staff who opened the record -- the privacy/audit answer.
	if ( function_exists( 'zymarg_os_get_customer_access_log' ) ) {
		foreach ( zymarg_os_get_customer_access_log( $user_id, 50 ) as $row ) {
			$events[] = array(
				'time'   => isset( $row->viewed_at ) ? (string) $row->viewed_at : '',
				'kind'   => 'access',
				'label'  => __( 'Record opened by staff', 'zymarg-os' ),
				'detail' => isset( $row->ip ) && $row->ip
					/* translators: 1: view context, 2: IP address. */
					? sprintf( __( '%1$s, from %2$s', 'zymarg-os' ), isset( $row->context ) ? $row->context : 'view', $row->ip )
					: (string) ( isset( $row->context ) ? $row->context : '' ),
				'actor'  => function_exists( 'zymarg_os_customer_access_actor_label' )
					? zymarg_os_customer_access_actor_label( $row )
					: '',
				'url'    => '',
			);
		}
	}

	// Newest first. Undated rows sink rather than randomly jumping to the top.
	usort(
		$events,
		static function ( $a, $b ) {
			return strcmp( (string) $b['time'], (string) $a['time'] );
		}
	);

	return array_slice( $events, 0, (int) $limit );
}

/**
 * Attach the parity data to the shared snapshot.
 *
 * Hooking the snapshot rather than the panels keeps ONE source of truth: the
 * capability check and the access-log write in zymarg_os_customer_snapshot()
 * already ran before this fires, so nothing here can leak data or skip an audit
 * entry. Anything else that consumes the snapshot later (an export, a REST
 * route, a vendor screen) gets these fields for free.
 *
 * @since 5.30.0
 *
 * @param array  $snapshot Assembled record.
 * @param int    $user_id  User ID.
 * @param string $context  View context.
 * @return array
 */
function zymarg_os_parity_extend_snapshot( $snapshot, $user_id, $context = 'view' ) {
	unset( $context );

	$snapshot['saved_prefs'] = zymarg_os_parity_saved_prefs( $user_id );
	$snapshot['reviews']     = zymarg_os_parity_reviews( $user_id );
	$snapshot['locked']      = zymarg_os_parity_locked_comparison( $user_id );
	$snapshot['history']     = zymarg_os_parity_history(
		$user_id,
		isset( $snapshot['timeline'] ) ? $snapshot['timeline'] : array()
	);

	// Added 5.31.0. These two read ZYMARG WC Product Grid's user meta, so they
	// are the first fields here that describe data this theme does not own.
	$snapshot['wishlist']        = zymarg_os_parity_product_list( $user_id, 'wishlist' );
	$snapshot['recently_viewed'] = zymarg_os_parity_product_list( $user_id, 'recently_viewed' );

	return $snapshot;
}
add_filter( 'zymarg_os_customer_snapshot', 'zymarg_os_parity_extend_snapshot', 10, 3 );

/* ======================================================================
   4. CONSOLE SECTIONS
   ====================================================================== */

/**
 * Register the new console sections.
 *
 * Ordered so the two questions support asks most often -- "what did they set"
 * and "what happened" -- sit next to each other.
 *
 * @since 5.30.0
 *
 * @param array $sections key => label.
 * @return array
 */
function zymarg_os_parity_console_sections( $sections ) {
	// Labels are kept terse on purpose. The toolbar sizes itself from the widest
	// option, so a long label here stretches the select, consumes the flex row
	// and forces .zym-cc__actions (margin-left:auto) into an ugly wrap. The
	// descriptive wording belongs in each panel's heading, where it costs nothing.
	$sections['saved_prefs']     = __( 'Saved preferences', 'zymarg-os' );
	$sections['reviews']         = __( 'Reviews', 'zymarg-os' );
	$sections['wishlist']        = __( 'Wishlist', 'zymarg-os' );
	$sections['recently_viewed'] = __( 'Recently viewed', 'zymarg-os' );
	$sections['history']         = __( 'Full history', 'zymarg-os' );
	$sections['frontend']        = __( 'Front-end only', 'zymarg-os' );

	return $sections;
}
add_filter( 'zymarg_os_customer_console_sections', 'zymarg_os_parity_console_sections' );

/**
 * Scoped styles for this layer.
 *
 * Two jobs, both defensive:
 *
 * 1. Cap the section select's width. The toolbar is a flex row that sizes to the
 *    widest <option>, so without a cap ANY future section label can stretch the
 *    control and break the bar's alignment -- the fault is structural, not just
 *    a matter of picking short words today.
 * 2. Colour the On/Off and change/access tags this layer introduces. The base
 *    .zym-cc__tag rules already exist; only the new modifiers are added here, so
 *    the original order/security tag colours are left untouched.
 *
 * Attached with wp_add_inline_style against the console's own handle rather than
 * by editing admin-customer-console.css, so this whole feature remains one file
 * plus one require line and can still be removed without touching your CSS.
 *
 * @since 5.30.1
 *
 * @return void
 */
function zymarg_os_parity_inline_styles() {
	$handle = 'zymarg-os-admin-customer-console';

	// Only fires on the Customers screen, because that is the only place the
	// console stylesheet is enqueued.
	if ( ! wp_style_is( $handle, 'enqueued' ) ) {
		return;
	}

	$css = '
		#zymarg-cc-section{max-width:280px;}
		.zym-cc__tag--on{background:#e6f6ec;color:#0a6b33;}
		.zym-cc__tag--off{background:#f1f1f1;color:#555;}
		.zym-cc__tag--change{background:#efe6f6;color:#4b0a6b;}
		.zym-cc__tag--access{background:#fff4e5;color:#8a4b00;}
	';

	wp_add_inline_style( $handle, $css );
}
// Priority 50: the console enqueues its stylesheet at 40, so the handle exists.
add_action( 'admin_enqueue_scripts', 'zymarg_os_parity_inline_styles', 50 );

/* ======================================================================
   5. PANELS
   ====================================================================== */

/**
 * Render the parity panels.
 *
 * @since 5.30.0
 *
 * @param array  $snapshot Customer snapshot.
 * @param string $current  Active section key.
 * @return void
 */
function zymarg_os_parity_render_panels( $snapshot, $current ) {
	zymarg_os_parity_panel_saved_prefs( $snapshot, $current );
	zymarg_os_parity_panel_reviews( $snapshot, $current );
	zymarg_os_parity_panel_products( $snapshot, $current, 'wishlist' );
	zymarg_os_parity_panel_products( $snapshot, $current, 'recently_viewed' );
	zymarg_os_parity_panel_history( $snapshot, $current );
	zymarg_os_parity_panel_frontend( $current );
}
add_action( 'zymarg_os_customer_console_panels', 'zymarg_os_parity_render_panels', 10, 2 );

/**
 * Panel: saved preferences, plus the locked-field comparison.
 *
 * @since 5.30.0
 *
 * @param array  $snapshot Snapshot.
 * @param string $current  Active section.
 * @return void
 */
function zymarg_os_parity_panel_saved_prefs( $snapshot, $current ) {
	$prefs  = isset( $snapshot['saved_prefs'] ) ? (array) $snapshot['saved_prefs'] : array();
	$locked = isset( $snapshot['locked'] ) ? (array) $snapshot['locked'] : array();

	zymarg_os_customer_panel_open( 'saved_prefs', $current, __( 'What this customer has switched on', 'zymarg-os' ) );

	echo '<p class="description zym-cc__readonly">' .
		esc_html__( 'These are the exact values saved from My Account -> Notifications. "Default" means the customer never changed it, so the theme default applies -- which is not the same as choosing off.', 'zymarg-os' ) .
		'</p>';

	if ( empty( $prefs ) ) {
		echo '<p class="description">' . esc_html__( 'No preferences available.', 'zymarg-os' ) . '</p>';
	} else {
		echo '<table class="widefat striped zym-cc__table"><thead><tr>' .
			'<th>' . esc_html__( 'Group', 'zymarg-os' ) . '</th>' .
			'<th>' . esc_html__( 'Preference', 'zymarg-os' ) . '</th>' .
			'<th>' . esc_html__( 'Value', 'zymarg-os' ) . '</th>' .
			'<th>' . esc_html__( 'Source', 'zymarg-os' ) . '</th>' .
			'</tr></thead><tbody>';

		foreach ( $prefs as $pref ) {
			echo '<tr><td>' . esc_html( $pref['group'] ) . '</td>' .
				'<td>' . esc_html( $pref['label'] ) . '</td>' .
				'<td>' . ( $pref['value']
					? '<span class="zym-cc__tag zym-cc__tag--on">' . esc_html__( 'On', 'zymarg-os' ) . '</span>'
					: '<span class="zym-cc__tag zym-cc__tag--off">' . esc_html__( 'Off', 'zymarg-os' ) . '</span>' ) . '</td>' .
				'<td>' . ( $pref['saved']
					? esc_html__( 'Saved by customer', 'zymarg-os' )
					: esc_html__( 'Default (never changed)', 'zymarg-os' ) ) . '</td></tr>';
		}

		echo '</tbody></table>';
	}

	// Locked fields, shown side by side as requested.
	if ( ! empty( $locked ) ) {
		echo '<h3 style="margin-top:1.5rem">' . esc_html__( 'Locked fields: pinned value vs stored value', 'zymarg-os' ) . '</h3>';
		echo '<p class="description zym-cc__readonly">' .
			esc_html__( 'The theme pins these values for the whole site, so the storefront always shows the pinned column. The stored column is what is really in the database for this customer. When the two disagree the row is flagged -- useful if an old value is still driving an export or a third-party plugin.', 'zymarg-os' ) .
			'</p>';

		echo '<table class="widefat striped zym-cc__table"><thead><tr>' .
			'<th>' . esc_html__( 'Field', 'zymarg-os' ) . '</th>' .
			'<th>' . esc_html__( 'Pinned (what everyone sees)', 'zymarg-os' ) . '</th>' .
			'<th>' . esc_html__( 'Stored (what is in the database)', 'zymarg-os' ) . '</th>' .
			'<th>' . esc_html__( 'Status', 'zymarg-os' ) . '</th>' .
			'</tr></thead><tbody>';

		foreach ( $locked as $row ) {
			echo '<tr><td><code>' . esc_html( $row['key'] ) . '</code></td>' .
				'<td>' . esc_html( $row['pinned'] ) . '</td>' .
				'<td>' . ( '' === $row['stored']
					? '<em>' . esc_html__( 'never saved', 'zymarg-os' ) . '</em>'
					: esc_html( $row['stored'] ) ) . '</td>' .
				'<td>' . ( $row['differs']
					? '<strong>' . esc_html__( 'Differs', 'zymarg-os' ) . '</strong>'
					: esc_html__( 'Consistent', 'zymarg-os' ) ) . '</td></tr>';
		}

		echo '</tbody></table>';
	}

	echo '</div>';
}

/**
 * Panel: reviews the customer left.
 *
 * @since 5.30.0
 *
 * @param array  $snapshot Snapshot.
 * @param string $current  Active section.
 * @return void
 */
function zymarg_os_parity_panel_reviews( $snapshot, $current ) {
	$reviews = isset( $snapshot['reviews'] ) ? (array) $snapshot['reviews'] : array();

	zymarg_os_customer_panel_open( 'reviews', $current, __( 'Reviews this customer left', 'zymarg-os' ) );

	if ( empty( $reviews ) ) {
		echo '<p class="description">' . esc_html__( 'This customer has not reviewed anything yet.', 'zymarg-os' ) . '</p></div>';

		return;
	}

	echo '<table class="widefat striped zym-cc__table"><thead><tr>' .
		'<th>' . esc_html__( 'Product', 'zymarg-os' ) . '</th>' .
		'<th>' . esc_html__( 'Rating', 'zymarg-os' ) . '</th>' .
		'<th>' . esc_html__( 'Review', 'zymarg-os' ) . '</th>' .
		'<th>' . esc_html__( 'Status', 'zymarg-os' ) . '</th>' .
		'<th>' . esc_html__( 'When', 'zymarg-os' ) . '</th>' .
		'</tr></thead><tbody>';

	$format = get_option( 'date_format' ) . ' ' . get_option( 'time_format' );

	foreach ( $reviews as $review ) {
		echo '<tr><td>' . ( $review['url']
			? '<a href="' . esc_url( $review['url'] ) . '">' . esc_html( $review['product'] ) . '</a>'
			: esc_html( $review['product'] ) ) . '</td>' .
			'<td>' . ( $review['rating']
				? esc_html( str_repeat( '*', min( 5, $review['rating'] ) ) . ' (' . $review['rating'] . '/5)' )
				: '&mdash;' ) . '</td>' .
			'<td>' . esc_html( $review['excerpt'] ) . '</td>' .
			'<td>' . ( $review['approved']
				? esc_html__( 'Published', 'zymarg-os' )
				: '<strong>' . esc_html__( 'Awaiting moderation', 'zymarg-os' ) . '</strong>' ) . '</td>' .
			'<td>' . esc_html(
				empty( $review['time'] ) ? '—' : mysql2date( $format, get_date_from_gmt( $review['time'] ) )
			) . '</td></tr>';
	}

	echo '</tbody></table></div>';
}

/**
 * Panel: the merged history stream.
 *
 * @since 5.30.0
 *
 * @param array  $snapshot Snapshot.
 * @param string $current  Active section.
 * @return void
 */
function zymarg_os_parity_panel_history( $snapshot, $current ) {
	$history = isset( $snapshot['history'] ) ? (array) $snapshot['history'] : array();

	zymarg_os_customer_panel_open( 'history', $current, __( 'Everything, in one timeline', 'zymarg-os' ) );

	echo '<p class="description zym-cc__readonly">' .
		esc_html__( 'Orders, security events, every saved field change, and every staff member who opened this record -- merged and sorted newest first. This is the screen to read during a dispute, because it shows cause and effect in order.', 'zymarg-os' ) .
		'</p>';

	if ( empty( $history ) ) {
		echo '<p class="description">' . esc_html__( 'Nothing recorded yet.', 'zymarg-os' ) . '</p></div>';

		return;
	}

	$labels = array(
		'order'    => __( 'Order', 'zymarg-os' ),
		'change'   => __( 'Saved a change', 'zymarg-os' ),
		'security' => __( 'Security', 'zymarg-os' ),
		'access'   => __( 'Staff viewed', 'zymarg-os' ),
		'event'    => __( 'Event', 'zymarg-os' ),
	);

	$format = get_option( 'date_format' ) . ' ' . get_option( 'time_format' );

	echo '<table class="widefat striped zym-cc__table"><thead><tr>' .
		'<th>' . esc_html__( 'Type', 'zymarg-os' ) . '</th>' .
		'<th>' . esc_html__( 'What', 'zymarg-os' ) . '</th>' .
		'<th>' . esc_html__( 'Detail', 'zymarg-os' ) . '</th>' .
		'<th>' . esc_html__( 'Who', 'zymarg-os' ) . '</th>' .
		'<th>' . esc_html__( 'When', 'zymarg-os' ) . '</th>' .
		'</tr></thead><tbody>';

	foreach ( $history as $event ) {
		$kind = $event['kind'];

		echo '<tr><td><span class="zym-cc__tag zym-cc__tag--' . esc_attr( $kind ) . '">' .
			esc_html( isset( $labels[ $kind ] ) ? $labels[ $kind ] : $kind ) . '</span></td>' .
			'<td>' . ( $event['url']
				? '<a href="' . esc_url( $event['url'] ) . '">' . esc_html( $event['label'] ) . '</a>'
				: esc_html( $event['label'] ) ) . '</td>' .
			'<td>' . esc_html( $event['detail'] ) . '</td>' .
			'<td>' . esc_html( $event['actor'] ) . '</td>' .
			'<td>' . esc_html(
				empty( $event['time'] ) ? '—' : mysql2date( $format, get_date_from_gmt( $event['time'] ) )
			) . '</td></tr>';
	}

	echo '</tbody></table></div>';
}

/**
 * Panel: the sections that exist on the front end but cannot be shown here.
 *
 * Deliberately a real panel rather than a silent omission. The gap was the
 * confusing part; naming it, and naming the plugin that owns each one, turns it
 * into information instead of a surprise.
 *
 * @since 5.30.0
 *
 * @param string $current Active section.
 * @return void
 */
function zymarg_os_parity_panel_frontend( $current ) {
	zymarg_os_customer_panel_open( 'frontend', $current, __( 'Sections that exist only on the front end', 'zymarg-os' ) );

	echo '<p class="description zym-cc__readonly">' .
		esc_html__( 'These My Account tabs are rendered by plugins rather than by this theme. Whether one can appear in this console depends entirely on where the owning plugin puts its data: user meta and custom tables can be read, but anything kept only in the visitor\'s browser cannot. Wishlist and Recently Viewed left this list in 5.31.0 once their storage was confirmed to be user meta.', 'zymarg-os' ) .
		'</p>';

	echo '<table class="widefat striped zym-cc__table"><thead><tr>' .
		'<th>' . esc_html__( 'Account tab', 'zymarg-os' ) . '</th>' .
		'<th>' . esc_html__( 'Where the data actually lives', 'zymarg-os' ) . '</th>' .
		'</tr></thead><tbody>';

	foreach ( zymarg_os_parity_plugin_owned_sections() as $slug => $info ) {
		echo '<tr><td><strong>' . esc_html( $info['label'] ) . '</strong><br><code>' . esc_html( $slug ) . '</code></td>' .
			'<td>' . esc_html( $info['owner'] ) . '</td></tr>';
	}

	echo '</tbody></table></div>';
}

/* ======================================================================
   6. PLUGIN-OWNED DATA: WISHLIST + RECENTLY VIEWED
   ----------------------------------------------------------------------
   Both lists belong to ZYMARG WC Product Grid, not to this theme. They are
   readable here because that plugin persists them in user meta for logged-in
   customers, keeping cookies and the WC session only as guest fallbacks.

   Read directly from user meta rather than through the plugin's own
   Wishlist_Store::get_ids() / Recently_Viewed::get_ids(), because both of
   those resolve get_current_user_id() -- from wp-admin that is the staff
   member, so calling them would return the staff member's own wishlist
   instead of the customer's. Reading the meta key is the only correct route
   for a third party asking about somebody else.
   ====================================================================== */

/**
 * Resolve the user-meta key used by ZYMARG WC Product Grid.
 *
 * Prefers the plugin's own constant so a future key rename is picked up
 * automatically, and falls back to the current literal when the plugin is not
 * active. The fallback matters: deactivating the plugin does not delete the
 * meta, so support can still see what a customer had saved.
 *
 * @since 5.31.0
 *
 * @param string $which Either 'wishlist' or 'recently_viewed'.
 * @return string Meta key.
 */
function zymarg_os_parity_wcpg_meta_key( $which ) {
	if ( 'wishlist' === $which ) {
		$class = 'Zymarg\\WCPG\\Wishlist\\Wishlist_Store';

		return ( class_exists( $class ) && defined( $class . '::USER_META_KEY' ) )
			? (string) constant( $class . '::USER_META_KEY' )
			: '_zymarg_wishlist';
	}

	$class = 'Zymarg\\WCPG\\Tracking\\Recently_Viewed';

	return ( class_exists( $class ) && defined( $class . '::USER_META_KEY' ) )
		? (string) constant( $class . '::USER_META_KEY' )
		: '_zymarg_recently_viewed';
}

/**
 * Read one of the two product lists for a specific customer.
 *
 * Stale IDs are reported rather than repaired. The plugin's own shortcode
 * self-heals the list by rewriting the meta when it meets a deleted product,
 * but this console is read-only on principle: a support agent opening a screen
 * must never silently rewrite customer data. A removed product therefore shows
 * as unavailable, which is also the more useful answer during a dispute.
 *
 * @since 5.31.0
 *
 * @param int    $user_id Customer user ID.
 * @param string $which   Either 'wishlist' or 'recently_viewed'.
 * @return array<int,array<string,mixed>>
 */
function zymarg_os_parity_product_list( $user_id, $which ) {
	$user_id = (int) $user_id;

	if ( $user_id <= 0 ) {
		return array();
	}

	$ids = get_user_meta( $user_id, zymarg_os_parity_wcpg_meta_key( $which ), true );

	if ( ! is_array( $ids ) || empty( $ids ) ) {
		return array();
	}

	$rows = array();

	foreach ( $ids as $id ) {
		$id = (int) $id;

		if ( $id <= 0 ) {
			continue;
		}

		$row = array(
			'id'        => $id,
			'name'      => '',
			'status'    => '',
			'price'     => '',
			'stock'     => '',
			'edit'      => '',
			'view'      => '',
			'available' => false,
		);

		$post = get_post( $id );

		if ( ! $post || 'product' !== $post->post_type ) {
			/* translators: %d: product ID. */
			$row['name']   = sprintf( __( 'Product #%d (no longer exists)', 'zymarg-os' ), $id );
			$row['status'] = 'missing';
			$rows[]        = $row;
			continue;
		}

		$row['name']      = get_the_title( $id );
		$row['status']    = (string) $post->post_status;
		$row['available'] = ( 'publish' === $post->post_status );
		$row['edit']      = (string) get_edit_post_link( $id, '' );
		$row['view']      = (string) get_permalink( $id );

		// WooCommerce is a hard requirement of this theme, but guard anyway so a
		// half-finished migration cannot take down the Customers screen.
		if ( function_exists( 'wc_get_product' ) ) {
			$product = wc_get_product( $id );

			if ( $product ) {
				$row['price'] = wp_strip_all_tags( (string) $product->get_price_html() );
				$row['stock']  = $product->is_in_stock()
					? __( 'In stock', 'zymarg-os' )
					: __( 'Out of stock', 'zymarg-os' );
			}
		}

		$rows[] = $row;
	}

	return $rows;
}

/**
 * Render either the Wishlist or the Recently viewed panel.
 *
 * One renderer for both, because the two lists are the same shape and only
 * differ in wording and ordering guarantees.
 *
 * @since 5.31.0
 *
 * @param array  $snapshot Customer snapshot.
 * @param string $current  Active section key.
 * @param string $which    Either 'wishlist' or 'recently_viewed'.
 * @return void
 */
function zymarg_os_parity_panel_products( $snapshot, $current, $which ) {
	$is_wishlist = ( 'wishlist' === $which );
	$rows        = isset( $snapshot[ $which ] ) ? (array) $snapshot[ $which ] : array();

	$title = $is_wishlist
		? __( 'Products this customer saved for later', 'zymarg-os' )
		: __( 'Products this customer looked at', 'zymarg-os' );

	zymarg_os_customer_panel_open( $which, $current, $title );

	if ( $is_wishlist ) {
		$intro = __( 'The customer\'s wishlist, newest entries last, exactly as stored by ZYMARG WC Product Grid. Items added before signing in are merged into the account at login, so this is the complete list for a registered customer. Useful for judging intent: a customer arguing about a price drop usually has the product sitting here.', 'zymarg-os' );
	} else {
		$intro = __( 'The last products this customer viewed, most recent first, capped at 20 by the plugin. Only browsing done while signed in is recorded -- unlike the wishlist, there is no merge of pre-login activity, so a customer who browsed as a guest and logged in afterwards will look emptier here than they really were.', 'zymarg-os' );
	}

	echo '<p class="description zym-cc__readonly">' . esc_html( $intro ) . '</p>';

	if ( empty( $rows ) ) {
		echo '<p class="description">' . esc_html(
			$is_wishlist
				? __( 'Nothing saved to the wishlist.', 'zymarg-os' )
				: __( 'No products viewed while signed in.', 'zymarg-os' )
		) . '</p>';

		echo '</div>';

		return;
	}

	echo '<table class="widefat striped zym-cc__table"><thead><tr>' .
		'<th>' . esc_html__( '#', 'zymarg-os' ) . '</th>' .
		'<th>' . esc_html__( 'Product', 'zymarg-os' ) . '</th>' .
		'<th>' . esc_html__( 'Price now', 'zymarg-os' ) . '</th>' .
		'<th>' . esc_html__( 'Availability', 'zymarg-os' ) . '</th>' .
		'</tr></thead><tbody>';

	$position = 0;

	foreach ( $rows as $row ) {
		++$position;

		echo '<tr><td>' . esc_html( (string) $position ) . '</td><td>';

		if ( $row['edit'] ) {
			echo '<a href="' . esc_url( $row['edit'] ) . '">' . esc_html( $row['name'] ) . '</a>';
		} else {
			echo esc_html( $row['name'] );
		}

		echo ' <code>#' . esc_html( (string) $row['id'] ) . '</code>';

		if ( $row['view'] && $row['available'] ) {
			echo ' <a href="' . esc_url( $row['view'] ) . '" target="_blank" rel="noopener">' .
				esc_html__( 'view', 'zymarg-os' ) . '</a>';
		}

		echo '</td><td>' . ( '' !== $row['price'] ? esc_html( $row['price'] ) : '&mdash;' ) . '</td><td>';

		if ( 'missing' === $row['status'] ) {
			echo '<span class="zym-cc__tag zym-cc__tag--off">' . esc_html__( 'Deleted', 'zymarg-os' ) . '</span>';
		} elseif ( ! $row['available'] ) {
			// Draft, private, pending or trashed: the customer cannot reach it.
			echo '<span class="zym-cc__tag zym-cc__tag--off">' .
				esc_html( sprintf( /* translators: %s: post status. */ __( 'Not public (%s)', 'zymarg-os' ), $row['status'] ) ) .
				'</span>';
		} elseif ( '' !== $row['stock'] ) {
			$tag = ( __( 'In stock', 'zymarg-os' ) === $row['stock'] ) ? 'on' : 'off';
			echo '<span class="zym-cc__tag zym-cc__tag--' . esc_attr( $tag ) . '">' .
				esc_html( $row['stock'] ) . '</span>';
		} else {
			echo '<span class="zym-cc__tag zym-cc__tag--on">' . esc_html__( 'Published', 'zymarg-os' ) . '</span>';
		}

		echo '</td></tr>';
	}

	echo '</tbody></table>';

	echo '<p class="description zym-cc__readonly">' . esc_html__( 'Prices and availability are current values, not what the customer saw at the time. Entries for removed products are shown rather than cleaned up, because this screen never writes to customer data.', 'zymarg-os' ) . '</p>';

	echo '</div>';
}
