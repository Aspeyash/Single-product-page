<?php
/**
 * Customer index — search that survives a million users.
 *
 * THE PROBLEM THIS SOLVES
 *   The old Customers search ran WP_User_Query with '*term*', which becomes
 *   LIKE '%term%'. MySQL cannot use an index for a leading wildcard, so every
 *   keystroke meant a full scan of wp_users, and the order count and lifetime
 *   value columns then ran two more WooCommerce lookups PER ROW. Fine at five
 *   thousand customers. At a million it is a table scan on every search and a
 *   timeout on the list.
 *
 * THE FIX
 *   One narrow, properly indexed table holding just the facts the list and the
 *   search dropdown need: name, email, username, phone, order count, lifetime
 *   value, last order date. Kept current by hooks as customers register, edit
 *   their profile and place orders, and backfilled in batches for accounts that
 *   already existed.
 *
 *   Search tries an index-usable prefix match FIRST ('rah%' uses the index).
 *   Only if that finds nothing does it fall back to a contains match, and even
 *   then it scans this narrow table rather than wp_users joined to usermeta.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Schema version.
 */
const ZYMARG_OS_CUSTOMER_INDEX_DB_VERSION = '1.0.0';

/**
 * Option holding the installed schema version.
 */
const ZYMARG_OS_CUSTOMER_INDEX_DB_OPTION = 'zymarg_os_customer_index_db';

/**
 * Option holding the backfill cursor (last user ID indexed).
 */
const ZYMARG_OS_CUSTOMER_INDEX_CURSOR_OPTION = 'zymarg_os_customer_index_cursor';

/**
 * Option set to '1' once the backfill has walked every existing user.
 */
const ZYMARG_OS_CUSTOMER_INDEX_READY_OPTION = 'zymarg_os_customer_index_ready';

/**
 * Fully-prefixed index table name.
 *
 * @return string
 */
function zymarg_os_customer_index_table() {
	global $wpdb;

	return $wpdb->prefix . 'zymarg_customer_index';
}

/* ======================================================================
   1. SCHEMA
   ====================================================================== */

/**
 * Create or upgrade the index table.
 *
 * @return void
 */
function zymarg_os_customer_index_install() {
	global $wpdb;

	require_once ABSPATH . 'wp-admin/includes/upgrade.php';

	$table   = zymarg_os_customer_index_table();
	$collate = $wpdb->get_charset_collate();

	/*
	 * Index notes:
	 * - display_name / user_email / username / phone carry plain indexes so a
	 *   prefix LIKE 'term%' is an index range scan, not a table scan.
	 * - total_spent and registered are indexed because the list sorts on them.
	 * - Column lengths are kept small deliberately; a 191-char index prefix is
	 *   the safe maximum under utf8mb4 on older MySQL.
	 */
	$sql = "CREATE TABLE {$table} (
		user_id bigint(20) unsigned NOT NULL,
		display_name varchar(191) NOT NULL DEFAULT '',
		user_email varchar(191) NOT NULL DEFAULT '',
		username varchar(191) NOT NULL DEFAULT '',
		phone varchar(60) NOT NULL DEFAULT '',
		order_count int(11) NOT NULL DEFAULT 0,
		total_spent decimal(18,4) NOT NULL DEFAULT 0.0000,
		last_order_at datetime DEFAULT NULL,
		registered datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
		is_vendor tinyint(1) NOT NULL DEFAULT 0,
		updated_at datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
		PRIMARY KEY  (user_id),
		KEY display_name (display_name),
		KEY user_email (user_email),
		KEY username (username),
		KEY phone (phone),
		KEY total_spent (total_spent),
		KEY registered (registered)
	) {$collate};";

	dbDelta( $sql );

	update_option( ZYMARG_OS_CUSTOMER_INDEX_DB_OPTION, ZYMARG_OS_CUSTOMER_INDEX_DB_VERSION );
}

/**
 * Install the table when missing or out of date.
 *
 * @return void
 */
function zymarg_os_customer_index_maybe_install() {
	if ( get_option( ZYMARG_OS_CUSTOMER_INDEX_DB_OPTION ) === ZYMARG_OS_CUSTOMER_INDEX_DB_VERSION ) {
		return;
	}

	zymarg_os_customer_index_install();
}
add_action( 'admin_init', 'zymarg_os_customer_index_maybe_install' );
add_action( 'after_switch_theme', 'zymarg_os_customer_index_install' );

/* ======================================================================
   2. KEEPING IT CURRENT
   ====================================================================== */

/**
 * Build the index row for one user.
 *
 * @param int $user_id User ID.
 * @return array|false Row data, or false when the user is gone.
 */
function zymarg_os_customer_index_row_data( $user_id ) {
	$user_id = (int) $user_id;
	$user    = get_userdata( $user_id );

	if ( ! $user ) {
		return false;
	}

	$order_count = 0;
	$total_spent = 0.0;
	$last_order  = null;

	if ( function_exists( 'wc_get_customer_order_count' ) ) {
		$order_count = (int) wc_get_customer_order_count( $user_id );
	}

	if ( function_exists( 'wc_get_customer_total_spent' ) ) {
		$total_spent = (float) wc_get_customer_total_spent( $user_id );
	}

	if ( $order_count > 0 && function_exists( 'zymarg_os_customer_orders' ) ) {
		$recent = zymarg_os_customer_orders( $user_id, 1 );

		if ( ! empty( $recent[0] ) && is_a( $recent[0], 'WC_Order' ) ) {
			$created = $recent[0]->get_date_created();

			if ( $created ) {
				$last_order = gmdate( 'Y-m-d H:i:s', $created->getTimestamp() );
			}
		}
	}

	$phone = get_user_meta( $user_id, 'billing_phone', true );

	return array(
		'user_id'       => $user_id,
		'display_name'  => (string) $user->display_name,
		'user_email'    => (string) $user->user_email,
		'username'      => (string) $user->user_login,
		'phone'         => (string) $phone,
		'order_count'   => $order_count,
		'total_spent'   => $total_spent,
		'last_order_at' => $last_order,
		'registered'    => (string) $user->user_registered,
		'is_vendor'     => function_exists( 'zymarg_os_customer_is_vendor' ) && zymarg_os_customer_is_vendor( $user_id ) ? 1 : 0,
		'updated_at'    => current_time( 'mysql', true ),
	);
}

/**
 * Write (insert or update) one customer's index row.
 *
 * @param int $user_id User ID.
 * @return bool
 */
function zymarg_os_customer_index_sync( $user_id ) {
	global $wpdb;

	$data = zymarg_os_customer_index_row_data( $user_id );

	if ( ! $data ) {
		return false;
	}

	if ( get_option( ZYMARG_OS_CUSTOMER_INDEX_DB_OPTION ) !== ZYMARG_OS_CUSTOMER_INDEX_DB_VERSION ) {
		zymarg_os_customer_index_install();
	}

	$table = zymarg_os_customer_index_table();

	// REPLACE keeps this a single statement whether the row exists or not.
	$wpdb->replace( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$table,
		$data,
		array( '%d', '%s', '%s', '%s', '%s', '%d', '%f', '%s', '%s', '%d', '%s' )
	);

	return true;
}

/**
 * Remove a customer from the index.
 *
 * @param int $user_id User ID.
 * @return void
 */
function zymarg_os_customer_index_delete( $user_id ) {
	global $wpdb;

	$wpdb->delete( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		zymarg_os_customer_index_table(),
		array( 'user_id' => (int) $user_id ),
		array( '%d' )
	);
}

add_action( 'user_register', 'zymarg_os_customer_index_sync' );
add_action( 'profile_update', 'zymarg_os_customer_index_sync' );
add_action( 'deleted_user', 'zymarg_os_customer_index_delete' );

/**
 * Re-index when a meta field shown in the list changes.
 *
 * @param int    $meta_id  Meta row ID.
 * @param int    $user_id  User ID.
 * @param string $meta_key Meta key.
 * @return void
 */
function zymarg_os_customer_index_meta_changed( $meta_id, $user_id, $meta_key ) {
	$watched = array( 'billing_phone', 'first_name', 'last_name' );

	if ( ! in_array( (string) $meta_key, $watched, true ) ) {
		return;
	}

	zymarg_os_customer_index_sync( $user_id );
}
add_action( 'updated_user_meta', 'zymarg_os_customer_index_meta_changed', 10, 3 );
add_action( 'added_user_meta', 'zymarg_os_customer_index_meta_changed', 10, 3 );

/**
 * Re-index a customer when one of their orders changes.
 *
 * @param int $order_id Order ID.
 * @return void
 */
function zymarg_os_customer_index_order_changed( $order_id ) {
	if ( ! function_exists( 'wc_get_order' ) ) {
		return;
	}

	$order = wc_get_order( $order_id );

	if ( ! $order ) {
		return;
	}

	$customer_id = (int) $order->get_customer_id();

	if ( $customer_id > 0 ) {
		zymarg_os_customer_index_sync( $customer_id );
	}
}
add_action( 'woocommerce_new_order', 'zymarg_os_customer_index_order_changed' );
add_action( 'woocommerce_order_status_changed', 'zymarg_os_customer_index_order_changed' );
add_action( 'woocommerce_update_order', 'zymarg_os_customer_index_order_changed' );

/* ======================================================================
   3. BACKFILL
   ====================================================================== */

/**
 * How many users to index per backfill batch.
 *
 * @return int
 */
function zymarg_os_customer_index_batch_size() {
	return (int) apply_filters( 'zymarg_os_customer_index_batch_size', 200 );
}

/**
 * Index the next batch of existing users.
 *
 * Uses keyset pagination (WHERE ID > cursor ORDER BY ID) rather than OFFSET.
 * OFFSET gets slower the deeper it goes; a primary-key range scan does not,
 * which is what makes this safe to run across millions of rows.
 *
 * @return int Users indexed in this batch.
 */
function zymarg_os_customer_index_backfill() {
	global $wpdb;

	if ( '1' === get_option( ZYMARG_OS_CUSTOMER_INDEX_READY_OPTION ) ) {
		return 0;
	}

	$batch  = zymarg_os_customer_index_batch_size();
	$cursor = (int) get_option( ZYMARG_OS_CUSTOMER_INDEX_CURSOR_OPTION, 0 );

	$ids = $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->prepare(
			"SELECT ID FROM {$wpdb->users} WHERE ID > %d ORDER BY ID ASC LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$cursor,
			$batch
		)
	);

	if ( empty( $ids ) ) {
		update_option( ZYMARG_OS_CUSTOMER_INDEX_READY_OPTION, '1' );

		return 0;
	}

	foreach ( $ids as $id ) {
		zymarg_os_customer_index_sync( (int) $id );
		$cursor = max( $cursor, (int) $id );
	}

	update_option( ZYMARG_OS_CUSTOMER_INDEX_CURSOR_OPTION, $cursor );

	if ( count( $ids ) < $batch ) {
		update_option( ZYMARG_OS_CUSTOMER_INDEX_READY_OPTION, '1' );
	}

	return count( $ids );
}
add_action( 'zymarg_os_customer_index_backfill_event', 'zymarg_os_customer_index_backfill' );

/**
 * Add the backfill schedule.
 *
 * @param array $schedules Cron schedules.
 * @return array
 */
function zymarg_os_customer_index_cron_schedule( $schedules ) {
	if ( ! isset( $schedules['zymarg_os_five_minutes'] ) ) {
		$schedules['zymarg_os_five_minutes'] = array(
			'interval' => 5 * MINUTE_IN_SECONDS,
			'display'  => __( 'Every five minutes (ZYMARG OS)', 'zymarg-os' ),
		);
	}

	return $schedules;
}
add_filter( 'cron_schedules', 'zymarg_os_customer_index_cron_schedule' ); // phpcs:ignore WordPress.WP.CronInterval.ChangeDetected

/**
 * Keep the backfill scheduled until it finishes, then stand down.
 *
 * @return void
 */
function zymarg_os_customer_index_schedule() {
	$next = wp_next_scheduled( 'zymarg_os_customer_index_backfill_event' );

	if ( '1' === get_option( ZYMARG_OS_CUSTOMER_INDEX_READY_OPTION ) ) {
		if ( $next ) {
			wp_unschedule_event( $next, 'zymarg_os_customer_index_backfill_event' );
		}

		return;
	}

	if ( ! $next ) {
		wp_schedule_event( time() + MINUTE_IN_SECONDS, 'zymarg_os_five_minutes', 'zymarg_os_customer_index_backfill_event' );
	}
}
add_action( 'admin_init', 'zymarg_os_customer_index_schedule' );

/**
 * Drop the schedule when the theme is switched away.
 *
 * @return void
 */
function zymarg_os_customer_index_unschedule() {
	$next = wp_next_scheduled( 'zymarg_os_customer_index_backfill_event' );

	if ( $next ) {
		wp_unschedule_event( $next, 'zymarg_os_customer_index_backfill_event' );
	}
}
add_action( 'switch_theme', 'zymarg_os_customer_index_unschedule' );

/**
 * Is the index still filling up?
 *
 * @return bool
 */
function zymarg_os_customer_index_is_building() {
	return '1' !== get_option( ZYMARG_OS_CUSTOMER_INDEX_READY_OPTION );
}

/**
 * Number of rows currently indexed.
 *
 * @return int
 */
function zymarg_os_customer_index_size() {
	global $wpdb;

	$table = zymarg_os_customer_index_table();

	return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
}

/**
 * Forget everything and rebuild from scratch.
 *
 * @return void
 */
function zymarg_os_customer_index_reset() {
	global $wpdb;

	$table = zymarg_os_customer_index_table();

	$wpdb->query( "TRUNCATE TABLE {$table}" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

	delete_option( ZYMARG_OS_CUSTOMER_INDEX_CURSOR_OPTION );
	delete_option( ZYMARG_OS_CUSTOMER_INDEX_READY_OPTION );

	zymarg_os_customer_index_schedule();
}

/**
 * "Rebuild index" button handler.
 *
 * @return void
 */
function zymarg_os_customer_index_handle_rebuild() {
	if ( ! function_exists( 'zymarg_os_can_view_customer_data' ) || ! zymarg_os_can_view_customer_data() ) {
		wp_die( esc_html__( 'Sorry, you are not allowed to do that.', 'zymarg-os' ) );
	}

	check_admin_referer( 'zymarg_os_customer_index_rebuild' );

	zymarg_os_customer_index_reset();
	zymarg_os_customer_index_backfill();

	wp_safe_redirect(
		add_query_arg(
			array(
				'page'      => 'zymarg-os-customers',
				'zymarg_ix' => 'rebuilding',
			),
			admin_url( 'admin.php' )
		)
	);
	exit;
}
add_action( 'admin_post_zymarg_os_customer_index_rebuild', 'zymarg_os_customer_index_handle_rebuild' );

/* ======================================================================
   4. SEARCH
   ====================================================================== */

/**
 * Search the index.
 *
 * Strategy, in order:
 *   1. A numeric term is treated as a user ID first — support usually has one.
 *   2. Prefix match (term%) on name, email, username and phone. This is the
 *      index-usable form and is what runs on virtually every search.
 *   3. Only when 1 and 2 find nothing, a contains match (%term%). Slower, but
 *      confined to this narrow table and capped by LIMIT.
 *
 * @param string $term  Search term.
 * @param int    $limit Max rows.
 * @return array<int,object>
 */
function zymarg_os_customer_index_search( $term, $limit = 20 ) {
	global $wpdb;

	$term  = trim( (string) $term );
	$limit = max( 1, min( 50, (int) $limit ) );

	if ( strlen( $term ) < 2 ) {
		return array();
	}

	$table = zymarg_os_customer_index_table();
	$rows  = array();

	/* 1. Exact user ID. */
	if ( ctype_digit( $term ) ) {
		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE user_id = %d LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				(int) $term
			)
		);

		if ( ! empty( $rows ) ) {
			return $rows;
		}
	}

	$like = $wpdb->esc_like( $term );

	/* 2. Prefix match — uses the indexes. */
	$prefix = $like . '%';

	$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->prepare(
			"SELECT * FROM {$table}
			 WHERE display_name LIKE %s
			    OR user_email LIKE %s
			    OR username LIKE %s
			    OR phone LIKE %s
			 ORDER BY order_count DESC, display_name ASC
			 LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$prefix,
			$prefix,
			$prefix,
			$prefix,
			$limit
		)
	);

	if ( ! empty( $rows ) ) {
		return $rows;
	}

	/*
	 * 3. Contains match. Deliberately last: this is the expensive shape, and
	 * it can be switched off entirely on very large installs.
	 */
	if ( ! apply_filters( 'zymarg_os_customer_index_deep_search', true, $term ) ) {
		return array();
	}

	$contains = '%' . $like . '%';

	$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->prepare(
			"SELECT * FROM {$table}
			 WHERE display_name LIKE %s
			    OR user_email LIKE %s
			    OR username LIKE %s
			    OR phone LIKE %s
			 ORDER BY order_count DESC, display_name ASC
			 LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$contains,
			$contains,
			$contains,
			$contains,
			$limit
		)
	);

	return is_array( $rows ) ? $rows : array();
}

/**
 * A page of customers from the index.
 *
 * @param array $args number, offset, orderby, order.
 * @return array<int,object>
 */
function zymarg_os_customer_index_page( $args = array() ) {
	global $wpdb;

	$args = wp_parse_args(
		$args,
		array(
			'number'  => 20,
			'offset'  => 0,
			'orderby' => 'registered',
			'order'   => 'DESC',
		)
	);

	// Whitelist: never interpolate a user-supplied column name.
	$columns = array( 'registered', 'display_name', 'total_spent', 'order_count', 'last_order_at', 'user_id' );
	$orderby = in_array( $args['orderby'], $columns, true ) ? $args['orderby'] : 'registered';
	$order   = 'ASC' === strtoupper( (string) $args['order'] ) ? 'ASC' : 'DESC';
	$table   = zymarg_os_customer_index_table();

	$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->prepare(
			"SELECT * FROM {$table} ORDER BY {$orderby} {$order} LIMIT %d OFFSET %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			max( 1, min( 100, (int) $args['number'] ) ),
			max( 0, (int) $args['offset'] )
		)
	);

	return is_array( $rows ) ? $rows : array();
}

/* ======================================================================
   5. AJAX ENDPOINT FOR THE DROPDOWN
   ====================================================================== */

/**
 * Nonce action for customer search.
 */
const ZYMARG_OS_CUSTOMER_SEARCH_NONCE = 'zymarg_os_customer_search';

/**
 * Serve the customer dropdown's search.
 *
 * @return void
 */
function zymarg_os_ajax_customer_search() {
	check_ajax_referer( ZYMARG_OS_CUSTOMER_SEARCH_NONCE, 'nonce' );

	if ( ! function_exists( 'zymarg_os_can_view_customer_data' ) || ! zymarg_os_can_view_customer_data() ) {
		wp_send_json_error( array( 'message' => __( 'Not allowed.', 'zymarg-os' ) ), 403 );
	}

	$term = isset( $_POST['term'] ) ? sanitize_text_field( wp_unslash( $_POST['term'] ) ) : '';

	if ( strlen( trim( $term ) ) < 2 ) {
		wp_send_json_success( array( 'results' => array() ) );
	}

	$rows    = zymarg_os_customer_index_search( $term, 20 );
	$results = array();

	foreach ( $rows as $row ) {
		$results[] = array(
			'id'     => (int) $row->user_id,
			'name'   => $row->display_name ? $row->display_name : $row->username,
			'email'  => $row->user_email,
			'orders' => (int) $row->order_count,
			'url'    => function_exists( 'zymarg_os_customer_view_url' ) ? zymarg_os_customer_view_url( $row->user_id ) : '',
		);
	}

	wp_send_json_success(
		array(
			'results'  => $results,
			'building' => zymarg_os_customer_index_is_building(),
		)
	);
}
add_action( 'wp_ajax_zymarg_os_customer_search', 'zymarg_os_ajax_customer_search' );
