<?php
/**
 * Required plugins notice.
 *
 * ZYMARG OS powers a multi-vendor marketplace, and that stack is five plugins:
 *
 *   - WooCommerce              (the store: products, cart, checkout, orders)
 *   - Dokan                    (the multi-vendor layer: sellers, commissions)
 *   - ZYMARG Vendor Dashboard  (the on-brand seller business OS)
 *   - ZYMARG Reviews Engine    (the product review experience)
 *   - ZYMARG Login & Security  (login, sessions, audit trail)
 *
 * Nothing else is required. As of v5.29.2 neither ZYMARG Theme Builder nor
 * Elementor is required or reported: the theme ships its own optional Header &
 * Footer builder (Customize -> ZYMARG OS -> Header & Footer, Simple or Block).
 *
 * NOTE on ZYMARG Login & Security: it is listed as required, but the theme is
 * deliberately built to survive without it. functions.php only loads the
 * theme's own login/session fallback when ZLS_VERSION is undefined. Listing it
 * here asks for it; it never hard-fails.
 *
 * This renders a friendly, dismissible admin notice listing whichever of the
 * five are not yet active, with one-click links to install / activate them.
 *
 * Detection is filterable, so you can point it at a different build:
 *   - zymarg_os_woocommerce_active           (bool)
 *   - zymarg_os_dokan_active                 (bool)
 *   - zymarg_os_vendor_dashboard_active      (bool)
 *   - zymarg_os_reviews_engine_active        (bool)
 *   - zymarg_os_login_security_active        (bool)
 *   - zymarg_os_vendor_dashboard_install_url (string)
 *   - zymarg_os_reviews_engine_install_url   (string)
 *   - zymarg_os_login_security_install_url   (string)
 *   - zymarg_os_required_plugins             (array) full list override
 *
 * NAME NOTE (v5.29.2): every function here is prefixed zymarg_os_ and has been
 * checked against the ZYMARG Vendor Dashboard plugin's global functions. The
 * theme and its plugins share one namespace - see the 5.29.1 changelog.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Is WooCommerce active?
 *
 * @return bool
 */
function zymarg_os_woocommerce_active() {
	$active = class_exists( 'WooCommerce' ) || defined( 'WC_VERSION' );

	return (bool) apply_filters( 'zymarg_os_woocommerce_active', $active );
}

/**
 * Is Dokan active?
 *
 * @return bool
 */
function zymarg_os_dokan_active() {
	$active = function_exists( 'dokan' )
		|| class_exists( 'WeDevs_Dokan' )
		|| defined( 'DOKAN_PLUGIN_VERSION' );

	return (bool) apply_filters( 'zymarg_os_dokan_active', $active );
}

/**
 * Is the ZYMARG Vendor Dashboard companion plugin active?
 *
 * Detects the constants the plugin defines in its main file.
 *
 * @return bool
 */
function zymarg_os_vendor_dashboard_active() {
	$active = defined( 'ZYMARG_VD_VERSION' )
		|| defined( 'ZYMARG_VD_FILE' )
		|| defined( 'ZYMARG_VD_DIR' );

	if ( ! $active && is_admin() ) {
		if ( ! function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$candidates = array(
			'zymarg-vendor-dashboard/zymarg-vendor-dashboard.php',
			'zymarg-os-vendor-dashboard/zymarg-vendor-dashboard.php',
		);
		foreach ( $candidates as $file ) {
			if ( is_plugin_active( $file ) ) {
				$active = true;
				break;
			}
		}
	}

	return (bool) apply_filters( 'zymarg_os_vendor_dashboard_active', $active );
}

/**
 * Is the ZYMARG Reviews Engine active?
 *
 * Uses the same signature the account Reviews tab already trusts for review
 * eligibility (see inc/account-sections.php).
 *
 * @return bool
 */
function zymarg_os_reviews_engine_active() {
	$active = class_exists( '\\ZymargReviewsEngine\\Review_Tracker' )
		|| defined( 'ZYMARG_REVIEWS_VERSION' );

	return (bool) apply_filters( 'zymarg_os_reviews_engine_active', $active );
}

/**
 * Is the ZYMARG Login & Security plugin active?
 *
 * ZLS_VERSION is the same constant functions.php checks to decide whether to
 * load the theme's login/session fallback, so this stays consistent with it.
 *
 * @return bool
 */
function zymarg_os_login_security_active() {
	$active = defined( 'ZLS_VERSION' ) || class_exists( 'ZLS_Audit' );

	return (bool) apply_filters( 'zymarg_os_login_security_active', $active );
}

/**
 * The full required-plugin stack, active state included.
 *
 * @return array<string,array{name:string,desc:string,url:string,active:bool}>
 */
function zymarg_os_required_plugins() {
	$plugins = array(
		'woocommerce'    => array(
			'name'   => __( 'WooCommerce', 'zymarg-os' ),
			'desc'   => __( 'The store engine - products, cart, checkout and orders. Importing, exporting and the shop features all require it.', 'zymarg-os' ),
			'url'    => self_admin_url( 'plugin-install.php?s=WooCommerce&tab=search&type=term' ),
			'active' => zymarg_os_woocommerce_active(),
		),
		'dokan'          => array(
			'name'   => __( 'Dokan', 'zymarg-os' ),
			'desc'   => __( 'The multi-vendor layer - sellers, stores, commissions and withdrawals.', 'zymarg-os' ),
			'url'    => self_admin_url( 'plugin-install.php?s=Dokan&tab=search&type=term' ),
			'active' => zymarg_os_dokan_active(),
		),
		'vendor_dash'    => array(
			'name'   => __( 'ZYMARG Vendor Dashboard', 'zymarg-os' ),
			'desc'   => __( 'The on-brand seller business OS - products, orders, earnings, analytics, reviews and messages.', 'zymarg-os' ),
			'url'    => apply_filters( 'zymarg_os_vendor_dashboard_install_url', self_admin_url( 'plugin-install.php' ) ),
			'active' => zymarg_os_vendor_dashboard_active(),
		),
		'reviews_engine' => array(
			'name'   => __( 'ZYMARG Reviews Engine', 'zymarg-os' ),
			'desc'   => __( 'The product review experience inside the Reviews tab, stored as native WooCommerce reviews.', 'zymarg-os' ),
			'url'    => apply_filters( 'zymarg_os_reviews_engine_install_url', self_admin_url( 'plugin-install.php' ) ),
			'active' => zymarg_os_reviews_engine_active(),
		),
		'login_security' => array(
			'name'   => __( 'ZYMARG Login & Security', 'zymarg-os' ),
			'desc'   => __( 'Branded login, session lengths and the security audit trail. Without it the theme falls back to its own built-in login.', 'zymarg-os' ),
			'url'    => apply_filters( 'zymarg_os_login_security_install_url', self_admin_url( 'plugin-install.php' ) ),
			'active' => zymarg_os_login_security_active(),
		),
	);

	return (array) apply_filters( 'zymarg_os_required_plugins', $plugins );
}

/**
 * Build the list of required plugins that are NOT yet active.
 *
 * @return array<string,array{name:string,desc:string,url:string,active:bool}>
 */
function zymarg_os_missing_recommended_plugins() {
	$missing = array();

	foreach ( zymarg_os_required_plugins() as $key => $plugin ) {
		if ( empty( $plugin['active'] ) ) {
			$missing[ $key ] = $plugin;
		}
	}

	return $missing;
}

/**
 * Handle dismissing the notice (per user).
 *
 * @return void
 */
function zymarg_os_dismiss_plugin_notice() {
	if ( ! isset( $_GET['zymarg_dismiss_plugins'] ) ) {
		return;
	}
	if ( ! isset( $_GET['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'zymarg_dismiss_plugins' ) ) {
		return;
	}
	update_user_meta( get_current_user_id(), 'zymarg_os_dismissed_plugin_notice', '1' );
	wp_safe_redirect( remove_query_arg( array( 'zymarg_dismiss_plugins', '_wpnonce' ) ) );
	exit;
}
add_action( 'admin_init', 'zymarg_os_dismiss_plugin_notice' );

/**
 * Render the required-plugins admin notice.
 *
 * @return void
 */
function zymarg_os_recommended_plugins_notice() {
	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}
	if ( get_user_meta( get_current_user_id(), 'zymarg_os_dismissed_plugin_notice', true ) ) {
		return;
	}

	$missing = zymarg_os_missing_recommended_plugins();
	if ( empty( $missing ) ) {
		return;
	}

	$dismiss_url = wp_nonce_url( add_query_arg( 'zymarg_dismiss_plugins', '1' ), 'zymarg_dismiss_plugins' );
	$spark       = function_exists( 'zymarg_discovery_spark' ) ? zymarg_discovery_spark( array( 'size' => 'md' ) ) : '';
	?>
	<div class="notice notice-info zymarg-recommend-notice" style="border-left-color:#9500a5;padding:14px 16px;position:relative;">
		<h3 style="margin:0 0 4px;display:flex;align-items:center;gap:8px;color:#36003d;">
			<?php echo $spark; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<?php esc_html_e( 'Finish setting up ZYMARG OS', 'zymarg-os' ); ?>
		</h3>
		<p style="margin:.2em 0 .8em;color:#534152;">
			<?php esc_html_e( 'ZYMARG OS runs a multi-vendor marketplace on five plugins. These are not yet active:', 'zymarg-os' ); ?>
		</p>
		<ul style="margin:0 0 .6em;padding:0;list-style:none;display:flex;flex-wrap:wrap;gap:10px;">
			<?php foreach ( $missing as $plugin ) : ?>
				<li style="background:#faf2fb;border:1px solid #e7c9e6;border-radius:8px;padding:10px 12px;flex:1 1 280px;">
					<strong style="color:#36003d;"><?php echo esc_html( $plugin['name'] ); ?></strong>
					<span style="display:block;color:#534152;font-size:13px;margin:2px 0 8px;"><?php echo esc_html( $plugin['desc'] ); ?></span>
					<a class="button button-primary" href="<?php echo esc_url( $plugin['url'] ); ?>"><?php esc_html_e( 'Install / Activate', 'zymarg-os' ); ?></a>
				</li>
			<?php endforeach; ?>
		</ul>
		<p style="margin:.2em 0 0;">
			<a href="<?php echo esc_url( $dismiss_url ); ?>" style="color:#857183;text-decoration:none;font-size:13px;"><?php esc_html_e( 'Dismiss', 'zymarg-os' ); ?></a>
		</p>
	</div>
	<?php
}
add_action( 'admin_notices', 'zymarg_os_recommended_plugins_notice' );

/* ---------------------------------------------------------------------- *
 * The wider ZYMARG plugin suite (reporting only, v5.29.3)
 * ---------------------------------------------------------------------- *
 * The five plugins above are REQUIRED. Everything below is inventory: the
 * Performance screen reports the whole suite so that when a customer reports a
 * bug you can see, in one place, exactly which ZYMARG plugins were installed,
 * which were switched on, and at what version.
 *
 * Nothing here changes behaviour. It never nags, never blocks, and never
 * marks an absent plugin as an error - a plugin you chose not to install is
 * not a fault.
 * ---------------------------------------------------------------------- */

/**
 * The expected ZYMARG plugin suite, by display name.
 *
 * Filter this if you add or retire a plugin.
 *
 * @return string[]
 */
function zymarg_os_zymarg_suite_expected() {
	$names = array(
		'ZYMARG Automation',
		'ZYMARG Backups',
		'ZYMARG Cart',
		'ZYMARG Checkout',
		'ZYMARG Communication',
		'ZYMARG Community Board',
		'ZYMARG Connection Engine',
		'ZYMARG Footer',
		'ZYMARG Header',
		'ZYMARG Homepage',
		'ZYMARG Insights',
		'ZYMARG Login Security',
		'ZYMARG Media Optimizer',
		'ZYMARG Payments',
		'ZYMARG Reviews Engine',
		'ZYMARG Search Result Page',
		'ZYMARG Search System',
		'ZYMARG Shipping',
		'ZYMARG Single Product',
		'ZYMARG Store Page',
		'ZYMARG Template Pack',
		'ZYMARG Vendor Dashboard',
		'ZYMARG WC Product Grid',
	);

	return (array) apply_filters( 'zymarg_os_zymarg_suite_expected', $names );
}

/**
 * Normalise a plugin name or folder into a comparison key.
 *
 * "ZYMARG Login & Security", "ZYMARG Login Security" and
 * "zymarg-login-security" all collapse to the same key, so a rename or an
 * ampersand never shows a plugin as missing when it is sitting right there.
 *
 * @param string $name Plugin name, slug or folder.
 * @return string
 */
function zymarg_os_plugin_name_key( $name ) {
	$key = strtolower( (string) $name );
	$key = str_replace( array( '&amp;', '&' ), ' and ', $key );
	$key = preg_replace( '/\\.php$/', '', $key );
	$key = preg_replace( '/[^a-z0-9]+/', '', $key );
	$key = preg_replace( '/^zymarg(os)?/', '', (string) $key );
	$key = preg_replace( '/^(and)+/', '', (string) $key );

	return (string) $key;
}

/**
 * Every installed ZYMARG plugin, keyed by comparison key.
 *
 * Reads the real plugin headers, so it reports what WordPress actually has on
 * disk rather than what the theme guesses.
 *
 * @return array<string,array{name:string,file:string,version:string,active:bool}>
 */
function zymarg_os_installed_zymarg_plugins() {
	if ( ! function_exists( 'get_plugins' ) || ! function_exists( 'is_plugin_active' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}

	if ( ! function_exists( 'get_plugins' ) ) {
		return array();
	}

	$found = array();

	foreach ( (array) get_plugins() as $file => $data ) {
		$name = isset( $data['Name'] ) ? (string) $data['Name'] : '';

		// Only ZYMARG-authored plugins, matched on either the display name or
		// the folder, so an odd header still gets picked up.
		if ( 0 !== stripos( $name, 'zymarg' ) && 0 !== stripos( (string) $file, 'zymarg' ) ) {
			continue;
		}

		$key = zymarg_os_plugin_name_key( $name ? $name : dirname( (string) $file ) );

		if ( '' === $key ) {
			continue;
		}

		$found[ $key ] = array(
			'name'    => $name ? $name : (string) $file,
			'file'    => (string) $file,
			'version' => isset( $data['Version'] ) ? (string) $data['Version'] : '',
			'active'  => function_exists( 'is_plugin_active' ) ? (bool) is_plugin_active( $file ) : false,
		);
	}

	return $found;
}

/**
 * The full suite report: every expected plugin plus any extra ZYMARG plugin
 * found on disk that is not on the expected list.
 *
 * Status is one of 'active', 'inactive' or 'missing'.
 *
 * @return array<int,array{name:string,version:string,status:string,extra:bool}>
 */
function zymarg_os_zymarg_suite() {
	$installed = zymarg_os_installed_zymarg_plugins();
	$rows      = array();
	$matched   = array();

	foreach ( zymarg_os_zymarg_suite_expected() as $name ) {
		$key = zymarg_os_plugin_name_key( $name );
		$hit = isset( $installed[ $key ] ) ? $installed[ $key ] : null;

		if ( null === $hit && '' !== $key ) {
			// Fall back to a containment match, so "ZYMARG WC Product Grid" still
			// finds a plugin registered as "ZYMARG WC Product Grid Engine".
			foreach ( $installed as $ikey => $data ) {
				if ( false !== strpos( $ikey, $key ) || false !== strpos( $key, $ikey ) ) {
					$hit = $data;
					$key = $ikey;
					break;
				}
			}
		}

		if ( null !== $hit ) {
			$matched[ $key ] = true;
		}

		$rows[] = array(
			'name'    => $name,
			'version' => null !== $hit ? $hit['version'] : '',
			'status'  => null === $hit ? 'missing' : ( $hit['active'] ? 'active' : 'inactive' ),
			'extra'   => false,
		);
	}

	// Any ZYMARG plugin installed but not on the expected list.
	foreach ( $installed as $ikey => $data ) {
		if ( ! empty( $matched[ $ikey ] ) ) {
			continue;
		}
		$rows[] = array(
			'name'    => $data['name'],
			'version' => $data['version'],
			'status'  => $data['active'] ? 'active' : 'inactive',
			'extra'   => true,
		);
	}

	return (array) apply_filters( 'zymarg_os_zymarg_suite', $rows );
}
