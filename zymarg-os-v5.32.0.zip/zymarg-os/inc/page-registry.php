<?php
/**
 * ZYMARG OS Page Registry.
 *
 * One screen that answers a question the site owner could not previously answer:
 * *which URLs does this site actually respond to, and who created them?*
 *
 * Three different layers register front-end URLs, and none of them tell you:
 *
 *   1. This theme  - 8 My Account endpoints registered in
 *      inc/account-dashboard.php (wishlist, returns, security, ...).
 *   2. WooCommerce - its own account endpoints (edit-account, payment-methods,
 *      order-pay, ...) plus its page settings (shop, cart, checkout).
 *   3. Dokan       - the vendor dashboard page, the store listing page and the
 *      vendor store URL prefix (/store/{vendor}/ by default).
 *
 * This file discovers all three, shows them in one table, and lets each URL be
 * switched off with a per-URL choice of what should happen instead: a redirect
 * to a page you choose, or a genuine 404.
 *
 * DESIGN NOTES
 *
 * - Discovery is admin-only. The front end never re-scans anything; enforcement
 *   reads a self-contained snapshot saved into the option, so a disabled URL
 *   costs one array lookup per request and never boots Dokan's nav system.
 *
 * - Endpoints stay REGISTERED even when disabled. Unregistering them would make
 *   the URL 404 for free, but it would also make a redirect impossible (there
 *   would be no query var left to detect), and it would require a rewrite flush
 *   on every save. Keeping registration and intercepting at template_redirect
 *   makes both outcomes behave identically and predictably.
 *
 * - Critical URLs are flagged, not blocked. Turning off checkout or
 *   edit-account will break core flows, so those rows carry a visible warning
 *   and a confirm prompt. The decision is still the site owner's.
 *
 * @package ZYMARG_OS
 * @since 5.19.0
 */

defined( 'ABSPATH' ) || exit;

const ZYMARG_OS_PAGE_REGISTRY_OPTION = 'zymarg_os_page_registry';

/* ---------------------------------------------------------------------- *
 * Stored rules
 * ---------------------------------------------------------------------- */

/**
 * Return every saved rule.
 *
 * Each rule is a self-contained snapshot so the front end never needs to run
 * discovery:
 *
 *   array(
 *     'enabled' => bool,           // false = intercept this URL
 *     'action'  => 'redirect|404',
 *     'target'  => string,         // redirect destination (may be empty)
 *     'source'  => 'theme|woocommerce|dokan',
 *     'type'    => 'endpoint|page|prefix',
 *     'slug'    => string,
 *     'page_id' => int,
 *     'label'   => string,
 *   )
 *
 * @return array<string,array>
 */
function zymarg_os_registry_rules() {
	$rules = get_option( ZYMARG_OS_PAGE_REGISTRY_OPTION, array() );

	return is_array( $rules ) ? $rules : array();
}

/**
 * Return one rule with defaults applied.
 *
 * Absent means "never touched", which must mean enabled. A registry that
 * defaulted to off would silently break the site the moment it was installed.
 *
 * @param string $id Registry item id.
 * @return array
 */
function zymarg_os_registry_rule( $id ) {
	$rules = zymarg_os_registry_rules();
	$rule  = isset( $rules[ $id ] ) && is_array( $rules[ $id ] ) ? $rules[ $id ] : array();

	return wp_parse_args(
		$rule,
		array(
			'enabled' => true,
			'action'  => 'redirect',
			'target'  => '',
			'source'  => '',
			'type'    => 'endpoint',
			'slug'    => '',
			'page_id' => 0,
			'label'   => '',
		)
	);
}

/**
 * Is this registry item switched off?
 *
 * @param string $id Registry item id.
 * @return bool
 */
function zymarg_os_registry_is_disabled( $id ) {
	$rule = zymarg_os_registry_rule( $id );

	return empty( $rule['enabled'] );
}

/* ---------------------------------------------------------------------- *
 * Discovery - theme
 * ---------------------------------------------------------------------- */

/**
 * Theme-registered My Account endpoints.
 *
 * @return array<string,array>
 */
function zymarg_os_registry_theme_items() {
	$items = array();

	if ( ! function_exists( 'zymarg_os_account_endpoint_slugs' ) ) {
		return $items;
	}

	/*
	 * Labels come from the sidebar config rather than the slug, because the two
	 * genuinely disagree: the 'coupons' endpoint is labelled "Vouchers". Showing
	 * only the slug would leave the owner hunting for a Vouchers row that does
	 * not exist.
	 */
	$labels = array();
	if ( function_exists( 'zymarg_os_account_nav_config' ) ) {
		$cfg = zymarg_os_account_nav_config();
		if ( isset( $cfg['items'] ) && is_array( $cfg['items'] ) ) {
			foreach ( $cfg['items'] as $slug => $def ) {
				$labels[ $slug ] = is_array( $def ) && isset( $def[0] ) ? $def[0] : $slug;
			}
		}
	}

	$account = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : home_url( '/my-account/' );

	// Pre-filter list, so disabling a row never hides it from its own screen.
	foreach ( zymarg_os_account_endpoint_slugs( false ) as $slug ) {
		$id = 'theme:' . $slug;

		$items[ $id ] = array(
			'id'       => $id,
			'source'   => 'theme',
			'type'     => 'endpoint',
			'slug'     => $slug,
			'label'    => isset( $labels[ $slug ] ) ? $labels[ $slug ] : ucwords( str_replace( '-', ' ', $slug ) ),
			'url'      => function_exists( 'wc_get_endpoint_url' ) ? wc_get_endpoint_url( $slug, '', $account ) : trailingslashit( $account ) . $slug . '/',
			'page_id'  => 0,
			'critical' => false,
			'note'     => '',
		);
	}

	return $items;
}

/* ---------------------------------------------------------------------- *
 * Discovery - WooCommerce
 * ---------------------------------------------------------------------- */

/**
 * WooCommerce account endpoints and page settings.
 *
 * @return array<string,array>
 */
function zymarg_os_registry_woo_items() {
	$items = array();

	if ( ! class_exists( 'WooCommerce' ) || ! function_exists( 'wc_get_page_permalink' ) ) {
		return $items;
	}

	$account = wc_get_page_permalink( 'myaccount' );

	// Theme endpoints are listed under the theme, so do not list them twice.
	$theme_slugs = function_exists( 'zymarg_os_account_endpoint_slugs' ) ? zymarg_os_account_endpoint_slugs( false ) : array();

	/*
	 * Endpoints WooCommerce needs in order to function. Switching these off does
	 * not tidy the site, it removes the customer's ability to pay, log in again
	 * or manage a card. Flagged loudly rather than hidden, because the owner
	 * asked to see every slug.
	 */
	$critical = array(
		'order-pay'                   => __( 'Customers pay for pending orders here. Disabling breaks payment retries.', 'zymarg-os' ),
		'order-received'              => __( 'The thank-you page after checkout. Disabling breaks order confirmation.', 'zymarg-os' ),
		'lost-password'               => __( 'Password reset. Disabling locks out customers who forget their password.', 'zymarg-os' ),
		'edit-account'                => __( 'Where customers change their name, email and password.', 'zymarg-os' ),
		'payment-methods'             => __( 'Saved cards. Required for subscriptions and saved-card checkout.', 'zymarg-os' ),
		'add-payment-method'          => __( 'Adding a new card. Required for saved-card checkout.', 'zymarg-os' ),
		'set-default-payment-method'  => __( 'Internal action URL used when changing the default card.', 'zymarg-os' ),
		'delete-payment-method'       => __( 'Internal action URL used when removing a card.', 'zymarg-os' ),
		'view-order'                  => __( 'A single order\'s detail page.', 'zymarg-os' ),
	);

	$query_vars = array();
	if ( function_exists( 'WC' ) && isset( WC()->query ) && is_object( WC()->query ) && method_exists( WC()->query, 'get_query_vars' ) ) {
		$query_vars = (array) WC()->query->get_query_vars();
	}

	$menu_labels = function_exists( 'wc_get_account_menu_items' ) ? (array) wc_get_account_menu_items() : array();

	foreach ( $query_vars as $key => $slug ) {
		$slug = (string) $slug;

		if ( '' === $slug || in_array( $slug, $theme_slugs, true ) ) {
			continue;
		}

		$id = 'woocommerce:' . $key;

		$items[ $id ] = array(
			'id'       => $id,
			'source'   => 'woocommerce',
			'type'     => 'endpoint',
			'slug'     => $slug,
			'label'    => isset( $menu_labels[ $key ] ) ? $menu_labels[ $key ] : ucwords( str_replace( '-', ' ', $key ) ),
			'url'      => function_exists( 'wc_get_endpoint_url' ) ? wc_get_endpoint_url( $key, '', $account ) : trailingslashit( $account ) . $slug . '/',
			'page_id'  => 0,
			'critical' => isset( $critical[ $key ] ),
			'note'     => isset( $critical[ $key ] ) ? $critical[ $key ] : '',
		);
	}

	// WooCommerce page settings. These are real pages with real slugs.
	$pages = array(
		'shop'      => __( 'Shop (product archive)', 'zymarg-os' ),
		'cart'      => __( 'Cart', 'zymarg-os' ),
		'checkout'  => __( 'Checkout', 'zymarg-os' ),
		'myaccount' => __( 'My Account', 'zymarg-os' ),
		'terms'     => __( 'Terms and Conditions', 'zymarg-os' ),
	);

	$critical_pages = array( 'cart', 'checkout', 'myaccount' );

	foreach ( $pages as $page => $label ) {
		$page_id = function_exists( 'wc_get_page_id' ) ? (int) wc_get_page_id( $page ) : 0;

		if ( $page_id <= 0 || ! get_post( $page_id ) ) {
			continue;
		}

		$id = 'woocommerce:page:' . $page;

		$items[ $id ] = array(
			'id'       => $id,
			'source'   => 'woocommerce',
			'type'     => 'page',
			'slug'     => (string) get_post_field( 'post_name', $page_id ),
			'label'    => $label,
			'url'      => (string) get_permalink( $page_id ),
			'page_id'  => $page_id,
			'critical' => in_array( $page, $critical_pages, true ),
			'note'     => in_array( $page, $critical_pages, true ) ? __( 'Required for customers to buy. Disable only if you have replaced it.', 'zymarg-os' ) : '',
		);
	}

	return $items;
}

/* ---------------------------------------------------------------------- *
 * Discovery - Dokan
 * ---------------------------------------------------------------------- */

/**
 * Dokan vendor pages, dashboard sub-pages and the store URL prefix.
 *
 * Every Dokan call here is guarded by function_exists and wrapped, because
 * Dokan's helpers move between major versions and some expect a seller context.
 * A registry that fataled when Dokan updated would be worse than no registry.
 *
 * @return array<string,array>
 */
function zymarg_os_registry_dokan_base() {
	$pages = get_option( 'dokan_pages', array() );
	$id    = ( is_array( $pages ) && ! empty( $pages['dashboard'] ) ) ? (int) $pages['dashboard'] : 0;
	$post  = $id > 0 ? get_post( $id ) : null;

	return $post ? (string) $post->post_name : 'dashboard';
}

/**
 * Discover Dokan's pages, store prefix and vendor dashboard sections.
 *
 * @return array
 */
function zymarg_os_registry_dokan_items() {
	$items = array();

	if ( ! function_exists( 'dokan' ) && ! class_exists( 'WeDevs_Dokan' ) ) {
		return $items;
	}

	// Dokan stores its page assignments in one option, keyed by purpose.
	$dokan_pages = get_option( 'dokan_pages', array() );

	if ( is_array( $dokan_pages ) ) {
		foreach ( $dokan_pages as $key => $page_id ) {
			$page_id = (int) $page_id;

			if ( $page_id <= 0 || ! get_post( $page_id ) ) {
				continue;
			}

			$id       = 'dokan:page:' . $key;
			$critical = in_array( $key, array( 'dashboard', 'store_listing' ), true );

			$items[ $id ] = array(
				'id'       => $id,
				'source'   => 'dokan',
				'type'     => 'page',
				'slug'     => (string) get_post_field( 'post_name', $page_id ),
				'label'    => get_the_title( $page_id ) . ' (' . str_replace( '_', ' ', $key ) . ')',
				'url'      => (string) get_permalink( $page_id ),
				'page_id'  => $page_id,
				'critical' => $critical,
				'note'     => $critical ? __( 'Core Dokan page. Vendors use this to run their store.', 'zymarg-os' ) : '',
			);
		}
	}

	/*
	 * Vendor store URL prefix. This is a rewrite prefix, not a page: every
	 * vendor store lives beneath it as /{prefix}/{vendor}/. Worth surfacing
	 * because it silently reserves a top-level path segment.
	 */
	if ( function_exists( 'dokan_get_option' ) ) {
		$prefix = (string) dokan_get_option( 'custom_store_url', 'dokan_general', 'store' );

		if ( '' !== $prefix ) {
			$items[ 'dokan:prefix:' . $prefix ] = array(
				'id'       => 'dokan:prefix:' . $prefix,
				'source'   => 'dokan',
				'type'     => 'prefix',
				'slug'     => $prefix,
				'label'    => __( 'Vendor store URL prefix', 'zymarg-os' ),
				'url'      => home_url( '/' . $prefix . '/' ),
				'page_id'  => 0,
				'critical' => true,
				'note'     => __( 'Every vendor storefront sits under this path. Disabling hides all vendor stores.', 'zymarg-os' ),
			);
		}
	}

	// Vendor dashboard sub-pages (products, orders, withdraw, settings, ...).
	if ( function_exists( 'dokan_get_dashboard_nav' ) ) {
		try {
			$nav = (array) dokan_get_dashboard_nav();
		} catch ( \Throwable $e ) {
			$nav = array();
		}

		foreach ( $nav as $key => $def ) {
			$key = (string) $key;

			if ( '' === $key ) {
				continue;
			}

			$id  = 'dokan:nav:' . $key;
			$url = '';

			if ( function_exists( 'dokan_get_navigation_url' ) ) {
				$url = (string) dokan_get_navigation_url( $key );
			}

			$items[ $id ] = array(
				'id'       => $id,
				'source'   => 'dokan',
				'type'     => 'nav',
				'base'     => zymarg_os_registry_dokan_base(),
				'slug'     => $key,
				'label'    => is_array( $def ) && ! empty( $def['title'] ) ? $def['title'] : ucwords( str_replace( '-', ' ', $key ) ),
				'url'      => $url,
				'page_id'  => 0,
				'critical' => false,
				'note'     => __( 'Vendor dashboard section.', 'zymarg-os' ),
			);
		}
	}

	return $items;
}

/**
 * Every discovered URL, from all three layers.
 *
 * @return array<string,array>
 */
function zymarg_os_registry_items() {
	$items = array_merge(
		zymarg_os_registry_theme_items(),
		zymarg_os_registry_woo_items(),
		zymarg_os_registry_dokan_items()
	);

	/**
	 * Filter the discovered page-registry items.
	 *
	 * Lets a plugin contribute its own slugs to the registry, or hide rows it
	 * does not want an admin switching off.
	 *
	 * @since 5.19.0
	 *
	 * @param array<string,array> $items Keyed by registry id.
	 */
	return (array) apply_filters( 'zymarg_os_page_registry_items', $items );
}

/* ---------------------------------------------------------------------- *
 * Front-end enforcement
 * ---------------------------------------------------------------------- */

/**
 * Does the current request match this rule?
 *
 * @param array  $rule Saved rule snapshot.
 * @param string $path Current request path, no surrounding slashes.
 * @return bool
 */
function zymarg_os_registry_request_matches( $rule, $path ) {
	global $wp;

	$slug = isset( $rule['slug'] ) ? (string) $rule['slug'] : '';
	$type = isset( $rule['type'] ) ? (string) $rule['type'] : 'endpoint';

	if ( '' === $slug ) {
		return false;
	}

	$segments = '' === $path ? array() : explode( '/', $path );

	if ( 'page' === $type ) {
		$page_id = isset( $rule['page_id'] ) ? (int) $rule['page_id'] : 0;

		if ( $page_id > 0 && is_page( $page_id ) ) {
			return true;
		}

		/*
		 * The shop page is a post-type archive, not a page query, so is_page()
		 * returns false there. Fall back to comparing the path.
		 */
		return ! empty( $segments ) && end( $segments ) === $slug;
	}

	/*
	 * Vendor dashboard sections live UNDER the dashboard page, and Dokan names
	 * the first one 'dashboard' as well. Matching on the slug alone therefore
	 * matched /dashboard/ itself, so switching off the "Dashboard" section took
	 * out every vendor's whole dashboard. Both segments must line up.
	 */
	if ( 'nav' === $type ) {
		$base = isset( $rule['base'] ) ? (string) $rule['base'] : '';

		if ( '' === $base || count( $segments ) < 2 ) {
			return false;
		}

		return $segments[0] === $base && $segments[1] === $slug;
	}

	if ( 'prefix' === $type ) {
		return ! empty( $segments ) && $segments[0] === $slug;
	}

	// Endpoints surface as query vars named after the slug.
	if ( isset( $wp->query_vars[ $slug ] ) ) {
		return true;
	}

	return in_array( $slug, $segments, true );
}

/**
 * Apply a rule: redirect somewhere useful, or serve a real 404.
 *
 * @param array $rule Saved rule snapshot.
 * @return void
 */
function zymarg_os_registry_block( $rule ) {
	$action = isset( $rule['action'] ) && '404' === $rule['action'] ? '404' : 'redirect';

	if ( 'redirect' === $action ) {
		$target = isset( $rule['target'] ) ? trim( (string) $rule['target'] ) : '';

		if ( '' === $target ) {
			/*
			 * No destination chosen. An account endpoint should fall back to My
			 * Account rather than the home page, so a customer who bookmarked
			 * /my-account/wishlist/ still lands somewhere they recognise.
			 */
			$is_account = in_array( (string) ( isset( $rule['source'] ) ? $rule['source'] : '' ), array( 'theme', 'woocommerce' ), true )
				&& 'endpoint' === ( isset( $rule['type'] ) ? $rule['type'] : '' );

			$target = ( $is_account && function_exists( 'wc_get_page_permalink' ) )
				? wc_get_page_permalink( 'myaccount' )
				: home_url( '/' );
		}

		wp_safe_redirect( $target, 302 );
		exit;
	}

	/*
	 * A real 404, not just a redirect to a "not found" page. The query is
	 * flagged, the status header is corrected and the theme's own 404 template
	 * renders, so search engines and the customer get a consistent answer.
	 */
	global $wp_query;

	if ( $wp_query instanceof WP_Query ) {
		$wp_query->set_404();
	}

	status_header( 404 );
	nocache_headers();

	/*
	 * Deliberately no include/exit here.
	 *
	 * template_redirect fires at the top of template-loader.php, BEFORE the
	 * template hierarchy is evaluated, so set_404() above is all WordPress needs
	 * in order to load the theme's own 404.php through its normal path.
	 * Including the template manually would bypass the template_include filter
	 * and risk rendering the header twice on requests where output had already
	 * started, which is the kind of bug that only shows up on some URLs.
	 */
}

/**
 * Intercept disabled URLs.
 *
 * Runs at template_redirect priority 0 - after the query is parsed, so query
 * vars are available, but before any template work happens.
 *
 * @return void
 */
function zymarg_os_registry_enforce() {
	if ( is_admin() || wp_doing_ajax() ) {
		return;
	}

	$rules = zymarg_os_registry_rules();

	if ( empty( $rules ) ) {
		return;
	}

	global $wp;
	$path = isset( $wp->request ) ? trim( (string) $wp->request, '/' ) : '';

	foreach ( $rules as $rule ) {
		if ( ! is_array( $rule ) || ! empty( $rule['enabled'] ) ) {
			continue;
		}

		if ( zymarg_os_registry_request_matches( $rule, $path ) ) {
			zymarg_os_registry_block( $rule );

			return;
		}
	}
}
add_action( 'template_redirect', 'zymarg_os_registry_enforce', 0 );

/**
 * Hide disabled theme sections from the My Account sidebar.
 *
 * Enforcement alone would leave a visible link that redirects or 404s, which
 * looks broken. Removing the link is the other half of switching a slug off.
 *
 * @param array $nav_items Sidebar items keyed by slug.
 * @return array
 */
function zymarg_os_registry_filter_nav( $nav_items ) {
	if ( ! is_array( $nav_items ) ) {
		return $nav_items;
	}

	foreach ( array_keys( $nav_items ) as $slug ) {
		if ( zymarg_os_registry_is_disabled( 'theme:' . $slug ) ) {
			unset( $nav_items[ $slug ] );
		}
	}

	return $nav_items;
}
add_filter( 'zymarg_os_account_nav_items', 'zymarg_os_registry_filter_nav', 20 );

/**
 * Hide disabled WooCommerce endpoints from WooCommerce's own account menu.
 *
 * @param array $items Menu items keyed by endpoint key.
 * @return array
 */
function zymarg_os_registry_filter_woo_menu( $items ) {
	if ( ! is_array( $items ) ) {
		return $items;
	}

	foreach ( array_keys( $items ) as $key ) {
		if ( zymarg_os_registry_is_disabled( 'woocommerce:' . $key ) ) {
			unset( $items[ $key ] );
		}
	}

	return $items;
}
add_filter( 'woocommerce_account_menu_items', 'zymarg_os_registry_filter_woo_menu', 20 );

/* ---------------------------------------------------------------------- *
 * Admin screen: ZYMARG OS -> Slugs & Pages
 * ---------------------------------------------------------------------- */

/**
 * Register the submenu.
 *
 * Priority 23 sits it after Import-Export (20), Performance (21) and Toast
 * Notification (22), keeping the menu in the order those were added.
 *
 * @return void
 */
function zymarg_os_registry_admin_menu() {
	add_submenu_page(
		'zymarg-os',
		__( 'Slugs & Pages', 'zymarg-os' ),
		__( 'Slugs & Pages', 'zymarg-os' ),
		'manage_options',
		'zymarg-os-pages',
		'zymarg_os_render_page_registry_page'
	);
}
add_action( 'admin_menu', 'zymarg_os_registry_admin_menu', 23 );

/**
 * Load the screen stylesheet only on this screen.
 *
 * @param string $hook_suffix Current admin page hook.
 * @return void
 */
function zymarg_os_registry_admin_assets( $hook_suffix ) {
	if ( false === strpos( (string) $hook_suffix, 'zymarg-os-pages' ) ) {
		return;
	}

	/*
	 * Depends on the brand layer so this file always prints AFTER it.
	 * inc/page-registry.php is required long after inc/admin-dark.php, so
	 * without this dependency the order was accidental -- and that is how
	 * this screen's header ended up looking different from every other
	 * ZYMARG screen before v5.27.9.
	 */
	wp_enqueue_style(
		'zymarg-os-admin-registry',
		ZYMARG_OS_URI . '/assets/css/admin-registry.css',
		wp_style_is( 'zymarg-os-admin-brand', 'registered' ) ? array( 'zymarg-os-admin-brand' ) : array(),
		ZYMARG_OS_VERSION
	);

	wp_enqueue_script(
		'zymarg-os-admin-registry',
		ZYMARG_OS_URI . '/assets/js/admin-registry.js',
		array(),
		ZYMARG_OS_VERSION,
		true
	);

	wp_localize_script(
		'zymarg-os-admin-registry',
		'ZymargRegistry',
		array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'zymarg_os_page_registry_ajax' ),
			'saving'  => __( 'Saving...', 'zymarg-os' ),
			'failed'  => __( 'Could not save. Your changes are still on screen - press Save again.', 'zymarg-os' ),
		)
	);
}
add_action( 'admin_enqueue_scripts', 'zymarg_os_registry_admin_assets' );

/**
 * Handle the save.
 *
 * Every discovered row is written, not just the changed ones, so the stored
 * snapshot always matches what the screen showed. Rows absent from the POST are
 * treated as enabled, which is what an unchecked checkbox means.
 *
 * @return void
 */
function zymarg_os_registry_handle_save() {
	if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
		return;
	}

	if ( empty( $_POST['zymarg_registry_action'] ) || 'save' !== $_POST['zymarg_registry_action'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
		return;
	}

	check_admin_referer( 'zymarg_os_page_registry_admin' );

	$posted = isset( $_POST['zymarg_registry'] ) && is_array( $_POST['zymarg_registry'] ) ? wp_unslash( $_POST['zymarg_registry'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	$design = isset( $_POST['zymarg_404'] ) && is_array( $_POST['zymarg_404'] ) ? wp_unslash( $_POST['zymarg_404'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput

	$off = zymarg_os_registry_store( $posted, $design );

	add_settings_error(
		'zymarg_os_page_registry',
		'saved',
		sprintf(
			/* translators: %d: number of URLs switched off. */
			_n( 'Saved. %d URL is switched off.', 'Saved. %d URLs are switched off.', $off, 'zymarg-os' ),
			(int) $off
		),
		'success'
	);
}
add_action( 'admin_init', 'zymarg_os_registry_handle_save' );

/**
 * Human-readable source label.
 *
 * @param string $source Source key.
 * @return string
 */
function zymarg_os_registry_source_label( $source ) {
	$labels = array(
		'theme'       => __( 'ZYMARG OS (this theme)', 'zymarg-os' ),
		'woocommerce' => __( 'WooCommerce', 'zymarg-os' ),
		'dokan'       => __( 'Dokan', 'zymarg-os' ),
	);

	return isset( $labels[ $source ] ) ? $labels[ $source ] : ucfirst( (string) $source );
}

/**
 * Render the screen.
 *
 * @return void
 */
function zymarg_os_render_page_registry_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Sorry, you are not allowed to manage this site\'s settings.', 'zymarg-os' ) );
	}

	settings_errors( 'zymarg_os_page_registry' );

	$items = zymarg_os_registry_items();

	// Group by source so the owner can see who created which URL.
	$grouped = array(
		'theme'       => array(),
		'woocommerce' => array(),
		'dokan'       => array(),
	);

	foreach ( $items as $id => $item ) {
		$source = isset( $item['source'] ) ? $item['source'] : 'theme';

		if ( ! isset( $grouped[ $source ] ) ) {
			$grouped[ $source ] = array();
		}

		$grouped[ $source ][ $id ] = $item;
	}

	$total = count( $items );
	$off   = 0;

	foreach ( array_keys( $items ) as $id ) {
		if ( zymarg_os_registry_is_disabled( $id ) ) {
			$off++;
		}
	}
	?>
	<div class="wrap zymarg-admin zymarg-registry">
		<h1>
			<?php if ( function_exists( 'zymarg_discovery_spark' ) ) { echo zymarg_discovery_spark( array( 'size' => 'lg' ) ); } // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<?php esc_html_e( 'Slugs & Pages', 'zymarg-os' ); ?>
			<span class="zymarg-registry__v">v<?php echo esc_html( ZYMARG_OS_VERSION ); ?></span>
		</h1>

		<p class="zymarg-registry__intro">
			<?php esc_html_e( 'Every front-end URL this site responds to, and which layer created it. Switch one off and choose what happens instead: send visitors somewhere useful, or return a genuine "not found".', 'zymarg-os' ); ?>
		</p>

		<p class="zymarg-registry__count">
			<?php
			printf(
				/* translators: 1: total URLs, 2: number switched off. */
				esc_html__( '%1$d URLs found - %2$d switched off.', 'zymarg-os' ),
				(int) $total,
				(int) $off
			);
			?>
		</p>

		<form method="post" class="zymarg-registry__form" data-registry-form="1">
			<?php wp_nonce_field( 'zymarg_os_page_registry_admin' ); ?>
			<input type="hidden" name="zymarg_registry_action" value="save" />

			<?php foreach ( $grouped as $source => $rows ) : ?>
				<?php if ( empty( $rows ) ) : ?>
					<?php continue; ?>
				<?php endif; ?>

				<?php
				/*
				 * Collapsed by default: with WooCommerce and Dokan active this screen
				 * lists 38 URLs, which is far past the point where a single flat table
				 * can be read. The count and the number switched off are surfaced in
				 * the summary so a closed group still answers "is anything off here?"
				 * without being opened.
				 *
				 * <details> rather than JavaScript tabs: it opens without scripts, is
				 * keyboard operable and searchable by the browser's own find-on-page.
				 */
				$group_off = 0;

				foreach ( $rows as $row_id => $row_item ) {
					if ( zymarg_os_registry_is_disabled( $row_id ) ) {
						$group_off++;
					}
				}
				?>
				<details class="zymarg-registry__group"<?php echo $group_off > 0 ? ' open' : ''; ?>>
					<summary>
						<span class="zymarg-registry__group-name"><?php echo esc_html( zymarg_os_registry_source_label( $source ) ); ?></span>
						<span class="zymarg-registry__badge"><?php echo (int) count( $rows ); ?></span>
						<?php if ( $group_off > 0 ) : ?>
							<span class="zymarg-registry__state is-gone">
								<?php
								printf(
									/* translators: %d: number switched off in this group. */
									esc_html( _n( '%d switched off', '%d switched off', $group_off, 'zymarg-os' ) ),
									(int) $group_off
								);
								?>
							</span>
						<?php endif; ?>
					</summary>

					<table class="zymarg-registry__table widefat">
						<thead>
							<tr>
								<th class="col-on"><?php esc_html_e( 'Active', 'zymarg-os' ); ?></th>
								<th><?php esc_html_e( 'What it is', 'zymarg-os' ); ?></th>
								<th><?php esc_html_e( 'Slug / URL', 'zymarg-os' ); ?></th>
								<th><?php esc_html_e( 'If switched off', 'zymarg-os' ); ?>
									<span class="zymarg-registry__hint"><?php esc_html_e( 'Only applies when Active is unticked', 'zymarg-os' ); ?></span>
								</th>
								<th><?php esc_html_e( 'Redirect to', 'zymarg-os' ); ?></th>
							</tr>
						</thead>
						<tbody>
						<?php foreach ( $rows as $id => $item ) : ?>
							<?php
							$rule     = zymarg_os_registry_rule( $id );
							$critical = ! empty( $item['critical'] );
							$field    = 'zymarg_registry[' . $id . ']';
							$key      = sanitize_key( str_replace( array( ':', '-' ), '_', $id ) );
							?>
							<tr class="<?php echo empty( $rule['enabled'] ) ? 'is-off' : ''; ?>">
								<td class="col-on">
									<input type="checkbox"
										id="<?php echo esc_attr( $key ); ?>_on"
										name="<?php echo esc_attr( $field ); ?>[enabled]"
										value="1"
										<?php checked( ! empty( $rule['enabled'] ) ); ?>
										<?php if ( $critical ) : ?>
											data-critical="1"
											onchange="if(!this.checked){this.checked=!confirm('<?php echo esc_js( __( 'This URL is required for the store to work properly. Switch it off anyway?', 'zymarg-os' ) ); ?>')?true:false;}"
										<?php endif; ?>
									/>
									<label class="screen-reader-text" for="<?php echo esc_attr( $key ); ?>_on">
										<?php
										printf(
											/* translators: %s: URL label. */
											esc_html__( 'Keep %s active', 'zymarg-os' ),
											esc_html( isset( $item['label'] ) ? $item['label'] : $id )
										);
										?>
									</label>
								</td>

								<td>
									<strong><?php echo esc_html( isset( $item['label'] ) ? $item['label'] : $id ); ?></strong>
									<?php if ( $critical ) : ?>
										<span class="zymarg-registry__warn"><?php esc_html_e( 'Required', 'zymarg-os' ); ?></span>
									<?php endif; ?>
									<?php if ( ! empty( $item['note'] ) ) : ?>
										<span class="zymarg-registry__note"><?php echo esc_html( $item['note'] ); ?></span>
									<?php endif; ?>

									<?php
									/*
									 * The saved state in words. A ticked box plus a dropdown
									 * reading "Show 404" is ambiguous - this says what the URL
									 * is actually doing right now.
									 */
									if ( ! empty( $rule['enabled'] ) ) {
										$state_class = 'is-live';
										$state_text  = __( 'Active', 'zymarg-os' );
									} elseif ( '404' === $rule['action'] ) {
										$state_class = 'is-gone';
										$state_text  = __( 'Off - shows 404', 'zymarg-os' );
									} else {
										$state_class = 'is-moved';
										$state_text  = __( 'Off - redirects', 'zymarg-os' );
									}
									?>
									<span class="zymarg-registry__state <?php echo esc_attr( $state_class ); ?>"
										data-live="<?php esc_attr_e( 'Active', 'zymarg-os' ); ?>"
										data-moved="<?php esc_attr_e( 'Off - redirects', 'zymarg-os' ); ?>"
										data-gone="<?php esc_attr_e( 'Off - shows 404', 'zymarg-os' ); ?>"><?php echo esc_html( $state_text ); ?></span>
								</td>

								<td>
									<code><?php echo esc_html( isset( $item['slug'] ) ? $item['slug'] : '' ); ?></code>
									<?php if ( ! empty( $item['url'] ) ) : ?>
										<a class="zymarg-registry__url" href="<?php echo esc_url( $item['url'] ); ?>" target="_blank" rel="noopener">
											<?php echo esc_html( str_replace( home_url(), '', $item['url'] ) ); ?>
										</a>
									<?php endif; ?>
								</td>

								<td class="zymarg-registry__when">
									<select name="<?php echo esc_attr( $field ); ?>[action]">
										<option value="redirect" <?php selected( '404' !== $rule['action'] ); ?>><?php esc_html_e( 'Redirect', 'zymarg-os' ); ?></option>
										<option value="404" <?php selected( '404' === $rule['action'] ); ?>><?php esc_html_e( 'Show 404', 'zymarg-os' ); ?></option>
									</select>
								</td>

								<td class="zymarg-registry__when">
									<input type="url"
										class="regular-text"
										name="<?php echo esc_attr( $field ); ?>[target]"
										value="<?php echo esc_attr( $rule['target'] ); ?>"
										placeholder="<?php echo esc_attr( home_url( '/' ) ); ?>" />
								</td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				</details>
			<?php endforeach; ?>

			<?php zymarg_os_404_render_admin_panel(); ?>

			<p class="zymarg-registry__status" data-registry-status role="status" aria-live="polite"></p>

			<?php if ( empty( $items ) ) : ?>
				<p class="zymarg-registry__empty">
					<?php esc_html_e( 'No URLs found. WooCommerce is probably inactive - this screen lists WooCommerce, Dokan and theme account URLs.', 'zymarg-os' ); ?>
				</p>
			<?php else : ?>
				<?php submit_button( __( 'Save Changes', 'zymarg-os' ) ); ?>
			<?php endif; ?>
		</form>

		<p class="zymarg-registry__hint">
			<?php esc_html_e( 'Leaving "Redirect to" empty sends account URLs to My Account and everything else to the home page. Switching off a My Account section also removes it from the sidebar.', 'zymarg-os' ); ?>
		</p>
	</div>
	<?php
}

/**
 * Write the URL rules and the 404 design.
 *
 * Shared by the normal form post and the AJAX save so there is one storage
 * path, not two that can drift apart.
 *
 * @param array $posted Raw zymarg_registry payload, already unslashed.
 * @param array $design Raw zymarg_404 payload, already unslashed.
 * @return int Number of URLs switched off.
 */
function zymarg_os_registry_store( $posted, $design = array() ) {
	$rules = array();
	$off   = 0;

	if ( ! is_array( $posted ) ) {
		$posted = array();
	}

	foreach ( zymarg_os_registry_items() as $id => $item ) {
		$row     = isset( $posted[ $id ] ) && is_array( $posted[ $id ] ) ? $posted[ $id ] : array();
		$enabled = ! empty( $row['enabled'] );
		$action  = ( isset( $row['action'] ) && '404' === $row['action'] ) ? '404' : 'redirect';
		$target  = isset( $row['target'] ) ? esc_url_raw( trim( (string) $row['target'] ) ) : '';

		if ( ! $enabled ) {
			$off++;
		}

		/*
		 * Store a snapshot of everything enforcement needs. Enforcement must not
		 * call discovery on the front end - that would boot Dokan's nav system on
		 * every page load just to decide whether to do nothing.
		 */
		$rules[ $id ] = array(
			'enabled' => $enabled,
			'action'  => $action,
			'target'  => $target,
			'source'  => isset( $item['source'] ) ? $item['source'] : '',
			'type'    => isset( $item['type'] ) ? $item['type'] : 'endpoint',
			'slug'    => isset( $item['slug'] ) ? $item['slug'] : '',
			'base'    => isset( $item['base'] ) ? $item['base'] : '',
			'page_id' => isset( $item['page_id'] ) ? (int) $item['page_id'] : 0,
			'label'   => isset( $item['label'] ) ? $item['label'] : '',
		);
	}

	update_option( ZYMARG_OS_PAGE_REGISTRY_OPTION, $rules, false );

	if ( function_exists( 'zymarg_os_404_save' ) ) {
		zymarg_os_404_save( $design );
	}

	return $off;
}

/**
 * Save this screen over admin-ajax.php, so pressing Save does not reload.
 *
 * Security matches a normal admin page load: a nonce of its own, plus the same
 * manage_options capability that add_submenu_page() was given.
 *
 * @return void
 */
function zymarg_os_registry_ajax_save() {
	check_ajax_referer( 'zymarg_os_page_registry_ajax', 'nonce' );

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => __( 'You do not have permission to change these settings.', 'zymarg-os' ) ), 403 );
	}

	$posted = isset( $_POST['zymarg_registry'] ) && is_array( $_POST['zymarg_registry'] ) ? wp_unslash( $_POST['zymarg_registry'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	$design = isset( $_POST['zymarg_404'] ) && is_array( $_POST['zymarg_404'] ) ? wp_unslash( $_POST['zymarg_404'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput

	$off = zymarg_os_registry_store( $posted, $design );

	wp_send_json_success(
		array(
			'off'     => (int) $off,
			'message' => sprintf(
				/* translators: %d: number of URLs switched off. */
				_n( 'Saved. %d URL is switched off.', 'Saved. %d URLs are switched off.', $off, 'zymarg-os' ),
				(int) $off
			),
		)
	);
}
add_action( 'wp_ajax_zymarg_os_registry_save', 'zymarg_os_registry_ajax_save' );
