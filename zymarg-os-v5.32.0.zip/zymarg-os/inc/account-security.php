<?php
/**
 * ZYMARG Account — Security.
 *
 * This is now the ONLY place in the account area where a password can be
 * changed. The old handler in inc/account-dashboard.php is removed, and the
 * WooCommerce edit-account form that carried the second one is no longer
 * rendered at all.
 *
 * Cards:
 *   1. Change password   (theme)
 *   2. Devices & sessions (ZYMARG Login & Security plugin)
 *   3. Recent security activity (plugin)
 *   4. Delete account    (theme)
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/* ======================================================================
   1. RETIRE THE LEGACY HANDLER
   ====================================================================== */

/**
 * Defensively unhook the old password handler.
 *
 * The function itself is deleted from inc/account-dashboard.php as part of
 * this change. This stays as a safety net: if a child theme, a stale opcache
 * copy, or a future merge ever brings it back, we still guarantee exactly one
 * handler processes a password change.
 *
 * @return void
 */
function zymarg_os_retire_legacy_password_handler() {
	remove_action( 'template_redirect', 'zymarg_os_handle_password_change' );
}
add_action( 'init', 'zymarg_os_retire_legacy_password_handler', 1 );

/* ======================================================================
   2. PASSWORD UPDATE HANDLER
   ====================================================================== */

/**
 * Handle the change-password submission.
 *
 * @return void
 */
function zymarg_os_handle_password_update() {
	if ( ! isset( $_POST['zymarg_pw_nonce'] ) ) {
		return;
	}

	if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['zymarg_pw_nonce'] ) ), 'zymarg_change_password' ) ) {
		return;
	}

	if ( ! is_user_logged_in() ) {
		return;
	}

	$user    = wp_get_current_user();
	$user_id = $user->ID;

	// Rate limit: 5 attempts per 15 minutes. Without this, a borrowed phone
	// with a live session is an offline-speed guessing box for the current
	// password.
	$throttle_key = 'zym_pw_try_' . $user_id;
	$attempts     = (int) get_transient( $throttle_key );

	if ( $attempts >= 5 ) {
		zymarg_os_notice( __( 'Too many attempts. Please wait 15 minutes before trying again.', 'zymarg-os' ), 'error' );
		zymarg_os_log_security_event( $user_id, 'PASSWORD_CHANGE_THROTTLED' );
		return;
	}

	$current = isset( $_POST['password_current'] ) ? (string) wp_unslash( $_POST['password_current'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
	$new     = isset( $_POST['password_1'] ) ? (string) wp_unslash( $_POST['password_1'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
	$confirm = isset( $_POST['password_2'] ) ? (string) wp_unslash( $_POST['password_2'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

	if ( '' === $current || '' === $new || '' === $confirm ) {
		zymarg_os_notice( __( 'Please fill in all three password fields.', 'zymarg-os' ), 'error' );
		return;
	}

	if ( ! wp_check_password( $current, $user->user_pass, $user_id ) ) {
		set_transient( $throttle_key, $attempts + 1, 15 * MINUTE_IN_SECONDS );
		zymarg_os_notice( __( 'Your current password is not correct.', 'zymarg-os' ), 'error' );
		zymarg_os_log_security_event( $user_id, 'PASSWORD_CHANGE_BAD_CURRENT' );
		return;
	}

	if ( $new !== $confirm ) {
		zymarg_os_notice( __( 'The two new passwords do not match.', 'zymarg-os' ), 'error' );
		return;
	}

	$min = zymarg_os_min_password_length();

	if ( strlen( $new ) < $min ) {
		zymarg_os_notice(
			sprintf(
				/* translators: %d: minimum number of characters. */
				__( 'Your new password must be at least %d characters.', 'zymarg-os' ),
				$min
			),
			'error'
		);
		return;
	}

	// Timing-safe: no point leaking whether the guess equalled the current one.
	if ( hash_equals( $current, $new ) ) {
		zymarg_os_notice( __( 'Your new password must be different from your current one.', 'zymarg-os' ), 'error' );
		return;
	}

	// Reject passwords built from the username or the email local part — the
	// first two things any credential-stuffing list tries.
	$lower       = strtolower( $new );
	$login       = strtolower( $user->user_login );
	$email_local = strtolower( (string) strstr( $user->user_email, '@', true ) );

	if ( ( '' !== $login && false !== strpos( $lower, $login ) )
		|| ( '' !== $email_local && false !== strpos( $lower, $email_local ) ) ) {
		zymarg_os_notice( __( 'Your password cannot contain your username or email address.', 'zymarg-os' ), 'error' );
		return;
	}

	/**
	 * Last word on password validity.
	 *
	 * Return a WP_Error (or a string) to reject. Lets the brand tighten the
	 * rules later — breach-list checks, entropy scoring — without editing
	 * this handler.
	 *
	 * @param true|WP_Error|string $valid Validation result.
	 * @param string               $new   Proposed password.
	 * @param WP_User              $user  User.
	 */
	$valid = apply_filters( 'zymarg_os_validate_new_password', true, $new, $user );

	if ( is_wp_error( $valid ) ) {
		zymarg_os_notice( $valid->get_error_message(), 'error' );
		return;
	}

	if ( is_string( $valid ) && '' !== $valid ) {
		zymarg_os_notice( $valid, 'error' );
		return;
	}

	// wp_update_user(), not wp_set_password(). wp_set_password() writes the
	// hash directly: it fires no `profile_update`, so the Login & Security
	// plugin never learns the password changed and no alert email is sent.
	// That was the old handler's real flaw.
	$result = wp_update_user(
		array(
			'ID'        => $user_id,
			'user_pass' => $new,
		)
	);

	if ( is_wp_error( $result ) ) {
		zymarg_os_notice( $result->get_error_message(), 'error' );
		return;
	}

	delete_transient( $throttle_key );

	// Changing the password invalidates every session, including this one.
	// Re-issue a cookie so the customer is not thrown out of the page they
	// are standing on.
	wp_set_current_user( $user_id );
	wp_set_auth_cookie( $user_id, true );

	zymarg_os_log_security_event( $user_id, 'PASSWORD_CHANGED' );
	zymarg_os_notice( __( 'Your password is updated. Other devices have been signed out.', 'zymarg-os' ), 'success' );

	zymarg_os_acc_redirect( zymarg_os_security_url() );
}
add_action( 'template_redirect', 'zymarg_os_handle_password_update' );

/* ======================================================================
   2b. SHARED PASSWORD REVEAL BUTTON
   ====================================================================== */

if ( ! function_exists( 'zymarg_os_pw_toggle_button' ) ) :
	/**
	 * Render the show / hide control for a password input.
	 *
	 * Both icons are printed and CSS decides which one is visible, keyed off the
	 * `.is-showing` class the accordion script already toggles. Swapping icons in
	 * CSS rather than rewriting innerHTML in JS means the button keeps working
	 * after the SPA injects a section, and it cannot end up showing the wrong
	 * glyph if a script fails to load.
	 *
	 * @return void
	 */
	function zymarg_os_pw_toggle_button() {
		?>
		<button type="button" class="zym-pw-toggle" data-zym-pw-toggle aria-pressed="false"
			aria-label="<?php esc_attr_e( 'Show password', 'zymarg-os' ); ?>">
			<span class="zym-pw-toggle__icon zym-pw-toggle__icon--closed" aria-hidden="true">
				<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M17.9 17.9A10.4 10.4 0 0 1 12 19.8c-6.6 0-10.2-6.6-10.2-6.6a18.5 18.5 0 0 1 5-5.9"></path><path d="M9.9 4.2A10.6 10.6 0 0 1 12 4.2c6.6 0 10.2 6.6 10.2 6.6a18.6 18.6 0 0 1-2.4 3.5"></path><path d="M9.9 9.9a3 3 0 1 0 4.2 4.2"></path><path d="M2.4 2.4l19.2 19.2"></path></svg>
			</span>
			<span class="zym-pw-toggle__icon zym-pw-toggle__icon--open" aria-hidden="true">
				<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M1.8 12S5.4 5.4 12 5.4 22.2 12 22.2 12 18.6 18.6 12 18.6 1.8 12 1.8 12z"></path><circle cx="12" cy="12" r="3"></circle></svg>
			</span>
		</button>
		<?php
	}
endif;

/* ======================================================================
   3. RENDERER (accordion)
   ====================================================================== */

/**
 * The Security section.
 *
 * @return void
 */
function zymarg_os_acc_section_security() {
	$user = wp_get_current_user();
	$min  = zymarg_os_min_password_length();
	?>
	<div class="panel-header">
		<?php echo zymarg_os_account_icon( 'lock' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		<h2><?php esc_html_e( 'Login & Security', 'zymarg-os' ); ?></h2>
	</div>
	<p class="panel-desc"><?php esc_html_e( 'Your password, your devices, and everything that happens to your account.', 'zymarg-os' ); ?></p>

	<?php
	zymarg_os_print_notices();

	zymarg_os_accordion_open( 'security' );

		/* -------- 1. Change password -------- */
		// Card numbers are counted rather than hard-coded, because cards 2 and 3
		// only exist when the Login & Security plugin supplies content. A list
		// that reads 1, 4 looks like two cards failed to load.
		$card = 1;

		zymarg_os_accordion_card_start( 'password', $card, __( 'Change password', 'zymarg-os' ), true );
		?>
		<form method="post" class="zym-acc-form zymarg-password-form" data-zym-ajax="password" novalidate>
			<?php wp_nonce_field( 'zymarg_change_password', 'zymarg_pw_nonce' ); ?>

			<input type="text" name="username" value="<?php echo esc_attr( $user->user_login ); ?>"
				autocomplete="username" hidden readonly>

			<div class="zym-field">
				<label class="zym-field__label" for="zym-pw-current"><?php esc_html_e( 'Current password', 'zymarg-os' ); ?></label>
				<div class="zym-pw-wrap">
					<input type="password" id="zym-pw-current" name="password_current" autocomplete="current-password" required>
					<?php zymarg_os_pw_toggle_button(); ?>
				</div>
			</div>

			<div class="zym-field">
				<label class="zym-field__label" for="zym-pw-new"><?php esc_html_e( 'New password', 'zymarg-os' ); ?></label>
				<div class="zym-pw-wrap">
					<input type="password" id="zym-pw-new" name="password_1" autocomplete="new-password" required
						data-zym-pw-strength data-zym-min="<?php echo esc_attr( $min ); ?>">
					<?php zymarg_os_pw_toggle_button(); ?>
				</div>

				<div class="zym-strength" data-zym-strength hidden>
					<div class="zym-strength__bar"><span></span></div>
					<span class="zym-strength__label"></span>
				</div>

				<p class="zym-hint">
					<?php
					echo esc_html(
						sprintf(
							/* translators: %d: minimum number of characters. */
							__( 'At least %d characters. Longer beats complicated.', 'zymarg-os' ),
							$min
						)
					);
					?>
				</p>
			</div>

			<div class="zym-field">
				<label class="zym-field__label" for="zym-pw-confirm"><?php esc_html_e( 'Confirm new password', 'zymarg-os' ); ?></label>
				<div class="zym-pw-wrap">
					<input type="password" id="zym-pw-confirm" name="password_2" autocomplete="new-password" required
						data-zym-pw-confirm>
					<?php zymarg_os_pw_toggle_button(); ?>
				</div>
				<p class="zym-match" data-zym-pw-match hidden></p>
			</div>

			<div class="zym-acc-save">
				<button type="submit" class="btn btn-primary btn-sm"><?php esc_html_e( 'Update password', 'zymarg-os' ); ?></button>
			</div>
		</form>
		<?php
		zymarg_os_accordion_card_end();

		/* -------- 2. Devices & sessions -------- */
		/*
		 * Rendered only when there is genuinely something inside it.
		 *
		 * These two cards used to be printed unconditionally, so with nothing to
		 * put in them the customer got an empty rounded box: a heading, a chevron
		 * and no content. Furniture with nothing in it reads as a panel that
		 * failed to load, which is worse than the feature simply not being there.
		 *
		 * The shortcode is rendered into a variable FIRST and the card is only
		 * opened if that output is non-empty, so a plugin that is active but has
		 * nothing to report (or whose section was removed) also leaves no box
		 * behind. Checking the plugin is present is not enough on its own.
		 */
		$sessions_html = zymarg_os_has_session_manager()
			? trim( do_shortcode( '[zymarg_security section="sessions"]' ) )
			: '';

		if ( '' !== $sessions_html ) {
			++$card;
			zymarg_os_accordion_card_start( 'sessions', $card, __( 'Devices & sessions', 'zymarg-os' ) );
			echo $sessions_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Shortcode output, already escaped by the plugin.
			zymarg_os_accordion_card_end();
		}

		/* -------- 3. Recent security activity -------- */
		$activity_html = zymarg_os_has_session_manager()
			? trim( do_shortcode( '[zymarg_security section="activity"]' ) )
			: '';

		if ( '' !== $activity_html ) {
			++$card;
			zymarg_os_accordion_card_start( 'activity', $card, __( 'Recent security activity', 'zymarg-os' ) );
			echo $activity_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Shortcode output, already escaped by the plugin.
			zymarg_os_accordion_card_end();
		}

		/* -------- 4. Delete account -------- */
		++$card;
		zymarg_os_accordion_card_start( 'delete', $card, __( 'Delete account', 'zymarg-os' ) );
		?>
		<p class="zym-danger__text">
			<?php esc_html_e( 'Deleting your account removes your profile, addresses and saved preferences. Completed orders are kept because we are legally required to keep them.', 'zymarg-os' ); ?>
		</p>
		<button type="button" class="btn btn-danger btn-sm" id="btn-delete-account">
			<?php esc_html_e( 'Delete my account', 'zymarg-os' ); ?>
		</button>
		<?php
		zymarg_os_accordion_card_end();

	zymarg_os_accordion_close();

	zymarg_os_render_delete_account_modal();
}

/**
 * The delete-account confirmation modal.
 *
 * IDs are preserved exactly (delete-modal, btn-delete-account,
 * delete-password, delete-cancel, zymarg-delete-form) because
 * assets/js/account.js already wires them up.
 *
 * @return void
 */
function zymarg_os_render_delete_account_modal() {
	?>
	<?php // No `hidden` attribute: woocommerce/account.css hides this with display:none and account.js reveals it by adding .is-open. ?>
	<div class="zymarg-modal-overlay" id="delete-modal">
		<div class="zymarg-modal-box" role="dialog" aria-modal="true" aria-labelledby="delete-modal-title">
			<div class="modal-header-danger">
				<h3 class="modal-title" id="delete-modal-title"><?php esc_html_e( 'Delete your account?', 'zymarg-os' ); ?></h3>
			</div>

			<ul class="modal-warnings">
				<li class="warning-item"><?php esc_html_e( 'Your profile, addresses and wishlist are erased.', 'zymarg-os' ); ?></li>
				<li class="warning-item"><?php esc_html_e( 'Any unused coupons and store credit are lost.', 'zymarg-os' ); ?></li>
				<li class="warning-item"><?php esc_html_e( 'This cannot be undone.', 'zymarg-os' ); ?></li>
			</ul>

			<form method="post" id="zymarg-delete-form" data-zym-ajax="delete">
				<?php wp_nonce_field( 'zymarg_delete_account', 'zymarg_del_nonce' ); ?>

				<div class="zym-field">
					<label class="zym-field__label" for="delete-password"><?php esc_html_e( 'Enter your password to confirm', 'zymarg-os' ); ?></label>
					<div class="zym-pw-wrap">
						<?php // Name must stay `confirm_password`: zymarg_os_handle_delete_account() reads exactly that key. ?>
						<input type="password" id="delete-password" name="confirm_password" autocomplete="current-password" required>
						<?php zymarg_os_pw_toggle_button(); ?>
					</div>
				</div>

				<div class="modal-actions">
					<button type="button" class="btn btn-outline btn-sm" id="delete-cancel"><?php esc_html_e( 'Keep my account', 'zymarg-os' ); ?></button>
					<button type="submit" class="btn btn-danger btn-sm"><?php esc_html_e( 'Delete permanently', 'zymarg-os' ); ?></button>
				</div>
			</form>
		</div>
	</div>
	<?php
}
