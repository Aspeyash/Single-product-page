<?php
/**
 * Product Card Delegate.
 *
 * When the ZYMARG WC Product Grid plugin is active, all product card rendering
 * in the theme delegates to the plugin's card template. When the plugin is not
 * active, the theme falls back to its own basic card markup.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Check whether the ZYMARG WC Product Grid plugin is active and available.
 *
 * @return bool
 */
function zymarg_os_wcpg_active() {
	return class_exists( '\Zymarg\WCPG\Template_Loader' );
}

/**
 * Get the default settings array for the plugin's product card.
 *
 * @return array
 */
function zymarg_os_branded_card_slug() {
	/**
	 * Filter the registered card slug the theme renders.
	 *
	 * @param string $slug Card template slug registered with the grid engine.
	 */
	return (string) apply_filters( 'zymarg_os_branded_card_slug', 'zymarg' );
}

/**
 * Is the branded card actually registered with the grid engine?
 *
 * Checking for Template_Manager is NOT a valid test: that class ships with the
 * Product Grid engine, so it exists whenever the engine is active, with or
 * without the Template Pack. The pack is what registers the card slug, so
 * asking the registry is the only honest test.
 *
 * @return bool
 */
function zymarg_os_branded_card_registered() {
	$manager = '\\Zymarg\\WCPG\\Templates\\Template_Manager';

	if ( ! class_exists( $manager ) || ! method_exists( $manager, 'is_registered_card' ) ) {
		return false;
	}

	return (bool) call_user_func( array( $manager, 'is_registered_card' ), zymarg_os_branded_card_slug() );
}

/**
 * Settings passed to the branded card template.
 *
 * @return array
 */
function zymarg_os_wcpg_card_settings() {
	return apply_filters( 'zymarg_os_wcpg_card_settings', array(
		'show_image'           => 'yes',
		'show_discount_badge'  => 'yes',
		'show_stock_badge'     => 'yes',
		'show_wishlist'        => 'yes',
		'show_quickview'       => 'yes',
		'show_atc'             => 'yes',
		'show_title'           => 'yes',
		'show_vendor'          => 'yes',
		'show_price'           => 'yes',
		'show_rating'          => 'yes',
		'show_sold_count'      => 'yes',
		'columns'              => 4,
		'price_position'       => 'below_rating',
		'vendor_position'      => 'below_price',
		'atc_position'         => 'with_price',
		'image_hover_zoom'     => 'yes',
		'quickview_visibility' => 'desktop',
		'quickview_display'    => 'hover_only',
	) );
}

/**
 * Render a single product card.
 *
 * Uses the ZYMARG WC Product Grid plugin template when available, otherwise
 * falls back to the theme's basic card markup.
 *
 * @param WC_Product|int $product WC_Product object or product ID.
 * @return void
 */
function zymarg_os_render_product_card( $product ) {
	if ( is_numeric( $product ) ) {
		$product = wc_get_product( $product );
	}

	if ( ! $product instanceof \WC_Product ) {
		return;
	}

	/*
	 * 5.21.2: this used to load the engine's own 'grid/product-card.php'
	 * directly. That file IS the engine's default card -- it is not a
	 * dispatcher, so it never consulted the card registry and the branded
	 * ZYMARG card was never rendered at all. The shop loop was showing the
	 * engine's default card the whole time, which is why it never matched the
	 * brand design no matter how much CSS was corrected.
	 *
	 * Template_Manager::render_card() is the dispatcher: it resolves a
	 * registered slug to its file, applies the 'zymarg_card_template' filter
	 * and honours the theme override at
	 * theme/zymarg-wcpg/cards/{slug}/product-card.php.
	 */
	if ( zymarg_os_wcpg_active() ) {
		$slug = zymarg_os_branded_card_slug();
		$args = array(
			'product'   => $product,
			'settings'  => zymarg_os_wcpg_card_settings(),
			'config'    => array( 'card' => array( 'template' => $slug ) ),
			'widget_id' => 'theme',
		);

		if ( zymarg_os_branded_card_registered() ) {
			$html = \Zymarg\WCPG\Templates\Template_Manager::render_card( $slug, $args );

			if ( '' !== $html ) {
				// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the card template escapes its own output.
				echo $html;
				return;
			}
		}

		// Registry unavailable or the card returned nothing: fall back to the
		// engine's default card rather than the theme's much plainer markup.
		\Zymarg\WCPG\Template_Loader::get_template( 'grid/product-card.php', $args );
		return;
	}

	// Fallback: theme's basic card markup.
	$permalink = $product->get_permalink();
	$image     = $product->get_image( 'medium' );
	$title     = $product->get_name();
	$price     = $product->get_price_html();
	?>
	<article class="zymarg-card zymarg-result">
		<a class="zymarg-result__link" href="<?php echo esc_url( $permalink ); ?>">
			<?php if ( $image ) : ?>
				<span class="zymarg-result__media"><?php echo $image; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
			<?php endif; ?>
			<h2 class="zymarg-result__title"><?php echo esc_html( $title ); ?></h2>
		</a>
		<?php if ( $price ) : ?>
			<div class="price"><?php echo wp_kses_post( $price ); ?></div>
		<?php endif; ?>
	</article>
	<?php
}

/**
 * Render a full product grid.
 *
 * Uses the plugin's grid-wrapper template when available, otherwise renders
 * cards inside the theme's standard grid container.
 *
 * @param WC_Product[]|int[] $products Array of WC_Product objects or product IDs.
 * @param int                $columns  Number of grid columns.
 * @return void
 */
function zymarg_os_render_product_grid( $products, $columns = 4 ) {
	if ( empty( $products ) ) {
		return;
	}

	// Normalize to WC_Product objects.
	$wc_products = array();
	foreach ( $products as $product ) {
		if ( is_numeric( $product ) ) {
			$product = wc_get_product( $product );
		}
		if ( $product instanceof \WC_Product ) {
			$wc_products[] = $product;
		}
	}

	if ( empty( $wc_products ) ) {
		return;
	}

	if ( zymarg_os_wcpg_active() ) {
		$settings            = zymarg_os_wcpg_card_settings();
		$settings['columns'] = $columns;

		/*
		 * Wrapper + column count for the theme's own grid CSS.
		 *
		 * The engine's grid-wrapper markup is laid out by the engine's frontend
		 * stylesheet, which is only enqueued by Render_Engine -- a path this
		 * delegate never takes. Without any grid rules the wrapper is a plain
		 * block element and every card stacks full-width, one per row. This
		 * wrapper gives the Product Card column CSS something to hook onto. The
		 * column counts themselves come from ZYMARG OS -> Product Card, so the
		 * $columns argument only reaches the engine's own settings array.
		 */
		echo '<div class="zymarg-os-card-grid">';

		\Zymarg\WCPG\Template_Loader::get_template( 'grid/grid-wrapper.php', array(
			'settings'  => $settings,
			'widget_id' => 'theme',
			'products'  => $wc_products,
		) );

		echo '</div>';
		return;
	}

	// Fallback: theme's basic grid.
	echo '<div class="zymarg-grid zymarg-grid--auto zymarg-results__grid">';
	foreach ( $wc_products as $product ) {
		zymarg_os_render_product_card( $product );
	}
	echo '</div>';
}


/* ---------------------------------------------------------------------- *
 * Branded card (ZYMARG Template Pack) — settings, assets, shop loop.
 *
 * The settings UI lives at ZYMARG OS -> Product Card (inc/admin-product-card.php).
 * The full technical background is documented in PRODUCT-CARD-OVERRIDE.md,
 * shipped with the ZYMARG Template Pack plugin.
 * ---------------------------------------------------------------------- */

const ZYMARG_OS_PRODUCT_CARD_OPTION = 'zymarg_os_product_card';

/**
 * Default Product Card settings.
 *
 * @return array
 */
function zymarg_os_product_card_defaults() {
	return array(
		'enabled'     => 1, // Use the branded card wherever the theme renders a product card.
		'shop_loop'   => 1, // Also take over WooCommerce's own shop / category loops.
		'cols_mobile' => 2, // Up to 767px.
		'cols_tablet' => 3, // 768px - 1024px.
		'cols_desktop' => 4, // 1025px - 1439px.
		'cols_wide'   => 5, // 1440px and up.
		// Space between cards, in px, per view (5.21.0). Previously hard-coded to
		// var(--zymarg-space-md) = 24px at every width, which is generous on
		// phones where the cards themselves are only ~160px wide.
		'gap_mobile'  => 10,
		'gap_tablet'  => 16,
		'gap_desktop' => 20,
		'gap_wide'    => 24,
	);
}

/**
 * Breakpoints the column settings map onto.
 *
 * Mobile is the base (no query); the rest are min-width, so the largest
 * matching rule wins without any max-width rules to fight.
 *
 * @return array<string,int> View key => min-width in px (0 for the base).
 */
function zymarg_os_product_card_breakpoints() {
	$breakpoints = array();

	foreach ( zymarg_os_product_card_views() as $view => $min_width ) {
		$breakpoints[ 'cols_' . $view ] = $min_width;
	}

	return $breakpoints;
}

/**
 * The four device views and the min-width each one starts at.
 *
 * Single source of truth for BOTH the column counts and the card gap, so the
 * two can never drift onto different breakpoints.
 *
 * @return array<string,int> View key => min-width in px (0 for the base).
 */
function zymarg_os_product_card_views() {
	return array(
		'mobile'  => 0,
		'tablet'  => 768,
		'desktop' => 1025,
		'wide'    => 1440,
	);
}

/**
 * Read the card gap for a view, clamped to a sane range.
 *
 * Zero is allowed (edge-to-edge cards), so this cannot reuse the column
 * reader's "< 1 means unset" rule.
 *
 * @param string $view One of mobile, tablet, desktop, wide.
 * @return int Gap in px.
 */
function zymarg_os_product_card_gap( $view ) {
	$key      = 'gap_' . $view;
	$defaults = zymarg_os_product_card_defaults();
	$saved    = get_option( ZYMARG_OS_PRODUCT_CARD_OPTION, array() );
	$saved    = is_array( $saved ) ? $saved : array();
	$fallback = isset( $defaults[ $key ] ) ? (int) $defaults[ $key ] : 16;
	$value    = array_key_exists( $key, $saved ) ? (int) $saved[ $key ] : $fallback;

	return (int) min( 64, max( 0, $value ) );
}

/**
 * Read a column count, clamped to a sane range.
 *
 * @param string $key One of cols_mobile, cols_tablet, cols_desktop, cols_wide.
 * @return int
 */
function zymarg_os_product_card_columns( $key ) {
	$defaults = zymarg_os_product_card_defaults();
	$saved    = get_option( ZYMARG_OS_PRODUCT_CARD_OPTION, array() );
	$saved    = is_array( $saved ) ? $saved : array();
	$fallback = isset( $defaults[ $key ] ) ? (int) $defaults[ $key ] : 4;
	$value    = isset( $saved[ $key ] ) ? (int) $saved[ $key ] : $fallback;

	if ( $value < 1 ) {
		$value = $fallback;
	}

	return (int) min( 8, max( 1, $value ) );
}

/**
 * Build the column CSS for every grid that holds a branded card.
 *
 * This deliberately drives ALL of them from one place:
 *   - WooCommerce's shop / category loop (ul.products)
 *   - the theme-delegated grids (search, archives, related, upsells)
 *   - the account tabs' shortcode grids
 *
 * The `body` prefix on the WooCommerce selectors raises specificity above
 * woocommerce/product.css, which carries its own max-width column rules and
 * would otherwise override these depending on load order. Mobile-first
 * min-width queries mean there are no competing max-width rules here at all.
 *
 * @return string CSS.
 */
function zymarg_os_product_card_columns_css() {
	$selectors = implode(
		',',
		array(
			'body.woocommerce ul.products',
			'body.woocommerce-page ul.products',
			'.zymarg-os-card-grid .zymarg-wcpg__grid',
			'.zymarg-wcpg .zymarg-wcpg__grid',
		)
	);

	$css = '';

	foreach ( zymarg_os_product_card_views() as $view => $min_width ) {
		$columns = zymarg_os_product_card_columns( 'cols_' . $view );
		$gap     = zymarg_os_product_card_gap( $view );

		if ( 0 === $min_width ) {
			// The base rule also resets the list itself. `gap` is now a real px
			// value from the setting rather than var(--zymarg-space-md), which was
			// a fixed 24px at every width and could not be tuned per device.
			$css .= $selectors . '{display:grid;margin:0;padding:0;list-style:none;'
				. sprintf( 'gap:%dpx;grid-template-columns:repeat(%d,minmax(0,1fr));}', $gap, $columns );
			continue;
		}

		$css .= sprintf(
			'@media (min-width:%dpx){%s{gap:%dpx;grid-template-columns:repeat(%d,minmax(0,1fr));}}',
			$min_width,
			$selectors,
			$gap,
			$columns
		);
	}

	// The theme's own loop wrapper adds nothing around the card, but WooCommerce
	// core ships `ul.products li.product { margin-bottom: 2.992em }`, which sits
	// on top of the grid gap and reads as "too much space" between rows. Grid
	// owns the spacing now, so zero the legacy margins out.
	$css .= 'body.woocommerce ul.products li.product,body.woocommerce-page ul.products li.product'
		. '{margin:0;padding:0;width:auto;float:none;clear:none;}'
		. 'body.woocommerce ul.products::before,body.woocommerce ul.products::after,'
		. 'body.woocommerce-page ul.products::before,body.woocommerce-page ul.products::after{display:none;}';

	return $css;
}

/**
 * Read a Product Card setting.
 *
 * @param string $key Setting key.
 * @return bool
 */
function zymarg_os_product_card_setting( $key ) {
	$defaults = zymarg_os_product_card_defaults();
	$saved    = get_option( ZYMARG_OS_PRODUCT_CARD_OPTION, array() );
	$saved    = is_array( $saved ) ? $saved : array();
	$value    = array_key_exists( $key, $saved ) ? $saved[ $key ] : ( isset( $defaults[ $key ] ) ? $defaults[ $key ] : 0 );

	return (bool) $value;
}

/**
 * Should the ZYMARG branded card be used?
 *
 * @return bool
 */
function zymarg_os_use_branded_card() {
	/**
	 * Filter whether the branded card is used at all.
	 *
	 * @param bool $enabled Current state.
	 */
	return (bool) apply_filters( 'zymarg_os_use_branded_card', zymarg_os_product_card_setting( 'enabled' ) );
}

/**
 * Should the branded card also replace WooCommerce's own shop / category loop?
 *
 * @return bool
 */
function zymarg_os_branded_card_in_shop_loop() {
	$enabled = zymarg_os_use_branded_card() && zymarg_os_product_card_setting( 'shop_loop' );

	/**
	 * Filter whether the branded card takes over the WooCommerce loop.
	 *
	 * @param bool $enabled Current state.
	 */
	return (bool) apply_filters( 'zymarg_os_branded_card_in_shop_loop', $enabled );
}

/**
 * Absolute path to the ZYMARG Template Pack's branded card template.
 *
 * The pack does not define a path constant, so the plugin directory is used.
 * Filterable so a differently-named install or a child theme can redirect it.
 *
 * @return string Path, or '' when the pack is not installed.
 */
function zymarg_os_branded_card_path() {
	$path = defined( 'WP_PLUGIN_DIR' )
		? WP_PLUGIN_DIR . '/zymarg-template-pack/templates/product-card.php'
		: '';

	/**
	 * Filter the branded card template path.
	 *
	 * @param string $path Absolute path to the card template.
	 */
	$path = (string) apply_filters( 'zymarg_os_branded_card_path', $path );

	return ( '' !== $path && file_exists( $path ) ) ? $path : '';
}

/**
 * Enqueue the branded card's stylesheet and script.
 *
 * The two account shortcodes, the theme delegate and the WooCommerce loop all
 * render the card outside the plugin's Render_Engine, so the engine's own
 * Asset_Manager never runs and nothing loads the card's CSS. Without this the
 * branded markup renders unstyled -- markup right, card wrong.
 *
 * Asset paths come from the engine's Template_Manager, which discovers them
 * beside the registered card's PHP file, so there is no hard-coded URL here.
 *
 * Scoping note: do NOT use is_wc_endpoint_url() for the account tabs. This
 * theme registers `wishlist` / `recently-viewed` with add_rewrite_endpoint()
 * rather than WooCommerce's woocommerce_get_query_vars filter, so WooCommerce
 * does not recognise them and that check is always false.
 *
 * @return void
 */
function zymarg_os_enqueue_branded_card_assets() {
	if ( ! zymarg_os_use_branded_card() ) {
		return;
	}

	/*
	 * NOTE (5.20.10): this used to bail out entirely when Template_Manager was
	 * missing. That was the bug behind "cards render vertical / squeezed".
	 * Rendering is gated on \Zymarg\WCPG\Template_Loader, but the assets were
	 * gated on \Zymarg\WCPG\Templates\Template_Manager -- two different
	 * classes. When the engine shipped the former without the latter, the
	 * branded markup rendered while the card CSS, the layout glue AND the
	 * admin column CSS never loaded, so every card stacked full-width inside
	 * the theme's own bordered li.product frame.
	 *
	 * The card's own stylesheet still needs Template_Manager to be located
	 * (only the engine knows its URL), but the theme's layout glue and the
	 * admin-controlled column counts do not depend on the engine at all and
	 * are now enqueued unconditionally below.
	 */
	$needs_assets = ( function_exists( 'zymarg_os_is_woo_context' ) && zymarg_os_is_woo_context() )
		|| is_search()
		|| is_archive()
		|| is_singular( 'product' );

	if ( ! $needs_assets ) {
		$zymarg_post = get_post();
		if ( $zymarg_post instanceof WP_Post ) {
			$needs_assets = has_shortcode( $zymarg_post->post_content, 'zymarg_wcpg_wishlist' )
				|| has_shortcode( $zymarg_post->post_content, 'zymarg_wcpg_recently_viewed' )
				|| has_shortcode( $zymarg_post->post_content, 'products' );
		}
	}

	if ( ! $needs_assets ) {
		return;
	}

	$assets = class_exists( '\Zymarg\WCPG\Templates\Template_Manager' )
		? \Zymarg\WCPG\Templates\Template_Manager::get_card_assets( 'zymarg' )
		: array();

	/*
	 * 5.21.2: load the card's assets through the engine's OWN pipeline.
	 *
	 * The engine enqueues a card template's style.css from exactly one place:
	 * Asset_Manager::maybe_enqueue_card_template_assets(), reached only via
	 * Asset_Manager::enqueue_for_render(), which in turn is called only by
	 * Render_Engine::render(). The theme renders cards itself and never goes
	 * through Render_Engine, so neither the engine's core frontend stylesheet
	 * nor the card's own stylesheet was ever enqueued on the shop loop.
	 *
	 * Calling enqueue_for_render() here is exactly what a native engine render
	 * does, so the shop loop now loads byte-for-byte the same assets, in the
	 * same order, under the same handles (zymarg-wcpg-frontend, then
	 * zymarg-wcpg-card-{slug}, which depends on it). It is documented as
	 * additive and safe to call more than once.
	 *
	 * Doing it on wp_enqueue_scripts rather than at render time also puts the
	 * <link> in <head> instead of the footer, so the card is never painted
	 * before its stylesheet lands.
	 */
	$slug = zymarg_os_branded_card_slug();

	if ( class_exists( '\Zymarg\WCPG\Services\Asset_Manager' )
		&& method_exists( '\Zymarg\WCPG\Services\Asset_Manager', 'enqueue_for_render' ) ) {

		\Zymarg\WCPG\Services\Asset_Manager::enqueue_for_render(
			array( 'card' => array( 'template' => $slug ) )
		);
	} elseif ( ! empty( $assets['css']['url'] ) ) {
		/*
		 * Older engine without Asset_Manager: register under the engine's own
		 * handle so that if the engine later reaches its render-time enqueue it
		 * finds the handle already present and nothing loads twice.
		 */
		$handle = 'zymarg-wcpg-card-' . $slug;

		if ( ! wp_style_is( $handle, 'registered' ) ) {
			$deps = wp_style_is( 'zymarg-wcpg-frontend', 'registered' )
				? array( 'zymarg-wcpg-frontend' )
				: array();

			wp_register_style(
				$handle,
				$assets['css']['url'],
				$deps,
				isset( $assets['css']['version'] ) ? $assets['css']['version'] : null
			);
		}

		wp_enqueue_style( $handle );

		if ( ! empty( $assets['js']['url'] ) ) {
			$js_handle = 'zymarg-wcpg-card-' . $slug . '-js';

			if ( ! wp_script_is( $js_handle, 'registered' ) ) {
				wp_register_script(
					$js_handle,
					$assets['js']['url'],
					array(),
					isset( $assets['js']['version'] ) ? $assets['js']['version'] : null,
					true
				);
			}

			wp_enqueue_script( $js_handle );
		}
	}

	/*
	 * Layout glue for the branded card: grid columns on theme-delegated
	 * surfaces, and removal of the theme's own card frame on the shop loop.
	 * Loaded after the card's own stylesheet so it always wins.
	 */
	wp_enqueue_style(
		'zymarg-os-branded-card-grid',
		ZYMARG_OS_URI . '/components/product-card-grid.css',
		// Only depend on the card sheet when it actually got enqueued, otherwise
		// WordPress drops this stylesheet for an unsatisfied dependency.
		wp_style_is( 'zymarg-os-branded-card', 'enqueued' ) ? array( 'zymarg-os-branded-card' ) : array(),
		defined( 'ZYMARG_OS_VERSION' ) ? ZYMARG_OS_VERSION : null
	);

	// Admin-controlled column counts per view.
	wp_add_inline_style( 'zymarg-os-branded-card-grid', zymarg_os_product_card_columns_css() );
}
add_action( 'wp_enqueue_scripts', 'zymarg_os_enqueue_branded_card_assets', 20 );
