<?php
/**
 * My Account — redesigned dashboard module.
 *
 * Replaces the default WooCommerce My Account layout with a custom sidebar +
 * section-panel design. Each section is rendered by inc/account-sections.php.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/* ---------------------------------------------------------------------- *
 * Pluggable account sections (extension API)
 * ---------------------------------------------------------------------- *
 * Companion plugins can register their own My Account sections (sidebar
 * item + endpoint + section body) without the theme having to know about
 * them. This keeps the theme lightweight and lets features live in their
 * own plugins (e.g. the "ZYMARG Wallet" plugin re-adds the Payments
 * section that used to be baked into this theme).
 *
 * A plugin registers via the `zymarg_os_account_sections` filter, returning
 * an array keyed by section slug. Each definition may contain:
 *
 *   label     (string)   Sidebar label.               [default: ucfirst(slug)]
 *   icon      (string)   Icon key known to
 *                        zymarg_os_account_icon(), OR raw inline SVG markup
 *                        (auto-detected by a leading "<").   [default: 'card']
 *   endpoint  (string)   WooCommerce endpoint slug.          [default: slug]
 *   after     (string)   Sidebar key to insert AFTER.  [default: 'addresses']
 *   render_cb (callable) Renders the section body. If omitted, the theme
 *                        looks for a function named
 *                        zymarg_os_acc_section_{slug}().
 *   enabled   (bool)     Set false to hide (e.g. an admin toggle). [true]
 *
 * Example:
 *   add_filter( 'zymarg_os_account_sections', function ( $s ) {
 *       $s['payments'] = array(
 *           'label'     => __( 'Payments', 'my-plugin' ),
 *           'icon'      => 'card',
 *           'after'     => 'addresses',
 *           'render_cb' => 'my_plugin_render_payments',
 *       );
 *       return $s;
 *   } );
 * ---------------------------------------------------------------------- */

/**
 * Collect plugin-registered account sections (normalised + filtered).
 *
 * @return array<string,array<string,mixed>> Keyed by sanitised slug.
 */
function zymarg_os_account_extra_sections() {
	$sections = apply_filters( 'zymarg_os_account_sections', array() );
	$clean    = array();

	if ( ! is_array( $sections ) ) {
		return $clean;
	}

	foreach ( $sections as $slug => $def ) {
		$slug = sanitize_key( (string) $slug );
		if ( '' === $slug || ! is_array( $def ) ) {
			continue;
		}
		// Never let a plugin override a core section slug.
		if ( in_array( $slug, array( 'dashboard', 'orders', 'wishlist', 'recently-viewed', 'addresses', 'profile', 'reviews', 'coupons', 'returns', 'support', 'notifications', 'security' ), true ) ) {
			continue;
		}
		if ( array_key_exists( 'enabled', $def ) && ! $def['enabled'] ) {
			continue;
		}
		$def = wp_parse_args(
			$def,
			array(
				'label'     => ucfirst( str_replace( array( '-', '_' ), ' ', $slug ) ),
				'icon'      => 'card',
				'endpoint'  => $slug,
				'after'     => 'addresses',
				'render_cb' => null,
			)
		);
		$def['endpoint']  = sanitize_key( (string) $def['endpoint'] );
		$clean[ $slug ]   = $def;
	}

	return $clean;
}

/**
 * Render a sidebar nav icon that may be an icon key OR raw inline SVG.
 *
 * Raw SVG is only ever supplied server-side by an installed plugin (trusted),
 * so it is emitted as-is; icon keys resolve through the theme icon library.
 *
 * @param string $icon Icon key or raw SVG markup.
 * @return string SVG markup.
 */
function zymarg_os_account_render_nav_icon( $icon ) {
	if ( is_string( $icon ) && '<' === substr( ltrim( $icon ), 0, 1 ) ) {
		return $icon;
	}
	return zymarg_os_account_icon( (string) $icon );
}

/* ---------------------------------------------------------------------- *
 * Custom WooCommerce endpoints for the new sections
 * ---------------------------------------------------------------------- */

/**
 * Register custom endpoints so WooCommerce knows about our new sections.
 */
function zymarg_os_account_endpoints() {
	foreach ( zymarg_os_account_endpoint_slugs() as $ep ) {
		add_rewrite_endpoint( $ep, EP_ROOT | EP_PAGES );
	}
}

/**
 * The single list of account endpoint slugs this theme owns.
 *
 * Extracted in v5.19.0 so the endpoint list has one definition instead of being
 * duplicated between the rewrite registration and the query-var filter, where
 * the two copies could drift apart. The Pages & Slugs registry also reads this
 * list to discover which slugs the theme created.
 *
 * @since 5.19.0
 *
 * @param bool $filtered Whether to apply the filter. Pass false to get the raw
 *                       list, which the registry screen needs so a slug it has
 *                       switched off does not disappear from its own table.
 * @return array<int,string> Endpoint slugs.
 */
function zymarg_os_account_endpoint_slugs( $filtered = true ) {
	$endpoints = array(
		'wishlist',
		'recently-viewed',
		'notifications',
		'reviews',
		'coupons',
		'returns',
		'support',
		'security',
	);
	// Endpoints contributed by plugin-registered sections (e.g. Payments).
	foreach ( zymarg_os_account_extra_sections() as $def ) {
		$endpoints[] = $def['endpoint'];
	}

	$endpoints = array_values( array_unique( array_filter( $endpoints ) ) );

	if ( ! $filtered ) {
		return $endpoints;
	}

	/**
	 * Filter the account endpoint slugs registered by the theme.
	 *
	 * @since 5.19.0
	 *
	 * @param array<int,string> $endpoints Endpoint slugs.
	 */
	return (array) apply_filters( 'zymarg_os_account_endpoint_slugs', $endpoints );
}
add_action( 'init', 'zymarg_os_account_endpoints' );

/**
 * Add query vars for the custom endpoints.
 *
 * @param array $vars Query vars.
 * @return array
 */
function zymarg_os_account_query_vars( $vars ) {
	foreach ( zymarg_os_account_endpoint_slugs() as $ep ) {
		$vars[] = $ep;
	}
	return $vars;
}
add_filter( 'query_vars', 'zymarg_os_account_query_vars' );

/**
 * Flush rewrite rules on theme activation so the new endpoints work immediately.
 */
function zymarg_os_account_flush_rules() {
	zymarg_os_account_endpoints();
	flush_rewrite_rules();
}
add_action( 'after_switch_theme', 'zymarg_os_account_flush_rules' );

/**
 * Flush rewrite rules once after a version change, so newly added account
 * endpoints (e.g. the Payments endpoint added in v5.11.8) resolve without the
 * admin having to manually re-save Settings → Permalinks. The endpoints are
 * already registered on `init`; this just refreshes the rewrite cache a single
 * time per version bump (guarded by an option so it never runs on every load).
 */
function zymarg_os_account_maybe_flush_rules() {
	$flag = get_option( 'zymarg_os_ep_version' );
	if ( $flag !== ZYMARG_OS_VERSION ) {
		flush_rewrite_rules();
		update_option( 'zymarg_os_ep_version', ZYMARG_OS_VERSION );
	}
}
add_action( 'init', 'zymarg_os_account_maybe_flush_rules', 20 );

/* ---------------------------------------------------------------------- *
 * Body classes
 * ---------------------------------------------------------------------- */

/**
 * Add body classes for the custom My Account layout.
 *
 * @param string[] $classes Body classes.
 * @return string[]
 */
function zymarg_os_account_body_classes( $classes ) {
	if ( ! function_exists( 'is_account_page' ) || ! is_account_page() ) {
		return $classes;
	}
	if ( ! is_user_logged_in() ) {
		return $classes;
	}
	$classes[] = 'zymarg-myaccount-active';

	/*
	 * Expose the active section as its own body class, e.g.
	 * zymarg-acc-section-messages, zymarg-acc-section-orders.
	 * This lets a single panel opt out of the shared column padding without
	 * relying on the CSS :has() selector, so it works in every browser.
	 */
	if ( function_exists( 'zymarg_os_account_active_section' ) ) {
		$zymarg_acc_section = zymarg_os_account_active_section();
		if ( $zymarg_acc_section ) {
			$classes[] = 'zymarg-acc-section-' . sanitize_html_class( $zymarg_acc_section );
		}
	}

	return $classes;
}
add_filter( 'body_class', 'zymarg_os_account_body_classes' );

/**
 * Hide the page title on the My Account page (our sidebar + panel header
 * handle the navigation context — the "My Account" <h1> is redundant and
 * leaks into the layout).
 *
 * @param bool $show Whether to show the page title.
 * @return bool
 */
function zymarg_os_account_hide_page_title( $show ) {
	if ( function_exists( 'is_account_page' ) && is_account_page() && is_user_logged_in() ) {
		return false;
	}
	return $show;
}
add_filter( 'zymarg_os_show_page_title', 'zymarg_os_account_hide_page_title' );/* ---------------------------------------------------------------------- *
 * Determine the active section
 * ---------------------------------------------------------------------- */

/**
 * Get the currently active My Account section key.
 *
 * @return string
 */
function zymarg_os_account_active_section() {
	global $wp;

	// WooCommerce built-in endpoints mapped to our section keys.
	$wc_map = array(
		'orders'          => 'orders',
		'view-order'      => 'orders',
		'order-received'  => 'orders',
		'order-pay'       => 'orders',
		'edit-address'    => 'addresses',
		'edit-account'    => 'profile',
	);

	foreach ( $wc_map as $ep => $section ) {
		if ( isset( $wp->query_vars[ $ep ] ) ) {
			return $section;
		}
	}

	// Custom endpoints.
	$custom = array( 'wishlist', 'recently-viewed', 'notifications', 'reviews', 'coupons', 'returns', 'support', 'security' );
	foreach ( $custom as $ep ) {
		if ( isset( $wp->query_vars[ $ep ] ) ) {
			return $ep;
		}
	}

	// Plugin-registered sections (e.g. Payments from the ZYMARG Wallet plugin).
	foreach ( zymarg_os_account_extra_sections() as $slug => $def ) {
		if ( isset( $wp->query_vars[ $def['endpoint'] ] ) ) {
			return $slug;
		}
	}

	return 'dashboard';
}

/* ---------------------------------------------------------------------- *
 * Sidebar rendering
 * ---------------------------------------------------------------------- */

/**
 * Assemble the My Account sidebar navigation.
 *
 * Single source of truth for the nav: the sidebar renders from this, and the
 * Customizer order control lists from this, so the two can never disagree
 * about which items exist.
 *
 * @since 5.16.0
 *
 * @return array{items:array<string,array{0:string,1:string}>,url_map:array<string,string>,community_url:string}
 */
function zymarg_os_account_nav_config() {
	// Navigation items: key => [ label, svg_icon ]
	$nav_items = array(
		'dashboard'       => array( __( 'Dashboard', 'zymarg-os' ), 'home' ),
		'profile'         => array( __( 'Profile', 'zymarg-os' ), 'user' ),
		'addresses'       => array( __( 'Addresses', 'zymarg-os' ), 'map-pin' ),
		'orders'          => array( __( 'Orders', 'zymarg-os' ), 'bag' ),
		'wishlist'        => array( __( 'Wishlist', 'zymarg-os' ), 'heart' ),
		'recently-viewed' => array( __( 'Recently Viewed', 'zymarg-os' ), 'clock' ),
		'reviews'         => array( __( 'Reviews', 'zymarg-os' ), 'star' ),
		'coupons'         => array( __( 'Vouchers', 'zymarg-os' ), 'ticket' ),
		'returns'         => array( __( 'Returns & Refunds', 'zymarg-os' ), 'refresh' ),
		'support'         => array( __( 'Support', 'zymarg-os' ), 'headset' ),
		'notifications'   => array( __( 'Notifications', 'zymarg-os' ), 'bell' ),
		'security'        => array( __( 'Security', 'zymarg-os' ), 'lock' ),
	);

	/*
	 * Insert "Community" directly after "Reviews" — ONLY when the ZYMARG
	 * Community Request Board plugin is active. The plugin defines
	 * ZCRB_POST_TYPE; if the constant is missing, the item is silently
	 * omitted so non-Community sites get exactly the same sidebar as before.
	 * The link points to the plugin's public archive (default: /community/),
	 * resolved dynamically so the URL stays correct regardless of permalink
	 * settings.
	 */
	$community_url = '';
	if ( defined( 'ZCRB_POST_TYPE' ) ) {
		$community_url = (string) get_post_type_archive_link( ZCRB_POST_TYPE );
	}
	if ( '' !== $community_url ) {
		$insert = array( 'community' => array( __( 'Community', 'zymarg-os' ), 'users' ) );
		$offset = array_search( 'reviews', array_keys( $nav_items ), true );
		if ( false !== $offset ) {
			$nav_items = array_slice( $nav_items, 0, $offset + 1, true )
				+ $insert
				+ array_slice( $nav_items, $offset + 1, null, true );
		}
	}

	// Map section keys to WC endpoints or custom endpoints for URL building.
	$url_map = array(
		'dashboard'       => '',
		'orders'          => 'orders',
		'wishlist'        => 'wishlist',
		'recently-viewed' => 'recently-viewed',
		'addresses'       => 'edit-address',
		'profile'         => 'edit-account',
		'notifications'   => 'notifications',
		'reviews'         => 'reviews',
		'coupons'         => 'coupons',
		'returns'         => 'returns',
		'support'         => 'support',
		'security'        => 'security',
	);

	/*
	 * Insert plugin-registered sections (e.g. "Payments" from the ZYMARG
	 * Wallet plugin) into the sidebar, each after its requested anchor item,
	 * and register its endpoint in the URL map. When no such plugin is
	 * active, the sidebar is exactly as it was before.
	 */
	foreach ( zymarg_os_account_extra_sections() as $slug => $def ) {
		$insert = array( $slug => array( $def['label'], $def['icon'] ) );
		$offset = array_search( $def['after'], array_keys( $nav_items ), true );
		if ( false !== $offset ) {
			$nav_items = array_slice( $nav_items, 0, $offset + 1, true )
				+ $insert
				+ array_slice( $nav_items, $offset + 1, null, true );
		} else {
			$nav_items += $insert;
		}
		$url_map[ $slug ] = $def['endpoint'];
	}

	/**
	 * Filter the final My Account sidebar navigation items.
	 *
	 * Fires after the built-in items, the conditional Community link and every
	 * plugin-registered section have been assembled, so a callback always sees
	 * the complete list. The array is keyed by section slug and each value is
	 * [ label, icon ]; keys must be preserved, because the URL map, the active
	 * -section resolver and the section renderers all look up by slug.
	 *
	 * @since 5.16.0
	 *
	 * @param array<string,array{0:string,1:string}> $nav_items Keyed by slug.
	 */
	$nav_items = apply_filters( 'zymarg_os_account_nav_items', $nav_items );

	return array(
		'items'         => is_array( $nav_items ) ? $nav_items : array(),
		'url_map'       => $url_map,
		'community_url' => $community_url,
	);
}

/* ---------------------------------------------------------------------- *
 * Sidebar menu order (Customizer-sortable)
 *
 * The owner can drag the My Account sidebar into any order from
 * Customize -> ZYMARG OS -> My Account — Links.
 *
 * Stored as a SPARSE WEIGHT MAP derived from an ordered list of slugs, never
 * as a rebuilt array. The sidebar is not a fixed list: "Community" only
 * appears when the Community Request Board plugin is active, and any plugin
 * can register a section through `zymarg_os_account_sections` (Wallet adds
 * Payments, Communication adds Messages). Rebuilding the nav from a stored
 * list would silently drop any item the owner had never seen, i.e. remove a
 * section from the customer's account page.
 *
 * So the sort only ever REORDERS — it never adds and never removes, and it
 * preserves array keys, because $url_map, zymarg_os_account_active_section()
 * and the section renderers all key off the slug.
 *
 * With the theme mod empty this layer is a no-op.
 * ---------------------------------------------------------------------- */

/**
 * The saved My Account sidebar order as a sanitised weight map.
 *
 * @return array<string,int> Slug => sort weight. Empty when unconfigured.
 */
function zymarg_os_account_nav_order() {
	$raw = (string) get_theme_mod( 'zymarg_account_nav_order', '' );
	if ( '' === trim( $raw ) ) {
		return array();
	}

	$slugs = array_filter( array_map( 'sanitize_key', array_map( 'trim', explode( ',', $raw ) ) ) );
	$slugs = array_values( array_unique( $slugs ) );
	$slugs = array_slice( $slugs, 0, 100 ); // Sanity cap; the real nav is ~14 items.

	$weights = array();
	$weight  = 0;
	foreach ( $slugs as $slug ) {
		$weights[ $slug ] = $weight;
		$weight          += 10;
	}

	return $weights;
}

/**
 * Apply the owner's custom My Account sidebar order.
 *
 * @param array $items Nav items keyed by slug.
 * @return array Same items, reordered, keys preserved. Never a different count.
 */
function zymarg_os_apply_account_nav_order( $items ) {
	if ( ! is_array( $items ) || count( $items ) < 2 ) {
		return $items;
	}

	$weights = zymarg_os_account_nav_order();
	if ( empty( $weights ) ) {
		return $items; // Unconfigured — leave the natural order completely alone.
	}

	/*
	 * Anchor an item with no saved weight to its natural NEIGHBOUR rather than
	 * to its natural index.
	 *
	 * A section the owner has never seen — one a plugin registered after the
	 * order was saved — then appears immediately after the item it naturally
	 * follows, wherever the owner has since moved that item to. Keying off the
	 * natural index instead would drop it at an unrelated slot that merely
	 * happens to share that number with a saved weight.
	 *
	 * Saved weights are scaled by 1000 so unsaved items can be slotted in
	 * between two saved ones without ever colliding. An item that precedes
	 * every saved one anchors to -1, so it stays at the top where it naturally
	 * sat. The original index is carried as a tiebreaker to keep the sort
	 * stable.
	 */
	$decorated = array();
	$index     = 0;
	$anchor    = -1;
	$offset    = 0;

	foreach ( $items as $key => $item ) {
		$slug = sanitize_key( (string) $key );

		if ( '' !== $slug && array_key_exists( $slug, $weights ) ) {
			$anchor = (int) $weights[ $slug ];
			$offset = 0;
			$weight = $anchor * 1000;
		} else {
			$offset++;
			$weight = ( $anchor * 1000 ) + $offset;
		}

		$decorated[] = array(
			'weight' => $weight,
			'index'  => $index,
			'key'    => $key,
			'item'   => $item,
		);
		$index++;
	}

	usort(
		$decorated,
		static function ( $a, $b ) {
			if ( $a['weight'] === $b['weight'] ) {
				return $a['index'] < $b['index'] ? -1 : ( $a['index'] > $b['index'] ? 1 : 0 );
			}
			return $a['weight'] < $b['weight'] ? -1 : 1;
		}
	);

	// Rebuild by hand, preserving the original keys: the slug is what every
	// other part of the account page looks items up by.
	$sorted = array();
	foreach ( $decorated as $entry ) {
		$sorted[ $entry['key'] ] = $entry['item'];
	}

	return $sorted;
}
add_filter( 'zymarg_os_account_nav_items', 'zymarg_os_apply_account_nav_order', 30 );

/**
 * Render the sidebar navigation.
 *
 * @return void
 */
function zymarg_os_account_sidebar() {
	$user    = wp_get_current_user();
	$active  = zymarg_os_account_active_section();
	$account = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : home_url( '/my-account/' );

	// One source of truth for the nav, shared with the Customizer control.
	$nav_config    = zymarg_os_account_nav_config();
	$nav_items     = $nav_config['items'];
	$url_map       = $nav_config['url_map'];
	$community_url = $nav_config['community_url'];

	?>
	<aside class="zymarg-acc-sidebar">
		<div class="user-header">
			<?php
			$has_uploaded_avatar = (bool) get_user_meta( $user->ID, '_zymarg_avatar_url', true );
			$avatar_classes      = 'user-avatar' . ( $has_uploaded_avatar ? ' has-photo' : '' );
			?>
			<div class="<?php echo esc_attr( $avatar_classes ); ?>">
				<img class="zymarg-avatar-preview" src="<?php echo esc_url( zymarg_os_get_user_avatar_url( $user->ID, 80 ) ); ?>" alt="">
				<button type="button" class="user-avatar-upload" id="zymarg-avatar-btn" title="<?php esc_attr_e( 'Change photo', 'zymarg-os' ); ?>">
					<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>
				</button>
				<div class="user-avatar-picker" id="zymarg-avatar-picker" style="display:none">
					<button type="button" class="avatar-picker-opt" id="zymarg-avatar-camera">
						<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>
						<?php esc_html_e( 'Take Photo', 'zymarg-os' ); ?>
					</button>
					<button type="button" class="avatar-picker-opt" id="zymarg-avatar-gallery">
						<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
						<?php esc_html_e( 'Choose from Gallery', 'zymarg-os' ); ?>
					</button>
					<?php if ( $has_uploaded_avatar ) : ?>
					<button type="button" class="avatar-picker-opt avatar-picker-opt--remove" id="zymarg-avatar-remove">
						<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-2 14a2 2 0 0 1-2 2H9a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2"/></svg>
						<?php esc_html_e( 'Remove photo', 'zymarg-os' ); ?>
					</button>
					<?php endif; ?>
				</div>
				<input type="file" id="zymarg-avatar-input" accept="image/*" style="display:none">
			</div>
			<div>
				<div class="user-name"><?php echo esc_html( $user->display_name ); ?></div>
				<div class="user-role"><?php esc_html_e( 'My Account', 'zymarg-os' ); ?></div>
			</div>
		</div>
		<nav>
			<?php foreach ( $nav_items as $key => $item ) : ?>
				<?php
				$endpoint = isset( $url_map[ $key ] ) ? $url_map[ $key ] : $key;
				// "community" is the only external link in the sidebar — it
				// points to the Community plugin's public archive URL.
				$is_external = false;
				if ( 'community' === $key && ! empty( $community_url ) ) {
					$url         = $community_url;
					$is_external = true;
				} else {
					$url = '' === $endpoint ? $account : wc_get_endpoint_url( $endpoint, '', $account );
				}
				$is_active = ( $key === $active );
				$classes   = 'nav-link' . ( $is_active ? ' active' : '' );
				?>
				<a class="<?php echo esc_attr( $classes ); ?>" href="<?php echo esc_url( $url ); ?>" data-nav="<?php echo esc_attr( $key ); ?>"<?php echo $is_external ? ' data-external="1"' : ''; ?>>
					<?php echo zymarg_os_account_render_nav_icon( $item[1] ); // phpcs:ignore ?>
					<span><?php echo esc_html( $item[0] ); ?></span>
				</a>
			<?php endforeach; ?>
			<hr class="nav-divider">
			<div class="zymarg-acc-sidebar__theme-switch" style="padding:10px 12px 6px;">
				<?php echo do_shortcode( '[zymarg_theme_switch]' ); ?>
			</div>
			<a class="nav-link logout" href="<?php echo esc_url( wp_logout_url( home_url( '/' ) ) ); ?>" data-zymarg-logout>
				<?php echo zymarg_os_account_icon( 'logout' ); // phpcs:ignore ?>
				<span><?php esc_html_e( 'Logout', 'zymarg-os' ); ?></span>
			</a>
		</nav>
	</aside>

	<!-- Logout Confirmation Modal -->
	<div class="zymarg-logout-modal" id="zymarg-logout-modal" hidden>
		<div class="zymarg-logout-modal__overlay" data-zymarg-logout-close></div>
		<div class="zymarg-logout-modal__dialog">
			<button type="button" class="zymarg-logout-modal__close" data-zymarg-logout-close aria-label="<?php esc_attr_e( 'Close', 'zymarg-os' ); ?>">&times;</button>
			<div class="zymarg-logout-modal__icon">
				<?php echo zymarg_os_account_icon( 'logout' ); // phpcs:ignore ?>
			</div>
			<h3 class="zymarg-logout-modal__title"><?php esc_html_e( 'Sign Out?', 'zymarg-os' ); ?></h3>
			<p class="zymarg-logout-modal__desc"><?php esc_html_e( 'Are you sure you want to log out of your account?', 'zymarg-os' ); ?></p>
			<div class="zymarg-logout-modal__actions">
				<button type="button" class="zymarg-logout-modal__btn zymarg-logout-modal__btn--cancel" data-zymarg-logout-close><?php esc_html_e( 'Cancel', 'zymarg-os' ); ?></button>
				<a href="<?php echo esc_url( wp_logout_url( home_url( '/' ) ) ); ?>" class="zymarg-logout-modal__btn zymarg-logout-modal__btn--confirm"><?php esc_html_e( 'Yes, Log Out', 'zymarg-os' ); ?></a>
			</div>
		</div>
	</div>
	<?php
}

/* ---------------------------------------------------------------------- *
 * SVG Icon helper
 * ---------------------------------------------------------------------- */

/**
 * Return an inline SVG icon by key.
 *
 * @param string $icon Icon key.
 * @return string SVG markup.
 */
function zymarg_os_account_icon( $icon ) {
	$icons = array(
		'home'    => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>',
		'bag'     => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a4 4 0 0 0-8 0v2"/></svg>',
		'heart'   => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1 1.1L12 21.3l7.8-7.8 1-1.1a5.5 5.5 0 0 0 0-7.8z"/></svg>',
		'clock'   => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>',
		'map-pin' => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>',
		'user'    => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>',
		'bell'    => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/></svg>',
		'star'    => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><polygon points="12 2 15.1 8.3 22 9.2 17 14.1 18.2 21 12 17.8 5.8 21 7 14.1 2 9.2 8.9 8.3 12 2"/></svg>',
		'ticket'  => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M2 9a3 3 0 0 1 3 3 3 3 0 0 1-3 3v4h20v-4a3 3 0 0 1 0-6V5H2z"/><line x1="13" y1="5" x2="13" y2="19" stroke-dasharray="2 2"/></svg>',
		'refresh' => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><polyline points="1 4 1 10 7 10"/><path d="M3.5 15a9 9 0 1 0 2.1-7.4L1 10"/></svg>',
		'message' => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>',
		'headset' => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M3 14v-2a9 9 0 0 1 18 0v2"/><rect x="2" y="14" width="5" height="7" rx="2"/><rect x="17" y="14" width="5" height="7" rx="2"/><path d="M17 21a4 4 0 0 1-4 4h-1"/></svg>',
		'globe'   => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>',
		'lock'    => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>',
		'card'    => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>',
		'users'   => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
		'logout'  => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>',
	);

	return isset( $icons[ $icon ] ) ? $icons[ $icon ] : '';
}

/* ---------------------------------------------------------------------- *
 * Template override — WooCommerce template file
 * ---------------------------------------------------------------------- *
 * The custom layout is handled entirely by our template override at
 * woocommerce/myaccount/my-account.php. This replaces the default WC
 * template for logged-in users. No hook-based wrapping is needed.
 *
 * The template calls:
 *   1. zymarg_os_account_sidebar()       — renders the sidebar nav.
 *   2. zymarg_os_account_active_section() — determines the current section.
 *   3. zymarg_os_account_render_section() — renders the section content.
 *   4. zymarg_os_account_bottom_nav()     — renders the mobile bottom nav.
 * ---------------------------------------------------------------------- */

/**
 * Render the mobile bottom navigation bar.
 * DISABLED — the user doesn't want a dedicated mobile footer on the account page.
 */
function zymarg_os_account_bottom_nav() {
	// Intentionally empty — bottom nav removed per user request.
}



/* ---------------------------------------------------------------------- *
 * AJAX: save notification / email preference toggles
 * ---------------------------------------------------------------------- */

/**
 * Save a user preference toggle via AJAX.
 */
function zymarg_os_save_pref_ajax() {
	check_ajax_referer( 'zymarg_save_pref', 'nonce' );

	if ( ! is_user_logged_in() ) {
		wp_send_json_error();
	}

	$key   = isset( $_POST['key'] ) ? sanitize_key( $_POST['key'] ) : '';
	$value = isset( $_POST['value'] ) ? absint( $_POST['value'] ) : 0;

	$allowed_keys = array(
		'order_updates', 'price_drops', 'restock',
		'newsletter', 'order_emails', 'promo_emails',
	);

	if ( ! in_array( $key, $allowed_keys, true ) ) {
		wp_send_json_error();
	}

	// Notification keys use zymarg_notif_ prefix, email prefs use zymarg_pref_ prefix.
	$notif_keys = array( 'order_updates', 'price_drops', 'restock' );
	$prefix     = in_array( $key, $notif_keys, true ) ? 'zymarg_notif_' : 'zymarg_pref_';

	update_user_meta( get_current_user_id(), $prefix . $key, $value );
	wp_send_json_success();
}
add_action( 'wp_ajax_zymarg_save_pref', 'zymarg_os_save_pref_ajax' );

/* ---------------------------------------------------------------------- *
 * AJAX: delete account
 * ---------------------------------------------------------------------- */

/**
 * Handle account deletion form submission.
 */
function zymarg_os_handle_delete_account() {
	if ( ! isset( $_POST['zymarg_del_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( $_POST['zymarg_del_nonce'] ), 'zymarg_delete_account' ) ) {
		return;
	}
	if ( ! is_user_logged_in() ) {
		return;
	}

	$password = isset( $_POST['confirm_password'] ) ? $_POST['confirm_password'] : ''; // phpcs:ignore
	$user     = wp_get_current_user();

	if ( ! wp_check_password( $password, $user->user_pass, $user->ID ) ) {
		wc_add_notice( __( 'Incorrect password. Account was NOT deleted.', 'zymarg-os' ), 'error' );
		return;
	}

	// Don't allow admins to delete themselves from the front end.
	if ( user_can( $user, 'manage_options' ) ) {
		wc_add_notice( __( 'Administrator accounts cannot be deleted from the front end.', 'zymarg-os' ), 'error' );
		return;
	}

	require_once ABSPATH . 'wp-admin/includes/user.php';
	wp_delete_user( $user->ID );
	wp_logout();
	zymarg_os_acc_redirect( home_url( '/' ) );
}
add_action( 'template_redirect', 'zymarg_os_handle_delete_account' );




/**
 * Inject critical inline CSS in <head> BEFORE any stylesheet loads.
 * This prevents the container from ever rendering at its constrained width —
 * the browser sees "full-width, no padding" from the very first paint frame.
 * No reflow, no "dancing".
 */
function zymarg_os_account_critical_css() {
	if ( ! function_exists( 'is_account_page' ) || ! is_account_page() || ! is_user_logged_in() ) {
		return;
	}
	?>
	<style id="zymarg-myaccount-critical">
	body.zymarg-myaccount-active .zymarg-container,
	body.zymarg-myaccount-active .zymarg-site-content,
	body.zymarg-myaccount-active .zymarg-entry,
	body.zymarg-myaccount-active .zymarg-entry__content,
	body.zymarg-myaccount-active .zymarg-main,
	body.zymarg-myaccount-active .zymarg-woo-main,
	body.zymarg-myaccount-active #content {
		max-width: none !important;
		width: 100% !important;
		padding: 0 !important;
		margin: 0 !important;
	}
	</style>
	<?php
}
add_action( 'wp_head', 'zymarg_os_account_critical_css', 1 );



/* ---------------------------------------------------------------------- *
 * Avatar upload: AJAX handler + assets
 * ---------------------------------------------------------------------- */

/**
 * Enqueue avatar upload assets on the My Account page.
 */
function zymarg_os_avatar_upload_assets() {
	if ( ! function_exists( 'is_account_page' ) || ! is_account_page() || ! is_user_logged_in() ) {
		return;
	}
	$ver = ZYMARG_OS_VERSION;
	wp_enqueue_style( 'zymarg-os-avatar-crop', ZYMARG_OS_URI . '/assets/css/avatar-crop.css', array(), $ver );
	wp_enqueue_script( 'zymarg-os-avatar-upload', ZYMARG_OS_URI . '/assets/js/avatar-upload.js', array(), $ver, true );
	wp_localize_script( 'zymarg-os-avatar-upload', 'ZymargAvatar', array(
		'ajaxUrl'          => admin_url( 'admin-ajax.php' ),
		'nonce'            => wp_create_nonce( 'zymarg_upload_avatar' ),
		'defaultAvatarUrl' => is_user_logged_in() ? get_avatar_url( get_current_user_id(), array( 'size' => 80 ) ) : '',
		'i18n'             => array(
			'confirmRemove' => __( 'Remove your profile photo? You can upload a new one anytime.', 'zymarg-os' ),
			'removeError'   => __( 'Could not remove your photo. Please try again.', 'zymarg-os' ),
		),
	) );
}
add_action( 'wp_enqueue_scripts', 'zymarg_os_avatar_upload_assets', 30 );

/**
 * AJAX: handle avatar upload — receives the cropped+compressed JPEG blob,
 * saves as a WordPress attachment, stores the URL in user meta.
 */
function zymarg_os_avatar_upload_ajax() {
	check_ajax_referer( 'zymarg_upload_avatar', '_wpnonce' );

	if ( ! is_user_logged_in() ) {
		wp_send_json_error( array( 'message' => 'Not logged in.' ) );
	}

	if ( empty( $_FILES['avatar']['tmp_name'] ) ) {
		wp_send_json_error( array( 'message' => 'No file uploaded.' ) );
	}

	require_once ABSPATH . 'wp-admin/includes/image.php';
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';

	$user_id = get_current_user_id();

	// Delete old avatar attachment if exists.
	$old_id = (int) get_user_meta( $user_id, '_zymarg_avatar_id', true );
	if ( $old_id ) {
		wp_delete_attachment( $old_id, true );
	}

	$attachment_id = media_handle_upload( 'avatar', 0 );
	if ( is_wp_error( $attachment_id ) ) {
		wp_send_json_error( array( 'message' => $attachment_id->get_error_message() ) );
	}

	$url = wp_get_attachment_url( $attachment_id );
	update_user_meta( $user_id, '_zymarg_avatar_id', $attachment_id );
	update_user_meta( $user_id, '_zymarg_avatar_url', $url );

	wp_send_json_success( array( 'url' => $url ) );
}
add_action( 'wp_ajax_zymarg_upload_avatar', 'zymarg_os_avatar_upload_ajax' );

/**
 * AJAX: remove the current user's avatar — deletes the attachment and clears
 * the _zymarg_avatar_id / _zymarg_avatar_url user meta. The next render
 * falls back to Gravatar automatically (see zymarg_os_get_user_avatar_url).
 *
 * @return void
 */
function zymarg_os_avatar_remove_ajax() {
	check_ajax_referer( 'zymarg_upload_avatar', '_wpnonce' );

	if ( ! is_user_logged_in() ) {
		wp_send_json_error( array( 'message' => 'Not logged in.' ), 403 );
	}

	$user_id = get_current_user_id();

	// Best-effort: delete the previous attachment.
	$old_id = (int) get_user_meta( $user_id, '_zymarg_avatar_id', true );
	if ( $old_id ) {
		wp_delete_attachment( $old_id, true );
	}

	// Clear our meta. zymarg_os_get_user_avatar_url() will fall back to Gravatar.
	delete_user_meta( $user_id, '_zymarg_avatar_id' );
	delete_user_meta( $user_id, '_zymarg_avatar_url' );

	wp_send_json_success(
		array(
			'message'    => 'Photo removed.',
			'defaultUrl' => get_avatar_url( $user_id, array( 'size' => 80 ) ),
		)
	);
}
add_action( 'wp_ajax_zymarg_remove_avatar', 'zymarg_os_avatar_remove_ajax' );

/**
 * Get the custom avatar URL for a user, falling back to Gravatar.
 *
 * @param int $user_id User ID.
 * @param int $size    Image size.
 * @return string URL.
 */
function zymarg_os_get_user_avatar_url( $user_id, $size = 80 ) {
	$custom = get_user_meta( $user_id, '_zymarg_avatar_url', true );
	if ( $custom ) {
		return $custom;
	}
	return get_avatar_url( $user_id, array( 'size' => $size ) );
}



/* ---------------------------------------------------------------------- *
 * My Account links (Support / Help / Track) — Customizer configurable
 * ---------------------------------------------------------------------- */

/**
 * Get a configured My Account link with a sensible fallback.
 *
 * @param string $key One of: contact, help, track.
 * @return string URL (may be empty for 'track' if unset).
 */
function zymarg_os_account_link( $key ) {
	$defaults = array(
		'contact' => home_url( '/contact/' ),
		'help'    => home_url( '/help/' ),
		'track'   => '',
		// Customer-facing browse destination. This site lists products at
		// /store-listing/, not WooCommerce's default /shop/, so the "Start
		// Shopping" card in an empty Orders section points here. Overridable in
		// the Customizer; falls back to the WooCommerce shop page if cleared.
		'shop'    => home_url( '/store-listing/' ),
	);
	$val = get_theme_mod( 'zymarg_account_link_' . $key, '' );
	if ( '' === $val && isset( $defaults[ $key ] ) ) {
		$val = $defaults[ $key ];
	}
	return esc_url( $val );
}

/**
 * Register the drag-to-sort control class for the sidebar order.
 *
 * Deliberately declared HERE rather than in inc/customize-controls.php. That
 * file is only required when the ZYMARG Login & Security plugin is inactive
 * (see functions.php — it is grouped with the theme's login fallback), so a
 * control defined there simply does not exist on a site running ZLS. This file
 * is loaded under exactly the condition that matters instead: WooCommerce
 * active and the woocommerce module on, i.e. whenever a My Account page exists.
 *
 * Runs at priority 1 so the class is available to the priority-10 registration
 * in zymarg_os_account_links_customizer() below.
 *
 * @since 5.16.1
 *
 * @return void
 */
function zymarg_os_register_account_nav_order_control() {
	if ( ! class_exists( 'WP_Customize_Control' ) ) {
		return;
	}
	if ( class_exists( 'Zymarg_Customize_Account_Nav_Order_Control' ) ) {
		return;
	}

	/**
	 * Drag-to-sort My Account sidebar order control.
	 *
	 * Lists the live sidebar links and saves a comma-separated list of slugs in
	 * the chosen order. Arrow buttons sit beside each row so the control also
	 * works by keyboard and on touch, where HTML5 drag and drop does not.
	 */
	class Zymarg_Customize_Account_Nav_Order_Control extends WP_Customize_Control {
		public $type = 'zymarg_account_nav_order';

		public function render_content() {
			if ( ! function_exists( 'zymarg_os_account_nav_config' ) ) {
				return;
			}

			$config = zymarg_os_account_nav_config();
			$items  = isset( $config['items'] ) && is_array( $config['items'] ) ? $config['items'] : array();
			if ( count( $items ) < 2 ) {
				return;
			}

			// Normalise to slug => label, skipping anything malformed.
			$rows = array();
			foreach ( $items as $slug => $item ) {
				$slug = sanitize_key( (string) $slug );
				if ( '' === $slug ) {
					continue;
				}
				$rows[ $slug ] = ( is_array( $item ) && isset( $item[0] ) && '' !== $item[0] )
					? (string) $item[0]
					: $slug;
			}
			if ( count( $rows ) < 2 ) {
				return;
			}

			// The live order is already sorted by the saved value, so the hidden
			// input starts in sync and saving without touching anything is a
			// no-op rather than a wipe.
			$current = implode( ',', array_keys( $rows ) );
			$uid     = 'zymarg-navorder-' . wp_unique_id();
			?>
			<?php if ( ! empty( $this->label ) ) : ?>
				<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
			<?php endif; ?>
			<?php if ( ! empty( $this->description ) ) : ?>
				<span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
			<?php endif; ?>
			<div class="zymarg-navorder-wrap" id="<?php echo esc_attr( $uid ); ?>" style="margin-top:8px;">
				<ul class="zymarg-navorder-list" style="margin:0;padding:0;list-style:none;background:#fff;border:1px solid #ddd;border-radius:6px;overflow:hidden;">
					<?php foreach ( $rows as $slug => $label ) : ?>
						<li class="zymarg-navorder-item" data-slug="<?php echo esc_attr( $slug ); ?>" draggable="true" style="display:flex;align-items:center;gap:6px;padding:7px 9px;border-bottom:1px solid #f0f0f1;cursor:grab;font-size:13px;">
							<span aria-hidden="true" style="color:#a7aaad;line-height:1;">&#8942;&#8942;</span>
							<span style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?php echo esc_html( $label ); ?></span>
							<button type="button" class="button zymarg-navorder-up" style="min-height:24px;height:24px;line-height:22px;padding:0 6px;" aria-label="<?php echo esc_attr( sprintf( /* translators: %s: menu item name. */ __( 'Move %s up', 'zymarg-os' ), $label ) ); ?>">&uarr;</button>
							<button type="button" class="button zymarg-navorder-down" style="min-height:24px;height:24px;line-height:22px;padding:0 6px;" aria-label="<?php echo esc_attr( sprintf( /* translators: %s: menu item name. */ __( 'Move %s down', 'zymarg-os' ), $label ) ); ?>">&darr;</button>
						</li>
					<?php endforeach; ?>
				</ul>
				<p style="margin:6px 0 0;color:#777;font-size:11px;">
					<?php esc_html_e( 'Only sections that are currently available are listed. Save and reload the Customizer to see newly added ones.', 'zymarg-os' ); ?>
				</p>
			</div>
			<input type="hidden" class="zymarg-navorder-value" <?php $this->link(); ?> value="<?php echo esc_attr( $current ); ?>">
			<script>
			(function() {
				var wrap = document.getElementById('<?php echo esc_js( $uid ); ?>');
				if (!wrap) return;
				var list   = wrap.querySelector('.zymarg-navorder-list');
				var hidden = wrap.parentNode.querySelector('.zymarg-navorder-value');
				if (!list || !hidden) return;
				var dragEl = null;

				function serialize() {
					var slugs = [];
					var items = list.querySelectorAll('.zymarg-navorder-item');
					Array.prototype.forEach.call(items, function(li, i) {
						var s = li.getAttribute('data-slug');
						if (s) slugs.push(s);
						var up = li.querySelector('.zymarg-navorder-up');
						var dn = li.querySelector('.zymarg-navorder-down');
						if (up) up.disabled = (i === 0);
						if (dn) dn.disabled = (i === items.length - 1);
					});
					hidden.value = slugs.join(',');
					hidden.dispatchEvent(new Event('change'));
				}

				list.addEventListener('click', function(e) {
					var btn = e.target.closest ? e.target.closest('.zymarg-navorder-up, .zymarg-navorder-down') : null;
					if (!btn || btn.disabled) return;
					e.preventDefault();
					var li = btn.closest('.zymarg-navorder-item');
					if (!li) return;
					var isUp = btn.classList.contains('zymarg-navorder-up');
					if (isUp && li.previousElementSibling) {
						li.parentNode.insertBefore(li, li.previousElementSibling);
					} else if (!isUp && li.nextElementSibling) {
						li.parentNode.insertBefore(li.nextElementSibling, li);
					} else {
						return;
					}
					serialize();
					if (!btn.disabled) { btn.focus(); }
					else {
						var other = li.querySelector(isUp ? '.zymarg-navorder-down' : '.zymarg-navorder-up');
						if (other && !other.disabled) other.focus();
					}
				});

				list.addEventListener('dragstart', function(e) {
					var li = e.target.closest ? e.target.closest('.zymarg-navorder-item') : null;
					if (!li) return;
					dragEl = li;
					li.style.opacity = '0.5';
					if (e.dataTransfer) {
						e.dataTransfer.effectAllowed = 'move';
						try { e.dataTransfer.setData('text/plain', li.getAttribute('data-slug') || ''); } catch (ignore) {}
					}
				});

				list.addEventListener('dragover', function(e) {
					if (!dragEl) return;
					var over = e.target.closest ? e.target.closest('.zymarg-navorder-item') : null;
					if (!over || over === dragEl || over.parentNode !== dragEl.parentNode) return;
					e.preventDefault();
					var box = over.getBoundingClientRect();
					var after = (e.clientY - box.top) > (box.height / 2);
					over.parentNode.insertBefore(dragEl, after ? over.nextSibling : over);
				});

				list.addEventListener('drop', function(e) {
					if (dragEl) e.preventDefault();
				});

				list.addEventListener('dragend', function() {
					if (!dragEl) return;
					dragEl.style.opacity = '';
					dragEl = null;
					serialize();
				});

				serialize();
			})();
			</script>
			<?php
		}
	}
}
add_action( 'customize_register', 'zymarg_os_register_account_nav_order_control', 1 );

/**
 * Sanitize the saved sidebar order: a comma-separated list of section slugs.
 *
 * @param string $value Raw value.
 * @return string Sanitised comma-separated slug list.
 */
function zymarg_os_sanitize_account_nav_order( $value ) {
	$slugs = array_filter( array_map( 'sanitize_key', array_map( 'trim', explode( ',', (string) $value ) ) ) );
	$slugs = array_values( array_unique( $slugs ) );
	$slugs = array_slice( $slugs, 0, 100 );

	return implode( ',', $slugs );
}

/**
 * Register Customizer controls for the My Account links.
 *
 * @param WP_Customize_Manager $wp_customize Customizer.
 * @return void
 */
function zymarg_os_account_links_customizer( $wp_customize ) {
	$wp_customize->add_section(
		'zymarg_account_links',
		array(
			'title'       => __( 'My Account — Links', 'zymarg-os' ),
			'description' => __( 'Set the URLs used by the My Account page (Support, Help Center, and the Track Order button), and choose the order of the sidebar links.', 'zymarg-os' ),
			// This section was missing the 'panel' key since it was first
			// written, so it has ALWAYS rendered as a stray top-level
			// Customizer item instead of nested inside ZYMARG OS. Fixed in
			// v5.12.12 — unrelated to the separate Login-section priority bug.
			'panel'       => 'zymarg_os_panel',
			'priority'    => 160,
		)
	);

	$fields = array(
		'contact' => __( 'Contact / Support URL', 'zymarg-os' ),
		'help'    => __( 'Help Center URL', 'zymarg-os' ),
		'track'   => __( 'Track Order URL (your courier tracking page — optional)', 'zymarg-os' ),
		'shop'    => __( 'Browse / Store Listing URL (where "Start Shopping" goes — defaults to /store-listing/)', 'zymarg-os' ),
	);
	foreach ( $fields as $key => $label ) {
		$wp_customize->add_setting(
			'zymarg_account_link_' . $key,
			array(
				'default'           => '',
				'sanitize_callback' => 'esc_url_raw',
			)
		);
		$wp_customize->add_control(
			'zymarg_account_link_' . $key,
			array(
				'type'    => 'url',
				'label'   => $label,
				'section' => 'zymarg_account_links',
			)
		);
	}

	/*
	 * Support section card visibility (v5.16.7).
	 *
	 * The My Account -> Support panel has two action cards: "Contact Support"
	 * (opens the admin messaging thread via the Communication plugin's
	 * data-zymarg-support-start hook) and "Help Center" (links to the URL
	 * set above). These two toggles let the marketplace owner independently
	 * enable or hide each card — most useful for the Help Center card while
	 * the owner is still building out the help content, so it stays hidden
	 * until the destination page exists.
	 */
	$wp_customize->add_setting(
		'zymarg_account_support_show_contact',
		array(
			'default'           => true,
			'sanitize_callback' => 'wp_validate_boolean',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'zymarg_account_support_show_contact',
		array(
			'type'        => 'checkbox',
			'label'       => __( 'Show "Contact Support" card', 'zymarg-os' ),
			'description' => __( 'When enabled, buyers see the "Contact Support" card on My Account -> Support. Clicking it opens a direct chat with your admin team.', 'zymarg-os' ),
			'section'     => 'zymarg_account_links',
		)
	);

	$wp_customize->add_setting(
		'zymarg_account_support_show_help',
		array(
			'default'           => false,
			'sanitize_callback' => 'wp_validate_boolean',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'zymarg_account_support_show_help',
		array(
			'type'        => 'checkbox',
			'label'       => __( 'Show "Help Center" card', 'zymarg-os' ),
			'description' => __( 'When enabled, buyers see the "Help Center" card on My Account -> Support. Requires a Help Center URL to be set above — the card stays hidden if the URL is blank, so you can prepare help content before switching this on.', 'zymarg-os' ),
			'section'     => 'zymarg_account_links',
		)
	);

	/*
	 * Sidebar link order. Lives in this same section because these ARE the
	 * My Account links — the URL fields above set where three of them point,
	 * this sets the order the customer sees them in.
	 */
	$wp_customize->add_setting(
		'zymarg_account_nav_order',
		array(
			'default'           => '',
			'sanitize_callback' => 'zymarg_os_sanitize_account_nav_order',
			'transport'         => 'refresh',
		)
	);

	if ( class_exists( 'Zymarg_Customize_Account_Nav_Order_Control' ) ) {
		$wp_customize->add_control(
			new Zymarg_Customize_Account_Nav_Order_Control(
				$wp_customize,
				'zymarg_account_nav_order',
				array(
					'label'       => __( 'Sidebar link order', 'zymarg-os' ),
					'description' => __( 'Drag a link, or use the arrow buttons, to set the order customers see in the My Account sidebar.', 'zymarg-os' ),
					'section'     => 'zymarg_account_links',
					'settings'    => 'zymarg_account_nav_order',
				)
			)
		);
	}
}
add_action( 'customize_register', 'zymarg_os_account_links_customizer' );

/* ---------------------------------------------------------------------- *
 * Marketing-email preference enforcement
 * ---------------------------------------------------------------------- *
 * Stores the customer's choice and exposes a single helper + filter that any
 * newsletter/marketing integration (Mailchimp, FluentCRM, custom code) can
 * check before sending promotional email. WooCommerce TRANSACTIONAL emails
 * (order confirmations, etc.) are intentionally NOT disabled — customers
 * need those, and disabling them causes support problems.
 * ---------------------------------------------------------------------- */

/**
 * Whether the user has opted in to marketing / promotional email.
 *
 * @param int $user_id User ID (defaults to current).
 * @return bool
 */
function zymarg_os_user_allows_marketing( $user_id = 0 ) {
	$user_id = $user_id ? $user_id : get_current_user_id();
	if ( ! $user_id ) {
		return false;
	}
	$promo = get_user_meta( $user_id, 'zymarg_pref_promo_emails', true );
	$news  = get_user_meta( $user_id, 'zymarg_pref_newsletter', true );
	// Unset = default opted-in (matches the toggle defaults).
	$promo = ( '' === $promo ) ? true : (bool) $promo;
	$news  = ( '' === $news ) ? true : (bool) $news;
	$allow = ( $promo || $news );

	/**
	 * Filter whether a user allows marketing email.
	 *
	 * @param bool $allow   Allowed.
	 * @param int  $user_id User ID.
	 */
	return (bool) apply_filters( 'zymarg_os_user_allows_marketing', $allow, $user_id );
}



/* ---------------------------------------------------------------------- *
 * AJAX: load a My Account section (SPA-style navigation + prefetch)
 * ---------------------------------------------------------------------- *
 * Returns the rendered HTML of a single section so the front-end can swap
 * the content area without a full page reload — and prefetch the other
 * sections in the background so navigation feels instant.
 * ---------------------------------------------------------------------- */

/**
 * Render one section and return its HTML over AJAX.
 *
 * @return void
 */
function zymarg_os_ajax_load_section() {
	check_ajax_referer( 'zymarg_load_section', 'nonce' );

	if ( ! is_user_logged_in() ) {
		wp_send_json_error( array( 'message' => 'not_logged_in' ) );
	}

	$section = isset( $_POST['section'] ) ? sanitize_key( wp_unslash( $_POST['section'] ) ) : 'dashboard';

	$allowed = array(
		'dashboard', 'orders', 'wishlist', 'recently-viewed', 'addresses',
		'profile', 'notifications', 'reviews', 'coupons', 'returns',
		'support', 'security',
	);
	// Allow plugin-registered sections (e.g. Payments) to load over SPA AJAX.
	foreach ( zymarg_os_account_extra_sections() as $slug => $def ) {
		$allowed[] = $slug;
	}
	if ( ! in_array( $section, $allowed, true ) ) {
		$section = 'dashboard';
	}

	// Note which assets exist before rendering, so anything the section
	// enqueues for itself can be forwarded to the browser. A section rendered
	// here cannot reach <head> on its own, which is why plugin panels arrived
	// unstyled over SPA navigation but looked right after a reload.
	$assets_before = function_exists( 'zymarg_os_acc_asset_snapshot' )
		? zymarg_os_acc_asset_snapshot()
		: null;

	ob_start();
	if ( function_exists( 'zymarg_os_account_render_section' ) ) {
		zymarg_os_account_render_section( $section );
	}
	$html = ob_get_clean();

	$assets = ( null !== $assets_before && function_exists( 'zymarg_os_acc_asset_diff' ) )
		? zymarg_os_acc_asset_diff( $assets_before )
		: array();

	wp_send_json_success(
		array(
			'html'   => $html,
			'assets' => $assets,
		)
	);
}
add_action( 'wp_ajax_zymarg_load_section', 'zymarg_os_ajax_load_section' );
