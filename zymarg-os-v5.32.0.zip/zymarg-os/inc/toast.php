<?php
/**
 * Unified Toast Notifications loader.
 *
 * Registers and enqueues the shared toast component (components/toast/toast.css
 * + assets/js/modules/toast.js) on the front end, exposes a small server-side
 * helper to queue a toast for the next page load, and wires the "login success"
 * notification. Add-to-cart and review-submitted toasts are auto-wired in JS;
 * wishlist/compare call window.ZymargToast directly.
 *
 * Also owns the "who fired that toast" tracking used by the ZYMARG OS ->
 * Toast Notification admin screen (see inc/admin-toast.php):
 *   - Every toast can carry a source (plugin/feature slug).
 *   - Attempts (shown + blocked) are logged to a rolling activity log.
 *   - Sources can be switched off from the admin screen, which blocks the
 *     toast from ever rendering (server-side queue) or lets the front-end
 *     script silently suppress it (client-fired toasts).
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

const ZYMARG_OS_TOAST_LOG_OPTION     = 'zymarg_os_toast_log';
const ZYMARG_OS_TOAST_STATS_OPTION   = 'zymarg_os_toast_stats';
const ZYMARG_OS_TOAST_BLOCKED_OPTION = 'zymarg_os_toast_blocked_sources';
const ZYMARG_OS_TOAST_LOG_MAX        = 200;

/**
 * Register + enqueue the toast assets on the front end.
 *
 * @return void
 */
function zymarg_os_toast_assets() {
	$ver = defined( 'ZYMARG_OS_VERSION' ) ? ZYMARG_OS_VERSION : '1.0.0';

	wp_register_style( 'zymarg-os-toast', ZYMARG_OS_URI . '/components/toast/toast.css', array(), $ver );
	wp_register_script( 'zymarg-os-toast', ZYMARG_OS_URI . '/assets/js/modules/toast.js', array(), $ver, true );

	wp_localize_script(
		'zymarg-os-toast',
		'ZymargToastCfg',
		array(
			'position'       => (string) apply_filters( 'zymarg_os_toast_position', 'bottom-right' ),
			'duration'       => (int) apply_filters( 'zymarg_os_toast_duration', 3800 ),
			'cartUrl'        => function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : '',
			// Powers the Toast Notification admin screen: activity log + on/off control.
			'logUrl'         => admin_url( 'admin-ajax.php' ),
			'logNonce'       => wp_create_nonce( 'zymarg_toast_log' ),
			'blockedSources' => array_values( zymarg_os_get_blocked_toast_sources() ),
			'i18n'           => array(
				'addedToCart' => __( 'Added to cart', 'zymarg-os' ),
				'viewCart'    => __( 'View cart', 'zymarg-os' ),
			),
		)
	);

	wp_enqueue_style( 'zymarg-os-toast' );
	wp_enqueue_script( 'zymarg-os-toast' );
}
add_action( 'wp_enqueue_scripts', 'zymarg_os_toast_assets', 8 );

/**
 * Load the same toast assets inside wp-admin.
 *
 * Plugins increasingly fire admin-side notices (settings saved, test failed,
 * copied to clipboard). Without this, window.ZymargToast simply does not
 * exist in wp-admin, so every plugin that tries to use the shared toast
 * system silently falls back to its own popup — which is exactly the
 * fragmentation the Toast Notification screen exists to prevent.
 *
 * Filterable so it can be switched off without editing the theme.
 *
 * @return void
 */
function zymarg_os_toast_admin_assets() {
	if ( ! apply_filters( 'zymarg_os_toast_enable_in_admin', true ) ) {
		return;
	}

	zymarg_os_toast_assets();
}
add_action( 'admin_enqueue_scripts', 'zymarg_os_toast_admin_assets', 8 );

/**
 * Load the same toast assets on wp-login.php.
 *
 * The login screen is neither "front end" nor "admin", so neither of the hooks
 * above fires there and window.ZymargToast would not exist. Login/security
 * plugins are the most likely to want a toast on exactly that screen, so the
 * contract covers it rather than forcing a future theme edit.
 *
 * Filterable so it can be switched off without editing the theme.
 *
 * @return void
 */
function zymarg_os_toast_login_assets() {
	if ( ! apply_filters( 'zymarg_os_toast_enable_on_login', true ) ) {
		return;
	}

	zymarg_os_toast_assets();
}
add_action( 'login_enqueue_scripts', 'zymarg_os_toast_login_assets', 8 );

/**
 * Print a tiny inline stub that captures toasts fired before toast.js loads.
 *
 * THE PROBLEM THIS SOLVES
 * The toast script is deferred to the footer, so any plugin that fires a toast
 * early (inline script, head script, or an AJAX reply that resolves fast) finds
 * window.ZymargToast undefined and loses the message. Until now every plugin
 * had to carry its own fallback popup as insurance, which is precisely the
 * duplication this system exists to remove.
 *
 * HOW IT WORKS
 * This prints, very early, a stand-in object with the same method names that
 * simply queues whatever it is given. When the real toast.js loads it replaces
 * the stub and replays the queue. Plugins can therefore call
 * window.ZymargToast at any time and never need a fallback of their own.
 *
 * @return void
 */
function zymarg_os_toast_early_stub() {
	if ( ! apply_filters( 'zymarg_os_toast_early_stub', true ) ) {
		return;
	}

	$js = <<<'JS'
window.ZymargToast = window.ZymargToast || ( function () {
	var q = [];
	function push( o ) { q.push( o || {} ); return null; }
	function merge( m, t, o ) {
		var p = {};
		if ( o ) { for ( var k in o ) { if ( Object.prototype.hasOwnProperty.call( o, k ) ) { p[ k ] = o[ k ]; } } }
		p.message = m;
		p.type = t;
		return p;
	}
	return {
		_isStub: true,
		_queue: q,
		show: function ( o ) { return push( o ); },
		success: function ( m, o ) { return push( merge( m, 'success', o ) ); },
		error: function ( m, o ) { return push( merge( m, 'error', o ) ); },
		info: function ( m, o ) { return push( merge( m, 'info', o ) ); },
		warning: function ( m, o ) { return push( merge( m, 'warning', o ) ); },
		getActivityLog: function () { return []; },
		isSourceBlocked: function () { return false; }
	};
}() );
JS;

	echo '<script id="zymarg-os-toast-stub">' . $js . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}
add_action( 'wp_head', 'zymarg_os_toast_early_stub', 1 );
add_action( 'admin_head', 'zymarg_os_toast_early_stub', 1 );
add_action( 'login_head', 'zymarg_os_toast_early_stub', 1 );

/**
 * Sources that have been switched off from the Toast Notification admin
 * screen. Blocked sources never render a toast (checked both here, for
 * server-queued toasts, and in toast.js for client-fired ones).
 *
 * @return array Lowercase source slugs.
 */
function zymarg_os_get_blocked_toast_sources() {
	$blocked = get_option( ZYMARG_OS_TOAST_BLOCKED_OPTION, array() );
	return is_array( $blocked ) ? array_map( 'strtolower', $blocked ) : array();
}

/**
 * Whether a given source has been switched off.
 *
 * @param string $source Source slug.
 * @return bool
 */
function zymarg_os_toast_is_source_blocked( $source ) {
	$source = zymarg_os_normalize_toast_source( $source );
	return in_array( $source, zymarg_os_get_blocked_toast_sources(), true );
}

/**
 * Normalize a raw source string into a safe, comparable slug.
 *
 * @param string $source Raw source string.
 * @return string
 */
function zymarg_os_normalize_toast_source( $source ) {
	$source = strtolower( trim( (string) $source ) );
	$source = preg_replace( '~[^a-z0-9_./ -]~', '', $source );
	return '' === $source ? 'unknown' : substr( $source, 0, 60 );
}

/**
 * Record one toast attempt (shown or blocked) into the rolling activity log
 * and the per-source counters shown on the admin screen.
 *
 * Expected keys in $entry: source, type, title, message, blocked, page.
 *
 * @param array $entry Toast event data.
 * @return void
 */
function zymarg_os_record_toast_event( $entry ) {
	$source = zymarg_os_normalize_toast_source( isset( $entry['source'] ) ? $entry['source'] : '' );
	$type   = isset( $entry['type'] ) && in_array( $entry['type'], array( 'success', 'error', 'info', 'warning' ), true ) ? $entry['type'] : 'info';

	$row = array(
		'source'  => $source,
		'type'    => $type,
		'title'   => sanitize_text_field( (string) ( isset( $entry['title'] ) ? $entry['title'] : '' ) ),
		'message' => sanitize_text_field( (string) ( isset( $entry['message'] ) ? $entry['message'] : '' ) ),
		'blocked' => ! empty( $entry['blocked'] ),
		'page'    => esc_url_raw( (string) ( isset( $entry['page'] ) ? $entry['page'] : '' ) ),
		'time'    => time(),
	);

	$log   = get_option( ZYMARG_OS_TOAST_LOG_OPTION, array() );
	$log   = is_array( $log ) ? $log : array();
	$log[] = $row;
	if ( count( $log ) > ZYMARG_OS_TOAST_LOG_MAX ) {
		$log = array_slice( $log, -1 * ZYMARG_OS_TOAST_LOG_MAX );
	}
	update_option( ZYMARG_OS_TOAST_LOG_OPTION, $log, false );

	$stats = get_option( ZYMARG_OS_TOAST_STATS_OPTION, array() );
	$stats = is_array( $stats ) ? $stats : array();
	if ( empty( $stats[ $source ] ) || ! is_array( $stats[ $source ] ) ) {
		$stats[ $source ] = array(
			'shown'        => 0,
			'blocked'      => 0,
			'last_seen'    => 0,
			'last_message' => '',
		);
	}
	if ( $row['blocked'] ) {
		$stats[ $source ]['blocked']++;
	} else {
		$stats[ $source ]['shown']++;
	}
	$stats[ $source ]['last_seen']    = $row['time'];
	$stats[ $source ]['last_message'] = $row['message'] ? $row['message'] : $row['title'];
	update_option( ZYMARG_OS_TOAST_STATS_OPTION, $stats, false );
}

/**
 * AJAX endpoint the front-end toast.js beacons every shown/blocked toast to,
 * so the Toast Notification admin screen has a live view of which
 * plugin/feature is using the toast system.
 *
 * @return void
 */
function zymarg_os_ajax_toast_log() {
	check_ajax_referer( 'zymarg_toast_log', 'nonce' );

	zymarg_os_record_toast_event(
		array(
			'source'  => wp_unslash( isset( $_POST['source'] ) ? $_POST['source'] : '' ),
			'type'    => wp_unslash( isset( $_POST['type'] ) ? $_POST['type'] : '' ),
			'title'   => wp_unslash( isset( $_POST['title'] ) ? $_POST['title'] : '' ),
			'message' => wp_unslash( isset( $_POST['message'] ) ? $_POST['message'] : '' ),
			'blocked' => ! empty( $_POST['blocked'] ),
			'page'    => wp_unslash( isset( $_POST['page'] ) ? $_POST['page'] : '' ),
		)
	);

	wp_send_json_success();
}
add_action( 'wp_ajax_zymarg_toast_log', 'zymarg_os_ajax_toast_log' );
add_action( 'wp_ajax_nopriv_zymarg_toast_log', 'zymarg_os_ajax_toast_log' );

/**
 * Queue a toast to show on the current user's next front-end page load.
 *
 * @param string $message Message text.
 * @param string $type    success|error|info|warning.
 * @param string $title   Optional title.
 * @param string $source  Optional plugin/feature identifier (e.g. "woocommerce", "my-plugin"). Shown in the Toast Notification admin screen and used for on/off control.
 * @return void
 */
function zymarg_os_queue_toast( $message, $type = 'info', $title = '', $source = '' ) {
	$uid = get_current_user_id();
	if ( ! $uid ) {
		return;
	}

	$source = zymarg_os_normalize_toast_source( $source ? $source : 'theme' );

	// A source switched off in the admin screen never gets queued.
	if ( zymarg_os_toast_is_source_blocked( $source ) ) {
		zymarg_os_record_toast_event(
			array(
				'source'  => $source,
				'type'    => $type,
				'title'   => $title,
				'message' => $message,
				'blocked' => true,
			)
		);
		return;
	}

	$queue = get_transient( 'zymarg_toast_queue_' . $uid );
	if ( ! is_array( $queue ) ) {
		$queue = array();
	}
	$queue[] = array(
		'message' => (string) $message,
		'type'    => (string) $type,
		'title'   => (string) $title,
		'source'  => $source,
	);
	set_transient( 'zymarg_toast_queue_' . $uid, $queue, 5 * MINUTE_IN_SECONDS );
}

/**
 * Flush any queued toasts as inline JS in the footer.
 *
 * @return void
 */
function zymarg_os_toast_flush_queue() {
	if ( ! is_user_logged_in() ) {
		return;
	}
	$uid   = get_current_user_id();
	$queue = get_transient( 'zymarg_toast_queue_' . $uid );
	if ( empty( $queue ) || ! is_array( $queue ) ) {
		return;
	}
	delete_transient( 'zymarg_toast_queue_' . $uid );

	// Each queued toast is already tagged with its source, so it will be
	// picked up by the client-side blocked-sources check and activity log too.
	echo '<script id="zymarg-toast-queue">(function(){var q=' . wp_json_encode( array_values( $queue ) ) . ';function fire(){if(!window.ZymargToast){return setTimeout(fire,60);}q.forEach(function(t){window.ZymargToast.show(t);});}fire();})();</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}
add_action( 'wp_footer', 'zymarg_os_toast_flush_queue', 100 );

/**
 * Queue a "welcome back" toast on successful login.
 *
 * @param string  $user_login Username.
 * @param WP_User $user       User object.
 * @return void
 */
function zymarg_os_toast_on_login( $user_login, $user = null ) {
	if ( ! $user instanceof WP_User ) {
		$user = get_user_by( 'login', $user_login );
	}
	if ( ! $user ) {
		return;
	}
	$name = $user->display_name ? $user->display_name : $user_login;
	zymarg_os_queue_toast(
		sprintf( /* translators: %s: display name */ __( 'Welcome back, %s!', 'zymarg-os' ), $name ),
		'success',
		'',
		'zymarg-login'
	);
}
add_action( 'wp_login', 'zymarg_os_toast_on_login', 10, 2 );
