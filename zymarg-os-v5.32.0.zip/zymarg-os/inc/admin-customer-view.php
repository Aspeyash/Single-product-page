<?php
/**
 * Customer console — the support view inside ZYMARG OS -> Customers.
 *
 * SHAPE OF THIS SCREEN
 *   Two dropdowns, one panel. The first dropdown picks the customer (a search
 *   box backed by the customer index, because a <select> listing a million
 *   users is not a thing). The second picks the section — Overview, Orders,
 *   Addresses, Profile, Activity, Access log — and only that panel is visible.
 *   The page stays one screen tall instead of becoming a long stack of tables.
 *
 *   All panels are rendered server-side and switched in the browser, so moving
 *   between sections costs no request at all.
 *
 * READ-ONLY
 *   Every value here comes from the getters in inc/customer-data.php and nothing
 *   on this screen writes to a customer's account. Editing stays with core's
 *   user screen (linked in the toolbar), which keeps the change log honest about
 *   who altered what — the record that settles payment disputes.
 *
 *   Opening a customer is recorded by inc/customer-access-log.php, and the
 *   Access log panel shows those records back to you.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * The sections offered in the section dropdown.
 *
 * @return array<string,string> key => label
 */
function zymarg_os_customer_console_sections() {
	$sections = array(
		'overview'  => __( 'Overview', 'zymarg-os' ),
		'orders'    => __( 'Orders', 'zymarg-os' ),
		'addresses' => __( 'Addresses', 'zymarg-os' ),
		'profile'   => __( 'Profile fields', 'zymarg-os' ),
		'activity'  => __( 'Activity timeline', 'zymarg-os' ),
		'access'    => __( 'Who viewed this account', 'zymarg-os' ),
	);

	/**
	 * Filters the customer console sections.
	 *
	 * @param array $sections key => label.
	 */
	return (array) apply_filters( 'zymarg_os_customer_console_sections', $sections );
}

/**
 * Enqueue the console's assets on the Customers screen.
 *
 * @param string $hook Admin page hook suffix.
 * @return void
 */
function zymarg_os_customer_console_assets( $hook ) {
	if ( false === strpos( (string) $hook, 'zymarg-os-customers' ) ) {
		return;
	}

	$ver = defined( 'ZYMARG_OS_VERSION' ) ? ZYMARG_OS_VERSION : '1.0.0';

	// Depends on the brand layer so the shared header always wins. See v5.27.9.
	wp_enqueue_style(
		'zymarg-os-admin-customer-console',
		ZYMARG_OS_URI . '/assets/css/admin-customer-console.css',
		wp_style_is( 'zymarg-os-admin-brand', 'registered' ) ? array( 'zymarg-os-admin-brand' ) : array(),
		$ver
	);

	wp_enqueue_script(
		'zymarg-os-admin-customer-console',
		ZYMARG_OS_URI . '/assets/js/admin-customer-console.js',
		array(),
		$ver,
		true
	);

	wp_localize_script(
		'zymarg-os-admin-customer-console',
		'ZymargCustomerConsole',
		array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( ZYMARG_OS_CUSTOMER_SEARCH_NONCE ),
			'strings' => array(
				'none'     => __( 'No customer matches that.', 'zymarg-os' ),
				'error'    => __( 'Search failed. Please try again.', 'zymarg-os' ),
				'building' => __( 'No match yet — the customer index is still building. Try again shortly.', 'zymarg-os' ),
			),
		)
	);
}
add_action( 'admin_enqueue_scripts', 'zymarg_os_customer_console_assets', 40 );

/* ======================================================================
   1. SHARED CHROME
   ====================================================================== */

/**
 * The screen header, identical in shape to every other ZYMARG OS screen.
 *
 * @param string $title Heading text.
 * @param string $intro Intro paragraph.
 * @return void
 */
function zymarg_os_customer_console_header( $title, $intro = '' ) {
	echo '<h1>';

	if ( function_exists( 'zymarg_discovery_spark' ) ) {
		echo zymarg_discovery_spark( array( 'size' => 'lg' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	echo esc_html( $title );
	echo '<span class="zymarg-welcome__v">v' . esc_html( ZYMARG_OS_VERSION ) . '</span>';
	echo '</h1>';

	if ( '' !== $intro ) {
		echo '<p class="zymarg-welcome__intro">' . esc_html( $intro ) . '</p>';
	}
}

/**
 * The customer search box — dropdown one.
 *
 * @return void
 */
function zymarg_os_customer_console_search_field() {
	?>
	<div class="zym-cc__field zym-cc__search">
		<label class="zym-cc__label" for="zymarg-cc-search">
			<?php esc_html_e( 'Customer', 'zymarg-os' ); ?>
		</label>
		<input
			type="search"
			id="zymarg-cc-search"
			class="zym-cc__input"
			autocomplete="off"
			role="combobox"
			aria-expanded="false"
			aria-controls="zymarg-cc-results"
			placeholder="<?php esc_attr_e( 'Search name, email, phone or ID…', 'zymarg-os' ); ?>"
			data-zymarg-customer-search
		>
		<ul id="zymarg-cc-results" class="zym-cc__results" role="listbox" data-zymarg-customer-results></ul>
	</div>
	<?php
}

/* ======================================================================
   2. PICKER (NO CUSTOMER CHOSEN)
   ====================================================================== */

/**
 * The landing state: pick a customer, plus the ten most recent for convenience.
 *
 * Deliberately short. The full paginated list is one click away rather than
 * filling this screen.
 *
 * @return void
 */
function zymarg_os_render_customer_console_picker() {
	$recent   = function_exists( 'zymarg_os_customer_index_page' ) ? zymarg_os_customer_index_page( array( 'number' => 10 ) ) : array();
	$building = function_exists( 'zymarg_os_customer_index_is_building' ) && zymarg_os_customer_index_is_building();
	?>
	<div class="wrap zymarg-admin zymarg-welcome" data-zymarg-console>
		<?php
		zymarg_os_customer_console_header(
			__( 'Customers', 'zymarg-os' ),
			__( 'Search for a customer to see their account exactly as they see it — orders, addresses, profile and history, read-only.', 'zymarg-os' )
		);
		?>

		<div class="zym-cc__bar">
			<?php zymarg_os_customer_console_search_field(); ?>
			<div class="zym-cc__actions">
				<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=zymarg-os-customers&view=list' ) ); ?>">
					<?php esc_html_e( 'Browse full list', 'zymarg-os' ); ?>
				</a>
			</div>
		</div>

		<?php if ( $building ) : ?>
			<div class="notice notice-info inline zym-cc__readonly">
				<p>
					<?php
					printf(
						/* translators: %s: number of customers indexed so far. */
						esc_html__( 'The customer search index is still building — %s indexed so far. Search gets more complete every few minutes.', 'zymarg-os' ),
						esc_html( number_format_i18n( function_exists( 'zymarg_os_customer_index_size' ) ? zymarg_os_customer_index_size() : 0 ) )
					);
					?>
				</p>
			</div>
		<?php endif; ?>

		<h2 class="title"><?php esc_html_e( 'Recently joined', 'zymarg-os' ); ?></h2>

		<?php if ( empty( $recent ) ) : ?>
			<p class="description">
				<?php esc_html_e( 'Nothing indexed yet. Use the search box above, or open the full list.', 'zymarg-os' ); ?>
			</p>
		<?php else : ?>
			<table class="widefat striped zym-cc__table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Customer', 'zymarg-os' ); ?></th>
						<th><?php esc_html_e( 'Orders', 'zymarg-os' ); ?></th>
						<th><?php esc_html_e( 'Lifetime value', 'zymarg-os' ); ?></th>
						<th><?php esc_html_e( 'Joined', 'zymarg-os' ); ?></th>
					</tr>
				</thead>
				<tbody>
				<?php foreach ( $recent as $row ) : ?>
					<tr>
						<td>
							<strong>
								<a href="<?php echo esc_url( zymarg_os_customer_view_url( $row->user_id ) ); ?>">
									<?php echo esc_html( $row->display_name ? $row->display_name : $row->username ); ?>
								</a>
							</strong>
							<div class="zym-cc__result-meta"><?php echo esc_html( $row->user_email ); ?></div>
						</td>
						<td><?php echo esc_html( number_format_i18n( (int) $row->order_count ) ); ?></td>
						<td>
							<?php
							echo function_exists( 'wc_price' )
								? wp_kses_post( wc_price( (float) $row->total_spent ) )
								: esc_html( number_format_i18n( (float) $row->total_spent, 2 ) );
							?>
						</td>
						<td><?php echo esc_html( mysql2date( get_option( 'date_format' ), $row->registered ) ); ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>
	</div>
	<?php
}

/* ======================================================================
   3. CONSOLE (CUSTOMER CHOSEN)
   ====================================================================== */

/**
 * The customer console.
 *
 * @param int $user_id Customer ID.
 * @return void
 */
function zymarg_os_render_customer_console( $user_id ) {
	$snapshot = zymarg_os_customer_snapshot( $user_id, 'view' );

	if ( is_wp_error( $snapshot ) ) {
		echo '<div class="wrap zymarg-admin zymarg-welcome">';
		zymarg_os_customer_console_header( __( 'Customer unavailable', 'zymarg-os' ), $snapshot->get_error_message() );
		echo '<p><a class="button" href="' . esc_url( admin_url( 'admin.php?page=zymarg-os-customers' ) ) . '">' .
			esc_html__( 'Back to customers', 'zymarg-os' ) . '</a></p></div>';

		return;
	}

	$identity = $snapshot['identity'];
	$sections = zymarg_os_customer_console_sections();
	$current  = isset( $_GET['section'] ) ? sanitize_key( wp_unslash( $_GET['section'] ) ) : 'overview'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

	if ( ! isset( $sections[ $current ] ) ) {
		$current = 'overview';
	}
	?>
	<div class="wrap zymarg-admin zymarg-welcome" data-zymarg-console>
		<?php zymarg_os_customer_console_header( $identity['name'] ); ?>

		<div class="zym-cc__bar">
			<?php zymarg_os_customer_console_search_field(); ?>

			<div class="zym-cc__field">
				<label class="zym-cc__label" for="zymarg-cc-section">
					<?php esc_html_e( 'Show', 'zymarg-os' ); ?>
				</label>
				<select id="zymarg-cc-section" data-zymarg-section-select>
					<?php foreach ( $sections as $key => $label ) : ?>
						<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $key, $current ); ?>>
							<?php echo esc_html( $label ); ?>
						</option>
					<?php endforeach; ?>
				</select>
			</div>

			<div class="zym-cc__actions">
				<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=zymarg-os-customers' ) ); ?>">
					<?php esc_html_e( 'All customers', 'zymarg-os' ); ?>
				</a>
				<?php if ( function_exists( 'zymarg_os_customer_orders_url' ) ) : ?>
					<a class="button" href="<?php echo esc_url( zymarg_os_customer_orders_url( $identity['id'] ) ); ?>">
						<?php esc_html_e( 'All orders', 'zymarg-os' ); ?>
					</a>
				<?php endif; ?>
				<a class="button" href="<?php echo esc_url( $identity['edit_url'] ); ?>">
					<?php esc_html_e( 'Edit in WordPress', 'zymarg-os' ); ?>
				</a>
			</div>
		</div>

		<?php
		zymarg_os_customer_panel_overview( $snapshot, $current );
		zymarg_os_customer_panel_orders( $identity['id'], $current );
		zymarg_os_customer_panel_addresses( $snapshot, $current );
		zymarg_os_customer_panel_profile( $snapshot, $current );
		zymarg_os_customer_panel_activity( $snapshot, $current );
		zymarg_os_customer_panel_access( $identity['id'], $current );

		/**
		 * Fires after the built-in console panels.
		 *
		 * Echo a div with class "zym-cc__panel" and a data-zymarg-panel attribute
		 * matching a key added via zymarg_os_customer_console_sections.
		 *
		 * @param array  $snapshot Customer snapshot.
		 * @param string $current  Active section key.
		 */
		do_action( 'zymarg_os_customer_console_panels', $snapshot, $current );
		?>
	</div>
	<?php
}

/**
 * Open a panel wrapper.
 *
 * @param string $key     Panel key.
 * @param string $current Active key.
 * @param string $title   Panel heading.
 * @return void
 */
function zymarg_os_customer_panel_open( $key, $current, $title ) {
	printf(
		'<div class="zym-cc__panel%1$s" data-zymarg-panel="%2$s"><h2>%3$s</h2>',
		$key === $current ? ' is-active' : '',
		esc_attr( $key ),
		esc_html( $title )
	);
}

/**
 * Overview: the facts an agent reads first.
 *
 * @param array  $snapshot Snapshot.
 * @param string $current  Active section.
 * @return void
 */
function zymarg_os_customer_panel_overview( $snapshot, $current ) {
	$identity = $snapshot['identity'];
	$metrics  = $snapshot['metrics'];

	zymarg_os_customer_panel_open( 'overview', $current, __( 'Who they are', 'zymarg-os' ) );
	?>
	<div class="zym-cc__who">
		<div class="zym-cc__avatar">
			<img src="<?php echo esc_url( $identity['avatar_url'] ); ?>" alt="" width="44" height="44">
		</div>
		<div>
			<strong><?php echo esc_html( $identity['name'] ); ?></strong>
			<?php if ( $identity['is_vendor'] ) : ?>
				<span class="zym-cc__tag"><?php esc_html_e( 'Vendor', 'zymarg-os' ); ?></span>
			<?php endif; ?>
			<div class="zym-cc__result-meta">
				<?php
				printf(
					/* translators: 1: user ID, 2: role list. */
					esc_html__( 'ID %1$s — %2$s', 'zymarg-os' ),
					esc_html( (string) $identity['id'] ),
					esc_html( implode( ', ', (array) $identity['roles'] ) )
				);
				?>
			</div>
		</div>
	</div>

	<?php if ( ! empty( $metrics['has_woocommerce'] ) ) : ?>
		<div class="zym-cc__stats">
			<div class="zym-cc__stat">
				<span class="zym-cc__stat-label"><?php esc_html_e( 'Orders', 'zymarg-os' ); ?></span>
				<span class="zym-cc__stat-value"><?php echo esc_html( number_format_i18n( (int) $metrics['order_count'] ) ); ?></span>
			</div>
			<div class="zym-cc__stat">
				<span class="zym-cc__stat-label"><?php esc_html_e( 'Lifetime value', 'zymarg-os' ); ?></span>
				<span class="zym-cc__stat-value"><?php echo wp_kses_post( wc_price( (float) $metrics['total_spent'] ) ); ?></span>
			</div>
			<div class="zym-cc__stat">
				<span class="zym-cc__stat-label"><?php esc_html_e( 'Average order', 'zymarg-os' ); ?></span>
				<span class="zym-cc__stat-value"><?php echo wp_kses_post( wc_price( (float) $metrics['average_order'] ) ); ?></span>
			</div>
			<div class="zym-cc__stat">
				<span class="zym-cc__stat-label"><?php esc_html_e( 'Last order', 'zymarg-os' ); ?></span>
				<span class="zym-cc__stat-value">
					<?php
					echo esc_html(
						$metrics['last_order_at']
							? mysql2date( get_option( 'date_format' ), get_date_from_gmt( $metrics['last_order_at'] ) )
							: '—'
					);
					?>
				</span>
			</div>
		</div>
	<?php endif; ?>

	<table class="widefat striped zym-cc__table">
		<tbody>
			<tr>
				<th><?php esc_html_e( 'Email', 'zymarg-os' ); ?></th>
				<td><a href="mailto:<?php echo esc_attr( $identity['email'] ); ?>"><?php echo esc_html( $identity['email'] ); ?></a></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'Username', 'zymarg-os' ); ?></th>
				<td><?php echo esc_html( $identity['username'] ); ?></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'Phone', 'zymarg-os' ); ?></th>
				<td><?php echo esc_html( $identity['phone'] ? $identity['phone'] : '—' ); ?></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'WhatsApp', 'zymarg-os' ); ?></th>
				<td>
					<?php
					echo $identity['whatsapp'] && function_exists( 'zymarg_os_whatsapp_link_html' )
						? wp_kses_post( zymarg_os_whatsapp_link_html( $identity['id'] ) )
						: '&mdash;';
					?>
				</td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'Customer since', 'zymarg-os' ); ?></th>
				<td><?php echo esc_html( mysql2date( get_option( 'date_format' ), $identity['registered'] ) ); ?></td>
			</tr>
			<?php if ( null !== $identity['completeness'] ) : ?>
				<tr>
					<th><?php esc_html_e( 'Profile completeness', 'zymarg-os' ); ?></th>
					<td><?php echo esc_html( is_array( $identity['completeness'] ) && isset( $identity['completeness']['percent'] ) ? $identity['completeness']['percent'] . '%' : (string) $identity['completeness'] ); ?></td>
				</tr>
			<?php endif; ?>
		</tbody>
	</table>
	</div>
	<?php
}

/**
 * Orders panel.
 *
 * @param int    $user_id Customer ID.
 * @param string $current Active section.
 * @return void
 */
function zymarg_os_customer_panel_orders( $user_id, $current ) {
	$orders = function_exists( 'zymarg_os_customer_orders' ) ? zymarg_os_customer_orders( $user_id, 10 ) : array();

	zymarg_os_customer_panel_open( 'orders', $current, __( 'Most recent orders', 'zymarg-os' ) );

	if ( empty( $orders ) ) {
		echo '<p class="description">' . esc_html__( 'No orders yet.', 'zymarg-os' ) . '</p></div>';

		return;
	}
	?>
	<table class="widefat striped zym-cc__table">
		<thead>
			<tr>
				<th><?php esc_html_e( 'Order', 'zymarg-os' ); ?></th>
				<th><?php esc_html_e( 'Date', 'zymarg-os' ); ?></th>
				<th><?php esc_html_e( 'Status', 'zymarg-os' ); ?></th>
				<th><?php esc_html_e( 'Items', 'zymarg-os' ); ?></th>
				<th><?php esc_html_e( 'Total', 'zymarg-os' ); ?></th>
			</tr>
		</thead>
		<tbody>
		<?php foreach ( $orders as $order ) : ?>
			<?php
			if ( ! is_a( $order, 'WC_Order' ) ) {
				continue;
			}
			$created = $order->get_date_created();
			?>
			<tr>
				<td><a href="<?php echo esc_url( $order->get_edit_order_url() ); ?>">#<?php echo esc_html( $order->get_order_number() ); ?></a></td>
				<td><?php echo esc_html( $created ? $created->date_i18n( get_option( 'date_format' ) ) : '—' ); ?></td>
				<td><?php echo esc_html( wc_get_order_status_name( $order->get_status() ) ); ?></td>
				<td><?php echo esc_html( number_format_i18n( $order->get_item_count() ) ); ?></td>
				<td><?php echo wp_kses_post( $order->get_formatted_order_total() ); ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
	</div>
	<?php
}

/**
 * Addresses panel.
 *
 * @param array  $snapshot Snapshot.
 * @param string $current  Active section.
 * @return void
 */
function zymarg_os_customer_panel_addresses( $snapshot, $current ) {
	$addresses = (array) $snapshot['addresses'];

	zymarg_os_customer_panel_open( 'addresses', $current, __( 'Address book', 'zymarg-os' ) );

	if ( empty( $addresses ) ) {
		echo '<p class="description">' . esc_html__( 'No addresses saved.', 'zymarg-os' ) . '</p></div>';

		return;
	}

	$skip = array( 'id', 'source', 'default' );

	echo '<table class="widefat striped zym-cc__table"><tbody>';

	foreach ( $addresses as $index => $address ) {
		$label = isset( $address['label'] ) && '' !== $address['label']
			? $address['label']
			: sprintf( /* translators: %d: address number. */ __( 'Address %d', 'zymarg-os' ), (int) $index + 1 );

		$parts = array();

		foreach ( (array) $address as $key => $value ) {
			if ( in_array( $key, $skip, true ) || 'label' === $key ) {
				continue;
			}

			if ( is_scalar( $value ) && '' !== trim( (string) $value ) ) {
				$parts[] = (string) $value;
			}
		}

		echo '<tr><th>' . esc_html( $label ) . '</th><td>' . esc_html( implode( ', ', $parts ) ) . '</td></tr>';
	}

	echo '</tbody></table></div>';
}

/**
 * Profile fields panel — the same fields My Account shows the customer.
 *
 * @param array  $snapshot Snapshot.
 * @param string $current  Active section.
 * @return void
 */
function zymarg_os_customer_panel_profile( $snapshot, $current ) {
	$fields = (array) $snapshot['profile'];

	zymarg_os_customer_panel_open( 'profile', $current, __( 'Profile fields', 'zymarg-os' ) );

	echo '<p class="description zym-cc__readonly">' .
		esc_html__( 'These are the same fields the customer sees on My Account, read from the same definitions. Read-only here on purpose — changes should come from the customer or from the WordPress user screen, so the change log stays accurate.', 'zymarg-os' ) .
		'</p>';

	if ( empty( $fields ) ) {
		echo '<p class="description">' . esc_html__( 'No profile fields are defined.', 'zymarg-os' ) . '</p></div>';

		return;
	}

	echo '<table class="widefat striped zym-cc__table"><tbody>';

	foreach ( $fields as $field ) {
		$value = isset( $field['value'] ) ? $field['value'] : '';

		if ( is_array( $value ) ) {
			$value = implode( ', ', array_filter( $value, 'is_scalar' ) );
		}

		echo '<tr><th>' . esc_html( $field['label'] );

		if ( ! empty( $field['locked'] ) ) {
			echo ' <span class="zym-cc__tag">' . esc_html__( 'Locked', 'zymarg-os' ) . '</span>';
		}

		echo '</th><td>' . esc_html( '' !== trim( (string) $value ) ? (string) $value : '—' ) . '</td></tr>';
	}

	echo '</tbody></table></div>';
}

/**
 * Activity panel — orders, account changes and security events in one order.
 *
 * @param array  $snapshot Snapshot.
 * @param string $current  Active section.
 * @return void
 */
function zymarg_os_customer_panel_activity( $snapshot, $current ) {
	$timeline = (array) $snapshot['timeline'];

	zymarg_os_customer_panel_open( 'activity', $current, __( 'Everything that happened, newest first', 'zymarg-os' ) );

	if ( empty( $timeline ) ) {
		echo '<p class="description">' .
			esc_html__( 'Nothing recorded yet. History is logged from the moment this version was installed.', 'zymarg-os' ) .
			'</p></div>';

		return;
	}

	$labels = array(
		'order'    => __( 'Order', 'zymarg-os' ),
		'change'   => __( 'Account change', 'zymarg-os' ),
		'security' => __( 'Security', 'zymarg-os' ),
	);
	?>
	<table class="widefat striped zym-cc__table">
		<thead>
			<tr>
				<th><?php esc_html_e( 'Type', 'zymarg-os' ); ?></th>
				<th><?php esc_html_e( 'What', 'zymarg-os' ); ?></th>
				<th><?php esc_html_e( 'Detail', 'zymarg-os' ); ?></th>
				<th><?php esc_html_e( 'Who', 'zymarg-os' ); ?></th>
				<th><?php esc_html_e( 'When', 'zymarg-os' ); ?></th>
			</tr>
		</thead>
		<tbody>
		<?php foreach ( $timeline as $entry ) : ?>
			<?php $type = isset( $entry['type'] ) ? $entry['type'] : ''; ?>
			<tr>
				<td>
					<span class="zym-cc__tag zym-cc__tag--<?php echo esc_attr( $type ); ?>">
						<?php echo esc_html( isset( $labels[ $type ] ) ? $labels[ $type ] : $type ); ?>
					</span>
				</td>
				<td>
					<?php if ( ! empty( $entry['url'] ) ) : ?>
						<a href="<?php echo esc_url( $entry['url'] ); ?>"><?php echo esc_html( $entry['label'] ); ?></a>
					<?php else : ?>
						<?php echo esc_html( $entry['label'] ); ?>
					<?php endif; ?>
				</td>
				<td><?php echo esc_html( isset( $entry['detail'] ) ? $entry['detail'] : '' ); ?></td>
				<td><?php echo esc_html( isset( $entry['actor'] ) ? $entry['actor'] : '' ); ?></td>
				<td>
					<?php
					echo esc_html(
						empty( $entry['time'] )
							? '—'
							: mysql2date(
								get_option( 'date_format' ) . ' ' . get_option( 'time_format' ),
								get_date_from_gmt( $entry['time'] )
							)
					);
					?>
				</td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
	</div>
	<?php
}

/**
 * Access log panel — which staff member opened this account.
 *
 * @param int    $user_id Customer ID.
 * @param string $current Active section.
 * @return void
 */
function zymarg_os_customer_panel_access( $user_id, $current ) {
	$rows = function_exists( 'zymarg_os_get_customer_access_log' ) ? zymarg_os_get_customer_access_log( $user_id, 20 ) : array();

	zymarg_os_customer_panel_open( 'access', $current, __( 'Staff who viewed this account', 'zymarg-os' ) );

	echo '<p class="description zym-cc__readonly">' .
		esc_html__( 'Every time a staff member opens this customer it is recorded here. Repeat views within five minutes count once. This is what lets you answer a customer or a regulator asking who accessed their data.', 'zymarg-os' ) .
		'</p>';

	if ( empty( $rows ) ) {
		echo '<p class="description">' . esc_html__( 'No staff access recorded yet.', 'zymarg-os' ) . '</p></div>';

		return;
	}
	?>
	<table class="widefat striped zym-cc__table">
		<thead>
			<tr>
				<th><?php esc_html_e( 'Staff member', 'zymarg-os' ); ?></th>
				<th><?php esc_html_e( 'What', 'zymarg-os' ); ?></th>
				<th><?php esc_html_e( 'From', 'zymarg-os' ); ?></th>
				<th><?php esc_html_e( 'When', 'zymarg-os' ); ?></th>
			</tr>
		</thead>
		<tbody>
		<?php foreach ( $rows as $row ) : ?>
			<tr>
				<td><?php echo esc_html( zymarg_os_customer_access_actor_label( $row ) ); ?></td>
				<td><?php echo esc_html( $row->context ); ?></td>
				<td><?php echo esc_html( $row->ip ? $row->ip : '—' ); ?></td>
				<td>
					<?php
					echo esc_html(
						mysql2date(
							get_option( 'date_format' ) . ' ' . get_option( 'time_format' ),
							get_date_from_gmt( $row->viewed_at )
						)
					);
					?>
				</td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
	</div>
	<?php
}
