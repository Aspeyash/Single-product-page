<?php
/**
 * ZYMARG Account — accordion primitive.
 *
 * The customer account panels were growing into single long scrolls. This
 * mirrors the numbered accordion already shipping in ZYMARG Vendor
 * Dashboard (includes/settings-hub.php) so a vendor who is also a customer
 * meets one consistent pattern across both surfaces.
 *
 * Deliberately re-implemented under the theme's own `zym-acc-*` namespace
 * rather than reusing the plugin's `.zymarg-vs-*` classes. The customer
 * account page must not depend on the vendor plugin's stylesheet being
 * loaded — vendors are a small subset of customers, and a shopper who never
 * opens a store would otherwise get an unstyled page.
 *
 * Usage:
 *
 *     zymarg_os_accordion_open( 'profile' );
 *         zymarg_os_accordion_card_start( 'photo', 1, __( 'Photo & identity' ), true );
 *             ... body markup ...
 *         zymarg_os_accordion_card_end();
 *     zymarg_os_accordion_close();
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Open an accordion wrapper.
 *
 * @param string $context Context key, used for remembering open state.
 * @return void
 */
function zymarg_os_accordion_open( $context ) {
	printf(
		'<div class="zym-acc" data-zym-acc="%s">',
		esc_attr( $context )
	);
}

/**
 * Close an accordion wrapper.
 *
 * @return void
 */
function zymarg_os_accordion_close() {
	echo '</div>';
}

/**
 * Start one numbered card.
 *
 * @param string $key    Section key (used for deep links: #profile-contact).
 * @param int    $number Badge number.
 * @param string $title  Card title.
 * @param bool   $open   Whether it renders expanded.
 * @param string $meta   Optional short status text shown next to the title.
 * @return void
 */
function zymarg_os_accordion_card_start( $key, $number, $title, $open = false, $meta = '' ) {
	$id = 'zym-acc-' . sanitize_html_class( $key );
	?>
	<section class="zym-acc-card<?php echo $open ? ' is-open' : ''; ?>"
		data-zym-acc-card="<?php echo esc_attr( $key ); ?>"
		id="<?php echo esc_attr( $id ); ?>">

		<h3 class="zym-acc-card__heading">
			<button type="button" class="zym-acc-card__toggle"
				aria-expanded="<?php echo $open ? 'true' : 'false'; ?>"
				aria-controls="<?php echo esc_attr( $id . '-body' ); ?>">
				<span class="zym-acc-card__num" aria-hidden="true"><?php echo esc_html( (string) $number ); ?></span>
				<span class="zym-acc-card__title"><?php echo esc_html( $title ); ?></span>
				<?php if ( '' !== $meta ) : ?>
					<span class="zym-acc-card__meta"><?php echo esc_html( $meta ); ?></span>
				<?php endif; ?>
				<span class="zym-acc-card__chevron" aria-hidden="true">&#x25BE;</span>
			</button>
		</h3>

		<div class="zym-acc-card__body" id="<?php echo esc_attr( $id . '-body' ); ?>">
	<?php
}

/**
 * Close a card.
 *
 * @return void
 */
function zymarg_os_accordion_card_end() {
	echo '</div></section>';
}
