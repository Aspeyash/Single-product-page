<?php
/**
 * Toast Notification control panel (admin page).
 *
 * A dedicated screen at ZYMARG OS -> Toast Notification that answers two
 * questions for a site running many plugins on top of one shared toast
 * system:
 *   1. WHO is using it? A live activity log + per-source counters show
 *      exactly which plugin/feature fired each toast (add-to-cart,
 *      wishlist, a specific plugin's own "source" tag, etc.). This is
 *      RUNTIME evidence — it only appears after a toast actually fires.
 *   2. WHO *could* use it, right now, before anything fires? A one-click
 *      code scanner reads every installed plugin's PHP/JS files looking
 *      for calls into the toast system (window.ZymargToast, the
 *      zymarg:toast event, or zymarg_os_queue_toast()) and lists which
 *      plugins already contain that code — no trigger required.
 *   3. HOW do I control it? Any source can be switched off here, which
 *      immediately stops that plugin/feature's toasts from rendering
 *      (both server-queued and client-fired), without touching the
 *      plugin's own code.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

const ZYMARG_OS_TOAST_SCAN_OPTION = 'zymarg_os_toast_plugin_scan';

/**
 * Register the Toast Notification submenu under the ZYMARG OS menu.
 * Priority 22 places it right after Performance (21) / Import-Export (20).
 *
 * @return void
 */
function zymarg_os_toast_admin_menu() {
	add_submenu_page(
		'zymarg-os',
		__( 'Toast Notification', 'zymarg-os' ),
		__( 'Toast Notification', 'zymarg-os' ),
		'manage_options',
		'zymarg-os-toast',
		'zymarg_os_render_toast_admin_page'
	);
}
add_action( 'admin_menu', 'zymarg_os_toast_admin_menu', 22 );

/**
 * Scan every installed plugin's PHP/JS files for toast-system usage, without
 * requiring anything to actually fire. Looks for:
 *   - window.ZymargToast.show()/success()/error()/info()/warning() calls
 *   - the decoupled 'zymarg:toast' CustomEvent
 *   - the server-side zymarg_os_queue_toast() helper
 * and, where possible, extracts the literal source string the plugin
 * declared (e.g. source: 'my-plugin-slug').
 *
 * Results are cached in an option so the (potentially slow) scan only runs
 * when explicitly requested from the admin screen.
 *
 * @return array<string,array> Plugin file => { name, active, matches[] }.
 */
function zymarg_os_scan_plugins_for_toast_usage( $only_plugin = '' ) {
	if ( ! function_exists( 'get_plugins' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}

	if ( function_exists( 'set_time_limit' ) ) {
		@set_time_limit( 120 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
	}

	$only_plugin = trim( (string) $only_plugin );

	/*
	 * Detection patterns, deliberately broad.
	 *
	 * A plugin almost never writes "ZymargToast.show()" literally — the
	 * idiomatic pattern is to alias the API first and guard for its absence:
	 *
	 *     var api = window.ZymargToast;
	 *     if ( api && api.show ) { api.show( payload ); }
	 *
	 * so matching only "ZymargToast.show(" misses real integrations. We match
	 * the identifier itself instead, which catches every call style.
	 */
	$patterns = array(
		'zymargtoast_api'   => array(
			'regex' => '~ZymargToast\b~',
			'kind'  => 'theme',
			'label' => __( 'Uses window.ZymargToast (theme toast API)', 'zymarg-os' ),
		),
		'zymarg_event'      => array(
			'regex' => '~zymarg:toast~',
			'kind'  => 'theme',
			'label' => __( 'Dispatches the zymarg:toast event', 'zymarg-os' ),
		),
		'zymarg_php_helper' => array(
			'regex' => '~zymarg_os_queue_toast\s*\(~',
			'kind'  => 'theme',
			'label' => __( 'Calls zymarg_os_queue_toast() in PHP', 'zymarg-os' ),
		),
		'zymarg_toast_cfg'  => array(
			'regex' => '~ZymargToastCfg~',
			'kind'  => 'theme',
			'label' => __( 'Reads the theme toast config (ZymargToastCfg)', 'zymarg-os' ),
		),

		/*
		 * "Rival" toasts: the plugin rolls its own popup instead of using the
		 * theme API. These CANNOT be styled or switched off from this panel,
		 * so surfacing them is the whole point — otherwise the panel says
		 * "no toast code" while the site visibly shows toasts.
		 */
		'own_toast_fn'      => array(
			'regex' => '~function\s+\w*[tT]oast\s*\(~',
			'kind'  => 'own',
			'label' => __( 'Defines its OWN toast() function (not the theme API)', 'zymarg-os' ),
		),
		'own_toast_host'    => array(
			'regex' => '~[\w-]*toast-host~i',
			'kind'  => 'own',
			'label' => __( 'Injects its OWN toast container into the page', 'zymarg-os' ),
		),
		'own_toast_markup'  => array(
			'regex' => '~class\s*=\s*["\'][^"\']*[\w-]*toast~i',
			'kind'  => 'own',
			'label' => __( 'Renders its OWN toast markup/CSS classes', 'zymarg-os' ),
		),
	);

	/**
	 * Filter the toast-detection patterns used by the plugin scanner.
	 *
	 * This exists so a new or unusual toast implementation can be taught to the
	 * scanner from a plugin or child theme, instead of requiring an edit to the
	 * theme itself. A missing pattern is what makes the scanner report "no toast
	 * code" for a plugin that visibly shows toasts.
	 *
	 * Each entry is keyed by a unique slug with:
	 *   'regex' => PCRE pattern to run against each scanned file's contents.
	 *   'kind'  => 'theme' (uses the shared toast system) or 'own' (rival popup).
	 *   'label' => Human-readable description shown in the scan results table.
	 *
	 * @param array $patterns Detection patterns.
	 */
	$patterns = (array) apply_filters( 'zymarg_os_toast_scan_patterns', $patterns );

	/**
	 * Filter the regex used to extract a declared toast source slug.
	 *
	 * @param string $source_regex PCRE pattern with one capture group.
	 */
	$source_regex = (string) apply_filters(
		'zymarg_os_toast_scan_source_regex',
		'~source["\']?\s*[:=]\s*["\']([a-z0-9_./ -]+)["\']~i'
	);

	$all_plugins          = get_plugins();
	$results              = array();
	$total_files          = 0;
	$plugins_checked      = 0;
	$incomplete           = array();
	$max_files_per_plugin = 8000; // Per-plugin budget. NEVER abort the whole scan.
	$max_bytes            = 3145728; // Skip single files over 3MB (giant bundles).

	foreach ( $all_plugins as $plugin_file => $plugin_data ) {
		$plugin_dir_rel = dirname( $plugin_file );
		$plugin_name    = ! empty( $plugin_data['Name'] ) ? $plugin_data['Name'] : $plugin_file;

		// Optional targeted scan: match against folder, main file, or display name.
		if ( '' !== $only_plugin ) {
			$haystack = $plugin_dir_rel . ' ' . $plugin_file . ' ' . $plugin_name;
			if ( false === stripos( $haystack, $only_plugin ) ) {
				continue;
			}
		}

		$plugin_dir = ( '.' === $plugin_dir_rel ) ? WP_PLUGIN_DIR : WP_PLUGIN_DIR . '/' . $plugin_dir_rel;
		if ( ! is_dir( $plugin_dir ) ) {
			continue;
		}

		$plugins_checked++;
		$matches_for_plugin = array();
		$plugin_files       = 0;
		$seen               = array(); // pattern|file dedupe.

		try {
			$iterator = new RecursiveIteratorIterator(
				new RecursiveDirectoryIterator( $plugin_dir, FilesystemIterator::SKIP_DOTS ),
				RecursiveIteratorIterator::LEAVES_ONLY,
				RecursiveIteratorIterator::CATCH_GET_CHILD
			);
		} catch ( Exception $e ) {
			continue;
		}

		foreach ( $iterator as $file ) {
			if ( $plugin_files >= $max_files_per_plugin ) {
				// Budget for THIS plugin only — move on to the next plugin
				// instead of killing the entire scan (the old bug).
				$incomplete[] = $plugin_name;
				break;
			}
			if ( ! $file->isFile() ) {
				continue;
			}
			$ext = strtolower( $file->getExtension() );
			if ( ! in_array( $ext, array( 'php', 'js' ), true ) ) {
				continue;
			}
			$path = $file->getPathname();
			if ( preg_match( '~/(node_modules|\.git)/~i', $path ) ) {
				continue;
			}
			if ( $file->getSize() > $max_bytes ) {
				continue;
			}

			$plugin_files++;
			$total_files++;
			$contents = @file_get_contents( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			if ( false === $contents || false === stripos( $contents, 'oast' ) ) {
				continue; // Cheap pre-filter: nothing here even mentions "Toast".
			}

			$rel_file = str_replace( trailingslashit( WP_PLUGIN_DIR ), '', $path );

			foreach ( $patterns as $key => $pattern ) {
				if ( ! preg_match( $pattern['regex'], $contents, $m, PREG_OFFSET_CAPTURE ) ) {
					continue;
				}
				$dedupe_key = $key . '|' . $rel_file;
				if ( isset( $seen[ $dedupe_key ] ) ) {
					continue;
				}
				$seen[ $dedupe_key ] = true;

				$offset = (int) $m[0][1];
				$line   = substr_count( substr( $contents, 0, $offset ), "\n" ) + 1;

				// Prefer a source declared near the match, then anywhere in the file.
				$source = '';
				$window = substr( $contents, max( 0, $offset - 600 ), 1200 );
				if ( preg_match( $source_regex, $window, $sm ) ) {
					$source = zymarg_os_normalize_toast_source( $sm[1] );
				} elseif ( preg_match( $source_regex, $contents, $sm ) ) {
					$source = zymarg_os_normalize_toast_source( $sm[1] );
				}

				// Evidence snippet: the matched line, trimmed.
				$line_start = strrpos( substr( $contents, 0, $offset ), "\n" );
				$line_start = ( false === $line_start ) ? 0 : $line_start + 1;
				$line_end   = strpos( $contents, "\n", $offset );
				$line_end   = ( false === $line_end ) ? strlen( $contents ) : $line_end;
				$snippet    = trim( substr( $contents, $line_start, $line_end - $line_start ) );
				if ( strlen( $snippet ) > 180 ) {
					$snippet = substr( $snippet, 0, 180 ) . '…';
				}

				$kind = isset( $pattern['kind'] ) ? $pattern['kind'] : 'theme';

				$matches_for_plugin[] = array(
					'label'   => $pattern['label'],
					'kind'    => $kind,
					'file'    => $rel_file,
					'line'    => $line,
					'snippet' => $snippet,
					'source'  => ( 'theme' === $kind ) ? $source : '',
				);
			}
		}

		if ( ! empty( $matches_for_plugin ) ) {
			$has_theme = false;
			$has_own   = false;
			foreach ( $matches_for_plugin as $mfp ) {
				if ( 'own' === $mfp['kind'] ) {
					$has_own = true;
				} else {
					$has_theme = true;
				}
			}

			$results[ $plugin_file ] = array(
				'name'          => $plugin_name,
				'active'        => is_plugin_active( $plugin_file ),
				'files_scanned' => $plugin_files,
				'has_theme'     => $has_theme,
				'has_own'       => $has_own,
				'matches'       => $matches_for_plugin,
			);
		}
	}

	update_option(
		ZYMARG_OS_TOAST_SCAN_OPTION,
		array(
			'time'            => time(),
			'results'         => $results,
			'files_scanned'   => $total_files,
			'plugins_checked' => $plugins_checked,
			'plugins_total'   => count( $all_plugins ),
			'incomplete'      => array_values( array_unique( $incomplete ) ),
			'only_plugin'     => $only_plugin,
		),
		false
	);

	// Pre-register any declared sources so they show in the Sources table
	// with a "not fired yet" state, even before the first real toast.
	$declared = array();
	foreach ( $results as $plugin ) {
		foreach ( $plugin['matches'] as $match ) {
			if ( ! empty( $match['source'] ) && 'theme' === $match['kind'] ) {
				$declared[] = $match['source'];
			}
		}
	}
	if ( $declared ) {
		$stats = get_option( ZYMARG_OS_TOAST_STATS_OPTION, array() );
		$stats = is_array( $stats ) ? $stats : array();
		foreach ( array_unique( $declared ) as $slug ) {
			if ( empty( $stats[ $slug ] ) || ! is_array( $stats[ $slug ] ) ) {
				$stats[ $slug ] = array(
					'shown'        => 0,
					'blocked'      => 0,
					'last_seen'    => 0,
					'last_message' => '',
				);
			}
		}
		update_option( ZYMARG_OS_TOAST_STATS_OPTION, $stats, false );
	}

	return $results;
}

/**
 * Handle the settings form: save the blocked-sources list, clear the log,
 * or run the plugin-code scan.
 *
 * @return void
 */
function zymarg_os_toast_admin_handle_post() {
	if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
		return;
	}
	if ( empty( $_POST['zymarg_toast_admin_action'] ) || ! isset( $_GET['page'] ) || 'zymarg-os-toast' !== $_GET['page'] ) {
		return;
	}
	check_admin_referer( 'zymarg_os_toast_admin' );

	$action = sanitize_key( wp_unslash( $_POST['zymarg_toast_admin_action'] ) );

	if ( 'save_sources' === $action ) {
		$blocked = array();

		if ( ! empty( $_POST['all_sources'] ) && is_array( $_POST['all_sources'] ) ) {
			/*
			 * Toggle form (v5.16.17+): a source is blocked when it was listed on
			 * the screen but its toggle came back OFF. Unchecked checkboxes are
			 * simply absent from the POST, so the hidden all_sources[] list is
			 * what tells us which rows were actually on screen.
			 */
			$enabled = array();
			if ( ! empty( $_POST['enabled_sources'] ) && is_array( $_POST['enabled_sources'] ) ) {
				foreach ( wp_unslash( $_POST['enabled_sources'] ) as $slug ) {
					$enabled[] = zymarg_os_normalize_toast_source( $slug );
				}
			}

			foreach ( wp_unslash( $_POST['all_sources'] ) as $slug ) {
				$slug = zymarg_os_normalize_toast_source( $slug );
				if ( '' !== $slug && ! in_array( $slug, $enabled, true ) ) {
					$blocked[] = $slug;
				}
			}
		} elseif ( ! empty( $_POST['blocked_sources'] ) && is_array( $_POST['blocked_sources'] ) ) {
			// Backward compatibility with the pre-toggle checkbox form.
			foreach ( wp_unslash( $_POST['blocked_sources'] ) as $slug ) {
				$blocked[] = zymarg_os_normalize_toast_source( $slug );
			}
		}

		update_option( ZYMARG_OS_TOAST_BLOCKED_OPTION, array_values( array_unique( $blocked ) ) );
		add_settings_error( 'zymarg_os_toast', 'saved', __( 'Toast source settings saved.', 'zymarg-os' ), 'success' );
	} elseif ( 'clear_log' === $action ) {
		delete_option( ZYMARG_OS_TOAST_LOG_OPTION );
		delete_option( ZYMARG_OS_TOAST_STATS_OPTION );
		add_settings_error( 'zymarg_os_toast', 'cleared', __( 'Toast activity log and counters cleared.', 'zymarg-os' ), 'success' );
	} elseif ( 'scan_plugins' === $action ) {
		$only  = isset( $_POST['scan_only_plugin'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['scan_only_plugin'] ) ) : '';
		$found = zymarg_os_scan_plugins_for_toast_usage( $only );
		if ( empty( $found ) ) {
			add_settings_error(
				'zymarg_os_toast',
				'scanned',
				'' !== $only
					? sprintf(
						/* translators: %s: plugin search term. */
						__( 'Scan complete: no toast-system code found in plugins matching “%s”. Check the folder/name spelling, or clear the box to scan everything.', 'zymarg-os' ),
						$only
					)
					: __( 'Scan complete: no plugin code referencing the toast system was found.', 'zymarg-os' ),
				'info'
			);
		} else {
			add_settings_error(
				'zymarg_os_toast',
				'scanned',
				sprintf(
					/* translators: %d: number of plugins found using the toast system. */
					_n( 'Scan complete: %d plugin already uses the toast system.', 'Scan complete: %d plugins already use the toast system.', count( $found ), 'zymarg-os' ),
					count( $found )
				),
				'success'
			);
		}
	}
}
add_action( 'admin_init', 'zymarg_os_toast_admin_handle_post' );

/**
 * Sources the theme itself knows about, so the Sources table always has rows
 * to toggle instead of sitting empty until something happens to fire.
 *
 * Before this existed, a source only appeared after it had already fired a
 * toast (writing to the stats option) or after a code scan found a declared
 * `source:` literal — which meant a brand new site showed an empty table and
 * no toggles at all.
 *
 * @return array Lowercase source slugs.
 */
function zymarg_os_get_known_toast_sources() {
	$known = array(
		'woocommerce',
		'zymarg-reviews',
		'zymarg-login',
		'zymarg-product-grid',
		'zymarg-single-product',
		'zymarg-communication',
		'theme',
		'unknown',
	);

	/**
	 * Filter the always-listed toast sources.
	 *
	 * @param array $known Lowercase source slugs.
	 */
	$known = (array) apply_filters( 'zymarg_os_known_toast_sources', $known );

	return array_values( array_unique( array_filter( array_map( 'zymarg_os_normalize_toast_source', $known ) ) ) );
}

/**
 * Render the Toast Notification admin screen.
 *
 * @return void
 */
function zymarg_os_render_toast_admin_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Sorry, you are not allowed to view this.', 'zymarg-os' ) );
	}

	settings_errors( 'zymarg_os_toast' );

	$stats   = get_option( ZYMARG_OS_TOAST_STATS_OPTION, array() );
	$stats   = is_array( $stats ) ? $stats : array();
	$blocked = zymarg_os_get_blocked_toast_sources();
	$log     = get_option( ZYMARG_OS_TOAST_LOG_OPTION, array() );
	$log     = is_array( $log ) ? array_reverse( $log ) : array();

	$scan            = get_option( ZYMARG_OS_TOAST_SCAN_OPTION, array() );
	$scan_results    = ( is_array( $scan ) && ! empty( $scan['results'] ) ) ? $scan['results'] : array();
	$scan_time       = ( is_array( $scan ) && ! empty( $scan['time'] ) ) ? (int) $scan['time'] : 0;
	$scan_files      = ( is_array( $scan ) && isset( $scan['files_scanned'] ) ) ? (int) $scan['files_scanned'] : 0;
	$scan_checked    = ( is_array( $scan ) && isset( $scan['plugins_checked'] ) ) ? (int) $scan['plugins_checked'] : 0;
	$scan_total      = ( is_array( $scan ) && isset( $scan['plugins_total'] ) ) ? (int) $scan['plugins_total'] : 0;
	$scan_incomplete = ( is_array( $scan ) && ! empty( $scan['incomplete'] ) ) ? (array) $scan['incomplete'] : array();
	$scan_only       = ( is_array( $scan ) && ! empty( $scan['only_plugin'] ) ) ? (string) $scan['only_plugin'] : '';

	// Union of "sources we've actually seen", "sources currently blocked", and
	// "sources declared in plugin code by the last scan" (so a plugin shows up
	// even before it has ever fired a real toast).
	$known_sources = array_unique(
		array_merge(
			array_keys( $stats ),
			$blocked,
			zymarg_os_get_known_toast_sources()
		)
	);
	sort( $known_sources );

	?>
	<div class="wrap zymarg-admin zymarg-welcome ztoast">
		<h1>
			<?php if ( function_exists( 'zymarg_discovery_spark' ) ) { echo zymarg_discovery_spark( array( 'size' => 'lg' ) ); } // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<?php esc_html_e( 'Toast Notification', 'zymarg-os' ); ?>
			<span class="zymarg-welcome__v">v<?php echo esc_html( defined( 'ZYMARG_OS_VERSION' ) ? ZYMARG_OS_VERSION : '1.0.0' ); ?></span>
		</h1>
		<p class="zymarg-welcome__intro">
			<?php esc_html_e( 'Your theme owns the one toast system every plugin shares. This screen shows exactly which plugin or feature fired each toast, scans your plugins for toast usage before anything even fires, and lets you switch any of them off without editing plugin code.', 'zymarg-os' ); ?>
		</p>

		<style>
			.ztoast-grid { display: grid; grid-template-columns: minmax(320px, 1fr) minmax(360px, 1.3fr); gap: 20px; align-items: start; margin-top: 16px; }
			@media (max-width: 1100px) { .ztoast-grid { grid-template-columns: 1fr; } }
			.ztoast-card { background: #fff; border: 1px solid #dcdcde; border-radius: 8px; padding: 16px 18px; }
			.ztoast-card--full { grid-column: 1 / -1; }
			.ztoast-card h2 { margin-top: 0; font-size: 15px; }
			.ztoast-table { width: 100%; border-collapse: collapse; font-size: 13px; }
			.ztoast-table th, .ztoast-table td { padding: 8px 6px; border-bottom: 1px solid #f0f0f1; text-align: left; vertical-align: top; }
			.ztoast-source { font-weight: 600; }
			.ztoast-pill { display: inline-block; padding: 2px 8px; border-radius: 10px; font-size: 11px; font-weight: 600; }
			.ztoast-pill--on { background: #edfaef; color: #1ea860; }
			.ztoast-pill--off { background: #fdeeee; color: #c0341d; }
			.ztoast-pill--neutral { background: #eef1f5; color: #50575e; }
			.ztoast-pill--type-success { background: #edfaef; color: #1ea860; }
			.ztoast-pill--type-error { background: #fdeeee; color: #c0341d; }
			.ztoast-pill--type-warning { background: #fff8e6; color: #9a6400; }
			.ztoast-pill--type-info { background: #eef4ff; color: #2457c5; }
			.ztoast-empty { color: #757575; font-style: italic; }
			.ztoast-log-wrap { max-height: 480px; overflow-y: auto; }
			.ztoast-scan-file { display: block; font-size: 12px; color: #757575; }
			.ztoast-scan-snippet { display: block; margin-top: 3px; font-size: 11px; background: #f6f7f7; padding: 4px 6px; border-radius: 4px; white-space: pre-wrap; word-break: break-word; }

			/* Real on/off toggle switch for each toast source. */
			.ztoast-switch { display: inline-flex; align-items: center; cursor: pointer; }
			.ztoast-switch input { position: absolute; opacity: 0; width: 1px; height: 1px; }
			.ztoast-switch__track {
				position: relative; display: block; width: 40px; height: 22px;
				background: #c3c4c7; border-radius: 999px; transition: background .18s ease;
			}
			.ztoast-switch__dot {
				position: absolute; top: 3px; left: 3px; width: 16px; height: 16px;
				background: #fff; border-radius: 50%; transition: transform .18s ease;
				box-shadow: 0 1px 2px rgba(0,0,0,.25);
			}
			.ztoast-switch input:checked + .ztoast-switch__track { background: #00a32a; }
			.ztoast-switch input:checked + .ztoast-switch__track .ztoast-switch__dot { transform: translateX(18px); }
			.ztoast-switch input:focus-visible + .ztoast-switch__track { outline: 2px solid #2271b1; outline-offset: 2px; }
		</style>

		<div class="ztoast-grid">

			<!-- Static code scan: know who uses it before anything ever fires -->
			<section class="ztoast-card ztoast-card--full">
				<h2><?php esc_html_e( 'Plugins already wired to this toast system (no trigger required)', 'zymarg-os' ); ?></h2>
				<p class="description">
					<?php esc_html_e( 'The activity log below only fills in after a toast actually fires. Use this scan instead to see, right now, which installed plugins already contain code that calls the toast system — by reading their files directly.', 'zymarg-os' ); ?>
				</p>

				<form method="post">
					<?php wp_nonce_field( 'zymarg_os_toast_admin' ); ?>
					<input type="hidden" name="zymarg_toast_admin_action" value="scan_plugins" />
					<p>
						<label for="scan_only_plugin"><strong><?php esc_html_e( 'Check one specific plugin (optional)', 'zymarg-os' ); ?></strong></label><br />
						<input type="text" id="scan_only_plugin" name="scan_only_plugin" class="regular-text" value="<?php echo esc_attr( $scan_only ); ?>" placeholder="<?php esc_attr_e( 'e.g. zymarg-communication', 'zymarg-os' ); ?>" />
						<span class="description"><?php esc_html_e( 'Type part of a plugin folder or name to scan just that one (faster). Leave empty to scan every installed plugin.', 'zymarg-os' ); ?></span>
					</p>
					<?php submit_button( __( 'Scan Installed Plugins Now', 'zymarg-os' ), 'primary', 'submit', false ); ?>
					<?php if ( $scan_time ) : ?>
						<span class="description" style="margin-left:10px;">
							<?php
							printf(
								/* translators: 1: human time diff, 2: file count, 3: plugins scanned, 4: plugins installed. */
								esc_html__( 'Last scanned %1$s ago — read %2$s files across %3$s of %4$s installed plugins.', 'zymarg-os' ),
								esc_html( human_time_diff( $scan_time ) ),
								esc_html( number_format_i18n( $scan_files ) ),
								esc_html( number_format_i18n( $scan_checked ) ),
								esc_html( number_format_i18n( $scan_total ) )
							);
							?>
						</span>
					<?php endif; ?>
				</form>

				<?php if ( ! empty( $scan_incomplete ) ) : ?>
					<div class="notice notice-warning inline" style="margin:12px 0;">
						<p>
							<?php
							printf(
								/* translators: %s: comma-separated plugin names. */
								esc_html__( 'These plugins are very large and were only partially scanned: %s. Use the box above to scan one of them on its own for a complete result.', 'zymarg-os' ),
								esc_html( implode( ', ', $scan_incomplete ) )
							);
							?>
						</p>
					</div>
				<?php endif; ?>

				<?php if ( ! $scan_time ) : ?>
					<p class="ztoast-empty" style="margin-top:12px;"><?php esc_html_e( 'Not scanned yet. Click the button above — it reads your plugin files directly, so it works even if no toast has ever shown.', 'zymarg-os' ); ?></p>
				<?php elseif ( empty( $scan_results ) ) : ?>
					<p class="ztoast-empty" style="margin-top:12px;"><?php esc_html_e( 'No toast code found — neither theme-toast calls nor any plugin-owned toast system.', 'zymarg-os' ); ?></p>
				<?php else : ?>
					<table class="ztoast-table" style="margin-top:12px;">
						<thead>
							<tr>
								<th><?php esc_html_e( 'Plugin', 'zymarg-os' ); ?></th>
								<th><?php esc_html_e( 'Status', 'zymarg-os' ); ?></th>
								<th><?php esc_html_e( 'Wiring', 'zymarg-os' ); ?></th>
								<th><?php esc_html_e( 'Declared source(s)', 'zymarg-os' ); ?></th>
								<th><?php esc_html_e( 'Evidence found in its files', 'zymarg-os' ); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ( $scan_results as $plugin ) : ?>
								<?php
								$sources = array_unique( array_filter( wp_list_pluck( $plugin['matches'], 'source' ) ) );
								?>
								<tr>
									<td><strong><?php echo esc_html( $plugin['name'] ); ?></strong></td>
									<td>
										<span class="ztoast-pill <?php echo $plugin['active'] ? 'ztoast-pill--on' : 'ztoast-pill--neutral'; ?>">
											<?php echo $plugin['active'] ? esc_html__( 'Active', 'zymarg-os' ) : esc_html__( 'Inactive', 'zymarg-os' ); ?>
										</span>
									</td>
									<td>
										<?php if ( ! empty( $plugin['has_theme'] ) ) : ?>
											<span class="ztoast-pill ztoast-pill--on"><?php esc_html_e( 'Uses theme toast', 'zymarg-os' ); ?></span><br />
											<span class="ztoast-scan-file"><?php esc_html_e( 'Controllable below', 'zymarg-os' ); ?></span>
										<?php endif; ?>
										<?php if ( ! empty( $plugin['has_own'] ) ) : ?>
											<span class="ztoast-pill ztoast-pill--type-warning"><?php esc_html_e( 'Own toast system', 'zymarg-os' ); ?></span><br />
											<span class="ztoast-scan-file"><?php esc_html_e( 'NOT controllable here', 'zymarg-os' ); ?></span>
										<?php endif; ?>
									</td>
									<td>
										<?php if ( $sources ) : ?>
											<?php foreach ( $sources as $s ) : ?>
												<span class="ztoast-source"><?php echo esc_html( $s ); ?></span><br />
											<?php endforeach; ?>
										<?php else : ?>
											<span class="ztoast-empty"><?php esc_html_e( 'not declared — will log as “unknown”', 'zymarg-os' ); ?></span>
										<?php endif; ?>
									</td>
									<td>
										<?php foreach ( $plugin['matches'] as $match ) : ?>
											<div style="margin-bottom:8px;">
												<?php echo esc_html( $match['label'] ); ?>
												<span class="ztoast-scan-file">
													<?php echo esc_html( $match['file'] ); ?><?php echo ! empty( $match['line'] ) ? esc_html( ':' . $match['line'] ) : ''; ?>
												</span>
												<?php if ( ! empty( $match['snippet'] ) ) : ?>
													<code class="ztoast-scan-snippet"><?php echo esc_html( $match['snippet'] ); ?></code>
												<?php endif; ?>
											</div>
										<?php endforeach; ?>
									</td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
					<p class="description" style="margin-top:8px;"><?php esc_html_e( 'Any source found here has already been added to the Sources table below (marked “not fired yet”) so you can switch it off in advance if you want.', 'zymarg-os' ); ?></p>
				<?php endif; ?>
			</section>

			<!-- Sources: who's using it + on/off control -->
			<section class="ztoast-card">
				<h2><?php esc_html_e( 'Sources using this toast system', 'zymarg-os' ); ?></h2>
				<p class="description"><?php esc_html_e( 'Every plugin/feature wired to the toast system reports a “source” name. Untick a source and it stops showing toasts immediately — no code changes needed.', 'zymarg-os' ); ?></p>

				<form method="post">
					<?php wp_nonce_field( 'zymarg_os_toast_admin' ); ?>
					<input type="hidden" name="zymarg_toast_admin_action" value="save_sources" />

					<?php if ( empty( $known_sources ) ) : ?>
						<p class="ztoast-empty"><?php esc_html_e( 'Nothing here yet. Run the scan above, or trigger a toast on the front end (e.g. add a product to cart), and sources will appear here.', 'zymarg-os' ); ?></p>
					<?php else : ?>
						<table class="ztoast-table">
							<thead>
								<tr>
									<th><?php esc_html_e( 'Enabled', 'zymarg-os' ); ?></th>
									<th><?php esc_html_e( 'Source', 'zymarg-os' ); ?></th>
									<th><?php esc_html_e( 'Shown', 'zymarg-os' ); ?></th>
									<th><?php esc_html_e( 'Blocked', 'zymarg-os' ); ?></th>
									<th><?php esc_html_e( 'Last seen', 'zymarg-os' ); ?></th>
									<th><?php esc_html_e( 'Last message', 'zymarg-os' ); ?></th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ( $known_sources as $source ) : ?>
									<?php
									$row          = isset( $stats[ $source ] ) ? $stats[ $source ] : array();
									$is_on        = ! in_array( $source, $blocked, true );
									$has_fired    = ! empty( $row['last_seen'] );
									$last_seen    = $has_fired ? human_time_diff( (int) $row['last_seen'] ) . ' ' . __( 'ago', 'zymarg-os' ) : '—';
									$last_message = $has_fired ? ( isset( $row['last_message'] ) ? $row['last_message'] : '' ) : __( 'Not fired yet (found by code scan)', 'zymarg-os' );
									?>
									<tr>
										<td>
											<input type="hidden" name="all_sources[]" value="<?php echo esc_attr( $source ); ?>" />
											<label class="ztoast-switch" for="src-<?php echo esc_attr( $source ); ?>">
												<input
													type="checkbox"
													id="src-<?php echo esc_attr( $source ); ?>"
													name="enabled_sources[]"
													value="<?php echo esc_attr( $source ); ?>"
													<?php checked( $is_on ); ?>
												/>
												<span class="ztoast-switch__track" aria-hidden="true"><span class="ztoast-switch__dot"></span></span>
												<span class="screen-reader-text">
													<?php
													printf(
														/* translators: %s: toast source slug. */
														esc_html__( 'Show toasts from %s', 'zymarg-os' ),
														esc_html( $source )
													);
													?>
												</span>
											</label>
										</td>
										<td>
											<span class="ztoast-source"><?php echo esc_html( $source ); ?></span><br />
											<span class="ztoast-pill <?php echo $is_on ? 'ztoast-pill--on' : 'ztoast-pill--off'; ?>">
												<?php echo $is_on ? esc_html__( 'Enabled', 'zymarg-os' ) : esc_html__( 'Disabled', 'zymarg-os' ); ?>
											</span>
											<?php if ( ! $has_fired ) : ?>
												<span class="ztoast-pill ztoast-pill--neutral"><?php esc_html_e( 'Not fired yet', 'zymarg-os' ); ?></span>
											<?php endif; ?>
										</td>
										<td><?php echo esc_html( isset( $row['shown'] ) ? $row['shown'] : 0 ); ?></td>
										<td><?php echo esc_html( isset( $row['blocked'] ) ? $row['blocked'] : 0 ); ?></td>
										<td><?php echo esc_html( $last_seen ); ?></td>
										<td><?php echo esc_html( $last_message ); ?></td>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
						<p><em class="description"><?php esc_html_e( 'Toggle ON = that source may show toasts. Toggle OFF = its toasts are suppressed instantly. Remember to Save.', 'zymarg-os' ); ?></em></p>
						<?php submit_button( __( 'Save Toast Sources', 'zymarg-os' ) ); ?>
					<?php endif; ?>
				</form>

				<hr />
				<h2><?php esc_html_e( 'Not showing up yet?', 'zymarg-os' ); ?></h2>
				<p class="description">
					<?php esc_html_e( 'Run the scan above first. If a plugin still does not appear, it may call the toast system in a way the scanner cannot see (e.g. built/minified JS), or it may not be wired in yet. Tell any plugin developer (or your own custom code) to tag their call with a source, for example:', 'zymarg-os' ); ?>
				</p>
				<pre style="background:#f6f7f7;padding:10px 12px;border-radius:6px;overflow:auto;">window.ZymargToast.success('Saved!', { source: 'my-plugin-slug' } );

// or, fully decoupled:
document.dispatchEvent( new CustomEvent( 'zymarg:toast', {
	detail: { message: 'Saved!', type: 'success', source: 'my-plugin-slug' }
} ) );

// Server-side (PHP), for the next page load:
zymarg_os_queue_toast( 'Saved!', 'success', '', 'my-plugin-slug' );</pre>
				<p class="description"><?php esc_html_e( 'Calls without a source are logged as “unknown” so you can still spot them.', 'zymarg-os' ); ?></p>
			</section>

			<!-- Activity log -->
			<section class="ztoast-card">
				<h2><?php esc_html_e( 'Recent activity', 'zymarg-os' ); ?></h2>
				<p class="description"><?php esc_html_e( 'The last 200 toasts fired site-wide (shown or blocked), newest first. This fills in only once toasts actually happen — use the scan above for advance visibility.', 'zymarg-os' ); ?></p>

				<?php if ( empty( $log ) ) : ?>
					<p class="ztoast-empty"><?php esc_html_e( 'Nothing logged yet.', 'zymarg-os' ); ?></p>
				<?php else : ?>
					<div class="ztoast-log-wrap">
						<table class="ztoast-table">
							<thead>
								<tr>
									<th><?php esc_html_e( 'When', 'zymarg-os' ); ?></th>
									<th><?php esc_html_e( 'Source', 'zymarg-os' ); ?></th>
									<th><?php esc_html_e( 'Type', 'zymarg-os' ); ?></th>
									<th><?php esc_html_e( 'Message', 'zymarg-os' ); ?></th>
									<th><?php esc_html_e( 'Status', 'zymarg-os' ); ?></th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ( array_slice( $log, 0, 200 ) as $entry ) : ?>
									<tr>
										<td><?php echo esc_html( ! empty( $entry['time'] ) ? human_time_diff( (int) $entry['time'] ) . ' ' . __( 'ago', 'zymarg-os' ) : '—' ); ?></td>
										<td class="ztoast-source"><?php echo esc_html( isset( $entry['source'] ) ? $entry['source'] : 'unknown' ); ?></td>
										<td><span class="ztoast-pill ztoast-pill--type-<?php echo esc_attr( isset( $entry['type'] ) ? $entry['type'] : 'info' ); ?>"><?php echo esc_html( isset( $entry['type'] ) ? $entry['type'] : 'info' ); ?></span></td>
										<td><?php echo esc_html( trim( ( isset( $entry['title'] ) ? $entry['title'] : '' ) . ' ' . ( isset( $entry['message'] ) ? $entry['message'] : '' ) ) ); ?></td>
										<td>
											<?php if ( ! empty( $entry['blocked'] ) ) : ?>
												<span class="ztoast-pill ztoast-pill--off"><?php esc_html_e( 'Blocked', 'zymarg-os' ); ?></span>
											<?php else : ?>
												<span class="ztoast-pill ztoast-pill--on"><?php esc_html_e( 'Shown', 'zymarg-os' ); ?></span>
											<?php endif; ?>
										</td>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					</div>
				<?php endif; ?>

				<form method="post" onsubmit="return confirm('<?php echo esc_js( __( 'Clear the activity log and counters? This cannot be undone.', 'zymarg-os' ) ); ?>');" style="margin-top:12px;">
					<?php wp_nonce_field( 'zymarg_os_toast_admin' ); ?>
					<input type="hidden" name="zymarg_toast_admin_action" value="clear_log" />
					<?php submit_button( __( 'Clear Log &amp; Counters', 'zymarg-os' ), 'delete', 'submit', false ); ?>
				</form>
			</section>

		</div>
	</div>
	<?php
}
