<?php
/**
 * Front-end asset enqueue.
 *
 * Loads the modular CSS architecture in cascade order:
 *   tokens -> animations -> base -> helpers -> ui -> components -> layouts
 *   -> icons -> (conditional) woocommerce
 *
 * Everything depends on the `zymarg-os-token-colors` handle (the first design
 * token file) so the cascade and Customizer overrides resolve correctly.
 * WooCommerce styles load only on shop/Dokan contexts; navigation styles load
 * with the Mega Menu module.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Helper: register + enqueue a list of stylesheets that all depend on a common
 * set of handles.
 *
 * @param array $sheets Map of handle-suffix => relative path.
 * @param array $deps   Shared dependencies for every sheet.
 * @return void
 */
function zymarg_os_enqueue_styles( array $sheets, array $deps = array() ) {
	foreach ( $sheets as $handle => $path ) {
		wp_enqueue_style(
			'zymarg-os-' . $handle,
			ZYMARG_OS_URI . '/' . ltrim( $path, '/' ),
			$deps,
			ZYMARG_OS_VERSION
		);
	}
}

/**
 * Enqueue styles and scripts.
 *
 * @return void
 */
function zymarg_os_enqueue_assets() {
	$ver = ZYMARG_OS_VERSION;

	/* ---- 1. Tokens: colors first (the root for everything else) ------- */
	wp_enqueue_style( 'zymarg-os-token-colors', ZYMARG_OS_URI . '/tokens/colors.css', array(), $ver );
	$base = array( 'zymarg-os-token-colors' );

	/*
	 * Shared ZYMARG brand tokens (--zym-*).
	 *
	 * Per ZYMARG DESIGN TOKENS v3 ("THE SHARED FILES"), this file is enqueued
	 * with the handle `zymarg-tokens` in every ZYMARG plugin AND here, and
	 * WordPress deduplicates by handle so only one copy ever loads. The handle
	 * must be spelled exactly like this — a mismatch means two copies load and
	 * the later one silently wins for every plugin on the page.
	 *
	 * Version is the TOKEN file's own version, not the theme version: the token
	 * file is versioned independently and only bumped when a token changes.
	 */
	if ( ! wp_style_is( 'zymarg-tokens', 'registered' ) ) {
		wp_register_style( 'zymarg-tokens', ZYMARG_OS_URI . '/tokens/zymarg-tokens.css', array(), ZYMARG_OS_TOKENS_VERSION );
	}
	wp_enqueue_style( 'zymarg-tokens' );

	zymarg_os_enqueue_styles(
		array(
			'token-typography'  => 'tokens/typography.css',
			'token-spacing'     => 'tokens/spacing.css',
			'token-radius'      => 'tokens/radius.css',
			'token-shadows'     => 'tokens/shadows.css',
			'token-opacity'     => 'tokens/opacity.css',
			'token-transitions' => 'tokens/transitions.css',
			'token-zindex'      => 'tokens/z-index.css',
		),
		$base
	);

	// Dark-scheme overrides (applied via the <html> data-theme attribute).
	zymarg_os_enqueue_styles( array( 'token-dark' => 'tokens/dark.css' ), $base );

	/* ---- 2. Animations (keyframes used by ui/loading, toast, tabs) ---- */
	zymarg_os_enqueue_styles( array( 'animations' => 'assets/animations/animations.css' ), $base );

	/* ---- 3. Base: reset + element typography -------------------------- */
	zymarg_os_enqueue_styles( array( 'base-typography' => 'base/typography.css' ), $base );

	/* ---- 4. Helpers (utility classes) --------------------------------- */
	zymarg_os_enqueue_styles(
		array(
			'helper-colors'     => 'helpers/colors.css',
			'helper-spacing'    => 'helpers/spacing.css',
			'helper-grid'       => 'helpers/grid.css',
			'helper-flex'       => 'helpers/flex.css',
			'helper-visibility' => 'helpers/visibility.css',
		),
		$base
	);

	/* ---- 5. UI primitives --------------------------------------------- */
	zymarg_os_enqueue_styles(
		array(
			'ui-modal'    => 'ui/modal.css',
			'ui-drawer'   => 'ui/drawer.css',
			'ui-tooltip'  => 'ui/tooltip.css',
			'ui-dropdown' => 'ui/dropdown.css',
			'ui-tabs'     => 'ui/tabs.css',
			'ui-loading'  => 'ui/loading.css',
		),
		$base
	);

	/* ---- 6. Components ------------------------------------------------- */
	zymarg_os_enqueue_styles(
		array(
			'component-buttons' => 'components/buttons.css',
			'component-cards'   => 'components/cards.css',
			'component-forms'   => 'components/forms.css',
			'component-badges'  => 'components/badges.css',
			'component-grid-skin' => 'components/grid-skin.css',
			'component-breadcrumbs' => 'components/breadcrumbs.css',
			'component-results' => 'components/results.css',
			'component-account-icon' => 'components/account-icon.css',
			'component-header-overflow-fix' => 'components/header-overflow-fix.css',
		),
		$base
	);

	// Navigation + mega menu only when that module is on.
	if ( zymarg_os_module_enabled( 'mega_menu' ) ) {
		zymarg_os_enqueue_styles( array( 'component-navigation' => 'components/navigation.css' ), $base );
	}

	/* ---- 7. Layouts --------------------------------------------------- */
	zymarg_os_enqueue_styles(
		array(
			'layout-container'       => 'layouts/container.css',
			'layout-section'         => 'layouts/section.css',
			'layout-responsive'      => 'layouts/responsive.css',
			'layout-bottom-nav-compat' => 'layouts/bottom-nav-compat.css',
		),
		$base
	);

	/* ---- 8. Icons ----------------------------------------------------- */
	zymarg_os_enqueue_styles( array( 'icons' => 'assets/icons/icons.css' ), $base );

	/* ---- 9. Theme stylesheet header (mostly metadata) ----------------- */
	wp_enqueue_style( 'zymarg-os-style', get_stylesheet_uri(), $base, $ver );

	/*
	 * WooCommerce notices (brand skin).
	 *
	 * Loaded whenever WooCommerce is active — NOT gated on zymarg_os_is_woo_context()
	 * — because wc_add_notice() output can surface outside shop templates too
	 * (login, password reset, any page holding a Woo form). Without this sheet the
	 * "saved" / "error" messages fall back to WooCommerce's stock grey boxes while
	 * the rest of the page is branded.
	 */
	if ( zymarg_os_module_enabled( 'woocommerce' ) && class_exists( 'WooCommerce' ) ) {
		wp_enqueue_style(
			'zymarg-os-woo-notices',
			ZYMARG_OS_URI . '/woocommerce/notices.css',
			array_merge( $base, array( 'zymarg-tokens' ) ),
			$ver
		);
	}

	/* ---- 10. WooCommerce (only on shop/Dokan contexts) ---------------- */
	if ( zymarg_os_module_enabled( 'woocommerce' ) && class_exists( 'WooCommerce' ) && zymarg_os_is_woo_context() ) {
		$woo_sheets = array(
			'woo-product'  => 'woocommerce/product.css',
			'woo-dokan'    => 'woocommerce/dokan.css',
			'woo-account'  => 'woocommerce/account.css',
		);

		// Cart styling — only when the theme_cart_styling module is ON.
		if ( zymarg_os_module_enabled( 'theme_cart_styling' ) ) {
			$woo_sheets['woo-cart'] = 'woocommerce/cart.css';
		}

		// Checkout styling — only when the theme_checkout_styling module is ON.
		if ( zymarg_os_module_enabled( 'theme_checkout_styling' ) ) {
			$woo_sheets['woo-checkout'] = 'woocommerce/checkout.css';
		}

		zymarg_os_enqueue_styles( $woo_sheets, $base );

		// Checkout anti-shift: reveal form after WC's first update_checkout completes.
		if ( zymarg_os_module_enabled( 'theme_checkout_styling' ) && function_exists( 'is_checkout' ) && is_checkout() ) {
			wp_add_inline_script(
				'wc-checkout',
				'(function(){var b=document.body;if(!b.classList.contains("woocommerce-checkout"))return;var d=false;function reveal(){if(!d){d=true;b.classList.add("zymarg-checkout-ready");}}jQuery(b).on("updated_checkout",reveal);setTimeout(reveal,3000);}());'
			);
		}

		// Enhanced single product page (sticky gallery, swatches, stepper, badges).
		if ( function_exists( 'is_product' ) && is_product()
			&& ( ! function_exists( 'zymarg_os_enhanced_pdp_enabled' ) || zymarg_os_enhanced_pdp_enabled() ) ) {

			zymarg_os_enqueue_styles( array( 'woo-single' => 'woocommerce/single-product.css' ), $base );

			wp_enqueue_script(
				'zymarg-os-single-product',
				ZYMARG_OS_URI . '/assets/js/single-product.js',
				array( 'jquery' ),
				$ver,
				true
			);
		}
	}

	/* ---- 11. Interactive JS (only when a feature needs it) ------------ */

	/* My Account page JS (tab switching, modals, recently-viewed tracker). */
	if ( zymarg_os_module_enabled( 'woocommerce' ) && class_exists( 'WooCommerce' ) && function_exists( 'is_account_page' ) && is_account_page() && is_user_logged_in() ) {
		// NOTE: the Discovery Spark stylesheet is deliberately NOT enqueued on
		// My Account. It was only ever here to paint the SPA loading mark, and
		// that mark has been removed, so loading it would ship an animation
		// stylesheet for markup that no longer exists.
		wp_enqueue_script(
			'zymarg-os-account',
			ZYMARG_OS_URI . '/assets/js/account.js',
			array(),
			$ver,
			true
		);
		// Turns every account save / update button into an AJAX submit.
		// Depends on account.js because it drives that file's SPA swap + cache.
		wp_enqueue_script(
			'zymarg-os-account-forms',
			ZYMARG_OS_URI . '/assets/js/account-forms.js',
			array( 'zymarg-os-account' ),
			$ver,
			true
		);
		wp_localize_script(
			'zymarg-os-account',
			'ZymargAccount',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'zymarg_save_pref' ),
				'sectionNonce' => wp_create_nonce( 'zymarg_load_section' ),
				'formNonce'    => wp_create_nonce( 'zymarg_acc_form' ),
				'savingText'   => esc_html__( 'Saving…', 'zymarg-os' ),
				'errorText'    => esc_html__( 'Could not save. Please try again.', 'zymarg-os' ),
				// Screen-reader-only text for the section loading state. There is
				// no visible mark or animation by design. NOTE: 'spark' is gone on
				// purpose — do not reintroduce it. An older cached account.js that
				// still reads it simply gets undefined and renders nothing, which
				// is the safe failure mode.
				'loadingText'  => esc_html__( 'Loading…', 'zymarg-os' ),
			)
		);
	}

	if ( zymarg_os_needs_script() ) {
		wp_enqueue_script(
			'zymarg-os-theme',
			ZYMARG_OS_URI . '/assets/js/theme.js',
			array(),
			$ver,
			true
		);

		wp_localize_script(
			'zymarg-os-theme',
			'ZymargOS',
			array(
				'scrollTopOffset' => (int) apply_filters( 'zymarg_os_scroll_top_offset', 400 ),
				'ajaxUrl'         => admin_url( 'admin-ajax.php' ),
				'loadingText'     => esc_html__( 'Loading…', 'zymarg-os' ),
				'errorText'       => esc_html__( 'Unable to load product.', 'zymarg-os' ),
			)
		);
	}
}
add_action( 'wp_enqueue_scripts', 'zymarg_os_enqueue_assets', 10 );

/**
 * Whether the current request is a WooCommerce / Dokan context where the shop
 * stylesheets should load.
 *
 * @return bool
 */
function zymarg_os_is_woo_context() {
	if ( ! class_exists( 'WooCommerce' ) ) {
		return false;
	}

	$is_woo = is_woocommerce() || is_cart() || is_checkout() || is_account_page();

	// Dokan store / dashboard pages.
	if ( ! $is_woo && function_exists( 'dokan_is_store_page' ) ) {
		$is_woo = dokan_is_store_page() || ( function_exists( 'dokan_is_seller_dashboard' ) && dokan_is_seller_dashboard() );
	}

	// A page that embeds the [woocommerce_my_account] shortcode but isn't the
	// WooCommerce-assigned account page — still load the account styles so it
	// doesn't render unstyled (the common "My Account looks broken" cause).
	if ( ! $is_woo && is_singular() ) {
		$post = get_post();
		if ( $post instanceof WP_Post && has_shortcode( (string) $post->post_content, 'woocommerce_my_account' ) ) {
			$is_woo = true;
		}
	}

	return (bool) apply_filters( 'zymarg_os_is_woo_context', $is_woo );
}

/**
 * Whether the front-end script bundle is needed for this request.
 *
 * @return bool
 */
function zymarg_os_needs_script() {
	$needed = zymarg_os_module_enabled( 'scroll_to_top' ) || zymarg_os_module_enabled( 'mega_menu' );

	if ( ! $needed && zymarg_os_module_enabled( 'woocommerce' ) && class_exists( 'WooCommerce' ) ) {
		$needed = zymarg_os_is_woo_context();
	}

	return (bool) apply_filters( 'zymarg_os_needs_script', $needed );
}
