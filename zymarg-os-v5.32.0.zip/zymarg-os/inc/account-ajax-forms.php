<?php
/**
 * ZYMARG Account — AJAX form layer.
 *
 * WHY THIS FILE EXISTS
 *
 * The My Account screen is a small SPA: assets/js/account.js swaps sections
 * in over AJAX so moving around the dashboard never blinks. Every *write*
 * on that screen, however, was still a classic PHP round trip — each card
 * posted to `template_redirect`, the handler saved, called
 * `wp_safe_redirect()` and the browser threw the whole page away and rebuilt
 * it. So navigation felt instant and saving felt like 2009: white flash,
 * lost scroll position, every accordion card slammed shut, and the sidebar,
 * header and prefetch cache all rebuilt for the sake of one changed field.
 *
 * This file makes those writes AJAX **without forking the handlers**. The
 * existing `template_redirect` handlers stay exactly as they are and remain
 * the single source of truth for validation, throttling, nonces, security
 * logging and Woo/Dokan hooks. We simply call them from `admin-ajax.php`
 * with the submitted fields staged into the superglobals they already read,
 * catch the redirect they would have performed, and answer with freshly
 * rendered section HTML plus the notices as toast payloads.
 *
 * Consequences worth knowing:
 *   - No handler is duplicated, so AJAX and no-JS submits can never drift.
 *   - JavaScript off, or any transport error, falls back to the native form
 *     POST and the old flow still works. Progressive enhancement, not a
 *     hard dependency.
 *   - `zymarg_os_acc_redirect()` replaces `wp_safe_redirect(); exit;` inside
 *     the handlers. On a normal request it behaves identically; during an
 *     AJAX submit it unwinds via exception so we can keep rendering.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Control-flow signal standing in for the `exit` a redirect used to perform.
 *
 * An exception is the only way to abandon a handler mid-function without
 * editing its internals: handlers redirect from inside nested conditionals,
 * and a return value would have to be checked at every one of those sites.
 */
if ( ! class_exists( 'Zymarg_OS_Account_Redirect' ) ) {
	/**
	 * Thrown in place of a redirect while handling an AJAX account submit.
	 */
	class Zymarg_OS_Account_Redirect extends Exception {

		/**
		 * Where the handler wanted to send the browser.
		 *
		 * @var string
		 */
		public $url = '';

		/**
		 * Constructor.
		 *
		 * @param string $url Redirect target.
		 */
		public function __construct( $url ) {
			$this->url = (string) $url;
			parent::__construct( 'zymarg_account_redirect' );
		}
	}
}

/* ======================================================================
   1. CONTEXT FLAG
   ====================================================================== */

/**
 * Read or set the "we are inside an AJAX account submit" flag.
 *
 * @param bool|null $set Pass a boolean to set, null to read.
 * @return bool Current state.
 */
function zymarg_os_acc_ajax_context( $set = null ) {
	static $active = false;

	if ( is_bool( $set ) ) {
		$active = $set;
	}

	return $active;
}

/**
 * Whether the current request is an AJAX account form submit.
 *
 * @return bool
 */
function zymarg_os_acc_is_ajax_form() {
	return zymarg_os_acc_ajax_context();
}

/**
 * Finish a save the way the request expects.
 *
 * Normal request: redirect and stop, exactly as before.
 * AJAX submit: unwind so the caller can render the updated section instead.
 *
 * @param string $url Where a full page load would have gone next.
 * @return void
 * @throws Zymarg_OS_Account_Redirect When handling an AJAX submit.
 */
function zymarg_os_acc_redirect( $url ) {
	if ( zymarg_os_acc_is_ajax_form() ) {
		throw new Zymarg_OS_Account_Redirect( $url );
	}

	wp_safe_redirect( $url );
	exit;
}

/* ======================================================================
   2. FORM REGISTRY
   ====================================================================== */

/**
 * Which submits may be routed through AJAX, and what to re-render after.
 *
 * `callback` is the untouched `template_redirect` handler. `section` is the
 * account section to re-render on success. `logout` marks a submit that ends
 * the session, where a real navigation is the correct outcome.
 *
 * Registering a new form is a filter call, not an edit to this file.
 *
 * @return array<string,array<string,mixed>>
 */
function zymarg_os_acc_form_map() {
	$map = array(
		'profile'      => array(
			'callback' => 'zymarg_os_handle_profile_save',
			'section'  => 'profile',
		),
		'password'     => array(
			'callback' => 'zymarg_os_handle_password_update',
			'section'  => 'security',
		),
		'email'        => array(
			'callback' => 'zymarg_os_handle_email_change_request',
			'section'  => 'profile',
		),
		'email_cancel' => array(
			'callback' => 'zymarg_os_handle_email_change_cancel',
			'section'  => 'profile',
		),
		'address'      => array(
			'callback' => 'zymarg_os_handle_address_actions',
			'section'  => 'addresses',
		),
		'delete'       => array(
			'callback' => 'zymarg_os_handle_delete_account',
			'section'  => '',
			'logout'   => true,
		),
	);

	/**
	 * Filter the AJAX-routable account submits.
	 *
	 * @param array $map Form key => definition.
	 */
	return apply_filters( 'zymarg_os_account_ajax_forms', $map );
}

/* ======================================================================
   3. NOTICES → TOASTS
   ====================================================================== */

/**
 * Drain the notice queue into a JSON-friendly list.
 *
 * Woo prints its notices from the account *page* template, which an AJAX
 * section swap never re-runs — so a saved-successfully message would simply
 * vanish. Draining them here and shipping them to the toast system keeps the
 * feedback the handlers already write, and clearing them stops the same
 * message reappearing on the customer's next full page load.
 *
 * @return array<int,array<string,string>>
 */
function zymarg_os_acc_collect_notices() {
	$out = array();

	if ( function_exists( 'wc_get_notices' ) && function_exists( 'wc_clear_notices' ) ) {
		foreach ( (array) wc_get_notices() as $type => $items ) {
			foreach ( (array) $items as $item ) {
				$message = is_array( $item ) && isset( $item['notice'] ) ? $item['notice'] : (string) $item;
				$message = trim( wp_strip_all_tags( $message ) );

				if ( '' === $message ) {
					continue;
				}

				$out[] = array(
					'type'    => zymarg_os_acc_notice_type( $type ),
					'message' => $message,
				);
			}
		}

		wc_clear_notices();

		return $out;
	}

	// WooCommerce absent: our own transient-backed queue.
	$key   = 'zymarg_notices_' . get_current_user_id();
	$queue = get_transient( $key );

	if ( is_array( $queue ) ) {
		foreach ( $queue as $notice ) {
			$message = trim( wp_strip_all_tags( (string) ( $notice['message'] ?? '' ) ) );

			if ( '' === $message ) {
				continue;
			}

			$out[] = array(
				'type'    => zymarg_os_acc_notice_type( $notice['type'] ?? 'success' ),
				'message' => $message,
			);
		}

		delete_transient( $key );
	}

	return $out;
}

/**
 * Map a Woo/theme notice type onto a toast type.
 *
 * @param string $type Incoming type.
 * @return string One of success|error|info.
 */
function zymarg_os_acc_notice_type( $type ) {
	switch ( (string) $type ) {
		case 'error':
			return 'error';
		case 'success':
			return 'success';
		default:
			return 'info';
	}
}

/* ======================================================================
   4. RENDERING
   ====================================================================== */

/**
 * Render one account section to a string.
 *
 * @param string $section Section slug.
 * @return string Markup, or '' when the section cannot be rendered.
 */
function zymarg_os_acc_render_section_html( $section ) {
	$section = (string) $section;

	if ( '' === $section || ! function_exists( 'zymarg_os_account_render_section' ) ) {
		return '';
	}

	ob_start();
	zymarg_os_account_render_section( $section );

	return (string) ob_get_clean();
}

/* ======================================================================
   5. THE ENDPOINT
   ====================================================================== */

/**
 * Run an account form handler over AJAX and return the updated section.
 *
 * @return void
 */
function zymarg_os_ajax_account_form() {
	check_ajax_referer( 'zymarg_acc_form', 'nonce' );

	if ( ! is_user_logged_in() ) {
		wp_send_json_error( array( 'message' => __( 'Please log in again to continue.', 'zymarg-os' ) ), 403 );
	}

	$form = isset( $_POST['form'] ) ? sanitize_key( wp_unslash( $_POST['form'] ) ) : '';
	$map  = zymarg_os_acc_form_map();

	if ( ! isset( $map[ $form ] ) || ! is_callable( $map[ $form ]['callback'] ) ) {
		wp_send_json_error( array( 'message' => __( 'Unknown form.', 'zymarg-os' ) ), 400 );
	}

	$definition = $map[ $form ];
	$is_logout  = ! empty( $definition['logout'] );

	// Read everything we need out of the real request *before* the
	// superglobals are restaged for the handler.
	$method  = isset( $_POST['method'] ) && 'get' === strtolower( sanitize_key( wp_unslash( $_POST['method'] ) ) ) ? 'GET' : 'POST';
	$payload = isset( $_POST['payload'] ) ? (string) wp_unslash( $_POST['payload'] ) : '';
	$section = isset( $_POST['section'] ) ? sanitize_key( wp_unslash( $_POST['section'] ) ) : '';

	if ( '' === $section ) {
		$section = (string) $definition['section'];
	}

	$fields = array();
	wp_parse_str( $payload, $fields );

	// WordPress hands handlers slashed superglobals and every handler
	// wp_unslash()es what it reads, so the staged data has to be slashed too
	// or a name like O'Brien loses its apostrophe.
	$fields = wp_slash( $fields );

	$saved = array(
		'post'   => $_POST,
		'get'    => $_GET,
		'request' => $_REQUEST,
		'method' => isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : 'POST',
	);

	if ( 'GET' === $method ) {
		$_GET  = $fields;
		$_POST = array();
	} else {
		$_POST = $fields;
		$_GET  = array();
	}

	$_REQUEST                  = array_merge( $_GET, $_POST );
	$_SERVER['REQUEST_METHOD'] = $method;

	// Handlers that guard on is_account_page() would bail on admin-ajax.php,
	// where there is no queried page at all. This is the supported Woo way to
	// tell them the request belongs to the account screen.
	add_filter( 'woocommerce_is_account_page', '__return_true' );

	zymarg_os_acc_ajax_context( true );

	$redirect = '';

	try {
		call_user_func( $definition['callback'] );
	} catch ( Zymarg_OS_Account_Redirect $signal ) {
		$redirect = $signal->url;
	}

	zymarg_os_acc_ajax_context( false );
	remove_filter( 'woocommerce_is_account_page', '__return_true' );

	$notices = zymarg_os_acc_collect_notices();

	// Same reasoning as the section endpoint: a re-render here may enqueue
	// assets that the already-parsed document will never pick up on its own.
	$assets_before = function_exists( 'zymarg_os_acc_asset_snapshot' )
		? zymarg_os_acc_asset_snapshot()
		: null;

	$html = $is_logout ? '' : zymarg_os_acc_render_section_html( $section );

	$assets = ( null !== $assets_before && function_exists( 'zymarg_os_acc_asset_diff' ) )
		? zymarg_os_acc_asset_diff( $assets_before )
		: array();

	// Put the real request back so anything later in the response (or any
	// shutdown hook) sees an honest picture.
	$_POST                     = $saved['post'];
	$_GET                      = $saved['get'];
	$_REQUEST                  = $saved['request'];
	$_SERVER['REQUEST_METHOD'] = $saved['method'];

	/**
	 * Fires after an account form has been handled over AJAX.
	 *
	 * @param string $form    Form key.
	 * @param array  $notices Collected notices.
	 */
	do_action( 'zymarg_os_account_ajax_handled', $form, $notices );

	wp_send_json_success(
		array(
			'form'     => $form,
			'section'  => $is_logout ? '' : $section,
			'html'     => $html,
			'assets'   => $assets,
			'notices'  => $notices,
			// Only a session-ending submit earns a real navigation.
			'redirect' => $is_logout ? ( $redirect ? $redirect : home_url( '/' ) ) : '',
			'saved'    => '' !== $redirect,
		)
	);
}
add_action( 'wp_ajax_zymarg_acc_form', 'zymarg_os_ajax_account_form' );
