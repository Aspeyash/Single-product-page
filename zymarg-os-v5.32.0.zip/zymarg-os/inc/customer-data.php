<?php
/**
 * Customer data — one source of truth for "everything about this person".
 *
 * WHY THIS FILE EXISTS
 *   Support needs to see what a customer sees. The tempting way to build that
 *   is to copy the My Account screens into wp-admin. That would mean a second
 *   copy of roughly a quarter of a megabyte of account code (15 account-*.php
 *   files), and every future field would have to be added twice — the same
 *   two-places-one-thing mistake that caused the admin header bug fixed in
 *   v5.27.9.
 *
 *   So instead: the FETCHING of customer data lives here, once, and both sides
 *   render from it. My Account renders it for the customer. The Customers
 *   screen renders it for staff. Add a profile field and both follow.
 *
 * READ-ONLY BY DESIGN
 *   Nothing in this file writes customer data. Staff viewing an account cannot
 *   change it from these getters, which keeps the change log (who edited what)
 *   trustworthy — the thing every payment dispute turns on.
 *
 * PRIVACY
 *   Every getter runs through zymarg_os_customer_redact_meta(), so secrets
 *   (2FA seeds, tokens, reset keys, session data) can never leak into an admin
 *   view by accident, even if a plugin adds one later. Reading a customer's
 *   record is recorded by inc/customer-access-log.php.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/* ======================================================================
   1. WHO IS ALLOWED TO SEE THIS
   ====================================================================== */

/**
 * Roles that are marketplace sellers rather than staff.
 *
 * Marketplace plugins hand vendors elevated capabilities so they can run their
 * own dashboard. That must never turn into "can browse the buyer database".
 *
 * @return array<int,string>
 */
function zymarg_os_customer_vendor_roles() {
	$roles = array( 'seller', 'vendor', 'dc_vendor', 'wcfm_vendor', 'dokan_vendor', 'shop_vendor' );

	/**
	 * Filters the roles treated as vendors.
	 *
	 * @param array $roles Role slugs.
	 */
	return (array) apply_filters( 'zymarg_os_vendor_roles', $roles );
}

/**
 * Is this user a marketplace vendor?
 *
 * NAME NOTE (v5.29.1): this was zymarg_os_user_is_vendor(), which the ZYMARG
 * Vendor Dashboard plugin already declares. Two declarations of one name is a
 * fatal error in PHP, so the theme's copy is namespaced under _customer_ and
 * DEFERS to the plugin's answer when the plugin is active — the plugin owns the
 * definition of "vendor" on a marketplace, so it should be the authority.
 *
 * @param int $user_id User ID.
 * @return bool
 */
function zymarg_os_customer_is_vendor( $user_id ) {
	$user_id = (int) $user_id;

	// The plugin's verdict wins when it is available.
	if ( function_exists( 'zymarg_os_user_is_vendor' ) ) {
		return (bool) zymarg_os_user_is_vendor( $user_id );
	}

	$user = get_userdata( $user_id );

	if ( ! $user ) {
		return false;
	}

	$vendor_roles = zymarg_os_customer_vendor_roles();

	foreach ( (array) $user->roles as $role ) {
		if ( in_array( $role, $vendor_roles, true ) ) {
			return true;
		}
	}

	return false;
}

/**
 * May this user read another customer's record?
 *
 * Stricter than a plain capability check on purpose: a vendor is blocked even
 * when a plugin has granted them a capability that would otherwise pass, unless
 * they are a full administrator.
 *
 * @param int $viewer_id Staff user ID, 0 for current user.
 * @return bool
 */
function zymarg_os_can_view_customer_data( $viewer_id = 0 ) {
	$viewer_id = $viewer_id ? (int) $viewer_id : get_current_user_id();

	if ( $viewer_id <= 0 ) {
		return false;
	}

	$capability = function_exists( 'zymarg_os_customers_capability' )
		? zymarg_os_customers_capability()
		: 'edit_users';

	$allowed = user_can( $viewer_id, $capability );

	if ( $allowed && zymarg_os_customer_is_vendor( $viewer_id ) && ! user_can( $viewer_id, 'manage_options' ) ) {
		$allowed = false;
	}

	/**
	 * Filters whether a user may read customer records.
	 *
	 * @param bool $allowed   Decision so far.
	 * @param int  $viewer_id User being checked.
	 */
	return (bool) apply_filters( 'zymarg_os_can_view_customer_data', $allowed, $viewer_id );
}

/* ======================================================================
   2. REDACTION
   ====================================================================== */

/**
 * Meta key fragments that must never reach an admin screen.
 *
 * Matched as substrings, so a plugin adding 'acme_totp_secret' is caught
 * without this list needing to know about it.
 *
 * @return array<int,string>
 */
function zymarg_os_customer_secret_meta_patterns() {
	$patterns = array(
		'password',
		'pass_hash',
		'session_tokens',
		'_secret',
		'totp',
		'2fa',
		'two_factor',
		'recovery_code',
		'backup_code',
		'activation_key',
		'reset_key',
		'_token',
		'api_key',
		'nonce',
		'payment_token',
		'card_number',
		'cvv',
	);

	/**
	 * Filters the never-display meta patterns.
	 *
	 * @param array $patterns Substrings.
	 */
	return (array) apply_filters( 'zymarg_os_customer_secret_meta_patterns', $patterns );
}

/**
 * Is this meta key a secret?
 *
 * @param string $key Meta key.
 * @return bool
 */
function zymarg_os_customer_meta_is_secret( $key ) {
	$key = strtolower( (string) $key );

	foreach ( zymarg_os_customer_secret_meta_patterns() as $pattern ) {
		if ( '' !== $pattern && false !== strpos( $key, strtolower( $pattern ) ) ) {
			return true;
		}
	}

	return false;
}

/**
 * Strip secret keys out of a key => value map.
 *
 * @param array $data Meta map.
 * @return array
 */
function zymarg_os_customer_redact_meta( $data ) {
	$clean = array();

	foreach ( (array) $data as $key => $value ) {
		if ( zymarg_os_customer_meta_is_secret( $key ) ) {
			continue;
		}

		$clean[ $key ] = $value;
	}

	return $clean;
}

/* ======================================================================
   3. IDENTITY
   ====================================================================== */

/**
 * Who this customer is: the header facts a support agent reads first.
 *
 * @param int $user_id User ID.
 * @return array Empty array when the user does not exist.
 */
function zymarg_os_customer_identity( $user_id ) {
	$user_id = (int) $user_id;
	$user    = get_userdata( $user_id );

	if ( ! $user ) {
		return array();
	}

	$phone = get_user_meta( $user_id, 'billing_phone', true );

	$identity = array(
		'id'           => $user_id,
		'name'         => $user->display_name,
		'first_name'   => get_user_meta( $user_id, 'first_name', true ),
		'last_name'    => get_user_meta( $user_id, 'last_name', true ),
		'email'        => $user->user_email,
		'username'     => $user->user_login,
		'roles'        => (array) $user->roles,
		'is_vendor'    => zymarg_os_customer_is_vendor( $user_id ),
		'registered'   => $user->user_registered,
		'phone'        => $phone ? $phone : '',
		'whatsapp'     => function_exists( 'zymarg_os_get_whatsapp_number' ) ? zymarg_os_get_whatsapp_number( $user_id ) : '',
		'avatar_url'   => function_exists( 'zymarg_os_get_user_avatar_url' ) ? zymarg_os_get_user_avatar_url( $user_id, 96 ) : get_avatar_url( $user_id, array( 'size' => 96 ) ),
		'completeness' => function_exists( 'zymarg_os_profile_completeness' ) ? zymarg_os_profile_completeness( $user_id ) : null,
		'edit_url'     => get_edit_user_link( $user_id ),
	);

	/**
	 * Filters a customer's identity block.
	 *
	 * @param array $identity Identity data.
	 * @param int   $user_id  User ID.
	 */
	return (array) apply_filters( 'zymarg_os_customer_identity', $identity, $user_id );
}

/* ======================================================================
   4. COMMERCE METRICS
   ====================================================================== */

/**
 * Order count, lifetime value, average order value, first and last order.
 *
 * @param int $user_id User ID.
 * @return array
 */
function zymarg_os_customer_metrics( $user_id ) {
	$user_id = (int) $user_id;

	$metrics = array(
		'order_count'     => 0,
		'total_spent'     => 0.0,
		'average_order'   => 0.0,
		'first_order_at'  => '',
		'last_order_at'   => '',
		'has_woocommerce' => function_exists( 'wc_price' ),
	);

	if ( ! $metrics['has_woocommerce'] ) {
		return $metrics;
	}

	if ( function_exists( 'wc_get_customer_order_count' ) ) {
		$metrics['order_count'] = (int) wc_get_customer_order_count( $user_id );
	}

	if ( function_exists( 'wc_get_customer_total_spent' ) ) {
		$metrics['total_spent'] = (float) wc_get_customer_total_spent( $user_id );
	}

	if ( $metrics['order_count'] > 0 ) {
		$metrics['average_order'] = $metrics['total_spent'] / $metrics['order_count'];
	}

	$last = function_exists( 'zymarg_os_customer_orders' ) ? zymarg_os_customer_orders( $user_id, 1 ) : array();

	if ( ! empty( $last[0] ) && is_a( $last[0], 'WC_Order' ) ) {
		$created = $last[0]->get_date_created();

		if ( $created ) {
			$metrics['last_order_at'] = $created->date( 'Y-m-d H:i:s' );
		}
	}

	if ( function_exists( 'zymarg_os_customer_first_order_date' ) ) {
		$metrics['first_order_at'] = (string) zymarg_os_customer_first_order_date( $user_id );
	}

	/**
	 * Filters a customer's commerce metrics.
	 *
	 * @param array $metrics Metrics.
	 * @param int   $user_id User ID.
	 */
	return (array) apply_filters( 'zymarg_os_customer_metrics', $metrics, $user_id );
}

/* ======================================================================
   5. ADDRESSES
   ====================================================================== */

/**
 * The customer's address book, exactly as My Account stores it.
 *
 * Falls back to WooCommerce billing/shipping meta when the theme's own address
 * book is empty, so older accounts still show something useful.
 *
 * @param int $user_id User ID.
 * @return array<int,array>
 */
function zymarg_os_customer_address_book( $user_id ) {
	$user_id   = (int) $user_id;
	$addresses = array();

	if ( function_exists( 'zymarg_os_get_addresses' ) ) {
		$addresses = (array) zymarg_os_get_addresses( $user_id );
	}

	if ( empty( $addresses ) ) {
		foreach ( array( 'billing', 'shipping' ) as $type ) {
			$line1 = get_user_meta( $user_id, $type . '_address_1', true );

			if ( ! $line1 ) {
				continue;
			}

			$addresses[] = array(
				'label'     => ucfirst( $type ),
				'name'      => trim( get_user_meta( $user_id, $type . '_first_name', true ) . ' ' . get_user_meta( $user_id, $type . '_last_name', true ) ),
				'address_1' => $line1,
				'address_2' => get_user_meta( $user_id, $type . '_address_2', true ),
				'city'      => get_user_meta( $user_id, $type . '_city', true ),
				'state'     => get_user_meta( $user_id, $type . '_state', true ),
				'postcode'  => get_user_meta( $user_id, $type . '_postcode', true ),
				'country'   => get_user_meta( $user_id, $type . '_country', true ),
				'phone'     => get_user_meta( $user_id, $type . '_phone', true ),
				'source'    => 'woocommerce',
			);
		}
	}

	/**
	 * Filters a customer's address list.
	 *
	 * @param array $addresses Addresses.
	 * @param int   $user_id   User ID.
	 */
	return (array) apply_filters( 'zymarg_os_customer_address_book', $addresses, $user_id );
}

/* ======================================================================
   6. PROFILE FIELDS — THE SHARED SOURCE OF TRUTH
   ====================================================================== */

/**
 * Every profile field the customer sees on My Account, with its current value.
 *
 * This is the function that makes duplication unnecessary: it walks the SAME
 * field definitions the front end uses (zymarg_os_profile_fields), so a field
 * added there appears on the admin side with no extra work.
 *
 * @param int $user_id User ID.
 * @return array<string,array> key => array( label, value, group, locked )
 */
function zymarg_os_customer_profile_fields( $user_id ) {
	$user_id = (int) $user_id;
	$out     = array();

	if ( ! function_exists( 'zymarg_os_profile_fields' ) ) {
		return $out;
	}

	$fields = (array) zymarg_os_profile_fields();

	foreach ( $fields as $key => $field ) {
		if ( zymarg_os_customer_meta_is_secret( $key ) ) {
			continue;
		}

		$value = function_exists( 'zymarg_os_profile_get_value' )
			? zymarg_os_profile_get_value( $key, $field, $user_id )
			: get_user_meta( $user_id, $key, true );

		$out[ $key ] = array(
			'label'  => isset( $field['label'] ) ? $field['label'] : $key,
			'value'  => $value,
			'group'  => isset( $field['group'] ) ? $field['group'] : '',
			'type'   => isset( $field['type'] ) ? $field['type'] : 'text',
			'locked' => function_exists( 'zymarg_os_profile_is_locked' ) ? (bool) zymarg_os_profile_is_locked( $key ) : false,
		);
	}

	/**
	 * Filters the customer profile field snapshot.
	 *
	 * @param array $out     Fields with values.
	 * @param int   $user_id User ID.
	 */
	return (array) apply_filters( 'zymarg_os_customer_profile_fields', $out, $user_id );
}

/* ======================================================================
   7. UNIFIED TIMELINE
   ====================================================================== */

/**
 * One merged, newest-first history: orders, account changes, security events.
 *
 * Three separate tables force an agent to cross-reference timestamps by eye.
 * Merging them answers the question support actually asks — "what happened to
 * this account, in order?" — such as a delivery address changed twelve minutes
 * before a disputed order.
 *
 * @param int $user_id User ID.
 * @param int $limit   Max entries returned.
 * @return array<int,array> Each: type, time (GMT mysql), label, detail, actor, url.
 */
function zymarg_os_customer_timeline( $user_id, $limit = 30 ) {
	$user_id = (int) $user_id;
	$limit   = max( 1, min( 200, (int) $limit ) );
	$entries = array();

	/* Orders. */
	if ( function_exists( 'zymarg_os_customer_orders' ) ) {
		foreach ( (array) zymarg_os_customer_orders( $user_id, $limit ) as $order ) {
			if ( ! is_a( $order, 'WC_Order' ) ) {
				continue;
			}

			$created = $order->get_date_created();

			$entries[] = array(
				'type'   => 'order',
				'time'   => $created ? gmdate( 'Y-m-d H:i:s', $created->getTimestamp() ) : '',
				'label'  => sprintf( /* translators: %s: order number. */ __( 'Order #%s', 'zymarg-os' ), $order->get_order_number() ),
				'detail' => function_exists( 'wc_get_order_status_name' ) ? wc_get_order_status_name( $order->get_status() ) : $order->get_status(),
				'actor'  => __( 'The customer', 'zymarg-os' ),
				'url'    => $order->get_edit_order_url(),
			);
		}
	}

	/* Account field changes. */
	if ( function_exists( 'zymarg_os_get_change_log' ) ) {
		foreach ( (array) zymarg_os_get_change_log( $user_id, $limit ) as $entry ) {
			if ( isset( $entry['field'] ) && zymarg_os_customer_meta_is_secret( $entry['field'] ) ) {
				continue;
			}

			$from = isset( $entry['old'] ) && '' !== $entry['old'] ? $entry['old'] : __( '(empty)', 'zymarg-os' );
			$to   = isset( $entry['new'] ) && '' !== $entry['new'] ? $entry['new'] : __( '(cleared)', 'zymarg-os' );

			$entries[] = array(
				'type'   => 'change',
				'time'   => isset( $entry['time'] ) ? $entry['time'] : '',
				'label'  => isset( $entry['label'] ) ? $entry['label'] : ( isset( $entry['field'] ) ? $entry['field'] : '' ),
				'detail' => sprintf( /* translators: 1: old value, 2: new value. */ __( '%1$s → %2$s', 'zymarg-os' ), $from, $to ),
				'actor'  => function_exists( 'zymarg_os_change_log_actor_label' ) ? zymarg_os_change_log_actor_label( $entry ) : '',
				'url'    => '',
			);
		}
	}

	/* Sign-ins and security events. */
	if ( function_exists( 'zymarg_os_customer_security_events' ) ) {
		foreach ( (array) zymarg_os_customer_security_events( $user_id, $limit ) as $event ) {
			$where = array();

			if ( ! empty( $event->device ) ) {
				$where[] = $event->device;
			}
			if ( ! empty( $event->ip ) ) {
				$where[] = $event->ip;
			}

			$entries[] = array(
				'type'   => 'security',
				'time'   => isset( $event->created_at ) ? $event->created_at : ( isset( $event->time ) ? $event->time : '' ),
				'label'  => isset( $event->event_type ) ? $event->event_type : __( 'Security event', 'zymarg-os' ),
				'detail' => implode( ' · ', $where ),
				'actor'  => __( 'The customer', 'zymarg-os' ),
				'url'    => '',
			);
		}
	}

	/* Newest first; entries without a timestamp sink to the bottom. */
	usort(
		$entries,
		static function ( $a, $b ) {
			$at = empty( $a['time'] ) ? 0 : strtotime( $a['time'] );
			$bt = empty( $b['time'] ) ? 0 : strtotime( $b['time'] );

			if ( $at === $bt ) {
				return 0;
			}

			return ( $at < $bt ) ? 1 : -1;
		}
	);

	$entries = array_slice( $entries, 0, $limit );

	/**
	 * Filters the merged customer timeline.
	 *
	 * @param array $entries Timeline entries.
	 * @param int   $user_id User ID.
	 * @param int   $limit   Requested limit.
	 */
	return (array) apply_filters( 'zymarg_os_customer_timeline', $entries, $user_id, $limit );
}

/* ======================================================================
   8. SNAPSHOT
   ====================================================================== */

/**
 * Everything about one customer, in one guarded call.
 *
 * Checks permission, records the access, and returns the assembled record.
 * Screens should call this rather than the individual getters, so no screen can
 * forget the permission check or the access log.
 *
 * @param int    $user_id User ID.
 * @param string $context What is being viewed, for the access log.
 * @return array|WP_Error
 */
function zymarg_os_customer_snapshot( $user_id, $context = 'view' ) {
	$user_id = (int) $user_id;

	if ( ! zymarg_os_can_view_customer_data() ) {
		return new WP_Error(
			'zymarg_os_forbidden',
			__( 'Sorry, you are not allowed to view customer records.', 'zymarg-os' )
		);
	}

	$identity = zymarg_os_customer_identity( $user_id );

	if ( empty( $identity ) ) {
		return new WP_Error(
			'zymarg_os_no_customer',
			__( 'That account no longer exists. It may have been deleted.', 'zymarg-os' )
		);
	}

	if ( function_exists( 'zymarg_os_log_customer_access' ) ) {
		zymarg_os_log_customer_access( $user_id, $context );
	}

	$snapshot = array(
		'identity'  => $identity,
		'metrics'   => zymarg_os_customer_metrics( $user_id ),
		'addresses' => zymarg_os_customer_address_book( $user_id ),
		'profile'   => zymarg_os_customer_profile_fields( $user_id ),
		'timeline'  => zymarg_os_customer_timeline( $user_id ),
	);

	/**
	 * Filters the complete customer snapshot.
	 *
	 * @param array  $snapshot Assembled record.
	 * @param int    $user_id  User ID.
	 * @param string $context  View context.
	 */
	return (array) apply_filters( 'zymarg_os_customer_snapshot', $snapshot, $user_id, $context );
}
