<?php
/**
 * Product Card control panel (admin page).
 *
 * A dedicated screen at ZYMARG OS -> Product Card that controls which product
 * card the theme renders, and explains what that choice affects.
 *
 * Background: the ZYMARG WC Product Grid engine only consults its card registry
 * when a grid is rendered through its Render_Engine. Most of this theme's
 * product surfaces do not go through Render_Engine -- they ask the engine's
 * Template_Loader for `grid/product-card.php` directly -- so the registry, the
 * `card_template` shortcode attribute and the card-settings filters have no say
 * over which card appears. The theme therefore ships a template override at
 * `zymarg-wcpg/grid/product-card.php` which routes that request to either the
 * ZYMARG Template Pack card or the engine's own card. This screen is the switch
 * for that router.
 *
 * The full technical write-up lives in PRODUCT-CARD-OVERRIDE.md, shipped with
 * the ZYMARG Template Pack plugin.
 *
 * Settings live in inc/product-card-delegate.php (option `zymarg_os_product_card`),
 * because they are read on the front end.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register the Product Card submenu under the ZYMARG OS menu.
 * Priority 23 places it right after Toast Notification (22).
 *
 * @return void
 */
function zymarg_os_product_card_admin_menu() {
	add_submenu_page(
		'zymarg-os',
		__( 'Product Card', 'zymarg-os' ),
		__( 'Product Card', 'zymarg-os' ),
		'manage_options',
		'zymarg-os-product-card',
		'zymarg_os_render_product_card_admin_page'
	);
}
add_action( 'admin_menu', 'zymarg_os_product_card_admin_menu', 23 );

/**
 * Handle the settings save.
 *
 * @return bool True when settings were just saved.
 */
function zymarg_os_product_card_maybe_save() {
	if ( ! isset( $_POST['zymarg_os_product_card_nonce'] ) ) {
		return false;
	}

	if ( ! current_user_can( 'manage_options' ) ) {
		return false;
	}

	check_admin_referer( 'zymarg_os_product_card_save', 'zymarg_os_product_card_nonce' );

	$settings = array(
		'enabled'   => isset( $_POST['zymarg_os_card_enabled'] ) ? 1 : 0,
		'shop_loop' => isset( $_POST['zymarg_os_card_shop_loop'] ) ? 1 : 0,
	);

	$defaults = zymarg_os_product_card_defaults();

	foreach ( array_keys( zymarg_os_product_card_breakpoints() ) as $key ) {
		$posted = isset( $_POST[ 'zymarg_os_' . $key ] ) ? absint( wp_unslash( $_POST[ 'zymarg_os_' . $key ] ) ) : 0;

		if ( $posted < 1 ) {
			$posted = (int) $defaults[ $key ];
		}

		$settings[ $key ] = (int) min( 8, max( 1, $posted ) );
	}

	// Card gap, per view (5.21.0). Unlike the column counts, 0 is a legitimate
	// value here (edge-to-edge cards), so an empty field cannot be treated as
	// "unset" -- only a genuinely absent field falls back to the default.
	foreach ( array_keys( zymarg_os_product_card_views() ) as $view ) {
		$key = 'gap_' . $view;

		if ( ! isset( $_POST[ 'zymarg_os_' . $key ] ) || '' === $_POST[ 'zymarg_os_' . $key ] ) {
			$settings[ $key ] = (int) $defaults[ $key ];
			continue;
		}

		$posted           = absint( wp_unslash( $_POST[ 'zymarg_os_' . $key ] ) );
		$settings[ $key ] = (int) min( 64, max( 0, $posted ) );
	}

	update_option( ZYMARG_OS_PRODUCT_CARD_OPTION, $settings );

	return true;
}

/**
 * Collect the environment status shown at the top of the screen.
 *
 * Everything the branded card depends on is optional and guarded, so a missing
 * piece never fatals -- it silently changes what renders. Surfacing each piece
 * here is what turns "the card looks wrong" into a one-glance diagnosis.
 *
 * @return array<int,array{label:string,ok:bool,detail:string}>
 */
function zymarg_os_product_card_status() {
	$engine_active = class_exists( '\Zymarg\WCPG\Templates\Template_Manager' );
	$card_path     = function_exists( 'zymarg_os_branded_card_path' ) ? zymarg_os_branded_card_path() : '';
	$override      = get_stylesheet_directory() . '/zymarg-wcpg/grid/product-card.php';
	$badges        = class_exists( 'Zymarg_Template_Pack_Badge_Resolver' );

	/*
	 * 5.21.2: the pack row used to pass as long as the card FILE existed on
	 * disk, and the engine row as long as Template_Manager existed. Neither is
	 * an honest test -- Template_Manager ships with the engine, so it is there
	 * with or without the pack, and a file on disk says nothing about whether
	 * the pack registered its slug. Every row could read green while the shop
	 * loop rendered the engine's default card. Ask the registry instead.
	 */
	$card_registered = function_exists( 'zymarg_os_branded_card_registered' )
		&& zymarg_os_branded_card_registered();

	$slug = function_exists( 'zymarg_os_branded_card_slug' ) ? zymarg_os_branded_card_slug() : 'zymarg';

	$css_ok = false;
	if ( $engine_active && $card_registered ) {
		$assets = \Zymarg\WCPG\Templates\Template_Manager::get_card_assets( $slug );
		$css_ok = ! empty( $assets['css']['url'] );
	}

	return array(
		array(
			'label'  => __( 'ZYMARG WC Product Grid (engine)', 'zymarg-os' ),
			'ok'     => $engine_active,
			'detail' => $engine_active
				? __( 'Active. The theme override is being consulted.', 'zymarg-os' )
				: __( 'Not active. No product cards are delegated at all — the theme falls back to its own basic grid.', 'zymarg-os' ),
		),
		array(
			'label'  => __( 'ZYMARG Template Pack (branded card)', 'zymarg-os' ),
			'ok'     => $card_registered,
			'detail' => $card_registered
				? __( 'Registered with the grid engine and rendered on the shop loop.', 'zymarg-os' )
				: (
					( '' !== $card_path )
						? __( 'The card file is on disk but the pack has not registered it with the engine, so the engine\'s default card is rendered instead. Check that the ZYMARG Template Pack plugin is activated.', 'zymarg-os' )
						: __( 'Card template not found. The engine\'s default card is rendered instead — no error, just a different card.', 'zymarg-os' )
				),
		),
		array(
			'label'  => __( 'Theme template override', 'zymarg-os' ),
			'ok'     => file_exists( $override ),
			'detail' => file_exists( $override )
				? __( 'zymarg-wcpg/grid/product-card.php is present. This is what makes the toggle work.', 'zymarg-os' )
				: __( 'Missing. Without it the engine always renders its own card and these toggles do nothing.', 'zymarg-os' ),
		),
		array(
			'label'  => __( 'Branded card stylesheet', 'zymarg-os' ),
			'ok'     => $css_ok,
			'detail' => $css_ok
				? __( 'Loaded through the engine\'s own asset pipeline, in the page head.', 'zymarg-os' )
				: __( 'Not loaded. The card markup would render with the theme\'s base typography instead of the card design.', 'zymarg-os' ),
		),
		array(
			'label'  => __( 'Badge resolver', 'zymarg-os' ),
			'ok'     => $badges,
			'detail' => $badges
				? __( 'Available. Status badges (Hot, New, Sale…) will resolve.', 'zymarg-os' )
				: __( 'Unavailable. Cards render without status badges.', 'zymarg-os' ),
		),
	);
}

/**
 * Render the Product Card screen.
 *
 * @return void
 */
function zymarg_os_render_product_card_admin_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You do not have permission to access this page.', 'zymarg-os' ) );
	}

	$saved     = zymarg_os_product_card_maybe_save();
	$enabled   = zymarg_os_product_card_setting( 'enabled' );
	$shop_loop = zymarg_os_product_card_setting( 'shop_loop' );
	?>
	<div class="wrap zymarg-admin zymarg-welcome">
		<h1>
			<?php if ( function_exists( 'zymarg_discovery_spark' ) ) { echo zymarg_discovery_spark( array( 'size' => 'lg' ) ); } // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<?php esc_html_e( 'Product Card', 'zymarg-os' ); ?>
			<span class="zymarg-welcome__v">v<?php echo esc_html( defined( 'ZYMARG_OS_VERSION' ) ? ZYMARG_OS_VERSION : '1.0.0' ); ?></span>
		</h1>

		<?php if ( $saved ) : ?>
			<div class="notice notice-success is-dismissible">
				<p><?php esc_html_e( 'Product Card settings saved.', 'zymarg-os' ); ?></p>
			</div>
		<?php endif; ?>

		<p class="zymarg-welcome__intro">
			<?php esc_html_e( 'Choose which card the theme renders wherever a product is listed. The ZYMARG branded card comes from the ZYMARG Template Pack plugin; the alternative is the Product Grid engine\'s own default card.', 'zymarg-os' ); ?>
		</p>

		<h2><?php esc_html_e( 'Status', 'zymarg-os' ); ?></h2>
		<table class="widefat striped" style="max-width:820px;">
			<tbody>
			<?php foreach ( zymarg_os_product_card_status() as $row ) : ?>
				<tr>
					<td style="width:32px;">
						<span class="dashicons <?php echo $row['ok'] ? 'dashicons-yes-alt' : 'dashicons-warning'; ?>"
							style="color:<?php echo $row['ok'] ? '#00a32a' : '#dba617'; ?>"></span>
					</td>
					<td style="width:280px;"><strong><?php echo esc_html( $row['label'] ); ?></strong></td>
					<td><?php echo esc_html( $row['detail'] ); ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>

		<form method="post" action="">
			<?php wp_nonce_field( 'zymarg_os_product_card_save', 'zymarg_os_product_card_nonce' ); ?>

			<h2><?php esc_html_e( 'Settings', 'zymarg-os' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Branded card', 'zymarg-os' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="zymarg_os_card_enabled" value="1" <?php checked( $enabled ); ?> />
							<?php esc_html_e( 'Use the ZYMARG Template Pack card everywhere the theme lists products', 'zymarg-os' ); ?>
						</label>
						<p class="description">
							<?php esc_html_e( 'When off, every surface below reverts to the Product Grid engine\'s default card. Nothing else changes.', 'zymarg-os' ); ?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Shop &amp; category loops', 'zymarg-os' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="zymarg_os_card_shop_loop" value="1" <?php checked( $shop_loop ); ?> />
							<?php esc_html_e( 'Also replace WooCommerce\'s own loop on the shop and category pages', 'zymarg-os' ); ?>
						</label>
						<p class="description">
							<?php esc_html_e( 'Requires the branded card above. Turn this off if a plugin needs to inject its own markup into the WooCommerce loop — see the trade-off below.', 'zymarg-os' ); ?>
						</p>
					</td>
				</tr>
			</table>

			<h2><?php esc_html_e( 'Cards per row', 'zymarg-os' ); ?></h2>
			<p class="description" style="max-width:820px;">
				<?php esc_html_e( 'Applies to every product grid: the shop and category pages, search, archives, related products, upsells and the account tabs. 1 to 8 cards per row.', 'zymarg-os' ); ?>
			</p>
			<table class="form-table" role="presentation">
				<?php
				$zymarg_views = array(
					'cols_mobile'  => array( __( 'Mobile', 'zymarg-os' ), __( 'Up to 767px', 'zymarg-os' ) ),
					'cols_tablet'  => array( __( 'Tablet', 'zymarg-os' ), __( '768px to 1024px', 'zymarg-os' ) ),
					'cols_desktop' => array( __( 'Desktop', 'zymarg-os' ), __( '1025px to 1439px', 'zymarg-os' ) ),
					'cols_wide'    => array( __( 'Large desktop', 'zymarg-os' ), __( '1440px and above', 'zymarg-os' ) ),
				);

				foreach ( $zymarg_views as $zymarg_key => $zymarg_view ) :
					?>
					<tr>
						<th scope="row">
							<label for="zymarg_os_<?php echo esc_attr( $zymarg_key ); ?>"><?php echo esc_html( $zymarg_view[0] ); ?></label>
						</th>
						<td>
							<input type="number" min="1" max="8" step="1" class="small-text"
								id="zymarg_os_<?php echo esc_attr( $zymarg_key ); ?>"
								name="zymarg_os_<?php echo esc_attr( $zymarg_key ); ?>"
								value="<?php echo esc_attr( zymarg_os_product_card_columns( $zymarg_key ) ); ?>" />
							<span class="description"><?php echo esc_html( $zymarg_view[1] ); ?></span>
						</td>
					</tr>
					<?php
				endforeach;
				?>
			</table>

			<h2><?php esc_html_e( 'Space between cards', 'zymarg-os' ); ?></h2>
			<p class="description" style="max-width:820px;">
				<?php esc_html_e( 'Gap between cards, in pixels, for each view — the same grids the counts above apply to. 0 puts the cards edge to edge; 64 is the maximum. This replaces the fixed 24px gap used before.', 'zymarg-os' ); ?>
			</p>
			<table class="form-table" role="presentation">
				<?php
				$zymarg_gaps = array(
					'mobile'  => array( __( 'Mobile', 'zymarg-os' ), __( 'Up to 767px', 'zymarg-os' ) ),
					'tablet'  => array( __( 'Tablet', 'zymarg-os' ), __( '768px to 1024px', 'zymarg-os' ) ),
					'desktop' => array( __( 'Desktop', 'zymarg-os' ), __( '1025px to 1439px', 'zymarg-os' ) ),
					'wide'    => array( __( 'Large desktop', 'zymarg-os' ), __( '1440px and above', 'zymarg-os' ) ),
				);

				foreach ( $zymarg_gaps as $zymarg_view_key => $zymarg_gap ) :
					?>
					<tr>
						<th scope="row">
							<label for="zymarg_os_gap_<?php echo esc_attr( $zymarg_view_key ); ?>"><?php echo esc_html( $zymarg_gap[0] ); ?></label>
						</th>
						<td>
							<input type="number" min="0" max="64" step="1" class="small-text"
								id="zymarg_os_gap_<?php echo esc_attr( $zymarg_view_key ); ?>"
								name="zymarg_os_gap_<?php echo esc_attr( $zymarg_view_key ); ?>"
								value="<?php echo esc_attr( zymarg_os_product_card_gap( $zymarg_view_key ) ); ?>" />
							<span class="description"><?php echo esc_html( $zymarg_gap[1] ); ?> — px</span>
						</td>
					</tr>
					<?php
				endforeach;
				?>
			</table>

			<?php submit_button(); ?>
		</form>

		<h2><?php esc_html_e( 'What each setting affects', 'zymarg-os' ); ?></h2>
		<table class="widefat striped" style="max-width:820px;">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Surface', 'zymarg-os' ); ?></th>
					<th><?php esc_html_e( 'Controlled by', 'zymarg-os' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<tr><td><?php esc_html_e( 'My Account → Wishlist', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'Branded card', 'zymarg-os' ); ?></td></tr>
				<tr><td><?php esc_html_e( 'My Account → Recently Viewed', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'Branded card', 'zymarg-os' ); ?></td></tr>
				<tr><td><?php esc_html_e( 'Search results', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'Branded card', 'zymarg-os' ); ?></td></tr>
				<tr><td><?php esc_html_e( 'Theme archives', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'Branded card', 'zymarg-os' ); ?></td></tr>
				<tr><td><?php esc_html_e( 'Related products', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'Branded card', 'zymarg-os' ); ?></td></tr>
				<tr><td><?php esc_html_e( 'Upsells', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'Branded card', 'zymarg-os' ); ?></td></tr>
				<tr><td><?php esc_html_e( 'Shop page, product categories &amp; tags, [products]', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'Branded card + Shop &amp; category loops', 'zymarg-os' ); ?></td></tr>
				<tr><td><?php esc_html_e( 'Elementor widgets &amp; [zymarg_products] shortcodes', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'Their own card setting in the Product Grid plugin', 'zymarg-os' ); ?></td></tr>
			</tbody>
		</table>

		<h2><?php esc_html_e( 'Good to know', 'zymarg-os' ); ?></h2>
		<ul class="ul-disc" style="max-width:820px;">
			<li>
				<strong><?php esc_html_e( 'Shop loop hooks:', 'zymarg-os' ); ?></strong>
				<?php esc_html_e( 'while the branded card runs in the shop loop, WooCommerce\'s woocommerce_before_shop_loop_item / woocommerce_after_shop_loop_item hooks do not fire — the card draws its own image, title, price, rating, wishlist, quick view and add-to-cart button. Plugins that inject markup into those hooks will show nothing there. Switch the shop loop toggle off to restore them.', 'zymarg-os' ); ?>
			</li>
			<li>
				<strong><?php esc_html_e( 'Cards per row:', 'zymarg-os' ); ?></strong>
				<?php esc_html_e( 'these counts override WooCommerce\'s own "Products per row" setting and the theme\'s shop column filter, because they are applied to every product grid from one place. Each view uses the count for its own width and above, so a value only affects the widths below the next view.', 'zymarg-os' ); ?>
			</li>
			<li>
				<strong><?php esc_html_e( 'Icons:', 'zymarg-os' ); ?></strong>
				<?php esc_html_e( 'the branded card uses Font Awesome for its wishlist, quick view and cart icons. If a page shows the card without icons, Font Awesome is not loading on that page.', 'zymarg-os' ); ?>
			</li>
			<li>
				<strong><?php esc_html_e( 'Plugin updates:', 'zymarg-os' ); ?></strong>
				<?php esc_html_e( 'the theme override routes to the Template Pack card rather than copying it, so updating the Template Pack updates the card everywhere with no re-sync.', 'zymarg-os' ); ?>
			</li>
			<li>
				<strong><?php esc_html_e( 'How to verify:', 'zymarg-os' ); ?></strong>
				<?php esc_html_e( 'view a product listing\'s page source and look for the CSS class zymarg-wcpg__card--zymarg on each card, plus a stylesheet with the id zymarg-os-branded-card-css. Markup without that stylesheet means the card is right but its CSS did not load.', 'zymarg-os' ); ?>
			</li>
			<li>
				<strong><?php esc_html_e( 'Developer notes:', 'zymarg-os' ); ?></strong>
				<?php esc_html_e( 'PRODUCT-CARD-OVERRIDE.md, shipped inside the ZYMARG Template Pack plugin folder, explains why this override exists, what does not work instead of it, and how to remove it once the engine routes every consumer through its card registry.', 'zymarg-os' ); ?>
			</li>
			<li>
				<strong><?php esc_html_e( 'Filters:', 'zymarg-os' ); ?></strong>
				<code>zymarg_os_use_branded_card</code>, <code>zymarg_os_branded_card_in_shop_loop</code>, <code>zymarg_os_branded_card_path</code>
			</li>
		</ul>
	</div>
	<?php
}
