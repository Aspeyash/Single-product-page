<?php
/**
 * My Account — custom multi-address book (Bangladesh, shipping only).
 *
 * Replaces WooCommerce's single billing/shipping address with a customer
 * address book: save multiple shipping addresses, set a default, edit/delete.
 * Country is fixed to Bangladesh (no country selector). Stored in user meta.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

const ZYMARG_OS_ADDRESSES_META = '_zymarg_addresses';

/**
 * Get the current customer's saved addresses.
 *
 * @param int $user_id Optional user ID (defaults to current).
 * @return array<int,array<string,mixed>>
 */
function zymarg_os_get_addresses( $user_id = 0 ) {
	$user_id = $user_id ? $user_id : get_current_user_id();
	$saved   = get_user_meta( $user_id, ZYMARG_OS_ADDRESSES_META, true );
	return is_array( $saved ) ? array_values( $saved ) : array();
}

/**
 * Persist the addresses array for a user.
 *
 * @param array $addresses Addresses.
 * @param int   $user_id   Optional user ID.
 * @return void
 */
function zymarg_os_save_addresses( $addresses, $user_id = 0 ) {
	$user_id = $user_id ? $user_id : get_current_user_id();
	update_user_meta( $user_id, ZYMARG_OS_ADDRESSES_META, array_values( $addresses ) );
}


/**
 * Handle add / edit / delete / set-default address form submissions.
 * Hooked to template_redirect so it runs before output and can redirect.
 *
 * @return void
 */
function zymarg_os_handle_address_actions() {
	if ( ! is_user_logged_in() || ! function_exists( 'is_account_page' ) || ! is_account_page() ) {
		return;
	}

	$account_url = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : home_url( '/my-account/' );
	$addr_url    = function_exists( 'wc_get_endpoint_url' ) ? wc_get_endpoint_url( 'edit-address', '', $account_url ) : $account_url;

	// ---- Delete -------------------------------------------------------
	if ( isset( $_GET['zymarg_delete_address'], $_GET['_zaddr_nonce'] )
		&& wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_zaddr_nonce'] ) ), 'zymarg_delete_address' ) ) {
		$id        = sanitize_text_field( wp_unslash( $_GET['zymarg_delete_address'] ) );
		$addresses = zymarg_os_get_addresses();
		$was_default = false;
		$addresses = array_values( array_filter( $addresses, function ( $a ) use ( $id, &$was_default ) {
			if ( $a['id'] === $id ) {
				$was_default = ! empty( $a['is_default'] );
				return false;
			}
			return true;
		} ) );
		// If we removed the default, promote the first remaining address.
		if ( $was_default && ! empty( $addresses ) ) {
			$addresses[0]['is_default'] = true;
		}
		zymarg_os_save_addresses( $addresses );
		zymarg_os_sync_default_to_wc( $addresses );
		wc_add_notice( __( 'Address removed.', 'zymarg-os' ) );
		zymarg_os_acc_redirect( $addr_url );
	}

	// ---- Set default --------------------------------------------------
	if ( isset( $_GET['zymarg_default_address'], $_GET['_zaddr_nonce'] )
		&& wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_zaddr_nonce'] ) ), 'zymarg_default_address' ) ) {
		$id        = sanitize_text_field( wp_unslash( $_GET['zymarg_default_address'] ) );
		$addresses = zymarg_os_get_addresses();
		foreach ( $addresses as &$a ) {
			$a['is_default'] = ( $a['id'] === $id );
		}
		unset( $a );
		zymarg_os_save_addresses( $addresses );
		zymarg_os_sync_default_to_wc( $addresses );
		wc_add_notice( __( 'Default address updated.', 'zymarg-os' ) );
		zymarg_os_acc_redirect( $addr_url );
	}

	// ---- Add / Edit (POST) -------------------------------------------
	if ( isset( $_POST['zymarg_save_address'], $_POST['_zaddr_nonce'] )
		&& wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_zaddr_nonce'] ) ), 'zymarg_save_address' ) ) {

		$name     = sanitize_text_field( wp_unslash( $_POST['z_name'] ?? '' ) );
		$phone    = sanitize_text_field( wp_unslash( $_POST['z_phone'] ?? '' ) );
		$addr1    = sanitize_text_field( wp_unslash( $_POST['z_address_1'] ?? '' ) );
		$area     = sanitize_text_field( wp_unslash( $_POST['z_area'] ?? '' ) );
		$city     = sanitize_text_field( wp_unslash( $_POST['z_city'] ?? '' ) );
		$postcode = sanitize_text_field( wp_unslash( $_POST['z_postcode'] ?? '' ) );
		$label    = sanitize_text_field( wp_unslash( $_POST['z_label'] ?? '' ) );
		$edit_id  = sanitize_text_field( wp_unslash( $_POST['z_edit_id'] ?? '' ) );

		// Basic validation.
		$errors = array();
		if ( '' === $name )     { $errors[] = __( 'Full name is required.', 'zymarg-os' ); }
		if ( '' === $phone )    { $errors[] = __( 'Phone number is required.', 'zymarg-os' ); }
		if ( '' === $addr1 )    { $errors[] = __( 'Address is required.', 'zymarg-os' ); }
		if ( '' === $city )     { $errors[] = __( 'District / City is required.', 'zymarg-os' ); }

		if ( ! empty( $errors ) ) {
			foreach ( $errors as $e ) {
				wc_add_notice( $e, 'error' );
			}
			return; // Stay on the form (errors shown above it).
		}

		$addresses = zymarg_os_get_addresses();

		$entry = array(
			'id'        => $edit_id ? $edit_id : 'addr_' . wp_generate_password( 8, false ),
			'label'     => $label,
			'name'      => $name,
			'phone'     => $phone,
			'address_1' => $addr1,
			'area'      => $area,
			'city'      => $city,
			'postcode'  => $postcode,
			'country'   => 'BD',
			'is_default'=> false,
		);

		if ( $edit_id ) {
			$found = false;
			foreach ( $addresses as &$a ) {
				if ( $a['id'] === $edit_id ) {
					$entry['is_default'] = ! empty( $a['is_default'] );
					$a = $entry;
					$found = true;
					break;
				}
			}
			unset( $a );
			if ( ! $found ) { $addresses[] = $entry; }
		} else {
			// First address becomes default automatically.
			if ( empty( $addresses ) ) {
				$entry['is_default'] = true;
			}
			$addresses[] = $entry;
		}

		zymarg_os_save_addresses( $addresses );
		zymarg_os_sync_default_to_wc( $addresses );
		wc_add_notice( $edit_id ? __( 'Address updated.', 'zymarg-os' ) : __( 'Address added.', 'zymarg-os' ) );
		zymarg_os_acc_redirect( $addr_url );
	}
}
add_action( 'template_redirect', 'zymarg_os_handle_address_actions', 5 );

/**
 * Sync the default address into WooCommerce shipping fields so checkout
 * pre-fills correctly. Billing country/postcode also set to BD so checkout
 * (which still needs billing internally) works without a country selector.
 *
 * @param array $addresses Addresses.
 * @return void
 */
function zymarg_os_sync_default_to_wc( $addresses ) {
	$user_id = get_current_user_id();
	$default = null;
	foreach ( $addresses as $a ) {
		if ( ! empty( $a['is_default'] ) ) {
			$default = $a;
			break;
		}
	}
	if ( ! $default && ! empty( $addresses ) ) {
		$default = $addresses[0];
	}
	if ( ! $default ) {
		return;
	}

	$parts = array_filter( array( $default['name'] ) );
	$first = $default['name'];
	$last  = '';
	if ( false !== strpos( $default['name'], ' ' ) ) {
		$bits  = explode( ' ', $default['name'], 2 );
		$first = $bits[0];
		$last  = $bits[1];
	}

	$map = array(
		'first_name' => $first,
		'last_name'  => $last,
		'address_1'  => $default['address_1'],
		'address_2'  => $default['area'],
		'city'       => $default['city'],
		'postcode'   => $default['postcode'],
		'country'    => 'BD',
		'phone'      => $default['phone'],
	);
	foreach ( $map as $key => $val ) {
		update_user_meta( $user_id, 'shipping_' . $key, $val );
		// Billing mirror (checkout needs billing internally).
		update_user_meta( $user_id, 'billing_' . $key, $val );
	}
}


/**
 * Render the address book section (called from account-sections.php).
 *
 * @return void
 */
function zymarg_os_render_address_book() {
	global $wp;
	$account_url = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : home_url( '/my-account/' );
	$addr_url    = function_exists( 'wc_get_endpoint_url' ) ? wc_get_endpoint_url( 'edit-address', '', $account_url ) : $account_url;

	$addresses = zymarg_os_get_addresses();

	// Determine if we're in add/edit mode.
	$editing   = isset( $_GET['zymarg_edit_address'] ) ? sanitize_text_field( wp_unslash( $_GET['zymarg_edit_address'] ) ) : '';
	$adding    = isset( $_GET['zymarg_add_address'] );
	$edit_data = array();
	if ( $editing ) {
		foreach ( $addresses as $a ) {
			if ( $a['id'] === $editing ) { $edit_data = $a; break; }
		}
	}

	echo '<div class="panel-header">';
	echo zymarg_os_account_icon( 'map-pin' ); // phpcs:ignore
	echo '<h2>' . esc_html__( 'Addresses', 'zymarg-os' ) . '</h2>';
	echo '</div>';

	if ( $adding || $editing ) {
		zymarg_os_render_address_form( $edit_data, $addr_url );
		return;
	}

	echo '<p class="panel-desc">' . esc_html__( 'Save one or more delivery addresses for faster checkout.', 'zymarg-os' ) . '</p>';

	echo '<a class="btn btn-primary zymarg-addr-add" href="' . esc_url( add_query_arg( 'zymarg_add_address', '1', $addr_url ) ) . '">+ ' . esc_html__( 'Add New Address', 'zymarg-os' ) . '</a>';

	if ( empty( $addresses ) ) {
		echo '<div class="empty-state">';
		echo zymarg_os_account_icon( 'map-pin' ); // phpcs:ignore
		echo '<p>' . esc_html__( 'No addresses saved yet. Add your first delivery address.', 'zymarg-os' ) . '</p>';
		echo '</div>';
		return;
	}

	echo '<div class="zymarg-addr-grid">';
	foreach ( $addresses as $a ) {
		$del_url = wp_nonce_url( add_query_arg( 'zymarg_delete_address', $a['id'], $addr_url ), 'zymarg_delete_address', '_zaddr_nonce' );
		$def_url = wp_nonce_url( add_query_arg( 'zymarg_default_address', $a['id'], $addr_url ), 'zymarg_default_address', '_zaddr_nonce' );
		$edit_link = add_query_arg( 'zymarg_edit_address', $a['id'], $addr_url );

		echo '<div class="zymarg-addr-card' . ( ! empty( $a['is_default'] ) ? ' is-default' : '' ) . '">';
		if ( ! empty( $a['is_default'] ) ) {
			echo '<span class="zymarg-addr-badge">' . esc_html__( 'Default', 'zymarg-os' ) . '</span>';
		}
		if ( ! empty( $a['label'] ) ) {
			echo '<div class="zymarg-addr-label">' . esc_html( $a['label'] ) . '</div>';
		}
		echo '<div class="zymarg-addr-name">' . esc_html( $a['name'] ) . '</div>';
		echo '<div class="zymarg-addr-lines">';
		echo esc_html( $a['address_1'] );
		if ( ! empty( $a['area'] ) ) { echo ', ' . esc_html( $a['area'] ); }
		echo '<br>' . esc_html( $a['city'] );
		if ( ! empty( $a['postcode'] ) ) { echo ' - ' . esc_html( $a['postcode'] ); }
		echo '<br>' . esc_html__( 'Bangladesh', 'zymarg-os' );
		echo '<br>' . esc_html__( 'Phone:', 'zymarg-os' ) . ' ' . esc_html( $a['phone'] );
		echo '</div>';
		echo '<div class="zymarg-addr-actions">';
		echo '<a class="btn btn-outline btn-sm" href="' . esc_url( $edit_link ) . '">' . esc_html__( 'Edit', 'zymarg-os' ) . '</a>';
		if ( empty( $a['is_default'] ) ) {
			echo '<a class="btn btn-outline btn-sm" href="' . esc_url( $def_url ) . '">' . esc_html__( 'Set as default', 'zymarg-os' ) . '</a>';
		}
		echo '<a class="btn btn-danger btn-sm" href="' . esc_url( $del_url ) . '" onclick="return confirm(\'' . esc_js( __( 'Delete this address?', 'zymarg-os' ) ) . '\')">' . esc_html__( 'Delete', 'zymarg-os' ) . '</a>';
		echo '</div>';
		echo '</div>';
	}
	echo '</div>';
}

/**
 * Render the add/edit address form (Bangladesh, no country selector).
 *
 * @param array  $data     Existing address data when editing.
 * @param string $addr_url The addresses endpoint URL.
 * @return void
 */
function zymarg_os_render_address_form( $data, $addr_url ) {
	$is_edit = ! empty( $data );
	$val = function ( $k ) use ( $data ) { return isset( $data[ $k ] ) ? $data[ $k ] : ''; };
	?>
	<p class="panel-desc"><?php echo $is_edit ? esc_html__( 'Edit your delivery address.', 'zymarg-os' ) : esc_html__( 'Add a new delivery address.', 'zymarg-os' ); ?></p>
	<form method="post" class="zymarg-addr-form" data-zym-ajax="address" style="max-width:480px">
		<?php wp_nonce_field( 'zymarg_save_address', '_zaddr_nonce' ); ?>
		<input type="hidden" name="zymarg_save_address" value="1">
		<input type="hidden" name="z_edit_id" value="<?php echo esc_attr( $val( 'id' ) ); ?>">

		<div class="form-group">
			<label><?php esc_html_e( 'Label (e.g. Home, Office)', 'zymarg-os' ); ?></label>
			<input type="text" name="z_label" value="<?php echo esc_attr( $val( 'label' ) ); ?>" placeholder="<?php esc_attr_e( 'Home', 'zymarg-os' ); ?>">
		</div>
		<div class="form-group">
			<label><?php esc_html_e( 'Full Name', 'zymarg-os' ); ?> *</label>
			<input type="text" name="z_name" value="<?php echo esc_attr( $val( 'name' ) ); ?>" required>
		</div>
		<div class="form-group">
			<label><?php esc_html_e( 'Phone Number', 'zymarg-os' ); ?> *</label>
			<input type="tel" name="z_phone" value="<?php echo esc_attr( $val( 'phone' ) ); ?>" placeholder="01XXXXXXXXX" required>
		</div>
		<div class="form-group">
			<label><?php esc_html_e( 'Address (House, Road, Block)', 'zymarg-os' ); ?> *</label>
			<input type="text" name="z_address_1" value="<?php echo esc_attr( $val( 'address_1' ) ); ?>" required>
		</div>
		<div class="form-group">
			<label><?php esc_html_e( 'Area / Thana', 'zymarg-os' ); ?></label>
			<input type="text" name="z_area" value="<?php echo esc_attr( $val( 'area' ) ); ?>">
		</div>
		<div class="form-group">
			<label><?php esc_html_e( 'District / City', 'zymarg-os' ); ?> *</label>
			<input type="text" name="z_city" value="<?php echo esc_attr( $val( 'city' ) ); ?>" required>
		</div>
		<div class="form-group">
			<label><?php esc_html_e( 'Postcode', 'zymarg-os' ); ?></label>
			<input type="text" name="z_postcode" value="<?php echo esc_attr( $val( 'postcode' ) ); ?>">
		</div>
		<div class="form-group">
			<label><?php esc_html_e( 'Country', 'zymarg-os' ); ?></label>
			<input type="text" value="<?php esc_attr_e( 'Bangladesh', 'zymarg-os' ); ?>" disabled>
		</div>

		<div style="display:flex;gap:10px;margin-top:8px">
			<button type="submit" class="btn btn-primary"><?php echo $is_edit ? esc_html__( 'Update Address', 'zymarg-os' ) : esc_html__( 'Save Address', 'zymarg-os' ); ?></button>
			<a class="btn btn-outline" href="<?php echo esc_url( $addr_url ); ?>"><?php esc_html_e( 'Cancel', 'zymarg-os' ); ?></a>
		</div>
	</form>
	<?php
}
