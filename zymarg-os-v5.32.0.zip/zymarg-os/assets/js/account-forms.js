/**
 * ZYMARG OS — My Account AJAX form layer.
 *
 * WHAT THIS FIXES
 *
 * Navigating the account dashboard was already instant (assets/js/account.js
 * swaps sections over AJAX), but every Save / Update button was still a plain
 * form POST: white flash, full rebuild, scroll jumped to the top and every
 * accordion card the customer had open slammed shut. Saving one phone number
 * cost a whole page.
 *
 * Now each form posts to `wp_ajax_zymarg_acc_form`, which runs the very same
 * PHP handler the classic POST used to hit, then answers with freshly
 * rendered section HTML plus its notices. We swap that HTML in and fire the
 * notices as toasts.
 *
 * DESIGN NOTES
 *
 * - Progressive enhancement: with JS off, or on any transport/HTTP failure,
 *   we fall back to the browser's native submit, so the old flow still works
 *   and a save is never silently lost.
 * - Delegated from `document`: section HTML is replaced wholesale on every
 *   swap, so listeners bound to a form would die on the first navigation.
 * - Forms opt in with `data-zym-ajax="<form key>"`, matching the PHP registry
 *   in inc/account-ajax-forms.php. Anything unmarked keeps posting normally.
 * - Address delete / set-default are GET links carrying a nonce, so those are
 *   intercepted too — otherwise the address book would still reload.
 * - `data-zym-ajax="delete"` ends the session on purpose; that one is allowed
 *   to navigate, because there is no account left to render.
 *
 * Plain ES5-safe JavaScript, no jQuery, matching the rest of assets/js.
 */
( function () {
	'use strict';

	var ACC = window.ZymargAccount || {};
	var SPA = window.ZymargAccountSPA || null;

	/* Address actions that arrive as nonce-carrying GET links. */
	var GET_ACTIONS = [ 'zymarg_delete_address', 'zymarg_default_address' ];

	function closest( el, selector ) {
		while ( el && 1 === el.nodeType ) {
			if ( el.matches ? el.matches( selector ) : el.msMatchesSelector( selector ) ) {
				return el;
			}
			el = el.parentNode;
		}
		return null;
	}

	function canAjax() {
		return !! ( ACC.ajaxUrl && ACC.formNonce && window.fetch && window.FormData );
	}

	/* ── Notices → toasts ───────────────────────────────────────────────
	 * The account page template is what prints Woo notices, and an AJAX
	 * section swap never re-runs it — so the server hands us the notices as
	 * data and we surface them through the theme's toast system instead.
	 * If toasts are switched off we fall back to inline notice markup so
	 * feedback is never lost, only relocated.
	 * ----------------------------------------------------------------- */
	function announce( notices, container ) {
		if ( ! notices || ! notices.length ) {
			return;
		}

		var toast = window.ZymargToast;

		if ( toast && toast.show ) {
			notices.forEach( function ( n ) {
				toast.show( { message: n.message, type: n.type || 'info', source: 'Account' } );
			} );
			return;
		}

		var target = container || document.querySelector( '.zymarg-acc-main .main-content' );
		if ( ! target ) {
			return;
		}

		var wrap = document.createElement( 'div' );
		wrap.className = 'zym-notices';
		notices.forEach( function ( n ) {
			var div = document.createElement( 'div' );
			div.className = 'zym-notice zym-notice--' + ( n.type || 'info' );
			div.textContent = n.message;
			wrap.appendChild( div );
		} );
		target.insertBefore( wrap, target.firstChild );
	}

	/* ── Pending state on the clicked button ───────────────────────────── */
	function busy( form, on ) {
		var buttons = form.querySelectorAll( 'button[type="submit"], input[type="submit"]' );

		for ( var i = 0; i < buttons.length; i++ ) {
			var b = buttons[ i ];

			if ( on ) {
				b.disabled = true;
				b.classList.add( 'is-busy' );
				b.setAttribute( 'aria-busy', 'true' );

				if ( ACC.savingText && null === b.getAttribute( 'data-zym-label' ) ) {
					b.setAttribute( 'data-zym-label', b.innerHTML );
					b.innerHTML = ACC.savingText;
				}
			} else {
				b.disabled = false;
				b.classList.remove( 'is-busy' );
				b.removeAttribute( 'aria-busy' );

				var label = b.getAttribute( 'data-zym-label' );
				if ( null !== label ) {
					b.innerHTML = label;
					b.removeAttribute( 'data-zym-label' );
				}
			}
		}
	}

	/**
	 * Serialise a form the way a browser would, including the submitter so
	 * named submit buttons keep working.
	 */
	function serialize( form, submitter ) {
		var data = new FormData( form );

		if ( submitter && submitter.name && ! data.has( submitter.name ) ) {
			data.append( submitter.name, submitter.value || '' );
		}

		var params = new URLSearchParams();
		data.forEach( function ( value, key ) {
			// Files cannot ride along in a URL-encoded payload. No account form
			// uploads anything (the avatar has its own AJAX flow in
			// avatar-upload.js), so skipping them is safe and keeps the
			// transport simple.
			if ( 'string' === typeof value ) {
				params.append( key, value );
			}
		} );

		return params.toString();
	}

	function currentSection() {
		if ( SPA && SPA.activeKey ) {
			return SPA.activeKey() || '';
		}

		var link = document.querySelector( '.zymarg-acc-sidebar .nav-link.active' );
		return link ? ( link.getAttribute( 'data-nav' ) || '' ) : '';
	}

	/**
	 * Send one account write to the server.
	 *
	 * @param {Object}   opts          Request description.
	 * @param {string}   opts.form     Form key from the PHP registry.
	 * @param {string}   opts.payload  URL-encoded fields.
	 * @param {string}   opts.method   'post' or 'get'.
	 * @param {Function} opts.fallback Native behaviour to run if AJAX fails.
	 * @param {Function} opts.done     Always called when the request settles.
	 */
	function submit( opts ) {
		var body = new URLSearchParams();
		body.set( 'action', 'zymarg_acc_form' );
		body.set( 'nonce', ACC.formNonce );
		body.set( 'form', opts.form );
		body.set( 'method', opts.method || 'post' );
		body.set( 'payload', opts.payload || '' );
		body.set( 'section', currentSection() );

		fetch( ACC.ajaxUrl, {
			method: 'POST',
			body: body,
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' }
		} )
			.then( function ( r ) { return r.json(); } )
			.then( function ( res ) {
				if ( ! res || ! res.success || ! res.data ) {
					throw new Error( 'zymarg_acc_form_failed' );
				}

				var data = res.data;

				// A re-rendered section can need files the page never loaded (a
				// plugin panel's own stylesheet, for one). Add them before the
				// swap so the new markup is never shown unstyled.
				if ( SPA && SPA.injectAssets ) {
					SPA.injectAssets( data.assets );
				}

				// Deleting the account ends the session: a real navigation is
				// the honest outcome here, not an in-place swap.
				if ( data.redirect ) {
					window.location.href = data.redirect;
					return;
				}

				if ( data.html && SPA && SPA.swap ) {
					// The section markup changed, so the prefetch cache for it is
					// now stale — refresh it rather than dropping it, so going
					// away and coming back still shows the saved values.
					SPA.swap( data.html, { keepScroll: true } );
					if ( SPA.setCache && data.section ) {
						SPA.setCache( data.section, data.html );
					}
				} else if ( data.html ) {
					var main = document.querySelector( '.zymarg-acc-main .main-content' );
					if ( main ) {
						main.innerHTML = data.html;
					}
				}

				// A password change signs other devices out and rotates nonces
				// elsewhere on the page; every other section's cached HTML may
				// also be out of date after a write.
				if ( SPA && SPA.invalidate ) {
					SPA.invalidate( { except: data.section } );
				}

				announce( data.notices );

				if ( opts.done ) { opts.done(); }
			} )
			.catch( function () {
				if ( opts.done ) { opts.done(); }

				// Never strand a save. Hand the request back to the browser and
				// let the classic PHP round trip finish the job.
				if ( opts.fallback ) { opts.fallback(); }
			} );
	}

	/* ── Form submits ──────────────────────────────────────────────────── */
	document.addEventListener( 'submit', function ( event ) {
		var form = event.target;

		if ( ! form || 'FORM' !== form.nodeName ) {
			return;
		}

		var key = form.getAttribute( 'data-zym-ajax' );

		if ( ! key || ! canAjax() ) {
			return; // Unmarked form, or no transport: classic POST.
		}

		// Respect the browser's own validation before we take over.
		if ( form.checkValidity && ! form.noValidate && ! form.checkValidity() ) {
			return;
		}

		event.preventDefault();
		busy( form, true );

		submit( {
			form: key,
			method: 'post',
			payload: serialize( form, event.submitter ),
			done: function () { busy( form, false ); },
			fallback: function () {
				if ( ACC.errorText && window.ZymargToast ) {
					window.ZymargToast.error( ACC.errorText, { source: 'Account' } );
				}
				// HTMLFormElement.submit() deliberately skips this listener.
				form.submit();
			}
		} );
	}, false );

	/* ── Nonce-carrying GET action links (address book) ─────────────────── */
	document.addEventListener( 'click', function ( event ) {
		if ( event.metaKey || event.ctrlKey || event.shiftKey || ( event.button && 0 !== event.button ) ) {
			return;
		}

		var link = closest( event.target, '.zymarg-acc-main a[href]' );

		if ( ! link || ! canAjax() ) {
			return;
		}

		var href = link.getAttribute( 'href' ) || '';
		var match = null;

		for ( var i = 0; i < GET_ACTIONS.length; i++ ) {
			if ( href.indexOf( GET_ACTIONS[ i ] + '=' ) > -1 ) {
				match = GET_ACTIONS[ i ];
				break;
			}
		}

		if ( ! match ) {
			return;
		}

		var query = href.indexOf( '?' ) > -1 ? href.slice( href.indexOf( '?' ) + 1 ) : '';

		if ( ! query ) {
			return;
		}

		event.preventDefault();
		link.classList.add( 'is-busy' );

		submit( {
			form: 'address',
			method: 'get',
			payload: query,
			done: function () { link.classList.remove( 'is-busy' ); },
			fallback: function () { window.location.href = link.href; }
		} );
	}, false );
}() );
