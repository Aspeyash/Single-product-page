/**
 * ZYMARG OS — save settings screens without reloading.
 *
 * WHY THIS EXISTS
 *   Slugs & Pages already saved over AJAX (assets/js/admin-registry.js) while
 *   Product Card, Account & Security and Toast Notification still posted the
 *   whole page. Same menu, three different behaviours — which is why the reload
 *   read as a bug. This is one script for all of them, driven by config, so the
 *   behaviour cannot drift apart again.
 *
 * HOW
 *   Deliberately the same shape as admin-registry.js: FormData is built from the
 *   real form, so every field the PHP saver already reads is sent under the name
 *   it already expects — including the screen's own nonce. The AJAX payload and
 *   a normal post are the same shape, so the server keeps a single save path.
 *
 * WHAT IT DELIBERATELY DOES NOT BIND
 *   Only the form carrying cfg.nonceField, and on Toast only the source-saving
 *   form. Buttons that must rebuild the screen (Scan Plugins, Clear Log) and the
 *   flows that perform real uploads (Upload Theme, Plugins, Import / Export)
 *   keep posting normally, on purpose.
 *
 * FAILURE BEHAVIOUR
 *   If fetch or FormData is missing the handler is never bound and the browser
 *   posts the form the old way, so Save always works. On a failed request the
 *   values stay on screen and the message invites a retry — nothing is lost.
 *
 * SPA AWARE
 *   The admin router (assets/js/admin-spa.js) swaps #wpbody-content, destroying
 *   the form this bound to. Re-initialising on 'zymarg:admin-screen' keeps AJAX
 *   save working after sidebar navigation, as admin-customer-console.js does.
 *
 * @package ZYMARG_OS
 */

( function () {
	'use strict';

	var cfg = window.ZymargAjaxSave || {};

	/**
	 * Is this the form the screen's PHP saver actually reads?
	 */
	function isTarget( form ) {
		if ( ! form.querySelector( '[name="' + cfg.nonceField + '"]' ) ) {
			return false;
		}

		// Toast renders three forms sharing one nonce; the hidden action field is
		// the only thing that tells the settings form from Scan and Clear Log.
		if ( cfg.requireName ) {
			var marker = form.querySelector( '[name="' + cfg.requireName + '"]' );

			if ( ! marker || marker.value !== cfg.requireValue ) {
				return false;
			}
		}

		return true;
	}

	function bind( form ) {
		if ( form.getAttribute( 'data-zymarg-ajax-save' ) ) {
			return;
		}

		form.setAttribute( 'data-zymarg-ajax-save', '1' );

		var busy   = false;
		var status = document.createElement( 'p' );

		status.className = 'zymarg-save__status';
		status.hidden    = true;
		status.setAttribute( 'role', 'status' );
		status.setAttribute( 'aria-live', 'polite' );
		form.appendChild( status );

		function say( message, state ) {
			status.hidden      = ! message;
			status.textContent = message || '';
			status.setAttribute( 'data-state', state || '' );
		}

		form.addEventListener( 'submit', function ( event ) {
			event.preventDefault();

			if ( busy ) {
				return;
			}

			busy = true;

			var button = form.querySelector( '[type="submit"]' );

			if ( button ) {
				button.disabled = true;
			}

			say( cfg.saving, 'busy' );

			var data = new FormData( form );

			data.set( 'action', cfg.action );
			data.set( 'nonce', cfg.nonce );

			window.fetch( cfg.ajaxUrl, {
				method:      'POST',
				credentials: 'same-origin',
				body:        data
			} )
				.then( function ( response ) {
					return response.json();
				} )
				.then( function ( payload ) {
					if ( ! payload || ! payload.success ) {
						var problem = payload && payload.data && payload.data.message
							? payload.data.message
							: cfg.failed;

						say( problem, 'bad' );

						return;
					}

					say( payload.data && payload.data.message ? payload.data.message : cfg.saved, 'ok' );
				} )
				.catch( function () {
					// Values are all still in the form, so a retry costs nothing.
					say( cfg.failed, 'bad' );
				} )
				.then( function () {
					busy = false;

					if ( button ) {
						button.disabled = false;
					}
				} );
		} );
	}

	function init() {
		if ( ! cfg.ajaxUrl || ! cfg.action || ! cfg.nonceField ) {
			return;
		}

		if ( typeof window.fetch !== 'function' || ! window.FormData ) {
			return;
		}

		var forms = document.querySelectorAll( '.wrap.zymarg-admin form[method="post"]' );

		for ( var i = 0; i < forms.length; i++ ) {
			if ( isTarget( forms[ i ] ) ) {
				bind( forms[ i ] );
			}
		}
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}

	document.addEventListener( 'zymarg:admin-screen', init );
}() );
