/**
 * ZYMARG OS - Slugs & Pages save
 *
 * Saves the screen over admin-ajax.php so pressing Save no longer reloads the
 * page. Progressive enhancement on purpose: the form still has its method,
 * action and hidden fields, so with JavaScript unavailable or broken the
 * browser posts it normally and the PHP handler answers exactly as before.
 * Nothing on this screen depends on this file to work.
 *
 * @package ZYMARG_OS
 * @since   5.20.0
 */
( function () {
	'use strict';

	if ( typeof ZymargRegistry === 'undefined' || ! ZymargRegistry.ajaxUrl ) {
		return;
	}

	var form = document.querySelector( '[data-registry-form]' );

	if ( ! form ) {
		return;
	}

	var status = form.querySelector( '[data-registry-status]' );
	var busy   = false;

	/**
	 * Show a message in the live region.
	 *
	 * The region is aria-live, so a screen reader announces the result of the
	 * save. Without it an AJAX save is silent to anyone not watching the button.
	 *
	 * @param {string} text  Message.
	 * @param {string} state 'ok' | 'bad' | 'busy'.
	 */
	function say( text, state ) {
		if ( ! status ) {
			return;
		}

		status.textContent = text;
		status.className   = 'zymarg-registry__status is-' + state;
	}

	/**
	 * Refresh the saved-state pill and the count in each group summary, so the
	 * screen tells the truth after a save without being reloaded.
	 */
	function refreshStates() {
		var total = 0;

		Array.prototype.forEach.call(
			form.querySelectorAll( 'details.zymarg-registry__group' ),
			function ( group ) {
				var off = 0;

				Array.prototype.forEach.call(
					group.querySelectorAll( 'tbody tr' ),
					function ( row ) {
						var box  = row.querySelector( 'input[type="checkbox"]' );
						var pick = row.querySelector( 'select' );
						var pill = row.querySelector( '.zymarg-registry__state' );

						if ( ! box ) {
							return;
						}

						var on = box.checked;

						if ( ! on ) {
							off++;
							total++;
						}

						if ( ! pill ) {
							return;
						}

						var is404 = pick && '404' === pick.value;

						pill.className = 'zymarg-registry__state ' + ( on ? 'is-live' : ( is404 ? 'is-gone' : 'is-moved' ) );
						pill.textContent = on
							? ( pill.getAttribute( 'data-live' ) || pill.textContent )
							: ( is404
								? ( pill.getAttribute( 'data-gone' ) || pill.textContent )
								: ( pill.getAttribute( 'data-moved' ) || pill.textContent ) );
					}
				);

				var badge = group.querySelector( 'summary .zymarg-registry__state' );

				if ( badge ) {
					badge.hidden = 0 === off;
				}
			}
		);

		return total;
	}

	form.addEventListener( 'submit', function ( event ) {
		// Nothing to intercept if fetch is missing - let the browser post it.
		if ( typeof window.fetch !== 'function' ) {
			return;
		}

		event.preventDefault();

		if ( busy ) {
			return;
		}

		busy = true;

		var button = form.querySelector( '[type="submit"]' );

		if ( button ) {
			button.disabled = true;
		}

		say( ZymargRegistry.saving, 'busy' );

		/*
		 * FormData over the real form: every field the PHP handler already reads
		 * is sent under the name it already expects, including the 404 design
		 * boxes, so the AJAX payload and a normal post are the same shape.
		 */
		var data = new FormData( form );

		data.set( 'action', 'zymarg_os_registry_save' );
		data.set( 'nonce', ZymargRegistry.nonce );

		window.fetch( ZymargRegistry.ajaxUrl, {
			method:      'POST',
			credentials: 'same-origin',
			body:        data
		} )
			.then( function ( response ) {
				return response.json();
			} )
			.then( function ( payload ) {
				if ( ! payload || ! payload.success ) {
					var problem = payload && payload.data && payload.data.message
						? payload.data.message
						: ZymargRegistry.failed;

					say( problem, 'bad' );

					return;
				}

				refreshStates();
				say( payload.data.message, 'ok' );
			} )
			.catch( function () {
				// The values are all still in the form, so a retry costs nothing.
				say( ZymargRegistry.failed, 'bad' );
			} )
			.then( function () {
				busy = false;

				if ( button ) {
					button.disabled = false;
				}
			} );
	} );
}() );
