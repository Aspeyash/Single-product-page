/**
 * ZYMARG OS — Account accordion behaviour.
 *
 * Mirrors ZYMARG Vendor Dashboard's Settings Hub interaction model:
 *   - click a numbered header to expand / collapse
 *   - on narrow screens only one card stays open at a time
 *   - password eye toggles, live strength meter, confirm-match feedback
 *   - email-change reveal / cancel
 *
 * ARCHITECTURE NOTE — why every handler is delegated from `document`:
 *
 * The My Account page is a small SPA. assets/js/account.js swaps each
 * section in with `main.innerHTML = html` over AJAX when the customer picks
 * an item in the sidebar. Any listener bound directly to a card at page load
 * is destroyed the instant that swap happens, so the accordion headers stop
 * responding — they only ever worked if the accordion section happened to be
 * the one the server rendered first.
 *
 * Delegating from `document` means the handlers survive every swap, forever,
 * with no re-init hook needed from account.js. A MutationObserver restores
 * remembered open-state on freshly injected markup.
 *
 * Plain ES5-safe JavaScript, no jQuery, matching the rest of assets/js.
 */
( function () {
	'use strict';

	var MOBILE_QUERY   = '(max-width: 782px)';
	var STORAGE_PREFIX = 'zymAcc:';

	function isMobile() {
		return window.matchMedia && window.matchMedia( MOBILE_QUERY ).matches;
	}

	/**
	 * Element.closest() with a guard for older browsers.
	 */
	function closest( el, selector ) {
		while ( el && 1 === el.nodeType ) {
			if ( el.matches ? el.matches( selector ) : el.msMatchesSelector( selector ) ) {
				return el;
			}
			el = el.parentNode;
		}
		return null;
	}

	function remember( context, key, open ) {
		try {
			if ( open ) {
				window.sessionStorage.setItem( STORAGE_PREFIX + context, key );
			} else if ( window.sessionStorage.getItem( STORAGE_PREFIX + context ) === key ) {
				window.sessionStorage.removeItem( STORAGE_PREFIX + context );
			}
		} catch ( e ) {
			/* Private mode: remembering is a nicety, never a requirement. */
		}
	}

	function recall( context ) {
		try {
			return window.sessionStorage.getItem( STORAGE_PREFIX + context );
		} catch ( e ) {
			return null;
		}
	}

	function setCard( card, open, context ) {
		var toggle = card.querySelector( '.zym-acc-card__toggle' );

		if ( open ) {
			card.classList.add( 'is-open' );
		} else {
			card.classList.remove( 'is-open' );
		}

		if ( toggle ) {
			toggle.setAttribute( 'aria-expanded', open ? 'true' : 'false' );
		}

		if ( context ) {
			remember( context, card.getAttribute( 'data-zym-acc-card' ), open );
		}
	}

	/* ==================================================================
	   1. ACCORDION — delegated click
	   ================================================================== */

	function handleAccordionClick( toggle ) {
		var card = closest( toggle, '.zym-acc-card' );

		if ( ! card ) {
			return;
		}

		var root    = closest( card, '.zym-acc' );
		var context = root ? ( root.getAttribute( 'data-zym-acc' ) || 'default' ) : '';
		var willOpen = ! card.classList.contains( 'is-open' );

		// On a phone, keep exactly one card open so the customer is never
		// scrolling through six expanded panels to reach the save button.
		if ( willOpen && root && isMobile() ) {
			var siblings = root.querySelectorAll( '.zym-acc-card.is-open' );

			for ( var i = 0; i < siblings.length; i++ ) {
				if ( siblings[ i ] !== card ) {
					setCard( siblings[ i ], false, context );
				}
			}
		}

		setCard( card, willOpen, context );
	}

	/* ==================================================================
	   2. PASSWORD EYE TOGGLE — delegated click
	   ================================================================== */

	function handleEyeToggle( btn ) {
		// The input is the toggle's sibling inside .zym-pw-wrap. Using
		// parentNode rather than closest('.zym-pw-wrap') keeps this working
		// even if the wrapper class is ever renamed in CSS.
		var wrap  = btn.parentNode;
		var input = wrap ? wrap.querySelector( 'input' ) : null;

		if ( ! input ) {
			return;
		}

		var showing = 'text' === input.getAttribute( 'type' );

		input.setAttribute( 'type', showing ? 'password' : 'text' );
		btn.classList.toggle( 'is-showing', ! showing );
		btn.setAttribute( 'aria-label', showing ? 'Show password' : 'Hide password' );
		// The icon swap is CSS, keyed off `.is-showing` above. aria-pressed keeps
		// screen readers in step with the glyph sighted users see.
		btn.setAttribute( 'aria-pressed', showing ? 'false' : 'true' );

		// Keep the caret where the customer left it.
		try {
			input.focus();
			input.setSelectionRange( input.value.length, input.value.length );
		} catch ( e ) {
			/* Some input types refuse setSelectionRange; harmless. */
		}
	}

	/* ==================================================================
	   3. PASSWORD STRENGTH + MATCH — delegated input
	   ================================================================== */

	function scorePassword( value, min ) {
		var score = 0;

		if ( ! value ) {
			return 0;
		}

		if ( value.length >= min ) {
			score++;
		}
		if ( value.length >= min + 4 ) {
			score++;
		}
		if ( /[a-z]/.test( value ) && /[A-Z]/.test( value ) ) {
			score++;
		}
		if ( /[0-9]/.test( value ) ) {
			score++;
		}
		if ( /[^A-Za-z0-9]/.test( value ) ) {
			score++;
		}

		return Math.min( score, 4 );
	}

	function handleStrength( input ) {
		var form = closest( input, 'form' );
		var meter = form ? form.querySelector( '[data-zym-strength]' ) : null;

		if ( ! meter ) {
			return;
		}

		var min   = parseInt( input.getAttribute( 'data-zym-min' ), 10 ) || 8;
		var value = input.value;
		var bar   = meter.querySelector( '.zym-strength__bar > span' );
		var label = meter.querySelector( '.zym-strength__label' );

		if ( ! value ) {
			meter.hidden = true;
			return;
		}

		meter.hidden = false;

		var score   = scorePassword( value, min );
		var states  = [ 'is-weak', 'is-weak', 'is-fair', 'is-good', 'is-strong' ];
		var words   = [ 'Too weak', 'Weak', 'Fair', 'Good', 'Strong' ];
		var widths  = [ 12, 25, 50, 75, 100 ];

		meter.classList.remove( 'is-weak', 'is-fair', 'is-good', 'is-strong' );
		meter.classList.add( states[ score ] );

		if ( bar ) {
			bar.style.width = widths[ score ] + '%';
		}
		if ( label ) {
			label.textContent = value.length < min
				? ( 'At least ' + min + ' characters' )
				: words[ score ];
		}

		// Re-run the match check: typing in the first field changes the answer.
		var confirmField = form.querySelector( '[data-zym-pw-confirm]' );

		if ( confirmField && confirmField.value ) {
			handleMatch( confirmField );
		}
	}

	function handleMatch( confirmField ) {
		var form = closest( confirmField, 'form' );
		var out  = form ? form.querySelector( '[data-zym-pw-match]' ) : null;
		var main = form ? form.querySelector( '[data-zym-pw-strength]' ) : null;

		if ( ! out || ! main ) {
			return;
		}

		if ( ! confirmField.value ) {
			out.hidden = true;
			return;
		}

		var ok = confirmField.value === main.value;

		out.hidden = false;
		out.classList.toggle( 'is-ok', ok );
		out.classList.toggle( 'is-bad', ! ok );
		out.textContent = ok ? 'Passwords match' : 'Passwords do not match yet';
	}

	/* ==================================================================
	   4. EMAIL CHANGE REVEAL — delegated click
	   ================================================================== */

	function handleEmailToggle( btn, show ) {
		var block = closest( btn, '.zym-email-block' );
		var form  = block ? block.querySelector( '[data-zym-email-form]' ) : null;

		if ( ! form ) {
			return;
		}

		form.hidden = ! show;
		btn.hidden  = show;

		if ( show ) {
			var first = form.querySelector( 'input' );
			if ( first ) {
				first.focus();
			}
		} else {
			var opener = block.querySelector( '[data-zym-email-toggle]' );
			if ( opener ) {
				opener.hidden = false;
			}
		}
	}

	/* ==================================================================
	   5. DELEGATED LISTENERS (bound once, for the life of the page)
	   ================================================================== */

	document.addEventListener( 'click', function ( event ) {
		var target = event.target;

		var accToggle = closest( target, '.zym-acc-card__toggle' );
		if ( accToggle ) {
			event.preventDefault();
			handleAccordionClick( accToggle );
			return;
		}

		var eye = closest( target, '[data-zym-pw-toggle]' );
		if ( eye ) {
			event.preventDefault();
			handleEyeToggle( eye );
			return;
		}

		var emailOpen = closest( target, '[data-zym-email-toggle]' );
		if ( emailOpen ) {
			event.preventDefault();
			handleEmailToggle( emailOpen, true );
			return;
		}

		var emailCancel = closest( target, '[data-zym-email-cancel]' );
		if ( emailCancel ) {
			event.preventDefault();
			handleEmailToggle( emailCancel, false );
		}
	}, false );

	document.addEventListener( 'input', function ( event ) {
		var target = event.target;

		if ( ! target || ! target.getAttribute ) {
			return;
		}

		if ( null !== target.getAttribute( 'data-zym-pw-strength' ) ) {
			handleStrength( target );
			return;
		}

		if ( null !== target.getAttribute( 'data-zym-pw-confirm' ) ) {
			handleMatch( target );
		}
	}, false );

	/* ==================================================================
	   6. RESTORE OPEN STATE ON FRESHLY INJECTED MARKUP
	   ================================================================== */

	function restore( root ) {
		if ( ! root || root.getAttribute( 'data-zym-acc-ready' ) ) {
			return;
		}

		root.setAttribute( 'data-zym-acc-ready', '1' );

		var context = root.getAttribute( 'data-zym-acc' ) || 'default';
		var saved   = recall( context );

		if ( ! saved ) {
			return;
		}

		var target = root.querySelector( '[data-zym-acc-card="' + saved + '"]' );

		if ( ! target ) {
			return;
		}

		if ( isMobile() ) {
			var open = root.querySelectorAll( '.zym-acc-card.is-open' );
			for ( var i = 0; i < open.length; i++ ) {
				if ( open[ i ] !== target ) {
					setCard( open[ i ], false, '' );
				}
			}
		}

		setCard( target, true, '' );
	}

	function scan( scope ) {
		var roots = ( scope || document ).querySelectorAll( '.zym-acc' );

		for ( var i = 0; i < roots.length; i++ ) {
			restore( roots[ i ] );
		}
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', function () {
			scan( document );
		} );
	} else {
		scan( document );
	}

	// Catch accordions injected by the account page's AJAX section swap.
	if ( window.MutationObserver ) {
		new window.MutationObserver( function ( mutations ) {
			for ( var i = 0; i < mutations.length; i++ ) {
				if ( mutations[ i ].addedNodes.length ) {
					scan( document );
					return;
				}
			}
		} ).observe( document.body, { childList: true, subtree: true } );
	}
}() );
