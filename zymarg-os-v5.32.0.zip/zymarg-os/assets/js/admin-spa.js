/**
 * ZYMARG OS — wp-admin sidebar AJAX navigation.
 *
 * WHAT THIS DOES
 *   WordPress's admin menu is a list of ordinary links, so every ZYMARG OS
 *   screen was a full page load. This intercepts clicks on the ZYMARG OS
 *   submenu, fetches the target screen, and swaps #wpbody-content in place —
 *   the same idea as the front-end My Account dashboard (assets/js/account.js),
 *   including its asset-diffing trick so a screen's own CSS/JS still arrives.
 *
 * WHAT IT DELIBERATELY DOES NOT TOUCH
 *   Only the slugs in ZymargAdminSPA.pages are intercepted. Screens that must
 *   perform real requests are excluded server-side (see inc/admin-spa.php):
 *   Customize (leaves wp-admin), Update / Upload Theme (multipart POST to
 *   update.php), Plugins (core install flows) and Import / Export (uploads and
 *   long-running jobs). Those keep loading normally, on purpose.
 *
 * FAILURE BEHAVIOUR
 *   Anything unexpected — a non-200, a timeout, markup without
 *   #wpbody-content, a missing History or fetch API — falls back to a normal
 *   browser navigation. The screen always loads; at worst it loads the old way.
 *
 * @package ZYMARG_OS
 */

( function () {
	'use strict';

	var cfg = window.ZymargAdminSPA || {};
	var allowed = cfg.pages || [];
	var region = document.getElementById( 'wpbody-content' );

	if ( ! region || ! allowed.length || ! window.fetch || ! window.history || ! window.history.pushState || ! window.DOMParser ) {
		return;
	}

	var busy = false;

	/* ---------------------------------------------------------------- utils */

	/**
	 * Return the ?page= slug of an admin.php URL, or '' when it is not one.
	 */
	function pageSlug( href ) {
		var url;
		try {
			url = new URL( href, window.location.href );
		} catch ( e ) {
			return '';
		}
		if ( url.origin !== window.location.origin ) {
			return '';
		}
		if ( ! /admin\.php$/.test( url.pathname ) ) {
			return '';
		}
		return url.searchParams.get( 'page' ) || '';
	}

	function isRoutable( href ) {
		var slug = pageSlug( href );
		return !! slug && allowed.indexOf( slug ) !== -1;
	}

	/* ------------------------------------------------------------- progress */

	var bar = null;

	function progress( on ) {
		if ( on ) {
			if ( ! bar ) {
				bar = document.createElement( 'div' );
				bar.className = 'zymarg-spa-bar';
				document.body.appendChild( bar );
			}
			bar.classList.add( 'is-active' );
			region.setAttribute( 'aria-busy', 'true' );
		} else if ( bar ) {
			bar.classList.remove( 'is-active' );
			region.removeAttribute( 'aria-busy' );
		}
	}

	/* --------------------------------------------------------------- assets */

	function existingStyles() {
		var out = {};
		var links = document.querySelectorAll( 'link[rel="stylesheet"][href]' );
		for ( var i = 0; i < links.length; i++ ) {
			out[ links[ i ].href.split( '?' )[ 0 ] ] = true;
		}
		return out;
	}

	function existingScripts() {
		var out = {};
		var tags = document.querySelectorAll( 'script[src]' );
		for ( var i = 0; i < tags.length; i++ ) {
			out[ tags[ i ].src.split( '?' )[ 0 ] ] = true;
		}
		return out;
	}

	/**
	 * Add stylesheets and scripts the incoming screen needs but this document
	 * has not loaded yet.
	 *
	 * A screen enqueues its assets in <head>/footer, which are outside the
	 * swapped region, so without this step a screen reached over AJAX would
	 * render unstyled and dead — exactly the bug the front-end account SPA hit
	 * in 5.27.5.
	 *
	 * Inline scripts are only re-run when they mention "ymarg" (the theme's own
	 * wp_localize_script data, e.g. ZymargRegistry). Blindly re-executing every
	 * inline script in a wp-admin document is not safe.
	 */
	function syncAssets( doc ) {
		var haveCss = existingStyles();
		var haveJs = existingScripts();
		var i;

		var links = doc.querySelectorAll( 'link[rel="stylesheet"][href]' );
		for ( i = 0; i < links.length; i++ ) {
			var href = links[ i ].getAttribute( 'href' );
			var absolute = new URL( href, window.location.href ).href;
			if ( haveCss[ absolute.split( '?' )[ 0 ] ] ) {
				continue;
			}
			var link = document.createElement( 'link' );
			link.rel = 'stylesheet';
			link.href = absolute;
			document.head.appendChild( link );
			haveCss[ absolute.split( '?' )[ 0 ] ] = true;
		}

		var scripts = doc.querySelectorAll( 'script' );
		for ( i = 0; i < scripts.length; i++ ) {
			var src = scripts[ i ].getAttribute( 'src' );

			if ( src ) {
				var srcAbs = new URL( src, window.location.href ).href;
				if ( haveJs[ srcAbs.split( '?' )[ 0 ] ] ) {
					continue;
				}
				var tag = document.createElement( 'script' );
				tag.src = srcAbs;
				tag.async = false;
				document.body.appendChild( tag );
				haveJs[ srcAbs.split( '?' )[ 0 ] ] = true;
				continue;
			}

			var code = scripts[ i ].textContent || '';
			if ( code.indexOf( 'ymarg' ) === -1 ) {
				continue;
			}
			try {
				var inline = document.createElement( 'script' );
				inline.textContent = code;
				document.body.appendChild( inline );
			} catch ( e ) {
				/* A screen's own data block failing must not break navigation. */
			}
		}
	}

	/* ------------------------------------------------------------ menu state */

	/**
	 * Move the "current" highlight in the sidebar to the screen just loaded.
	 * Scoped to the ZYMARG OS top-level item so no other menu is touched.
	 */
	function setCurrent( slug ) {
		var root = document.getElementById( 'toplevel_page_zymarg-os' );
		if ( ! root ) {
			return;
		}

		var items = root.querySelectorAll( 'li' );
		for ( var i = 0; i < items.length; i++ ) {
			items[ i ].classList.remove( 'current' );
			var link = items[ i ].querySelector( 'a' );
			if ( link ) {
				link.classList.remove( 'current' );
				link.removeAttribute( 'aria-current' );
			}
		}

		var anchors = root.querySelectorAll( 'a[href]' );
		for ( var j = 0; j < anchors.length; j++ ) {
			if ( pageSlug( anchors[ j ].href ) !== slug ) {
				continue;
			}
			anchors[ j ].classList.add( 'current' );
			anchors[ j ].setAttribute( 'aria-current', 'page' );
			var li = anchors[ j ].closest( 'li' );
			if ( li ) {
				li.classList.add( 'current' );
			}
			break;
		}
	}

	/* ------------------------------------------------------------ navigation */

	function hardLoad( url ) {
		window.location.href = url;
	}

	function render( html, url ) {
		var doc = new DOMParser().parseFromString( html, 'text/html' );
		var next = doc.getElementById( 'wpbody-content' );

		if ( ! next ) {
			return false;
		}

		syncAssets( doc );
		region.innerHTML = next.innerHTML;

		if ( doc.title ) {
			document.title = doc.title;
		}

		setCurrent( pageSlug( url ) );
		window.scrollTo( 0, 0 );

		/*
		 * Screens that need to re-bind after a swap can listen for this instead
		 * of relying on DOMContentLoaded, which has long since fired.
		 */
		try {
			document.dispatchEvent( new CustomEvent( 'zymarg:admin-screen', { detail: { url: url } } ) );
		} catch ( e ) {}

		return true;
	}

	function go( url, push ) {
		if ( busy ) {
			return;
		}
		busy = true;
		progress( true );

		var done = false;
		var timer = window.setTimeout( function () {
			if ( ! done ) {
				done = true;
				hardLoad( url );
			}
		}, 12000 );

		window.fetch( url, {
			credentials: 'same-origin',
			headers: { 'X-Requested-With': 'XMLHttpRequest' }
		} )
			.then( function ( res ) {
				if ( ! res.ok ) {
					throw new Error( 'HTTP ' + res.status );
				}
				return res.text();
			} )
			.then( function ( html ) {
				if ( done ) {
					return;
				}
				done = true;
				window.clearTimeout( timer );

				if ( ! render( html, url ) ) {
					hardLoad( url );
					return;
				}

				if ( push ) {
					window.history.pushState( { zymargSpa: true }, '', url );
				}

				busy = false;
				progress( false );
			} )
			.catch( function () {
				if ( done ) {
					return;
				}
				done = true;
				window.clearTimeout( timer );
				hardLoad( url );
			} );
	}

	/* ---------------------------------------------------------------- events */

	document.addEventListener( 'click', function ( event ) {
		if ( event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey ) {
			return;
		}

		var link = event.target.closest ? event.target.closest( 'a[href]' ) : null;
		if ( ! link || ! link.closest( '#adminmenu' ) ) {
			return;
		}
		if ( link.target && '_self' !== link.target ) {
			return;
		}
		if ( ! isRoutable( link.href ) ) {
			return;
		}
		if ( link.href.split( '#' )[ 0 ] === window.location.href.split( '#' )[ 0 ] ) {
			return;
		}

		event.preventDefault();
		go( link.href, true );
	} );

	window.addEventListener( 'popstate', function ( event ) {
		if ( ! event.state || ! event.state.zymargSpa ) {
			return;
		}
		if ( ! isRoutable( window.location.href ) ) {
			hardLoad( window.location.href );
			return;
		}
		go( window.location.href, false );
	} );

	/* Mark the entry point so Back to the first screen is also handled. */
	try {
		window.history.replaceState( { zymargSpa: true }, '', window.location.href );
	} catch ( e ) {}
} )();
