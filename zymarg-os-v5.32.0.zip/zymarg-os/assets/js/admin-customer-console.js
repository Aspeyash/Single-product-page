/**
 * ZYMARG OS — Customer console behaviour.
 *
 * Two dropdowns drive the whole screen:
 *   1. Customer — a search box that queries the customer index over AJAX, so it
 *      works with millions of accounts (a real <select> of every user is not
 *      possible at that size).
 *   2. Section — switches which panel is visible. All panels are already in the
 *      document, so switching is instant and costs no request, and only one is
 *      ever in the flow, which keeps the page one screen tall.
 *
 * Re-initialises on 'zymarg:admin-screen' so it still works after the admin
 * AJAX router (assets/js/admin-spa.js) swaps the page in without a reload.
 *
 * @package ZYMARG_OS
 */

( function () {
	'use strict';

	var cfg = window.ZymargCustomerConsole || {};

	function text( value ) {
		return String( value === undefined || value === null ? '' : value );
	}

	/* ------------------------------------------------------ section switch */

	function initSections( root ) {
		var select = root.querySelector( '[data-zymarg-section-select]' );
		var panels = root.querySelectorAll( '[data-zymarg-panel]' );

		if ( ! select || ! panels.length ) {
			return;
		}

		function show( key ) {
			var matched = false;
			var i;

			for ( i = 0; i < panels.length; i++ ) {
				var isMatch = panels[ i ].getAttribute( 'data-zymarg-panel' ) === key;
				panels[ i ].classList.toggle( 'is-active', isMatch );

				if ( isMatch ) {
					matched = true;
				}
			}

			/* Unknown key (stale link, removed section): fall back to the first. */
			if ( ! matched ) {
				panels[ 0 ].classList.add( 'is-active' );
				select.value = panels[ 0 ].getAttribute( 'data-zymarg-panel' );
			}
		}

		select.addEventListener( 'change', function () {
			show( select.value );

			/*
			 * Keep the choice in the hash so a reload, a bookmark or a link
			 * pasted to a colleague lands on the same section.
			 */
			try {
				window.history.replaceState( window.history.state, '', '#' + select.value );
			} catch ( e ) {}
		} );

		var fromHash = ( window.location.hash || '' ).replace( '#', '' );

		if ( fromHash ) {
			select.value = fromHash;
		}

		show( select.value );
	}

	/* ---------------------------------------------------- customer search */

	function initSearch( root ) {
		var input = root.querySelector( '[data-zymarg-customer-search]' );
		var list = root.querySelector( '[data-zymarg-customer-results]' );

		if ( ! input || ! list || ! cfg.ajaxUrl || ! window.fetch ) {
			return;
		}

		var timer = null;
		var controller = null;
		var items = [];
		var active = -1;

		function close() {
			list.classList.remove( 'is-open' );
			list.innerHTML = '';
			items = [];
			active = -1;
		}

		function message( str ) {
			list.innerHTML = '<li class="zym-cc__empty"></li>';
			list.firstChild.textContent = str;
			list.classList.add( 'is-open' );
			items = [];
			active = -1;
		}

		function highlight( next ) {
			if ( ! items.length ) {
				return;
			}

			active = ( next + items.length ) % items.length;

			for ( var i = 0; i < items.length; i++ ) {
				items[ i ].classList.toggle( 'is-active', i === active );
			}

			items[ active ].scrollIntoView( { block: 'nearest' } );
		}

		function render( results, building ) {
			if ( ! results.length ) {
				message(
					building
						? text( cfg.strings && cfg.strings.building )
						: text( cfg.strings && cfg.strings.none )
				);
				return;
			}

			list.innerHTML = '';
			items = [];

			results.forEach( function ( row ) {
				var li = document.createElement( 'li' );
				li.className = 'zym-cc__result';
				li.setAttribute( 'role', 'option' );

				var name = document.createElement( 'div' );
				name.className = 'zym-cc__result-name';
				name.textContent = text( row.name );

				var meta = document.createElement( 'div' );
				meta.className = 'zym-cc__result-meta';
				meta.textContent = text( row.email ) + ' \u00b7 #' + text( row.id );

				/* textContent everywhere: customer-supplied names are never HTML. */
				li.appendChild( name );
				li.appendChild( meta );

				li.addEventListener( 'click', function () {
					if ( row.url ) {
						window.location.href = row.url;
					}
				} );

				list.appendChild( li );
				items.push( li );
			} );

			list.classList.add( 'is-open' );
			active = -1;
		}

		function search( term ) {
			if ( controller ) {
				controller.abort();
			}

			controller = window.AbortController ? new window.AbortController() : null;

			var body = new URLSearchParams();
			body.append( 'action', 'zymarg_os_customer_search' );
			body.append( 'nonce', text( cfg.nonce ) );
			body.append( 'term', term );

			window
				.fetch( cfg.ajaxUrl, {
					method: 'POST',
					credentials: 'same-origin',
					body: body,
					signal: controller ? controller.signal : undefined
				} )
				.then( function ( res ) {
					return res.json();
				} )
				.then( function ( payload ) {
					if ( ! payload || ! payload.success ) {
						message( text( cfg.strings && cfg.strings.error ) );
						return;
					}

					render( payload.data.results || [], !! payload.data.building );
				} )
				.catch( function ( err ) {
					if ( err && 'AbortError' === err.name ) {
						return;
					}

					message( text( cfg.strings && cfg.strings.error ) );
				} );
		}

		input.addEventListener( 'input', function () {
			var term = input.value.trim();

			if ( timer ) {
				window.clearTimeout( timer );
			}

			if ( term.length < 2 ) {
				close();
				return;
			}

			/* Debounced: one request per pause, not one per keystroke. */
			timer = window.setTimeout( function () {
				search( term );
			}, 250 );
		} );

		input.addEventListener( 'keydown', function ( event ) {
			if ( 'ArrowDown' === event.key ) {
				event.preventDefault();
				highlight( active + 1 );
			} else if ( 'ArrowUp' === event.key ) {
				event.preventDefault();
				highlight( active - 1 );
			} else if ( 'Enter' === event.key ) {
				if ( active > -1 && items[ active ] ) {
					event.preventDefault();
					items[ active ].click();
				}
			} else if ( 'Escape' === event.key ) {
				close();
			}
		} );

		document.addEventListener( 'click', function ( event ) {
			if ( ! list.contains( event.target ) && event.target !== input ) {
				close();
			}
		} );
	}

	/* ------------------------------------------------------------- boot */

	function init() {
		var root = document.querySelector( '[data-zymarg-console]' );

		if ( ! root || root.getAttribute( 'data-zymarg-ready' ) === '1' ) {
			return;
		}

		root.setAttribute( 'data-zymarg-ready', '1' );

		initSections( root );
		initSearch( root );
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}

	/* The admin router replaces the page without a reload; re-bind after it. */
	document.addEventListener( 'zymarg:admin-screen', init );
} )();
