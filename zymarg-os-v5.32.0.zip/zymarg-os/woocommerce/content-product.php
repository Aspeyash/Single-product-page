<?php
/**
 * Theme override: WooCommerce loop item (shop, category / tag archives,
 * [products] shortcode and the product blocks).
 *
 * WooCommerce's own loop renders its default card through the
 * woocommerce_before_shop_loop_item* / woocommerce_after_shop_loop_item* hook
 * stack. The theme's other product surfaces (search, archives, related,
 * upsells, the account tabs) all render the ZYMARG branded card instead, so
 * without this file the shop and category pages are the only places left
 * showing a different card.
 *
 * When the branded card is switched off -- or when its "shop loop" sub-toggle
 * is off -- WooCommerce's original template is included unchanged, so the
 * default loop and every plugin hooked into it behave exactly as before.
 *
 * Toggle: ZYMARG OS -> Product Card.
 *
 * NOTE: while the branded card is active in the loop, the
 * woocommerce_before/after_shop_loop_item* hooks do NOT fire -- the branded
 * card renders its own image, title, price, rating, wishlist, quick view and
 * add-to-cart. Plugins that inject markup into those hooks will be silent here.
 * That is the documented trade-off of taking over the loop; switch the shop
 * loop toggle off to get the hooks back.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

global $product;

if ( ! $product instanceof WC_Product || ! $product->is_visible() ) {
	return;
}

$zymarg_branded_loop = function_exists( 'zymarg_os_branded_card_in_shop_loop' )
	&& zymarg_os_branded_card_in_shop_loop()
	&& function_exists( 'zymarg_os_render_product_card' );

if ( ! $zymarg_branded_loop ) {
	// Hand straight back to WooCommerce's own template.
	$zymarg_wc_default = function_exists( 'WC' ) ? WC()->plugin_path() . '/templates/content-product.php' : '';

	if ( '' !== $zymarg_wc_default && file_exists( $zymarg_wc_default ) ) {
		include $zymarg_wc_default;
	}

	return;
}

/*
 * Keep WooCommerce's <li class="product ..."> wrapper. Its classes are what
 * WooCommerce's own column CSS, and plenty of third-party CSS, hook onto --
 * dropping it would break the shop grid layout even though the card itself is
 * styled by the Template Pack.
 */
?>
<li <?php wc_product_class( 'zymarg-os-loop-item', $product ); ?>>
	<?php zymarg_os_render_product_card( $product ); ?>
</li>
