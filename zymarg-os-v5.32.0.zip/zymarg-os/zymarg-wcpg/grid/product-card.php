<?php
/**
 * Theme override: ZYMARG WC Product Grid card template.
 *
 * The engine's Template_Loader::locate() checks the active theme before its own
 * templates, so this file intercepts every request for `grid/product-card.php`.
 * That path is what the wishlist and recently-viewed shortcodes, and the theme's
 * own zymarg_os_render_product_card(), ask for -- none of which pass through the
 * engine's Render_Engine, so none of them consult the card registry.
 *
 * This file is a THIN ROUTER, not a copy of a card:
 *
 *   Branded card ON  -> include the ZYMARG Template Pack's product-card.php
 *   Branded card OFF -> include the engine's own grid/product-card.php
 *
 * Routing rather than copying means the Template Pack can be updated freely --
 * there is no duplicated markup here to drift out of sync.
 *
 * Toggle: ZYMARG OS -> Product Card (option `zymarg_os_product_card`).
 * Background: PRODUCT-CARD-OVERRIDE.md, shipped with the ZYMARG Template Pack.
 *
 * The including scope provides $product, $settings and $widget_id; a plain
 * include inherits them, so the target template receives them unchanged.
 *
 * @package ZYMARG_OS
 *
 * @var \WC_Product $product
 * @var array       $settings
 * @var int|string  $widget_id
 */

defined( 'ABSPATH' ) || exit;

$zymarg_use_branded = ! function_exists( 'zymarg_os_use_branded_card' ) || zymarg_os_use_branded_card();

if ( $zymarg_use_branded && function_exists( 'zymarg_os_branded_card_path' ) ) {
	$zymarg_branded_card = zymarg_os_branded_card_path();

	if ( '' !== $zymarg_branded_card ) {
		include $zymarg_branded_card;
		return;
	}
}

// Fall back to the engine's bundled card (also the OFF state).
$zymarg_engine_card = defined( 'ZYMARG_WCPG_DIR' )
	? ZYMARG_WCPG_DIR . 'templates/grid/product-card.php'
	: '';

if ( '' !== $zymarg_engine_card && file_exists( $zymarg_engine_card ) ) {
	include $zymarg_engine_card;
}
