=== ZYMARG OS ===

Contributors: zymarg
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 5.32.0
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A lightweight, modular, page-builder-friendly WordPress theme built for
multivendor marketplaces (WooCommerce + Dokan), with the ZYMARG design system.

== Description ==

ZYMARG OS is intentionally minimal where it should be and powerful where it
matters. It ships WITHOUT a visual header or footer — those are managed by your
own ZYMARG plugin / page builder — and focuses on a fast, flexible foundation:

* Clean white base lit by two soft purple "orb" glows (the ZYMARG look).
* The full ZYMARG colour token system, exposed as CSS variables and as a
  block-editor / theme.json palette.
* Inter (body) + Sora (headings) typography.
* Modular architecture — turn features on/off so only the code you use loads.

= Features =

* Advanced Typography — per-element control: font source, base size, line
  height, heading weight, plus custom font family overrides.
* Advanced Colours — Customizer colour controls wired to CSS variables with a
  live preview.
* Spacing controls — content padding and max-width.
* Custom button styling — radius and token-driven colours.
* Mega Menu — multi-column dropdowns (add the `mega-menu` class to a menu item;
  use `mega-cols-2`..`mega-cols-6` to set columns) and sticky navigation.
* WooCommerce — shop grid columns, Quick View (AJAX), off-canvas cart drawer,
  sticky add-to-cart bar, gallery zoom/lightbox/slider, plus Dokan vendor-store
  styling.
* LearnDash / LMS — token-based accent styling, loaded only on LMS pages.
* Scroll to Top — accessible floating button.
* Custom Layout hooks — zymarg_os_body_open, zymarg_os_before_content,
  zymarg_os_content_top, zymarg_os_content_bottom, zymarg_os_after_content,
  zymarg_os_footer.
* White Label — rebrand the theme in the admin via the `zymarg_os_white_label`
  filter (agency mode).
* Performance — disables emojis, removes jQuery Migrate on the front end,
  trims unused block CSS, defers the theme script, and adds resource hints.

= Fonts =

Font Loading is set in Customize -> ZYMARG OS -> Typography:

1. Google Fonts (default) — optimised with preconnect hints + `display=swap`
   and only the weights used.
2. Self-host Inter + Sora — GDPR-friendly; drop .woff2 files into
   /assets/fonts (see assets/fonts/fonts.css for the file names).
3. Upload my own fonts — upload .woff2/.woff/.ttf files for headings and/or
   body; the theme generates the @font-face rules with `font-display: swap`.
4. System fonts — zero font requests.

== Installation ==

1. Upload the `zymarg-os` folder to /wp-content/themes/ (or install the zip via
   Appearance -> Themes -> Add New -> Upload Theme).
2. Activate the theme through the Themes menu in WordPress.
3. Go to Appearance -> Customize -> ZYMARG OS to configure modules, colours,
   typography, spacing and buttons.

== Changelog ==

= 5.32.0 - Settings screens save without reloading the page =

Pressing Save on a ZYMARG OS settings screen reloaded the whole page. That was
never a broken feature, it was an inconsistency: Slugs & Pages had grown its own
AJAX save, and the other screens never did. Sidebar navigation was already AJAX
(inc/admin-spa.php), which made the reload on Save look like a bug.

Audited every screen in the ZYMARG OS menu. Three saved by posting the page and
now save over AJAX:

* Product Card
* Account & Security
* Toast Notification (the Save Toast Sources form)

How it works. One new script, assets/js/admin-ajax-save.js, driven per screen by
inc/admin-ajax-save.php. It builds FormData from the real form, so every field
the existing saver reads arrives under the name it already expects, including
the form's own nonce. The AJAX route then calls that screen's own save function,
so there is no second copy of any save logic to drift out of sync. Both files are
additive: no existing screen file was modified.

Deliberately still posting the page, because a reload is the correct outcome:

* Upload Theme and Plugins - real multipart uploads and core install flows.
* Import / Export - already has its own batched AJAX with progress.
* Toast "Scan Installed Plugins" and "Clear Log & Counters" - both rebuild the
  whole screen. Saving them over AJAX would leave a stale table on screen.

Safety. If JavaScript is unavailable, or fetch/FormData are missing, the submit
handler is never bound and the browser posts the form exactly as before. Deleting
inc/admin-ajax-save.php restores the old behaviour on every screen. An expired
form nonce now returns a readable message instead of dying with an HTML notice
the request could not parse. On Toast, a hidden action field is checked on both
sides, so a Clear Log payload can never travel down the save route.

Also re-binds after sidebar navigation. The admin router swaps #wpbody-content,
which destroys the form the script bound to, so it re-initialises on the
zymarg:admin-screen event the way the Customers console already does.

One known limit. Sidebar navigation into the ZYMARG OS menu from an unrelated
screen, such as Dashboard or Appearance, still loads once the normal way: the
router only ships on the screens it can route, so it is not present on the page
you are leaving. Moving between ZYMARG OS screens is AJAX.

= 5.31.0 - Wishlist and Recently viewed now appear in the Customers console =

The 5.30.0 notes claimed Wishlist and Recently Viewed could never be shown here because the theme owns none of their data. The first half of that was right and the conclusion was wrong. Reading ZYMARG WC Product Grid settled it: for signed-in customers both lists are persisted in user meta, and the cookie plus WooCommerce session are only guest fallbacks. Storage location, not ownership, is what decides whether the console can answer a question - so both are now real panels, and both have left the "Front-end only" table.

Two new sections in the Customers console "Show" dropdown, taking it to twelve:

* Wishlist - what the customer saved for later, in stored order, with the current price and availability of each item. Guest additions are merged into the account at login by the plugin, so for a registered customer this is the complete list. It answers the intent question during a price-drop or restock argument.
* Recently viewed - the last products the customer opened, most recent first, capped at 20 by the plugin.

One honest limit on Recently viewed, found by comparing the two stores rather than assuming they matched: the wishlist has a merge-on-login step and the recently-viewed list does not. Pre-login browsing stays in the cookie and is never backfilled, so this panel reports what a customer viewed while signed in. That is stated in the panel itself rather than left for someone to discover during an escalation.

Both panels read the meta key directly instead of calling the plugin's own Wishlist_Store::get_ids() or Recently_Viewed::get_ids(). Those resolve get_current_user_id(), which inside wp-admin is the staff member - calling them would have shown the agent their own wishlist while appearing to work. The plugin's constants are preferred when the class is loaded so a future key rename is picked up automatically, with the current literals as fallback, which also means the panels still work after the plugin is deactivated, since deactivation does not delete the meta.

Stale entries are reported, not repaired. The plugin's shortcode rewrites the stored list when it meets a deleted product; this console deliberately does not, because a read-only support screen must never silently rewrite customer data. Removed products show as Deleted, and products that exist but are not public show their status, which is usually the more useful answer anyway.

Support was considered and deliberately left out. ZYMARG Communication does expose a sanctioned public API, and its listForUser() has no permission gate, so it could have been surfaced. It ships its own Conversations screen in wp-admin, and private correspondence is better read in one place under that plugin's own permissions than copied into a second surface. The "Front-end only" table now explains that choice instead of implying the data is unreachable.

= 5.30.1 - Toolbar alignment fix: the section dropdown can no longer stretch the bar =

The four sections added in 5.30.0 carried labels that were too long - "Full history (everything, merged)" at 32 characters being the worst. A <select> sizes itself to its widest option, .zym-cc__field carries min-width:240px with no maximum, and .zym-cc__actions is pushed right with margin-left:auto. The result was that the section control grew wide enough to consume the flex row, so the "Customer" and "Show" labels crowded together and the All customers / All orders / Edit in WordPress buttons wrapped out of alignment. The panels themselves were correct throughout; only the toolbar was affected.

Fixed on both levels, because shortening the words alone would have left the trap in place for the next section anyone adds:

* Labels shortened to match the terse house style already used by Overview and Orders: "Reviews they left" becomes "Reviews", "Full history (everything, merged)" becomes "Full history", and "Front-end only sections" becomes "Front-end only". The descriptive wording was never lost - it already lived in each panel's own heading, which is where it costs no layout.
* #zymarg-cc-section is now capped at max-width:280px, so no future label of any length can stretch the toolbar again. This is the real fix; the renaming above is cosmetic.

Also added in the same pass: colours for the On / Off / change / access tags this layer introduces, which had been rendering unstyled because only the original order and security tag modifiers existed in the stylesheet.

Both are delivered through wp_add_inline_style() against the console's own handle, at admin_enqueue_scripts priority 50 so the handle is guaranteed to exist after the console registers it at 40, and guarded by wp_style_is() so nothing loads outside the Customers screen. assets/css/admin-customer-console.css was deliberately not edited: the feature stays one file plus one require line, and removing it still leaves no trace in your stylesheets. Only the new .zym-cc__tag--* modifiers are declared, so existing tag colours are untouched.

= 5.30.0 - The Customers console now answers what the customer saved, and what happened, in order =

The original plan was for My Account and the Customers console to mirror each other, so that whatever a customer could see and change, support could see too. The two drifted, and the reason turned out to be structural rather than careless. Wishlist, Recently Viewed and Support own no data in this theme at all - they are shells that render whatever the Product Grid, Insights and Comm plugins return. The console, by contrast, can only display what the theme itself can query. Those two things can never be made identical, and chasing sameness in the UI was always going to keep breaking. Parity for the sections the theme genuinely owns is achievable, and that is what this release does.

Four new sections in the Customers console "Show" dropdown:

* Saved preferences - the real notification and email toggle values, read from the same zymarg_notif_* and zymarg_pref_* meta the account page writes. Each row states whether the value was saved by the customer or is still the theme default, because "switched it off" and "never touched it" are different facts and look identical until you separate them. That distinction is what settles a "you never emailed me" complaint.
* Reviews they left - product, rating, excerpt and moderation state, so a review stuck awaiting moderation is visible instead of looking like it was never written.
* Full history (everything, merged) - the theme kept three histories answering three different questions: orders and security events in the snapshot timeline, field-level changes in the change log, and staff access in the access log. Reading a dispute meant opening three panels and reconstructing the order by eye. All three are now normalised to one shape and sorted newest first in a single stream. All three sources already stored GMT timestamps, so they are directly comparable and no conversion guesswork was needed.
* Front-end only sections - the plugin-owned tabs, named, each with the plugin that actually holds the data. Deliberately a real panel rather than a silent omission: the gap was the confusing part, and naming it turns a surprise into information.

Locked profile fields are now shown side by side. zymarg_os_profile_filter_locked_meta() short-circuits get_user_metadata for locked keys so the whole site agrees on one value, currently BDT and Asia/Dhaka. That is right for the storefront and wrong for the one screen you open when something looks broken, because it meant the console could never show the stored truth. The panel now prints the pinned value next to the value actually in the database and flags the row when they disagree - which is how you catch an old value still driving an export or a third-party plugin. Never-saved is reported as such rather than as a conflict.

Read only, by design. The write path stays where it was, in zymarg_os_handle_profile_save(), which owns validation, the locked-field rules and the change-log hooks. A second write path in wp-admin would silently skip the change log and duplicate the validation surface, which is exactly how an audit trail rots.

New file inc/admin-customer-panels.php, loaded inside the existing is_admin() block, so nothing runs on the front end. Fourteen new functions, all prefixed zymarg_os_parity_*, diffed against every function in the theme before release per the 5.29.1 lesson - zero collisions. Nothing existing was rewritten: the layer attaches entirely through extension points the theme had already published, the zymarg_os_customer_snapshot filter, zymarg_os_customer_console_sections and the zymarg_os_customer_console_panels action. Extending the snapshot rather than the panels keeps one source of truth, because the capability check and the access-log write in zymarg_os_customer_snapshot() have already run by the time the new data is attached, so nothing here can leak a record or skip an audit entry. New filters: zymarg_os_parity_plugin_owned_sections and zymarg_os_parity_pref_fields. No new tables, no new options, no cron.

To remove the feature entirely, delete the single zymarg_os_require() line in functions.php - the helper checks is_readable() first, so a missing file is skipped rather than fatal.

= 5.29.3 - Performance now reports the whole ZYMARG plugin suite =

The five required plugins tell you whether the marketplace can run. They tell you nothing about the other eighteen ZYMARG plugins this site actually uses, and that gap showed up exactly where it hurts: in support. When a customer reports a broken cart, a missing review, or a header that will not stick, the first question is always "which ZYMARG plugins were installed, which were switched on, and at what version?" Until now the only way to answer was to open the Plugins screen and read 23 rows by eye.

Performance -> "ZYMARG plugin suite" now answers it in one glance. It is a flat list of every ZYMARG plugin the site expects, with version and status, plus a running count in the heading. Three states, and the distinction matters when triaging:

* Active - installed and switched on.
* Installed, switched off - the code is on disk, so a stray deactivation is visible instead of looking identical to a plugin you never installed.
* Not installed - and this is not an error. Only the five under Integrations are required; a plugin you chose not to install is a choice, not a fault, and the screen never nags about it.

The data is read from the real plugin headers via get_plugins(), the same source the Plugins screen uses, so it cannot drift from reality the way a hand-maintained constant check can. Names are matched on a normalised key, which means "ZYMARG Login & Security", "ZYMARG Login Security" and the zymarg-login-security folder all resolve to the same plugin - an ampersand or a rename will not make a plugin that is sitting right there report as missing. Any ZYMARG plugin found on disk that is not on the expected list is appended and labelled "Installed, but not on the expected list", so a new plugin appears on the report the day it is installed rather than the day the theme is updated.

The list is deliberately not collapsed and not behind a dropdown. Performance is its own screen with its own menu item, so there is nothing to keep short here; the rule about hiding options inside a dropdown belongs to the customer console, where the page really does have to stay compact.

New, all reporting-only and all admin-side: zymarg_os_zymarg_suite_expected(), zymarg_os_plugin_name_key(), zymarg_os_installed_zymarg_plugins() and zymarg_os_zymarg_suite(), in inc/recommended-plugins.php. All four names were diffed against the companion plugins before release - zero collisions. Filters: zymarg_os_zymarg_suite_expected to add or retire a plugin, and zymarg_os_zymarg_suite to reshape the finished report. No new tables, no new options, no cron, and nothing runs on the front end.

= 5.29.2 - The required-plugin list now matches reality: five plugins, no Theme Builder, no Elementor =
* Change: the "Finish setup" notice asked for ZYMARG Theme Builder and Elementor,
  neither of which is used any more, while never once asking for the plugins the
  marketplace actually runs on. The required stack is now WooCommerce, Dokan,
  ZYMARG Vendor Dashboard, ZYMARG Reviews Engine and ZYMARG Login & Security.
* Change: inc/recommended-plugins.php rewritten around one filterable list,
  zymarg_os_required_plugins. Each entry carries its own detection result, so the
  notice and the Performance screen can never disagree again. Per-plugin filters:
  zymarg_os_woocommerce_active, zymarg_os_dokan_active,
  zymarg_os_vendor_dashboard_active, zymarg_os_reviews_engine_active and
  zymarg_os_login_security_active.
* Removed: zymarg_os_theme_builder_active() and zymarg_os_elementor_active(),
  along with the zymarg_os_theme_builder_install_url filter. Nothing else in the
  theme called them (verified by grep) except the Performance screen, which was
  updated in the same release.
* Change: Performance -> Integrations now lists the five required plugins instead
  of Theme Builder / Elementor / WooCommerce. ZYMARG Login & Security reports
  "Fallback (theme login)" rather than a red "Missing", because the theme is
  designed to keep working without it - see the ZLS_VERSION note below.
* Note: ZYMARG Login & Security is listed as required but is NOT a hard
  dependency. functions.php only loads the theme's own login, session-control and
  Customizer-login files when ZLS_VERSION is undefined, and
  inc/login-fallback-notice.php emails the admin when that fallback goes live.
  That behaviour is unchanged.
* Change: Help screen wording no longer tells you to drop shortcodes into "your
  Elementor header" - it now says ZYMARG Header. The Grid Skin instructions say
  "Page builder" instead of "Elementor".
* Change: style.css description rewritten. It no longer claims the theme REQUIRES
  ZYMARG Theme Builder, and it now names ZYMARG Header / ZYMARG Footer (or the
  theme's own Header & Footer builder) as what renders the header and footer.
* Detection signatures used: WC_VERSION / WooCommerce, dokan() / WeDevs_Dokan /
  DOKAN_PLUGIN_VERSION, ZYMARG_VD_VERSION (from the plugin's main file),
  \ZymargReviewsEngine\Review_Tracker (the same class the account Reviews tab
  already trusts for review eligibility) and ZLS_VERSION / ZLS_Audit.
* Kept deliberately: the Elementor anti-CLS critical CSS in inc/performance.php
  (11 selectors targeting .elementor-location-header). It is inert without
  Elementor and removing it is a separate, riskier change - see the note in that
  file. If the ZYMARG Header plugin needs the same boot-freeze protection, those
  selectors should be retargeted rather than deleted.
* Namespace: all five new detection functions were diffed against the ZYMARG
  Vendor Dashboard plugin's global functions before release, per the 5.29.1
  lesson. Zero collisions.

= 5.29.1 - Fatal error fix: function name clash with the Vendor Dashboard plugin =

* FIXED a fatal error that took the site down on 5.29.0: "Cannot redeclare
  zymarg_os_user_is_vendor()". The ZYMARG Vendor Dashboard plugin already
  declares that function, and inc/customer-data.php declared it a second time.
  PHP treats a duplicate function name as a fatal error, so the whole site went
  white — front end and admin.
* The theme's copy is renamed zymarg_os_customer_is_vendor(), and when the plugin
  is active it now DEFERS to the plugin's answer instead of deciding separately.
  The plugin owns what "vendor" means on a marketplace, so it should be the
  authority; two independent definitions would eventually disagree, and a vendor
  wrongly classed as staff is a data leak.
* Also renamed zymarg_os_vendor_roles() to zymarg_os_customer_vendor_roles() for
  the same reason. The FILTER is still called zymarg_os_vendor_roles, unchanged,
  because inc/session-control.php already uses that filter name — so one filter
  still controls the vendor role list everywhere.
* Root cause of the miss: the pre-release name-collision check only scanned the
  theme. The theme and its companion plugins share the zymarg_os_ prefix, so that
  check has to cover the plugins too.

= 5.29.0 - Customer support console, phases 2 and 3: search at scale, and the view =

The console is now live under ZYMARG OS -> Customers. Search any customer and
read their account exactly as they see it — read-only, on one short screen.

PHASE 2 — SEARCH THAT SURVIVES A MILLION USERS

* NEW {prefix}zymarg_customer_index — one narrow, properly indexed table holding
  name, email, username, phone, order count, lifetime value and last order date.
  Kept current by hooks on registration, profile edits, watched meta and every
  order change, including on the front end where checkout happens.
* FIXED the search that would have taken the site down at scale. The old query
  used '*term*', which becomes LIKE '%term%'; a leading wildcard cannot use an
  index, so every keystroke scanned all of wp_users, and order count and
  lifetime value then ran two more lookups PER ROW. Search now tries an
  index-usable prefix match first, falls back to a contains match only when that
  finds nothing, and resolves to a capped list of IDs fetched by primary key.
* Pagination's SELECT FOUND_ROWS() is switched off on the search path. It was
  the other half of the cost, and the result set is already capped at 50.
* Backfill runs every five minutes in batches, using keyset pagination
  (WHERE ID > cursor) rather than OFFSET, because OFFSET gets slower the deeper
  it goes while a primary-key range scan does not. It stands down automatically
  once complete. A "Rebuild index" action starts it over.
* Search is honest while the index fills: the dropdown says so rather than
  implying a customer does not exist.
* Filters: zymarg_os_customer_index_batch_size, zymarg_os_customer_index_deep_search.

PHASE 3 — THE VIEW, DELIBERATELY SHORT

* NEW read-only customer console. Two dropdowns drive everything: one picks the
  customer (a search box, since a <select> of a million users is not possible),
  one picks the section. Only the chosen section is visible, so the screen stays
  one screen tall instead of a long stack of tables.
* Sections: Overview, Orders, Addresses, Profile fields, Activity timeline, and
  Who viewed this account. All are rendered up front and switched in the browser,
  so moving between them costs no request at all. The section is kept in the URL
  hash, so a reload or a link shared with a colleague lands in the same place.
* Profile fields are read from the SAME definitions My Account uses, so a field
  added for customers appears for staff automatically, with no second copy of the
  account files to maintain.
* The Customers landing screen is now the searchable picker plus the ten most
  recent customers. The long paginated list is still there, one click away under
  "Browse full list", instead of filling the screen by default.
* The customer search dropdown works with keyboard arrows and Enter, is debounced
  to one request per pause rather than one per keystroke, and cancels in-flight
  requests so results cannot arrive out of order.
* The console re-initialises after the admin AJAX router swaps the page in, so it
  keeps working without a reload (see v5.27.9).
* Vendors still cannot reach any of this, and opening a customer is recorded in
  the access log added in 5.28.0 — visible in the last panel.
* Editing stays on core's user screen, linked in the toolbar. Read-only is the
  point: it keeps the change log an accurate record of who altered what, which is
  what payment disputes turn on.
* Filter: zymarg_os_customer_console_sections. Action: zymarg_os_customer_console_panels
  (for adding your own panel).

= 5.28.0 - Customer support console, phase 1: the data layer =

First of three phases behind ZYMARG OS -> Customers. This phase adds no new
screen; it builds the foundation the next two phases render from, so nothing
visible changes yet and nothing existing changes behaviour.

* NEW inc/customer-data.php — read-only getters that are the single source of
  truth for "everything about this customer": identity, commerce metrics
  (orders, lifetime value, average order value), address book, profile fields
  and a merged timeline. The admin side will render from the SAME field
  definitions the front end uses (zymarg_os_profile_fields), so a field added
  to My Account appears for staff automatically — no second copy of the 15
  account-*.php files, and no repeat of the two-places-one-thing bug fixed in
  5.27.9.
* NEW unified timeline: orders, account field changes and security events
  merged into one newest-first history. Support no longer cross-references
  three tables by eye to spot that a delivery address changed minutes before
  a disputed order.
* NEW inc/customer-access-log.php — a dedicated, indexed table recording which
  staff member viewed which customer and when, throttled so tab switching
  records one visit, and pruned daily after a retention window (365 days by
  default, filterable). The most common data leak in a large marketplace is a
  support agent looking up someone they know; a visible log is the deterrent,
  and the answer when a customer or regulator asks who accessed their data.
* NEW hardened access rule: vendors can never browse the buyer database, even
  when a marketplace plugin has granted them capabilities that would otherwise
  pass, unless they are a full administrator.
* NEW redaction layer: 2FA seeds, tokens, reset keys, session data and
  card-shaped meta can never reach an admin screen, matched by substring so a
  plugin adding a secret later is caught without a code change.
* Read-only by design. Nothing here writes customer data, which keeps the
  change log trustworthy — the record every payment dispute turns on.
* Filters added: zymarg_os_vendor_roles, zymarg_os_can_view_customer_data,
  zymarg_os_customer_secret_meta_patterns, zymarg_os_customer_identity,
  zymarg_os_customer_metrics, zymarg_os_customer_address_book,
  zymarg_os_customer_profile_fields, zymarg_os_customer_timeline,
  zymarg_os_customer_snapshot, zymarg_os_customer_access_retention_days,
  zymarg_os_customer_access_throttle. Action: zymarg_os_customer_accessed.

= 5.27.9 - One header authority, and the ZYMARG OS menu no longer reloads =

* FIXED (properly this time) the header that was still a different size and
  design on Slugs & Pages. 5.27.8 only fixed the missing version badge; the
  heading itself was still wrong. The cause was never specificity, it was load
  order: `.wrap.zymarg-registry > h1` and `.wrap.zymarg-admin > h1` have
  IDENTICAL specificity, and inc/page-registry.php is required at
  functions.php line 134 — long after inc/admin-dark.php (line 95) enqueues the
  brand layer — so the registry stylesheet printed last and won. That screen
  alone lost the header card, its border, the 3px gradient strip and the 22px
  wordmark.
* assets/css/admin-brand.css is now the SINGLE authority for every screen
  header. Competing h1 / version-badge / intro rules were removed from
  assets/css/admin-registry.css, assets/css/admin-import.css and
  assets/css/admin-screens.css, and from the inline <style> blocks in
  inc/admin-help.php, inc/admin-menu.php (three screens) and
  inc/admin-performance.php.
* admin-registry.css, admin-import.css and admin-spa.css now declare
  admin-brand.css as a dependency, so stylesheet order can never silently
  regress the header again no matter when a file is required.
* NEW: the ZYMARG OS admin menu is now AJAX. Clicking a submenu item fetches
  the screen and swaps it in with a thin gradient progress bar — no page
  reload, no white flash. Back and Forward work. New files:
  inc/admin-spa.php, assets/js/admin-spa.js, assets/css/admin-spa.css.
* The router carries each screen's own CSS and JS across the swap (the same
  asset-diffing approach as the front-end My Account dashboard), so localized
  data such as ZymargRegistry still arrives.
* Four menu items stay real page loads on purpose, because they must perform
  genuine browser requests: Customize (leaves wp-admin), Update / Upload Theme
  (multipart POST to update.php), Plugins (core install flows) and
  Import / Export (file uploads and long jobs). Filter the routed list with
  `zymarg_os_admin_spa_pages`; return an empty array to disable the router.
* Any failure — non-200, timeout, unexpected markup, or an old browser — falls
  back to a normal navigation, so a screen always loads.

= 5.27.8 - Every ZYMARG OS screen header is the same header =
* Fix: the Product Card screen had no Discovery Spark and no version badge. Its header was a bare `<h1>` with only the title, and its `.wrap` never carried the `zymarg-welcome` class, so it read as a different screen from the rest of the menu. It now renders the Spark at `lg` and the version badge like every other screen, and its intro paragraph uses `.zymarg-welcome__intro` instead of a one-off inline style.
* Fix: the Slugs & Pages version badge was a flat purple pill while every other screen showed the gradient pill. `assets/css/admin-brand.css` styles the badge by class name and simply never listed `.zymarg-registry__v`, so the older flat rule in `admin-registry.css` kept winning on that one screen. The brand layer now covers the registry badge and its intro paragraph too.
* Fix: the Customers detail header was missing the version badge, and the "Customer not found" fallback had neither Spark nor badge. Both now match.
* Note: the wp-admin sidebar is WordPress core navigation and loads each screen as a normal page request. The theme's AJAX/SPA navigation is the front-end My Account dashboard (assets/js/account.js); no admin-side SPA was ever shipped. See the 5.27.8 notes in the Help screen for why a wp-admin router is opt-in work rather than a bug fix.

= 5.27.7 - The Profile avatar now matches the sidebar avatar =
* Fix: the avatar inside Profile -> "Identity & email" ignored the design chosen for the sidebar avatar and rendered as a plain 64x64 square. The markup had always asked for `.zym-identity__avatar`, but that class was never written, so the thumbnail fell through to the browser's default image box - no radius, no cropping, and a stretch on any upload that was not perfectly square. `assets/css/account-accordion.css` now defines the class to mirror the sidebar treatment exactly: 44x44, 12px squircle radius, borderless, `object-fit: cover`, with a placeholder surface behind the image while it loads.
* Fix: the image's intrinsic `width`/`height` attributes in `zymarg_os_profile_render_avatar()` said 64 while the rendered box is 44, which reserved the wrong space and nudged the row as the photo arrived. They now agree with the rendered size; the file is still requested at 96px so it stays sharp on retina screens.
* Note: the Profile avatar remains display-only. Uploading, changing and removing a photo still happen at the one control in the dashboard sidebar - no second upload button and no duplicate AJAX flow were added.

= 5.27.6 - The empty box beside the security panel headings is gone =
* Fix: an empty rounded box sat to the left of the "Active sessions" and "Recent activity" headings. This was the theme's own doing, not the plugin's. The Login & Security plugin builds those headings as a chip wrapping the Discovery Spark, and 5.27.1's guard hid the spark but not the chip - a 44x44 white box with a border, radius and shadow, left framing nothing. The theme now hides the chip as well, so the heading sits flush; the chip's flex gap closes with it.
* Note: the plugin was read only for this fix. Nothing in it was modified, so a plugin update cannot undo the change and cannot bring the box back.

= 5.27.5 - No empty security cards; plugin panels styled over SPA navigation =
* Fix: the "Devices & sessions" and "Recent security activity" cards were printed unconditionally, so with nothing to put inside them the customer got an empty rounded box - a heading and a chevron wrapped around nothing. Each shortcode is now rendered into a variable first and the card is only opened when that output is genuinely non-empty, so an inactive plugin, or a section whose contents were removed, leaves no box behind.
* Fix: card numbers in the Security accordion are counted rather than hard-coded, so the list never reads 1, 4 when the two middle cards are absent.
* Fix: plugin-rendered panels appeared unstyled when Security was reached from another menu item, but correct after a reload. A section rendered inside admin-ajax cannot add anything to `<head>`, so a stylesheet the shortcode enqueues at render time never reached the browser. Both AJAX endpoints now diff the style and script queues around the render and report what was newly enqueued; `assets/js/account.js` adds those files once each, before the markup is shown. Dependencies and `wp_add_inline_style()` CSS are carried along, so this works for any plugin section, not just these two.
* New: `zymarg_os_acc_asset_snapshot()`, `zymarg_os_acc_asset_diff()`, `zymarg_os_acc_asset_url()`, and the `zymarg_os_account_ajax_assets` filter as an escape hatch for a plugin that enqueues its CSS only on `wp_enqueue_scripts` and never during the shortcode.

= 5.27.4 - Date of birth is three dropdowns, fully on brand =
* Changed: date of birth no longer uses a native date input. The browser draws that calendar panel outside the page, so no stylesheet can reach it - it could never be brought on brand. It is now Day / Month / Year selects using the theme's own select styling, which also suits the task far better: a calendar opens on the current month, so a birth year meant paging back hundreds of months, while a year dropdown is one tap.
* New: `zymarg_os_profile_render_dob()` and `zymarg_os_profile_dob_parts()`. The three controls post as one array under the existing `zymarg_dob` key, so the save handler still treats it as a single field and the "a missing key means not edited, never clear" rule is unchanged. Stored format stays `Y-m-d`, so nothing else that reads this meta needs to change.
* New: validation the native input could not do. `checkdate()` rejects impossible combinations such as 31 February, future dates are refused, and a partial date is reported as a mistake rather than silently clearing the field. Month names come from the active locale, so a Bengali site reads in Bengali.
* New: `zymarg_os_profile_dob_year_range` filter for the selectable years. Default is the last 100 years, ending 13 years ago.
* Note: the year list runs newest first, since a customer is likelier to be 25 than 95.

= 5.27.3 - Link buttons are on brand =
* Fix: `.zym-linkbtn` had no CSS anywhere in the theme, so "Change email address", "Cancel this change" and "Cancel" rendered as raw operating-system buttons - the only place in the account cards where browser chrome showed through. They are now brand text buttons in ZYMARG purple with a subtle hover, a focus ring, and a comfortable tap target. Because these are real `<button>` elements (they trigger behaviour rather than navigate), the reset has to be explicit: buttons do not inherit font or colour the way links do.
* Changed: the "Cancel" beside a primary submit, and "Cancel this change" in the pending-email block, are muted rather than purple, so the quieter choice never looks like the recommended one.

= 5.27.2 - Email card no longer looks duplicated; branded date field; gender options; honest password eye =
* Fix: the "Change email address" card appeared to have the same button twice. The reveal form is marked `hidden`, but `.zym-acc-form { display: block }` overrode it - the `hidden` attribute is only a user-agent `display: none`, so any explicit display rule beats it. The form was therefore always open beneath its own trigger. `[hidden]` is now enforced inside the account panels, which also repairs the pending-change and strength/match blocks that rely on the same attribute.
* Fix: the password reveal button showed an open eye emoji in both states, so it never indicated whether the password was masked. It is now a pair of inline SVGs - struck-out eye while masked, open eye while visible - swapped in CSS off the `.is-showing` class the script already sets, and `aria-pressed` is kept in step for screen readers.
* New: `zymarg_os_pw_toggle_button()` renders that control once and is reused by all five password fields (current, new, confirm, delete-account confirmation, email-change confirmation), replacing five copies of the same markup.
* Changed: date of birth is now branded as far as the platform allows. `accent-color` recolours the picker's selected day from the browser default blue to ZYMARG purple, `color-scheme: light` stops the field turning grey when the visitor's OS is in dark mode, and the calendar button is restyled to match the eye toggle. Note the calendar panel itself is drawn by the browser, not the page, and cannot be fully restyled in CSS - a scripted date picker would be required for complete control.
* Changed: gender options are now Female, Male, Non-binary, Transgender and Intersex, with "Prefer not to say" remaining the default. "Other" is removed. Anyone who previously stored `other` sees the field unset until they choose again; no stored data is deleted.

= 5.27.1 - Time zone pinned to Dhaka, locked-field badge removed =
* Changed: time zone is now locked to `Asia/Dhaka`, alongside currency. Bangladesh is a single time zone, so a per-customer picker could not add flexibility - only disagreement, since the field's own hint says order times and delivery windows follow it. A customer who set Asia/Tokyo would read a delivery window differently from the rider, the vendor and support. As with currency, a previously saved value is overridden on read, so no migration is needed.
* Changed: the locked-field "Fixed" badge is removed entirely, along with its CSS. The hint beneath the value already explains why it cannot be changed, so the badge was repeating it in a louder voice.
* Changed: the time zone hint now reads "Order times and delivery windows are shown in Bangladesh Standard Time."
* New: a defensive `display: none` for any `.zymarg-spark` inside the account panels. The Spark markup is gone and its stylesheet is no longer enqueued on My Account, which is precisely the risk: an unstyled `.zymarg-spark` has no dimensions of its own, so its SVG expands to fill the panel and takes the layout with it. A stale page cache, a cached older `account.js`, or a plugin injecting one can no longer break the page.
* Note: this release changes the theme version, which is what cache-busts `account.js` and the account stylesheets. If the old Spark is still visible after updating, the browser or a page-cache plugin is serving stale assets - purge and hard-reload.

= 5.27.0 - My Account saves without reloading; currency fixed to Taka =
* New: `inc/account-ajax-forms.php` - a single `zymarg_acc_form` AJAX endpoint that every My Account form now posts through. It calls the SAME handler the classic POST always called, so validation, nonces, capability checks and sanitisation are not duplicated or reimplemented; only the transport changed. Covers Profile (all four accordion cards), password change, email change and cancel, address save, address delete and set-default, and account deletion.
* Fix: every Save and Update button on My Account reloaded the whole page. Only section navigation, the preference toggles and avatar upload had ever been AJAX. Saves now happen in place, and scroll position plus which accordion cards are open survive the save.
* Fix: the "Go to Security" link at the foot of the Profile panel navigated the browser instead of switching sections. `assets/js/account.js` only intercepted sidebar nav links and dashboard cards, so a plain link inside a panel fell through. In-panel links pointing at another account section are now routed through the SPA. Matching is done on path AND query string, so the address delete / set-default links are not mistaken for navigation and stripped of their nonce.
* New: `assets/js/account-forms.js` - the delegated submit layer. Progressive enhancement throughout: with JavaScript disabled, without `fetch`, on an HTTP error, or on a network failure it falls back to the native POST, so a save is never silently lost.
* Changed: the handlers' `wp_safe_redirect(); exit;` calls became `zymarg_os_acc_redirect()`, which throws a control-flow exception during AJAX rather than terminating the response mid-request, and behaves exactly as before on a classic POST.
* Fix: WooCommerce notices were being lost on an AJAX save. Woo prints them from the page template, which a section swap never re-runs, so they are now drained into the JSON response, surfaced as toasts, and cleared so they cannot reappear on the next full page load.
* New: locked Profile fields, via `zymarg_os_profile_locked_fields()`. Currency is pinned to Bangladeshi Taka and rendered as a stated fact with a lock badge rather than a disabled control - there is no `<select>` to re-enable in devtools and no field to post. Enforced in three places: the renderer emits no input, the save handler ignores the key even if a crafted request contains it, and reads of the meta are filtered so a customer who saved another currency before this release is not still treated as that currency by email, exports or a vendor plugin. No migration pass needed.
* Changed: the currency field is labelled "Currency" rather than "Preferred currency", which it no longer is, and states that prices, refunds and payouts are all in Taka.
* Changed: the Discovery Spark is no longer used as the My Account section loading mark. It was the only animation anywhere in the account panels, and it became visible on Security once "Go to Security" started routing through the SPA instead of reloading. The loading state is now a reserved, unanimated panel with screen-reader-only text, and the Spark stylesheet is no longer enqueued on My Account at all - one fewer stylesheet on the page. `ZymargAccount.spark` is replaced by `ZymargAccount.loadingText`.
* Changed: the locked-field badge is text only, dropping its lock glyph, to match the rest of the panels.
* Note: the `panel-header` icons are untouched. Profile ships `user` and Addresses ships `map-pin`, so Security's `lock` is the consistent choice, not the odd one out.
* Note: time zone is deliberately left editable for now. Locking it to `Asia/Dhaka` is one line in `zymarg_os_profile_locked_fields()`.
* Note: this pins the CUSTOMER's stored preference only. The store currency (WooCommerce -> Settings) and site time zone (Settings -> General) are separate and should agree, or the two will drift.

= 5.26.2 - Product Card screen branded, form-table geometry corrected =
* Fix: the Product Card screen rendered `<div class="wrap">` with no `zymarg-admin` class, so it was the one theme screen still outside the back-end token scope and stayed unbranded while every other screen changed. The "Customer not found" branch in `inc/admin-customers.php` had the same gap. Both now carry the class, and every `class="wrap"` in the theme is accounted for.
* Fix: text escaped the card on Account & Security. The 5.26.1 card recipe was applied directly to `table.form-table`, but core sets `border-collapse: collapse` on it. Under collapse the cell borders belong to the table rather than the cells, so they paint straight through the `border-radius` instead of being clipped by it, and padding on the table box does not reliably contain cell content. The table now uses `border-collapse: separate` with no padding of its own, and the card's inner spacing is carried on the cells. Identical appearance, correct geometry.
* Fix: `.large-text` and `.regular-text` fields inside a padded cell could exceed the card. Form controls in a form-table are now `box-sizing: border-box` with `max-width: 100%`.
* Fix: long form labels now wrap inside core's 200px label column instead of overflowing it.
* Changed: `h2.title` section labels sit tighter to the card they name, instead of floating midway between two cards.
* Housekeeping: removed a duplicated `.wrap.wrap` compound selector introduced by the 5.26.1 patch. Valid CSS, but unintended specificity.

= 5.26.1 - The back end now actually consumes the brand tokens =
* Fix: `.zymarg-admin` was declared in `tokens/zymarg-tokens.css` but never rendered by any screen. Every back-end-only token (`--zym-radius-control`, `--zym-shadow-surface`, `--zym-color-neutral-text`, the admin font stack, the 3px focus ring, the 1200px container) therefore resolved to nothing, and the admin screens silently inherited the FRONT END `:root` values instead -- Inter Variable, 1280px, the 4px focus ring. The class is now on every theme admin wrapper, which switches the whole back-end token block on. Token document section 2, placement.
* Fix: the Discovery Spark's drop-shadow glow was still the upstream indigo `rgba(104,51,234)` in all nine keyframe positions while the lens fill had already been recoloured to `#9500A5`. This is the exact mistake section 3.8 warns about: recolouring the fill and leaving the glow behind. Both now read the brand purple.
* Fix: the `[zymarg_spark]` shortcode still defaulted to the upstream `purple="#6833EA"`.
* Fix: the admin version badge was a solid `--color-primary` fill at 3px 10px / weight 600 / 0.02em / `999px`. It is now the section 2.14 gradient pill: 6px 12px, weight 700, 0.04em, `--zym-radius-pill`, with the specified shadow.
* New: `assets/css/admin-brand.css` -- sections 2.8, 2.11 and 2.14 scoped to `.zymarg-admin`. Brands the WordPress core primitives the screens actually render (`.button-primary` was shipping WordPress blue, plus `.form-table`, `p.description`, form fields, checkboxes, notices, tables, `code`, `hr`, links), and restyles the screen `<h1>` to the 2.14 header card with its 3px gradient top strip.
* New: `assets/css/admin-menu-brand.css` -- section 2.16. The top-level sidebar item now carries the brand gradient at rest in every state, with a surface-white label and the decorative `wp-menu-arrow` hidden. Scoped to `#toplevel_page_zymarg-os`, so it cannot reach another menu item, another plugin, or the front end. Anchors are matched with `> a`, never `> a.wp-has-submenu`, which is the selector bug that makes branding appear only after the menu is clicked.
* Changed: `inc/admin-dark.php` now enqueues the shared `zymarg-tokens` handle in admin, guarded with `wp_style_is()` so it still deduplicates against any ZYMARG plugin shipping the same file. The menu stylesheet is enqueued unconditionally on every admin page, not gated on the theme's own screens.
* Housekeeping: Stable tag in readme.txt was stuck at 5.21.2 while style.css was at 5.26.0.
* Note: `ZYMARG_OS_TOKENS_VERSION` deliberately stays at 2.0.0. No token VALUE changed in this release, and the token document is explicit that the token file version is bumped only when one does.
* Known remaining work, deliberately not in this release: the front-end and login spinners still exist and violate section 3.1; the sidebar icon is a raster logo that cannot be masked to surface white; the six screen headers still use a plain `<h1>` rather than the 2.14 reference markup; roughly 40 inline styles and 180 hardcoded hex values remain across the admin PHP and `admin-import.css` / `admin-registry.css`.

= 5.21.2 - The shop loop now renders the actual branded card =
* Fix: the shop loop was never rendering the ZYMARG card at all. The theme loaded the engine's `grid/product-card.php` directly, but that file IS the engine's own default card, not a dispatcher -- it never consults the card registry. Every card on the shop page was the engine's default card wearing the theme's base typography, which is why no amount of CSS correction ever made it match the brand design. Cards now render through `Template_Manager::render_card()`, the engine's real dispatcher.
* Fix: neither the engine's core stylesheet nor the card's own stylesheet was ever enqueued on the shop loop. Both load from `Asset_Manager::enqueue_for_render()`, which only runs inside `Render_Engine::render()` -- a path the theme never took. The theme now calls that same method on `wp_enqueue_scripts`, so the loop loads exactly the assets a native engine render loads, under the engine's own handles, and in the page head rather than the footer.
* Fix: the Product Card status rows could all read green while the branded card was not being rendered. `Template_Manager` ships with the engine, so its presence proves nothing about the pack, and a card file on disk proves nothing about registration. The pack row now asks the registry via `is_registered_card()`.
* Removed: the 5.21.1 stylesheet fallback, which guessed the pack's plugin folder and enqueued under a theme-owned handle. The engine's pipeline is used instead, so the file can no longer load twice under two handles.

= 5.21.1 - The card stylesheet now always loads =
* Fix: the branded card's stylesheet loaded only when the grid engine's asset lookup returned a URL. When it returned nothing, the branded card markup rendered with its own CSS entirely absent, so the theme's base typography took over: the card title fell back to `clamp(1.3rem, 2.4vw, 1.75rem)` (~21px on a phone instead of 12px), overflowing its 2-line clamp, truncating the seller name to a single letter and pushing the add-to-cart button over the vendor row. Most visible on phones, where cards are only ~160px wide.
* Changed: the theme now resolves `style.css` and `script.js` directly from the card template's own directory when the engine does not supply them, so the card design no longer depends on the engine's asset pipeline having registered first.
* Note: the file is read from within the plugins directory only, and the engine's own URLs still win when it does provide them.

= 5.21.0 - Space between cards is now a setting =
* New: Space between cards at ZYMARG OS -> Product Card. Separate gap in px for mobile, tablet, desktop and large desktop, 0 to 64, applied to every product grid alongside the existing Cards per row counts.
* Fix: WooCommerce core's `ul.products li.product { margin-bottom: 2.992em }` stacked on top of the grid gap, so rows sat roughly 48px apart instead of the intended gap. Grid now owns card spacing and the legacy margin is zeroed.
* Changed: default gaps are tighter and device-aware (10 / 16 / 20 / 24px) instead of a fixed 24px at every width, which was heavy on phones where cards are only ~160px wide.
* Changed: column counts and gaps now resolve from one `zymarg_os_product_card_views()` breakpoint map, so the two can no longer drift onto different breakpoints.

= 5.20.11 - Seller avatar guard now covers every grid =
* Fix: the 5.20.10 avatar guard only matched the theme's own shop-loop wrapper, so engine-rendered grids (Elementor widget, shortcodes, Dokan store pages) still showed the stretched seller picture. The guard is now container-agnostic and also ships in `woocommerce/product.css`, which loads on every WooCommerce context.

= 5.20.10 - Shop grid columns and the seller avatar =
* Fix: product cards no longer collapse to a single full-width column on phones, or to two columns on tablets. `woocommerce/product.css` declared the shop grid columns twice; the later, lower block silently overrode the intended 3 / 2 counts.
* Fix: the seller profile picture on the shop loop no longer stretches to the full card width. WooCommerce's own `ul.products li.product img { width: 100% }` outranked the branded card's class-only 20px avatar rule, so the theme's layout glue now pins it back to a 20px circle.
* Fix: the branded card's layout CSS and the admin column counts are now enqueued even when the grid engine exposes `Template_Loader` without `Templates\Template_Manager`. The card markup used to render with no styling at all in that case.
* Fix: the Cards per row -> Desktop setting now actually drives the WooCommerce shop loop. The column count and the CSS custom property were resolved from the same filter with two different defaults (5 and 3), and neither read the saved setting.
* Changed: shop column counts now resolve through one `zymarg_os_shop_columns()` helper, still filterable via `zymarg_os_shop_columns`.

= 5.20.8 - Product card grid columns per device =
* New: Cards per row settings for mobile, tablet, desktop and large desktop at ZYMARG OS -> Product Card, applied to every product grid.
* Fix: product cards stacked one per row on the shop page and on the theme-rendered grids (search, archives, related products, upsells).
* Fix: removed the double card frame on the shop loop, where the theme border wrapped the branded card border.

= 5.20.7 - Branded product card everywhere, with an admin toggle =
* New: ZYMARG OS -> Product Card panel to switch the branded card on/off (plus a shop-loop sub-toggle) with a live status readout.
* New: the branded card now also renders on the shop page, product categories/tags and [products] loops.
* Fix: branded card CSS/JS now load on every surface that renders the card, not just the account page.
* Changed: the theme card override now routes to the Template Pack instead of duplicating it, so pack updates apply with no re-sync.

= 5.20.6 - Moved the card override guide out of the theme =
* Changed: docs/PRODUCT-CARD-OVERRIDE.md has been removed from the theme and now ships with the ZYMARG Template Pack plugin instead, where the card markup it documents actually lives. It does not belong in the theme every site downloads. The explanation of why the override is needed remains inline in inc/account-sections.php, now with a pointer to the full guide. No functional change.

= 5.20.5 - Documented how the account product card override works =
* Added docs/PRODUCT-CARD-OVERRIDE.md, a developer guide to the branded product card on the My Account Wishlist and Recently Viewed tabs. It records why those two tabs bypass the product grid plugin's render engine, the three approaches that look correct but silently do nothing (the card_template attribute, the card-settings filters, editing the plugin's own template), why is_wc_endpoint_url() must not be used to scope anything on the theme's custom account endpoints, and how to re-sync the override copy after a Template Pack update. Documentation only - no functional change.

= 5.20.4 - Recently Viewed & Wishlist really do use the branded card now =
* Fixed, properly this time: the My Account Recently Viewed and Wishlist tabs kept rendering the ZYMARG WC Product Grid plugin's default card. Both shortcodes render their cards by calling the plugin's Template_Loader for the literal path grid/product-card.php, bypassing the plugin's Render_Engine entirely - so they never consult the card-template registry (no card_template attribute, no *_card_settings filter can reach them) and never trigger the plugin's automatic card asset loading. The theme now ships the override Template_Loader itself documents, at zymarg-wcpg/grid/product-card.php (an unmodified copy of the ZYMARG Template Pack's own branded card), and enqueues that card's stylesheet and script directly from the Template Pack. Which products appear, columns, limits, fallbacks and empty states are all untouched.
* Removed the two earlier attempts at this that could not work: the card_template shortcode attribute (5.20.1) and the card-settings filter hooks (5.20.2 / 5.20.3).

= 5.20.1 - Recently Viewed & Wishlist now use the branded card =
* Fixed: the My Account Recently Viewed and Wishlist tabs rendered with the ZYMARG WC Product Grid plugin's default card instead of the ZYMARG Template Pack's branded card used everywhere else in the store. Both shortcode calls now pass card_template="zymarg"; columns, limits, fallbacks and empty states are unchanged.

= 5.20.0 - Collapsible groups, saving without a reload, your own 404 design =
* **The three groups are now collapsible.** With WooCommerce and Dokan active the screen listed 38 URLs in one continuous table. Each source is now a collapsed panel whose summary carries the URL count and, when any are switched off, how many - so a closed group still answers "is anything off in here?". A group opens automatically when it contains something switched off. Built with `<details>`, so it works without JavaScript and the browser's own find-on-page still searches inside it.
* **Save no longer reloads the page.** The Save button posts over admin-ajax.php and reports the result in a live region, so a screen reader announces it too. The form keeps its method and hidden fields, so with JavaScript unavailable the browser posts it normally and the old handler answers exactly as before. Both paths write through one shared storage function rather than two that could drift.
* **New: your own HTML design for the 404 page.** Paste a complete standalone HTML file, the same way the ZYMARG Homepage plugin accepts one for a homepage section, with two placements: **Full page** sends your file exactly as written, and **Inside my layout** removes the document wrapper and confines your CSS to the 404 area so `* { margin: 0 }` and `body { overflow: hidden }` cannot strip or freeze your header, menu and footer. Scripts are kept. Filter `zymarg_os_404_allow_scripts` to strip them.
* **Fixed: switching off the Dokan "Dashboard" section took out every vendor dashboard.** Dokan names its first dashboard section `dashboard`, the same slug as the dashboard page, and the matcher compared slugs only - so a rule meant for `/dashboard/dashboard/` also matched `/dashboard/`. Vendor sections are now matched on both path segments.

= 5.19.1 - Slugs & Pages naming, header spark, clearer switch-off state =
* **Renamed** the submenu from "Pages & Slugs" to **Slugs & Pages**.
* **Fixed: the discovery spark was missing from the screen heading.** Every other ZYMARG OS admin screen opens with it; this one did not. Now uses the same `zymarg_discovery_spark( array( 'size' => 'lg' ) )` call as Welcome, Help, Import, Performance and Toast.
* **Fixed: the 404 option served the 404 template manually.** The rule now flags the query with `set_404()` and lets WordPress load `404.php` through its normal path, instead of including the template and exiting. Manually including it bypassed the `template_include` filter and could render the header twice on requests where output had already begun.
* **Fixed: the switch-off controls looked active when they were not.** The Redirect / Show 404 dropdown only takes effect once a row is unticked, but nothing said so. Each row now shows its real saved state in words - **Active**, **Off - redirects**, or **Off - shows 404** - the column carries the hint "Only applies when Active is unticked", and the inert controls are dimmed via CSS `:has()` while the row is still active. The fields stay enabled so their values still save.
* Internal: corrected `--zym-font-xxs` to the real token name `--zym-font-size-xxs` in the new admin stylesheet.

= 5.19.0 - Slugs & Pages: every URL on the site, in one place =
* **New: ZYMARG OS > Slugs & Pages.** A registry of every front-end URL the site responds to, grouped by which layer created it: this theme's 8 My Account endpoints, WooCommerce's account endpoints and page settings (shop, cart, checkout, my account, terms), and Dokan's vendor pages, dashboard sections and vendor store URL prefix.
* Each row can be switched off, with a per-URL choice of what happens instead: **redirect** to a destination you pick, or a genuine **404**. Leaving the redirect field empty sends account URLs to My Account and everything else to the home page.
* Switching off a My Account section also removes it from the account sidebar, and switching off a WooCommerce endpoint removes it from WooCommerce's account menu, so a disabled URL never leaves a visible broken link.
* URLs that WooCommerce and Dokan need in order to function (checkout, cart, order-pay, order-received, lost-password, edit-account, payment methods, the vendor store prefix) are marked **Required** and ask for confirmation before being switched off. They are flagged rather than hidden, because the decision belongs to the site owner.
* Endpoints stay registered when disabled, and are intercepted at `template_redirect` instead. Unregistering them would make a redirect impossible and would force a rewrite flush on every save.
* Front-end enforcement reads a self-contained snapshot saved with the settings, so a disabled URL costs one array lookup per request. Discovery is admin-only and never runs on the front end. Every Dokan call is guarded by `function_exists` and wrapped, so a Dokan update cannot fatal the site.
* Internal: `zymarg_os_account_endpoint_slugs()` now provides the single definition of the theme's account endpoint slugs, replacing the duplicated list that was maintained in both the rewrite registration and the query-var filter. New filters: `zymarg_os_page_registry_items` and `zymarg_os_account_endpoint_slugs`.

= 5.18.3 - Browse destination is now a setting, not a hardcoded slug =
* **Changed: "Start Shopping" now goes to /store-listing/** instead of WooCommerce's /shop/. Rather than hardcoding the slug in a template, this adds a `shop` key to `zymarg_os_account_link()` with a new Customizer field under **ZYMARG OS > My Account - Links**, defaulting to `/store-listing/` and falling back to the WooCommerce shop page if cleared.
* The `order_again` link behind "Buy Again" still builds on WooCommerce's own shop page, because that is the URL WooCommerce expects to handle. The browse destination and the re-order base URL are deliberately separate values.

= 5.18.2 - Brand status colours, and Quick Actions that are actually actionable =
* **Fixed: Quick Actions no longer offers dead ends.** In the Orders section the three cards rendered unconditionally, so a customer with zero orders was still shown "Track Order - check delivery status", "Refund Request - start a return" and "Buy Again - reorder your items". There was nothing to track, return or reorder, and "Buy Again" quietly fell back to a plain shop link, so its label described something it was not doing. Track and Refund now appear only when at least one order exists; Buy Again appears only when there is a completed or processing order to re-order from. With no orders, a single "Start Shopping" card is shown instead.
* Minor performance side effect: the extra `wc_get_orders()` lookup behind "Buy Again" no longer runs at all for customers with no orders.
* **Brand status colours.** The twelve order/return status chips in `woocommerce/account.css` were hardcoded Bootstrap-era pairs (`#d4edda` green, `#cce5ff` blue, `#fff3cd` amber, `#f8d7da` red). They are now three tokenised families: settled/done on the brand accent, in-progress on `--zym-color-warning`, failed on `--zym-color-danger`. Each chip still prints its own status text, so meaning never depends on hue.
* `components/badges.css` success/warning badges tokenised for the same reason, removing the last green (`#1c7c43`) from the front end.
* All of these now follow dark mode, since they reference the dark-aware `--color-primary` channel rather than a fixed light-mode tint.

= 5.18.1 - The green success state, and the AJAX notice paths =
Follow-up to 5.18.0. Branding the classic notices revealed that a *second*, green message could appear a moment after a save, on top of the freshly branded one. That green came from the theme itself, and it was the last un-tokenised colour on the front end.

* **Fixed: green success states are gone.** `components/toast/toast.css` hardcoded `#1ea860` for the success toast's left border, icon and progress bar, and `components/login.css` hardcoded `#059669` for AJAX login/register success. PART 1 of the token document contains no green, so both now carry the brand accent. Error and warning states in both files were also hardcoded and are now `--zym-color-danger` and `--zym-color-warning`.
* Success and info deliberately look alike; the toast icon still differs per type, so state is never signalled by colour alone.
* **New: Cart and Checkout BLOCK notices are now branded.** The blocks never render the classic notice classes - they mount `.wc-block-components-notice-banner` client-side after hydration, which is why a message there arrived late and off-brand. Also covers `.wc-block-components-validation-error` so a failed checkout field matches a failed account field.
* Toast accents use `--color-primary` rather than `--zym-color-primary` so they follow dark mode, since the `--zym-*` palette is light-mode only.
* No new hardcoded colours anywhere: every value in the touched rules resolves to a token.

= 5.18.0 - Branded save and error messages =
Every "saved" and "error" message in the account area was still rendering in WooCommerce's stock grey box. The Profile save, the Address save, login, cart and checkout all print their messages through WooCommerce core's `wc_add_notice()`, and nothing in the theme styled those classes - so the message was the one part of a fully branded screen that was not on brand. This release brands them.

* **New: `woocommerce/notices.css`** - a brand skin for `.woocommerce-message`, `.woocommerce-info` and `.woocommerce-error`. Surface fill tinted with the brand accent, 1px brand border, card radius, purple-tinted card shadow and a 3px brand strip on the top edge, replacing WooCommerce's grey `#f6f6f6` fill and flat top border.
* **New: `tokens/zymarg-tokens.css`** - the shared `--zym-*` brand token file, enqueued with the shared `zymarg-tokens` handle so WordPress deduplicates it against every ZYMARG plugin shipping the same file. Versioned independently via the new `ZYMARG_OS_TOKENS_VERSION` constant, per the token document: bumped only when a token value actually changes, never on a theme release.
* State is never signalled by colour alone: success, info and error each carry their own masked SVG icon, so the icon distinguishes them even where the colour cannot. Success and info deliberately share the brand purple because the front end palette has no green and inventing one is forbidden.
* Error messages use `--zym-color-danger`, the palette's only front end red.
* Full dark-scheme support. The `--zym-*` palette is light-mode only, so the notice's component-local channels repoint to the theme's `data-theme` dark tokens - the same way every other component in the theme flips. No `--zym-*` value is ever redefined.
* Multi-error validation lists (`<ul class="woocommerce-error">`) drop their bullets and align under the block icon; inline action buttons such as "View cart" pick up the brand button radius and stack instead of floating under 768px.
* Keyboard focus on links and buttons inside a notice uses the brand focus ring. Reduced-motion preferences are respected.
* Loaded whenever WooCommerce is active rather than only in shop contexts, because `wc_add_notice()` output can surface on login, password reset and any page holding a Woo form.
* No markup, template or save-handler changes. Nothing about how Profile or Addresses validate and save was touched - only how the resulting message looks.

= 5.17.0 - Stable toast contract: no more theme edits =
This release closes the last gaps that would have forced future theme edits every time a plugin was wired into the shared toast system. From here on, adding or migrating a plugin is a plugin-only change.

* **New: toasts now work on wp-login.php.** The login screen is neither "front end" nor "admin", so neither existing hook fired there and `window.ZymargToast` did not exist. Login and security plugins are the most likely to want a toast on exactly that screen. Controlled by the new `zymarg_os_toast_enable_on_login` filter.
* **New: plugins no longer need their own fallback popup.** A tiny inline stub is printed early on every page, so `window.ZymargToast` always exists. Toasts fired before the main (deferred, footer-loaded) script has finished loading are queued and replayed automatically instead of being silently lost. This removes the single biggest reason plugins kept shipping duplicate toast code. Controlled by the new `zymarg_os_toast_early_stub` filter.
* **New: the plugin scanner's detection patterns are now filterable** via `zymarg_os_toast_scan_patterns` (and `zymarg_os_toast_scan_source_regex`). A missing pattern is what made the scanner wrongly report "no toast code" for a plugin that visibly showed toasts; that can now be corrected from a plugin or child theme instead of requiring a theme edit.
* New: `docs/TOAST-INTEGRATION.md` documents the complete, stable contract - how to fire a toast from JS or PHP, how to register a source so it gets an on/off toggle, every available filter, and how to migrate a plugin that ships its own toast.
* No breaking changes. Existing integrations, sources, toggles and logs continue to work untouched.

= 5.16.18 =
* Added `zymarg-single-product` to the always-listed toast sources, so the ZYMARG Single Product plugin (2.4.8+) gets its on/off toggle on the Toast Notification screen immediately, without waiting for a toast to fire or a plugin scan to run.

= 5.16.17 =
* **Fix: the Sources table was empty on a fresh install, so there were no toggles to see.** A source only appeared in the list after it had already fired a real toast, or after a plugin code scan found a declared source name. On a new site neither had happened yet, so the screen showed "Nothing here yet" and no controls at all. The theme's own known sources are now always listed, so there is always something to switch on or off.
* New: `zymarg_os_get_known_toast_sources()` plus a `zymarg_os_known_toast_sources` filter, so the always-listed set can be extended from a child theme or plugin.
* **Fix: replaced the confusing inverted checkbox with a real on/off toggle switch.** Previously ticking a box meant "switch this source OFF", which read backwards. The control is now a green/grey switch where ON means enabled, matching what everyone expects.
* The form now posts the visible rows alongside the enabled ones, so turning a source off is recorded reliably instead of depending on unchecked-box behaviour. The old checkbox format is still accepted for backward compatibility.
* Accessibility: each toggle has a proper screen-reader label and a visible keyboard focus ring.


= 5.16.16 — Toast system now available inside wp-admin =
* Fixed a structural gap: the shared toast assets were only enqueued on `wp_enqueue_scripts` (front end), so `window.ZymargToast` did not exist in wp-admin. Any plugin firing admin-side notices through the theme API silently fell back to its own popup — the exact fragmentation the Toast Notification screen exists to prevent.
* The toast stylesheet and script are now also enqueued on `admin_enqueue_scripts`, so admin toasts share the site's design language and are logged and controllable like front-end ones.
* New filter `zymarg_os_toast_enable_in_admin` (default `true`) to switch admin-side toasts off without editing the theme.

= 5.16.15 — Fix: toast scanner false negatives + detect plugin-owned toast systems =
* Fixed: the plugin scanner reported "no toast code" even when plugins were clearly using the toast system. Two causes: (1) it only matched the literal "ZymargToast.show(" and missed the normal aliased style (var api = window.ZymargToast; api.show(...)); (2) hitting the global file cap aborted the entire scan, so plugins later in the alphabet were never reached.
* Fixed: the file budget is now per-plugin instead of global, and partially scanned plugins are reported instead of failing silently.
* New: "Check one specific plugin" box — scan a single plugin by folder or name for a fast, complete result.
* New: detects plugins that ship their OWN toast system instead of using the theme API, and flags them as "Own toast system — NOT controllable here".
* New: evidence now shows the exact file, line number and code snippet for every match, plus scan diagnostics (files read, plugins checked).

= 5.16.14 — Feature: scan plugins for toast usage without triggering one =
* New: Toast Notification screen now has a "Scan Installed Plugins Now" button. It reads every installed plugin's PHP/JS files directly and reports which ones already call the toast system (window.ZymargToast, the zymarg:toast event, or zymarg_os_queue_toast()) — no need to wait for a toast to actually fire on the front end.
* New: when the scan finds a plugin that declares a `source` name in its code, that source is added to the Sources table immediately, marked "Not fired yet", so you can review or switch it off in advance.
* New: scan results also show each plugin's active/inactive status and which file(s) the toast calls were found in.

= 5.16.13 — Feature: Toast Notification source tracking + control panel =
* New: every toast (add to cart, wishlist, login, reviews, and any of your ~25 plugins wired into the shared toast system) can now be tagged with a `source` so you can tell which plugin/feature fired it. Untagged calls are logged as "unknown".
* New: ZYMARG OS -> Toast Notification admin screen — shows a live activity log (last 200 toasts) and per-source counters (shown/blocked, last seen, last message).
* New: any source can be switched off from that screen. Disabled sources stop showing toasts immediately, both for server-queued toasts and toasts fired directly by front-end/plugin JS — no plugin code changes required.
* Cleanup: removed the unused, unreferenced `ui/toast.css` stub that duplicated `.zymarg-toast` styling under different class names and was never enqueued.

= 5.16.11 — Change: hide the whole section header, not just its text =
* Change: the section-icon that sat beside the section name on every My Account panel is now hidden too, and the 2px horizontal divider under the panel-header is gone with it. In 5.16.10 only the h2 text was hidden, so the icon and divider still painted with nothing between them — this closes the visual gap the earlier release left. The panel now opens directly with the section description, which was already the first line that named the section in context.
* Change: the "Go to Homepage" button that sat in the same slot on the Dashboard section header is also hidden. The site's main navigation already offers a home link on every page, so the extra button here was redundant once the header that framed it stopped rendering.
* Note: the h2 itself stays in the DOM under the standard `.screen-reader-text` clip pattern, so screen readers still hear "Support" / "Orders" / etc., the page outline stays valid, and reverting to a visible header is still a one-line CSS change. The icon svg and the home-icon link are the only things dropped from the accessibility tree — both carry no accessible name (no aria-label, no title beyond "Go to Homepage" which duplicates the site nav) so the loss is purely decorative.

= 5.16.10 — Change: hide the section-name heading on My Account =
* Change: the "Section Name" `<h2>` at the top of every My Account section (Dashboard, Orders, Wishlist, Recently Viewed, Addresses, Profile, Notifications, Reviews, Vouchers, Returns & Refunds, Support, and the rest) is no longer visible. The sidebar's active state already indicates the section, and the section description directly below the heading also names the section in context, so the h2 read as redundant on every panel.
* Note: hidden visually with the standard `.screen-reader-text` clip pattern rather than removed from the HTML. The heading is still in the DOM, still announced by screen readers, and still contributes to the page outline and search-engine outline — so a11y and SEO are unaffected. Reverting to the visible heading is a single-line CSS change if you ever want it back.
* Note: nothing else changes. The panel description, section icon, "Go to Homepage" button on the Dashboard header, the horizontal divider below the header, and every action-card, list and control below are all untouched. Paired with Vendor Dashboard 1.46.12, which lands the same section-name-hidden treatment on the vendor's own dashboard.

= 5.16.9 — Polish: My Account tile title size =
* Change: `.action-card .ac-label` moves from 13px to 14px. A one-notch bump so the title reads well next to the 38x38 icon square, especially now that Contact Support has no subtitle. Every action-card on My Account (Track Order, Refund Request, Buy Again, Contact Support, Help Center) picks up the change together.
* Note: paired with Vendor Dashboard 1.46.11, which lands the same 13->14 bump on its Support tile and adds a scoped mobile subtitle fix and an SVG stroke-width match so the two Support surfaces read identically on every viewport.

= 5.16.8 — Fix: My Account Support tile alignment and copy =
* Fix: on My Account -> Support, the "Contact Support" tile rendered its text centred inside its column while every other tile on the surface was left-aligned. The tile is the only `<button class="action-card">` — every other action-card is an `<a>` — and browsers default `<button>` to `text-align: center`, which the two block-level divs inside inherited. `.action-card` now sets `text-align: start` at the root so buttons and anchors on this shape are normalised in one place. Every action-card on My Account (Track Order, Refund Request, Buy Again, Help Center, Contact Support) shares the fix.
* Change: the "Chat or email our team" subtitle under Contact Support on the Support panel is gone. The tile now shows just the title, matching how buyers read the row in practice. Help Center keeps its "FAQs and guides" subtitle because it disambiguates a card that isn't otherwise self-explanatory.
* Note: the paired Vendor Dashboard release ships the same subtitle drop and adopts this exact tile design on its own Support section, so a buyer's Support panel and a vendor's Support section now read identically.

= 5.16.1 — Fix: the sidebar order control was invisible on most sites =
* Fixed: the "Sidebar link order" control added in 5.16.0 did not appear. Its
  class was declared in inc/customize-controls.php, which functions.php only
  loads when the ZYMARG Login & Security plugin is INACTIVE — it is grouped with
  the theme's login fallback. On any site running that plugin the class never
  existed, so the control was silently skipped and My Account — Links showed
  only its three URL fields. The class now lives in inc/account-dashboard.php
  alongside the section it belongs to, which loads whenever WooCommerce is
  active — i.e. whenever there is a My Account page to order.
* Note: inc/customize-controls.php is byte-identical to 5.15.2 again. Nothing
  else changed; if you never saw the control, 5.16.0 behaved exactly like
  5.15.2.

= 5.16.0 — You choose the My Account sidebar order =
* New: Customize -> ZYMARG OS -> My Account — Links gained a "Sidebar link
  order" control. Drag a link into place, or move it with the arrow buttons,
  which also work by keyboard and on touch. The order applies to every
  customer's My Account page.
* New: filter `zymarg_os_account_nav_items`. The My Account sidebar array had
  never been filterable, so nothing outside the theme could reorder it — a
  plugin could only append a section next to an anchor via
  `zymarg_os_account_sections`. The assembled array now passes through this
  filter, keyed by slug.
* New: `zymarg_os_account_nav_config()` is now the single source of truth for
  the sidebar. Both the front end and the Customizer control read from it, so
  they can never disagree about which links exist.
* Note: the order is stored as a sparse weight map, not a rebuilt list, and the
  sort only ever reorders — it cannot add or drop a link. No section can be
  removed from a customer's account page by a saved order, including sections
  added later by a plugin. Keys are preserved, because the URL map, the active
  -section resolver and the section renderers all look up by slug.
* Note: only sections currently available are listed. One that appears later
  (e.g. after activating a plugin) is anchored to the link it naturally follows
  — so it shows up next to that link wherever you have moved it to, rather than
  at an unrelated slot.
* Note: with the setting untouched the sidebar is identical to 5.15.2.

= 5.15.2 — Help text now matches the code =
* Fixed: the Product Reviews help card called reviews "built-in" with "no plugin
  needed". They come from the ZYMARG Reviews Engine plugin, which has to be
  active. The card now says so.
* Fixed: it described a "15/30-day window" for writing a review. There is one
  setting, 15 days by default. Corrected.
* Fixed: it sent you to WooCommerce -> ZYMARG Reviews for settings. The engine
  registers its own top-level ZYMARG Reviews menu. Corrected.
* Fixed: it promised photos are "auto-compressed in the browser". Nothing does
  that. The theme file that once did was never enqueued and the engine has no
  equivalent, so the claim is gone rather than left to mislead.
* Removed: assets/js/review-image-compress.js and assets/css/admin-reviews.css.
  Neither was referenced by any file in the theme.

= 5.15.1 — Fixed: the My Account review surfaces =
* Fixed: the "Write Review" button in My Account -> Reviews -> Pending linked to
  the product page anchor #reviews, which is not where the review form lives.
  The button now builds its URL with the Reviews Engine's own
  Review_Tracker::get_review_url(), passing the order and order-item ids, so the
  link carries the nonce the form needs and lands on the form itself. If the
  engine is not active the old permalink is used as a fallback.
* Fixed: the Pending tab listed items the buyer could no longer review. It now
  skips orders outside the engine's review window and hides individual items
  that already have a review, instead of only de-duplicating by product.
* Fixed: the My Reviews tab queried approved comments only, so a review held for
  moderation vanished from the buyer's own list with no explanation. Pending
  reviews are now listed and badged "Awaiting approval"; spam and trashed
  comments stay hidden.
* Fixed: a review with no rating rendered as an empty star badge. It now reads
  "No rating".
* Changed: the Pending tab scanned the 10 most recent orders and My Reviews
  showed 20 entries. Both are now 50 and filterable via
  zymarg_os_pending_reviews_order_limit and zymarg_os_my_reviews_limit.
* Housekeeping: Stable tag in readme.txt was stuck at 5.12.20 while style.css
  had reached 5.15.0; both now track the same number.

= 5.12.20 — Changed: squared the sidebar's right edge in Messages =
* Changed: .zymarg-acc-sidebar no longer rounds its top-right and bottom-right
  corners while the Messages section is active. The sidebar rounds those
  corners so it reads as a panel floating against the page, which works
  wherever the content column has a gutter. In Messages the gutter is 0 and the
  inbox now squares its own outer frame, so those two curves peeled away from
  the flush edge and showed small notches of background at the sidebar's top
  and bottom corners.
* Scoped: the rule is keyed to body.zymarg-acc-section-messages, so every other
  account panel keeps the rounded sidebar exactly as it is. It is also wrapped
  in min-width: 768px, because below that the sidebar is an off-canvas drawer
  and is not adjacent to the content at all.
* Unchanged (deliberately): the sidebar width stays 260px, and its padding,
  gap, background and border-right are untouched. Only the two corner radii on
  the side that touches the inbox change.
* Note: pairs with ZYMARG Communication 1.25.2, which squares the inbox's own
  outer frame. Install both together.

= 5.12.19 — Fixed: section body class now stays in sync over AJAX =
* Fixed: the zymarg-acc-section-* body class was only emitted by PHP on a full
  page load, but the My Account page swaps sections over AJAX. Any styling
  keyed to that class therefore applied on a hard refresh and then silently
  stopped matching once the visitor navigated between sections, so panels
  looked correct after a reload and wrong after a click.
* Added: assets/js/account.js now strips any existing zymarg-acc-section-*
  class and applies the one for the newly loaded section, keying off the same
  sanitised section slug PHP uses, so both paths always agree.

= 5.12.18 — Changed: one consistent gutter for every My Account panel =
* Removed: the 960px max-width and the margin: 0 auto centering on
  .zymarg-acc-main .main-content. That pair made panel alignment depend on the
  viewport: on a wide screen the column floated in the middle of the main area,
  while on a laptop the cap never engaged and the panel ran flush against the
  sidebar with only its padding in between. Panels now start at the same
  distance from the sidebar at every screen width.
* Changed: the column gutter is now a flat 16px on mobile and 24px from 768px
  up, replacing 2rem 1rem / 2.5rem 2rem. Horizontal and vertical spacing match,
  so cards, tables and forms sit on one predictable grid.
* Unchanged (deliberately): the Messages panel keeps padding 0 and remains
  edge-to-edge. It hosts a chat UI that supplies its own internal padding, so a
  column gutter around it only produced a dead gap.
* Unchanged (deliberately): the 260px sidebar, and the body-class mechanism
  added in 5.12.17.

= 5.12.17 — Changed: the My Account Messages panel is now edge-to-edge =
* Added: the active account section is now exposed as its own body class, for
  example zymarg-acc-section-messages or zymarg-acc-section-orders. This lets a
  single panel opt out of shared layout rules in plain CSS, with no reliance on
  the :has() selector, so it behaves the same in every browser.
* Changed: on the Messages panel only, .main-content now uses padding 0 and
  max-width none, on both mobile and desktop. The messaging UI owns its own
  internal padding, so the column padding around it (2rem 1rem on mobile,
  2.5rem 2rem on desktop) was only producing a dead gap around the chat box.
* Unchanged (deliberately): every other panel — Dashboard, Orders, Downloads,
  Addresses, Account Details and the rest — keeps the original 2rem 1rem /
  2.5rem 2rem padding and its existing reading width. Nothing about them moves.
* Unchanged (deliberately): the 260px account sidebar. Its width, padding,
  sticky positioning, border and z-index are all untouched. .main-content sits
  inside .zymarg-acc-main, which is a flex sibling of the sidebar, so the
  widened panel can only expand into the space to the right of the sidebar and
  is structurally incapable of overlapping it.

= 5.12.16 — Removed: built-in sticky add-to-cart bar (single product) =
* Removed: the theme's sticky add-to-cart bar on single product pages, for sites
  that use a dedicated plugin for this. Deleted zymarg_os_sticky_add_to_cart()
  and its zymarg_os_footer hook (inc/woocommerce.php), initStickyAddToCart() and
  its onReady() call (assets/js/theme.js), and the .zymarg-sticky-atc styles
  (woocommerce/product.css). The zymarg_os_enable_sticky_atc filter is gone too,
  since it no longer has anything to gate.
* Changed: the WooCommerce module description and the Theme Help page no longer
  advertise sticky add-to-cart.
* UNCHANGED: everything else in the WooCommerce module — Quick View, the
  off-canvas cart drawer and its live fragment updates, gallery zoom/lightbox,
  shop columns and Dokan styling. The normal WooCommerce add-to-cart button on
  the product page is untouched, as is the "Added to cart" toast.

= 5.12.15 — Removed: built-in Live Search, and the legacy Wishlist module toggle =
* Removed: the Live Search feature in full — the [zymarg_search] shortcode, the
  zymarg_live_search AJAX handlers (priv + nopriv), the ZymargSearch script
  localisation, the trending/recent searches tracker
  (zymarg_os_record_trending_search, zymarg_os_maybe_record_trending,
  zymarg_os_get_trending_searches and the zymarg_os_search_trending option),
  plus assets/js/live-search.js and assets/css/search.css. Search-as-you-type is
  now handled by a dedicated plugin.
* Removed: the "Live Search" module from the Modules registry, so the toggle no
  longer appears under Customize → ZYMARG OS → Modules.
* Removed: the dead "Wishlist (removed in v5.7.6)" module toggle, which had been
  kept for backward compatibility since v5.7.6 but had no effect.
* UNCHANGED (deliberately): the My Account → Wishlist tab, its WooCommerce
  endpoint and query var, the zymarg_os_account_wishlist_content filter and the
  "Wishlist Integration" Customizer section all remain, so third-party wishlist
  plugins keep working exactly as before.
* UNCHANGED: searchform.php and search.php (the standard search form and the
  search results template) are untouched — normal WordPress/WooCommerce search
  still works, including the sorting bar and product-grid delegation.
* Note: inc/smart-ux.php now ships only Instant Load + Scroll Animations.

= 5.12.14 — Fix: admin login blocked in Coming Soon/Maintenance mode; AJAX gate missing login actions; rate-limit XFF spoofing =
* Fix: wp-login.php and /wp-admin/ were intercepted by the Coming Soon/Maintenance
  placeholder before WordPress could establish a session, permanently locking out
  any admin who was not already logged in. Both are now whitelisted before the
  capability check in zymarg_os_maybe_show_placeholder().
* Fix: The AJAX gate (zymarg_os_ajax_gate) only whitelisted 'wp_check_password' and
  'heartbeat'. The three unauthenticated AJAX actions used by the branded login card
  — zymarg_lost_password, zymarg_register_user, zymarg_get_nonce — were silently
  blocked in non-live modes, breaking password reset, registration, and nonce refresh.
  All three are now added to the $safe_actions whitelist.
* Security: zymarg_os_get_client_ip() read HTTP_X_FORWARDED_FOR unconditionally as a
  fallback, allowing any client to forge the header and rotate fake IPs to bypass the
  rate limit on registration and lost-password. XFF is now only trusted when
  REMOTE_ADDR is a private/loopback address (a reliable signal that a trusted reverse
  proxy is in front). CF-Connecting-IP and X-Real-IP are unaffected.

= 5.12.13 — Security: REST API and AJAX gate for Site Mode; clarify Custom HTML asset loading =
* Fix: REST API requests from unauthenticated visitors are now blocked (403 / 503)
  when Site Mode is Coming Soon or Maintenance. Admins and whitelisted core routes
  (/oembed/, /wp/v2/themes, /wp/v2/plugins) always pass through.
* Fix: Unauthenticated nopriv AJAX requests are now blocked when Site Mode is active.
  Logged-in users (vendors, customers) and safe core actions (heartbeat) are
  always passed through — no impact on WooCommerce or Dokan sessions.
* Fix: rest_pre_dispatch registered with correct 3-argument signature so the
  WP_REST_Request object is received and $request->get_route() used reliably
  (previous approach via $GLOBALS['wp']->query_vars was unreliable at REST time).
* Improvement: Custom HTML Customizer description now explicitly states the theme
  stylesheet is not loaded in Custom HTML layout — inline your own <style> tags.

= 5.12.12 — Fix: "My Account — Links" section was missing from the ZYMARG OS panel since it was first written =
* Fixes a long-standing bug: the "My Account — Links" Customizer section
  (Contact/Support URL, Help Center URL, Track Order URL) was registered
  WITHOUT a `panel` argument, so it has always rendered as a stray top-level
  Customizer item (alongside Site Identity, Menus, Widgets, etc.) instead of
  nested inside "ZYMARG OS", since the section was first added.
* Fix: added `'panel' => 'zymarg_os_panel'` to the add_section() call in
  inc/account-dashboard.php. No setting keys changed, so all saved
  Contact/Help/Track-order URLs carry over unchanged.
* Audited every OTHER add_section() call in the theme (9 total) to confirm
  none of them have this same missing-panel bug — all others already had the
  panel argument from the start.
* Unrelated to, and independent of, the separate Login-section registration-
  order fix shipped in the ZYMARG Login & Security plugin v1.7.0.

= 5.12.11 — CRITICAL FIX: fatal "Class WP_Customize_Control not found" on every page (introduced in 5.12.10) =
* Fixes a site-crashing fatal error introduced in v5.12.10:
  `Uncaught Error: Class "WP_Customize_Control" not found in
  inc/login-fallback-notice.php`.
* ROOT CAUSE: the new Zymarg_Customize_Login_Source_Status_Control class was
  declared at the TOP LEVEL of inc/login-fallback-notice.php — a file that is
  ALWAYS loaded on every request (not just the Customizer). `extends
  WP_Customize_Control` executed immediately on load, but that core class
  only exists while the Customizer is bootstrapping — it is NOT available on
  regular admin pages (Dashboard, Plugins, etc.) or the front end. Any normal
  page load fataled the entire site.
* FIX: the class definition now lives INSIDE a function
  (zymarg_os_register_login_source_status_control()) that is only ever
  invoked from a `customize_register` callback (priority 1, guaranteed to run
  before the status control is instantiated at the default priority), guarded
  by `class_exists( 'WP_Customize_Control' )` first — the exact same safe
  pattern the theme's own inc/customize-controls.php has always used. This is
  the standard, safe way to define custom Customizer control classes in
  WordPress.
* No functional change to the feature itself — the status card, alert email
  field, email notifications and wp-admin notice all work exactly as
  documented in 5.12.9/5.12.10, just without crashing the site.
* If your site is currently down from this bug: rename (don't delete)
  inc/login-fallback-notice.php via SFTP/FTP to disable it immediately, then
  upload this version to replace the whole theme.

= 5.12.10 �� Live login-source status readout in Customize -> ZYMARG OS -> Login =
* New: a read-only status card at the TOP of the Login Customizer section
  showing, right now, which system is running your login screen — a green dot
  + "Plugin is running your login screen" when the ZYMARG Login & Security
  plugin is active, or a red dot + "Theme fallback is running your login
  screen" when it isn't. Each state includes a one-line explanation of what's
  on/off.
* This is a STATUS READOUT, not a toggle. Which system runs login is decided
  automatically by whether the plugin is active or not — a manual on/off here
  could leave the site with no login screen at all if both were switched off.
  Instead, the card links straight to the Plugins page, which is the one place
  that actually controls it.
* Lets you check the current state on demand from Customize -> ZYMARG OS ->
  Login, in addition to the email + wp-admin notification you already get
  automatically whenever it changes.
* New class Zymarg_Customize_Login_Source_Status_Control (registered by
  inc/login-fallback-notice.php, always loaded, so it's reachable regardless
  of which system is currently running login).

= 5.12.9 — Login source alerts on TWO channels: email + a native wp-admin notification =
* New: "Login source alert email" field under Customize -> ZYMARG OS -> Login.
  Type your address there once — no PHP, no wp-config editing, no
  update_option()/add_filter() snippets required. Leave blank to use the site
  admin email (unchanged default behaviour).
* This field is registered directly by inc/login-fallback-notice.php, which is
  ALWAYS loaded (unlike inc/login.php, which only loads when the plugin is
  inactive) — so the field is reachable in the Customizer no matter which
  system (plugin or theme) is currently running login.
* Recipient resolution order: Customizer field -> legacy
  zymarg_os_login_source_email option (for anyone who set it via code before
  this field existed) -> site admin email -> `zymarg_os_login_source_email`
  filter (still available for advanced overrides).
* NEW SECOND CHANNEL: a native, dismissible wp-admin notice now appears on
  EVERY wp-admin screen whenever the login source is different from what you
  last dismissed — green "Plugin active" success notice, or yellow "Theme
  fallback" warning notice with a direct link to Plugins. This is INDEPENDENT
  of the email: dismissing the notice does not silence future emails, and vice
  versa. The notice reappears automatically the next time the source changes.
* Dismissing uses a tiny AJAX call (wp_ajax_zymarg_os_ack_login_notice,
  nonce-protected + capability-gated to `activate_plugins`) so the
  acknowledgement persists across page loads instead of re-appearing on every
  screen until the browser tab is closed.

= 5.12.8 — Login source monitor: emails you WHICH system is running (plugin or theme) on every change =
* Rewrite of the login-fallback-notice.php into a full bi-directional "login
  source monitor". Two distinct email notifications:
  - Plugin takes over → "[Site] Login is now running via ZYMARG Login & Security
    plugin" (confirms full features are active, theme code not loaded).
  - Theme fallback takes over → "[Site] Login is running on the THEME fallback"
    (lists what's off, links to Plugins page to reactivate).
* Emails fire ONCE per state change — you get one email when the source switches
  from plugin→theme or theme→plugin. No repeats while the state stays the same.
* On first-ever install: saves state silently (no email — avoids a false alarm
  before you've ever had the plugin).
* Recipient: option `zymarg_os_login_source_email` (set it to your specific
  address), falls back to `admin_email`. Filterable via
  `zymarg_os_login_source_email`.
* Kill-switch: `zymarg_os_login_source_notify_enabled` filter (default true).
* Subject/body customizable via filters `zymarg_os_login_source_email_subject`
  and `zymarg_os_login_source_email_body`.
* Admin notice (dismissible, yellow) still shows while theme fallback is active.

= 5.12.7 — Login/session now a fallback (defers to "ZYMARG Login & Security" plugin) + fallback email alert =
* Change: the theme's built-in login experience (inc/login.php: branded login
  card, first-visit popup, wp-login.php branding, login redirects and AJAX)
  and session control (inc/session-control.php: auth-cookie lifetimes) are now
  loaded ONLY as a fallback. When the "ZYMARG Login & Security" plugin is active
  (detected via its ZLS_VERSION constant), the theme no longer parses these
  files at all — eliminating redundant code and any chance of function-name
  collisions with the plugin. The plugin uses identical Customizer keys, so the
  "Login" section and every saved value carry over with zero migration.
* Change: inc/customize-controls.php (the page-checkbox / per-page-delay
  Customizer controls, used only by the theme login section) is loaded under
  the same fallback condition.
* New: inc/login-fallback-notice.php — a tiny always-loaded monitor. If the
  plugin that was previously active becomes inactive (deactivated/deleted) and
  the theme login fallback takes over, it emails the site administrator ONCE
  and shows a dismissible wp-admin notice. It never false-alarms on a fresh
  theme-only install (only fires if the plugin was seen active before), and it
  resets automatically when the plugin is reactivated. Recipient filterable via
  `zymarg_os_login_fallback_email`; feature toggle via
  `zymarg_os_login_fallback_notify_enabled`; body via
  `zymarg_os_login_fallback_email_body`.
* When the plugin is active this release is behaviour-identical to 5.12.6 on the
  front end (the plugin was already rendering login/session).

= 5.12.0 — Payments moved into the standalone "ZYMARG Wallet" plugin + new account-section extension API =
* Change: the My Account → Payments feature (saved payment methods — bKash,
  Nagad, Rocket, Card, Bank) has been REMOVED from the theme and now ships as
  a standalone plugin, "ZYMARG Wallet". Install + activate that plugin to get
  the Payments section back. Your saved methods are NOT lost — the plugin reads
  the exact same user-meta store, and the same Customize → ZYMARG OS → Payments
  toggles, so everything reappears unchanged once the plugin is active.
* New: a generic, reusable account-section extension API. Companion plugins can
  now register their own My Account sidebar sections (item + endpoint + panel)
  via the `zymarg_os_account_sections` filter — no theme edits required. Each
  definition supports label, icon (icon key or raw inline SVG), endpoint, the
  sidebar anchor to insert after, a render callback, and an enabled flag. The
  filter is wired into endpoints, query vars, active-section detection, the
  sidebar, the URL map, the section dispatcher and the SPA AJAX loader.
* Result: the theme is lighter and free of payments-specific code, and the
  ZYMARG Wallet plugin (and future plugins) plug in cleanly. When no such
  plugin is active, the My Account sidebar is exactly as it was before.

= 5.11.10 — Payments empty-state: force two centered lines =
* The Payments empty state now renders on exactly two centered lines:
  "No payment methods saved yet." / "Add your first one." (hard line break
  instead of relying on natural wrapping).

= 5.11.9 — Fix: centered empty-state text =
* Fix: the My Account empty-state messages (e.g. "No payment methods saved
  yet. Add your first one.") now render as a tidy, centered block — the
  icon + text stack and centre via flexbox, and the paragraph is width-
  constrained with balanced wrapping so a two-line message reads cleanly
  in the middle. Applies to every account section's empty state.

= 5.11.8 — New: My Account → Payments (saved payment methods) =
* New: a "Payments" item in the My Account sidebar (directly under Addresses)
  where customers can save, edit, delete and set-default their own payment
  methods — bKash, Nagad, Rocket, Card and Bank Account. Stored in user meta.
* Security: for cards, only the last 4 digits, expiry and cardholder name are
  stored — never the full card number (PAN) or CVV.
* Admin control: Customize → ZYMARG OS → Payments adds a master toggle to
  show/hide the whole section, plus a per-type toggle for each of the 5 method
  types, so any method can be hidden from customers.
* Adds a version-keyed rewrite-rule flush so the new /my-account/payments/
  endpoint resolves after an in-place upgrade without re-saving permalinks.
* Files: new inc/account-payments.php; wiring in inc/account-dashboard.php,
  inc/account-sections.php, functions.php; styles in woocommerce/account.css;
  form JS in assets/js/account.js.

= 5.8.14 — Fix: My Account "View order" now works =
* Fix: clicking "View" on an order in My Account showed nothing because the
  custom account router didn't recognise WooCommerce's order sub-endpoints
  (view-order, order-received, order-pay, add-payment-method) and fell through
  to the Dashboard. Those endpoints now render WooCommerce's real order-detail
  content inside the branded My Account shell, with the "Orders" sidebar item
  kept active.

= 5.8.13 — Fix: theme version constant now auto-reads from style.css =
* Fix: ZYMARG_OS_VERSION was hardcoded as '5.8.1' in functions.php since
  v5.8.1 was released, so the admin welcome page badge + help page badge
  + asset cache-busting query string had all drifted 11 versions out of
  sync with the actual style.css version. Constant now reads from
  style.css's "Version:" header via get_file_data() at runtime, so all
  consumers always reflect the real shipped version. Style.css is now
  the single source of truth for theme version.

= 5.8.12 — Kill orb gradients in LIGHT mode (dark mode untouched) =
* Tweak: Both orb systems (site-wide in layouts/section.css + My Account-
  specific in woocommerce/account.css) are now hidden in light mode for a
  clean flat-white look. Dark mode keeps both orb systems exactly as before
  — soft purple atmospheric glow gives the dark UI its character.
* Tokens: --zymarg-orb-1-color and --zymarg-orb-2-color set to transparent
  in tokens/colors.css. tokens/dark.css UNCHANGED, so the dark overrides
  flow through automatically.
* Selector pattern matches tokens/dark.css, so the auto-mode-on-dark-OS
  edge case shows orbs correctly without any extra config.

= 5.8.11 ��� Dark-mode toggle switch in My Account sidebar =
* New: [zymarg_theme_switch] shortcode — a binary slider-switch styled
  control (matching the rest of the theme's toggle switches) that flips
  between light and dark mode. Shares state with the existing icon-button
  variant [zymarg_theme_toggle], so they stay in sync if both are used.
* My Account: the dark-mode switch now sits in the sidebar between the
  divider and the Logout button. Buyers can flip dark mode without
  leaving their account area.
* Inline CSS is printed in wp_head so the switch is styled on every
  page (including the Vendor Dashboard plugin page, where it can be
  embedded with the same shortcode).

= 5.8.10 — Website background → pure white =
* Tweak: --color-surface (the page background token) changed from
  #f8f9ff (very faint purple tint) to #ffffff (pure white). All
  other tokens unchanged. The two purple background orbs may still
  be visible — observation pass before next iteration.

= 5.8.9 — Fix: dashboard cards weren't clickable =
* Fix: The 5 dashboard cards (Recent Orders / Wishlist / Recently Viewed /
  Notifications / Vouchers) were silently swallowing clicks. The
  drag-to-scroll JS was adding the .is-grabbing class on EVERY mousedown,
  which activated `pointer-events: none` on the cards via CSS — so the
  click registered on the parent .dash-cards and the click handler's
  closest('.dash-card[data-goto]') returned null, exiting silently.
* Now: .is-grabbing only kicks in after 8px of movement (a real drag).
  Plain clicks pass through cleanly. A separate capture-phase click
  handler suppresses the trailing click that follows a real drag, so
  dragging horizontally never accidentally opens a section either.

= 5.8.8 — My Account avatar: camera icon nudged 5px up =
* Tweak: Camera button on the sidebar avatar moved 5px upward
  (bottom 3px -> 8px) for better visual balance against the avatar.

= 5.8.7 — My Account avatar: tap-anywhere on mobile + repaired LATEST.md =
* UX: On touch devices, the camera overlay now stays hidden when a photo
  is set (same clean look as desktop). Tapping anywhere on the avatar
  opens the picker — so mobile vendors can still change or remove their
  photo with a single tap, no hover required.
* Repo: LATEST.md was stale at v5.8.5 due to a missed edit during the
  v5.8.6 commit. Updated to reflect v5.8.7.

= 5.8.6 — My Account avatar: Remove photo + hover-reveal camera =
* New: "Remove photo" option in the avatar picker — only shows when the
  user has actually uploaded a photo. Confirms via dialog, then deletes the
  attachment + clears user meta, and the avatar instantly reverts to the
  default Gravatar.
* UX: When a photo is set, the camera overlay now FADES out (instead of
  hard hide) and FADES back in on hover/focus — so users can always change
  or remove their photo. On touch devices (no hover), the camera stays
  visible.
* Backend: new AJAX endpoint `zymarg_remove_avatar` that mirrors the upload
  endpoint's nonce + permission model; non-destructive — only the avatar's
  own attachment + user meta are touched.

= 5.8.5 — My Account avatar: tighter camera icon =
* Tweak: Camera button scaled down ~20% (36px -> 28px button, 20px -> 16px
  SVG) and nudged down 5px (bottom: 8px -> 3px) for better visual balance
  on the 40px avatar.

= 5.8.4 — My Account avatar: hide camera overlay when photo set + 2x icon =
* UX: Once a real photo is uploaded, the camera overlay on the My Account
  sidebar avatar is hidden automatically. Triggered server-side via the
  _zymarg_avatar_url user meta AND client-side immediately after a
  successful upload — no reload needed.
* UX: Camera button + SVG icon are now 2x larger (button 36px, SVG 20px)
  so the upload affordance is much more discoverable when the user hasn't
  uploaded a photo yet.
* Consistency: matches the Vendor Dashboard plugin's avatar pattern —
  buyer + seller experiences feel like one family.

= 5.8.3 — Fix: Community sidebar link now actually navigates =
* Fix: The My Account sidebar's SPA click handler was intercepting the
  "Community" link and trying to AJAX-load a section (which doesn't exist
  for an external link), so clicks did nothing. Added `data-external="1"`
  support so external sidebar links bypass the SPA interceptor and follow
  their `href` natively.
* Foundation for any future external sidebar links — just add the data
  attribute and the SPA will leave them alone.

= 5.8.2 — My Account sidebar gains a "Community" item =
* New: My Account sidebar adds a **Community** menu item directly after Reviews,
  linking to the public Community archive (default: /community/).
* The item appears ONLY when the ZYMARG Community Request Board plugin is
  active (detected via the ZCRB_POST_TYPE constant). On sites without the
  plugin, the sidebar is unchanged.
* No other sidebar items were touched. No new My Account endpoint registered.
  Pure additive change.

= 5.8.1 — Help page documents the Wishlist + Recently Viewed shortcodes =
* Added: a new "Wishlist & Recently Viewed shortcodes" section to the
  ZYMARG OS admin Help page documenting both `[zymarg_wcpg_wishlist]` and
  `[zymarg_wcpg_recently_viewed]` (provided by ZYMARG WC Product Grid
  v1.5.2+). Includes copy-to-clipboard examples for each attribute, a
  list of useful pages to drop them on (empty cart, 404, thank-you,
  footer, single-product cross-sell row), and a developer note on the
  `*_card_settings` filters.
* The theme already wires the Recently Viewed shortcode into My Account
  automatically (see v5.7.8) — this Help page section is for placing the
  same grids anywhere else on your site.

= 5.7.10 — My Account dashboard cards are now clickable =
* Fixed: the dashboard "quick access" tiles on My Account → Dashboard
  (Recent Orders, Wishlist, Recently Viewed, Notifications, Vouchers)
  did not actually navigate when clicked — they only showed a one-line
  preview tooltip and looked like dead buttons. They now route through
  the existing SPA loader so clicking a tile opens the matching section
  in-place, with proper history/scroll/sidebar-active state. Cmd/Ctrl/
  Shift-click still passes through for "open in new tab" behaviour.

= 5.7.9 — Header dropdowns are clipping-proof =
* Added a defensive CSS layer (`components/header-overflow-fix.css`) that
  forces `overflow: visible` on every Elementor / Theme Builder header
  section, container, column and widget wrapper. This means dropdowns inside
  your header (live search, account menu, mini-cart, mega menu sub-panels)
  can NEVER be cut off below the header again — even if an Elementor section's
  "Overflow" setting is accidentally flipped to Hidden (a very easy mistake
  to make in the Elementor UI).
* Scope is strictly limited to the header (`.elementor-location-header`); page
  content, footer, single product, shop and other layouts are untouched.
* Shipped after a real-world incident where this exact misconfiguration caused
  every header dropdown on the site to be cut off below the header.

= 5.7.8 — Recently Viewed uses the same card as your homepage =
* Improved: when the **ZYMARG WC Product Grid plugin v1.5.2+** is active,
  the My Account → Recently Viewed section now renders via its new
  `[zymarg_wcpg_recently_viewed]` shortcode, using the SAME product-card
  template as your homepage / search / category pages. Consistent design
  everywhere.
* Falls back gracefully:
    1. ZYMARG WC Product Grid shortcode (best — matching cards)
    2. ZYMARG Insights server-side renderer (still cross-device)
    3. A friendly "enable a plugin" prompt if neither is installed.
* No other theme code changed.

= 5.7.7 — Recently Viewed now cross-device via ZYMARG Insights =
* Fixed: the My Account → "Recently Viewed" list was always empty. The old
  tracker lived in `assets/js/account.js`, which only loads on the account
  page — so product views were never recorded and the list had nothing to
  show.
* Recently Viewed is now powered server-side by the new, free **ZYMARG
  Insights** plugin. Benefits: it works across all of a signed-in customer's
  devices, survives browser/cache clears, and records views via a fast,
  non-blocking beacon that never slows product pages.
* `inc/account-sections.php` now renders the plugin's grid when ZYMARG
  Insights is active (`zymarg_insights_render_recently_viewed()`), and shows a
  friendly "enable the plugin" prompt otherwise — no blank panel.
* Removed the dead localStorage tracker block from `assets/js/account.js`
  (a no-op stub remains so the SPA loader keeps working unchanged).
* No other functionality changed. If you don't install ZYMARG Insights, the
  rest of My Account works exactly as before.

= 5.7.6 — Wishlist removed from theme; pluggable from your product-grid plugin =
* Removed the theme's built-in wishlist module entirely to keep ZYMARG OS
  lightweight. Deleted files (~597 lines): `inc/wishlist.php`,
  `assets/js/wishlist.js`, `components/wishlist.css`. The single source of
  truth is now your product-grid plugin.
* The My Account → Wishlist tab in the sidebar stays — but it is now POWERED
  by whichever wishlist-providing plugin you have active, so users can still
  find their saved items whenever they want. Two ways to wire it up:
    * **Shortcode** (no code): Customize → ZYMARG OS → Wishlist Integration →
      paste your plugin's shortcode name (without brackets). Defaults to
      `zymarg_wcpg_wishlist` (shipped by ZYMARG WC Product Grid v1.4.6+).
    * **Filter** (for developers): hook `zymarg_os_account_wishlist_content`
      and return HTML.
* If neither is configured, the tab shows a friendly empty state instead of
  rendering blank.
* The dashboard "Wishlist" tile is preserved (icon + label) but no longer
  shows a count (the count lived in the removed storage layer).
* Admin → ZYMARG Help: replaced the old Wishlist card with a new card
  documenting the integration.
* The `zymarg_os_modules` registry entry for `wishlist` is kept for backward
  compatibility (default off) but has no effect — `wishlist.php` no longer
  ships with the theme.

= 5.7.5 — Login card: spark -4px, tighter OR-divider, +2px under Google =
* Discovery Spark in the login card pushed up a further 2 px (now translateY
  -4 px total) on `.zymarg-login .zymarg-spark`.
* OR-divider between Login button and "Continue with Google" reduced again:
  margin-y mobile 13 -> 8, tablet 14 -> 9, desktop 19 -> 12.
* Gap below "Continue with Google" (above "Forgot Password?") bumped by 2 px
  via the inline style on the link: 8 -> 10.

= 5.7.4 — Login card: nip the Google -> Forgot gap; nudge the Discovery Spark =
* Login card: the gap between the "Continue with Google" button and the
  "Forgot Password?" link was actually being controlled by an INLINE style
  (`margin-top: 30px !important`) in `inc/login.php`, which is why the CSS
  reductions in 5.7.2 / 5.7.3 could not affect it. Reduced that inline value
  from 30 px down to 8 px so the link now sits tight under the Google button
  on all viewports.
* Discovery Spark in the login card pushed up by 2 px via
  `transform: translateY(-2px)` on `.zymarg-login .zymarg-spark`. Layout-
  neutral (uses transform, so surrounding elements do not reflow).

= 5.7.3 — Login card: deeper squeeze on the area below the Login button =
* Following on from 5.7.2, the rows below the Login button were cut further
  (visible reduction this time). `components/login.css`:
  * Google sign-in button vertical padding: 11 -> 8.
  * Forgot password link: padding 3 -> 0; mobile-only top margin 24 -> 12.
  * Footer padding-top / padding-bottom:
    mobile  13/19 -> 8/12, tablet 14/19 -> 9/12, desktop 19/26 -> 12/16.
  * Footer text margin-bottom: 10 -> 6.
  * Footer divider margin-top + padding-top:
    mobile 10+10 -> 6+6, tablet+ 13+13 -> 8+8.
* Compounded vs 5.7.1 baseline: roughly 50 px shorter below the button on
  mobile, 40 px on tablet and 50 px on desktop.
* Untouched: page wrapper, header, brand, tabs, error banner, all form fields,
  the Login button itself, the OR-divider and the v5.7.2 logo size.

= 5.7.2 — Login card: tighten everything below the Login button =
* Branded login card (the front-end `/my-account/` card rendered by the
  `[zymarg_login]` shortcode) — reduced ~20% of all vertical spacing BELOW the
  Login button. Applies on mobile, tablet and desktop. Nothing above or
  including the Login button is changed; side margins/paddings preserved so the
  layout does not shift horizontally.
* Specific tightenings (`components/login.css`): the OR-divider, the Google
  sign-in button (vertical padding 14 -> 11), the Forgot password link
  (mobile-only 30px top margin -> 24px; padding 4 -> 3), the Footer paddings
  and inner text/divider gaps.
* Site logo on the login card reduced ~5% (mobile 24 -> 23 px; tablet+
  31 -> 29 px) for a slightly more compact header.
* Result: ~21 px shorter on mobile, ~21 px shorter on tablet and ~28 px shorter
  on desktop, with no change to the form fields, the button itself, or the
  centred page wrapper.

= 5.7.1 — Fix: Elementor header "dancing" / layout shift on load =
* Fix: pages no longer visibly "dance" (settle-in / layout shift) on load when
  an Elementor header is active. The theme now freezes transitions and entrance
  animations during the first paints on EVERY page (previously only on account/
  product), so the page and header snap straight to their final layout. The
  freeze is removed a moment after load, with a 1.5s safety timer so it can
  never get stuck, and content stays visible throughout.
* The behaviour is filterable: add_filter( 'zymarg_os_anti_dance', '__return_false' )
  to disable it.

= 5.7.0 — Removed Algolia engine + built-in Reviews system =
* Removed: the native Algolia search engine (inc/algolia.php, the ZYMARG OS ->
  Search Engine admin page, indexing/sync, and its help/menu entries). Live
  Search now runs purely on the built-in, cached WP_Query engine — the AJAX
  handler for that already lived in smart-ux.php, so search keeps working. The
  Algolia code path was also removed from live-search.js and smart-ux.php.
* Removed: the built-in Reviews system (inc/reviews.php, inc/review-rules.php,
  inc/reviews-admin.php, the inc/reviews/ classes + templates, and the
  zymarg-reviews / review-sort assets). Product reviews now use the default
  WooCommerce reviews. Nothing else referenced this system, so removal is clean.
* Net effect: a lighter theme (fewer files + assets) with no functional loss to
  the features you kept.

= 5.6.0 — Marketplace description + ZYMARG Theme Builder rename =
* Change: refreshed the theme description to state it powers a fully functional
  multi-vendor marketplace and requires two companion plugins — ZYMARG Theme
  Builder and ZYMARG Vendor Dashboard.
* Change: renamed "ZYMARG Powerhouse" to "ZYMARG Theme Builder" everywhere
  (recommended-plugins notice, Performance page, helper functions/filters). The
  detection helper now matches both the new and legacy plugin signatures, so
  nothing breaks. Filters are now zymarg_os_theme_builder_active and
  zymarg_os_theme_builder_install_url.

= 5.5.0 — Vendor Dashboard moved to its own plugin =
* Change: the entire Vendor Dashboard (Phases 0-5) has been extracted from the
  theme into a dedicated plugin, "ZYMARG Vendor Dashboard" (v1.0.0). This is the
  correct architecture — functionality and vendor data (messages, coupons,
  reviews) now survive theme changes. Install that plugin to keep the vendor OS.
* Kept in the theme: the global ZYMARG design language (the --zymarg-gradient
  token, gradient buttons, rounded soft-shadow cards) and the My Account
  styling. The plugin automatically uses these tokens + the Discovery Spark mark
  when the theme is active, and falls back to built-in styling otherwise.
* Removed the now-unused "Vendor Dashboard" module toggle.

= 5.4.0 — Vendor Dashboard Phase 5: Messages & Customers =
* New: Messages �� a Messenger-style buyer<->vendor inbox (works on Dokan Lite).
  Two-pane layout with a conversation list and a chat thread (bubbles + a
  composer). Messages are stored privately (zymarg_message post type) per
  vendor/customer pair; vendors can open any of their customers and chat. The
  inbox is seeded from the vendor's order customers so it is useful immediately.
  Mobile shows a list -> thread drill-down with a back button.
* New: Customers — Recent / Repeat / Top Buyers tabs aggregated from the
  vendor's orders, each row showing orders, total spent (vendor share), last
  order date, and a one-tap Message button that deep-links into the inbox.
* All endpoints are ownership-checked and nonce-protected.
* Note: the buyer-facing reply UI (so customers can message back from the
  storefront) is the natural follow-up; the storage + vendor side are in place.

= 5.3.0 — Vendor Dashboard Phase 4: Promotions & Reviews =
* New: Promotions section with a native vendor COUPON creator that works on
  Dokan Lite (no Pro needed). Set code, type (%/fixed cart/fixed product),
  amount, expiry, usage limit and min spend. New coupons are automatically
  restricted to the vendor's own products so they never discount another
  seller. Includes a coupon list with delete. All ownership-checked + nonce-
  protected.
* New: Reviews section — manage reviews on your products with rating filter
  tabs (All / 5-1 stars), a public Reply, Hide/Unhide (approve/hold) and Report
  (flags the review for the marketplace admin). Vendors can only act on reviews
  of their own products.
* Change: the Coupon and Promotion Quick Actions now open the native Promotions
  screen.

= 5.2.0 — Vendor Dashboard Phase 3: Earnings & Analytics =
* New: Earnings section — Today's Earnings, This Week, This Month, plus
  Available Balance, Withdrawn and Pending Withdrawal, a 30-day earnings trend
  chart, and a Withdraw button that hands off to Dokan. Balance/withdrawn/
  pending read Dokan's payout data when available; the period totals are always
  computed from orders.
* New: Analytics section — Revenue, Orders, Visitors and Conversion stat cards,
  a 30-day revenue chart, and a Top Products ranking (by units sold, with a
  relative sales bar). Visitors/conversion light up via the new
  zymarg_os_vendor_visitors filter (hook your analytics/view source).
* Change: Earnings and Analytics sidebar items now open these native ZYMARG
  screens; the revenue chart now supports sparse x-axis labels for clean 30-day
  views.

= 5.1.0 — Global ZYMARG design language (gradient + cards) =
* New: the dashboard's signature look is now the theme-wide default, driven by a
  single global token. Added --zymarg-gradient (+ --zymarg-gradient-hover) and
  --zymarg-shadow-soft so the entire look can be tuned or reverted from one place.
* Change: primary buttons (.zymarg-btn) and WooCommerce buttons (shop, cart,
  checkout, single add-to-cart) now use the purple->magenta->pink gradient.
  Secondary/ghost buttons explicitly keep their outline/transparent style.
* Change: global cards (.zymarg-card) adopt the dashboard's 18px corners and the
  softer layered shadow.
* Change: the .zymarg-gradient-primary / .zymarg-gradient-text helpers and the
  Vendor Dashboard + My Account (--zv-grad) now all reference the one global
  gradient token — single source of truth, so colour/Customizer/dark-mode
  changes flow everywhere automatically.
* Note: product-grid cards on the shop keep their existing layout for now (the
  global gradient buttons + card token still apply); a dedicated shop product
  card restyle can follow if desired.

= 5.0.0 — Vendor Dashboard Phase 2: Products & Orders =
* New: Products section ��� a beautiful card grid (no more WooCommerce tables)
  showing each product's image, name, price, stock, units sold and views, with
  a status badge and a featured star. Includes search and pagination.
* New: per-product actions menu (•••) — Edit and View (open Dokan/WordPress),
  plus live AJAX actions: Feature/Unfeature, Hide/Unhide (catalog visibility),
  Duplicate (uses WooCommerce's own duplicator), and Delete (to trash). All are
  ownership-checked (a vendor can only manage their own products) and nonce-
  protected.
* New: Orders section — tabbed by lifecycle (Pending, Processing, Shipped,
  Delivered, Cancelled, Refunds) with per-tab counts, customer, date, item
  count, vendor revenue share and a View link to the Dokan order. Orders are
  scoped to the vendor's items (whole-store for admin preview).
* Change: the Products and Orders sidebar items now open these native ZYMARG
  screens inside the dashboard shell; "Add Product" and the Quick Actions still
  use Dokan's real forms for the write flows (no functionality reimplemented).
* Adds the vendor product-action AJAX endpoint and the supporting tab / menu
  JavaScript. Works on Dokan Lite; deeper per-section tooling continues in later
  phases (Earnings, Analytics, Promotions, Reviews, Messages, Customers).

= 4.11.1 — My Account: deepen the in-panel dashboard match =
* Improve: the content that loads when you press a sidebar menu item now fully
  matches the Vendor Dashboard — card icon tiles use the signature gradient with
  white icons, primary/submit buttons use the brand gradient, status chips are
  fully-rounded pills, tab bars are pill-style, and order totals use brand
  purple. (v4.11.0 only restyled the sidebar + card radius/shadow.)
* Still visual-only and scoped to the account page; no markup, scripts or
  behaviour changed.

= 4.11.0 — My Account matches the Vendor Dashboard design =
* New: the customer My Account page is now visually harmonized with the ZYMARG
  Vendor Dashboard — white sidebar, the signature gradient active-nav pill, a
  card-style user header, and a unified card radius / shadow / hover across all
  panels (Dashboard, Orders, Wishlist, Addresses, etc.).
* This is a styling-only layer appended to the account stylesheet and scoped to
  the account page; no markup, scripts, endpoints or behaviour were changed, so
  all existing functionality (SPA section nav, avatar upload, forms, modals,
  address book) remains intact.

= 4.10.1 — Vendor Dashboard: correct greeting for the visitor's timezone =
* Fix: the Dashboard greeting ("Good morning/afternoon/evening") now reads the
  visitor's LOCAL device time instead of the server/site timezone, so it is
  correct for vendors everywhere (e.g. Bangladesh, UTC+6) regardless of how the
  WordPress timezone is configured. The server still renders an initial value;
  the browser corrects it on load.

= 4.10.0 — ZYMARG Vendor Dashboard (Phase 0 + 1) =
* New: a custom, on-brand Vendor Dashboard — a seller "business operating
  system" built on top of Dokan Lite (free). Unlike a re-skin, it is a custom
  ZYMARG shell so the vendor experience matches the buyer account and mirrors
  the data the mobile app pulls from Dokan's REST API.
* New: the dashboard automatically takes over the vendor dashboard page
  (slug: `dashboard`, where Dokan's [dokan-dashboard] normally lives) via a
  the_content filter, and is also available anywhere via the
  [zymarg_vendor_dashboard] shortcode.
* New: Phase 0 shell — branded sidebar (Dashboard, Products, Orders, Earnings,
  Analytics, Promotions, Reviews, Messages, Customers, Shipping, Payments,
  Store Settings, Notifications, Support, Settings, Logout), store card,
  responsive mobile drawer (hamburger + overlay), and a logout confirmation
  modal.
* New: Phase 1 signature Dashboard screen — warm time-aware greeting
  ("Good morning, {name} ���"), Quick Actions row (+ Product, + Coupon,
  + Withdraw, + Store Banner, + Promotion), four stat cards (Today's Sales,
  Today's Orders, Pending Orders, Store Rating), a dependency-free inline-SVG
  7-day revenue chart, Latest Orders, Low Stock and Recent Reviews.
* New: access control — Dokan sellers see the dashboard; admins/shop managers
  get a clearly labelled preview; logged-out and non-vendor users get
  sign-in / "become a vendor" prompts.
* New: "Vendor Dashboard" module toggle under Customize → ZYMARG OS → Modules
  (enabled by default; needs WooCommerce, and Dokan for live seller data).
* Data layer is best-effort with safe fallbacks, so the screen renders cleanly
  on a brand-new store with no data yet.

= 3.6.6 — Fix My Account content rendering (template override) =
* Fixed: the right-side content panels were rendering "far below" and the
  word "count" appeared on the top-left of the Dashboard. Root cause: the
  hook-based template wrapping approach (woocommerce_before/after_account_
  navigation + removing woocommerce_account_content) did not fully suppress
  WooCommerce's default dashboard output — WC's default "Hello [name]…" and
  dashboard paragraphs rendered FIRST, then our panels rendered below them.
* Fix: replaced the hook-based approach with a proper WooCommerce template
  override at woocommerce/myaccount/my-account.php. For logged-in users,
  the template renders the ZYMARG layout directly (sidebar, orbs, section
  panel). For logged-out users, it renders WC's standard login form. This
  gives us full control over the page output — no stray WC content leaks.
* Fixed: "count" text leaking was caused by the PHP expression
  `count( zymarg_os_get_wishlist() )` evaluating when the wishlist module
  hadn't fully initialized. Now guarded with `zymarg_os_wishlist_enabled()`
  and an `is_array()` check.
* Added CSS safety net: `.zymarg-myaccount-wrap .woocommerce` is forced
  to `display: block` to override any WC grid/flex that might leak through.
* No changes outside the My Account page.

= 3.6.5 — New My Account page design (sidebar + 13 sections) =
* Brand-new, app-like My Account experience replacing the previous default
  WooCommerce layout. Fixed sidebar on desktop with user avatar + navigation,
  mobile bottom nav, 13 section panels with smooth fade-in transitions.
* Sections fully wired to real WooCommerce data:
  - Dashboard: order count, wishlist count, quick-action cards with inline
    detail expand/collapse.
  - Orders: real orders from wc_get_orders() with tab filtering by status
    (All / Processing / Shipped / Delivered / Cancelled), status badges, view
    links. Quick Actions (Track Order, Refund Request, Buy Again).
  - Wishlist: renders the theme's built-in [zymarg_wishlist] shortcode.
  - Addresses: WooCommerce's native my-address.php template.
  - Profile: WooCommerce's native form-edit-account.php template.
  - Security: custom password change form (validates current password,
    re-authenticates after update so user stays logged in), active sessions
    display, and a Delete Account modal with password confirmation that calls
    wp_delete_user() (admins blocked from self-deletion).
  - Vouchers (formerly "Coupons"): queries real WC coupons available to the
    user (email-restricted or unrestricted), with Available / Used / Expired
    tabs.
  - Reviews: "My Reviews" tab queries real comment-type reviews; "Pending
    Reviews" tab shows completed-order products the user hasn't reviewed yet.
* Sections wired to Dokan Pro (feature-gated, graceful fallback):
  - Returns & Refunds: queries Dokan's dokan_rma_request table; falls back
    to showing WC refunded orders when Dokan isn't active.
  - Support: lists Dokan Store Support tickets (dokan_store_support CPT);
    shows Contact Support / Help Center links when Dokan isn't active.
  - Notifications: shows Dokan announcements when available; notification
    preference toggles save to user meta via AJAX.
* Lightweight theme-built features:
  - Recently Viewed: localStorage-based product tracker. Auto-records
    product visits on single-product pages; renders the history as action
    cards on the account page. No plugin needed, no cookies, GDPR-friendly.
  - Preferences: email preference toggles (Newsletter, Order Emails,
    Promotional) saved to user meta via AJAX. Instant toggle with no page
    reload.
* Design system: 767-line account.css using ZYMARG design tokens with
  hardcoded fallbacks. Sidebar, section panels, cards grid, action cards,
  status badges, forms, buttons, toggle switches, tabs, dashboard cards,
  inline detail, empty states, delete-account modal, bottom nav, order items,
  settings cards, and WooCommerce form overrides.
* Mobile-first: single-column at <768px, bottom nav visible, sidebar hidden.
  Desktop: fixed 260px sidebar + fluid content area (max 960px).
* WooCommerce endpoint registration for 9 custom sections (wishlist,
  recently-viewed, notifications, reviews, coupons, returns, support,
  preferences, security). Flush rewrite rules on theme activation.
* "Coupons" renamed to "Vouchers" per brand decision.
* No changes outside the My Account page. Shop, product, cart, checkout,
  Dokan vendor store, blog, header, footer, mega menu are all untouched.

= 3.6.4 — Reverted My Account page to default WooCommerce styling =
* The "Supercharged My Account" module (welcome hero, stat cards,
  quick-action buttons, premium menu icons, branded sidebar / content
  panel / tables / address cards / forms / buttons / notices) has been
  removed. The WooCommerce My Account page now renders with default
  WooCommerce styling so a new account-page design can be introduced
  cleanly in a follow-up release.
* Files removed:
  - inc/account-dashboard.php (PHP module, all hero / stats / quick-action
    rendering, body-class additions, Customizer "My Account" section,
    dynamic CSS for the hero gradient).
  - woocommerce/account.css (all .woocommerce-account / .zymarg-account-*
    / .zymarg-acc-* rules).
* Files restructured:
  - The previous account.css contained Dokan vendor-store + dashboard
    styling alongside the My Account rules. Those Dokan rules have been
    moved to a new dedicated woocommerce/dokan.css file so multivendor
    UIs stay on-brand. Enqueue updated accordingly (woo-account ->
    woo-dokan).
  - inc/dynamic-css.php no longer references the deleted account hero
    CSS function.
  - inc/admin-help.php: the long "My Account page (supercharged)" help
    card is removed; the separate "My Account header icon" subsection
    (a different feature — the customizable account icon for the site
    header, [zymarg_account_icon]) has been promoted to its own help
    card with a short note explaining that the account page itself now
    uses default WooCommerce styling.
* Kept (separate features, not part of the My Account page design):
  - inc/account-icon.php + components/account-icon.css — the
    customizable header My Account icon.
  - The reviews module's "Write a review" column on the Orders table
    (functionality, not styling).
* No styling changes anywhere outside the My Account page. Shop, single
  product, cart, checkout, Dokan, blog, header, footer, mega menu are
  all untouched.

= 3.6.3 — Bulletproof My Account hero (initials avatar + mobile layout) =
* Fixed: when Gravatar was slow or blocked (common on networks outside
  the US/EU), the My Account hero rendered the alt text "FirstName" as
  plain text where the avatar should be — making the dashboard look
  broken with the user's name showing twice. The hero now wraps the
  avatar in a brand-coloured initials circle that is ALWAYS visible.
  The Gravatar image overlays the circle when (and only when) it loads;
  if the network blocks it, the polished initials remain. The image's
  alt is now empty so it can never leak into the layout.
* Refined: the avatar circle uses a subtle two-layer gradient (the
  signature ZYMARG primary -> primary-container plus a soft brand-text
  overlay) and a soft outline derived from the hero's text colour, so
  the fallback feels like a designed brand mark rather than a placeholder.
* Fixed: "Member since" date could drift by a day for users registered
  near midnight UTC (date_i18n( ..., strtotime( $user->user_registered ) )
  treated the UTC string as server-local). Now uses wp_date() with the
  site timezone for accurate display.
* Fixed (mobile layout):
  - Welcome hero stacks vertically and centres below ~520 px, so long
    greetings + emails no longer get crushed into a 70 px wide column.
  - Account content panel + hero padding tighten from space-lg (40 px)
    to space-md (24 px) below 600 px, recovering inner content width.
  - Sticky sidebar navigation is released to static positioning below
    768 px, so the 6-tab nav no longer glues to the top of the
    viewport while you scroll the dashboard on a phone.
  - Quick-action pills become a full-width CTA bar below 520 px instead
    of stranded left-hugging pills.
* Refined: hero gets `overflow: hidden` so any over-long content stays
  inside the rounded gradient corner.
* No styling changes anywhere outside the My Account page.

= 3.6.2 — Elegant My Account icons (specificity fix + refined glyphs) =
* Fixed: every tab in the My Account sidebar (Dashboard, Orders, Downloads,
  Addresses, Account details, Logout) was rendering the same generic circle
  instead of its own icon. Caused by a CSS specificity bug in
  woocommerce/account.css — the per-endpoint icon rules (specificity 0,2,2)
  were being overridden by the base + fallback rules (0,2,3). The base now
  uses mask longhands (no more shorthand mask-image reset), and the generic
  fallback is wrapped in :where() so it has zero specificity.
* Refined: the per-endpoint icons themselves are redrawn with consistent
  visual weight, rounded geometry and better legibility at 16-20px
  (modular grid for Dashboard, shopping bag for Orders, arrow-into-tray
  for Downloads, soft pin for Addresses, refined user for Account details,
  exit-door for Logout).
* Refined: the active accent bar on the sidebar nav now uses the signature
  ZYMARG gradient (primary -> primary-inverse) with a soft glow, so it
  reads as a polished brand mark in both light and dark mode.
* Refined: stat-card values (Orders, Total spent, Wishlist) use tabular
  lining numerals so currency and counts align column-perfectly across
  cards.
* Cleaned: removed dead `.woocommerce-account.logged-out` selector and the
  redundant "re-assert" icon block at the bottom of account.css.
* No styling changes anywhere outside the My Account page.

= 3.6.1 — Smart-switch default mode (dark-by-default + switchable) =
* New "Smart switch — default mode" option (Customize -> ZYMARG OS -> Colours):
  choose whether the visitor-controlled switch starts on Auto, Light or Dark.
  So you can default the site to Dark while still letting visitors switch to
  Light — the previous behaviour always started on Auto.
* Clarified that the "Light" and "Dark" schemes are fixed and do NOT allow
  switching (the [zymarg_theme_toggle] button only works in "Smart switch"
  mode). This was a common trap — selecting "Dark" locked the site to dark and
  the toggle did nothing. Help page updated with a clear callout.
* The switch no longer persists the default to the browser until the visitor
  actually clicks, so changing the default later is respected.

= 3.6.0 — Site logo shortcode =
* New [zymarg_logo] shortcode outputs your WordPress Custom Logo (Customize →
  Site Identity → Logo) so you can place it anywhere — e.g. a Shortcode element
  in your Elementor header. Options: size (max height px), link (true/false),
  alt and class. Falls back to the site title when no logo is set. Documented
  in the Help page (which now covers every theme shortcode).

= 3.5.9 — Flexible dark/light toggle button =
* The [zymarg_theme_toggle] switch now accepts options so it fits any header:
  size ("sm" / "md" / "lg"), show_label ("true" shows a visible "Theme: …"
  label beside the icon), label (custom accessible text) and class. Defaults
  are unchanged (icon-only, md). Set the colour scheme to "Toggle" in
  Customize -> ZYMARG OS -> Colours, then place the shortcode in your header
  (e.g. an Elementor Shortcode widget) so visitors can pick Auto / Light /
  Dark. Help page updated.

= 3.5.8 — Smarter caching detection in the Performance report =
* The Performance report now detects host / edge caches that have no plugin
  (Pantheon Global CDN, WP Engine, Kinsta, SiteGround, Cloudways, Cloudflare)
  as well as the major caching plugins (WP Rocket, W3 Total Cache, LiteSpeed,
  WP Super Cache, WP Fastest Cache, Cache Enabler, Autoptimize) and object
  caches — and names the provider. Fixes the false "No caching detected"
  warning on hosts like Pantheon. Declarable via the zymarg_os_detected_cache
  filter.

= 3.5.7 — Performance report + recommended-plugins notice =
* New "Performance" dashboard page (ZYMARG OS -> Performance) with detailed
  diagnostics: environment (theme/WP/PHP/memory/HTTPS/caching/debug), active
  integrations (ZYMARG Theme Builder, Elementor, WooCommerce), every module's
  on/off state, a map of what assets load and when, and tailored
  recommendations.
* New post-activation admin notice recommending the ZYMARG Theme Builder and
  Elementor plugins (the theme works hand-in-hand with them). Lists only what
  is missing, links to install/activate, and is dismissible per user.
  Detection is filterable (zymarg_os_theme_builder_active /
  zymarg_os_theme_builder_install_url).
* Note on lazy loading: the existing "Lazy Images" module lazy-loads
  images/iframes; separately, the theme already lazy-loads its own CSS/JS
  (only enqueuing what each page needs) — both are surfaced in the new report.

= 3.5.6 — Removed content top/bottom gap (zero by default) =
* Removed the content area's top/bottom padding entirely — the theme now adds
  ZERO vertical gap by default. Create page spacing with your page builder
  (e.g. Elementor) instead.
* Removed the related controls: "Content vertical padding" and the two
  "remove top/bottom gap" toggles (Customize -> ZYMARG OS -> Spacing), plus
  their dynamic CSS. The Spacing section now only holds the content-width
  controls. Lighter and simpler for builder-first sites.

= 3.5.5 — Fix: My Account rendered unstyled (vertical) on shortcode pages =
* The My Account styles now load and apply on ANY page that contains the
  [woocommerce_my_account] shortcode — not only the page WordPress flags as
  the official account page. Previously, if your My Account page wasn't the
  one assigned in WooCommerce → Settings → Advanced, account.css never loaded
  and the body lacked the woocommerce-account class, so the page rendered
  completely unstyled (everything stacked vertically). The theme now adds the
  needed context (loads account.css + adds the woocommerce-account body class)
  whenever the shortcode is present, so the two-column layout always renders.

= 3.5.4 — Fix: My Account two-column layout could scramble =
* Hardened the My Account grid so only the navigation menu and the content
  area form the two columns. Any other direct child of the WooCommerce wrapper
  (notices, "Hi name" wrappers, headings, etc.) now spans the full width
  instead of being placed into a grid cell — which previously scrambled the
  menu/content alignment and looked broken. No markup or feature changes.

= 3.5.3 — Removed the built-in header/footer (lighter, builder-first) =
* Removed the optional built-in Header & Footer builder so the theme is leaner
  for sites that build their header/footer with a page builder (e.g. Elementor)
  or the ZYMARG plugin.
* Deleted inc/header-footer.php and components/header-footer.css; stripped the
  related header/top-bar/search JS from the front-end script; removed the
  Header & Footer Customizer section, the announcement bar, the header
  action area, the per-page "Hide header/footer" toggles, the header/footer
  block patterns, and the related Help/menu entries.
* header.php and footer.php remain as minimal document scaffolding (head,
  body, #page wrapper, wp_head/wp_body_open/wp_footer) — your builder/plugin
  injects the actual header & footer.
* The "remove top/bottom gap" Spacing toggles remain (useful when an external
  header/footer sits against your content). No other features affected.

= 3.5.2 — Fluid / percentage content width =
* New "Content width mode" in Customize -> ZYMARG OS -> Spacing: choose Fixed
  (a constant pixel width, as before) or Fluid (a percentage of the screen).
* Fluid mode fills a configurable share of the viewport (50–100%) but is capped
  by the "Content max width" value, so the layout breathes on ultra-wide / 4K /
  8K displays while keeping text line-length readable. Implemented as
  min(<pct>vw, <cap>px) on the content container.
* Raised the Content max width ceiling from 1920px to 2560px to suit large
  displays.

= 3.5.1 — Secure SVG uploads =
* New "SVG Uploads" module (Customize -> ZYMARG OS -> Modules): lets
  administrators upload SVG images to the Media Library, which WordPress
  blocks by default.
* Every uploaded SVG is sanitized server-side before it is saved — <script>,
  event handlers (on*), foreignObject/iframe/embed/object, javascript: links
  and DOCTYPE/ENTITY (XXE) are stripped or rejected.
* Uploads are restricted to users who can manage the site (filterable via
  zymarg_os_svg_upload_cap), and SVGs now preview correctly in the Media
  Library and image pickers (Account Icon, login logo). On by default.

= 3.5.0 — Discovery Spark™ accent timing tweak =
* The accent spark now pulses at 0.20s (twice as fast) while the companion and
  hero sparks stay at 0.40s, giving the mark a livelier lead beat. Shape,
  colours and sizes unchanged.

= 3.4.11 — Discovery Spark™ motion refresh =
* Updated the ZYMARG Discovery Spark™ animation to the new, faster sequential
  pulse: accent → companion → hero, each firing once per 0.40s cycle (down
  from 1.2s), pulsing in place on its own re-centred origin.
* The mark's shape, colours (purple #6833EA / gold #FFD166) and the full size
  matrix (xs–xl) are unchanged, so every existing placement stays the same
  size — only the motion is new. Updated the design-system demo to match.

= 3.4.10 — Fix: missing medium shadow token =
* Added the --zymarg-shadow-md design token (light + dark + auto), which was
  referenced by the login card and the My Account address cards but never
  defined — so those elements now show their intended soft elevation instead
  of no shadow.

= 3.4.9 — Clearer login pop-up instructions =
* Help page: added a clear note that the login pop-up options (frequency,
  delay, account-icon trigger and the page-targeting rules) only appear after
  you tick "Enable first-visit login pop-up", and that the "Page IDs" field
  shows only when "Only specific pages" / "All pages except…" is selected.

= 3.4.8 — Native Algolia search engine (no plugin required) =
* ZYMARG OS now connects to Algolia by ITSELF — no "WP Search with Algolia"
  (or any) plugin needed. This is the theme's search specialty.
* New dashboard page: ZYMARG OS -> Search Engine. Enter your Algolia keys,
  pick an index, choose what to index, and run a one-click reindex with a live
  progress bar.
* Indexes Products, Product Categories and Brands (brand taxonomy auto-detected;
  Categories and Brands individually toggleable).
* Real-time auto-sync: products, categories and brands update in Algolia
  automatically on add / edit / delete.
* Algolia is now the DEFAULT engine; built-in WordPress search is the automatic
  fallback when Algolia is not configured (so search never breaks).
* Security: the Admin API key is stored server-side and used only for indexing
  — it is never exposed to the browser; only the Search-Only key reaches
  visitors.
* All existing search-bar features are unchanged: instant search-as-you-type,
  the Trending + Recent searches panel, and "See all results".
* Search settings moved out of the Customizer into the new Search Engine page;
  Help page rewritten to document the native, plugin-free setup.

= 3.4.7 — Branded login screen, login card & first-visit pop-up =
* New "Login" feature (Customize -> ZYMARG OS -> Login), three parts:
  * Branded WordPress login screen (wp-login.php) — your logo, brand
    background, accent colour and the ZYMARG orb glow.
  * Front-end login card via the [zymarg_login] shortcode (Login / Register /
    Lost-password tabs) for any page, plus a [zymarg_login_button] that opens
    the pop-up.
  * An elegant first-visit login pop-up (modal) for logged-out visitors with a
    backdrop blur and smooth scale-in.
* Pop-up frequency: once per visitor / once per session / once every X days /
  every visit, with a configurable delay.
* Three INDEPENDENT pop-up sizes — set width + max-height separately for
  desktop, tablet and mobile (with an optional full-screen mobile sheet).
* Page targeting: Entire site / Only specific pages / All pages except…
  (never shown to logged-in users). Opens from the header account icon too.
* Customizable card title, subtitle, accent colour and card background. Brand
  defaults, dark-mode safe. Documented in the ZYMARG OS Help page.

= 3.4.6 — Fully customizable header + announcement bar =
* The built-in (Simple) header is now fully customizable from Customize ->
  ZYMARG OS -> Header & Footer, no code or page builder required:
  * Layout & spacing — logo position, contained/full width, content max-width,
    horizontal padding, header height and logo max-height.
  * Colours & borders — background, text/link colour, link hover colour, a
    bottom border (width + colour) and an optional drop shadow.
  * Menu typography — font size, weight, UPPERCASE toggle and item spacing.
  * Sticky — pin on scroll, a separate "scrolled" background colour, and an
    optional shrink-on-scroll effect.
  * Transparent (overlay) header — sits over your first/hero section with its
    own text colour and turns solid on scroll.
  * Action area — search icon (with a slide-down search box), account icon,
    wishlist count, cart icon + live count, and a coloured CTA button.
  * Mobile — configurable hamburger breakpoint and hamburger colour.
* New announcement / promo bar above the header (text with basic HTML, an
  optional whole-bar link, background + text colours, and an optional dismiss
  that is remembered per browser). Works with plugin / Block headers too.
* All header values are driven by the Customizer via dynamic CSS, default to
  the brand palette and are dark-mode safe. Documented everything in the
  ZYMARG OS Help page.

= 3.4.5 — Supercharged, fully customizable My Account page =
* New "My Account" feature that gives the WooCommerce account page a premium,
  branded makeover (Customize -> ZYMARG OS -> My Account):
  * Welcome hero — gradient banner with the customer's avatar, a personal
    {first_name} greeting and a "member since" line. Configurable gradient
    colours, text colour and avatar shape (circle / rounded / square).
  * Live stat cards — total orders, total spent and wishlist count (each
    toggleable).
  * Quick-action buttons — up to three (Browse shop / Track orders / Edit
    details by default); each label + link is editable, with smart defaults.
  * Premium menu icons — a brand-tinted icon on every account tab (Dashboard,
    Orders, Downloads, Addresses, Account details, Logout).
* Every piece has its own on/off switch; turn the master toggle off to revert
  to the standard WooCommerce layout. Colours default to the brand palette and
  are dark-mode safe.
* Documented the full My Account feature set (plus the Account Icon) in the
  ZYMARG OS Help page.

= 3.4.4 — Fully customizable My Account icon =
* New "Account Icon" feature: a My Account icon you can drop into the header
  menu (enable it in Customize -> ZYMARG OS -> Account Icon) or place anywhere
  with the [zymarg_account_icon] shortcode (works inside plugin / page-builder
  headers too).
* Icon style: choose from 7 built-in SVGs (User, User solid, User in circle,
  User in square, Account badge, Storefront, Heart) OR upload your own image
  (PNG / SVG / JPG).
* Background: pick a shape (none / circle / rounded square / square) plus a
  background colour and a separate hover colour.
* Icon (foreground) colour and overall size controls, an optional text label,
  a custom link (auto-links to the WooCommerce My Account page by default) and
  an open-in-new-tab toggle.
* Fully token-driven defaults (brand primary #9500a5) so it matches the site
  out of the box and flips correctly in dark mode.

= 3.4.3 — Elegant, on-brand My Account page =
* Redesigned the WooCommerce My Account page end-to-end so the whole screen —
  not just the navigation — feels intentional and on-brand.
* Two-column layout: a sticky, card-style navigation with an animated primary
  accent bar on the active/hover item, beside a clean rounded content panel.
* Styled the previously-bare areas: orders & downloads tables (rounded, header
  shading, row hover), address cards (responsive grid with hover lift), the
  account-details / address forms (token inputs with a primary focus ring),
  primary + outlined buttons, and notices.
* Fully token-driven (brand primary #9500a5, radius, spacing, shadow,
  transition tokens) so it inherits Customizer colours and flips correctly in
  dark mode. Responsive: collapses to a single column on small screens.

= 3.4.2 — Centered, perfected product tabs (mobile one-line) =
* Single product tabs (Description, Additional information, Reviews, More
  Products, …) are now centered with a clean, pixel-aligned underline.
* Fixed a specificity clash where ui/tabs.css painted the tabs as grey "pills"
  and overrode the intended underline style; the PDP underline style now wins.
* Mobile: tabs stay on a single horizontal line (tightened spacing; the row
  scrolls instead of wrapping, and each tab stays reachable).

= 3.4.1 — No WooCommerce sidebar (kills the stray default-widget sidebar) =
* The theme now disables WooCommerce's default sidebar
  (remove_action 'woocommerce_sidebar' / woocommerce_get_sidebar). WooCommerce
  pages (shop, product, product-category) no longer call get_sidebar('shop'),
  so no sidebar.php is ever loaded on them.
* Added intentionally empty sidebar.php and sidebar-shop.php templates. On
  install/deploy these overwrite any stray or legacy sidebar.php left in the
  theme folder, so the old Kubrick-style sidebar (Search / Pages / Archives /
  Categories) can never render again.
* sidebar.php only outputs anything if you deliberately enable the optional
  Sidebar widget area (Customize → ZYMARG OS → Widget Areas) and add widgets.

= 3.4.0 — Single product control + widget-area cleanup =
* New "Single Product" Customizer section (ZYMARG OS -> Customize -> Single
  Product). The theme now decides what shows on the product page:
  * Product tabs: show/hide, rename, and reorder every tab — auto-discovered,
    so it covers WooCommerce core (Description, Additional information, Reviews)
    AND plugin tabs like Dokan's Shipping and Questions & Answers.
  * Sections: show/hide Related products, Up-sells, Dokan "More Products from
    this store", and the Dokan "Product Enquiry" button.
* The Dokan blocks are removed with safe, version-tolerant hook name-matching,
  with a CSS fallback as a backstop — no core/plugin templates are overridden.
* New "Widget Areas" Customizer section: the optional Sidebar widget area is now
  off by default (toggle to enable), and the Footer Column 1-4 areas only
  register when the theme's Simple footer is active. This stops WordPress from
  parking its default widgets (Search/Recent Posts/Pages/Archives/Categories…)
  in unused areas. Existing widgets move to Inactive Widgets, nothing is lost.
* Added a "Single Product page — what shows" guide to the Help page, including a
  read-only inspector that lists the tabs detected on your product pages.
* All controls default to no-ops, so existing sites look unchanged until you
  toggle something.

= 3.3.0 — Fully customizable Scroll-to-Top button =
* New "Scroll to Top" Customizer section (ZYMARG OS -> Customize -> Scroll to
  Top). Appearance: background colour, hover colour, icon colour, icon style
  (6 choices), shape (circle / rounded / pill), size and bottom-left/right
  position.
* Behaviour: editable "show after scrolling" threshold, an optional
  scroll-progress ring that fills as you scroll, and a hide-on-mobile toggle.
* Visibility: show on the entire site, the entire site except listed pages, or
  only on listed pages (by page ID or slug; also accepts "home" and "shop").
* Added a "Scroll to Top button" guide to the ZYMARG OS Help page, including
  where to find the settings.
* Colours/size flow through CSS variables (--zst-*) with token fallbacks, so
  the default look is unchanged. The zymarg_os_show_scroll_top filter still
  works for developers.

= 3.2.5 — Brand-aligned admin dashboard colours =
* Reviews dashboard: replaced the off-brand indigo accent (#4f00d0) with the
  brand magenta (#bd00d1), so the header bar / button gradients use the real
  ZYMARG brand pair (#9500a5 -> #bd00d1).
* Snapped bespoke mauve neutrals on the Reviews and Plugins screens to the
  ZYMARG colour tokens (ink #36003d, text #534152, outline #857183 / #d8bfd3,
  surfaces #eaedff / #faf8ff).
* Help screen: code-snippet text now uses the brand tint #ffd6fb instead of the
  near-match #f0d6ff.
* Semantic status chips (approved/pending/rejected) and gold rating stars are
  intentionally left as-is.

= 3.2.4 — Consistent brand orbs in dark mode =
* Dark-mode background orbs now use the same blue-violet brand pair as light
  mode and the policy page (#6833EA / #582A9F) instead of magenta, so the
  signature glow stays on-brand whether a visitor is in light or dark mode.
* No change to the primary brand colour, tints, or light-mode orbs — those
  already matched the policy page.

= 3.2.3 — Tidier review rules =
* Removed the "Override the ZYMARG Reviews plugin" setting from the Review
  rules screen (only relevant if you kept the legacy plugin). The theme
  handles reviews natively regardless.

= 3.2.2 — Reviews menu moved under ZYMARG OS =
* The Reviews screen is now a submenu inside the ZYMARG OS menu (alongside
  Welcome, Help, Customize, Update / Upload Theme, Plugins, Import / Export),
  instead of a separate top-level item next to Comments.

= 3.2.1 — Custom review-notification recipients =
* You can now set which email address(es) receive the "new review" notification
  (Reviews → Review rules). Supports multiple comma-separated addresses;
  leave blank to use the site admin email.

= 3.2.0 — Reviews dashboard + rules (superpowers) =
* New top-level "Reviews" admin menu (next to Comments) showing every product
  review you've received, with stats (total / approved / pending / average),
  filters (status, rating, product, search), sorting (newest / oldest /
  highest / lowest), pagination, and one-click Approve / Unapprove / Edit /
  Trash — all in an elegant, on-brand screen.
* New review rules ("superpowers"):
  - Who can write a review: any logged-in user, or ONLY verified purchasers
    (enforced on every form as a hard server check).
  - Override: let the theme handle reviews even if the legacy ZYMARG Reviews
    plugin is active.
  - Auto-approve (none / verified buyers / everyone).
  - Minimum review length, block reviews containing links (anti-spam), and an
    email-me-on-new-review notification.
* Mobile: the product review cards now use much more width (reduced widget
  container padding) so they no longer look cramped on phones.

= 3.1.1 — Toast consolidation hotfix =
* Removed the legacy ui/toast.css stub (it styled the same .zymarg-toast
  classes as the new unified Toast component and could clash). The new
  components/toast/toast.css is now the single source of truth.

= 3.1.0 — Wishlist, Toasts, smart search & more =
* New: Product Wishlist — heart buttons on shop + single products, saved for
  members (account) and guests (cookie), a [zymarg_wishlist] page and
  [zymarg_wishlist_count] badge, brand-styled and customizable. Toggle under
  Modules.
* New: Unified Toast notifications — one brand-styled, dark-mode-aware system
  used for add-to-cart, wishlist, login and review-submitted, with a
  window.ZymargToast API and a zymarg_os_queue_toast() PHP helper.
* New: Trending & Recent searches — the live-search box shows trending (from
  real searches, with a popular-categories fallback) and per-visitor recent
  searches on focus; they vanish on typing.
* Quick View confirmed built-in (no change needed) and documented.
* Help page expanded to document Reviews, Wishlist, Import/Export, Lazy Images,
  Smart Dark Mode, Trending/Recent search and Toasts.

= 2.13.0 — Smart dark mode (Auto / Light / Dark) =
* The theme switch is now a smart 3-way control: Auto (follow the device),
  Light, and Dark. The choice is remembered in localStorage and applied before
  first paint (no flash). Set Customize → ZYMARG OS → Colours → Color scheme to
  "Smart switch", then place the [zymarg_theme_toggle] button.
* Added semantic colour variables — --surface, --surface-2, --text-primary,
  --text-secondary — that map onto the token system and flip automatically in
  dark mode, so components use intent-based names instead of hardcoded colours.

= 2.12.0 — Reliable review sorting + Lazy Images module =
* Reviews: the sort dropdown (Most Recent / Highest Rated / Lowest Rated) now
  works reliably. Sorting uses machine-readable data (rating + epoch date) on
  each card instead of parsing the displayed date, so it is correct under any
  locale/date format, and it re-sorts after "Load more".
* New "Lazy Images" module with an on/off toggle (Customize → ZYMARG OS →
  Modules, default on). ON lazy-loads images + iframes with async decoding
  (leaving the LCP image to WordPress for safe performance); OFF disables lazy
  loading site-wide so every image loads immediately.

= 2.11.0 — Review photo uploads: 4 MB / 4 images + auto-compressor =
* Review form image upload now allows up to 4 images at 4 MB each (was 2 MB).
* Built-in client-side image compressor: large photos are resized (max
  1920px) and re-encoded to high-quality JPEG in the browser before upload,
  turning multi-MB photos into a few hundred KB — faster uploads, less
  storage, and no upload-limit errors.
* The upload box is placed on the right side of the form, with right-aligned
  thumbnail previews and a live size summary.
* Server still enforces the 4-image / 4 MB caps as a safety net. Compressor
  dimension/quality are filterable (zymarg_os_review_image_max_dimension,
  zymarg_os_review_image_quality).

= 2.10.0 — Smarter export (variations, progress bar, snapshots) =
* Product & Snapshot export now drive WooCommerce's own batched exporter, so
  variable products export WITH all their variations (full round-trip
  fidelity) instead of losing them.
* Exports run in AJAX batches with a live progress bar — no more timeouts /
  white screen on large catalogues.
* Store Snapshot is built from that correct export, so a Snapshot → Restore
  round-trip keeps variable products intact.
* Category & status filters on the product export are preserved.
* No-JS fallback also routed through the WooCommerce exporter.

= 2.9.0 — Smarter product import (progress bar, variations, warnings) =
* Product CSV import now runs in small AJAX batches with a live progress bar
  and running counts (created / updated / skipped / failed) — no more white
  screen or "did not respond in time" on large catalogues.
* Fixes variable products: the import now drives WooCommerce's own importer,
  so variable products + their variations import correctly instead of each
  variation row becoming a separate simple product.
* Reports products that were imported without an image (and lists any failed
  rows) in the results.
* Recognises standard WooCommerce export CSVs (Type, Parent, Attribute N
  name/value(s)/visible/global/default, etc.) in addition to the simple
  ZYMARG format.
* Drag-and-drop CSV preview retained; batch size filterable via
  `zymarg_os_import_batch_size`.

= 2.8.1 — Import / Export moved under the ZYMARG OS menu =
* The Import / Export screen is now a submenu inside the ZYMARG OS menu
  (alongside Welcome, Help, Customize, Update / Upload Theme, Plugins),
  instead of a separate top-level menu item.

= 2.8.0 — Import / Export hub + Store Snapshot =
* The "Import" menu is now "Import / Export" — a full store migration hub.
* Export Products (CSV): download your catalogue with optional category and
  status filters; round-trips cleanly with the importer and standard
  WooCommerce export CSVs.
* Export Categories (CSV): download the whole product-category tree
  (name, slug, parent, description).
* Store Snapshot: one-click ZIP backup containing products.csv +
  categories.csv + a manifest — a portable backup you can move between sites.
* Restore Snapshot: upload a snapshot ZIP to recreate categories (first) and
  products (after) on any ZYMARG OS site.
* Live store stats strip (published products, drafts, categories, on sale).
* Drag-and-drop uploads with an instant CSV preview (row count + detected
  columns) and button loading states.
* Everything remains native WooCommerce data; existing SKUs/terms are skipped
  so imports and restores are safe to re-run.

= 2.7.0 — Import menu (demo content + CSV) =
* New top-level "Import" admin menu with an elegant, on-brand card UI.
* Demo Content: one-click import of a bundled starter catalogue (8 sample
  products across Apparel, Accessories and Home & Living categories).
* Import Products (CSV): bulk-create products from a CSV; categories in the
  file are created automatically, including parent > child hierarchy.
* Import Categories (CSV): build your product-category tree from a CSV
  (name, slug, parent, description).
* Downloadable sample CSV templates and an in-page Instructions card.
* All items are created as native WooCommerce data (real products and
  product_cat terms), so they appear in WooCommerce Products, reports and
  the shop. Existing SKUs are skipped to avoid duplicates. Also compatible
  with a standard WooCommerce product export CSV.

= 2.6.2 — Revert thumbnail gap, keep shadow =
* Reverted the product gallery thumbnail gap back to the original 10px
  (the snug 2px spacing from 2.6.1 is undone).
* Kept the slight shadow on each thumbnail (deeper on hover / active).

= 2.6.1 — Tighter gallery thumbnails =
* The product gallery thumbnail strip now sits snug: the gap between
  thumbnails is reduced from 10px to 2px so they stick together.
* Added a slight shadow to each thumbnail (a touch deeper on hover / the
  active thumbnail) for subtle depth.

= 2.6.0 ��� Built-in product reviews (no plugin required) =
* New: the full ZYMARG Reviews experience is now native to the theme — no
  separate plugin and no Elementor needed. It renders inside the WooCommerce
  single-product "Reviews" tab with the exact same design (rating summary,
  star-breakdown bars, All/Media filters, review feed with photos and
  "Verified Buyer" badges).
* New: a "Write a Review" button appears on My Account → Orders (and View
  Order) for completed orders within a 15/30-day window. It links to the
  product page, auto-opens the Reviews tab and reveals the review form
  (secure, nonce-gated).
* Reviews are stored as native WooCommerce reviews, so they count toward the
  product's star average and reporting. Optional photo uploads, auto-approve
  for verified buyers, and a completion reminder email are supported.
* Admin settings live under WooCommerce → ZYMARG Reviews (review window,
  media limits, moderation, button labels, reminder email).
* Fully responsive across mobile, tablet and desktop. Render options are
  filterable via `zymarg_os_reviews_settings`.

= 2.5.20 — Summary nudge tweak =
* On tablet and desktop the Product Summary block is now positioned 4% lower
  (raised 1% from the previous 5%).

= 2.5.19 — Revert summary card; nudge it down 5% =
* Reverted the v2.5.18 change: the Product Summary boxed card is restored exactly
  as it was before.
* On tablet and desktop (two-column layout) the summary block is now positioned
  5% lower.

= 2.5.18 — Summary aligns with the product image =
* On desktop/tablet the Product Summary now sits flush and top-aligned with the
  product image: the title starts level with the top of the image instead of
  being pushed down by the summary's boxed padding. (The boxed "card" styling
  was removed from the summary to achieve this.)

= 2.5.17 — 10 products across two rows =
* Related products now show 10 items in a 5-column grid (two tidy rows on
  desktop/tablet; 2 columns on phones).
* Added a filter to request 10 items for Dokan's "More Products" section where
  the Dokan version allows it.

= 2.5.16 — Product grid alignment fix (no more ragged rows) =
* Fixed the ragged rows and phantom empty slots in the Related and "More
  Products" grids (e.g. 3+4+1 instead of clean rows, or "space for 8" when only
  6 products exist). Cause: WooCommerce's clearfix pseudo-elements and the
  "clear" on first items were leaking into the CSS grid as invisible cells.
  These are now neutralised so the grid lays out evenly.
* Columns are now consistent: 4 across on desktop and tablet (so 8 related
  products sit in two tidy rows) and 2 across on phones.

= 2.5.15 — More related products, grid fixes & swatch alignment =
* Related products increased from 4 to 8 (two rows of four; fewer show if the
  product simply has fewer related items).
* Every product list on the single product page — related, up-sells and any
  "More Products" / vendor list inside a tab — now uses one responsive grid
  (4 / 3 / 2 / 1 columns) instead of stacking as vertical cards. Hardened to
  override Dokan / legacy float styles.
* Fixed variation swatch alignment: swatch chips are now consistent auto-width
  pills that sit inline neatly next to the product image column.
* Gallery thumbnails (the small variety images under the main image) are now
  about 50% larger and fill their cells, while staying responsive.

= 2.5.14 — Visible product-page trust icons =
* Fixed the product page trust badge icons that were invisible (purple icon on a
  purple circle). The icons are now white on a lighter, brighter purple circle
  so they read clearly.

= 2.5.13 — Fix related/up-sells product grid on single product page =
* Fixed the "more products" (related & up-sells) grid on the single product page
  which could collapse into a squished half-width column. Those sections now
  always span the full width and use a properly responsive grid: 4 columns on
  desktop, 3 on tablet, 2 on phones (1 on very narrow screens). Product card
  images are normalised so they never overflow.

= 2.5.12 — Next-level single product page =
* New: a completely redesigned, conversion-focused single product page with full
  variable-product support. Sticky image gallery (zoom + lightbox + thumbnails),
  variation swatches (colour chips / button pills) synced to WooCommerce's live
  price/image/stock with unavailable options dimmed, a quantity stepper (+/-), a
  percentage-off sale badge, a trust-badge row, and restyled tabs & related
  products. Built with hooks + a scoped stylesheet (no template overrides) so it
  stays compatible with WooCommerce/Dokan updates. Toggle it in Customize →
  ZYMARG OS → Modules → "Enhanced single product page". Documented on the Help page.

= 2.5.11 — Plugins screen in the ZYMARG OS menu =
* New: "Plugins" item in the ZYMARG OS menu with a two-column page — "Add Plugin"
  (upload a plugin zip or browse the directory) and "Installed Plugins" (a live
  list with Active/Inactive badges plus a button to the full Plugins screen).
  Activate/deactivate/delete still use the native WordPress screen. Only shown to
  users who can install plugins; respects DISALLOW_FILE_MODS. Documented in Help.

= 2.5.10 — Slightly larger menu icon =
* The ZYMARG OS menu icon is now ~10% larger again for better visibility in the
  sidebar (still white on a transparent background).

= 2.5.9 — Update/Upload Theme from the ZYMARG OS menu =
* New: "Update / Upload Theme" item in the ZYMARG OS menu (and a button on the
  Welcome screen). Upload a new theme zip in one click without going to
  Appearance → Themes. Uploading an already-installed theme uses WordPress's
  built-in replace/update flow and keeps your settings. Only shown to users who
  can install themes; respects DISALLOW_FILE_MODS. Documented on the Help page.

= 2.5.8 — Help page: more feature guides =
* Added in-dashboard Help instructions for features that previously had none:
  Mega Menu (with copy-paste CSS classes and step-by-step setup), the
  WooCommerce shop features (Quick View, off-canvas cart drawer, sticky
  add-to-cart, gallery zoom/lightbox, shop columns), the product Grid Skin
  (zymarg-grid-skin) for builder/plugin grids, and a note on Scroll to Top.

= 2.5.7 — One-click header/footer gap removers =
* New: two toggles in Customize → ZYMARG OS → Spacing — "I already have a header
  above (remove the top gap)" and "I already have a footer below (remove the
  bottom gap)". For sites using a header/footer from another theme/plugin, these
  close the empty gap with one click, no CSS. Default off, so sites without an
  external header/footer keep their balanced spacing. Per site. Documented on
  the in-dashboard Help page.

= 2.5.6 — White menu icon =
* The ZYMARG OS menu icon is now solid white on a transparent background and
  5% larger, so it reads clearly against the dark admin sidebar.

= 2.5.5 — Correct menu icon size =
* Fixed the oversized menu icon. WordPress shows PNG menu icons at their raw
  pixel size (no scaling), so the icon overflowed the row. The icon is now a
  grayscale logo embedded in an SVG data URI — WordPress sizes SVG icons to 20px
  automatically (same method as the original v2.5.0 icon), so it sits correctly.

= 2.5.4 — Grayscale, balanced menu icon =
* The ZYMARG OS menu icon is now grayscale (soft black-and-white tones) and
  has padding around it so it no longer looks oversized — it now sits balanced
  next to the other sidebar items.

= 2.5.3 — Menu icon fix =
* Fixed: the dedicated "ZYMARG OS" menu showed no icon. WordPress strips inline
  "data:" PNG icons via esc_url(), so the v2.5.2 inline icon never rendered. The
  icon now ships as a tiny 2 KB PNG file (ZYMARG/menu-icon.png) and displays
  correctly in the sidebar.

= 2.5.2 — Lightweight menu icon =
* The menu icon is now embedded inline as a tiny 2 KB data URI instead of
  bundling the full 544 KB logo file. The theme stays lean and the branded
  icon still shows in the sidebar. Removed /ZYMARG/zymarg-logo.png.

= 2.5.1 — Branded menu icon =
* The dedicated "ZYMARG OS" sidebar menu now uses the official ZYMARG logo
  instead of the auto-generated monochrome Discovery Spark icon.

= 2.5.0 — Dedicated admin menu =
* ZYMARG OS now has its own top-level sidebar menu (with a monochrome Discovery
  Spark icon), like WooCommerce/Dokan/Elementor — a branded home in the
  dashboard. Includes a Welcome screen (version, big CTAs, quick-setting tiles
  to every Customizer panel) and the Help guide, which moved here from
  Appearance. Adds a "Customize" quick link too.

= 2.4.0 — Result sorting =
* Search & archive pages now have a Sort dropdown: Latest, Oldest, Name (A–Z),
  and — on WooCommerce — Price low→high and high→low. It auto-submits and
  preserves the search query. WooCommerce shop/category pages keep their own
  native ordering dropdown (now styled to match).
* All result/archive layouts remain fully responsive (3→2→1 column grids,
  mobile-friendly sort bar).

= 2.3.0 — Results & archive pages =
* Added styled search.php and archive.php templates: results/posts shown as an
  on-brand responsive card grid (with product price on WooCommerce), a query +
  result-count heading, the search form, and pagination. (WooCommerce product
  category/search pages keep using WooCommerce's own grid.)
* The [zymarg_search] bar is now a real search form: pressing Enter goes to the
  full results page, and the dropdown gains a "See all results →" link.

= 2.2.1 =
* Help page: added an "Add the search bar to your header" step-by-step card
  (synced-pattern Block header + the [zymarg_search] shortcode).

= 2.2.0 — Algolia search =
* Live Search can now run on Algolia: Customize → ZYMARG OS → Search → set
  engine to "Algolia" and enter your Application ID, Search-Only API Key and
  Index name. Searches then run directly in the visitor's browser against
  Algolia — zero search load on your WordPress server, scaling to 100k+
  products with instant, typo-tolerant results.
* The built-in WP_Query search remains as an automatic fallback (used only when
  Algolia isn't configured), so the search bar never breaks.
* Note: index your products into Algolia with the free "WP Search with Algolia"
  plugin; the theme handles the search UI + querying, not indexing.
* The Discovery Spark now appears inside the search bar by default (disable
  with [zymarg_search spark="false"]).

= 2.1.0 — SEO & Scale =
* SEO Schema module: Organization + WebSite (Sitelinks search box) JSON-LD for
  rich results, auto-deferring to Yoast/Rank Math/SEOPress/AIOSEO to avoid
  duplicates (WooCommerce keeps providing Product schema).
* Breadcrumbs module: [zymarg_breadcrumbs] shortcode + optional auto-display
  (Customize → Spacing) + BreadcrumbList JSON-LD. Smart trail for pages,
  posts, products (shop → category → product), archives and search.
* Live Search upgraded for scale: title-focused search_columns, short-term
  result caching, and a zymarg_os_live_search_args filter. Automatically uses
  ElasticPress / Relevanssi / Algolia when installed (recommended for 100k+
  products).

= 2.0.0 — Smart UX =
* Instant Load: prefetches internal pages on hover/tap so navigation feels
  instant (skips cart/checkout/account/admin; respects Save-Data).
* Scroll Animations: add the "zymarg-reveal" class (or --left/--right/--zoom)
  to any block to reveal it on scroll. Progressive + reduced-motion safe.
* Live Search: [zymarg_search] shows instant search-as-you-type results
  (products on WooCommerce sites, otherwise posts/pages) in a branded dropdown.
* All three are toggleable modules; documented in Appearance → ZYMARG OS Help.

= 1.9.0 =
* Header & Footer visibility rules: "Show header/footer on" — Entire site,
  Only specific pages, or All pages except… (comma-separated page IDs). Plus
  per-page "Hide the header/footer on this page" checkboxes in the page editor
  "ZYMARG OS" box (alongside Hide page title).
* Help page expanded: added Header & Footer (incl. visibility) and Per-page
  controls cards. Going forward, every major feature is documented in
  Appearance → ZYMARG OS Help.

= 1.8.0 =
* New optional Header & Footer (Customize -> ZYMARG OS -> Header & Footer),
  both off by default so plugin-managed setups are unaffected. Each has two
  content sources:
  - Simple: built-in layout (header = logo + menu with layout/sticky/width/
    height/background; footer = 1–4 widget columns + copyright) — 4 new Footer
    Column widget areas added.
  - Block: render a synced pattern you design in the block editor, giving
    unlimited rows, columns and custom widths/heights.
* Added "ZYMARG Header Bar" and "ZYMARG Footer" starter block patterns, a
  responsive mobile menu toggle, and header/footer styling.

= 1.7.3 =
* Added a one-click "Turn WooCommerce Coming Soon OFF" button to the dashboard
  notice. Unlike the runtime override, this actually writes WooCommerce's own
  setting to Live (woocommerce_coming_soon = no) — so WooCommerce's settings
  page reflects it too. Capability-checked and nonce-protected, with success
  feedback.

= 1.7.2 =
* Site Mode gains a "Force the site live" option: when Mode = Live, the theme
  overrides other coming-soon / maintenance systems (e.g. WooCommerce's built-in
  Coming Soon) on the front end so the site is public. The override is applied
  at runtime via pre_option filters — nothing is written to other plugins'
  settings, so it's fully reversible.
* Added dashboard notices: confirms what's being overridden when Force Live is
  on, or warns when another coming-soon system may be hiding the site while it's
  off. Extensible via the zymarg_os_force_live_overrides and
  zymarg_os_detected_coming_soon filters (+ the zymarg_os_force_live action).

= 1.7.1 =
* Site Mode now supports a Custom HTML layout: in Customize -> ZYMARG OS ->
  Site Mode, set Layout to "Custom HTML" and paste your own design for the
  Coming Soon / Maintenance page. Shortcodes (e.g. [zymarg_spark]) are
  processed; admins with unfiltered_html may include styles/scripts.

= 1.7.0 =
* New Site Mode superpower (Customize -> ZYMARG OS -> Site Mode): switch the
  site between Live, Coming Soon, and Maintenance. Visitors see a branded,
  orb-background placeholder with your headline, message, optional launch
  countdown, social links and a login link, while logged-in admins keep seeing
  the real site. Maintenance mode returns an SEO-safe HTTP 503. An admin-bar
  badge reminds you while it's active.

= 1.6.1 =
* You can now hide the page title: a "Hide the page title on this page"
  checkbox in the page editor (ZYMARG OS box), plus a global "Hide all page
  titles" toggle in Customize -> ZYMARG OS -> Spacing. (The blank-canvas and
  full-width page templates already omit the title.)

= 1.6.0 =
* Added an in-dashboard Help page (Appearance -> ZYMARG OS Help): a friendly
  guide to the Discovery Spark, dark-mode toggle, block patterns and fonts,
  with one-click "Copy" buttons for every shortcode and live Spark previews.
* Removed the bundled brand logo image files from the ZYMARG/ folder (kept the
  Discovery Spark component and demo). The theme thumbnail is unaffected.

= 1.5.1 =
* Added the official ZYMARG brand assets to the ZYMARG/ folder:
  zymarg-logo.svg (vector), zymarg-logo-horizontal.png (lockup),
  zymarg-mark.png (square mark) and zymarg-logo.jpg.
* Rebuilt the theme thumbnail (screenshot.png) to feature the official ZYMARG
  logo on the signature orb background.

= 1.5.0 =
* Dark / Light theme system: choose Light, Dark, Auto (follow the visitor's
  device) or Toggle (visitor switch) in Customize -> ZYMARG OS -> Colours.
  Dark tokens (tokens/dark.css) re-theme every component; a no-flash early
  script and a [zymarg_theme_toggle] button/​helper are included.
* Added "Container" starter patterns �� Row (flex), Grid (responsive auto-fit),
  Split (content + media) and Section (full-width padded) — so you can drop in
  a container and drag items around in the free editor, Elementor-style.

= 1.4.0 =
* Gutenberg, leveled up: added a "ZYMARG OS" block-pattern library — hero with
  the orb background, feature cards, gradient CTA, stats bar, product section,
  Discovery Spark feature and vendor spotlight — so you can build pages in the
  free block editor without Elementor.
* Added custom block STYLE variations: buttons (Primary/Outline/Ghost), group
  (Card/Orb Section/Gradient Band), rounded image and brand separator. These
  preview correctly inside the editor (token + block CSS loaded there too).
* Added a decoupled product-grid SKIN (components/grid-skin.css): add the
  class "zymarg-grid-skin" to your product-grid plugin's Elementor widget (or
  any wrapper) and its cards, images, prices and buttons inherit ZYMARG styling.

= 1.3.0 =
* Fonts: "Self-host" now AUTO-DOWNLOADS Inter + Sora from Google to
  /uploads/zymarg-os-fonts/ and serves them locally (faster + GDPR-friendly).
  Runs on Customizer publish, with a manual "Download fonts now" admin button
  and a safe fallback to the static stylesheet / system fonts.
* Updates: added a self-hosted theme update mechanism. Point the theme at a
  JSON manifest via the ZYMARG_OS_UPDATE_URI constant or the
  zymarg_os_update_manifest_url filter and updates appear in Dashboard ->
  Updates like any theme. Inactive (safe) until a URL is configured.
* Added the ZYMARG/ folder with the ZYMARG Discovery Spark component:
  zymarg-discovery-spark.css, a reusable PHP helper [zymarg_discovery_spark()]
  + [zymarg_spark] shortcode with size (xs-xl), motion and colour variations,
  and a standalone demo matrix (discovery-spark-demo.html).

= 1.2.0 =
* Reorganised the CSS into a cleaner, de-duplicated architecture:
  - tokens/ — split design tokens into colors, typography, spacing, radius,
    shadows, opacity (new), transitions and z-index (single source of truth).
  - base/ — reset + element typography.
  - helpers/ — utility classes (colors, spacing, grid, flex, visibility),
    moved out of the old design-system/ and layouts/.
  - ui/ — new reusable primitives: modal, drawer, toast, tooltip, dropdown,
    tabs and loading (spinner/overlay/skeleton).
* WooCommerce Quick View now reuses the generic ui/modal, and the off-canvas
  cart reuses the generic ui/drawer (no more duplicated modal/drawer CSS).
* Removed the old design-system/ folder and components/skeleton.css after
  moving their contents; rewired the enqueue cascade accordingly.
* New opacity tokens now drive disabled buttons and input placeholders.

= 1.1.1 =
* Added screenshot.png (1200x900) so the theme shows a branded preview on the
  Appearance -> Themes screen.

= 1.1.0 =
* Refactored the CSS into a modular architecture: design-system/ (variables,
  colors, typography, spacing, grid), components/ (buttons, cards, forms,
  badges, skeleton, navigation), layouts/ (container, section, responsive) and
  woocommerce/ (product, cart, checkout, account).
* Added assets/icons/ (SVG sprite + helper classes) and assets/animations/
  (keyframes + animation utilities, incl. skeleton shimmer and optional orb
  drift).
* Stylesheets now load in cascade order and WooCommerce CSS is split so only
  the relevant files load on shop/Dokan contexts.
* New utility classes for colour, spacing, grid/flex, typography and badges.

= 1.0.0 =
* Initial release.
* Modular activation system with Performance, WooCommerce, Mega Menu,
  Scroll to Top, Custom Fonts, White Label and LearnDash modules.
* ZYMARG design tokens, dual-orb background, Inter/Sora typography.
* Customizer controls for colours, typography (incl. custom font upload),
  spacing and buttons, with live colour preview.
* WooCommerce + Dokan integration: Quick View, off-canvas cart, sticky
  add-to-cart, configurable shop columns.
* Custom layout hooks, theme.json palette, blank-canvas and full-width page
  templates.
