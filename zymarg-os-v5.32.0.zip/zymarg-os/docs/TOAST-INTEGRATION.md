# ZYMARG OS - Toast integration for plugins

Drop-in guide for wiring any plugin into the theme's shared toast system.

As of theme **5.17.0** this needs **no theme edits, ever**. Everything below is
plugin-side only.

---

## 1. Fire a toast (JavaScript)

```js
window.ZymargToast.show( {
    message: 'Saved!',
    type:    'success',            // success | error | info | warning
    source:  'my-plugin-slug'      // ALWAYS set this
} );
```

Shorthands:

```js
window.ZymargToast.success( 'Saved!', { source: 'my-plugin-slug' } );
window.ZymargToast.error( 'Failed.', { source: 'my-plugin-slug' } );
```

Optional extras: `title`, `duration` (ms), `action: { label, url }`.

### You do NOT need a fallback popup

An inline stub is printed in the page head before your scripts run, so
`window.ZymargToast` always exists. Toasts fired before the main script loads
are queued and replayed automatically.

Available on the **front end**, in **wp-admin**, and on **wp-login.php**.

---

## 2. Fire a toast (PHP)

Shows on the next page load:

```php
zymarg_os_queue_toast( 'Settings saved.', 'success', '', 'my-plugin-slug' );
```

---

## 3. Register your source (one-time, 5 lines)

This makes your plugin appear on the Toast Notification screen with an on/off
toggle immediately, before it has ever fired a toast.

```php
add_filter( 'zymarg_os_known_toast_sources', function ( $sources ) {
    $sources[] = 'my-plugin-slug';
    return $sources;
} );
```

---

## 4. Fully decoupled option (no hard dependency)

```js
document.dispatchEvent( new CustomEvent( 'zymarg:toast', {
    detail: { message: 'Hi', type: 'info', source: 'my-plugin-slug' }
} ) );
```

---

## Rules

1. Always pass a `source`. Without it the toast logs as `unknown` and cannot be
   toggled off individually.
2. Use one stable slug per plugin, lowercase with hyphens.
3. Never build your own toast. That is the whole point of this system.
4. Respect the toggle. Blocking is handled centrally; do not work around it.

---

## Available filters (the stable contract)

| Filter | Purpose |
| --- | --- |
| `zymarg_os_known_toast_sources` | Register a source so it always has a toggle |
| `zymarg_os_toast_position` | Change on-screen position |
| `zymarg_os_toast_duration` | Change default display time |
| `zymarg_os_toast_enable_in_admin` | Disable toasts in wp-admin |
| `zymarg_os_toast_enable_on_login` | Disable toasts on wp-login.php |
| `zymarg_os_toast_early_stub` | Disable the early-call queue stub |
| `zymarg_os_toast_scan_patterns` | Teach the plugin scanner a new toast style |
| `zymarg_os_toast_scan_source_regex` | Change how declared sources are detected |

---

## Migrating a plugin that has its own toast

Rewrite only the body of its existing toast function to call
`window.ZymargToast`, keeping the original signature so every call site keeps
working. Then delete the old toast CSS and markup once confirmed live.
See `zymarg-login-security`, `zymarg-wc-product-grid` and
`zymarg-single-product` for worked examples.
