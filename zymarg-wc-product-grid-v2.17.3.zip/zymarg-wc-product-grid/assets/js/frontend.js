/* global jQuery, ZYMARGWCPG */
/**
 * ZYMARG WC Product Grid - Frontend Runtime (Phase 4)
 *
 * Real AJAX layer:
 *   - Cache-safe wishlist heart hydration on page load (one /hydrate call
 *     reads visitor wishlist IDs and toggles aria-pressed on every heart).
 *   - Wishlist click: optimistic toggle, AJAX persist, rollback on error.
 *   - Add to cart: simple products only (variable links to PDP); refreshes
 *     cart fragments via the WC fragments hook so themed mini-carts update.
 *   - Click tracking on card link clicks (throttled per card per page).
 *   - Quick view click: posts a quickview event for trending, prevents
 *     default - the modal arrives in Phase 5.
 *   - Load more pagination: posts widget settings + page, appends rendered
 *     cards, hydrates them too.
 *   - Toast notifications for success / error / rate-limit messages.
 *
 * v1.3.14 fix: ajaxUrl and nonce are no longer read once at IIFE init time.
 * They are read lazily via getNs() inside every handler and every ajax()
 * call. This fixes silent failures on the search results page where
 * ZYMARGWCPG is populated asynchronously (waitForWCPG polling) — by the
 * time any user click fires, ZYMARGWCPG is always fully populated.
 */
( function ( $ ) {
	'use strict';

	var ns   = ( window.ZYMARGWCPG = window.ZYMARGWCPG || {} );
	ns.ready = true;

	var TRACK_KEY = '_zymargTracked';

	/**
	 * Read ajaxUrl + nonce lazily at call time.
	 * Always returns the live window.ZYMARGWCPG object so async
	 * population (search page) is picked up correctly.
	 */
	function getNs() {
		return window.ZYMARGWCPG || {};
	}

	/* ----------------------------------------------------------------- *
	 * Toast
	 * ----------------------------------------------------------------- */
	var $toastHost = null;

	/**
	 * v2.17.2 — Consolidated onto the ZYMARG OS theme toast system.
	 *
	 * This function previously rendered its own `.zymarg-wcpg__toast` popup.
	 * Because shoppers also see toasts from the theme and from other plugins,
	 * that meant several visually different popups on one storefront, and none
	 * of these could be reviewed or switched off from Theme → Toast
	 * Notification.
	 *
	 * It now delegates to `window.ZymargToast`, tagging every toast with the
	 * source `zymarg-product-grid`, so this plugin appears in the theme's toast
	 * activity log and on/off control panel.
	 *
	 * The original implementation is preserved as an automatic fallback for
	 * when the ZYMARG OS theme is not active, so the plugin still works
	 * standalone on any theme.
	 *
	 * The `( message, type )` signature is unchanged, so all existing call
	 * sites here and in quickview.js / wishlist-button.js keep working. An
	 * optional third argument passes extra theme-toast options through (for
	 * example a "View wishlist" action).
	 *
	 * @param {string} message Text to display.
	 * @param {string} type     'success' | 'error' | 'info'. Defaults to 'info'.
	 * @param {Object} [opts]   Optional extra ZymargToast options (title, action, duration).
	 */
	function toast( message, type, opts ) {
		if ( ! message ) { return; }

		var api = window.ZymargToast;
		if ( api && typeof api.show === 'function' ) {
			var payload = {
				message: message,
				type: type || 'info',
				source: 'zymarg-product-grid'
			};
			if ( opts ) {
				if ( opts.title ) { payload.title = opts.title; }
				if ( opts.action ) { payload.action = opts.action; }
				if ( typeof opts.duration === 'number' ) { payload.duration = opts.duration; }
			}
			api.show( payload );
			return;
		}

		// ---- Fallback: theme toast unavailable (different theme active) ----
		if ( ! $toastHost ) {
			$toastHost = $( '<div class="zymarg-wcpg__toast-host" role="status" aria-live="polite"></div>' ).appendTo( 'body' );
		}
		var $t = $( '<div class="zymarg-wcpg__toast"></div>' )
			.addClass( 'zymarg-wcpg__toast--' + ( type || 'info' ) )
			.text( message )
			.appendTo( $toastHost );
		setTimeout( function () { $t.addClass( 'is-in' ); }, 10 );
		setTimeout( function () {
			$t.removeClass( 'is-in' );
			setTimeout( function () { $t.remove(); }, 250 );
		}, 2400 );
	}

	function ajax( action, data ) {
		var _ns = getNs();
		return $.ajax( {
			url: _ns.ajaxUrl || '/wp-admin/admin-ajax.php',
			method: 'POST',
			dataType: 'json',
			data: $.extend( {
				action: 'zymarg_wcpg_' + action,
				nonce:  _ns.nonce || ''
			}, data || {} )
		} );
	}

	/* ----------------------------------------------------------------- *
	 * Hydration - cache-safe wishlist heart state
	 * ----------------------------------------------------------------- */
	function hydrate( $scope ) {
		$scope = $scope || $( document );
		var $hearts = $scope.find( '[data-action="wishlist-toggle"]' );
		var $badges = $scope.find( '[data-zymarg-wcpg-wishlist-count]' );
		// Skip the AJAX call entirely if there is nothing to hydrate on
		// this page (no hearts AND no Wishlist Button badges).
		if ( ! $hearts.length && ! $badges.length ) { return; }
		ajax( 'hydrate', {} ).done( function ( res ) {
			if ( ! res || ! res.success || ! res.data ) { return; }
			var ids   = res.data.wishlist_ids || [];
			var count = typeof res.data.wishlist_count !== 'undefined'
				? res.data.wishlist_count
				: ids.length;
			var idMap = {};
			for ( var i = 0; i < ids.length; i++ ) { idMap[ ids[ i ] ] = true; }
			$hearts.each( function () {
				var _ns2 = getNs();
				var pid  = parseInt( $( this ).data( 'product-id' ), 10 );
				$( this ).attr( 'aria-pressed', idMap[ pid ] ? 'true' : 'false' );
				$( this ).attr(
					'aria-label',
					idMap[ pid ]
						? ( ( _ns2.i18n && _ns2.i18n.removeFromWishlist ) || 'Remove from wishlist' )
						: ( ( _ns2.i18n && _ns2.i18n.addToWishlist )      || 'Add to wishlist' )
				);
			} );
			// Broadcast the hydrated count so the standalone Wishlist
			// Button widget can refresh its badge even when the page
			// was served from a full-page cache (where the badge's
			// server-rendered count was for a different visitor).
			$( document ).trigger( 'zymarg_wcpg:wishlist:hydrated', [ { count: count, ids: ids } ] );
		} );
	}

	/* ----------------------------------------------------------------- *
	 * Wishlist click
	 * ----------------------------------------------------------------- */
	$( document ).on( 'click', '[data-action="wishlist-toggle"]', function ( e ) {
		e.preventDefault();
		var $btn = $( this );
		if ( $btn.data( 'busy' ) ) { return; }
		$btn.data( 'busy', true );

		var pid    = parseInt( $btn.data( 'product-id' ), 10 );
		var wasOn  = $btn.attr( 'aria-pressed' ) === 'true';
		var nextOn = ! wasOn;

		// Optimistic toggle.
		$btn.attr( 'aria-pressed', nextOn ? 'true' : 'false' );

		ajax( 'wishlist', { op: 'toggle', product_id: pid } )
			.done( function ( res ) {
				var _ns = getNs();
				if ( res && res.success ) {
					var on = !! ( res.data && res.data.in_wishlist );
					$btn.attr( 'aria-pressed', on ? 'true' : 'false' );
					toast( res.data && res.data.message ? res.data.message : '', 'success' );
					// Broadcast for the standalone Wishlist Button widget
					// (live count badge updates). Safe no-op if no listener.
					if ( res.data && typeof res.data.count !== 'undefined' ) {
						$( document ).trigger( 'zymarg_wcpg:wishlist:changed', [ {
							count:       res.data.count,
							product_id:  pid,
							in_wishlist: on
						} ] );
					}
				} else {
					// Rollback.
					$btn.attr( 'aria-pressed', wasOn ? 'true' : 'false' );
					toast( ( res && res.data && res.data.message ) || ( ( _ns.i18n && _ns.i18n.genericError ) || 'Error' ), 'error' );
				}
			} )
			.fail( function ( xhr ) {
				var _ns = getNs();
				$btn.attr( 'aria-pressed', wasOn ? 'true' : 'false' );
				if ( xhr.status === 429 ) {
					toast( ( _ns.i18n && _ns.i18n.rateLimited ) || 'Too many requests', 'error' );
				} else {
					toast( ( _ns.i18n && _ns.i18n.genericError ) || 'Error', 'error' );
				}
			} )
			.always( function () { $btn.data( 'busy', false ); } );
	} );

	/* ----------------------------------------------------------------- *
	 * Add to cart - simple products only
	 * ----------------------------------------------------------------- */
	$( document ).on( 'click', '[data-action="add-to-cart"]', function ( e ) {
		var $btn = $( this );
		var type = String( $btn.data( 'product-type' ) || 'simple' );
		var pid  = parseInt( $btn.data( 'product-id' ), 10 );

		// Variable products: let the <a> link navigate to the PDP.
		if ( 'simple' !== type || ! pid ) { return; }

		// Out-of-stock: let the link navigate too.
		var inStock = $btn.closest( '.zymarg-wcpg__card' ).is( ':not(.is-oos)' );
		if ( ! inStock ) { return; }

		e.preventDefault();
		if ( $btn.data( 'busy' ) ) { return; }
		$btn.data( 'busy', true ).addClass( 'is-loading' );

		ajax( 'add_to_cart', { product_id: pid, quantity: 1 } )
			.done( function ( res ) {
				var _ns = getNs();
				if ( res && res.success ) {
					toast( ( res.data && res.data.message ) || ( ( _ns.i18n && _ns.i18n.addedToCart ) || 'Added' ), 'success' );

					if ( res.data && res.data.fragments ) {
						$( document.body ).trigger(
							'wc_fragments_refreshed',
							[ res.data.fragments, res.data.cart_hash ]
						);

						// Check if we're inside an Elementor widget wrapper.
						// On the search page there is no .zymarg-wcpg ancestor,
						// so $widget will be empty — treat that as showViewCart=true
						// (same as the widget default) so fragments still fire.
						var $widget      = $btn.closest( '.zymarg-wcpg' );
						var showViewCart = $widget.length
							? ( '0' !== $widget.attr( 'data-show-view-cart' ) )
							: true;

						if ( showViewCart ) {
							$( document.body ).trigger(
								'added_to_cart',
								[ res.data.fragments, res.data.cart_hash, $btn ]
							);
						} else {
							$btn.siblings( '.added_to_cart' ).remove();
							$btn.parent().find( '.added_to_cart' ).remove();
						}
					}
				} else {
					toast( ( res && res.data && res.data.message ) || ( ( _ns.i18n && _ns.i18n.genericError ) || 'Error' ), 'error' );
				}
			} )
			.fail( function ( xhr ) {
				var _ns = getNs();
				if ( xhr.status === 429 ) {
					toast( ( _ns.i18n && _ns.i18n.rateLimited ) || 'Too many requests', 'error' );
				} else {
					toast( ( _ns.i18n && _ns.i18n.genericError ) || 'Error', 'error' );
				}
			} )
			.always( function () {
				$btn.data( 'busy', false ).removeClass( 'is-loading' );
			} );
	} );

	/* ----------------------------------------------------------------- *
	 * Click tracking on card link clicks (throttle once per card per page).
	 * ----------------------------------------------------------------- */
	$( document ).on( 'click', '.zymarg-wcpg__title-link, .zymarg-wcpg__image-link', function () {
		var $card = $( this ).closest( '.zymarg-wcpg__card' );
		if ( ! $card.length || $card.data( TRACK_KEY ) ) { return; }
		var pid = parseInt( $card.data( 'product-id' ), 10 );
		if ( ! pid ) { return; }
		$card.data( TRACK_KEY, true );
		ajax( 'track_click', { product_id: pid, event: 'click' } );
	} );

	/* ----------------------------------------------------------------- *
	 * Load more pagination
	 * ----------------------------------------------------------------- */
	$( document ).on( 'click', '.zymarg-wcpg__load-more', function ( e ) {
		e.preventDefault();
		var $btn = $( this );
		if ( $btn.data( 'busy' ) ) { return; }

		var $widget = $btn.closest( '.zymarg-wcpg' );
		var $grid   = $widget.find( '.zymarg-wcpg__grid' );
		var page    = parseInt( $btn.data( 'page' ), 10 ) || 2;
		var settings;
		try {
			settings = JSON.parse( $widget.attr( 'data-settings' ) || '{}' );
		} catch ( err ) {
			settings = {};
		}

		var extraData = {
			page:      page,
			widget_id: $widget.attr( 'data-widget-id' )
		};
		var algoliaQuery = $btn.data( 'algolia-query' );
		if ( algoliaQuery !== undefined && algoliaQuery !== '' ) {
			extraData.algolia_query = String( algoliaQuery );
		}
		// v1.5.22: carry active VCF category term across paginated pages.
		var vcfTermId = parseInt( $btn.data( 'vcf-term-id' ), 10 ) || 0;
		if ( vcfTermId > 0 ) {
			extraData.current_vendor_category_term_id = vcfTermId;
		}
		// v1.5.23: carry vendor ID across paginated pages for AJAX context.
		var vcfVendorId = parseInt( $btn.data( 'vcf-vendor-id' ), 10 ) || 0;
		if ( vcfVendorId > 0 ) {
			extraData.current_vendor_id = vcfVendorId;
		}

		// v2.6.0: Infinite scroll sends an explicit offset + batch, because its
		// batch size can differ from the first-page size and page-number math
		// would then skip or duplicate products. A legacy Load More button never
		// has a batch set, so its request shape is unchanged.
		var batchSize = parseInt( $btn.data( 'batch' ), 10 ) || 0;
		if ( batchSize > 0 ) {
			extraData.offset = $grid.find( '.zymarg-wcpg__card' ).length;
			extraData.batch  = batchSize;
		}

		$widget.trigger( 'zymarg:loadmore:start' );
		$btn.data( 'busy', true ).addClass( 'is-loading' );

		ajax( 'load_more', $.extend( extraData, settings ) )
			.done( function ( res ) {
				var before = $grid.find( '.zymarg-wcpg__card' ).length;
				if ( res && res.success && res.data && res.data.html ) {
					var $newCards = $( res.data.html );
					$grid.append( $newCards );
					hydrate( $newCards );
					if ( res.data.has_more ) {
						$btn.data( 'page', page + 1 );
					} else {
						$btn.remove();
					}
					$widget.trigger( 'zymarg:loadmore:done', [ {
						added:   $grid.find( '.zymarg-wcpg__card' ).length - before,
						hasMore: !! res.data.has_more
					} ] );
				} else {
					$btn.remove();
					$widget.trigger( 'zymarg:loadmore:done', [ { added: 0, hasMore: false } ] );
				}
			} )
			.fail( function ( xhr ) {
				var _ns = getNs();
				if ( xhr.status === 429 ) {
					toast( ( _ns.i18n && _ns.i18n.rateLimited ) || 'Too many requests', 'error' );
				} else {
					toast( ( _ns.i18n && _ns.i18n.genericError ) || 'Error', 'error' );
				}
				$widget.trigger( 'zymarg:loadmore:fail', [ { status: xhr.status } ] );
			} )
			.always( function () {
				$btn.data( 'busy', false ).removeClass( 'is-loading' );
			} );
	} );

	/* ----------------------------------------------------------------- *
	 * Bootstrap on DOM ready.
	 * ----------------------------------------------------------------- */
	$( function () {
		hydrate();
	} );

	// Re-hydrate when Elementor renders a widget (covers the editor preview
	// reload and AJAX-loaded sections).
	$( window ).on( 'elementor/frontend/init', function () {
		if ( window.elementorFrontend && elementorFrontend.hooks ) {
			elementorFrontend.hooks.addAction(
				'frontend/element_ready/zymarg_product_grid.default',
				function ( $scope ) { hydrate( $scope ); }
			);
		}
	} );

	/* ----------------------------------------------------------------- *
	 * v1.5.22: Vendor Category Filter bridge
	 *
	 * Listens for the custom event dispatched by the ZYMARG Theme Builder
	 * Vendor Category Filter widget (widgets.js) when the user clicks a
	 * category tab. Finds every Product Grid widget on the page that shares
	 * the same filter_group_id and re-fetches its cards via the existing
	 * load_more AJAX handler with current_vendor_category_term_id injected.
	 *
	 * Detail payload: { term_id: Number, group: String }
	 *   term_id = 0 ��� "All" tab (no category filter)
	 *   term_id > 0 → specific product_cat term ID
	 *   group       → matches data-filter-group on the .zymarg-wcpg wrapper
	 * ----------------------------------------------------------------- */
	document.addEventListener( 'zymarg:vcf:filter', function ( e ) {
		if ( ! e.detail ) { return; }

		var termId = parseInt( e.detail.term_id, 10 ) || 0;
		var group  = String( e.detail.group || '' );
		if ( ! group ) { return; }

		// Find all Product Grid widgets that share this group ID.
		var selector = '.zymarg-wcpg[data-filter-group="' + group + '"]';
		var grids    = document.querySelectorAll( selector );
		if ( ! grids.length ) { return; }

		grids.forEach( function ( gridEl ) {
			var $grid   = $( gridEl );
			var $cards  = $grid.find( '.zymarg-wcpg__grid' );
			var widgetId = $grid.attr( 'data-widget-id' ) || '';

			var settings;
			try {
				settings = JSON.parse( $grid.attr( 'data-settings' ) || '{}' );
			} catch ( err ) {
				settings = {};
			}

			// Show loading state.
			$cards.addClass( 'is-loading' );

			ajax( 'load_more', $.extend( {}, settings, {
				page:                               1,
				widget_id:                          widgetId,
				current_vendor_category_term_id:    termId,
				current_vendor_id:                  parseInt( $grid.attr( 'data-vendor-id' ) || '0', 10 ) || 0,
			} ) ).done( function ( res ) {
				if ( res && res.success && res.data ) {
					$cards.html( res.data.html || '' );
					hydrate( $cards );

					// Reset load-more button to page 2, store active term.
					var $btn = $grid.find( '.zymarg-wcpg__load-more' );
					if ( $btn.length ) {
						if ( res.data.has_more ) {
							$btn.data( 'page', 2 )
								.data( 'vcf-term-id', termId )
								.data( 'vcf-vendor-id', parseInt( $grid.attr( 'data-vendor-id' ) || '0', 10 ) || 0 )
								.show();
						} else {
							$btn.hide();
						}
					}
				}
			} ).fail( function () {
				toast( ( getNs().i18n && getNs().i18n.genericError ) || 'Error', 'error' );
			} ).always( function () {
				$cards.removeClass( 'is-loading' );
			} );
		} );
	} );

	/* ----------------------------------------------------------------- *
	 * v1.5.22: Preserve active VCF category term across load-more pages
	 *
	 * When a load-more click fires AND the grid has an active VCF term
	 * (stored by the filter bridge above), inject the term ID into the
	 * POST payload so paginated pages stay within the same category.
	 * Patched onto the existing load-more handler via a pre-ajax hook.
	 * ----------------------------------------------------------------- */
	$( document ).on( 'click', '.zymarg-wcpg__load-more', function () {
		// Attach any active VCF term to the button's data so the main
		// load-more handler can read it via extraData below.
		var $btn    = $( this );
		var termId  = parseInt( $btn.data( 'vcf-term-id' ), 10 ) || 0;
		if ( termId > 0 ) {
			// Store on the button so the main handler picks it up.
			$btn.data( 'current-vendor-category-term-id', termId );
		}
	} );

	/* ----------------------------------------------------------------- *
	 * v2.6.0: Infinite scroll (grid layout)
	 *
	 * Drives the existing Load More button from an IntersectionObserver
	 * instead of duplicating the request logic. Every source-specific data
	 * attribute (Algolia query, category term, Dokan vendor) therefore keeps
	 * working for free.
	 *
	 * Progressive enhancement: the button is rendered server-side and only
	 * hidden here. Without JS or IntersectionObserver the widget silently
	 * behaves as a normal Load More button.
	 *
	 * Cache safety: the batch size and cap are resolved from viewport width
	 * in the browser. Resolving them in PHP would let a cached desktop page
	 * serve desktop numbers to phones.
	 *
	 * The cap counts auto-loaded products only. Once it is reached the pill
	 * fades out, the button is revealed, and auto loading never resumes for
	 * that page view.
	 * ----------------------------------------------------------------- */
	var INFINITE_MIN_MS   = 1500; // Minimum pill display time (from the mockup).
	var INFINITE_PREFETCH = 300;  // Start loading before the sentinel is on screen.

	function infiniteDevice() {
		var w = window.innerWidth || document.documentElement.clientWidth || 0;
		if ( w < 768 )  { return 'mobile'; }
		if ( w < 1025 ) { return 'tablet'; }
		return 'desktop';
	}

	function infiniteText( key, fallback ) {
		var i18n = getNs().i18n || {};
		return i18n[ key ] || fallback;
	}

	function infiniteSetup( $widget ) {
		var $btn = $widget.find( '.zymarg-wcpg__load-more' ).first();

		if ( ! $btn.length || '1' !== String( $btn.attr( 'data-infinite' ) ) ) { return; }
		if ( $widget.data( '_zymargInfinite' ) ) { return; }

		var $loader     = $widget.find( '.zymarg-wcpg__infinite-loader' ).first();
		var $pagination = $btn.closest( '.zymarg-wcpg__pagination' );
		var sentinel    = $widget.find( '.zymarg-wcpg__scroll-sentinel' ).get( 0 );

		// No sentinel or no observer support: keep the manual button as rendered.
		if ( ! sentinel || ! window.IntersectionObserver ) { return; }

		$widget.data( '_zymargInfinite', true );

		var autoLoaded = 0; // Auto-loaded products only. The first page never counts.
		var stopped    = false;
		var shownAt    = 0;
		var observer   = null;

		function numAttr( prefix, fallback ) {
			var value = parseInt( $btn.attr( 'data-' + prefix + '-' + infiniteDevice() ), 10 );
			return value > 0 ? value : fallback;
		}

		function applyBatch() {
			$btn.data( 'batch', numAttr( 'batch', 20 ) );
		}

		function loaderShow() {
			shownAt = ( new Date() ).getTime();
			$loader
				.attr( 'class', 'zymarg-wcpg__infinite-loader is-loading' )
				.html(
					'<span class="zymarg-wcpg__loader-dots" aria-hidden="true">' +
					'<span></span><span></span><span></span></span>' +
					'<span class="zymarg-wcpg__loader-label">' +
					infiniteText( 'loadingMore', 'Loading more products' ) +
					' <span class="zymarg-wcpg__loader-text-dots">' +
					'<span>.</span><span>.</span><span>.</span></span></span>'
				);
		}

		function loaderHide() {
			$loader.attr( 'class', 'zymarg-wcpg__infinite-loader' ).empty();
		}

		function loaderFinished() {
			$loader
				.attr( 'class', 'zymarg-wcpg__infinite-loader is-finished' )
				.html(
					'<span class="zymarg-wcpg__finished-icon" aria-hidden="true">&#10003;</span>' +
					'<span>' + infiniteText( 'allLoaded', 'All products loaded' ) + '</span>'
				);
		}

		// Cards are appended immediately; only the pill honours the minimum
		// display time, so content is never held back by the animation.
		function afterMinimum( fn ) {
			var remaining = INFINITE_MIN_MS - ( ( new Date() ).getTime() - shownAt );
			if ( remaining > 0 ) {
				window.setTimeout( fn, remaining );
			} else {
				fn();
			}
		}

		function stopAuto( revealButton ) {
			stopped = true;
			if ( observer ) {
				observer.disconnect();
				observer = null;
			}
			if ( revealButton ) {
				$pagination.removeClass( 'is-auto' );
			}
		}

		$widget.on( 'zymarg:loadmore:start', function () {
			loaderShow();
		} );

		$widget.on( 'zymarg:loadmore:done', function ( e, data ) {
			var hasMore = !! ( data && data.hasMore );

			if ( ! stopped ) {
				autoLoaded += ( data && data.added ) || 0;
			}

			// Nothing left in the catalog: confirm with the finished pill.
			if ( ! hasMore ) {
				afterMinimum( loaderFinished );
				stopAuto( false );
				return;
			}

			afterMinimum( loaderHide );

			if ( stopped ) { return; }

			// Cap reached: hand control back to the user.
			if ( autoLoaded >= numAttr( 'max', 100 ) ) {
				stopAuto( true );
				return;
			}

			if ( observer ) {
				observer.observe( sentinel );
			}
		} );

		// A failed or rate-limited request must not retry in a scroll loop.
		$widget.on( 'zymarg:loadmore:fail', function () {
			afterMinimum( loaderHide );
			stopAuto( true );
		} );

		observer = new window.IntersectionObserver(
			function ( entries ) {
				if ( stopped || ! entries.length || ! entries[0].isIntersecting ) { return; }
				if ( $btn.data( 'busy' ) ) { return; }

				// Unobserve first so a fast scroll cannot queue a second request.
				observer.unobserve( sentinel );
				applyBatch();
				$btn.trigger( 'click' );
			},
			{ root: null, rootMargin: INFINITE_PREFETCH + 'px 0px', threshold: 0 }
		);

		$pagination.addClass( 'is-auto' );
		applyBatch();
		observer.observe( sentinel );

		// Rotating a tablet or resizing a desktop window switches device tier.
		$( window ).on( 'resize.zymargInfinite', function () {
			if ( ! stopped ) { applyBatch(); }
		} );
	}

	function infiniteBoot( $scope ) {
		var $root = $scope && $scope.length ? $scope : $( document );

		if ( $root.is && $root.is( '.zymarg-wcpg' ) ) {
			infiniteSetup( $root );
		}

		$root.find( '.zymarg-wcpg' ).each( function () {
			infiniteSetup( $( this ) );
		} );
	}

	$( function () {
		infiniteBoot();
	} );

	$( window ).on( 'elementor/frontend/init', function () {
		if ( window.elementorFrontend && elementorFrontend.hooks ) {
			elementorFrontend.hooks.addAction(
				'frontend/element_ready/zymarg_product_grid.default',
				function ( $scope ) { infiniteBoot( $scope ); }
			);
		}
	} );

	// ----------------------------------------------------------------
	// Flash Deals countdown (v2.9.0)
	//
	// The server prints only an absolute end timestamp, because rendered HTML
	// is cached and any server-formatted digits would freeze. Everything
	// visible is produced here.
	//
	// One shared interval drives every timer on the page. Each tick recomputes
	// from the absolute end time, so the display cannot drift no matter how
	// often ticks are missed or throttled.
	// ----------------------------------------------------------------

	var COUNTDOWN_SELECTOR  = '.zymarg-wcpg__countdown';
	var COUNTDOWN_SKEW_TOL  = 60000; // Ignore clock gaps under a minute.
	var countdownTimer      = null;
	var countdownSkew       = null;  // ms to add to the client clock.

	function countdownPad( n ) {
		return ( n < 10 ) ? ( '0' + n ) : String( n );
	}

	/**
	 * Adaptive formatter: days only when at least one remains, seconds only
	 * inside the final hour where they actually convey urgency.
	 */
	function countdownFormat( remainingMs, i18n ) {
		var total = Math.floor( remainingMs / 1000 );
		if ( total < 0 ) {
			total = 0;
		}

		var days  = Math.floor( total / 86400 );
		var hours = Math.floor( ( total % 86400 ) / 3600 );
		var mins  = Math.floor( ( total % 3600 ) / 60 );
		var secs  = total % 60;

		var dU = i18n.countdownDay || 'd';
		var hU = i18n.countdownHour || 'h';
		var mU = i18n.countdownMinute || 'm';
		var sU = i18n.countdownSecond || 's';

		if ( days > 0 ) {
			return days + dU + ' ' + countdownPad( hours ) + hU + ' ' + countdownPad( mins ) + mU;
		}
		if ( total >= 3600 ) {
			return countdownPad( hours ) + hU + ' ' + countdownPad( mins ) + mU;
		}

		return countdownPad( mins ) + mU + ' ' + countdownPad( secs ) + sU;
	}

	/**
	 * Correct for a wrong device clock.
	 *
	 * data-now is the server clock at render time. A large gap means the
	 * visitor's clock is genuinely wrong and must be corrected. A small gap is
	 * just cache age, and is deliberately ignored so a cached page is not
	 * distorted by treating its age as clock skew.
	 */
	function countdownResolveSkew( $el ) {
		if ( null !== countdownSkew ) {
			return countdownSkew;
		}

		var serverNow = parseInt( $el.attr( 'data-now' ), 10 );
		if ( ! serverNow || isNaN( serverNow ) ) {
			countdownSkew = 0;
			return countdownSkew;
		}

		var diffMs = ( serverNow * 1000 ) - ( new Date() ).getTime();
		countdownSkew = ( Math.abs( diffMs ) > COUNTDOWN_SKEW_TOL ) ? diffMs : 0;

		return countdownSkew;
	}

	function countdownTick() {
		var $timers = $( COUNTDOWN_SELECTOR ).not( '.is-ended' );
		if ( ! $timers.length ) {
			countdownStop();
			return;
		}

		var i18n  = getNs().i18n || {};
		var nowMs = ( new Date() ).getTime();

		$timers.each( function () {
			var $el   = $( this );
			var endTs = parseInt( $el.attr( 'data-ends' ), 10 );
			if ( ! endTs || isNaN( endTs ) ) {
				return;
			}

			var $time     = $el.find( '.zymarg-wcpg__countdown-time' );
			var $sr       = $el.find( '.zymarg-wcpg__countdown-sr' );
			var remaining = ( endTs * 1000 ) - ( nowMs + countdownResolveSkew( $el ) );

			if ( remaining <= 0 ) {
				// The card deliberately stays in place: removing it would
				// reflow the grid and break slider geometry mid-view.
				var ended = i18n.countdownEnded || 'Deal ended';
				$el.addClass( 'is-ended' );
				$time.text( ended );
				$sr.text( ended );
				$el.trigger( 'zymarg:countdown:ended' );
				return;
			}

			var formatted = countdownFormat( remaining, i18n );
			var prefix    = i18n.countdownEndsIn || '';
			$time.text( prefix ? ( prefix + ' ' + formatted ) : formatted );

			// Screen readers get a coarse per-minute update. A per-second live
			// region would be unusable with assistive tech.
			var stamp = Math.floor( remaining / 60000 );
			if ( $el.data( 'zymargSrStamp' ) !== stamp ) {
				$el.data( 'zymargSrStamp', stamp );
				var tpl = i18n.countdownSrFormat || 'Sale ends in %s';
				$sr.text( tpl.replace( '%s', formatted ) );
			}
		} );
	}

	function countdownStart() {
		if ( countdownTimer ) {
			return;
		}
		if ( ! $( COUNTDOWN_SELECTOR ).not( '.is-ended' ).length ) {
			return;
		}

		countdownTick();
		countdownTimer = window.setInterval( countdownTick, 1000 );
	}

	function countdownStop() {
		if ( countdownTimer ) {
			window.clearInterval( countdownTimer );
			countdownTimer = null;
		}
	}

	function countdownBoot() {
		countdownStop();
		countdownStart();
	}

	$( function () {
		countdownBoot();
	} );

	// No point burning a timer while the tab is hidden. Recomputing from the
	// absolute end time on return means nothing has to be caught up.
	$( document ).on( 'visibilitychange', function () {
		if ( document.hidden ) {
			countdownStop();
		} else {
			countdownBoot();
		}
	} );

	// Cards arriving via load more / infinite scroll need adopting.
	$( document ).on( 'zymarg:loadmore:done', function () {
		countdownBoot();
	} );

	$( window ).on( 'elementor/frontend/init', function () {
		if ( window.elementorFrontend && elementorFrontend.hooks ) {
			elementorFrontend.hooks.addAction(
				'frontend/element_ready/zymarg_product_grid.default',
				function () { countdownBoot(); }
			);
		}
	} );

	// Expose for debugging / external use.
	ns.hydrate = hydrate;
	ns.toast   = toast;

} )( jQuery );
