<?php
/**
 * ZYMARG Template Pack - dynamic status badge resolver.
 *
 * Resolves exactly ONE status badge per product from a fixed priority ladder.
 * The ladder is total: the final rung ('classic') is age-only and matches
 * anything older than the freshness window, so every product always resolves
 * to a badge. That guarantee is what keeps the meta row from collapsing on
 * products with no rating and no sales.
 *
 * Priority (first match wins):
 *   1  limited_offer     on sale WITH a future end date
 *   2  last_chance       managing stock, qty at or below threshold
 *   3  hot_pick          top N of the engine trending cache
 *   4  best_seller       lifetime sales at or above threshold
 *   5  in_demand         anywhere in the trending cache
 *   6  popular           7-day engagement score at or above threshold
 *   7  great_value       discount at or above threshold percent
 *   8  fresh_pick        published within the fresh window
 *   9  latest_collection published within the latest window
 *  10  classic           floor - always matches
 *
 * Engine coupling: tiers 3, 5 and 6 read data owned by ZYMARG WC Product Grid
 * (Trending_Calculator + Engagement_Store). Every access is guarded, so if the
 * engine moves those internals the ladder simply falls through to the price,
 * freshness and lifecycle tiers instead of fataling.
 *
 * @package Zymarg\TemplatePack
 * @since   1.5.0
 */

defined( 'ABSPATH' ) || exit;

final class Zymarg_Template_Pack_Badge_Resolver {

	/**
	 * Meta key mirroring the 7-day weighted engagement score. Used only if the
	 * engine's own constant is unavailable.
	 */
	const FALLBACK_META = '_zymarg_clicks_7d';

	/**
	 * Request-scoped cache of the trending top-N id list.
	 *
	 * @var int[]|null
	 */
	private static $trending_ids = null;

	/**
	 * Wire up the bulk meta preload.
	 */
	public static function init() {
		add_action( 'zymarg_product_grid_before_render', array( __CLASS__, 'prime' ), 10, 2 );
	}

	/**
	 * Prime the post-meta cache for the whole result set in ONE query.
	 *
	 * Without this, tier 6 would issue a get_post_meta() per card. The engine
	 * fires this action with the full product list before any card renders.
	 *
	 * @param array $config   Render config (unused).
	 * @param array $products Products about to render.
	 */
	public static function prime( $config, $products = array() ) {
		unset( $config );

		if ( ! is_array( $products ) || empty( $products ) ) {
			return;
		}

		$ids = array();
		foreach ( $products as $maybe_product ) {
			if ( $maybe_product instanceof \WC_Product ) {
				$ids[] = (int) $maybe_product->get_id();
			} elseif ( is_numeric( $maybe_product ) ) {
				$ids[] = (int) $maybe_product;
			}
		}

		$ids = array_filter( array_unique( $ids ) );
		if ( ! empty( $ids ) ) {
			update_meta_cache( 'post', $ids );
		}
	}

	/**
	 * Ladder thresholds. All filterable.
	 *
	 * @return array<string,int>
	 */
	public static function thresholds() {
		return (array) apply_filters(
			'zymarg_pack_badge_thresholds',
			array(
				'last_chance_qty'   => 3,
				'hot_pick_top_n'    => 20,
				'best_seller_sales' => 50,
				'popular_score'     => 10,
				'great_value_pct'   => 25,
				'fresh_days'        => 7,
				'latest_days'       => 30,
			)
		);
	}

	/**
	 * Badge labels. All filterable, all translatable.
	 *
	 * @return array<string,string>
	 */
	public static function labels() {
		return (array) apply_filters(
			'zymarg_pack_badge_labels',
			array(
				'limited_offer'     => __( 'Limited Offer', 'zymarg-template-pack' ),
				'last_chance'       => __( 'Last Chance', 'zymarg-template-pack' ),
				'hot_pick'          => __( 'Hot Pick', 'zymarg-template-pack' ),
				'best_seller'       => __( 'Best Seller', 'zymarg-template-pack' ),
				'in_demand'         => __( 'In Demand', 'zymarg-template-pack' ),
				'popular'           => __( 'Popular', 'zymarg-template-pack' ),
				'great_value'       => __( 'Great Value', 'zymarg-template-pack' ),
				'fresh_pick'        => __( 'Fresh Pick', 'zymarg-template-pack' ),
				'latest_collection' => __( 'Latest Collection', 'zymarg-template-pack' ),
				'classic'           => __( 'Classic', 'zymarg-template-pack' ),
			)
		);
	}

	/**
	 * Visual tier for a badge key. Drives colour grouping in CSS.
	 *
	 * @param string $key Badge key.
	 * @return string
	 */
	private static function tier_of( $key ) {
		$map = array(
			'limited_offer'     => 'price',
			'great_value'       => 'price',
			'last_chance'       => 'scarcity',
			'hot_pick'          => 'trending',
			'best_seller'       => 'trending',
			'in_demand'         => 'trending',
			'popular'           => 'trending',
			'fresh_pick'        => 'freshness',
			'latest_collection' => 'freshness',
			'classic'           => 'lifecycle',
		);

		return isset( $map[ $key ] ) ? $map[ $key ] : 'lifecycle';
	}

	/**
	 * Trending top-N ids from the engine cache, resolved once per request.
	 *
	 * @return int[]
	 */
	private static function trending_ids() {
		if ( null !== self::$trending_ids ) {
			return self::$trending_ids;
		}

		self::$trending_ids = array();

		if ( class_exists( '\Zymarg\WCPG\Trending\Trending_Calculator' )
			&& method_exists( '\Zymarg\WCPG\Trending\Trending_Calculator', 'get_cached_ids' ) ) {
			$ids = \Zymarg\WCPG\Trending\Trending_Calculator::get_cached_ids();
			if ( is_array( $ids ) ) {
				self::$trending_ids = array_values( array_map( 'intval', $ids ) );
			}
		}

		return self::$trending_ids;
	}

	/**
	 * 7-day weighted engagement score for a product.
	 *
	 * @param int $product_id Product id.
	 * @return int
	 */
	private static function engagement_score( $product_id ) {
		$meta_key = self::FALLBACK_META;

		if ( class_exists( '\Zymarg\WCPG\Trending\Engagement_Store' )
			&& defined( '\Zymarg\WCPG\Trending\Engagement_Store::META_MIRROR' ) ) {
			$meta_key = (string) constant( '\Zymarg\WCPG\Trending\Engagement_Store::META_MIRROR' );
		}

		return (int) get_post_meta( (int) $product_id, $meta_key, true );
	}

	/**
	 * Discount percentage for a product, or 0 when not determinable.
	 *
	 * Variable products expose no parent regular price, so they resolve to 0
	 * here and fall through to a later tier rather than reporting a wrong
	 * number.
	 *
	 * @param \WC_Product $product Product.
	 * @return int
	 */
	private static function discount_pct( \WC_Product $product ) {
		$regular = (float) $product->get_regular_price();
		$current = (float) $product->get_price();

		if ( $regular <= 0 || $current <= 0 || $current >= $regular ) {
			return 0;
		}

		return (int) round( ( ( $regular - $current ) / $regular ) * 100 );
	}

	/**
	 * Walk the ladder and return the first matching badge key.
	 *
	 * @param \WC_Product $product    Product.
	 * @param array       $thresholds Resolved thresholds.
	 * @return string
	 */
	private static function match( \WC_Product $product, array $thresholds, array $skip = array() ) {
		$now = time();

		// Rungs listed in $skip are passed over so the ladder falls through to
		// the next genuine match, rather than rendering no badge at all. The
		// flash card uses this to drop 'limited_offer', which would otherwise
		// win on every flash product and duplicate the countdown beside it.
		$allowed = static function ( $key ) use ( $skip ) {
			return ! in_array( $key, $skip, true );
		};

		// 1. Limited Offer - a genuinely time-limited sale.
		if ( $allowed( 'limited_offer' ) && $product->is_on_sale() ) {
			$sale_end = $product->get_date_on_sale_to();
			if ( $sale_end && $sale_end->getTimestamp() > $now ) {
				return 'limited_offer';
			}
		}

		// 2. Last Chance - real, managed scarcity only.
		if ( $allowed( 'last_chance' ) && $product->managing_stock() ) {
			$qty = $product->get_stock_quantity();
			if ( null !== $qty && $qty > 0 && $qty <= (int) $thresholds['last_chance_qty'] ) {
				return 'last_chance';
			}
		}

		$product_id = (int) $product->get_id();
		$trending   = self::trending_ids();

		// 3. Hot Pick - top of the trending cache (already score-ordered).
		if ( $allowed( 'hot_pick' ) && ! empty( $trending ) ) {
			$position = array_search( $product_id, $trending, true );
			if ( false !== $position && $position < (int) $thresholds['hot_pick_top_n'] ) {
				return 'hot_pick';
			}
		}

		// 4. Best Seller - lifetime volume.
		if ( $allowed( 'best_seller' ) && (int) $product->get_total_sales() >= (int) $thresholds['best_seller_sales'] ) {
			return 'best_seller';
		}

		// 5. In Demand - anywhere in the trending cache.
		if ( $allowed( 'in_demand' ) && ! empty( $trending ) && in_array( $product_id, $trending, true ) ) {
			return 'in_demand';
		}

		// 6. Popular - recent engagement (clicks, quickviews, wishlists, carts).
		if ( $allowed( 'popular' ) && self::engagement_score( $product_id ) >= (int) $thresholds['popular_score'] ) {
			return 'popular';
		}

		// 7. Great Value - deep discount with no end date.
		if ( $allowed( 'great_value' ) && $product->is_on_sale() && self::discount_pct( $product ) >= (int) $thresholds['great_value_pct'] ) {
			return 'great_value';
		}

		// 8 + 9. Freshness.
		$created = $product->get_date_created();
		if ( $created ) {
			$age_days = ( $now - $created->getTimestamp() ) / DAY_IN_SECONDS;
			if ( $allowed( 'fresh_pick' ) && $age_days <= (float) $thresholds['fresh_days'] ) {
				return 'fresh_pick';
			}
			if ( $allowed( 'latest_collection' ) && $age_days <= (float) $thresholds['latest_days'] ) {
				return 'latest_collection';
			}
		}

		// 10. Classic - age-only floor. Always matches.
		return 'classic';
	}

	/**
	 * Resolve the single status badge for a product.
	 *
	 * @param \WC_Product $product  Product.
	 * @param array       $settings Card settings.
	 * @return array{key:string,label:string,tier:string}|null Null only when disabled or invalid.
	 */
	public static function resolve( $product, array $settings = array(), array $skip = array() ) {
		if ( ! ( $product instanceof \WC_Product ) ) {
			return null;
		}

		$key    = self::match( $product, self::thresholds(), $skip );
		$labels = self::labels();

		$result = array(
			'key'   => $key,
			'label' => isset( $labels[ $key ] ) ? (string) $labels[ $key ] : '',
			'tier'  => self::tier_of( $key ),
		);

		/**
		 * Filter the resolved badge. Return null to render no badge at all.
		 *
		 * @param array|null  $result   Resolved badge.
		 * @param \WC_Product $product  Product.
		 * @param array       $settings Card settings.
		 */
		$result = apply_filters( 'zymarg_pack_badge_result', $result, $product, $settings );

		if ( ! is_array( $result ) || empty( $result['label'] ) ) {
			return null;
		}

		return $result;
	}
}
