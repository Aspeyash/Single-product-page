/**
 * ZYMARG Template Pack — front-end tweaks (v1.4.5)
 *
 * Loaded automatically by the engine's Asset_Manager as the card template's
 * optional script.js (dependency: the engine frontend JS), so it only runs on
 * pages where the ZYMARG card is actually rendered.
 *
 * Purpose
 * -------
 * 1. Suppress the engine's built-in green "Added to cart" success toast on the
 *    ZYMARG card. The site's theme already shows its own add-to-cart
 *    notification via ZymargToast (added_to_cart body event), so the engine
 *    toast would be a duplicate.
 *
 * 2. Bridge wishlist toggle results into the theme's ZymargToast system.
 *    The engine fires `zymarg_wcpg:wishlist:changed` after every successful
 *    heart toggle but does not fire any WooCommerce body event — so the theme's
 *    built-in add-to-cart listener never picks it up. This block listens for
 *    that event and routes it through ZymargToast so wishlist feedback matches
 *    the add-to-cart toast style exactly.
 *
 * Scope / safety
 * --------------
 * We only remove the green SUCCESS toast for cart additions, never error or
 * wishlist toasts. The wishlist bridge only fires when ZymargToast is present
 * (theme active) and gracefully no-ops otherwise.
 */
( function () {
	'use strict';

	if ( typeof window.jQuery === 'undefined' ) {
		return;
	}

	var $ = window.jQuery;

	/* ------------------------------------------------------------------ *
	 * 1. Suppress duplicate engine add-to-cart success toast
	 * ------------------------------------------------------------------ */

	/**
	 * Remove any green success toast the engine has appended to its
	 * body-level toast host. Error/info toasts (different modifier classes)
	 * are left in place.
	 */
	function removeSuccessToasts() {
		$( '.zymarg-wcpg__toast--success' ).remove();
	}

	// Immediate, precise catch: fires for card + Quick View cart additions.
	$( document.body ).on( 'added_to_cart', function () {
		removeSuccessToasts();
		window.setTimeout( removeSuccessToasts, 0 );
		window.setTimeout( removeSuccessToasts, 80 );
	} );

	// Fallback: poll briefly after an add-to-cart click on a ZYMARG card, in
	// case `added_to_cart` is not triggered. Scoped to the ZYMARG card's ATC
	// control so an unrelated wishlist success toast is not affected.
	$( document ).on(
		'click',
		'.zymarg-wcpg__card--zymarg .zymarg-zc__atc-btn, .zymarg-wcpg__card--zymarg [data-action="add-to-cart"]',
		function () {
			var tries = 0;
			var timer = window.setInterval( function () {
				removeSuccessToasts();
				if ( ++tries >= 10 ) {
					window.clearInterval( timer );
				}
			}, 120 );
		}
	);

	/* ------------------------------------------------------------------ *
	 * 2. Bridge wishlist toggles into the theme ZymargToast system
	 * ------------------------------------------------------------------ */

	/**
	 * After a successful heart toggle the engine broadcasts
	 * `zymarg_wcpg:wishlist:changed` with { in_wishlist, count, product_id }.
	 * We relay that into ZymargToast so the feedback matches the add-to-cart
	 * toast style. When ZymargToast IS present we also remove the engine's
	 * own `.zymarg-wcpg__toast--success` below, so wishlist feedback is never
	 * shown twice. When ZymargToast is absent this handler returns early and
	 * the engine toast is left completely alone as the fallback, expiring on
	 * its own schedule.
	 */
	$( document ).on( 'zymarg_wcpg:wishlist:changed', function ( e, payload ) {
		if ( ! window.ZymargToast ) { return; }
		if ( ! payload ) { return; }

		var ns  = window.ZYMARGWCPG || {};
		var i18n = ns.i18n || {};

		var message = payload.in_wishlist
			? ( i18n.addedToWishlist    || 'Added to wishlist' )
			: ( i18n.removedFromWishlist || 'Removed from wishlist' );

		// Remove the engine's own wishlist success toast to avoid the
		// duplicate now that the theme toast is taking over.
		$( '.zymarg-wcpg__toast--success' ).remove();

		window.ZymargToast.success( message, {
			action: ( payload.in_wishlist && i18n.viewWishlist && ns.wishlistUrl )
				? { label: i18n.viewWishlist, url: ns.wishlistUrl }
				: null
		} );
	} );

}() );
