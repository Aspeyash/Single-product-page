/**
 * ZYMARG Flash Sales card - countdown ticker (v1.7.1)
 *
 * Loaded automatically by the engine's Asset_Manager because it sits beside
 * this template's product-card.php, so it only runs on pages where the flash
 * card is actually rendered.
 *
 * Why the pack ships its own ticker
 * ---------------------------------
 * The engine's countdown renderer (v2.9.0) uses an adaptive format: days when
 * more than a day remains, seconds only under an hour. The approved flash
 * mockup uses a fixed HH:MM:SS readout instead, and the design was locked as
 * pixel-identical - so this card renders its own timer element and ticks it
 * here rather than bending the engine's shared format.
 *
 * Clock skew
 * ----------
 * Each element carries data-ends and data-now, both server-side timestamps.
 * The difference between data-now and the browser clock is measured ONCE, on
 * the first tick, and cached for every tick after it - so a visitor with a
 * badly set clock still sees the correct remaining time.
 *
 * Measuring it once is not an optimisation, it is the whole correctness
 * argument. Re-deriving skew on every tick cancels the browser clock out of
 * the sum entirely (remaining = ends - (now + (serverNow - now)) reduces to
 * ends - serverNow, a constant) and the timer freezes at its rendered value.
 * That was the v1.6.0-1.7.0 bug fixed in v1.7.1.
 *
 * A gap smaller than SKEW_TOL is treated as cache age or rounding and ignored;
 * the card HTML is cached, so data-now is routinely a little stale. Anything
 * larger is treated as a real client-clock error. This matches the engine's
 * countdown renderer, so both timers agree on a page that shows both.
 */
( function () {
	'use strict';

	var SELECTOR = '.zymarg-wcpg__card--flash .zymarg-zc__timer-val';
	var SKEW_TOL = 60;
	var timer = null;
	var skewSecs = null;

	/**
	 * Zero-pad to two digits.
	 *
	 * @param {number} n Value.
	 * @return {string} Padded value.
	 */
	function pad( n ) {
		return ( n < 10 ? '0' : '' ) + n;
	}

	/**
	 * Format remaining seconds as HH:MM:SS.
	 *
	 * Hours are not capped at 24: a three-day sale reads 72:00:00, which keeps
	 * the format fixed-width and unambiguous rather than silently wrapping.
	 *
	 * @param {number} secs Seconds remaining.
	 * @return {string} Formatted string.
	 */
	function format( secs ) {
		var h = Math.floor( secs / 3600 );
		var m = Math.floor( ( secs % 3600 ) / 60 );
		var s = Math.floor( secs % 60 );

		return pad( h ) + ':' + pad( m ) + ':' + pad( s );
	}

	/**
	 * Update every timer on the page.
	 *
	 * @return {void}
	 */
	function tick() {
		var nodes = document.querySelectorAll( SELECTOR );

		if ( ! nodes.length ) {
			if ( timer ) {
				window.clearInterval( timer );
				timer = null;
			}
			return;
		}

		var browserNow = Math.floor( Date.now() / 1000 );
		var i;

		for ( i = 0; i < nodes.length; i++ ) {
			updateNode( nodes[ i ], browserNow );
		}
	}

	/**
	 * Resolve the server-to-browser clock offset, once, and cache it.
	 *
	 * @param {Element} node       Timer element carrying data-now.
	 * @param {number}  browserNow Current browser timestamp in seconds.
	 * @return {number} Seconds to add to the browser clock.
	 */
	function resolveSkew( node, browserNow ) {
		if ( null !== skewSecs ) {
			return skewSecs;
		}

		var serverNow = parseInt( node.getAttribute( 'data-now' ), 10 );
		if ( ! serverNow ) {
			skewSecs = 0;
			return skewSecs;
		}

		var diff = serverNow - browserNow;
		skewSecs = ( Math.abs( diff ) > SKEW_TOL ) ? diff : 0;

		return skewSecs;
	}

	/**
	 * Update a single timer element.
	 *
	 * @param {Element} node       Timer element.
	 * @param {number}  browserNow Current browser timestamp in seconds.
	 * @return {void}
	 */
	function updateNode( node, browserNow ) {
		if ( node.getAttribute( 'data-ended' ) === '1' ) {
			return;
		}

		var ends = parseInt( node.getAttribute( 'data-ends' ), 10 );
		if ( ! ends ) {
			return;
		}

		var remaining = ends - ( browserNow + resolveSkew( node, browserNow ) );

		if ( remaining <= 0 ) {
			node.setAttribute( 'data-ended', '1' );
			node.textContent = '00:00:00';

			var card = node.closest ? node.closest( '.zymarg-wcpg__card--flash' ) : null;
			if ( card ) {
				card.classList.add( 'is-ended' );
			}
			return;
		}

		node.textContent = format( remaining );
	}

	/**
	 * Start ticking, once.
	 *
	 * @return {void}
	 */
	function boot() {
		tick();

		if ( ! timer && document.querySelector( SELECTOR ) ) {
			timer = window.setInterval( tick, 1000 );
		}
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', boot );
	} else {
		boot();
	}

	// Cards arriving via load-more / infinite scroll need picking up too.
	if ( window.jQuery ) {
		window.jQuery( document ).on( 'zymarg_wcpg:products:appended', boot );
	}
}() );
