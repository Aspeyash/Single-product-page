<?php
/**
 * ZYMARG card template.
 *
 * Part of the ZYMARG Template Pack standalone plugin.
 * Registered with the Product Grid engine via:
 *   Template_Manager::register_card( 'zymarg', __FILE__ )
 *
 * Layout:
 *
 *  Image container (1:1 ratio)
 *    - Discount badge: top-left corner pill, "−N% off" format
 *    - Quick view:     top-right corner, no background, desktop hover-only
 *    - Wishlist:       bottom-right corner, no background, always visible
 *    - OOS badge:      bottom-left corner pill, "Out of stock" only
 *
 *  Content box (compact, white background)
 *    - Row 1: Product title (2-line clamp)
 *    - Row 2: Stars + numeric average · divider · Sold count
 *             Desktop/tablet: full star strip. Mobile: single star icon.
 *             Divider hidden when only one element present.
 *             Row omitted entirely when neither renders.
 *    - Row 3: Current price (bold) + old price (strikethrough subscript inline)
 *    - ATC:   Circular button, absolutely positioned between rows 3 and 4,
 *             right-aligned, overflows without pushing other rows.
 *    - Row 4: Dokan vendor avatar (20px circle) + store name
 *
 * Theme override: copy to theme/zymarg-wcpg/cards/zymarg/product-card.php
 *
 * @package Zymarg\TemplatePack
 *
 * @var \WC_Product $product
 * @var array       $settings
 * @var array       $config
 * @var int|string  $widget_id
 */

defined( 'ABSPATH' ) || exit;

if ( ! ( $product instanceof \WC_Product ) ) {
	return;
}

// ── Helper: truthy check for settings flags ───────────────────────────
$enabled = static function ( $value ): bool {
	return in_array( (string) $value, [ '1', 'yes', 'true' ], true );
};

// ── Visibility flags ──────────────────────────────────────────────────
$show_image     = ! isset( $settings['show_image'] )          || $enabled( $settings['show_image'] );
$show_discount  = ! isset( $settings['show_discount_badge'] ) || $enabled( $settings['show_discount_badge'] );
$show_stock     = ! isset( $settings['show_stock_badge'] )    || $enabled( $settings['show_stock_badge'] );
$show_wishlist  = ! isset( $settings['show_wishlist'] )       || $enabled( $settings['show_wishlist'] );
$show_quickview = ! isset( $settings['show_quickview'] )      || $enabled( $settings['show_quickview'] );
$show_atc       = ! isset( $settings['show_atc'] )            || $enabled( $settings['show_atc'] );
$show_title     = ! isset( $settings['show_title'] )          || $enabled( $settings['show_title'] );
$show_rating    = ! isset( $settings['show_rating'] )         || $enabled( $settings['show_rating'] );
$show_sold      = ! isset( $settings['show_sold_count'] )     || $enabled( $settings['show_sold_count'] );
$show_price     = ! isset( $settings['show_price'] )          || $enabled( $settings['show_price'] );
$show_vendor    = isset( $settings['show_vendor'] )           && $enabled( $settings['show_vendor'] );
$show_badge     = ! isset( $settings['show_status_badge'] )   || $enabled( $settings['show_status_badge'] );
$image_zoom     = ! isset( $settings['image_hover_zoom'] )    || $enabled( $settings['image_hover_zoom'] );
$image_full     = isset( $settings['image_full_resolution'] ) && $enabled( $settings['image_full_resolution'] );

// ── Product data ──────────────────────────────────────────────────────
$product_id  = (int) $product->get_id();
$permalink   = $product->get_permalink();
$title       = $product->get_name();
$is_in_stock = $product->is_in_stock();
$is_on_sale  = $product->is_on_sale();

// ── Rating / sold data ────────────────────────────────────────────────
$rating_count  = (int) $product->get_rating_count();
$rating_avg    = (float) $product->get_average_rating();
$total_sales   = (int) $product->get_total_sales();
$render_rating = $show_rating && $rating_count > 0 && $rating_avg > 0;
$render_sold   = $show_sold   && $total_sales > 0;

// -- Dynamic status badge: leading item of the meta row ------------------
// Always resolves to exactly one badge, which is what keeps the meta row at
// a constant height on products with no rating and no sales.
$status_badge = null;
if ( $show_badge && class_exists( 'Zymarg_Template_Pack_Badge_Resolver' ) ) {
	$status_badge = Zymarg_Template_Pack_Badge_Resolver::resolve( $product, $settings );
}

// ── Discount badge — "−N% off" format ────────────────────────────────
$discount_badge_html = '';
if ( $show_discount && $is_on_sale ) {
	$discount_badge_html = (string) \Zymarg\WCPG\Product_Data::get_discount_badge_html( $product, 'percent' );
	$discount_badge_html = str_replace(
		'zymarg-wcpg__badge--discount',
		'zymarg-wcpg__badge--discount zymarg-zc__badge--disc',
		$discount_badge_html
	);
	// Append " off" after the percentage figure.
	$discount_badge_html = preg_replace(
		'/(-\d+%)<\/span>/',
		'$1 ' . esc_html__( 'off', 'zymarg-template-pack' ) . '</span>',
		$discount_badge_html
	);
}

// ── OOS badge — shown only when product is out of stock ──────────────
$oos_badge_html = '';
if ( $show_stock && ! $is_in_stock ) {
	$oos_badge_html = '<span class="zymarg-zc__badge--oos">'
		. esc_html__( 'Out of stock', 'zymarg-template-pack' )
		. '</span>';
}

// ── Wishlist state ────────────────────────────────────────────────────
$is_wished = $show_wishlist
	? \Zymarg\WCPG\Wishlist\Wishlist_Store::has( $product_id )
	: false;

// ── Vendor data (Dokan) ───────────────────────────────────────────────
$vendor_html = '';
if ( $show_vendor
	&& class_exists( '\Zymarg\WCPG\Vendor\Vendor_Resolver' )
	&& \Zymarg\WCPG\Vendor\Vendor_Resolver::is_supported()
	&& function_exists( 'dokan_get_vendor' )
) {
	$vendor_id = \Zymarg\WCPG\Vendor\Vendor_Resolver::resolve( $product_id );
	if ( $vendor_id ) {
		$vendor = dokan_get_vendor( $vendor_id );
		if ( $vendor ) {
			// Store name resolution — same chain as the core vendor.php partial.
			if ( function_exists( 'zymarg_tb_get_vendor_display_name' ) ) {
				$store_name = zymarg_tb_get_vendor_display_name( $vendor, $vendor_id );
			} else {
				$store_name = method_exists( $vendor, 'get_shop_name' )
					? trim( (string) $vendor->get_shop_name() )
					: '';
				if ( '' === $store_name ) {
					$user = get_userdata( $vendor_id );
					if ( $user ) {
						foreach ( [
							$user->display_name,
							trim( $user->first_name . ' ' . $user->last_name ),
							$user->user_login,
						] as $candidate ) {
							$candidate = trim( (string) $candidate );
							if ( '' !== $candidate ) {
								$store_name = $candidate;
								break;
							}
						}
					}
				}
			}

			if ( '' !== $store_name ) {
				$store_url  = method_exists( $vendor, 'get_shop_url' )
					? (string) $vendor->get_shop_url()
					: '';
				$avatar_img = get_avatar(
					$vendor_id,
					40,
					'',
					esc_attr( $store_name ),
					[
						'class'   => 'zymarg-zc__vendor-avatar',
						'loading' => 'lazy',
					]
				);

				$vendor_inner = $avatar_img
					. '<span class="zymarg-zc__vendor-name">' . esc_html( $store_name ) . '</span>';

				if ( '' !== $store_url ) {
					$vendor_html = '<a class="zymarg-zc__vendor" href="' . esc_url( $store_url ) . '" '
						. 'aria-label="' . esc_attr( sprintf(
							/* translators: %s: vendor store name */
							__( 'Visit %s store', 'zymarg-template-pack' ),
							$store_name
						) ) . '">'
						. $vendor_inner . '</a>';
				} else {
					$vendor_html = '<div class="zymarg-zc__vendor">' . $vendor_inner . '</div>';
				}
			}
		}
	}
}

// ── Card classes ──────────────────────────────────────────────────────
$card_classes   = [ 'zymarg-wcpg__card', 'zymarg-wcpg__card--zymarg' ];
$card_classes[] = $is_in_stock ? '' : 'is-oos';
$card_classes[] = $is_on_sale  ? 'is-on-sale' : '';
$card_classes[] = 'zymarg-wcpg__card--' . esc_attr( $product->get_type() );
$card_classes   = array_filter( $card_classes );

/** Same filter as the classic template — extensions work across both templates. */
$card_classes = (array) apply_filters( 'zymarg_card_classes', $card_classes, $product, $settings );

// ── Extra HTML attributes (extension hook) ────────────────────────────
$extra_attrs     = (array) apply_filters( 'zymarg_card_attributes', [], $product, $settings );
$extra_attrs_html = '';
foreach ( $extra_attrs as $attr_name => $attr_value ) {
	$extra_attrs_html .= ' ' . esc_attr( $attr_name ) . '="' . esc_attr( $attr_value ) . '"';
}

// ── Algolia click-analytics ───────────────────────────────────────────
$algolia_query_id = (string) apply_filters( 'zymarg_wcpg_algolia_query_id', '' );
$algolia_position = 0;
if ( '' !== $algolia_query_id ) {
	static $zymarg_zc_algolia_pos = 0;
	$zymarg_zc_algolia_pos++;
	$algolia_position = $zymarg_zc_algolia_pos;
}

// ── ATC label ─────────────────────────────────────────────────────────
$is_simple_purchasable = $product->is_type( 'simple' ) && $product->is_purchasable() && $is_in_stock;
$atc_label             = $is_simple_purchasable
	? __( 'Add to cart', 'zymarg-template-pack' )
	: ( $product->is_type( 'variable' )
		? __( 'Select options', 'zymarg-template-pack' )
		: __( 'Read more', 'zymarg-template-pack' ) );

// ── Capture card HTML for zymarg_card_html filter ─────────────────────
ob_start();

/** @see 03-hooks.md — zymarg_before_card */
do_action( 'zymarg_before_card', $product, $settings );
?>

<div class="<?php echo esc_attr( implode( ' ', $card_classes ) ); ?>"
	data-product-id="<?php echo esc_attr( $product_id ); ?>"
	<?php if ( '' !== $algolia_query_id ) : ?>
		data-algolia-query-id="<?php echo esc_attr( $algolia_query_id ); ?>"
		data-algolia-position="<?php echo esc_attr( $algolia_position ); ?>"
	<?php endif; ?>
	<?php // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo $extra_attrs_html; ?>>

	<?php // ─── IMAGE CONTAINER ──────────────────────────────────────── ?>
	<?php do_action( 'zymarg_before_card_image', $product, $settings ); ?>

	<?php if ( $show_image ) : ?>
		<div class="zymarg-zc__image-wrap<?php echo $image_zoom ? ' has-zoom' : ''; ?>">

			<?php // Discount badge — top-left ?>
			<?php if ( '' !== $discount_badge_html ) : ?>
				<?php // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo $discount_badge_html; ?>
			<?php endif; ?>

			<?php // Quick view — top-right, desktop hover-only ?>
			<?php if ( $show_quickview ) : ?>
				<?php
				// Respect the Elementor Quick View visibility / display settings,
				// mirroring the engine's classic-card contract so the button honours
				// desktop/tablet/mobile + hover-only/always.
				$qv_visibility = isset( $settings['quickview_visibility'] ) ? (string) $settings['quickview_visibility'] : 'desktop';
				if ( ! in_array( $qv_visibility, array( 'desktop', 'tablet', 'mobile', 'desktop_tablet', 'tablet_mobile', 'all' ), true ) ) {
					$qv_visibility = 'desktop';
				}
				$qv_display = isset( $settings['quickview_display'] ) ? (string) $settings['quickview_display'] : 'hover_only';
				if ( ! in_array( $qv_display, array( 'hover_only', 'always' ), true ) ) {
					$qv_display = 'hover_only';
				}
				?>
				<button type="button"
					class="zymarg-zc__icon-btn zymarg-zc__icon-btn--qv"
					data-action="quickview"
					data-product-id="<?php echo esc_attr( $product_id ); ?>"
					data-qv-visibility="<?php echo esc_attr( $qv_visibility ); ?>"
					data-qv-display="<?php echo esc_attr( $qv_display ); ?>"
					aria-label="<?php esc_attr_e( 'Quick view', 'zymarg-template-pack' ); ?>">
					<?php \Zymarg\WCPG\Product_Data::render_icon( $settings['quickview_icon'] ?? null, 'far fa-eye' ); ?>
				</button>
			<?php endif; ?>

			<?php // Product image link ?>
			<a class="zymarg-zc__image-link"
				href="<?php echo esc_url( $permalink ); ?>"
				aria-label="<?php echo esc_attr( $title ); ?>">
				<?php
				$image_size = $image_full ? 'full' : 'woocommerce_thumbnail';
				$image_id   = (int) $product->get_image_id();
				if ( $image_id ) {
					echo wp_get_attachment_image(
						$image_id,
						$image_size,
						false,
						[
							'class'    => 'zymarg-zc__image',
							'loading'  => 'lazy',
							'decoding' => 'async',
							'alt'      => esc_attr( $title ),
						]
					);
				} else {
					echo wc_placeholder_img( $image_size, [ 'class' => 'zymarg-zc__image' ] );
				}
				?>
			</a>

			<?php // OOS badge — bottom-left ?>
			<?php if ( '' !== $oos_badge_html ) : ?>
				<?php // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo $oos_badge_html; ?>
			<?php endif; ?>

			<?php // Wishlist — bottom-right, always visible ?>
			<?php if ( $show_wishlist ) : ?>
				<button type="button"
					class="zymarg-zc__icon-btn zymarg-zc__icon-btn--wishlist"
					data-action="wishlist-toggle"
					data-product-id="<?php echo esc_attr( $product_id ); ?>"
					aria-label="<?php echo esc_attr( $is_wished
						? __( 'Remove from wishlist', 'zymarg-template-pack' )
						: __( 'Add to wishlist', 'zymarg-template-pack' )
					); ?>"
					aria-pressed="<?php echo $is_wished ? 'true' : 'false'; ?>">
					<span class="zymarg-wcpg__icon-idle">
						<?php \Zymarg\WCPG\Product_Data::render_icon( $settings['wishlist_icon'] ?? null, 'far fa-heart' ); ?>
					</span>
					<span class="zymarg-wcpg__icon-active">
						<?php \Zymarg\WCPG\Product_Data::render_icon( $settings['wishlist_icon_active'] ?? null, 'fas fa-heart' ); ?>
					</span>
				</button>
			<?php endif; ?>

		</div>
	<?php endif; ?>

	<?php do_action( 'zymarg_after_card_image', $product, $settings ); ?>

	<?php // ─── CONTENT BOX ──────────────────────────────────────────── ?>
	<div class="zymarg-zc__body">

		<?php // Row 1: Title ?>
		<?php do_action( 'zymarg_before_card_title', $product, $settings ); ?>
		<?php if ( $show_title ) : ?>
			<div class="zymarg-zc__row zymarg-zc__row--title">
				<a class="zymarg-zc__title-link" href="<?php echo esc_url( $permalink ); ?>">
					<h3 class="zymarg-zc__title"><?php echo esc_html( $title ); ?></h3>
				</a>
			</div>
		<?php endif; ?>
		<?php do_action( 'zymarg_after_card_title', $product, $settings ); ?>

		<?php // Row 2: Rating + divider + sold count
		// Desktop/tablet: full star strip. Mobile: single star + average.
		// Divider only when both elements present. Row omitted when neither renders.
		?>
		<?php if ( $status_badge || $render_rating || $render_sold ) : ?>
			<div class="zymarg-zc__row zymarg-zc__row--meta">

				<?php if ( $status_badge ) : ?>
					<span class="zymarg-zc__status-badge" data-badge="<?php echo esc_attr( $status_badge['key'] ); ?>" data-tier="<?php echo esc_attr( $status_badge['tier'] ); ?>"><?php echo esc_html( $status_badge['label'] ); ?></span>
				<?php endif; ?>

				<?php if ( $status_badge && ( $render_rating || $render_sold ) ) : ?>
					<span class="zymarg-zc__divider" aria-hidden="true"></span>
				<?php endif; ?>

				<?php if ( $render_rating ) :
					$fill_pct   = min( 100, max( 0, ( $rating_avg / 5 ) * 100 ) );
					$aria_label = sprintf(
						/* translators: %s: numeric rating average */
						__( 'Rated %s out of 5', 'zymarg-template-pack' ),
						number_format_i18n( $rating_avg, 1 )
					);
				?>
					<?php // Full star strip — desktop only (>1024px) ?>
					<div class="zymarg-zc__rating zymarg-zc__rating--full" aria-label="<?php echo esc_attr( $aria_label ); ?>">
						<span class="zymarg-zc__stars" aria-hidden="true">
							<span class="zymarg-zc__stars-fill" style="width:<?php echo esc_attr( $fill_pct ); ?>%;"></span>
						</span>
						<span class="zymarg-zc__rating-avg"><?php echo esc_html( number_format_i18n( $rating_avg, 1 ) ); ?></span>
					</div>
					<?php // Single star compact — tablet + mobile (<=1024px) ?>
					<div class="zymarg-zc__rating zymarg-zc__rating--compact" aria-label="<?php echo esc_attr( $aria_label ); ?>">
						<span class="zymarg-zc__star-icon" aria-hidden="true">&#9733;</span>
						<span class="zymarg-zc__rating-avg"><?php echo esc_html( number_format_i18n( $rating_avg, 1 ) ); ?></span>
					</div>
				<?php endif; ?>

				<?php if ( $render_rating && $render_sold ) : ?>
					<span class="zymarg-zc__divider" aria-hidden="true"></span>
				<?php endif; ?>

				<?php if ( $render_sold ) : ?>
					<span class="zymarg-zc__sold">
						<?php echo esc_html( sprintf(
							/* translators: %s: number of units sold */
							__( 'Sold %s', 'zymarg-template-pack' ),
							number_format_i18n( $total_sales )
						) ); ?>
					</span>
				<?php endif; ?>

			</div>
		<?php endif; ?>

		<?php // Row 3: Price ?>
		<?php do_action( 'zymarg_before_card_price', $product, $settings ); ?>
		<?php if ( $show_price ) : ?>
			<div class="zymarg-zc__row zymarg-zc__row--price">
				<?php \Zymarg\WCPG\Product_Data::render_price( $product ); ?>
			</div>
		<?php endif; ?>
		<?php do_action( 'zymarg_after_card_price', $product, $settings ); ?>

		<?php // ATC button — absolutely positioned between rows 3 and 4 ?>
		<?php if ( $show_atc ) : ?>
			<?php do_action( 'zymarg_before_add_to_cart', $product, $settings ); ?>
			<div class="zymarg-zc__atc-anchor">
				<a class="zymarg-zc__atc-btn"
					href="<?php echo esc_url( $permalink ); ?>"
					data-action="add-to-cart"
					data-product-id="<?php echo esc_attr( $product_id ); ?>"
					data-product-type="<?php echo esc_attr( $product->get_type() ); ?>"
					aria-label="<?php echo esc_attr( $atc_label ); ?>">
					<?php \Zymarg\WCPG\Product_Data::render_icon( $settings['atc_icon'] ?? null, 'fas fa-plus' ); ?>
				</a>
			</div>
			<?php do_action( 'zymarg_after_add_to_cart', $product, $settings ); ?>
		<?php endif; ?>

		<?php // Row 4: Vendor logo + name ?>
		<?php if ( $show_vendor && '' !== $vendor_html ) : ?>
			<div class="zymarg-zc__row zymarg-zc__row--vendor">
				<?php // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo $vendor_html; ?>
			</div>
		<?php endif; ?>

	</div>

</div>

<?php
do_action( 'zymarg_after_card', $product, $settings );

$_zymarg_card_html = ob_get_clean();

// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
echo apply_filters( 'zymarg_card_html', $_zymarg_card_html, $product, $settings );
?>
