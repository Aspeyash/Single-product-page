# Product Card Override — how the ZYMARG card becomes the site-wide default

**Applies to:** ZYMARG Template Pack 1.7.4+, ZYMARG OS theme 5.20.7+, ZYMARG WC Product Grid 2.17.4
**Audience:** developers maintaining any of the three
**Status:** workaround. Section 10 describes how to delete it.

---

## 1. The problem in one paragraph

The Product Grid engine picks a card from its **card registry** (where this pack
registers `zymarg` and `flash`) **only inside `Render_Engine::render()`**.
Elementor widgets and `[zymarg_products]` go through `Render_Engine`, so they
honour the registry. Almost nothing else does. The wishlist shortcode, the
recently-viewed shortcode and the ZYMARG OS theme's own
`zymarg_os_render_product_card()` each ask the engine's `Template_Loader` for
the hard-coded path **`grid/product-card.php`** and render it directly. No
registry lookup happens, so the branded card never appears — and no error is
raised, because from the engine's point of view nothing went wrong.

> The two account shortcodes never pass a `$config` at all, so there is no
> "card" key anywhere in their render path to influence.

## 2. What does NOT fix this

All of these were tried and shipped before the real cause was found. None work:

| Attempt | Why it fails |
| --- | --- |
| `card_template="zymarg"` on the shortcodes | The shortcodes' `shortcode_atts()` whitelist has no such attribute, so it is silently dropped. |
| `zymarg_wcpg_wishlist_card_settings` / `..._recently_viewed_card_settings` filters | They feed **display toggles** (show price, show badge…) into an already hard-coded template path. They cannot change the path. |
| `zymarg_layout_template`, `zymarg_product_grid_config`, `zymarg_card_classes` | All `Render_Engine`-only. These consumers never reach `Render_Engine`. |
| Registering the card again, or earlier | The registry is not consulted on this path at all. |

## 3. What actually works — a theme-side router

`Template_Loader::locate()` checks the active theme **before** the plugin:

```
locate_template( array( 'zymarg-wcpg/' . $relative ) )   // theme wins
ZYMARG_WCPG_DIR . 'templates/' . $relative               // plugin fallback
```

So the theme ships:

```
wp-content/themes/zymarg-os/zymarg-wcpg/grid/product-card.php
```

This file is **not a copy of a card**. It is a thin router:

- branded card ON → `include` this pack's `templates/product-card.php`
- branded card OFF → `include` the engine's `templates/grid/product-card.php`

Because it routes instead of duplicating, **updating this pack updates the card
everywhere with no re-sync step**. (Theme 5.20.1–5.20.6 used a byte-identical
copy here and required a manual `diff`/`cp` after every pack release; 5.20.7
removed that burden. If you are on an older theme, upgrade rather than
re-syncing.)

The including scope provides `$product`, `$settings` and `$widget_id`; a plain
`include` inherits them, so the target template receives them unchanged.

## 4. Assets — the trap that costs the most time

None of these consumers run `Render_Engine::render()`, so the engine's
`Asset_Manager::enqueue_for_render()` never fires and **the card's CSS/JS are
never enqueued**. Every rule in this pack's `templates/style.css` is scoped to
`.zymarg-wcpg__card--zymarg`, so the symptom is precise and misleading: the
right markup, completely unstyled. It looks like the override failed when it
actually succeeded.

The theme fixes this in `inc/product-card-delegate.php`:

```php
$assets = \Zymarg\WCPG\Templates\Template_Manager::get_card_assets( 'zymarg' );
// -> array( 'css' => array( 'path', 'url', 'version' ), 'js' => array( ... ) )
```

enqueued under the handle `zymarg-os-branded-card` on `wp_enqueue_scripts`
(priority 20). Paths are read from the engine, never hard-coded.

**Do not scope this with `is_wc_endpoint_url()`.** ZYMARG OS registers its
account tabs with `add_rewrite_endpoint()` and WordPress's own `query_vars`
filter, not WooCommerce's `woocommerce_get_query_vars`, so WooCommerce does not
recognise any of them and the check is **always false**:

```
wishlist  recently-viewed  notifications  reviews
coupons   returns          support        security
```

This exact mistake shipped as theme 5.20.3 and produced an unstyled card.

## 5. Where the card now renders

| Surface | Path | Branded? |
| --- | --- | --- |
| My Account → Wishlist | `[zymarg_wcpg_wishlist]` | via override |
| My Account → Recently Viewed | `[zymarg_wcpg_recently_viewed]` | via override |
| Search results | `search.php` → theme delegate | via override |
| Theme archives | `archive.php` → theme delegate | via override |
| Related products | `inc/woocommerce.php` → theme delegate | via override |
| Upsells | `inc/woocommerce.php` → theme delegate | via override |
| Shop, product category/tag, `[products]` | `woocommerce/content-product.php` | via loop override |
| Elementor widgets, `[zymarg_products]` | `Render_Engine` | via the card registry (unaffected) |

The first six come free with the override, because they all resolve
`grid/product-card.php`. The shop loop needed one extra file — see section 6.

## 6. The WooCommerce loop override

`wp-content/themes/zymarg-os/woocommerce/content-product.php` replaces
WooCommerce's loop item with the branded card inside WooCommerce's own
`<li class="product …">` wrapper (kept deliberately — WooCommerce's column CSS
and a lot of third-party CSS hook onto those classes).

**Trade-off, by design:** while it is active the
`woocommerce_before_shop_loop_item*` / `woocommerce_after_shop_loop_item*` hook
stack does **not** run. The branded card draws its own image, title, price,
rating, wishlist, quick view and add-to-cart, so plugins injecting markup into
those hooks render nothing on the shop loop. The shop-loop toggle exists
precisely to hand the loop back to WooCommerce when that matters; in the OFF
state the file includes WooCommerce's original template unchanged.

The theme's own quick-view button is already removed when the grid plugin is
active (`inc/woocommerce.php`), so it is not affected.

## 7. The admin toggle

**ZYMARG OS → Product Card** (`inc/admin-product-card.php`, capability
`manage_options`, option `zymarg_os_product_card`):

| Setting | Key | Default | Effect |
| --- | --- | --- | --- |
| Branded card | `enabled` | on | Branded card on every surface in section 5. Off → engine default card. |
| Shop & category loops | `shop_loop` | on | Adds the WooCommerce loop. Requires `enabled`. |

The screen also renders a status readout (engine active, pack card found,
override present, stylesheet located, badge resolver available), a
surface-by-surface table and the trade-offs above.

Programmatic control:

```php
add_filter( 'zymarg_os_use_branded_card',           '__return_false' );
add_filter( 'zymarg_os_branded_card_in_shop_loop',  '__return_false' );
add_filter( 'zymarg_os_branded_card_path', function ( $path ) { return $path; } );
```

Use `zymarg_os_branded_card_path` if this plugin's folder is ever renamed — the
theme resolves it as `WP_PLUGIN_DIR . '/zymarg-template-pack/templates/product-card.php'`
because this pack defines no path constant.

## 8. Dependencies and failure modes

Everything the card touches is guarded, so nothing here can fatal:

| Dependency | Guard | Missing → |
| --- | --- | --- |
| `WC_Product` instance | `instanceof` | Card renders nothing |
| `Zymarg_Template_Pack_Badge_Resolver` | `class_exists` | No status badges |
| `\Zymarg\WCPG\Vendor\Vendor_Resolver` | `class_exists` | No vendor row |
| `dokan_get_vendor()` | `function_exists` | No vendor row |
| `zymarg_tb_get_vendor_display_name()` | `function_exists` | Falls back to the store name |
| Font Awesome | none | Icon-less buttons (see below) |

**Silent failure to know about:** deactivate this pack and every surface quietly
falls back to the engine's default card. No warning, no error — just a
different card. The status table on the admin screen is there to make that
visible in one glance.

**Known gap:** the card's wishlist / quick-view / cart icons are Font Awesome
classes (`far fa-eye`, `far fa-heart`, `fas fa-heart`, `fas fa-plus`). Nothing
in this pack loads Font Awesome. If a surface shows the card without icons,
that is the cause.

**Known gap:** the theme delegate and the WooCommerce loop do not emit the
pack's grid wrapper (`.zymarg-wcpg--card-zymarg`) or its
`--columns-desktop/tablet/mobile` and `--grid-gap` custom properties. Card-level
styling is unaffected; grid-level rules keyed to that wrapper (for example the
load-more button rule in `templates/style.css`) will not apply.

## 9. Verifying

View source on any product listing:

1. `class="zymarg-wcpg__card zymarg-wcpg__card--zymarg"` → the override ran.
2. `<link id="zymarg-os-branded-card-css">` → the CSS loaded.
3. `<script id="zymarg-os-branded-card-js">` → the JS loaded.

Bisect rule: **1 without 2 is an asset problem (section 4), not an override
problem.** Do not start editing templates until you have checked 2.

## 10. The proper long-term fix

Route the remaining consumers through `Render_Engine` — the wishlist and
recently-viewed shortcodes, and ideally a public helper the theme can call
instead of `Template_Loader::get_template( 'grid/product-card.php' )`. Once
every consumer honours the card registry, **delete all of this**:

- `zymarg-os/zymarg-wcpg/grid/product-card.php`
- `zymarg-os/woocommerce/content-product.php` (if the loop is routed too)
- the branded-card block in `zymarg-os/inc/product-card-delegate.php`
- `zymarg-os/inc/admin-product-card.php`
- this document

Until then, keep them.

## 11. Blast radius when the engine changes

The override intercepts **every** caller of `grid/product-card.php`, site-wide —
not only the surfaces listed in section 5. If a future engine release adds new
callers of that path, they inherit the branded card automatically. Before
shipping an engine update, re-check who asks for it:

```bash
grep -rn "grid/product-card.php" wp-content/plugins/zymarg-wc-product-grid/
```

If the engine ever renames or stops using that path, the override goes inert and
every surface silently reverts to the engine's card. That is safe, but it is
silent — check the admin status table after any engine upgrade.

## 12. File map

**This plugin**
```
templates/product-card.php   the branded card the theme routes to
templates/style.css          all rules scoped to .zymarg-wcpg__card--zymarg
templates/script.js          card interactions
includes/class-badge-resolver.php
PRODUCT-CARD-OVERRIDE.md     this file
```

**ZYMARG OS theme**
```
zymarg-wcpg/grid/product-card.php   the router
woocommerce/content-product.php     WooCommerce loop override
inc/product-card-delegate.php       settings, asset loading, card helpers
inc/admin-product-card.php          ZYMARG OS -> Product Card screen
inc/account-sections.php            the two account tabs
```

## 13. History

| Version | Outcome |
| --- | --- |
| Theme 5.20.1 | `card_template` attribute — no effect (dropped by `shortcode_atts()`) |
| Theme 5.20.2 | card-settings filters — no effect (display toggles only) |
| Theme 5.20.3 | Override added; card changed but rendered unstyled (`is_wc_endpoint_url()` trap) |
| Theme 5.20.4 | Asset loading fixed — **working** |
| Theme 5.20.5 | Documentation added (in the theme) |
| Theme 5.20.6 / Pack 1.7.3 | Documentation moved into this plugin |
| Theme 5.20.7 / Pack 1.7.4 | Copy replaced by a router; shop loop covered; admin toggle + status panel; assets loaded site-wide |

## 14. Before you ship a change here

- [ ] Card renders on: shop, a category, search, an archive, a single product's related/upsells, both account tabs.
- [ ] The branded stylesheet is present on each of those pages (section 9, step 2).
- [ ] Both toggles off → the engine's default card returns and the WooCommerce loop hooks fire again.
- [ ] The pack deactivated → no fatals, engine card renders, admin status table flags it.
- [ ] Bump the pack version (`zymarg-template-pack.php`) and `CHANGELOG.md`, or the theme version (`style.css`) and `readme.txt`.
- [ ] Update section 13.
