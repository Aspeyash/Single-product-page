# Changelog — ZYMARG Template Pack

All notable changes to the ZYMARG Template Pack are documented here. The pack
registers the ZYMARG branded card template for the ZYMARG WC Product Grid engine.

## [1.7.6] - 2026-08-16

### Changed

- **Requires ZYMARG WC Product Grid 2.17.5+.** The engine removed bullets,
  fraction, and progress-bar pagination in that release in favour of a
  single "X more" chip. Both pack cards' slider default has been updated
  from `progress` to `chip` to match -- on an older engine that value is
  invalid and pagination is hidden entirely rather than broken, since the
  removed types no longer exist for it to fall back to.
- Classic ZYMARG card (`templates/style.css`): the progress-bar brand
  tint is replaced with a chip brand tint. Light mode needs no override --
  the engine's default chip is already brand purple -- dark mode lightens
  it to the pack's light-pink accent.
- Flash card (`templates/flash/style.css`): the progress-bar's animated
  primary → accent gradient now paints the chip's background instead of a
  bar fill. Same gradient, same flow animation, same brand identity.

## [1.7.5] - 2026-08-15

### Fixed

- Both card templates hard-coded Font Awesome `<i class="fa...">` tags for the
  Quick View eye, the wishlist heart (idle and active) and, on the ZYMARG card,
  the add-to-cart plus. Nothing in the pack or the engine enqueues Font Awesome
  -- those tags only rendered because Elementor happened to load it. On a theme
  without it the buttons were blank boxes. All seven now go through
  `Product_Data::render_icon()`, which prefers an Elementor icon value, falls
  back to the engine's inline SVG, and only then emits the icon-font tag.

### Notes

- Requires ZYMARG WC Product Grid 2.7.0+ for the inline SVG
  fallback. Earlier engines emit the icon-font tag, matching old behaviour.

## [1.7.4] - 2026-08-15

### Changed
- `PRODUCT-CARD-OVERRIDE.md` rewritten for the theme-wide rollout: the theme override is now a thin router that includes this plugin's `templates/product-card.php` instead of holding a byte-identical copy of it, so the copy/re-sync step is gone and pack updates reach every surface immediately.
- Documented the new ZYMARG OS -> Product Card admin panel (branded card on/off, shop-loop sub-toggle, status readout) and the `zymarg_os_use_branded_card`, `zymarg_os_branded_card_in_shop_loop` and `zymarg_os_branded_card_path` filters.
- Documented the widened blast radius: the card now also renders on the shop page, product category/tag archives, search, theme archives, related products and upsells — not just the two account tabs.

## [1.7.3] - 2026-08-15

### Added

- `PRODUCT-CARD-OVERRIDE.md`: a developer guide to how this pack's branded card
  reaches the My Account Wishlist and Recently Viewed tabs in ZYMARG OS. Those
  two tabs are the one place the engine does not apply the registered card
  automatically -- both shortcodes call `Template_Loader::get_template(
  'grid/product-card.php' )` directly and bypass `Render_Engine`, so neither the
  card registry nor automatic card-asset loading is involved. The guide records
  the three approaches that look correct but silently do nothing (the
  `card_template` shortcode attribute, the `*_card_settings` filters, editing the
  engine's own template), why `is_wc_endpoint_url()` must never be used to scope
  anything on the theme's custom account endpoints, the distinction between the
  `grid/product-card.php` and `cards/zymarg/product-card.php` override paths,
  and -- most importantly -- that the theme keeps a byte-identical copy of
  `templates/product-card.php` that must be re-synced whenever the card changes
  here.
- Documentation only. No change to card markup, styles, defaults or behaviour.

## [1.7.2] - 2026-08-06

### Changed

- The flash card now shares the ZYMARG card's slider defaults: progress-bar
  pagination and no navigation arrows. Previously both defaults sat behind an
  `'zymarg' === $template` check, so flash sliders inherited the engine's
  bullets + arrows and looked nothing like the rest of the pack. Explicit intent
  still wins -- setting `slider_pagination_type` or `slider_arrows` on the
  shortcode or in Elementor overrides the default as before.
- The flash progress bar is styled from the card's own scarcity bar: 4px tall,
  warm translucent track, primary -> accent gradient with the pack's flow
  animation, and a dark-mode variant. Requires engine 2.10.3+, which emits
  `data-card-template` on the slider wrapper; on older engines the neutral
  engine bar is used instead.
- Tightened the vertical space around the flash card's "Ends in" row.

### Notes

- Slider looping is untouched, and always has been: the pack has never set
  `loop`, `free_scroll` or `mousewheel`. The engine defaults `loop` to true but
  forces it off whenever free-scroll is active, which is its own default, so
  pack sliders do not loop.

## [1.7.1] - 2026-08-06

### Fixed

- Flash Sales countdown was frozen: it rendered the correct remaining time on
  load and then never advanced. `script.js` recomputed the clock skew on every
  tick, which algebraically cancelled the browser clock out of the calculation:
  `skew = serverNow - browserNow`, so
  `remaining = ends - (browserNow + skew)` reduces to `ends - serverNow`, a
  constant. The interval fired every second and recomputed the same value. Skew
  is now resolved once and cached, which is what the file's own docblock always
  described. Differences under 60s are treated as cache age and ignored, and
  larger ones as a genuinely wrong client clock -- the same rule and tolerance
  the engine's own countdown renderer uses, so both timers agree on a page that
  shows both.
- Because `remaining` could never decrease, the `remaining <= 0` branch was
  unreachable: an expired sale kept displaying its last positive value and never
  received the `is-ended` class until the page was reloaded. Both now work.

---

## [1.7.0] - 2026-08-05

### Added

- Two filters on the Flash Sales card, so a plugin that runs its own flash-sale feature on its own meta can supply the window the card renders. Both are additive: with nothing hooked, every value is identical to 1.6.4.
  - `zymarg_pack_flash_end_ts` — the timestamp the countdown counts down to. `Source_Flash_Deals::end_ts_for()` resolves this through WooCommerce's on-sale state and sale-to date, so it returns 0 for a flash sale held outside those fields, and the countdown does not render.
  - `zymarg_pack_flash_window_start` — the start of the window the scarcity bar measures "sold" against.

### Why the second filter matters more than it looks

`Flash_Sales_Counter::window_start_for()` reads WooCommerce's sale-from date and, when there isn't one, **falls back to the product's created date**. A product whose sale window lives outside WooCommerce therefore had its entire lifetime of sales counted as sold *within the current sale*: an older product would open its flash sale with the bar already near full. That is a fabricated figure, which is the thing this card was built to avoid — 1.6.0 states the bar is genuinely empty on day one. The filter lets the owner of the window state where it actually begins, and returning 0 leaves the bar empty rather than wrong.

### Notes

- Neither filter touches pricing. Nothing here reads or writes `_sale_price`, `woocommerce_product_get_sale_price` or `woocommerce_product_is_on_sale`, so a consumer using these filters does not push its products into WooCommerce's global on-sale lists.
- Returning 0 from either filter is a supported answer meaning "unknown": the countdown hides and the bar stays empty. No element falls back to an invented value.
- No visual change. The alignment work in 1.6.1–1.6.4 is untouched; this release only adds the two hooks and does not alter the card's markup, CSS or JS.

## [1.6.4] - 2026-08-05

### Fixed

- **ZYMARG card: Add to cart button no longer disappears when `show_vendor` is
  off.** The button was absolutely positioned inside a zero-height anchor that
  sat between the price row and the vendor row, centred on that boundary with
  `translateY(-50%)`. With the vendor row hidden the anchor became the last
  child of the card body, so the lower half of the button extended past the
  card's bottom edge and `.zymarg-wcpg__card--zymarg { overflow: hidden }`
  clipped it. Because grid cards stretch to equal height, the amount of slack
  below the anchor varied per card, which is why the button vanished on some
  cards and survived on others.
- **Long vendor store names no longer run underneath the button.** Nothing
  reserved horizontal space on the right, so `text-overflow: ellipsis` on
  `.zymarg-zc__vendor-name` truncated at the row's full width rather than at
  the button's edge. This affected the previous layout too; it was not
  introduced by the repositioning.

### Changed

- The Add to cart button is now pinned to the bottom-right corner of
  `.zymarg-zc__body` (`right: 10px; bottom: 10px`, and `8px` at ≤767px to match
  the mobile body padding) instead of tracking a row boundary. It is now
  independent of which rows render — vendor on or off, countdown on or off.
- `.zymarg-zc__atc-anchor` is now `position: static` so the body remains the
  button's containing block. The wrapper element is retained so card markup is
  unchanged and existing row spacing is preserved.
- `.zymarg-zc__row--price` and `.zymarg-zc__row--vendor` each reserve `34px` of
  right padding for the button.
- Hover transform simplified from `translateY(-50%) scale(1.1)` to `scale(1.1)`.
- Visible side effect: because the button is anchored to the bottom of the card
  body and grid cards stretch to equal height, buttons now align across a grid
  row instead of sitting at each card's own price boundary. With the vendor row
  showing, the button's resting position moves down by roughly 3px.

## [1.6.3] - 2026-08-04

### Fixed

- **Add to cart button is now centred on the scarcity bar track.** v1.6.2
  removed the mockup's `translateY(-4.5px)` nudge, which centred the button
  against the whole scarcity block — the 4px track *plus* the
  "N Sold / N Left" label line beneath it — so it sat level with the labels
  instead of the bar. The button is now anchored to the top of the block
  (`align-self: flex-start`) and shifted up by half its own height
  (`translateY(-12px)`), so the bar runs through its centre. Anchoring to the
  top rather than re-tuning the centre nudge means the alignment depends only
  on the 4px track and will not drift if the label type size changes.

## [1.6.2] - 2026-08-04

Second alignment pass on the Flash Sales card, from side-by-side review against
the ZYMARG card.

### Fixed

- **Quick view and wishlist glyphs now match the ZYMARG card.** The flash card
  drew its own inline SVG paths at a fixed 15px; ZYMARG renders the Font Awesome
  tags `far fa-eye`, `far fa-heart` and `fas fa-heart` at the inherited size.
  Different artwork at a different size, so the two templates never matched even
  after v1.6.1 aligned the button chrome. The flash card now emits the same tags
  and the stylesheet no longer forces a glyph size.
- **Add to cart button sits centred on the scarcity bar.** A leftover
  `translateY(-4.5px)` from the standalone mockup was lifting it above centre.

### Changed

- **Desktop rating now shows the five-star bar plus the numeric average**, as on
  the ZYMARG card. The flash card only ever emitted the compact single-star
  form. Both forms are now rendered and swapped at the same 1024px breakpoint
  ZYMARG uses, so tablet and mobile are unchanged.

## [1.6.1] - 2026-08-04

Brings the Flash Sales card into line with the ZYMARG card. The mockup was
designed as a single standalone 220px card; several of its choices only worked
in isolation and looked wrong once the card sat in a real grid beside ZYMARG
cards. Everything below is an alignment change, not a redesign — the gradient
border, glow, bolt badge, scarcity bar and shimmer timer are untouched.

### Fixed

- **Card gaps on desktop and tablet.** The card carried `max-width: 220px` from
  the mockup. In any column wider than 220px the card stopped short and left
  dead space inside the grid cell, which read as an oversized gap. Mobile looked
  correct only because phone columns are narrower than 220px, so the cap never
  bound. The cap is removed; the card now fills its column like the ZYMARG card.
- **Flash grids now use the same 8px gap as ZYMARG grids.** `apply_defaults()`
  returned early for every template except `zymarg`, so flash grids silently
  fell through to the engine's 6px global default.
- **The WooCommerce "View cart" link no longer escapes the card.** After a
  successful add-to-cart, WooCommerce injects an `.added_to_cart` anchor beside
  the button. The ZYMARG card has hidden it since v1.2.0; the flash card had no
  such rule, so the link rendered unstyled beside a 28px icon button and
  overlapped the neighbouring card. Cart fragments and the header cart counter
  are unaffected.
- **Duplicate countdowns on flash cards.** The engine's countdown renderer
  auto-enables for the `flash_deals` source, so a flash card showed the engine's
  adaptive countdown *and* its own `HH:MM:SS` footer timer. The countdown
  suppression that already existed for the ZYMARG card now covers the flash card
  too. `show_countdown="yes"` still forces it back on.

### Changed

- **Quick view icon** matches ZYMARG: 30×30 button, 15px glyph, transparent
  background with a drop-shadow instead of a blurred dark chip, positioned 8px
  from the edges, hover scales to 1.15 and tints to `--zc-primary-light`.
- **Quick view now honours the widget settings.** The card renders
  `data-qv-visibility` and `data-qv-display`, and the stylesheet carries the same
  responsive contract as the ZYMARG card. Previously the button was hard-coded
  always-visible and `display: none` below 1024px, so the Quick View visibility
  and hover-only settings had no effect on flash cards.
- **Wishlist icon** matches ZYMARG, including the active heart colour, which was
  `#ff4d6d` red and is now `--zc-primary-light`.
- **Type scale matches ZYMARG throughout**: title 13px/500, price 14px, old
  price 11px, meta row 11px, status badge 10px, rating average 11px, star 12px,
  sold count 11px, flash badge 10px. Body padding and row gap adopt the ZYMARG
  rhythm (10px / 5px) now that the text is the same size.
- **Responsive type scaling added**, mirroring the ZYMARG breakpoints: title and
  price step down at ≤1024px, and at ≤767px the body tightens to 8px padding /
  4px gap with a 9px status badge. The flash card previously had no type
  scaling at all.
- **Stock bar labels are 11px**, matching the sold count.
- **Countdown text is 11px** with a 10px bolt icon.

### Changed — sold count semantics

- **The meta-row sold count is now lifetime sales (`Sold 63`), identical to the
  ZYMARG card**, and is ON by default for flash grids. It previously reported
  sales inside the current sale window, which is always 0 on a newly flagged
  product, so the count never appeared.
- **The scarcity bar still reports window sales** (`0 Sold` / `423 Left`). The
  two numbers answer different questions and are deliberately different: the row
  is "how popular is this product", the bar is "how much of this sale is gone".
  Neither is fabricated.

## [1.6.0] - 2026-08-03

### Added

- **Flash Sales card template** (`card_template="flash"`), matching the approved mockup exactly. Registered alongside the ZYMARG card, so both ship in this one plugin.
  - Animated gradient border, ambient glow in dark mode, gradient-clipped price and countdown text.
  - Scarcity bar showing units sold **within the current sale window** and units remaining. It is never a fabricated figure: on day one the bar is genuinely empty.
  - Fixed `HH:MM:SS` countdown, ticked by the card's own script. The engine's adaptive format (days / hours / seconds) is deliberately not used here, because the approved design specifies a fixed-width readout.
  - Inline SVG bolt icons. The pack still enqueues no Font Awesome, and the engine's icon map has no `fa-bolt`.
  - Quick view is desktop-only, matching the mockup.
- The card lives in `templates/flash/` with its own `style.css` and `script.js`. The engine discovers template assets by looking beside the template's PHP file, so a second card needs a second directory.

### Changed

- `Zymarg_Template_Pack_Badge_Resolver::resolve()` accepts an optional list of badge keys to skip. Skipped rungs now fall through to the next genuine match instead of suppressing the badge entirely, which is what the existing `zymarg_pack_badge_result` filter does.
- The flash card skips the `limited_offer` badge. It would win on every flash product and merely restate the countdown sitting a few pixels below it.

### Requires

- ZYMARG WC Product Grid **2.10.0** or later, for the Flash Deals validator and the per-window sales counter.

## [1.5.0] — 2026-08-02
### Added
- **Dynamic status badge on the ZYMARG card.** Every product now shows exactly
  one rounded pill at the head of the rating/sold row. This is what fixes the
  inconsistent card height: a brand-new product with no reviews and no sales
  used to render an empty meta row that collapsed, so cards in the same grid
  did not line up. The badge always resolves, so the row always has content.
  New class `Zymarg_Template_Pack_Badge_Resolver`
  (`includes/class-badge-resolver.php`) walks a fixed ten-rung ladder and
  returns the first match:

  | # | Badge | Condition |
  |---|-------|-----------|
  | 1 | Limited Offer | on sale with a future end date |
  | 2 | Last Chance | managing stock, quantity at or below 3 |
  | 3 | Hot Pick | top 20 of the engine trending cache |
  | 4 | Best Seller | lifetime sales at or above 50 |
  | 5 | In Demand | anywhere in the trending cache |
  | 6 | Popular | 7-day engagement score at or above 10 |
  | 7 | Great Value | discount at or above 25% |
  | 8 | Fresh Pick | published within 7 days |
  | 9 | Latest Collection | published within 30 days |
  | 10 | Classic | age-only floor, always matches |

  `Classic` is deliberately age-only. Adding any activity requirement to the
  final rung would reopen the collapsing-row bug for an older product with no
  sales and no reviews.
- Badge markup is `<span class="zymarg-zc__status-badge" data-badge="..."
  data-tier="...">`, styled as a rounded pill and coloured by tier: price
  (purple), trending (amber), scarcity (red), freshness (green), lifecycle
  (muted). Dark-mode variants included for all five tiers. Type scales down at
  the mobile breakpoint.
- New card setting `show_status_badge`, defaulted ON for the ZYMARG template
  and overridable by any consumer.
- Three new filters: `zymarg_pack_badge_thresholds` (all ten cut-offs),
  `zymarg_pack_badge_labels` (all ten labels, translatable), and
  `zymarg_pack_badge_result` (return `null` to suppress the badge entirely).

### Changed
- **The engine countdown is now off by default on the ZYMARG card.** Engine
  2.9.0 auto-enables the flash-deals countdown for any card in a `flash_deals`
  grid, which duplicated the new "Limited Offer" badge. The pack now defaults
  `card.show_countdown` to `no` through its existing `apply_defaults()`
  mechanism. Explicit intent still wins: pass `show_countdown="yes"` and the
  countdown returns. A dedicated flash-deals template is the intended home for
  the live countdown. No engine change was required for this.
- **Compact rating on tablet.** The single-star-plus-average display was
  previously mobile-only; it now applies at 1024px and below, matching the
  engine's tablet breakpoint and the 4-column tablet layout. The two display
  rules moved from the 767px block up into the existing 1024px block. Tablet
  spacing, title size, price size, add-to-cart size and vendor size are
  unchanged: only the rating display switched.

### Performance
- Post meta for the entire result set is primed in a single query on
  `zymarg_product_grid_before_render`, before any card renders. Without this,
  the engagement lookup behind the `Popular` rung would issue one query per
  card.

### Note
- Rungs 3, 5 and 6 read data owned by the engine (`Trending_Calculator` and
  `Engagement_Store`). Every access is guarded with `class_exists` /
  `method_exists`, so if those internals ever move the ladder falls through to
  the price, freshness and lifecycle rungs instead of fataling.
- On a low-traffic store the trending and engagement rungs will rarely fire at
  first, so most products will land on Fresh Pick, Latest Collection or
  Classic. That is expected cold-start behaviour, not a fault.
- Variable products expose no parent regular price, so the `Great Value` rung
  reports 0% for them and they fall through to a later rung rather than
  showing a wrong discount figure.
- Engine unchanged: this release requires no update to ZYMARG WC Product Grid
  beyond 2.9.0.

## [1.4.5] — 2026-08-01
### Fixed
- Corrected a misleading comment in `templates/script.js`. It claimed the
  engine's own wishlist toast "is intentionally left alive as a fallback — it
  auto-expires in 2.4 s", while the code four lines below it unconditionally
  called `$( '.zymarg-wcpg__toast--success' ).remove()`. The behaviour was
  always correct (the handler returns early when `ZymargToast` is missing, so
  the engine toast really is the fallback) but the comment described the
  opposite of what the removal line does. Comment only — no behavioural change.
### Note
- The `removedFromWishlist`, `viewWishlist`, and `wishlistUrl` keys this pack
  has read since 1.4.4 are now actually shipped by the engine as of ZYMARG WC
  Product Grid **2.8.0**. Update both plugins and the "View wishlist" action
  link on the wishlist toast starts appearing on its own — no pack changes
  needed. The action link is shown only when a product is *added* (there is
  nothing useful to link to on removal).

## [1.4.4] — 2026-07-31
### Fixed
- Wishlist toast notifications now appear using the theme's `ZymargToast` system
  (`templates/script.js`). Previously the engine fired its own internal
  `.zymarg-wcpg__toast` on wishlist toggle but never triggered a WooCommerce body
  event, so the theme had no hook to show its branded notification. The fix listens
  for the `zymarg_wcpg:wishlist:changed` event broadcast by the engine after every
  successful heart toggle and routes it into `ZymargToast.success()` — matching the
  style and behaviour of the add-to-cart toast exactly. The engine's duplicate
  `.zymarg-wcpg__toast--success` is removed at the same time to prevent double
  notifications. Gracefully no-ops when `ZymargToast` is unavailable.
### Note
- If your ZYMARGWCPG PHP localisation includes `addedToWishlist`,
  `removedFromWishlist`, `viewWishlist`, and `wishlistUrl` keys those strings and
  the "View Wishlist" action link are picked up automatically. Without them the
  toast falls back to built-in English strings and no action link.

## [1.4.3] — 2026-07-30
### Changed
- ZYMARG grids now apply the 8px gap to BOTH grid and slider layouts via the
  engine config (layout.gap), replacing the previous grid-only CSS override.
  Requires engine v2.4.4+, where the slider spacing inherits layout.gap. The gap
  stays overridable per instance (shortcode `gap`, Elementor Grid gap / Slide spacing).
### Removed
- Grid-only CSS gap override (.zymarg-wcpg--card-zymarg .zymarg-wcpg__grid) from
  templates/style.css — superseded by the config-driven approach so the slider is covered too.

## [1.4.2] — 2026-07-30
### Added
- ZYMARG-branded grids used an 8px grid gap via a scoped CSS override (grid layout only). Superseded in 1.4.3.

## [1.4.1] — 2026-07-30
### Added
- Brand-purple progress-bar pagination for ZYMARG sliders with a dark-mode variant. Pairs with engine v2.4.1.

## [1.4.0] — 2026-07-30
### Added
- ZYMARG slider defaults: progress-bar pagination and navigation arrows off (both overridable per instance).
- Dark-mode colors for the grid heading title, subtitle, and "View All" link.

## [1.3.0] — 2026-07-29
### Changed
- ZYMARG card template refinements across the Elementor widget, the [zymarg_products] shortcode, and standalone-plugin consumers.

## [1.2.0] — 2026-07-29
### Changed
- ZYMARG card styling and layout refinements.

## [1.1.0] — 2026-07-29
### Changed
- ZYMARG card template updates following the engine template-pack fixes.

## [1.0.1]
- Initial ZYMARG branded card template.
