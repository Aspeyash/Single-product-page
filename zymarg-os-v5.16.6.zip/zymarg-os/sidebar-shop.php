<?php
/**
 * Shop sidebar (intentionally empty).
 *
 * ZYMARG OS does not use a WooCommerce shop sidebar — the theme owns the shop,
 * product and archive layouts. This empty template ensures get_sidebar('shop')
 * never loads a stray or legacy sidebar.php that would print default widgets.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

// Intentionally empty: no shop sidebar by design.
