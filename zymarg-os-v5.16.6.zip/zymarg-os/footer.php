<?php
/**
 * The footer.
 *
 * Minimal by design: no visual footer is rendered by the theme (the ZYMARG
 * plugin handles it). The zymarg_os_footer hook fires here (via wp_footer) so
 * the scroll-to-top button, cart drawer, quick-view modal and any injected
 * footer content can attach.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;
?>
	</div><!-- #page -->

<?php wp_footer(); ?>
</body>
</html>
