<?php
/**
 * Template Name: ZYMARG Canvas (Blank)
 *
 * A blank canvas with no theme container, padding or chrome — ideal for
 * Elementor / block layouts where you control the entire page. The background
 * orbs still render (via wp_body_open) unless disabled with the
 * `zymarg_os_show_orbs` filter.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

get_header();

zymarg_os_before_content();
?>
<div id="content" class="zymarg-canvas">
	<main id="main" class="zymarg-main">
		<?php
		while ( have_posts() ) {
			the_post();
			the_content();
		}
		?>
	</main>
</div>
<?php
zymarg_os_after_content();

get_footer();
