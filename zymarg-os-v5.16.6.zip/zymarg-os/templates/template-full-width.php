<?php
/**
 * Template Name: ZYMARG Full Width
 *
 * A full-width, edge-to-edge content area (no max-width container) but with the
 * theme's vertical rhythm preserved. Good for landing pages that still want the
 * theme typography defaults.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

get_header();

zymarg_os_before_content();
?>
<div id="content" class="zymarg-site-content zymarg-full-width">
	<?php zymarg_os_content_top(); ?>

	<main id="main" class="zymarg-main">
		<?php
		while ( have_posts() ) {
			the_post();
			the_content();
		}
		?>
	</main>

	<?php zymarg_os_content_bottom(); ?>
</div>
<?php
zymarg_os_after_content();

get_footer();
