<?php
/**
 * Archive template (categories, tags, author, date, custom taxonomies).
 *
 * Non-WooCommerce archives shown as an on-brand card grid. WooCommerce product
 * category/shop archives keep using WooCommerce's own (already-styled) grid.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

get_header();

zymarg_os_before_content();
?>
<div id="content" class="zymarg-container zymarg-site-content">
	<?php zymarg_os_content_top(); ?>

	<main id="main" class="zymarg-main zymarg-archive">
		<header class="zymarg-results__header">
			<?php the_archive_title( '<h1 class="zymarg-results__title">', '</h1>' ); ?>
			<?php
			$desc = get_the_archive_description();
			if ( $desc ) {
				echo '<div class="zymarg-results__desc zymarg-text-muted">' . wp_kses_post( $desc ) . '</div>';
			}
			?>
		</header>

		<?php if ( have_posts() ) : ?>
			<?php if ( function_exists( 'zymarg_os_sorting_bar' ) ) { zymarg_os_sorting_bar(); } ?>
			<?php
			// Separate product posts from non-product posts for grid delegation.
			$zymarg_archive_products     = array();
			$zymarg_archive_non_products = array();
			$zymarg_use_wcpg             = function_exists( 'zymarg_os_wcpg_active' ) && zymarg_os_wcpg_active();

			while ( have_posts() ) {
				the_post();
				$is_product = ( 'product' === get_post_type() ) && function_exists( 'wc_get_product' );

				if ( $is_product && $zymarg_use_wcpg ) {
					$wc_product = wc_get_product( get_the_ID() );
					if ( $wc_product ) {
						$zymarg_archive_products[] = $wc_product;
					}
				} else {
					$zymarg_archive_non_products[] = get_post();
				}
			}

			// Render product results via plugin grid wrapper.
			if ( ! empty( $zymarg_archive_products ) ) {
				zymarg_os_render_product_grid( $zymarg_archive_products );
			}

			// Render non-product results (or all results if plugin inactive).
			if ( ! empty( $zymarg_archive_non_products ) ) :
			?>
			<div class="zymarg-grid zymarg-grid--auto zymarg-results__grid">
				<?php
				foreach ( $zymarg_archive_non_products as $zymarg_post ) {
					setup_postdata( $GLOBALS['post'] = $zymarg_post ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
					?>
					<article <?php post_class( 'zymarg-card zymarg-result' ); ?>>
						<a class="zymarg-result__link" href="<?php the_permalink(); ?>">
							<?php if ( has_post_thumbnail() ) : ?>
								<span class="zymarg-result__media"><?php the_post_thumbnail( 'medium' ); ?></span>
							<?php endif; ?>
							<h2 class="zymarg-result__title"><?php the_title(); ?></h2>
						</a>
						<div class="zymarg-result__excerpt zymarg-text-muted"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 22 ) ); ?></div>
					</article>
					<?php
				}
				wp_reset_postdata();
				?>
			</div>
			<?php endif; ?>

			<?php
			the_posts_pagination(
				array(
					'mid_size'  => 1,
					'prev_text' => esc_html__( 'Previous', 'zymarg-os' ),
					'next_text' => esc_html__( 'Next', 'zymarg-os' ),
				)
			);
			?>
		<?php else : ?>
			<div class="zymarg-card"><p><?php esc_html_e( 'Nothing found in this archive.', 'zymarg-os' ); ?></p></div>
		<?php endif; ?>
	</main>

	<?php zymarg_os_content_bottom(); ?>
</div>
<?php
zymarg_os_after_content();

get_footer();
