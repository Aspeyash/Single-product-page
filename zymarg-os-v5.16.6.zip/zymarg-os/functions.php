<?php
/**
 * ZYMARG OS functions and definitions.
 *
 * Bootstraps the theme by defining constants and loading the modular
 * include files from /inc. Each feature lives in its own file and many of
 * them are gated behind the modular activation system (inc/modules.php) so
 * only the code you actually use is loaded.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Theme version — read DIRECTLY from style.css's "Version:" header at runtime,
 * so there is a single source of truth. Bump style.css and every consumer of
 * this constant (cache-busting, admin badges, helper docs) updates in lockstep.
 * Prevents the historical drift where style.css and a hardcoded constant fell
 * out of sync over multiple releases.
 */
if ( ! defined( 'ZYMARG_OS_VERSION' ) ) {
	$zymarg_os_header = get_file_data( __DIR__ . '/style.css', array( 'Version' => 'Version' ) );
	define( 'ZYMARG_OS_VERSION', ! empty( $zymarg_os_header['Version'] ) ? $zymarg_os_header['Version'] : '0.0.0' );
}

/** Absolute path to the theme directory, no trailing slash. */
if ( ! defined( 'ZYMARG_OS_DIR' ) ) {
	define( 'ZYMARG_OS_DIR', get_template_directory() );
}

/** URI to the theme directory, no trailing slash. */
if ( ! defined( 'ZYMARG_OS_URI' ) ) {
	define( 'ZYMARG_OS_URI', get_template_directory_uri() );
}

/**
 * Safely require a file from the theme's /inc directory.
 *
 * @param string $relative_path Path relative to the theme root, e.g. 'inc/setup.php'.
 * @return void
 */
function zymarg_os_require( $relative_path ) {
	$file = trailingslashit( ZYMARG_OS_DIR ) . ltrim( $relative_path, '/' );

	if ( is_readable( $file ) ) {
		require_once $file;
	}
}

/*
 * Core (always loaded) includes.
 * ------------------------------------------------------------------ */
zymarg_os_require( 'inc/modules.php' );     // Modular activation system (must load first).
zymarg_os_require( 'inc/setup.php' );       // Theme supports & registrations.
zymarg_os_require( 'inc/fonts.php' );       // Font engine: Google / self-host / custom uploads.
zymarg_os_require( 'inc/font-localizer.php' ); // Auto-download Google fonts to the server.
zymarg_os_require( 'inc/enqueue.php' );     // Styles, scripts & fonts.
zymarg_os_require( 'inc/hooks.php' );       // Custom layout action hooks.
zymarg_os_require( 'inc/customizer.php' );  // Typography / colour / spacing controls.
zymarg_os_require( 'inc/dynamic-css.php' ); // Turns Customizer values into CSS variables.
zymarg_os_require( 'inc/page-title.php' );  // Per-page / global page-title hiding.
zymarg_os_require( 'inc/sorting.php' );     // Sort dropdown for search/archive pages.
zymarg_os_require( 'inc/coming-soon.php' ); // Site Mode: Live / Coming Soon / Maintenance.
zymarg_os_require( 'inc/smart-ux.php' );      // Instant Load, Scroll Animations.
zymarg_os_require( 'inc/schema.php' );        // SEO structured data (defers to SEO plugins).
zymarg_os_require( 'inc/lazy-images.php' );   // Lazy Images module (toggle in Modules).

if ( zymarg_os_module_enabled( 'breadcrumbs' ) ) {
	zymarg_os_require( 'inc/breadcrumbs.php' ); // Breadcrumb trail + shortcode + schema.
}
zymarg_os_require( 'inc/discovery-spark.php' ); // ZYMARG Discovery Spark component + shortcode.
zymarg_os_require( 'inc/logo.php' );            // [zymarg_logo] site-logo shortcode.
zymarg_os_require( 'inc/block-patterns.php' );  // Gutenberg block patterns + block styles.
zymarg_os_require( 'inc/dark-mode.php' );       // Dark / light colour-scheme system.
zymarg_os_require( 'inc/toast.php' );           // Unified toast notifications (shared).

if ( is_admin() ) {
	zymarg_os_require( 'inc/updater.php' ); // Self-hosted theme update mechanism.
	zymarg_os_require( 'inc/admin-help.php' ); // ZYMARG OS Help guide (render).
	zymarg_os_require( 'inc/admin-dark.php' ); // Dark mode tokens inside wp-admin.
	zymarg_os_require( 'inc/admin-menu.php' ); // Dedicated ZYMARG OS sidebar menu.
	zymarg_os_require( 'inc/import.php' );     // Import menu: demo content + CSV product/category import.
	zymarg_os_require( 'inc/recommended-plugins.php' ); // "Finish setup" notice (ZYMARG Theme Builder + Elementor).
	zymarg_os_require( 'inc/admin-performance.php' );   // Performance report dashboard page.
}

/*
 * Optional modules.
 * Loaded only when enabled via zymarg_os_module_enabled(). Each module
 * defaults to enabled but can be toggled off from the Customizer
 * (Customize -> ZYMARG OS -> Modules) to keep the front end lean.
 * ------------------------------------------------------------------ */
if ( zymarg_os_module_enabled( 'mega_menu' ) ) {
	zymarg_os_require( 'inc/mega-menu.php' );
}

/*
 * Scroll to Top.
 * The file is always loaded so its Customizer + dynamic-CSS helper functions
 * exist even when the button is switched off; the button itself only renders
 * when the module is enabled (see zymarg_os_scrolltop_should_display()).
 * ------------------------------------------------------------------ */
zymarg_os_require( 'inc/scroll-to-top.php' );

/*
 * Account Icon.
 * Always loaded so its Customizer controls, dynamic-CSS helper and the
 * [zymarg_account_icon] shortcode exist even when header auto-injection is
 * switched off. The icon only renders in the header when enabled.
 * ------------------------------------------------------------------ */
zymarg_os_require( 'inc/account-icon.php' );

/*
 * Login experience + Session Control.
 * ------------------------------------------------------------------
 * These are now provided by the "ZYMARG Login & Security" plugin, which is
 * the single source of truth for login + session on this site. We ONLY load
 * the theme's built-in login + session code as a FALLBACK, when that plugin
 * is not active (detected via the ZLS_VERSION constant the plugin defines on
 * load — plugins load before the theme, so this check is reliable here).
 *
 *   Plugin ACTIVE   → none of these files are parsed. No redundant code and
 *                     no function-name collisions with the plugin. The plugin
 *                     renders the branded login card, popup, wp-login.php
 *                     branding, session lengths and the "Login" Customizer
 *                     section (identical setting keys — zero migration).
 *
 *   Plugin INACTIVE → the theme's own login experience takes over
 *                     automatically, and inc/login-fallback-notice.php emails
 *                     the site admin once to flag that the fallback is live.
 * ------------------------------------------------------------------ */
if ( ! defined( 'ZLS_VERSION' ) ) {
	zymarg_os_require( 'inc/customize-controls.php' ); // Custom Customizer controls (page checkboxes, page delays).
	zymarg_os_require( 'inc/login.php' );              // Branded login card, popup, wp-login.php branding, AJAX.
	zymarg_os_require( 'inc/session-control.php' );    // Master auth-cookie session-length override.
}

/*
 * Login fallback monitor.
 * Always loaded (tiny, uniquely-named functions — no collision with the
 * plugin). Emails the site admin once if the plugin that was previously
 * active disappears and the theme login fallback takes over.
 * ------------------------------------------------------------------ */
zymarg_os_require( 'inc/login-fallback-notice.php' );

if ( zymarg_os_module_enabled( 'white_label' ) && is_admin() ) {
	zymarg_os_require( 'inc/white-label.php' );
}

if ( zymarg_os_module_enabled( 'woocommerce' ) && class_exists( 'WooCommerce' ) ) {
	zymarg_os_require( 'inc/woocommerce.php' );
	zymarg_os_require( 'inc/product-card-delegate.php' ); // Delegate product cards to WCPG plugin.
	zymarg_os_require( 'inc/single-product.php' ); // Enhanced single-product page.
	zymarg_os_require( 'inc/account-dashboard.php' ); // My Account redesign (sidebar + sections).
	zymarg_os_require( 'inc/account-sections.php' );  // My Account section renderers.
	zymarg_os_require( 'inc/account-addresses.php' );  // Custom multi-address book (Bangladesh).
}

/* The wishlist module was removed in v5.7.6 — the My Account → Wishlist
 * tab is now pluggable (filter `zymarg_os_account_wishlist_content` + a
 * Customizer-set shortcode). See inc/account-sections.php for details. */

if ( zymarg_os_module_enabled( 'learndash' ) && defined( 'LEARNDASH_VERSION' ) ) {
	zymarg_os_require( 'inc/learndash.php' );
}

if ( zymarg_os_module_enabled( 'performance' ) ) {
	zymarg_os_require( 'inc/performance.php' );
}

if ( zymarg_os_module_enabled( 'svg_upload' ) ) {
	zymarg_os_require( 'inc/svg-support.php' ); // Secure, admin-only, sanitized SVG uploads.
}
