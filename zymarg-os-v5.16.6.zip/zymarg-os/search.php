<?php
/**
 * Search results template.
 *
 * A clean, on-brand results page: a heading with the query + result count, the
 * search form, and matches shown as a responsive card grid (with product price
 * on WooCommerce sites). Note: product-only searches (?s=…&post_type=product)
 * are rendered by WooCommerce's own product grid; this covers general searches.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

get_header();

zymarg_os_before_content();
?>
<div id="content" class="zymarg-container zymarg-site-content">
	<?php zymarg_os_content_top(); ?>

	<main id="main" class="zymarg-main zymarg-search-results">
		<header class="zymarg-results__header">
			<h1 class="zymarg-results__title">
				<?php
				/* translators: %s: search query. */
				printf( esc_html__( 'Search results for: %s', 'zymarg-os' ), '<span>' . esc_html( get_search_query() ) . '</span>' );
				?>
			</h1>
			<?php if ( have_posts() ) : ?>
				<p class="zymarg-results__count zymarg-text-muted">
					<?php
					global $wp_query;
					printf(
						/* translators: %d: number of results. */
						esc_html( _n( '%d result found', '%d results found', (int) $wp_query->found_posts, 'zymarg-os' ) ),
						(int) $wp_query->found_posts
					);
					?>
				</p>
			<?php endif; ?>
			<div class="zymarg-results__search"><?php get_search_form(); ?></div>
		</header>

		<?php if ( have_posts() ) : ?>
			<?php if ( function_exists( 'zymarg_os_sorting_bar' ) ) { zymarg_os_sorting_bar(); } ?>
			<?php
			// Separate product posts from non-product posts for grid delegation.
			$zymarg_search_products     = array();
			$zymarg_search_non_products = array();
			$zymarg_use_wcpg            = function_exists( 'zymarg_os_wcpg_active' ) && zymarg_os_wcpg_active();

			while ( have_posts() ) {
				the_post();
				$is_product = ( 'product' === get_post_type() ) && function_exists( 'wc_get_product' );

				if ( $is_product && $zymarg_use_wcpg ) {
					$wc_product = wc_get_product( get_the_ID() );
					if ( $wc_product ) {
						$zymarg_search_products[] = $wc_product;
					}
				} else {
					$zymarg_search_non_products[] = get_post();
				}
			}

			// Render product results via plugin grid wrapper.
			if ( ! empty( $zymarg_search_products ) ) {
				zymarg_os_render_product_grid( $zymarg_search_products );
			}

			// Render non-product results (or all results if plugin inactive).
			if ( ! empty( $zymarg_search_non_products ) ) :
			?>
			<div class="zymarg-grid zymarg-grid--auto zymarg-results__grid">
				<?php
				foreach ( $zymarg_search_non_products as $zymarg_post ) {
					setup_postdata( $GLOBALS['post'] = $zymarg_post ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
					$is_product = ( 'product' === get_post_type() ) && function_exists( 'wc_get_product' );
					?>
					<article <?php post_class( 'zymarg-card zymarg-result' ); ?>>
						<a class="zymarg-result__link" href="<?php the_permalink(); ?>">
							<?php if ( has_post_thumbnail() ) : ?>
								<span class="zymarg-result__media"><?php the_post_thumbnail( 'medium' ); ?></span>
							<?php endif; ?>
							<h2 class="zymarg-result__title"><?php the_title(); ?></h2>
						</a>
						<?php
						if ( $is_product ) {
							$product = wc_get_product( get_the_ID() );
							if ( $product ) {
								echo '<div class="price">' . wp_kses_post( $product->get_price_html() ) . '</div>';
							}
						}
						?>
						<div class="zymarg-result__excerpt zymarg-text-muted"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 22 ) ); ?></div>
					</article>
					<?php
				}
				wp_reset_postdata();
				?>
			</div>
			<?php endif; ?>

			<?php
			the_posts_pagination(
				array(
					'mid_size'  => 1,
					'prev_text' => esc_html__( 'Previous', 'zymarg-os' ),
					'next_text' => esc_html__( 'Next', 'zymarg-os' ),
				)
			);
			?>
		<?php else : ?>
			<div class="zymarg-card zymarg-results__none">
				<p><?php esc_html_e( 'Sorry, nothing matched your search. Try different keywords.', 'zymarg-os' ); ?></p>
			</div>
		<?php endif; ?>
	</main>

	<?php zymarg_os_content_bottom(); ?>
</div>
<?php
zymarg_os_after_content();

get_footer();
