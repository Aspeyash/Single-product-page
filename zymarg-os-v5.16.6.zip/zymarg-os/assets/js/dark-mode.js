/**
 * ZYMARG OS — Smart dark mode (Auto / Light / Dark).
 *
 * Loaded in "toggle" colour-scheme mode. The switch cycles through three
 * modes and remembers the choice in localStorage:
 *
 *   auto  → follow the operating-system preference (data-theme="auto")
 *   light → always light (data-theme="light")
 *   dark  → always dark  (data-theme="dark")
 *
 * The dark token overrides (tokens/dark.css) already react to the data-theme
 * value, including the prefers-color-scheme media query for "auto". No deps.
 */
( function () {
	'use strict';

	var STORAGE_KEY = 'zymarg-theme';
	var MODES = [ 'auto', 'light', 'dark' ];
	var root = document.documentElement;

	function systemPrefersDark() {
		return window.matchMedia && window.matchMedia( '(prefers-color-scheme: dark)' ).matches;
	}

	/** The site-configured default mode (set on <html> in toggle mode). */
	function defaultMode() {
		var d = root.getAttribute( 'data-theme-default' );
		return ( d === 'light' || d === 'dark' || d === 'auto' ) ? d : 'auto';
	}

	/** Read the saved mode, defaulting to the site's configured default. */
	function storedMode() {
		try {
			var s = localStorage.getItem( STORAGE_KEY );
			if ( s === 'auto' || s === 'light' || s === 'dark' ) {
				return s;
			}
		} catch ( e ) {}
		return defaultMode();
	}

	/** Resolve a mode to the concrete theme actually shown. */
	function resolve( mode ) {
		if ( mode === 'auto' ) {
			return systemPrefersDark() ? 'dark' : 'light';
		}
		return mode;
	}

	function labelFor( btn, mode ) {
		var map = {
			auto: btn.getAttribute( 'data-l-auto' ) || 'Theme: Auto',
			light: btn.getAttribute( 'data-l-light' ) || 'Theme: Light',
			dark: btn.getAttribute( 'data-l-dark' ) || 'Theme: Dark'
		};
		return map[ mode ] || map.auto;
	}

	/** Reflect the current mode on every toggle button. */
	function sync( mode ) {
		mode = mode || storedMode();
		var shown = resolve( mode );
		var buttons = document.querySelectorAll( '[data-zymarg-theme-toggle]' );
		Array.prototype.forEach.call( buttons, function ( btn ) {
			btn.setAttribute( 'data-mode', mode );
			btn.setAttribute( 'data-active', shown );
			btn.setAttribute( 'aria-label', labelFor( btn, mode ) );
			btn.setAttribute( 'title', labelFor( btn, mode ) );
			var sr = btn.querySelector( '[data-zymarg-theme-label]' );
			if ( sr ) { sr.textContent = labelFor( btn, mode ); }
		} );
		// Toggle-switch variant — binary (checked === dark).
		var switches = document.querySelectorAll( '[data-zymarg-theme-switch]' );
		var isDark = ( shown === 'dark' );
		Array.prototype.forEach.call( switches, function ( s ) {
			s.checked = isDark;
		} );
	}

	/** Apply a mode: set data-theme, persist, and re-sync the buttons. */
	function apply( mode ) {
		root.setAttribute( 'data-theme', mode );
		try {
			localStorage.setItem( STORAGE_KEY, mode );
		} catch ( e ) {}
		sync( mode );
	}

	function nextMode( mode ) {
		var i = MODES.indexOf( mode );
		return MODES[ ( i + 1 ) % MODES.length ];
	}

	function bind() {
		// Reflect the current mode on load without persisting the default
		// prematurely — only an explicit click saves the visitor's choice.
		var initial = storedMode();
		root.setAttribute( 'data-theme', initial );
		sync( initial );

		var buttons = document.querySelectorAll( '[data-zymarg-theme-toggle]' );
		Array.prototype.forEach.call( buttons, function ( btn ) {
			btn.addEventListener( 'click', function () {
				apply( nextMode( storedMode() ) );
			} );
		} );

		// Toggle-switch variant — binary on/off (checked = dark, unchecked = light).
		// Skips "auto" mode because a binary switch can't represent it; if the
		// visitor was previously on "auto", toggling commits them to an explicit
		// dark/light choice.
		var switches = document.querySelectorAll( '[data-zymarg-theme-switch]' );
		Array.prototype.forEach.call( switches, function ( s ) {
			s.addEventListener( 'change', function () {
				apply( s.checked ? 'dark' : 'light' );
			} );
		} );
	}

	if ( document.readyState !== 'loading' ) {
		bind();
	} else {
		document.addEventListener( 'DOMContentLoaded', bind );
	}

	// While on 'auto', repaint button state when the OS preference changes.
	if ( window.matchMedia ) {
		var mq = window.matchMedia( '(prefers-color-scheme: dark)' );
		var onChange = function () {
			if ( storedMode() === 'auto' ) {
				sync( 'auto' );
			}
		};
		if ( mq.addEventListener ) {
			mq.addEventListener( 'change', onChange );
		} else if ( mq.addListener ) {
			mq.addListener( onChange );
		}
	}
}() );
