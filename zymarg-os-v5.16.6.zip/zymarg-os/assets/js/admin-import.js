/**
 * ZYMARG OS — Admin: Import / Export screen enhancements.
 *
 * Progressive enhancement (forms still work without JS):
 *   - Drag-and-drop dropzones with an instant CSV preview (rows + columns).
 *   - Batched, AJAX-driven Products import with a live progress bar, running
 *     counts and a warnings report (e.g. products imported without an image).
 *     This drives WooCommerce's own importer in small chunks so big / variable
 *     catalogues import correctly and never time out.
 *   - "Working…" loading state for the other (direct) forms.
 *
 * No dependencies. Vanilla JS.
 */
(function () {
	'use strict';

	var CFG = window.ZymargImport || {};
	var I18N = CFG.i18n || {};

	function t(key, fallback) {
		return (I18N && I18N[key]) ? I18N[key] : fallback;
	}

	function escapeHtml(s) {
		return String(s).replace(/[&<>"']/g, function (m) {
			return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m];
		});
	}

	function humanSize(bytes) {
		if (!bytes && bytes !== 0) { return ''; }
		if (bytes < 1024) { return bytes + ' B'; }
		if (bytes < 1024 * 1024) { return (bytes / 1024).toFixed(1) + ' KB'; }
		return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
	}

	/* ---- CSV preview parser (header + row count) ---------------------- */
	function parseCsvPreview(text) {
		text = String(text).replace(/\r\n?/g, '\n').replace(/\n+$/, '');
		if (!text) { return { rows: 0, columns: [] }; }

		var lines = text.split('\n');
		var header = lines.length ? lines[0] : '';
		var columns = [];
		var cur = '';
		var inQuotes = false;
		for (var i = 0; i < header.length; i++) {
			var ch = header.charAt(i);
			if (ch === '"') {
				if (inQuotes && header.charAt(i + 1) === '"') { cur += '"'; i++; }
				else { inQuotes = !inQuotes; }
			} else if (ch === ',' && !inQuotes) {
				columns.push(cur.trim()); cur = '';
			} else { cur += ch; }
		}
		columns.push(cur.trim());

		var dataRows = 0;
		for (var j = 1; j < lines.length; j++) {
			if (lines[j].trim() !== '') { dataRows++; }
		}
		return { rows: dataRows, columns: columns.filter(function (c) { return c !== ''; }) };
	}

	function ensurePreviewEl(zone) {
		var el = zone.querySelector('.zymarg-import-file__preview');
		if (!el) {
			el = document.createElement('div');
			el.className = 'zymarg-import-file__preview';
			zone.appendChild(el);
		}
		return el;
	}

	function renderPreview(zone, file) {
		var preview = ensurePreviewEl(zone);
		if (!file) { preview.innerHTML = ''; preview.classList.remove('is-shown'); return; }
		preview.classList.add('is-shown');

		var name = file.name || '';
		if (!/\.csv$/i.test(name)) {
			preview.innerHTML =
				'<span class="zymarg-import-file__name">' + escapeHtml(name) + '</span>' +
				'<span class="zymarg-import-file__meta">' + escapeHtml(humanSize(file.size)) + '</span>';
			return;
		}

		var reader = new FileReader();
		reader.onload = function (e) {
			var info = parseCsvPreview(e.target.result);
			var cols = info.columns.slice(0, 12).map(function (c) {
				return '<span class="zymarg-import-chip-mini">' + escapeHtml(c) + '</span>';
			}).join('');
			var more = info.columns.length > 12 ? ' +' + (info.columns.length - 12) : '';
			preview.innerHTML =
				'<span class="zymarg-import-file__name">' + escapeHtml(name) + '</span>' +
				'<span class="zymarg-import-file__meta"><b>' + info.rows + '</b> ' + escapeHtml(t('rows', 'rows detected')) + ' • ' + escapeHtml(humanSize(file.size)) + '</span>' +
				'<span class="zymarg-import-file__cols"><em>' + escapeHtml(t('columns', 'Columns')) + ':</em> ' + cols + escapeHtml(more) + '</span>';
		};
		reader.onerror = function () {
			preview.innerHTML = '<span class="zymarg-import-file__name">' + escapeHtml(name) + '</span>';
		};
		reader.readAsText(file.slice(0, 512 * 1024));
	}

	function initDropzone(zone) {
		var input = zone.querySelector('input[type="file"]');
		if (!input) { return; }

		var hint = document.createElement('span');
		hint.className = 'zymarg-import-file__hint';
		hint.textContent = t('drop', 'Drop your CSV here, or click to choose');
		zone.insertBefore(hint, input.nextSibling);

		input.addEventListener('change', function () {
			renderPreview(zone, input.files && input.files[0] ? input.files[0] : null);
		});
		['dragenter', 'dragover'].forEach(function (evt) {
			zone.addEventListener(evt, function (e) { e.preventDefault(); e.stopPropagation(); zone.classList.add('is-dragover'); });
		});
		['dragleave', 'dragend', 'drop'].forEach(function (evt) {
			zone.addEventListener(evt, function (e) { e.preventDefault(); e.stopPropagation(); zone.classList.remove('is-dragover'); });
		});
		zone.addEventListener('drop', function (e) {
			var dt = e.dataTransfer;
			if (dt && dt.files && dt.files.length) {
				try { input.files = dt.files; } catch (err) { /* older browsers */ }
				renderPreview(zone, dt.files[0]);
			}
		});
	}

	/* ---- Batched Products import (AJAX + progress bar) ---------------- */
	function ProgressUI(form) {
		var panel = form.parentNode.querySelector('[data-import-progress]');
		this.panel = panel;
		this.fill = panel.querySelector('.zymarg-import-progress__fill');
		this.status = panel.querySelector('.zymarg-import-progress__status');
		this.pct = panel.querySelector('.zymarg-import-progress__pct');
		this.counts = panel.querySelector('[data-progress-counts]');
		this.note = panel.querySelector('[data-progress-note]');
		this.actions = panel.querySelector('[data-progress-actions]');
	}
	ProgressUI.prototype.show = function () { this.panel.hidden = false; };
	ProgressUI.prototype.setStatus = function (txt) { this.status.textContent = txt; };
	ProgressUI.prototype.setPct = function (p) {
		p = Math.max(0, Math.min(100, p | 0));
		this.fill.style.width = p + '%';
		this.pct.textContent = p + '%';
	};
	ProgressUI.prototype.setError = function (msg) {
		this.panel.classList.add('is-error');
		this.setStatus(msg || t('genericErr', 'Something went wrong.'));
	};
	ProgressUI.prototype.setCounts = function (tot) {
		var c = this.counts;
		c.hidden = false;
		c.innerHTML =
			chip(tot.imported, t('imported', 'created')) +
			chip(tot.updated, t('updated', 'updated')) +
			chip(tot.skipped, t('skipped', 'skipped')) +
			(tot.failed ? chip(tot.failed, t('failed', 'failed')) : '');
	};
	ProgressUI.prototype.finish = function (tot) {
		this.panel.classList.add('is-done');
		this.setPct(100);
		this.setStatus(t('complete', 'Import complete'));
		this.setCounts(tot);

		var notes = [];
		if (tot.warnings.length) {
			notes.push(noteBlock(t('noImageHd', 'Imported without an image') + ' (' + tot.warnings.length + ')', tot.warnings, 'warn'));
		}
		if (tot.failedMsgs.length) {
			notes.push(noteBlock(t('failHd', 'Issues') + ' (' + tot.failedMsgs.length + ')', tot.failedMsgs, 'err'));
		}
		if (notes.length) { this.note.hidden = false; this.note.innerHTML = notes.join(''); }

		if (CFG.productsUrl) {
			this.actions.hidden = false;
			this.actions.innerHTML = '<a class="button zymarg-import-btn" href="' + escapeHtml(CFG.productsUrl) + '">' + escapeHtml(t('viewProd', 'View products')) + '</a>';
		}
	};
	ProgressUI.prototype.finishExport = function (url) {
		this.panel.classList.add('is-done');
		this.setPct(100);
		this.setStatus(t('dlReady', 'Your download is ready.'));
		if (url) {
			this.actions.hidden = false;
			this.actions.innerHTML = '<a class="button zymarg-import-btn" href="' + escapeHtml(url) + '">' + escapeHtml(t('download', 'Download')) + '</a>';
		}
	};

	function chip(n, label) {
		return '<span class="zymarg-import__chip"><b>' + (n | 0) + '</b> ' + escapeHtml(label) + '</span>';
	}
	function noteBlock(heading, items, kind) {
		var shown = items.slice(0, 30).map(function (x) { return '<li>' + escapeHtml(x) + '</li>'; }).join('');
		var more = items.length > 30 ? '<li class="is-more">' + escapeHtml((t('andMore', '…and %d more')).replace('%d', items.length - 30)) + '</li>' : '';
		return '<div class="zymarg-import-note is-' + kind + '"><strong>' + escapeHtml(heading) + '</strong><ul>' + shown + more + '</ul></div>';
	}

	function postForm(data) {
		return fetch(CFG.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: data })
			.then(function (r) { return r.json(); });
	}

	function runProductsImport(form) {
		var input = form.querySelector('input[type="file"]');
		if (!input || !input.files || !input.files.length) { return; }

		var ui = new ProgressUI(form);
		var btn = form.querySelector('button[type="submit"]');
		if (btn) { btn.disabled = true; btn.classList.add('is-loading'); }
		ui.show();
		ui.setPct(0);
		ui.setStatus(t('uploading', 'Uploading file…'));

		var totals = { imported: 0, updated: 0, skipped: 0, failed: 0, warnings: [], failedMsgs: [] };

		var fd = new FormData();
		fd.append('action', 'zymarg_import_upload');
		fd.append('nonce', CFG.uploadNonce);
		fd.append('file', input.files[0]);

		postForm(fd).then(function (res) {
			if (!res || !res.success) {
				throw new Error((res && res.data && res.data.message) || t('genericErr', 'Upload failed.'));
			}
			ui.setStatus(t('importing', 'Importing products…'));
			batch(res.data.token, 0);
		}).catch(function (err) { ui.setError(err.message); reenable(btn); });

		function batch(token, position) {
			var b = new FormData();
			b.append('action', 'zymarg_import_batch');
			b.append('nonce', CFG.batchNonce);
			b.append('token', token);
			b.append('position', position);

			postForm(b).then(function (res) {
				if (!res || !res.success) {
					throw new Error((res && res.data && res.data.message) || t('genericErr', 'Import failed.'));
				}
				var d = res.data;
				totals.imported += (d.imported | 0);
				totals.updated += (d.updated | 0);
				totals.skipped += (d.skipped | 0);
				totals.failed += (d.failed | 0);
				if (d.warnings && d.warnings.length) { totals.warnings = totals.warnings.concat(d.warnings); }
				if (d.failed_messages && d.failed_messages.length) { totals.failedMsgs = totals.failedMsgs.concat(d.failed_messages); }

				ui.setPct(d.percent);
				ui.setCounts(totals);

				if (d.done) { ui.finish(totals); reenable(btn); }
				else { batch(token, d.position); }
			}).catch(function (err) { ui.setError(err.message); reenable(btn); });
		}

		function reenable(button) {
			if (button) { button.disabled = false; button.classList.remove('is-loading'); }
		}
	}

	/* ---- Batched export (Products CSV / Store Snapshot) --------------- */
	function runExport(form, mode) {
		var ui = new ProgressUI(form);
		var btn = form.querySelector('button[type="submit"]');
		if (btn) { btn.disabled = true; btn.classList.add('is-loading'); }
		ui.show();
		ui.setPct(0);
		ui.setStatus(t('exporting', 'Preparing export…'));

		var category = (form.querySelector('[name="category"]') || {}).value || 0;
		var status = (form.querySelector('[name="status"]') || {}).value || 'any';

		step(1, '');

		function step(stepNum, token) {
			var fd = new FormData();
			fd.append('action', 'zymarg_export_batch');
			fd.append('nonce', CFG.exportNonce);
			fd.append('mode', mode);
			fd.append('step', stepNum);
			fd.append('token', token);
			fd.append('category', category);
			fd.append('status', status);

			postForm(fd).then(function (res) {
				if (!res || !res.success) {
					throw new Error((res && res.data && res.data.message) || t('genericErr', 'Export failed.'));
				}
				var d = res.data;
				ui.setPct(d.percent);
				ui.setStatus(t('exporting', 'Preparing export…') + ' (' + (d.exported || 0) + ' ' + t('exported', 'exported') + ')');
				if (d.done) {
					ui.finishExport(d.url);
					reenable(btn);
					if (d.url) { window.location.href = d.url; }
				} else {
					step(d.step, d.token);
				}
			}).catch(function (err) { ui.setError(err.message); reenable(btn); });
		}

		function reenable(button) {
			if (button) { button.disabled = false; button.classList.remove('is-loading'); }
		}
	}

	/* ---- Generic loading state for the direct (non-batched) forms ----- */
	function initSubmitState(form) {
		form.addEventListener('submit', function () {
			var btn = form.querySelector('button[type="submit"], .zymarg-import-btn');
			if (btn && !btn.disabled) {
				btn.dataset.label = btn.textContent;
				btn.classList.add('is-loading');
				btn.textContent = t('working', 'Working…');
				setTimeout(function () {
					btn.classList.remove('is-loading');
					if (btn.dataset.label) { btn.textContent = btn.dataset.label; }
				}, 8000);
			}
		});
	}

	function init() {
		var zones = document.querySelectorAll('.zymarg-import [data-dropzone]');
		Array.prototype.forEach.call(zones, initDropzone);

		var forms = document.querySelectorAll('.zymarg-import form');
		Array.prototype.forEach.call(forms, function (form) {
			var exportMode = form.getAttribute('data-zymarg-export-form');
			if (form.getAttribute('data-zymarg-import-form') === 'products' && CFG.ajaxUrl) {
				form.addEventListener('submit', function (e) {
					var input = form.querySelector('input[type="file"]');
					if (input && input.files && input.files.length) {
						e.preventDefault();
						runProductsImport(form);
					}
					// else: let the browser show the "required" validation.
				});
			} else if (exportMode && CFG.ajaxUrl) {
				form.addEventListener('submit', function (e) {
					e.preventDefault();
					runExport(form, exportMode);
				});
			} else {
				initSubmitState(form);
			}
		});
	}

	if (document.readyState !== 'loading') { init(); }
	else { document.addEventListener('DOMContentLoaded', init); }
})();
