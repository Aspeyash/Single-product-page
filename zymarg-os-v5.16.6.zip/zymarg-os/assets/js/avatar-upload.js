/**
 * ZYMARG OS — Avatar Upload: live camera OR gallery → passport crop → compress → upload.
 *
 * "Take Photo"  → opens the device/webcam via getUserMedia (live preview + shutter).
 * "Choose from Gallery" → opens the file picker.
 * Both feed into a 7:9 passport-ratio crop, JPEG compression, then AJAX upload.
 *
 * No external dependencies. Uses native canvas + MediaDevices API.
 */
(function () {
	'use strict';

	var RATIO_W = 7;
	var RATIO_H = 9;
	var OUTPUT_W = 280;
	var OUTPUT_H = Math.round(OUTPUT_W * (RATIO_H / RATIO_W)); // 360
	var QUALITY = 0.85;

	var input = document.getElementById('zymarg-avatar-input');
	var avatarBtn = document.getElementById('zymarg-avatar-btn');
	var picker = document.getElementById('zymarg-avatar-picker');
	var cameraOpt = document.getElementById('zymarg-avatar-camera');
	var galleryOpt = document.getElementById('zymarg-avatar-gallery');
	var removeOpt = document.getElementById('zymarg-avatar-remove');
	if (!input || !avatarBtn) return;

	var overlay, cropBox, imgEl, cropData = {};
	var camStream = null;

	function hidePicker() { if (picker) picker.style.display = 'none'; }

	function togglePicker() {
		if (!picker) { return; }
		picker.style.display = (picker.style.display === 'none' || !picker.style.display) ? 'block' : 'none';
	}

	// Toggle picker popup
	avatarBtn.addEventListener('click', function (e) {
		e.stopPropagation();
		togglePicker();
	});
	document.addEventListener('click', hidePicker);
	if (picker) picker.addEventListener('click', function (e) { e.stopPropagation(); });

	// Tap-on-avatar (works on touch + mouse). When the user has a photo set,
	// the small camera button is hidden behind .has-photo's opacity/visibility
	// (and hover-reveal doesn't exist on touch devices). So we let the entire
	// avatar wrapper act as the picker trigger in that state — clean look on
	// mobile + a real way to change/remove the photo with a single tap.
	document.querySelectorAll('.zymarg-acc-sidebar .user-avatar').forEach(function (av) {
		av.addEventListener('click', function (e) {
			if (!av.classList.contains('has-photo')) { return; }
			if (e.target.closest && e.target.closest('#zymarg-avatar-btn, #zymarg-avatar-picker')) { return; }
			e.preventDefault();
			e.stopPropagation();
			togglePicker();
		});
	});


	// Gallery option → file picker
	if (galleryOpt) {
		galleryOpt.addEventListener('click', function () {
			hidePicker();
			input.value = '';
			input.click();
		});
	}
	input.addEventListener('change', function () {
		var file = input.files && input.files[0];
		if (file && /^image\//.test(file.type)) { showCropModal(file); }
	});

	// Camera option → live camera (getUserMedia) with file-input fallback
	if (cameraOpt) {
		cameraOpt.addEventListener('click', function () {
			hidePicker();
			if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
				openCamera();
			} else {
				// Fallback: native camera capture via a temp input
				var tmp = document.createElement('input');
				tmp.type = 'file';
				tmp.accept = 'image/*';
				tmp.setAttribute('capture', 'user');
				tmp.addEventListener('change', function () {
					var f = tmp.files && tmp.files[0];
					if (f && /^image\//.test(f.type)) { showCropModal(f); }
				});
				tmp.click();
			}
		});
	}

	// Remove option → confirm → AJAX delete → revert avatar src + drop .has-photo
	if (removeOpt) {
		removeOpt.addEventListener('click', function () {
			hidePicker();
			var i18n = (window.ZymargAvatar && window.ZymargAvatar.i18n) || {};
			var confirmMsg = i18n.confirmRemove || 'Remove your profile photo?';
			if (!window.confirm(confirmMsg)) { return; }

			var fd = new FormData();
			fd.append('action', 'zymarg_remove_avatar');
			fd.append('_wpnonce', (window.ZymargAvatar && window.ZymargAvatar.nonce) || '');

			fetch((window.ZymargAvatar && window.ZymargAvatar.ajaxUrl) || '/wp-admin/admin-ajax.php', {
				method: 'POST', body: fd, credentials: 'same-origin'
			})
			.then(function (r) { return r.json(); })
			.then(function (res) {
				if (res && res.success && res.data && res.data.defaultUrl) {
					// Revert the avatar image to the default (Gravatar/etc.)
					document.querySelectorAll('.zymarg-acc-sidebar .user-avatar img, .zymarg-avatar-preview').forEach(function (im) {
						im.src = res.data.defaultUrl + (res.data.defaultUrl.indexOf('?') > -1 ? '&' : '?') + 't=' + Date.now();
					});
					// Drop the .has-photo class so the camera overlay is shown again.
					document.querySelectorAll('.zymarg-acc-sidebar .user-avatar').forEach(function (av) {
						av.classList.remove('has-photo');
					});
					// The Remove button only renders when photo is set — remove it
					// from the DOM so it doesn't linger until next page load.
					if (removeOpt && removeOpt.parentNode) { removeOpt.parentNode.removeChild(removeOpt); }
				} else {
					alert((res && res.data && res.data.message) || i18n.removeError || 'Could not remove your photo. Please try again.');
				}
			})
			.catch(function () { alert(i18n.removeError || 'Could not remove your photo. Please try again.'); });
		});
	}


	/* ── Live Camera (getUserMedia) ──────────────────────────────────── */
	function openCamera() {
		var cam = document.createElement('div');
		cam.className = 'zymarg-crop-overlay';
		cam.innerHTML =
			'<div class="zymarg-crop-modal">' +
			'<div class="zymarg-crop-header"><span>Take a photo</span><button class="zymarg-cam-close">&times;</button></div>' +
			'<div class="zymarg-cam-area"><video id="zymarg-cam-video" autoplay playsinline muted></video></div>' +
			'<div class="zymarg-crop-actions"><button class="btn btn-outline zymarg-cam-close-btn">Cancel</button><button class="btn btn-primary zymarg-cam-shot">Capture</button></div>' +
			'</div>';
		document.body.appendChild(cam);

		var video = cam.querySelector('#zymarg-cam-video');
		var closeCam = function () {
			if (camStream) { camStream.getTracks().forEach(function (t) { t.stop(); }); camStream = null; }
			if (cam.parentNode) { cam.parentNode.removeChild(cam); }
		};
		cam.querySelector('.zymarg-cam-close').addEventListener('click', closeCam);
		cam.querySelector('.zymarg-cam-close-btn').addEventListener('click', closeCam);

		navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' }, audio: false })
			.then(function (stream) {
				camStream = stream;
				video.srcObject = stream;
			})
			.catch(function () {
				closeCam();
				alert('Could not access the camera. Please allow camera permission, or use "Choose from Gallery".');
			});

		cam.querySelector('.zymarg-cam-shot').addEventListener('click', function () {
			if (!video.videoWidth) { return; }
			var c = document.createElement('canvas');
			c.width = video.videoWidth;
			c.height = video.videoHeight;
			c.getContext('2d').drawImage(video, 0, 0);
			c.toBlob(function (blob) {
				closeCam();
				if (blob) {
					var f = new File([blob], 'camera.jpg', { type: 'image/jpeg' });
					showCropModal(f);
				}
			}, 'image/jpeg', 0.92);
		});
	}


	/* ── Crop Modal ──────────────────────────────────────────────────── */
	function showCropModal(file) {
		var url = URL.createObjectURL(file);

		overlay = document.createElement('div');
		overlay.className = 'zymarg-crop-overlay';
		overlay.innerHTML =
			'<div class="zymarg-crop-modal">' +
			'<div class="zymarg-crop-header"><span>Crop Image</span><button class="zymarg-crop-cancel">&times;</button></div>' +
			'<div class="zymarg-crop-area"><img id="zymarg-crop-img" alt=""><div class="zymarg-crop-frame"></div></div>' +
			'<div class="zymarg-crop-zoom"><span>-</span><input type="range" id="zymarg-crop-zoom" min="1" max="4" step="0.01" value="1"><span>+</span></div>' +
			'<div class="zymarg-crop-actions"><button class="btn btn-outline zymarg-crop-cancel-btn">Cancel</button><button class="btn btn-primary zymarg-crop-save">Save Photo</button></div>' +
			'</div>';
		document.body.appendChild(overlay);

		imgEl = overlay.querySelector('#zymarg-crop-img');
		cropBox = overlay.querySelector('.zymarg-crop-frame');

		// Run initCrop whether the image loads async OR is already complete (race fix).
		var started = false;
		function start() { if (started) { return; } started = true; URL.revokeObjectURL(url); initCrop(); }
		imgEl.onload = start;
		imgEl.onerror = function () { closeCrop(); alert('Could not load that image.'); };
		imgEl.src = url;
		if (imgEl.complete && imgEl.naturalWidth) { start(); }

		overlay.querySelector('.zymarg-crop-cancel').addEventListener('click', closeCrop);
		overlay.querySelector('.zymarg-crop-cancel-btn').addEventListener('click', closeCrop);
		overlay.querySelector('.zymarg-crop-save').addEventListener('click', function () { saveCrop(file); });
		overlay.addEventListener('click', function (e) { if (e.target === overlay) closeCrop(); });
	}


	/* Pan-the-image + zoom-slider crop (fixed centered frame). */
	function initCrop() {
		var area = overlay.querySelector('.zymarg-crop-area');
		var zoom = overlay.querySelector('#zymarg-crop-zoom');
		var aw = area.offsetWidth || 380;
		var ah = area.offsetHeight || 320;
		var iw = imgEl.naturalWidth;
		var ih = imgEl.naturalHeight;

		// Fixed crop frame: passport ratio, centered, fits inside the area with margin.
		var fh = Math.min(ah - 24, Math.round((aw - 24) * (RATIO_H / RATIO_W)));
		var fw = Math.round(fh * (RATIO_W / RATIO_H));
		if (fw > aw - 24) { fw = aw - 24; fh = Math.round(fw * (RATIO_H / RATIO_W)); }
		var frameLeft = Math.round((aw - fw) / 2);
		var frameTop = Math.round((ah - fh) / 2);

		cropBox.style.width = fw + 'px';
		cropBox.style.height = fh + 'px';
		cropBox.style.left = frameLeft + 'px';
		cropBox.style.top = frameTop + 'px';

		// Minimum scale so the image always covers the frame.
		var minScale = Math.max(fw / iw, fh / ih);
		var scale = minScale;
		// Start centered on the frame.
		var offX = frameLeft + (fw - iw * scale) / 2;
		var offY = frameTop + (fh - ih * scale) / 2;

		function clamp() {
			var dw = iw * scale, dh = ih * scale;
			offX = Math.min(frameLeft, Math.max(frameLeft + fw - dw, offX));
			offY = Math.min(frameTop, Math.max(frameTop + fh - dh, offY));
		}
		function render() {
			clamp();
			imgEl.style.width = (iw * scale) + 'px';
			imgEl.style.height = (ih * scale) + 'px';
			imgEl.style.left = offX + 'px';
			imgEl.style.top = offY + 'px';
		}

		imgEl.style.position = 'absolute';
		render();

		cropData = {
			get scale() { return scale; },
			get sx() { return (frameLeft - offX) / scale; },
			get sy() { return (frameTop - offY) / scale; },
			get sw() { return fw / scale; },
			get sh() { return fh / scale; }
		};

		// Zoom slider (multiplier 1..4 of minScale).
		zoom.addEventListener('input', function () {
			var mult = parseFloat(zoom.value) || 1;
			var newScale = minScale * mult;
			// Zoom toward the frame center.
			var fcx = frameLeft + fw / 2, fcy = frameTop + fh / 2;
			offX = fcx - (fcx - offX) * (newScale / scale);
			offY = fcy - (fcy - offY) * (newScale / scale);
			scale = newScale;
			render();
		});

		// Drag to pan the image.
		var dragging = false, startX, startY, startOffX, startOffY;
		function startDrag(e) {
			e.preventDefault();
			dragging = true;
			var pt = e.touches ? e.touches[0] : e;
			startX = pt.clientX; startY = pt.clientY;
			startOffX = offX; startOffY = offY;
			document.addEventListener('mousemove', moveDrag);
			document.addEventListener('touchmove', moveDrag, { passive: false });
			document.addEventListener('mouseup', endDrag);
			document.addEventListener('touchend', endDrag);
		}
		function moveDrag(e) {
			if (!dragging) { return; }
			e.preventDefault();
			var pt = e.touches ? e.touches[0] : e;
			offX = startOffX + (pt.clientX - startX);
			offY = startOffY + (pt.clientY - startY);
			render();
		}
		function endDrag() {
			dragging = false;
			document.removeEventListener('mousemove', moveDrag);
			document.removeEventListener('touchmove', moveDrag);
			document.removeEventListener('mouseup', endDrag);
			document.removeEventListener('touchend', endDrag);
		}
		area.addEventListener('mousedown', startDrag);
		area.addEventListener('touchstart', startDrag, { passive: false });
	}


	/* ── Save: crop → compress → upload ──────────────────────────────── */
	function saveCrop(originalFile) {
		var d = cropData;
		var sx = Math.round(d.sx);
		var sy = Math.round(d.sy);
		var sw = Math.round(d.sw);
		var sh = Math.round(d.sh);

		var canvas = document.createElement('canvas');
		canvas.width = OUTPUT_W;
		canvas.height = OUTPUT_H;
		var ctx = canvas.getContext('2d');
		ctx.fillStyle = '#ffffff';
		ctx.fillRect(0, 0, OUTPUT_W, OUTPUT_H);

		var img = new Image();
		img.onload = function () {
			ctx.drawImage(img, sx, sy, sw, sh, 0, 0, OUTPUT_W, OUTPUT_H);
			canvas.toBlob(function (blob) {
				if (blob) { uploadAvatar(blob); }
			}, 'image/jpeg', QUALITY);
		};
		img.src = URL.createObjectURL(originalFile);
	}

	function uploadAvatar(blob) {
		var saveBtn = overlay.querySelector('.zymarg-crop-save');
		if (saveBtn) { saveBtn.textContent = 'Uploading...'; saveBtn.disabled = true; }

		var fd = new FormData();
		fd.append('action', 'zymarg_upload_avatar');
		fd.append('_wpnonce', (window.ZymargAvatar && window.ZymargAvatar.nonce) || '');
		fd.append('avatar', blob, 'avatar.jpg');

		fetch((window.ZymargAvatar && window.ZymargAvatar.ajaxUrl) || '/wp-admin/admin-ajax.php', {
			method: 'POST', body: fd, credentials: 'same-origin'
		})
		.then(function (r) { return r.json(); })
		.then(function (res) {
			if (res && res.success && res.data && res.data.url) {
				document.querySelectorAll('.zymarg-acc-sidebar .user-avatar img, .zymarg-avatar-preview').forEach(function (im) {
					im.src = res.data.url + '?t=' + Date.now();
				});
				// Mark the avatar wrappers as "has-photo" so the camera overlay
				// disappears immediately — no reload needed. The CSS rule for
				// .user-avatar.has-photo .user-avatar-upload hides it.
				document.querySelectorAll('.zymarg-acc-sidebar .user-avatar').forEach(function (av) {
					av.classList.add('has-photo');
				});
			} else {
				alert((res && res.data && res.data.message) || 'Upload failed. Please try again.');
			}
			closeCrop();
		})
		.catch(function () { alert('Upload failed. Please try again.'); closeCrop(); });
	}

	function closeCrop() {
		if (overlay && overlay.parentNode) { overlay.parentNode.removeChild(overlay); }
		overlay = null;
		input.value = '';
	}
})();
