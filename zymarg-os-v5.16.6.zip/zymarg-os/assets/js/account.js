/**
 * ZYMARG OS — My Account interactive logic + SPA navigation.
 *
 * - Event-delegated handlers (survive AJAX content swaps): tabs, dashboard
 *   cards, delete-account modal, preference toggles, mobile hamburger.
 * - SPA navigation: sidebar clicks load sections via AJAX (no full reload),
 *   with background prefetch so every section is instant after first paint.
 * - Recently-viewed localStorage tracker.
 *
 * @package ZYMARG_OS
 */
(function () {
	'use strict';

	var ACC = window.ZymargAccount || {};

	function $(sel, ctx) { return (ctx || document).querySelector(sel); }

	/* ── Tabs (delegated) ──────────────────────────────────────────────── */
	document.addEventListener('click', function (e) {
		var btn = e.target.closest ? e.target.closest('.tab-bar button') : null;
		if (!btn) { return; }
		var bar = btn.closest('.tab-bar');
		bar.querySelectorAll('button').forEach(function (b) { b.classList.remove('active'); });
		btn.classList.add('active');
		var parent = bar.parentElement;
		parent.querySelectorAll('.tab-content').forEach(function (tc) { tc.classList.remove('active'); });
		var t = parent.querySelector('#' + btn.dataset.tab);
		if (t) { t.classList.add('active'); }
	});


	/* ── Dashboard cards → navigate to the matching section ───────────────
	 * The .dash-card[data-goto] tiles on the Dashboard panel (Recent Orders,
	 * Wishlist, Recently Viewed, Notifications, Vouchers) used to only show
	 * a one-line preview text and never actually navigated — making the
	 * cards visually look like buttons but functionally do nothing.
	 *
	 * Now: clicking a card routes through the existing SPA navTo() loader so
	 * the matching section is opened in-place (with proper history + scroll
	 * + sidebar active-state). Cmd/Ctrl/Shift-clicks are passed through so
	 * "open in new tab" still works from a wrapped <a>, if present.
	 * ------------------------------------------------------------------- */
	document.addEventListener('click', function (e) {
		var card = e.target.closest ? e.target.closest('.dash-card[data-goto]') : null;
		if (!card) { return; }
		if (e.metaKey || e.ctrlKey || e.shiftKey) { return; } // allow open-in-new-tab
		var key = card.dataset.goto;
		if (!key) { return; }
		var navLink = document.querySelector('.zymarg-acc-sidebar .nav-link[data-nav="' + key + '"]');
		if (!navLink) { return; }
		e.preventDefault();
		navTo(key, navLink.href, true);
	});


	/* ── Delete-account modal (delegated) ──────────────────────────────── */
	document.addEventListener('click', function (e) {
		var modal = document.getElementById('delete-modal');
		if (e.target.closest && e.target.closest('#btn-delete-account')) {
			if (modal) {
				modal.classList.add('is-open');
				var pw = document.getElementById('delete-password');
				if (pw) { pw.value = ''; setTimeout(function () { pw.focus(); }, 100); }
			}
			return;
		}
		if (e.target.closest && e.target.closest('#delete-cancel')) {
			if (modal) { modal.classList.remove('is-open'); }
			return;
		}
		if (modal && e.target === modal) { modal.classList.remove('is-open'); }
	});
	document.addEventListener('keydown', function (e) {
		var modal = document.getElementById('delete-modal');
		if (e.key === 'Escape' && modal && modal.classList.contains('is-open')) {
			modal.classList.remove('is-open');
		}
	});

	/* ── Preference / notification toggles (delegated) ─────────────────── */
	document.addEventListener('change', function (e) {
		var input = e.target.closest ? e.target.closest('.toggle-switch input[data-pref]') : null;
		if (!input) { return; }
		if (!ACC.ajaxUrl) { return; }
		var fd = new FormData();
		fd.append('action', 'zymarg_save_pref');
		fd.append('key', input.dataset.pref);
		fd.append('value', input.checked ? '1' : '0');
		fd.append('nonce', ACC.nonce || '');
		fetch(ACC.ajaxUrl, { method: 'POST', body: fd, credentials: 'same-origin' });
	});


	/* ── Recently viewed ───────────────────────────────────────────────
	 * Recently Viewed is now powered server-side by the ZYMARG Insights
	 * plugin (cross-device, privacy-first). The plugin renders the grid in
	 * PHP when the section loads, and tracks product views via its own
	 * non-blocking beacon on product pages — so the old, broken localStorage
	 * tracker (which never loaded outside the account page) has been removed.
	 *
	 * This no-op is kept so existing call sites stay harmless whether or not
	 * the plugin is active.
	 * ------------------------------------------------------------------- */
	function renderRecentlyViewed() { /* handled server-side by ZYMARG Insights */ }


	/* ── Mobile arrow toggle (delegated) ───────────────────────────────── */
	function closeSidebar() {
		var sb = $('.zymarg-acc-sidebar'); var ov = document.getElementById('zymarg-acc-overlay');
		var btn = document.getElementById('zymarg-acc-hamburger');
		if (sb) { sb.classList.remove('is-open'); }
		if (ov) { ov.classList.remove('is-open'); }
		if (btn) { btn.classList.remove('is-open'); }
	}
	document.addEventListener('click', function (e) {
		if (e.target.closest && e.target.closest('#zymarg-acc-hamburger')) {
			var sb = $('.zymarg-acc-sidebar'); var ov = document.getElementById('zymarg-acc-overlay');
			var btn = document.getElementById('zymarg-acc-hamburger');
			if (sb && sb.classList.contains('is-open')) { closeSidebar(); }
			else {
				if (sb) { sb.classList.add('is-open'); }
				if (ov) { ov.classList.add('is-open'); }
				if (btn) { btn.classList.add('is-open'); }
			}
			return;
		}
		if (e.target.id === 'zymarg-acc-overlay') { closeSidebar(); }
	});

	/* ── SPA navigation + background prefetch ──────────────────────────── */
	var cache = {};
	function mainEl() { return $('.zymarg-acc-main .main-content'); }

	function setActiveNav(key) {
		document.querySelectorAll('.zymarg-acc-sidebar .nav-link').forEach(function (l) {
			l.classList.toggle('active', l.dataset.nav === key);
		});
		// Sections are swapped over AJAX, so the zymarg-acc-section-* body class
		// printed by PHP on first paint would otherwise stay stuck on whichever
		// section happened to load first. Any layout rule keyed to that class
		// (the Messages panel runs edge-to-edge) has to follow the section the
		// user is actually on, not the one they landed on.
		if (key) {
			var b = document.body;
			String(b.className).split(/\s+/).forEach(function (c) {
				if (c.indexOf('zymarg-acc-section-') === 0) { b.classList.remove(c); }
			});
			b.classList.add('zymarg-acc-section-' + String(key).replace(/[^A-Za-z0-9_-]/g, ''));
		}
	}
	function swap(html) {
		var m = mainEl();
		if (!m) { return; }
		m.innerHTML = html;
		m.classList.remove('is-loading');
		renderRecentlyViewed();
		window.scrollTo(0, 0);
	}
	function fetchSection(key) {
		var fd = new FormData();
		fd.append('action', 'zymarg_load_section');
		fd.append('section', key);
		fd.append('nonce', ACC.sectionNonce || '');
		return fetch(ACC.ajaxUrl, { method: 'POST', body: fd, credentials: 'same-origin' })
			.then(function (r) { return r.json(); })
			.then(function (res) { return (res && res.success && res.data) ? res.data.html : null; });
	}


	function navTo(key, url, push) {
		if (cache[key]) {
			swap(cache[key]);
			finishNav(key, url, push);
			return;
		}
		var m = mainEl();
		if (m) {
			m.classList.add('is-loading');
			m.innerHTML = '<div class="zymarg-acc-loading">' + (ACC.spark || '') + '</div>';
		}
		fetchSection(key).then(function (html) {
			if (html) { cache[key] = html; swap(html); }
			else if (m) { m.classList.remove('is-loading'); window.location.href = url; return; }
			finishNav(key, url, push);
		}).catch(function () {
			if (m) { m.classList.remove('is-loading'); }
			window.location.href = url;
		});
	}
	function finishNav(key, url, push) {
		setActiveNav(key);
		if (push && window.history && window.history.pushState) {
			window.history.pushState({ zsec: key }, '', url);
		}
		if (window.innerWidth < 768) { closeSidebar(); }
	}

	// Intercept sidebar navigation.
	document.addEventListener('click', function (e) {
		var link = e.target.closest ? e.target.closest('.zymarg-acc-sidebar .nav-link') : null;
		if (!link) { return; }
		var key = link.dataset.nav;
		if (!key || key === 'logout') { return; }       // let logout navigate normally
		if (link.dataset.external === '1') { return; }  // external links (e.g. Community) navigate normally
		if (e.metaKey || e.ctrlKey || e.shiftKey) { return; } // allow open-in-new-tab
		e.preventDefault();
		navTo(key, link.href, true);
	});

	// Back / forward buttons.
	window.addEventListener('popstate', function (ev) {
		var key = ev.state && ev.state.zsec;
		if (key) { navTo(key, location.href, false); }
	});

	// Seed cache with the server-rendered first section so returning is instant.
	var activeLink = $('.zymarg-acc-sidebar .nav-link.active');
	var m0 = mainEl();
	if (activeLink && m0) {
		cache[activeLink.dataset.nav] = m0.innerHTML;
		if (window.history && window.history.replaceState) {
			window.history.replaceState({ zsec: activeLink.dataset.nav }, '', location.href);
		}
	}
	renderRecentlyViewed();

	// Background-prefetch every other section once idle, one at a time.
	function prefetchAll() {
		var links = Array.prototype.slice.call(document.querySelectorAll('.zymarg-acc-sidebar .nav-link'));
		var keys = links.map(function (l) { return l.dataset.nav; })
			.filter(function (k) { return k && k !== 'logout'; });
		var i = 0;
		function next() {
			if (i >= keys.length) { return; }
			var k = keys[i++];
			if (cache[k]) { next(); return; }
			fetchSection(k).then(function (html) {
				if (html) { cache[k] = html; }
				next();
			}).catch(next);
		}
		next();
	}
	if ('requestIdleCallback' in window) {
		requestIdleCallback(prefetchAll, { timeout: 2000 });
	} else {
		setTimeout(prefetchAll, 1200);
	}
})();



/* ==============================================================
   Logout Confirmation Modal
   ============================================================== */
(function () {
	'use strict';

	var logoutModal = document.getElementById('zymarg-logout-modal');
	if (!logoutModal) return;

	var logoutLink = document.querySelector('[data-zymarg-logout]');
	if (!logoutLink) return;

	// Intercept the logout link click — show confirmation instead.
	logoutLink.addEventListener('click', function (e) {
		e.preventDefault();
		openLogoutModal();
	});

	function openLogoutModal() {
		logoutModal.hidden = false;
		void logoutModal.offsetWidth;
		logoutModal.classList.add('is-open');
		document.body.style.overflow = 'hidden';
	}

	function closeLogoutModal() {
		logoutModal.classList.remove('is-open');
		document.body.style.overflow = '';
		setTimeout(function () {
			logoutModal.hidden = true;
		}, 320);
	}

	// Close buttons and overlay.
	logoutModal.querySelectorAll('[data-zymarg-logout-close]').forEach(function (el) {
		el.addEventListener('click', closeLogoutModal);
	});

	// ESC key.
	document.addEventListener('keydown', function (e) {
		if (e.key === 'Escape' && !logoutModal.hidden) {
			closeLogoutModal();
		}
	});
})();



/* ==============================================================
   Dashboard Cards — Smooth Drag-to-Scroll (desktop mouse swipe)
   ============================================================== */
(function () {
	'use strict';

	var slider = document.querySelector('.dash-cards');
	if (!slider) return;

	var isDown = false;
	var wasDragged = false;
	var startX;
	var scrollLeft;
	var DRAG_THRESHOLD = 8; // px — anything below is treated as a click, not a drag

	slider.addEventListener('mousedown', function (e) {
		isDown = true;
		wasDragged = false;
		startX = e.pageX - slider.offsetLeft;
		scrollLeft = slider.scrollLeft;
		// NOTE: don't add is-grabbing yet — only flip into "grabbing" mode once
		// the cursor has actually moved past the drag threshold. This stops
		// pointer-events:none from kicking in on a plain click and swallowing
		// the .dash-card[data-goto] handler.
	});

	slider.addEventListener('mouseleave', function () {
		isDown = false;
		slider.classList.remove('is-grabbing');
	});

	slider.addEventListener('mouseup', function () {
		isDown = false;
		slider.classList.remove('is-grabbing');
		// wasDragged is intentionally NOT reset here — the click handler below
		// needs it for one more tick so it can suppress the trailing click that
		// the browser fires after a drag. Reset happens on the next mousedown.
	});

	slider.addEventListener('mousemove', function (e) {
		if (!isDown) return;
		var x = e.pageX - slider.offsetLeft;
		var walk = (x - startX) * 1.5;
		if (Math.abs(walk) > DRAG_THRESHOLD) {
			slider.classList.add('is-grabbing');
			wasDragged = true;
		}
		if (wasDragged) {
			e.preventDefault();
			slider.scrollLeft = scrollLeft - walk;
		}
	});

	// Suppress the trailing click that follows a real drag (so dragging
	// horizontally never accidentally opens a section). Plain clicks pass
	// through normally because wasDragged stays false.
	slider.addEventListener('click', function (e) {
		if (wasDragged) {
			e.preventDefault();
			e.stopPropagation();
		}
	}, true); // capture phase so we run before the .dash-card[data-goto] handler
})();



