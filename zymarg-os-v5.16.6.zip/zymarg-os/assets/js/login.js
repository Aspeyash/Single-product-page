/**
 * ZYMARG OS — Login card + pop-up behaviour (v4.4.3).
 * BUILD MARKER: v4.8.9 — open browser DevTools console after loading
 *   the login page; you should see "ZYMARG Login JS v4.8.9 loaded".
 *   If not → JS file is cached.
 *
 * - Tab switching (Password / OTP) with animated transitions.
 * - Form submit with loading spinner + toast notification.
 * - Opens/closes the login modal (button, overlay, ESC, account icon).
 * - First-visit auto-open with configurable frequency.
 *
 * Forms post to standard WordPress endpoints so login works even
 * if JavaScript is disabled (only the pop-up + UX polish needs JS).
 */
( function () {
	'use strict';

	// Build marker — visible in browser console to verify the latest JS is loading.
	if ( typeof console !== 'undefined' && console.log ) {
		console.log( '%c[ZYMARG Login JS v4.8.9 loaded]', 'color:#9500a5;font-weight:bold;' );
	}

	function ready( fn ) {
		if ( document.readyState !== 'loading' ) {
			fn();
		} else {
			document.addEventListener( 'DOMContentLoaded', fn );
		}
	}

	ready( function () {
		var modal = document.getElementById( 'zymarg-login-modal' );

		/* ==============================================================
		   Tab switching (Password / OTP)
		   ============================================================== */
		function bindTabs( root ) {
			var tabs = root.querySelectorAll( '.zymarg-login__tab' );
			var panels = root.querySelectorAll( '.zymarg-login__panel' );
			var container = root.querySelector( '.zymarg-login__panels' );

			tabs.forEach( function ( btn ) {
				btn.addEventListener( 'click', function () {
					var target = btn.getAttribute( 'data-tab' );

					// Update tab active states.
					tabs.forEach( function ( t ) {
						var isActive = t.getAttribute( 'data-tab' ) === target;
						t.classList.toggle( 'is-active', isActive );
						t.setAttribute( 'aria-selected', String( isActive ) );
					} );

					// Switch panels with animation.
					panels.forEach( function ( p ) {
						var isTarget = p.getAttribute( 'data-panel' ) === target;
						if ( isTarget ) {
							p.hidden = false;
							p.classList.add( 'is-entering' );
							// Force reflow then remove entering class for animation.
							void p.offsetWidth;
							setTimeout( function () {
								p.classList.remove( 'is-entering' );
							}, 10 );
							// Dynamically resize container to match active panel height.
							if ( container ) {
								container.style.minHeight = p.scrollHeight + 'px';
							}
						} else {
							p.hidden = true;
						}
					} );
				} );
			} );

			// Set initial height based on the active panel.
			if ( container ) {
				var activePanel = root.querySelector( '.zymarg-login__panel.is-active, .zymarg-login__panel:not([hidden])' );
				if ( activePanel ) {
					container.style.minHeight = activePanel.scrollHeight + 'px';
				}
			}
		}

		document.querySelectorAll( '.zymarg-login' ).forEach( bindTabs );

		/* ==============================================================
		   Form submit — loading spinner
		   ============================================================== */
		document.querySelectorAll( '[data-zlg-submit]' ).forEach( function ( btn ) {
			var form = btn.closest( 'form' );
			if ( ! form ) return;
			// Skip AJAX forms — they have their own submit handlers below.
			if ( form.hasAttribute( 'data-zlg-lost-form' ) || form.hasAttribute( 'data-zlg-register-form' ) ) {
				return;
			}

			form.addEventListener( 'submit', function () {
				var spanEl = btn.querySelector( 'span' );
				var originalText = spanEl ? spanEl.textContent : '';
				btn.classList.add( 'is-loading' );
				btn.disabled = true;
				btn.innerHTML = '<span class="zymarg-login__spinner"></span> <span>Signing In...</span>';

				// The form will naturally submit and redirect.
				// If it stays on the page (error), restore after 4s.
				setTimeout( function () {
					btn.classList.remove( 'is-loading' );
					btn.disabled = false;
					btn.innerHTML = '<span>' + originalText + '</span>';
				}, 4000 );
			} );
		} );

		/* ==============================================================
		   Password show/hide toggle (eye icon)
		   ============================================================== */
		document.querySelectorAll( '[data-zlg-pw-toggle]' ).forEach( function ( btn ) {
			btn.addEventListener( 'click', function () {
				var wrap  = btn.closest( '.zymarg-login__password-wrap' );
				var input = wrap ? wrap.querySelector( 'input' ) : null;
				if ( ! input ) return;

				var showing = input.type === 'password';
				input.type = showing ? 'text' : 'password';

				var iconShow = btn.querySelector( '.zymarg-login__pw-icon--show' );
				var iconHide = btn.querySelector( '.zymarg-login__pw-icon--hide' );
				if ( iconShow ) iconShow.hidden = showing;
				if ( iconHide ) iconHide.hidden = ! showing;

				btn.setAttribute( 'aria-label', showing ? 'Hide password' : 'Show password' );
			} );
		} );

		/* ==============================================================
		   Panel switching: Forgot Password & Create New Account
		   ============================================================== */
		function switchPanel( card, target ) {
			var tabs   = card.querySelectorAll( '.zymarg-login__tab' );
			var panels = card.querySelectorAll( '.zymarg-login__panel' );
			var container = card.querySelector( '.zymarg-login__panels' );

			// Update tab active state — hidden panels (lost/register) deselect all tabs.
			var isTab = ( target === 'password' || target === 'otp' );
			tabs.forEach( function ( t ) {
				var on = isTab && t.getAttribute( 'data-tab' ) === target;
				t.classList.toggle( 'is-active', on );
				t.setAttribute( 'aria-selected', String( on ) );
			} );

			// Switch panels with animation.
			panels.forEach( function ( p ) {
				var match = p.getAttribute( 'data-panel' ) === target;
				if ( match ) {
					p.hidden = false;
					p.classList.add( 'is-entering' );
					void p.offsetWidth;
					setTimeout( function () { p.classList.remove( 'is-entering' ); }, 10 );
					if ( container ) {
						container.style.minHeight = p.scrollHeight + 'px';
					}
				} else {
					p.hidden = true;
				}
			} );
		}

		// "Forgot Password?" → show lost panel.
		document.querySelectorAll( '[data-zlg-show-lost]' ).forEach( function ( link ) {
			link.addEventListener( 'click', function ( e ) {
				e.preventDefault();
				var card = link.closest( '.zymarg-login' );
				if ( card ) switchPanel( card, 'lost' );
			} );
		} );

		// "Create New Account" → show register panel.
		document.querySelectorAll( '[data-zlg-show-register]' ).forEach( function ( link ) {
			link.addEventListener( 'click', function ( e ) {
				e.preventDefault();
				var card = link.closest( '.zymarg-login' );
				if ( card ) switchPanel( card, 'register' );
			} );
		} );

		// "← Back to login" → return to password panel.
		document.querySelectorAll( '[data-zlg-back-to-login]' ).forEach( function ( btn ) {
			btn.addEventListener( 'click', function ( e ) {
				e.preventDefault();
				var card = btn.closest( '.zymarg-login' );
				if ( card ) switchPanel( card, 'password' );
			} );
		} );

		/* ==============================================================
		   AJAX: Lost Password form
		   (v4.8.10+ uses referer+rate-limit instead of nonce, so JS no
		    longer needs to fetch a fresh nonce before submitting.)
		   ============================================================== */
		document.querySelectorAll( '[data-zlg-lost-form]' ).forEach( function ( form ) {
			form.addEventListener( 'submit', function ( e ) {
				e.preventDefault();
				var submitBtn = form.querySelector( '[data-zlg-submit]' );
				var msgEl     = form.querySelector( '[data-zlg-lost-message]' );
				var spanEl    = submitBtn ? submitBtn.querySelector( 'span' ) : null;
				var orig      = spanEl ? spanEl.textContent : 'Send Reset Link';

				if ( submitBtn ) {
					submitBtn.classList.add( 'is-loading' );
					submitBtn.disabled = true;
					submitBtn.innerHTML = '<span class="zymarg-login__spinner"></span> <span>Sending...</span>';
				}
				if ( msgEl ) {
					msgEl.hidden = true;
					msgEl.className = 'zymarg-login__inline-message';
				}

				var fd = new FormData( form );
				fetch( ( window.ZymargLogin && window.ZymargLogin.ajaxUrl ) || '/wp-admin/admin-ajax.php', {
					method:      'POST',
					credentials: 'same-origin',
					body:        fd,
				} )
				.then( function ( r ) { return r.json(); } )
				.then( function ( data ) {
					if ( msgEl ) {
						msgEl.hidden = false;
						msgEl.classList.add( data.success ? 'is-success' : 'is-error' );
						msgEl.textContent = ( data.data && data.data.message ) || ( data.success ? 'Reset link sent.' : 'Something went wrong.' );
					}
				} )
				.catch( function () {
					if ( msgEl ) {
						msgEl.hidden = false;
						msgEl.classList.add( 'is-error' );
						msgEl.textContent = 'Network error. Please try again.';
					}
				} )
				.finally( function () {
					if ( submitBtn ) {
						submitBtn.classList.remove( 'is-loading' );
						submitBtn.disabled = false;
						submitBtn.innerHTML = '<span>' + orig + '</span>';
					}
				} );
			} );
		} );

		/* ==============================================================
		   AJAX: Register form
		   ============================================================== */
		document.querySelectorAll( '[data-zlg-register-form]' ).forEach( function ( form ) {
			form.addEventListener( 'submit', function ( e ) {
				e.preventDefault();
				var submitBtn = form.querySelector( '[data-zlg-submit]' );
				var msgEl     = form.querySelector( '[data-zlg-register-message]' );
				var spanEl    = submitBtn ? submitBtn.querySelector( 'span' ) : null;
				var orig      = spanEl ? spanEl.textContent : 'Create Account';

				if ( submitBtn ) {
					submitBtn.classList.add( 'is-loading' );
					submitBtn.disabled = true;
					submitBtn.innerHTML = '<span class="zymarg-login__spinner"></span> <span>Creating...</span>';
				}
				if ( msgEl ) {
					msgEl.hidden = true;
					msgEl.className = 'zymarg-login__inline-message';
				}

				var fd = new FormData( form );
				fetch( ( window.ZymargLogin && window.ZymargLogin.ajaxUrl ) || '/wp-admin/admin-ajax.php', {
					method:      'POST',
					credentials: 'same-origin',
					body:        fd,
				} )
				.then( function ( r ) { return r.json(); } )
				.then( function ( data ) {
					if ( msgEl ) {
						msgEl.hidden = false;
						msgEl.classList.add( data.success ? 'is-success' : 'is-error' );
						msgEl.textContent = ( data.data && data.data.message ) || ( data.success ? 'Account created.' : 'Something went wrong.' );
					}
					if ( data.success && data.data && data.data.redirect ) {
						setTimeout( function () {
							var target  = data.data.redirect;
							var current = window.location.href;
							// If target URL strips to same path as current, force a reload
							// (assigning the same URL to location.href is a no-op).
							var stripQs = function ( u ) { return ( u || '' ).replace( /[?#].*$/, '' ); };
							if ( stripQs( target ) === stripQs( current ) ) {
								window.location.reload();
							} else {
								window.location.assign( target );
							}
						}, 900 );
					} else if ( submitBtn ) {
						submitBtn.classList.remove( 'is-loading' );
						submitBtn.disabled = false;
						submitBtn.innerHTML = '<span>' + orig + '</span>';
					}
				} )
				.catch( function () {
					if ( msgEl ) {
						msgEl.hidden = false;
						msgEl.classList.add( 'is-error' );
						msgEl.textContent = 'Network error. Please try again.';
					}
					if ( submitBtn ) {
						submitBtn.classList.remove( 'is-loading' );
						submitBtn.disabled = false;
						submitBtn.innerHTML = '<span>' + orig + '</span>';
					}
				} );
			} );
		} );

		/* ==============================================================
		   Toast notification
		   ============================================================== */
		function showToast( message ) {
			var toast = document.getElementById( 'zymarg-login-toast' );
			if ( ! toast ) return;

			var msgEl = document.getElementById( 'zymarg-login-toast-msg' );
			if ( msgEl && message ) {
				msgEl.textContent = message;
			}

			toast.classList.add( 'is-visible' );
			setTimeout( function () {
				toast.classList.remove( 'is-visible' );
			}, 3000 );
		}

		// Expose globally for potential use by other scripts.
		window.zymargLoginToast = showToast;

		// Show toast if URL has login success param.
		if ( window.location.search.indexOf( 'login=success' ) !== -1 ) {
			showToast( 'Welcome back!' );
		}

		/* ==============================================================
		   Google sign-in button (placeholder — redirects to plugin URL)
		   ============================================================== */
		document.querySelectorAll( '[data-zlg-google]' ).forEach( function ( btn ) {
			btn.addEventListener( 'click', function () {
				// If a social login plugin provides a URL, redirect there.
				// Otherwise show a toast indicating it's not configured.
				var googleUrl = btn.getAttribute( 'data-google-url' );
				if ( googleUrl ) {
					window.location.href = googleUrl;
				} else {
					showToast( 'Google login is not configured yet.' );
				}
			} );
		} );

		/* ==============================================================
		   Modal — open / close
		   ============================================================== */
		if ( ! modal ) return;

		var lastFocus = null;

		function openModal() {
			if ( ! modal.hidden ) return;
			lastFocus = document.activeElement;
			modal.hidden = false;
			void modal.offsetWidth;
			modal.classList.add( 'is-open' );
			document.body.classList.add( 'zymarg-login-open' );

			var field = modal.querySelector( 'input[type="text"], input[type="email"]' );
			if ( field ) {
				try { field.focus( { preventScroll: true } ); } catch ( e ) { field.focus(); }
			}
			remember();
		}

		function closeModal() {
			if ( modal.hidden ) return;
			modal.classList.remove( 'is-open' );
			document.body.classList.remove( 'zymarg-login-open' );
			setTimeout( function () { modal.hidden = true; }, 320 );
			if ( lastFocus && lastFocus.focus ) {
				lastFocus.focus();
			}
		}

		// Close buttons and overlay.
		modal.querySelectorAll( '[data-zymarg-login-close]' ).forEach( function ( el ) {
			el.addEventListener( 'click', closeModal );
		} );

		// ESC key.
		document.addEventListener( 'keydown', function ( e ) {
			if ( e.key === 'Escape' && ! modal.hidden ) {
				closeModal();
			}
		} );

		// Manual open triggers.
		document.querySelectorAll( '[data-zymarg-login-open]' ).forEach( function ( el ) {
			el.addEventListener( 'click', function ( e ) {
				e.preventDefault();
				openModal();
			} );
		} );

		// Header account icon opens the pop-up (optional).
		if ( modal.getAttribute( 'data-trigger-account' ) === '1' ) {
			document.querySelectorAll( '.zymarg-account-icon, .menu-item-zymarg-account > a' ).forEach( function ( el ) {
				el.addEventListener( 'click', function ( e ) {
					e.preventDefault();
					openModal();
				} );
			} );
		}

		/* ==============================================================
		   First-visit frequency logic
		   ============================================================== */
		var KEY = 'zymargLoginPopup';

		function store( v ) {
			try { if ( window.localStorage ) { localStorage.setItem( KEY, v ); } } catch ( e ) {}
		}
		function read() {
			try { return window.localStorage ? localStorage.getItem( KEY ) : null; } catch ( e ) { return null; }
		}

		function remember() {
			var freq = modal.getAttribute( 'data-frequency' ) || 'once';
			if ( freq === 'session' ) {
				try { if ( window.sessionStorage ) { sessionStorage.setItem( KEY, '1' ); } } catch ( e ) {}
			} else if ( freq === 'once' || freq === 'days' ) {
				store( String( Date.now() ) );
			}
		}

		function shouldAutoOpen() {
			var freq = modal.getAttribute( 'data-frequency' ) || 'once';
			if ( freq === 'every' ) return true;
			if ( freq === 'session' ) {
				try { return ! ( window.sessionStorage && sessionStorage.getItem( KEY ) ); } catch ( e ) { return true; }
			}
			var seen = read();
			if ( ! seen ) return true;
			if ( freq === 'once' ) return false;
			if ( freq === 'days' ) {
				var days = parseInt( modal.getAttribute( 'data-days' ), 10 ) || 7;
				var elapsed = Date.now() - parseInt( seen, 10 );
				return elapsed > days * 86400000;
			}
			return false;
		}

		if ( modal.getAttribute( 'data-auto' ) === '1' && shouldAutoOpen() ) {
			var delay = parseInt( modal.getAttribute( 'data-delay' ), 10 );
			if ( isNaN( delay ) || delay < 0 ) {
				delay = 1500;
			}
			setTimeout( openModal, delay );
		}

		// Force-open popup on My Account page (bypasses frequency/localStorage).
		// Uses a SEPARATE delay (data-force-delay on the wrapper) so this can
		// open instantly (0ms) while the general site popup waits 2000ms.
		var forceWrap = document.querySelector( '[data-force-login-popup="1"]' );
		if ( forceWrap ) {
			var forceDelay = parseInt( forceWrap.getAttribute( 'data-force-delay' ), 10 );
			if ( isNaN( forceDelay ) || forceDelay < 0 ) {
				forceDelay = 0;
			}
			if ( forceDelay === 0 ) {
				openModal();
			} else {
				setTimeout( openModal, forceDelay );
			}
		}
	} );
}() );
