/**
 * ZYMARG OS — Enhanced single product page
 * -----------------------------------------------------------------------------
 * Loaded only on is_product() when the enhanced PDP is enabled.
 *
 *   1. Quantity stepper (+ / −) around the native qty input.
 *   2. Variation swatches: turns each variation <select> into clickable
 *      colour chips / button pills. We DO NOT re-implement variation matching —
 *      we set the hidden <select> value and fire its change event, so
 *      WooCommerce's own wc-add-to-cart-variation engine handles the live
 *      price, image swap, stock and availability. We then mirror its
 *      enabled/disabled + selected state back onto the swatches.
 *
 * Vanilla JS for the UI; uses jQuery (already present on variable product
 * pages) only to listen to WooCommerce's variation events.
 */
( function () {
	'use strict';

	function onReady( fn ) {
		if ( document.readyState !== 'loading' ) {
			fn();
		} else {
			document.addEventListener( 'DOMContentLoaded', fn );
		}
	}

	/* ---- Quantity stepper --------------------------------------------- */
	function initQuantitySteppers( root ) {
		var boxes = ( root || document ).querySelectorAll( '.zymarg-pdp form.cart .quantity' );

		boxes.forEach( function ( box ) {
			if ( box.dataset.zymargStepper ) {
				return;
			}
			var input = box.querySelector( 'input.qty' );
			if ( ! input ) {
				return;
			}
			box.dataset.zymargStepper = '1';

			var minus = document.createElement( 'button' );
			minus.type = 'button';
			minus.className = 'zymarg-qty-btn zymarg-qty-minus';
			minus.setAttribute( 'aria-label', 'Decrease quantity' );
			minus.textContent = '\u2212'; // minus sign

			var plus = document.createElement( 'button' );
			plus.type = 'button';
			plus.className = 'zymarg-qty-btn zymarg-qty-plus';
			plus.setAttribute( 'aria-label', 'Increase quantity' );
			plus.textContent = '+';

			box.insertBefore( minus, input );
			box.appendChild( plus );

			function step( dir ) {
				var stepSize = parseFloat( input.getAttribute( 'step' ) ) || 1;
				var min = parseFloat( input.getAttribute( 'min' ) );
				var max = parseFloat( input.getAttribute( 'max' ) );
				var val = parseFloat( input.value ) || 0;

				val += dir * stepSize;

				if ( ! isNaN( min ) && val < min ) {
					val = min;
				}
				if ( ! isNaN( max ) && max > 0 && val > max ) {
					val = max;
				}
				if ( val < 0 ) {
					val = 0;
				}

				input.value = val;
				input.dispatchEvent( new Event( 'change', { bubbles: true } ) );
			}

			minus.addEventListener( 'click', function () { step( -1 ); } );
			plus.addEventListener( 'click', function () { step( 1 ); } );
		} );
	}

	/* ---- Variation swatches ------------------------------------------- */

	// Resolve an option label to a CSS colour, if it looks like one.
	function colourFor( label ) {
		var raw = ( label || '' ).trim().toLowerCase();
		if ( ! raw ) {
			return null;
		}
		var map = {
			'navy': '#001f54', 'sky blue': '#87ceeb', 'sky': '#87ceeb',
			'royal blue': '#4169e1', 'baby blue': '#89cff0', 'teal': '#008080',
			'mint': '#98ff98', 'lime': '#bfff00', 'olive': '#808000',
			'maroon': '#800000', 'burgundy': '#800020', 'wine': '#722f37',
			'rose': '#ff007f', 'blush': '#de5d83', 'peach': '#ffe5b4',
			'mustard': '#ffdb58', 'charcoal': '#36454f', 'slate': '#708090',
			'cream': '#fffdd0', 'ivory': '#fffff0', 'beige': '#f5f5dc',
			'tan': '#d2b48c', 'khaki': '#c3b091', 'sand': '#c2b280',
			'turquoise': '#40e0d0', 'lavender': '#e6e6fa', 'lilac': '#c8a2c8',
			'mauve': '#e0b0ff', 'coral': '#ff7f50', 'salmon': '#fa8072',
			'forest green': '#228b22', 'forest': '#228b22', 'emerald': '#50c878',
			'gold': '#d4af37', 'silver': '#c0c0c0', 'rose gold': '#b76e79',
			'space grey': '#4b4f54', 'space gray': '#4b4f54', 'graphite': '#383838',
			'off white': '#f8f8f2', 'offwhite': '#f8f8f2'
		};
		if ( map[ raw ] ) {
			return map[ raw ];
		}
		// Try the browser's own named-colour parser (handles red, blue, etc.).
		var probe = new Option().style;
		probe.color = '';
		probe.color = raw.replace( /\s+/g, '' );
		if ( probe.color !== '' ) {
			return raw.replace( /\s+/g, '' );
		}
		return null;
	}

	function buildSwatches( select ) {
		if ( select.dataset.zymargSwatched ) {
			return;
		}
		select.dataset.zymargSwatched = '1';

		var attrName = ( select.getAttribute( 'data-attribute_name' ) || select.name || '' ).toLowerCase();
		var isColour = /(colou?r|colour|couleur)/.test( attrName );

		var wrap = document.createElement( 'div' );
		wrap.className = 'zymarg-swatches';

		Array.prototype.forEach.call( select.options, function ( opt ) {
			if ( ! opt.value ) {
				return; // skip "Choose an option"
			}
			var btn = document.createElement( 'button' );
			btn.type = 'button';
			btn.className = 'zymarg-swatch';
			btn.setAttribute( 'data-value', opt.value );
			btn.setAttribute( 'title', opt.textContent );
			btn.setAttribute( 'aria-label', opt.textContent );

			if ( isColour ) {
				btn.classList.add( 'is-color' );
				var col = colourFor( opt.textContent );
				if ( col ) {
					btn.classList.add( 'has-color' );
					btn.style.setProperty( '--swatch', col );
					btn.textContent = opt.textContent; // hidden via CSS, kept for a11y
				} else {
					btn.textContent = opt.textContent;
				}
			} else {
				btn.textContent = opt.textContent;
			}

			btn.addEventListener( 'click', function () {
				if ( btn.classList.contains( 'is-disabled' ) ) {
					return;
				}
				// Toggle off if re-clicking the active one.
				if ( select.value === opt.value ) {
					select.value = '';
				} else {
					select.value = opt.value;
				}
				fireChange( select );
				syncSelected( select, wrap );
			} );

			wrap.appendChild( btn );
		} );

		select.classList.add( 'zymarg-select-hidden' );
		select.insertAdjacentElement( 'afterend', wrap );
		select._zymargSwatchWrap = wrap;
	}

	function fireChange( select ) {
		select.dispatchEvent( new Event( 'change', { bubbles: true } ) );
		if ( window.jQuery ) {
			window.jQuery( select ).trigger( 'change' );
		}
	}

	function syncSelected( select, wrap ) {
		var current = select.value;
		wrap.querySelectorAll( '.zymarg-swatch' ).forEach( function ( btn ) {
			btn.classList.toggle( 'is-selected', current && btn.getAttribute( 'data-value' ) === current );
		} );
	}

	function syncDisabled( select, wrap ) {
		// WooCommerce marks unavailable <option>s disabled on the OTHER selects.
		var optByValue = {};
		Array.prototype.forEach.call( select.options, function ( opt ) {
			if ( opt.value ) {
				optByValue[ opt.value ] = opt.disabled;
			}
		} );
		wrap.querySelectorAll( '.zymarg-swatch' ).forEach( function ( btn ) {
			var v = btn.getAttribute( 'data-value' );
			btn.classList.toggle( 'is-disabled', !! optByValue[ v ] );
		} );
	}

	function initVariationSwatches() {
		var forms = document.querySelectorAll( '.zymarg-pdp form.variations_form' );
		if ( ! forms.length ) {
			return;
		}

		forms.forEach( function ( form ) {
			var selects = form.querySelectorAll( '.variations select' );
			selects.forEach( buildSwatches );

			function resyncAll() {
				form.querySelectorAll( '.variations select' ).forEach( function ( select ) {
					if ( select._zymargSwatchWrap ) {
						syncSelected( select, select._zymargSwatchWrap );
						syncDisabled( select, select._zymargSwatchWrap );
					}
				} );
				// Re-add steppers in case WooCommerce re-rendered the qty box.
				initQuantitySteppers( form );
			}

			// Native fallback.
			selects.forEach( function ( select ) {
				select.addEventListener( 'change', resyncAll );
			} );

			// WooCommerce variation lifecycle events (jQuery).
			if ( window.jQuery ) {
				window.jQuery( form ).on(
					'woocommerce_update_variation_values woocommerce_variation_has_changed found_variation reset_data check_variations update_variation_values',
					function () {
						// Defer so WooCommerce finishes toggling option states first.
						setTimeout( resyncAll, 0 );
					}
				);
			}

			resyncAll();
		} );
	}

	onReady( function () {
		initQuantitySteppers( document );
		initVariationSwatches();
	} );
}() );
