/**
 * ZYMARG OS — Front-end behaviours
 * -----------------------------------------------------------------------------
 * Vanilla JS, no jQuery dependency. Powers:
 *   - Scroll-to-top button
 *   - Sticky / advanced menu state (adds a class on scroll)
 *   - Mega menu (keyboard + touch friendly)
 *   - Off-canvas cart drawer
 *   - Sticky add-to-cart visibility (WooCommerce)
 *
 * Config is passed from PHP via the global `ZymargOS` object (see inc/enqueue.php).
 */
( function () {
	'use strict';

	var config = window.ZymargOS || {};

	function onReady( fn ) {
		if ( document.readyState !== 'loading' ) {
			fn();
		} else {
			document.addEventListener( 'DOMContentLoaded', fn );
		}
	}

	/* ---- Scroll to top ------------------------------------------------ */
	function initScrollToTop() {
		var btn = document.querySelector( '.zymarg-scroll-top' );
		if ( ! btn ) {
			return;
		}

		var threshold = parseInt( config.scrollTopOffset, 10 ) || 400;
		var ring = btn.querySelector( '.zymarg-scroll-top__ring-bar' );

		function update() {
			var y = window.pageYOffset;

			if ( y > threshold ) {
				btn.classList.add( 'is-visible' );
			} else {
				btn.classList.remove( 'is-visible' );
			}

			// Update the scroll-progress ring (if present).
			if ( ring ) {
				var doc = document.documentElement;
				var max = doc.scrollHeight - doc.clientHeight;
				var pct = max > 0 ? Math.min( 100, Math.max( 0, ( y / max ) * 100 ) ) : 0;
				ring.style.strokeDashoffset = ( 100 - pct ).toFixed( 2 );
			}
		}

		window.addEventListener( 'scroll', update, { passive: true } );
		window.addEventListener( 'resize', update, { passive: true } );
		btn.addEventListener( 'click', function ( e ) {
			e.preventDefault();
			window.scrollTo( { top: 0, behavior: 'smooth' } );
		} );

		update();
	}

	/* ---- Sticky menu state -------------------------------------------- */
	function initStickyMenu() {
		var targets = document.querySelectorAll( '.zymarg-sticky' );
		if ( ! targets.length ) {
			return;
		}

		function toggle() {
			var scrolled = window.pageYOffset > 20;
			targets.forEach( function ( el ) {
				el.classList.toggle( 'is-stuck', scrolled );
			} );
		}

		window.addEventListener( 'scroll', toggle, { passive: true } );
		toggle();
	}

	/* ---- Mega menu ---------------------------------------------------- */
	function initMegaMenu() {
		var items = document.querySelectorAll( '.menu-item-has-children, .zymarg-mega-menu' );
		if ( ! items.length ) {
			return;
		}

		items.forEach( function ( item ) {
			var link = item.querySelector( 'a' );
			if ( ! link ) {
				return;
			}

			// Touch / click toggle on small screens.
			link.addEventListener( 'click', function ( e ) {
				if ( window.innerWidth <= 1024 && item.querySelector( '.sub-menu, .zymarg-mega-menu__panel' ) ) {
					e.preventDefault();
					item.classList.toggle( 'is-open' );
				}
			} );

			// Keyboard accessibility.
			item.addEventListener( 'focusin', function () {
				item.classList.add( 'is-focused' );
			} );
			item.addEventListener( 'focusout', function ( e ) {
				if ( ! item.contains( e.relatedTarget ) ) {
					item.classList.remove( 'is-focused' );
				}
			} );
		} );
	}

	/* ---- Off-canvas cart ---------------------------------------------- */
	function initCartDrawer() {
		var drawer = document.querySelector( '.zymarg-cart-drawer' );
		var overlay = document.querySelector( '.zymarg-drawer__overlay' );
		var openers = document.querySelectorAll( '.zymarg-cart-toggle' );

		if ( ! drawer ) {
			return;
		}

		function open() {
			drawer.classList.add( 'is-open' );
			if ( overlay ) {
				overlay.classList.add( 'is-open' );
			}
			document.body.style.overflow = 'hidden';
		}

		function close() {
			drawer.classList.remove( 'is-open' );
			if ( overlay ) {
				overlay.classList.remove( 'is-open' );
			}
			document.body.style.overflow = '';
		}

		openers.forEach( function ( opener ) {
			opener.addEventListener( 'click', function ( e ) {
				e.preventDefault();
				open();
			} );
		} );

		if ( overlay ) {
			overlay.addEventListener( 'click', close );
		}

		var closeBtn = drawer.querySelector( '.zymarg-drawer__close' );
		if ( closeBtn ) {
			closeBtn.addEventListener( 'click', close );
		}

		document.addEventListener( 'keyup', function ( e ) {
			if ( e.key === 'Escape' ) {
				close();
			}
		} );
	}

	onReady( function () {
		initScrollToTop();
		initStickyMenu();
		initMegaMenu();
		initCartDrawer();
	} );
}() );


/* ---- Quick View (WooCommerce) ---------------------------------------- */
( function () {
	'use strict';

	var config = window.ZymargOS || {};

	function ready( fn ) {
		if ( document.readyState !== 'loading' ) {
			fn();
		} else {
			document.addEventListener( 'DOMContentLoaded', fn );
		}
	}

	ready( function () {
		var modal = document.querySelector( '#zymarg-quick-view' );
		if ( ! modal || ! config.ajaxUrl ) {
			return;
		}

		var body = modal.querySelector( '.zymarg-modal__body' );
		var triggers = document.querySelectorAll( '.zymarg-quick-view' );

		function openModal() {
			modal.classList.add( 'is-open' );
			document.body.style.overflow = 'hidden';
		}

		function closeModal() {
			modal.classList.remove( 'is-open' );
			document.body.style.overflow = '';
			if ( body ) {
				body.innerHTML = '';
			}
		}

		triggers.forEach( function ( trigger ) {
			trigger.addEventListener( 'click', function () {
				var id = trigger.getAttribute( 'data-product-id' );
				if ( ! id || ! body ) {
					return;
				}

				body.innerHTML = '<p class="zymarg-modal__loading">' + ( config.loadingText || 'Loading…' ) + '</p>';
				openModal();

				var params = new URLSearchParams();
				params.append( 'action', 'zymarg_quick_view' );
				params.append( 'product_id', id );

				fetch( config.ajaxUrl, {
					method: 'POST',
					headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
					body: params.toString()
				} )
					.then( function ( res ) { return res.json(); } )
					.then( function ( json ) {
						if ( json && json.success && json.data && json.data.html ) {
							body.innerHTML = json.data.html;
						} else {
							body.innerHTML = '<p>' + ( config.errorText || 'Unable to load product.' ) + '</p>';
						}
					} )
					.catch( function () {
						body.innerHTML = '<p>' + ( config.errorText || 'Unable to load product.' ) + '</p>';
					} );
			} );
		} );

		modal.querySelectorAll( '.zymarg-modal__close, .zymarg-modal__overlay' ).forEach( function ( el ) {
			el.addEventListener( 'click', closeModal );
		} );

		document.addEventListener( 'keyup', function ( e ) {
			if ( e.key === 'Escape' ) {
				closeModal();
			}
		} );
	} );
}() );
