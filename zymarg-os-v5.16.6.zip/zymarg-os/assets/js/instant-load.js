/**
 * ZYMARG OS — Instant Load.
 * Prefetches an internal page when the visitor hovers (or taps) a link, so the
 * actual click loads almost instantly. Conservative: same-origin only, skips
 * cart/checkout/account/admin/add-to-cart/downloads, and prefetches each URL
 * once. Uses the browser's native <link rel="prefetch">.
 */
( function () {
	'use strict';

	var test = document.createElement( 'link' );
	if ( ! ( test.relList && test.relList.supports && test.relList.supports( 'prefetch' ) ) ) {
		return;
	}
	// Respect Save-Data / slow connections.
	var conn = navigator.connection;
	if ( conn && ( conn.saveData || /2g/.test( conn.effectiveType || '' ) ) ) {
		return;
	}

	var done = {};
	var timer;
	var SKIP = /add-to-cart=|\/cart|\/checkout|\/wp-admin|wp-login|\/my-account|logout|\?s=|\?add_to_wishlist/;

	function prefetch( url ) {
		if ( done[ url ] ) {
			return;
		}
		done[ url ] = true;
		var link = document.createElement( 'link' );
		link.rel = 'prefetch';
		link.href = url;
		document.head.appendChild( link );
	}

	function eligible( a ) {
		if ( ! a || ! a.href || a.origin !== location.origin ) {
			return false;
		}
		if ( a.hasAttribute( 'download' ) || a.getAttribute( 'rel' ) === 'nofollow' ) {
			return false;
		}
		if ( a.pathname === location.pathname && a.hash ) {
			return false;
		}
		if ( SKIP.test( a.href ) ) {
			return false;
		}
		return true;
	}

	document.addEventListener( 'mouseover', function ( e ) {
		var a = e.target.closest ? e.target.closest( 'a' ) : null;
		if ( ! eligible( a ) ) {
			return;
		}
		clearTimeout( timer );
		timer = setTimeout( function () { prefetch( a.href ); }, 65 );
	}, { passive: true } );

	document.addEventListener( 'mouseout', function () {
		clearTimeout( timer );
	}, { passive: true } );

	document.addEventListener( 'touchstart', function ( e ) {
		var a = e.target.closest ? e.target.closest( 'a' ) : null;
		if ( eligible( a ) ) {
			prefetch( a.href );
		}
	}, { passive: true } );
}() );
