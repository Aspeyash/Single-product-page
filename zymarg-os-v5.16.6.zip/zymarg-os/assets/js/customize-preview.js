/**
 * ZYMARG OS — Customizer live preview.
 * Updates colour CSS variables in real time without a refresh.
 */
( function () {
	'use strict';

	if ( typeof wp === 'undefined' || ! wp.customize ) {
		return;
	}

	var map = {
		zymarg_color_primary:           '--color-primary',
		zymarg_color_primary_container: '--color-primary-container',
		zymarg_color_on_primary:        '--color-on-primary',
		zymarg_color_on_primary_fixed:  '--color-on-primary-fixed',
		zymarg_color_secondary:         '--color-secondary',
		zymarg_color_text_body:         '--color-text-body',
		zymarg_color_text_muted:        '--color-text-muted',
		zymarg_color_surface:           '--color-surface',
		zymarg_color_surface_container: '--color-surface-container',
		zymarg_color_outline_variant:   '--color-outline-variant'
	};

	Object.keys( map ).forEach( function ( settingId ) {
		wp.customize( settingId, function ( setting ) {
			setting.bind( function ( value ) {
				if ( value ) {
					document.documentElement.style.setProperty( map[ settingId ], value );
				}
			} );
		} );
	} );
}() );
