/**
 * ZYMARG OS — Unified Toast Notifications.
 *
 * One toast system for the whole theme. Public API:
 *
 *   ZymargToast.show({ title, message, type, duration, action })
 *   ZymargToast.success(message, opts)
 *   ZymargToast.error(message, opts)
 *   ZymargToast.info(message, opts)
 *   ZymargToast.warning(message, opts)
 *
 * Also listens for a DOM event so any script (or inline PHP output) can fire a
 * toast without a hard dependency:
 *
 *   document.dispatchEvent(new CustomEvent('zymarg:toast', { detail: {...} }));
 *
 * Built-in integrations (auto-wired): WooCommerce "added to cart", and the
 * native review-submitted confirmation. Wishlist/compare call the API directly.
 *
 * Config (optional) via window.ZymargToastCfg: { position, duration }.
 */
( function () {
	'use strict';

	var CFG = window.ZymargToastCfg || {};
	var POSITION = CFG.position || 'bottom-right';
	var DEFAULT_DURATION = CFG.duration || 3800;
	var region;

	var ICONS = {
		success: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg>',
		error:   '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M18 6 6 18M6 6l12 12"/></svg>',
		warning: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 9v4m0 4h.01M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/></svg>',
		info:    '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 16v-4m0-4h.01"/><circle cx="12" cy="12" r="9"/></svg>'
	};

	function esc( s ) {
		return String( s == null ? '' : s ).replace( /[&<>"']/g, function ( c ) {
			return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ c ];
		} );
	}

	function ensureRegion() {
		if ( region && document.body.contains( region ) ) { return region; }
		region = document.createElement( 'div' );
		region.className = 'zymarg-toast-region zymarg-toast-region--' + POSITION;
		region.setAttribute( 'role', 'region' );
		region.setAttribute( 'aria-live', 'polite' );
		region.setAttribute( 'aria-label', 'Notifications' );
		document.body.appendChild( region );
		return region;
	}

	function dismiss( el ) {
		if ( ! el || el.__leaving ) { return; }
		el.__leaving = true;
		el.classList.add( 'is-leaving' );
		el.classList.remove( 'is-visible' );
		setTimeout( function () {
			if ( el.parentNode ) { el.parentNode.removeChild( el ); }
		}, 280 );
	}

	function show( opts ) {
		opts = opts || {};
		if ( typeof opts === 'string' ) { opts = { message: opts }; }

		var type = opts.type || 'info';
		if ( ! ICONS[ type ] ) { type = 'info'; }
		var duration = ( typeof opts.duration === 'number' ) ? opts.duration : DEFAULT_DURATION;

		var root = ensureRegion();
		var el = document.createElement( 'div' );
		el.className = 'zymarg-toast zymarg-toast--' + type;
		el.setAttribute( 'role', type === 'error' ? 'alert' : 'status' );

		var html = '<span class="zymarg-toast__icon">' + ICONS[ type ] + '</span><div class="zymarg-toast__body">';
		if ( opts.title ) { html += '<p class="zymarg-toast__title">' + esc( opts.title ) + '</p>'; }
		if ( opts.message ) { html += '<p class="zymarg-toast__msg">' + esc( opts.message ) + '</p>'; }
		if ( opts.action && opts.action.label ) {
			if ( opts.action.url ) {
				html += '<a class="zymarg-toast__action" href="' + esc( opts.action.url ) + '">' + esc( opts.action.label ) + '</a>';
			} else {
				html += '<button type="button" class="zymarg-toast__action" data-toast-action>' + esc( opts.action.label ) + '</button>';
			}
		}
		html += '</div><button type="button" class="zymarg-toast__close" aria-label="Dismiss">&times;</button>';
		if ( duration > 0 ) {
			html += '<span class="zymarg-toast__bar"></span>';
		}
		el.innerHTML = html;

		el.querySelector( '.zymarg-toast__close' ).addEventListener( 'click', function () { dismiss( el ); } );
		var actionBtn = el.querySelector( '[data-toast-action]' );
		if ( actionBtn && opts.action && typeof opts.action.onClick === 'function' ) {
			actionBtn.addEventListener( 'click', function () { opts.action.onClick(); dismiss( el ); } );
		}

		root.appendChild( el );
		// Force reflow so the entrance transition runs.
		void el.offsetWidth;
		el.classList.add( 'is-visible' );

		if ( duration > 0 ) {
			var bar = el.querySelector( '.zymarg-toast__bar' );
			if ( bar ) {
				bar.style.transition = 'transform ' + duration + 'ms linear';
				void bar.offsetWidth;
				bar.style.transform = 'scaleX(0)';
			}
			var timer = setTimeout( function () { dismiss( el ); }, duration );
			// Pause on hover.
			el.addEventListener( 'mouseenter', function () {
				clearTimeout( timer );
				if ( bar ) { bar.style.transition = 'none'; }
			} );
			el.addEventListener( 'mouseleave', function () {
				timer = setTimeout( function () { dismiss( el ); }, 1200 );
				if ( bar ) { bar.style.transition = 'transform 1200ms linear'; void bar.offsetWidth; bar.style.transform = 'scaleX(0)'; }
			} );
		}

		return el;
	}

	var API = {
		show: show,
		success: function ( m, o ) { return show( Object.assign( { message: m, type: 'success' }, o || {} ) ); },
		error: function ( m, o ) { return show( Object.assign( { message: m, type: 'error' }, o || {} ) ); },
		info: function ( m, o ) { return show( Object.assign( { message: m, type: 'info' }, o || {} ) ); },
		warning: function ( m, o ) { return show( Object.assign( { message: m, type: 'warning' }, o || {} ) ); }
	};
	window.ZymargToast = API;

	// Generic event hook for decoupled callers (incl. server-printed inline JS).
	document.addEventListener( 'zymarg:toast', function ( e ) {
		show( e.detail || {} );
	} );

	/* ---- Built-in integrations -------------------------------------- */
	function ready( fn ) {
		if ( document.readyState !== 'loading' ) { fn(); } else { document.addEventListener( 'DOMContentLoaded', fn ); }
	}

	ready( function () {
		// WooCommerce: "added to cart" (jQuery event fired by WC).
		if ( window.jQuery ) {
			window.jQuery( document.body ).on( 'added_to_cart', function () {
				API.success( ( CFG.i18n && CFG.i18n.addedToCart ) || 'Added to cart', {
					action: CFG.cartUrl ? { label: ( CFG.i18n && CFG.i18n.viewCart ) || 'View cart', url: CFG.cartUrl } : null
				} );
			} );
		}

		// Native reviews: toast when the review form shows its success message.
		document.querySelectorAll( '.zymarg-review-form .zymarg-form-message' ).forEach( function ( node ) {
			if ( ! window.MutationObserver ) { return; }
			var mo = new MutationObserver( function () {
				var txt = ( node.textContent || '' ).trim();
				if ( txt && ! node.__toasted ) {
					node.__toasted = true;
					API.success( txt );
					setTimeout( function () { node.__toasted = false; }, 4000 );
				}
			} );
			mo.observe( node, { childList: true, characterData: true, subtree: true } );
		} );
	} );
}() );
