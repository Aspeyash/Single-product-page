/**
 * ZYMARG OS — Scroll reveal.
 * Reveals elements with the .zymarg-reveal class as they enter the viewport.
 * Progressive enhancement: if JS or IntersectionObserver is unavailable, or the
 * visitor prefers reduced motion, content stays fully visible (the hide rule is
 * only applied once the html.zymarg-reveal-on class is added below).
 */
( function () {
	'use strict';

	if ( ! ( 'IntersectionObserver' in window ) ) {
		return;
	}
	if ( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ) {
		return;
	}

	document.documentElement.classList.add( 'zymarg-reveal-on' );

	function init() {
		var els = document.querySelectorAll( '.zymarg-reveal' );
		if ( ! els.length ) {
			return;
		}

		var io = new IntersectionObserver( function ( entries ) {
			entries.forEach( function ( entry ) {
				if ( entry.isIntersecting ) {
					entry.target.classList.add( 'is-visible' );
					io.unobserve( entry.target );
				}
			} );
		}, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' } );

		els.forEach( function ( el ) {
			io.observe( el );
		} );
	}

	if ( document.readyState !== 'loading' ) {
		init();
	} else {
		document.addEventListener( 'DOMContentLoaded', init );
	}
}() );
