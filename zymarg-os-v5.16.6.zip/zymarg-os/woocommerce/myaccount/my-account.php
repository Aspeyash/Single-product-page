<?php
/**
 * My Account page — ZYMARG OS template override.
 *
 * Logged-in users: full custom sidebar + section-panel layout.
 * Logged-out users: empty page with the branded ZYMARG login POPUP that
 *                   force-opens after the configured delay.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

if ( ! is_user_logged_in() ) {
	// Logged-out: don't render any login form here. The popup (rendered via
	// wp_footer) will force-open. Just provide a placeholder background so
	// the page isn't blank if popup somehow doesn't fire.
	$acc_delay   = function_exists( 'zymarg_os_login_resolve_delay' ) ? (int) zymarg_os_login_resolve_delay() : 0;
	$acc_message = trim( (string) ( function_exists( 'zymarg_os_login_opt' ) ? zymarg_os_login_opt( 'account_message' ) : '' ) );
	if ( '' === $acc_message ) {
		$acc_message = __( 'Please sign in to access your account.', 'zymarg-os' );
	}
	?>
	<div class="zymarg-myaccount-loggedout" data-force-login-popup="1" data-force-delay="<?php echo esc_attr( $acc_delay ); ?>">
		<div class="zymarg-myaccount-loggedout__placeholder">
			<p><?php echo esc_html( $acc_message ); ?></p>
		</div>
	</div>
	<?php
	return;
}

// Logged-in: render the full ZYMARG custom layout.
?>
<div class="zymarg-myaccount-wrap">
	<button class="zymarg-acc-hamburger" id="zymarg-acc-hamburger" aria-label="<?php esc_attr_e( 'Open menu', 'zymarg-os' ); ?>">
		<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><polyline points="9 18 15 12 9 6"/></svg>
	</button>
	<div class="zymarg-acc-overlay" id="zymarg-acc-overlay"></div>
	<?php zymarg_os_account_sidebar(); ?>
	<div class="zymarg-acc-main">
		<div class="orb-1" aria-hidden="true"></div>
		<div class="orb-2" aria-hidden="true"></div>
		<div class="main-content">
			<?php
			if ( function_exists( 'woocommerce_output_all_notices' ) ) {
				woocommerce_output_all_notices();
			}
			$section = zymarg_os_account_active_section();
			if ( function_exists( 'zymarg_os_account_render_section' ) ) {
				zymarg_os_account_render_section( $section );
			} else {
				woocommerce_account_content();
			}
			?>
		</div>
		<?php zymarg_os_account_bottom_nav(); ?>
	</div>
</div>
