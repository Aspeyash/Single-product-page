<?php
/**
 * The template for displaying 404 (not found) pages.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

get_header();

zymarg_os_before_content();
?>
<div id="content" class="zymarg-container zymarg-site-content">
	<main id="main" class="zymarg-main zymarg-404">
		<section class="zymarg-card" style="text-align:center;">
			<h1 class="zymarg-404__code"><?php esc_html_e( '404', 'zymarg-os' ); ?></h1>
			<h2><?php esc_html_e( 'This page could not be found.', 'zymarg-os' ); ?></h2>
			<p class="zymarg-text-muted"><?php esc_html_e( 'The page you are looking for might have been moved or no longer exists.', 'zymarg-os' ); ?></p>

			<div class="zymarg-404__search">
				<?php get_search_form(); ?>
			</div>

			<p>
				<a class="zymarg-btn" href="<?php echo esc_url( home_url( '/' ) ); ?>">
					<?php esc_html_e( 'Back to home', 'zymarg-os' ); ?>
				</a>
			</p>
		</section>
	</main>
</div>
<?php
zymarg_os_after_content();

get_footer();
