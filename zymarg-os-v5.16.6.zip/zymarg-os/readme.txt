=== ZYMARG OS ===

Contributors: zymarg
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 5.16.1
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A lightweight, modular, page-builder-friendly WordPress theme built for
multivendor marketplaces (WooCommerce + Dokan), with the ZYMARG design system.

== Description ==

ZYMARG OS is intentionally minimal where it should be and powerful where it
matters. It ships WITHOUT a visual header or footer — those are managed by your
own ZYMARG plugin / page builder — and focuses on a fast, flexible foundation:

* Clean white base lit by two soft purple "orb" glows (the ZYMARG look).
* The full ZYMARG colour token system, exposed as CSS variables and as a
  block-editor / theme.json palette.
* Inter (body) + Sora (headings) typography.
* Modular architecture — turn features on/off so only the code you use loads.

= Features =

* Advanced Typography — per-element control: font source, base size, line
  height, heading weight, plus custom font family overrides.
* Advanced Colours — Customizer colour controls wired to CSS variables with a
  live preview.
* Spacing controls — content padding and max-width.
* Custom button styling — radius and token-driven colours.
* Mega Menu — multi-column dropdowns (add the `mega-menu` class to a menu item;
  use `mega-cols-2`..`mega-cols-6` to set columns) and sticky navigation.
* WooCommerce — shop grid columns, Quick View (AJAX), off-canvas cart drawer,
  sticky add-to-cart bar, gallery zoom/lightbox/slider, plus Dokan vendor-store
  styling.
* LearnDash / LMS — token-based accent styling, loaded only on LMS pages.
* Scroll to Top — accessible floating button.
* Custom Layout hooks — zymarg_os_body_open, zymarg_os_before_content,
  zymarg_os_content_top, zymarg_os_content_bottom, zymarg_os_after_content,
  zymarg_os_footer.
* White Label — rebrand the theme in the admin via the `zymarg_os_white_label`
  filter (agency mode).
* Performance — disables emojis, removes jQuery Migrate on the front end,
  trims unused block CSS, defers the theme script, and adds resource hints.

= Fonts =

Font Loading is set in Customize -> ZYMARG OS -> Typography:

1. Google Fonts (default) — optimised with preconnect hints + `display=swap`
   and only the weights used.
2. Self-host Inter + Sora — GDPR-friendly; drop .woff2 files into
   /assets/fonts (see assets/fonts/fonts.css for the file names).
3. Upload my own fonts — upload .woff2/.woff/.ttf files for headings and/or
   body; the theme generates the @font-face rules with `font-display: swap`.
4. System fonts — zero font requests.

== Installation ==

1. Upload the `zymarg-os` folder to /wp-content/themes/ (or install the zip via
   Appearance -> Themes -> Add New -> Upload Theme).
2. Activate the theme through the Themes menu in WordPress.
3. Go to Appearance -> Customize -> ZYMARG OS to configure modules, colours,
   typography, spacing and buttons.

== Changelog ==

= 5.16.1 — Fix: the sidebar order control was invisible on most sites =
* Fixed: the "Sidebar link order" control added in 5.16.0 did not appear. Its
  class was declared in inc/customize-controls.php, which functions.php only
  loads when the ZYMARG Login & Security plugin is INACTIVE — it is grouped with
  the theme's login fallback. On any site running that plugin the class never
  existed, so the control was silently skipped and My Account — Links showed
  only its three URL fields. The class now lives in inc/account-dashboard.php
  alongside the section it belongs to, which loads whenever WooCommerce is
  active — i.e. whenever there is a My Account page to order.
* Note: inc/customize-controls.php is byte-identical to 5.15.2 again. Nothing
  else changed; if you never saw the control, 5.16.0 behaved exactly like
  5.15.2.

= 5.16.0 — You choose the My Account sidebar order =
* New: Customize -> ZYMARG OS -> My Account — Links gained a "Sidebar link
  order" control. Drag a link into place, or move it with the arrow buttons,
  which also work by keyboard and on touch. The order applies to every
  customer's My Account page.
* New: filter `zymarg_os_account_nav_items`. The My Account sidebar array had
  never been filterable, so nothing outside the theme could reorder it — a
  plugin could only append a section next to an anchor via
  `zymarg_os_account_sections`. The assembled array now passes through this
  filter, keyed by slug.
* New: `zymarg_os_account_nav_config()` is now the single source of truth for
  the sidebar. Both the front end and the Customizer control read from it, so
  they can never disagree about which links exist.
* Note: the order is stored as a sparse weight map, not a rebuilt list, and the
  sort only ever reorders — it cannot add or drop a link. No section can be
  removed from a customer's account page by a saved order, including sections
  added later by a plugin. Keys are preserved, because the URL map, the active
  -section resolver and the section renderers all look up by slug.
* Note: only sections currently available are listed. One that appears later
  (e.g. after activating a plugin) is anchored to the link it naturally follows
  — so it shows up next to that link wherever you have moved it to, rather than
  at an unrelated slot.
* Note: with the setting untouched the sidebar is identical to 5.15.2.

= 5.15.2 — Help text now matches the code =
* Fixed: the Product Reviews help card called reviews "built-in" with "no plugin
  needed". They come from the ZYMARG Reviews Engine plugin, which has to be
  active. The card now says so.
* Fixed: it described a "15/30-day window" for writing a review. There is one
  setting, 15 days by default. Corrected.
* Fixed: it sent you to WooCommerce -> ZYMARG Reviews for settings. The engine
  registers its own top-level ZYMARG Reviews menu. Corrected.
* Fixed: it promised photos are "auto-compressed in the browser". Nothing does
  that. The theme file that once did was never enqueued and the engine has no
  equivalent, so the claim is gone rather than left to mislead.
* Removed: assets/js/review-image-compress.js and assets/css/admin-reviews.css.
  Neither was referenced by any file in the theme.

= 5.15.1 — Fixed: the My Account review surfaces =
* Fixed: the "Write Review" button in My Account -> Reviews -> Pending linked to
  the product page anchor #reviews, which is not where the review form lives.
  The button now builds its URL with the Reviews Engine's own
  Review_Tracker::get_review_url(), passing the order and order-item ids, so the
  link carries the nonce the form needs and lands on the form itself. If the
  engine is not active the old permalink is used as a fallback.
* Fixed: the Pending tab listed items the buyer could no longer review. It now
  skips orders outside the engine's review window and hides individual items
  that already have a review, instead of only de-duplicating by product.
* Fixed: the My Reviews tab queried approved comments only, so a review held for
  moderation vanished from the buyer's own list with no explanation. Pending
  reviews are now listed and badged "Awaiting approval"; spam and trashed
  comments stay hidden.
* Fixed: a review with no rating rendered as an empty star badge. It now reads
  "No rating".
* Changed: the Pending tab scanned the 10 most recent orders and My Reviews
  showed 20 entries. Both are now 50 and filterable via
  zymarg_os_pending_reviews_order_limit and zymarg_os_my_reviews_limit.
* Housekeeping: Stable tag in readme.txt was stuck at 5.12.20 while style.css
  had reached 5.15.0; both now track the same number.

= 5.12.20 — Changed: squared the sidebar's right edge in Messages =
* Changed: .zymarg-acc-sidebar no longer rounds its top-right and bottom-right
  corners while the Messages section is active. The sidebar rounds those
  corners so it reads as a panel floating against the page, which works
  wherever the content column has a gutter. In Messages the gutter is 0 and the
  inbox now squares its own outer frame, so those two curves peeled away from
  the flush edge and showed small notches of background at the sidebar's top
  and bottom corners.
* Scoped: the rule is keyed to body.zymarg-acc-section-messages, so every other
  account panel keeps the rounded sidebar exactly as it is. It is also wrapped
  in min-width: 768px, because below that the sidebar is an off-canvas drawer
  and is not adjacent to the content at all.
* Unchanged (deliberately): the sidebar width stays 260px, and its padding,
  gap, background and border-right are untouched. Only the two corner radii on
  the side that touches the inbox change.
* Note: pairs with ZYMARG Communication 1.25.2, which squares the inbox's own
  outer frame. Install both together.

= 5.12.19 — Fixed: section body class now stays in sync over AJAX =
* Fixed: the zymarg-acc-section-* body class was only emitted by PHP on a full
  page load, but the My Account page swaps sections over AJAX. Any styling
  keyed to that class therefore applied on a hard refresh and then silently
  stopped matching once the visitor navigated between sections, so panels
  looked correct after a reload and wrong after a click.
* Added: assets/js/account.js now strips any existing zymarg-acc-section-*
  class and applies the one for the newly loaded section, keying off the same
  sanitised section slug PHP uses, so both paths always agree.

= 5.12.18 — Changed: one consistent gutter for every My Account panel =
* Removed: the 960px max-width and the margin: 0 auto centering on
  .zymarg-acc-main .main-content. That pair made panel alignment depend on the
  viewport: on a wide screen the column floated in the middle of the main area,
  while on a laptop the cap never engaged and the panel ran flush against the
  sidebar with only its padding in between. Panels now start at the same
  distance from the sidebar at every screen width.
* Changed: the column gutter is now a flat 16px on mobile and 24px from 768px
  up, replacing 2rem 1rem / 2.5rem 2rem. Horizontal and vertical spacing match,
  so cards, tables and forms sit on one predictable grid.
* Unchanged (deliberately): the Messages panel keeps padding 0 and remains
  edge-to-edge. It hosts a chat UI that supplies its own internal padding, so a
  column gutter around it only produced a dead gap.
* Unchanged (deliberately): the 260px sidebar, and the body-class mechanism
  added in 5.12.17.

= 5.12.17 — Changed: the My Account Messages panel is now edge-to-edge =
* Added: the active account section is now exposed as its own body class, for
  example zymarg-acc-section-messages or zymarg-acc-section-orders. This lets a
  single panel opt out of shared layout rules in plain CSS, with no reliance on
  the :has() selector, so it behaves the same in every browser.
* Changed: on the Messages panel only, .main-content now uses padding 0 and
  max-width none, on both mobile and desktop. The messaging UI owns its own
  internal padding, so the column padding around it (2rem 1rem on mobile,
  2.5rem 2rem on desktop) was only producing a dead gap around the chat box.
* Unchanged (deliberately): every other panel — Dashboard, Orders, Downloads,
  Addresses, Account Details and the rest — keeps the original 2rem 1rem /
  2.5rem 2rem padding and its existing reading width. Nothing about them moves.
* Unchanged (deliberately): the 260px account sidebar. Its width, padding,
  sticky positioning, border and z-index are all untouched. .main-content sits
  inside .zymarg-acc-main, which is a flex sibling of the sidebar, so the
  widened panel can only expand into the space to the right of the sidebar and
  is structurally incapable of overlapping it.

= 5.12.16 — Removed: built-in sticky add-to-cart bar (single product) =
* Removed: the theme's sticky add-to-cart bar on single product pages, for sites
  that use a dedicated plugin for this. Deleted zymarg_os_sticky_add_to_cart()
  and its zymarg_os_footer hook (inc/woocommerce.php), initStickyAddToCart() and
  its onReady() call (assets/js/theme.js), and the .zymarg-sticky-atc styles
  (woocommerce/product.css). The zymarg_os_enable_sticky_atc filter is gone too,
  since it no longer has anything to gate.
* Changed: the WooCommerce module description and the Theme Help page no longer
  advertise sticky add-to-cart.
* UNCHANGED: everything else in the WooCommerce module — Quick View, the
  off-canvas cart drawer and its live fragment updates, gallery zoom/lightbox,
  shop columns and Dokan styling. The normal WooCommerce add-to-cart button on
  the product page is untouched, as is the "Added to cart" toast.

= 5.12.15 — Removed: built-in Live Search, and the legacy Wishlist module toggle =
* Removed: the Live Search feature in full — the [zymarg_search] shortcode, the
  zymarg_live_search AJAX handlers (priv + nopriv), the ZymargSearch script
  localisation, the trending/recent searches tracker
  (zymarg_os_record_trending_search, zymarg_os_maybe_record_trending,
  zymarg_os_get_trending_searches and the zymarg_os_search_trending option),
  plus assets/js/live-search.js and assets/css/search.css. Search-as-you-type is
  now handled by a dedicated plugin.
* Removed: the "Live Search" module from the Modules registry, so the toggle no
  longer appears under Customize → ZYMARG OS → Modules.
* Removed: the dead "Wishlist (removed in v5.7.6)" module toggle, which had been
  kept for backward compatibility since v5.7.6 but had no effect.
* UNCHANGED (deliberately): the My Account → Wishlist tab, its WooCommerce
  endpoint and query var, the zymarg_os_account_wishlist_content filter and the
  "Wishlist Integration" Customizer section all remain, so third-party wishlist
  plugins keep working exactly as before.
* UNCHANGED: searchform.php and search.php (the standard search form and the
  search results template) are untouched — normal WordPress/WooCommerce search
  still works, including the sorting bar and product-grid delegation.
* Note: inc/smart-ux.php now ships only Instant Load + Scroll Animations.

= 5.12.14 — Fix: admin login blocked in Coming Soon/Maintenance mode; AJAX gate missing login actions; rate-limit XFF spoofing =
* Fix: wp-login.php and /wp-admin/ were intercepted by the Coming Soon/Maintenance
  placeholder before WordPress could establish a session, permanently locking out
  any admin who was not already logged in. Both are now whitelisted before the
  capability check in zymarg_os_maybe_show_placeholder().
* Fix: The AJAX gate (zymarg_os_ajax_gate) only whitelisted 'wp_check_password' and
  'heartbeat'. The three unauthenticated AJAX actions used by the branded login card
  — zymarg_lost_password, zymarg_register_user, zymarg_get_nonce — were silently
  blocked in non-live modes, breaking password reset, registration, and nonce refresh.
  All three are now added to the $safe_actions whitelist.
* Security: zymarg_os_get_client_ip() read HTTP_X_FORWARDED_FOR unconditionally as a
  fallback, allowing any client to forge the header and rotate fake IPs to bypass the
  rate limit on registration and lost-password. XFF is now only trusted when
  REMOTE_ADDR is a private/loopback address (a reliable signal that a trusted reverse
  proxy is in front). CF-Connecting-IP and X-Real-IP are unaffected.

= 5.12.13 — Security: REST API and AJAX gate for Site Mode; clarify Custom HTML asset loading =
* Fix: REST API requests from unauthenticated visitors are now blocked (403 / 503)
  when Site Mode is Coming Soon or Maintenance. Admins and whitelisted core routes
  (/oembed/, /wp/v2/themes, /wp/v2/plugins) always pass through.
* Fix: Unauthenticated nopriv AJAX requests are now blocked when Site Mode is active.
  Logged-in users (vendors, customers) and safe core actions (heartbeat) are
  always passed through — no impact on WooCommerce or Dokan sessions.
* Fix: rest_pre_dispatch registered with correct 3-argument signature so the
  WP_REST_Request object is received and $request->get_route() used reliably
  (previous approach via $GLOBALS['wp']->query_vars was unreliable at REST time).
* Improvement: Custom HTML Customizer description now explicitly states the theme
  stylesheet is not loaded in Custom HTML layout — inline your own <style> tags.

= 5.12.12 — Fix: "My Account — Links" section was missing from the ZYMARG OS panel since it was first written =
* Fixes a long-standing bug: the "My Account — Links" Customizer section
  (Contact/Support URL, Help Center URL, Track Order URL) was registered
  WITHOUT a `panel` argument, so it has always rendered as a stray top-level
  Customizer item (alongside Site Identity, Menus, Widgets, etc.) instead of
  nested inside "ZYMARG OS", since the section was first added.
* Fix: added `'panel' => 'zymarg_os_panel'` to the add_section() call in
  inc/account-dashboard.php. No setting keys changed, so all saved
  Contact/Help/Track-order URLs carry over unchanged.
* Audited every OTHER add_section() call in the theme (9 total) to confirm
  none of them have this same missing-panel bug — all others already had the
  panel argument from the start.
* Unrelated to, and independent of, the separate Login-section registration-
  order fix shipped in the ZYMARG Login & Security plugin v1.7.0.

= 5.12.11 — CRITICAL FIX: fatal "Class WP_Customize_Control not found" on every page (introduced in 5.12.10) =
* Fixes a site-crashing fatal error introduced in v5.12.10:
  `Uncaught Error: Class "WP_Customize_Control" not found in
  inc/login-fallback-notice.php`.
* ROOT CAUSE: the new Zymarg_Customize_Login_Source_Status_Control class was
  declared at the TOP LEVEL of inc/login-fallback-notice.php — a file that is
  ALWAYS loaded on every request (not just the Customizer). `extends
  WP_Customize_Control` executed immediately on load, but that core class
  only exists while the Customizer is bootstrapping — it is NOT available on
  regular admin pages (Dashboard, Plugins, etc.) or the front end. Any normal
  page load fataled the entire site.
* FIX: the class definition now lives INSIDE a function
  (zymarg_os_register_login_source_status_control()) that is only ever
  invoked from a `customize_register` callback (priority 1, guaranteed to run
  before the status control is instantiated at the default priority), guarded
  by `class_exists( 'WP_Customize_Control' )` first — the exact same safe
  pattern the theme's own inc/customize-controls.php has always used. This is
  the standard, safe way to define custom Customizer control classes in
  WordPress.
* No functional change to the feature itself — the status card, alert email
  field, email notifications and wp-admin notice all work exactly as
  documented in 5.12.9/5.12.10, just without crashing the site.
* If your site is currently down from this bug: rename (don't delete)
  inc/login-fallback-notice.php via SFTP/FTP to disable it immediately, then
  upload this version to replace the whole theme.

= 5.12.10 — Live login-source status readout in Customize -> ZYMARG OS -> Login =
* New: a read-only status card at the TOP of the Login Customizer section
  showing, right now, which system is running your login screen — a green dot
  + "Plugin is running your login screen" when the ZYMARG Login & Security
  plugin is active, or a red dot + "Theme fallback is running your login
  screen" when it isn't. Each state includes a one-line explanation of what's
  on/off.
* This is a STATUS READOUT, not a toggle. Which system runs login is decided
  automatically by whether the plugin is active or not — a manual on/off here
  could leave the site with no login screen at all if both were switched off.
  Instead, the card links straight to the Plugins page, which is the one place
  that actually controls it.
* Lets you check the current state on demand from Customize -> ZYMARG OS ->
  Login, in addition to the email + wp-admin notification you already get
  automatically whenever it changes.
* New class Zymarg_Customize_Login_Source_Status_Control (registered by
  inc/login-fallback-notice.php, always loaded, so it's reachable regardless
  of which system is currently running login).

= 5.12.9 — Login source alerts on TWO channels: email + a native wp-admin notification =
* New: "Login source alert email" field under Customize -> ZYMARG OS -> Login.
  Type your address there once — no PHP, no wp-config editing, no
  update_option()/add_filter() snippets required. Leave blank to use the site
  admin email (unchanged default behaviour).
* This field is registered directly by inc/login-fallback-notice.php, which is
  ALWAYS loaded (unlike inc/login.php, which only loads when the plugin is
  inactive) — so the field is reachable in the Customizer no matter which
  system (plugin or theme) is currently running login.
* Recipient resolution order: Customizer field -> legacy
  zymarg_os_login_source_email option (for anyone who set it via code before
  this field existed) -> site admin email -> `zymarg_os_login_source_email`
  filter (still available for advanced overrides).
* NEW SECOND CHANNEL: a native, dismissible wp-admin notice now appears on
  EVERY wp-admin screen whenever the login source is different from what you
  last dismissed — green "Plugin active" success notice, or yellow "Theme
  fallback" warning notice with a direct link to Plugins. This is INDEPENDENT
  of the email: dismissing the notice does not silence future emails, and vice
  versa. The notice reappears automatically the next time the source changes.
* Dismissing uses a tiny AJAX call (wp_ajax_zymarg_os_ack_login_notice,
  nonce-protected + capability-gated to `activate_plugins`) so the
  acknowledgement persists across page loads instead of re-appearing on every
  screen until the browser tab is closed.

= 5.12.8 — Login source monitor: emails you WHICH system is running (plugin or theme) on every change =
* Rewrite of the login-fallback-notice.php into a full bi-directional "login
  source monitor". Two distinct email notifications:
  - Plugin takes over → "[Site] Login is now running via ZYMARG Login & Security
    plugin" (confirms full features are active, theme code not loaded).
  - Theme fallback takes over → "[Site] Login is running on the THEME fallback"
    (lists what's off, links to Plugins page to reactivate).
* Emails fire ONCE per state change — you get one email when the source switches
  from plugin→theme or theme→plugin. No repeats while the state stays the same.
* On first-ever install: saves state silently (no email — avoids a false alarm
  before you've ever had the plugin).
* Recipient: option `zymarg_os_login_source_email` (set it to your specific
  address), falls back to `admin_email`. Filterable via
  `zymarg_os_login_source_email`.
* Kill-switch: `zymarg_os_login_source_notify_enabled` filter (default true).
* Subject/body customizable via filters `zymarg_os_login_source_email_subject`
  and `zymarg_os_login_source_email_body`.
* Admin notice (dismissible, yellow) still shows while theme fallback is active.

= 5.12.7 — Login/session now a fallback (defers to "ZYMARG Login & Security" plugin) + fallback email alert =
* Change: the theme's built-in login experience (inc/login.php: branded login
  card, first-visit popup, wp-login.php branding, login redirects and AJAX)
  and session control (inc/session-control.php: auth-cookie lifetimes) are now
  loaded ONLY as a fallback. When the "ZYMARG Login & Security" plugin is active
  (detected via its ZLS_VERSION constant), the theme no longer parses these
  files at all — eliminating redundant code and any chance of function-name
  collisions with the plugin. The plugin uses identical Customizer keys, so the
  "Login" section and every saved value carry over with zero migration.
* Change: inc/customize-controls.php (the page-checkbox / per-page-delay
  Customizer controls, used only by the theme login section) is loaded under
  the same fallback condition.
* New: inc/login-fallback-notice.php — a tiny always-loaded monitor. If the
  plugin that was previously active becomes inactive (deactivated/deleted) and
  the theme login fallback takes over, it emails the site administrator ONCE
  and shows a dismissible wp-admin notice. It never false-alarms on a fresh
  theme-only install (only fires if the plugin was seen active before), and it
  resets automatically when the plugin is reactivated. Recipient filterable via
  `zymarg_os_login_fallback_email`; feature toggle via
  `zymarg_os_login_fallback_notify_enabled`; body via
  `zymarg_os_login_fallback_email_body`.
* When the plugin is active this release is behaviour-identical to 5.12.6 on the
  front end (the plugin was already rendering login/session).

= 5.12.0 — Payments moved into the standalone "ZYMARG Wallet" plugin + new account-section extension API =
* Change: the My Account → Payments feature (saved payment methods — bKash,
  Nagad, Rocket, Card, Bank) has been REMOVED from the theme and now ships as
  a standalone plugin, "ZYMARG Wallet". Install + activate that plugin to get
  the Payments section back. Your saved methods are NOT lost — the plugin reads
  the exact same user-meta store, and the same Customize → ZYMARG OS → Payments
  toggles, so everything reappears unchanged once the plugin is active.
* New: a generic, reusable account-section extension API. Companion plugins can
  now register their own My Account sidebar sections (item + endpoint + panel)
  via the `zymarg_os_account_sections` filter — no theme edits required. Each
  definition supports label, icon (icon key or raw inline SVG), endpoint, the
  sidebar anchor to insert after, a render callback, and an enabled flag. The
  filter is wired into endpoints, query vars, active-section detection, the
  sidebar, the URL map, the section dispatcher and the SPA AJAX loader.
* Result: the theme is lighter and free of payments-specific code, and the
  ZYMARG Wallet plugin (and future plugins) plug in cleanly. When no such
  plugin is active, the My Account sidebar is exactly as it was before.

= 5.11.10 — Payments empty-state: force two centered lines =
* The Payments empty state now renders on exactly two centered lines:
  "No payment methods saved yet." / "Add your first one." (hard line break
  instead of relying on natural wrapping).

= 5.11.9 — Fix: centered empty-state text =
* Fix: the My Account empty-state messages (e.g. "No payment methods saved
  yet. Add your first one.") now render as a tidy, centered block — the
  icon + text stack and centre via flexbox, and the paragraph is width-
  constrained with balanced wrapping so a two-line message reads cleanly
  in the middle. Applies to every account section's empty state.

= 5.11.8 — New: My Account → Payments (saved payment methods) =
* New: a "Payments" item in the My Account sidebar (directly under Addresses)
  where customers can save, edit, delete and set-default their own payment
  methods — bKash, Nagad, Rocket, Card and Bank Account. Stored in user meta.
* Security: for cards, only the last 4 digits, expiry and cardholder name are
  stored — never the full card number (PAN) or CVV.
* Admin control: Customize → ZYMARG OS → Payments adds a master toggle to
  show/hide the whole section, plus a per-type toggle for each of the 5 method
  types, so any method can be hidden from customers.
* Adds a version-keyed rewrite-rule flush so the new /my-account/payments/
  endpoint resolves after an in-place upgrade without re-saving permalinks.
* Files: new inc/account-payments.php; wiring in inc/account-dashboard.php,
  inc/account-sections.php, functions.php; styles in woocommerce/account.css;
  form JS in assets/js/account.js.

= 5.8.14 — Fix: My Account "View order" now works =
* Fix: clicking "View" on an order in My Account showed nothing because the
  custom account router didn't recognise WooCommerce's order sub-endpoints
  (view-order, order-received, order-pay, add-payment-method) and fell through
  to the Dashboard. Those endpoints now render WooCommerce's real order-detail
  content inside the branded My Account shell, with the "Orders" sidebar item
  kept active.

= 5.8.13 — Fix: theme version constant now auto-reads from style.css =
* Fix: ZYMARG_OS_VERSION was hardcoded as '5.8.1' in functions.php since
  v5.8.1 was released, so the admin welcome page badge + help page badge
  + asset cache-busting query string had all drifted 11 versions out of
  sync with the actual style.css version. Constant now reads from
  style.css's "Version:" header via get_file_data() at runtime, so all
  consumers always reflect the real shipped version. Style.css is now
  the single source of truth for theme version.

= 5.8.12 — Kill orb gradients in LIGHT mode (dark mode untouched) =
* Tweak: Both orb systems (site-wide in layouts/section.css + My Account-
  specific in woocommerce/account.css) are now hidden in light mode for a
  clean flat-white look. Dark mode keeps both orb systems exactly as before
  — soft purple atmospheric glow gives the dark UI its character.
* Tokens: --zymarg-orb-1-color and --zymarg-orb-2-color set to transparent
  in tokens/colors.css. tokens/dark.css UNCHANGED, so the dark overrides
  flow through automatically.
* Selector pattern matches tokens/dark.css, so the auto-mode-on-dark-OS
  edge case shows orbs correctly without any extra config.

= 5.8.11 — Dark-mode toggle switch in My Account sidebar =
* New: [zymarg_theme_switch] shortcode — a binary slider-switch styled
  control (matching the rest of the theme's toggle switches) that flips
  between light and dark mode. Shares state with the existing icon-button
  variant [zymarg_theme_toggle], so they stay in sync if both are used.
* My Account: the dark-mode switch now sits in the sidebar between the
  divider and the Logout button. Buyers can flip dark mode without
  leaving their account area.
* Inline CSS is printed in wp_head so the switch is styled on every
  page (including the Vendor Dashboard plugin page, where it can be
  embedded with the same shortcode).

= 5.8.10 — Website background → pure white =
* Tweak: --color-surface (the page background token) changed from
  #f8f9ff (very faint purple tint) to #ffffff (pure white). All
  other tokens unchanged. The two purple background orbs may still
  be visible — observation pass before next iteration.

= 5.8.9 — Fix: dashboard cards weren't clickable =
* Fix: The 5 dashboard cards (Recent Orders / Wishlist / Recently Viewed /
  Notifications / Vouchers) were silently swallowing clicks. The
  drag-to-scroll JS was adding the .is-grabbing class on EVERY mousedown,
  which activated `pointer-events: none` on the cards via CSS — so the
  click registered on the parent .dash-cards and the click handler's
  closest('.dash-card[data-goto]') returned null, exiting silently.
* Now: .is-grabbing only kicks in after 8px of movement (a real drag).
  Plain clicks pass through cleanly. A separate capture-phase click
  handler suppresses the trailing click that follows a real drag, so
  dragging horizontally never accidentally opens a section either.

= 5.8.8 — My Account avatar: camera icon nudged 5px up =
* Tweak: Camera button on the sidebar avatar moved 5px upward
  (bottom 3px -> 8px) for better visual balance against the avatar.

= 5.8.7 — My Account avatar: tap-anywhere on mobile + repaired LATEST.md =
* UX: On touch devices, the camera overlay now stays hidden when a photo
  is set (same clean look as desktop). Tapping anywhere on the avatar
  opens the picker — so mobile vendors can still change or remove their
  photo with a single tap, no hover required.
* Repo: LATEST.md was stale at v5.8.5 due to a missed edit during the
  v5.8.6 commit. Updated to reflect v5.8.7.

= 5.8.6 — My Account avatar: Remove photo + hover-reveal camera =
* New: "Remove photo" option in the avatar picker — only shows when the
  user has actually uploaded a photo. Confirms via dialog, then deletes the
  attachment + clears user meta, and the avatar instantly reverts to the
  default Gravatar.
* UX: When a photo is set, the camera overlay now FADES out (instead of
  hard hide) and FADES back in on hover/focus — so users can always change
  or remove their photo. On touch devices (no hover), the camera stays
  visible.
* Backend: new AJAX endpoint `zymarg_remove_avatar` that mirrors the upload
  endpoint's nonce + permission model; non-destructive — only the avatar's
  own attachment + user meta are touched.

= 5.8.5 — My Account avatar: tighter camera icon =
* Tweak: Camera button scaled down ~20% (36px -> 28px button, 20px -> 16px
  SVG) and nudged down 5px (bottom: 8px -> 3px) for better visual balance
  on the 40px avatar.

= 5.8.4 — My Account avatar: hide camera overlay when photo set + 2x icon =
* UX: Once a real photo is uploaded, the camera overlay on the My Account
  sidebar avatar is hidden automatically. Triggered server-side via the
  _zymarg_avatar_url user meta AND client-side immediately after a
  successful upload — no reload needed.
* UX: Camera button + SVG icon are now 2x larger (button 36px, SVG 20px)
  so the upload affordance is much more discoverable when the user hasn't
  uploaded a photo yet.
* Consistency: matches the Vendor Dashboard plugin's avatar pattern —
  buyer + seller experiences feel like one family.

= 5.8.3 — Fix: Community sidebar link now actually navigates =
* Fix: The My Account sidebar's SPA click handler was intercepting the
  "Community" link and trying to AJAX-load a section (which doesn't exist
  for an external link), so clicks did nothing. Added `data-external="1"`
  support so external sidebar links bypass the SPA interceptor and follow
  their `href` natively.
* Foundation for any future external sidebar links — just add the data
  attribute and the SPA will leave them alone.

= 5.8.2 — My Account sidebar gains a "Community" item =
* New: My Account sidebar adds a **Community** menu item directly after Reviews,
  linking to the public Community archive (default: /community/).
* The item appears ONLY when the ZYMARG Community Request Board plugin is
  active (detected via the ZCRB_POST_TYPE constant). On sites without the
  plugin, the sidebar is unchanged.
* No other sidebar items were touched. No new My Account endpoint registered.
  Pure additive change.

= 5.8.1 — Help page documents the Wishlist + Recently Viewed shortcodes =
* Added: a new "Wishlist & Recently Viewed shortcodes" section to the
  ZYMARG OS admin Help page documenting both `[zymarg_wcpg_wishlist]` and
  `[zymarg_wcpg_recently_viewed]` (provided by ZYMARG WC Product Grid
  v1.5.2+). Includes copy-to-clipboard examples for each attribute, a
  list of useful pages to drop them on (empty cart, 404, thank-you,
  footer, single-product cross-sell row), and a developer note on the
  `*_card_settings` filters.
* The theme already wires the Recently Viewed shortcode into My Account
  automatically (see v5.7.8) — this Help page section is for placing the
  same grids anywhere else on your site.

= 5.7.10 — My Account dashboard cards are now clickable =
* Fixed: the dashboard "quick access" tiles on My Account → Dashboard
  (Recent Orders, Wishlist, Recently Viewed, Notifications, Vouchers)
  did not actually navigate when clicked — they only showed a one-line
  preview tooltip and looked like dead buttons. They now route through
  the existing SPA loader so clicking a tile opens the matching section
  in-place, with proper history/scroll/sidebar-active state. Cmd/Ctrl/
  Shift-click still passes through for "open in new tab" behaviour.

= 5.7.9 — Header dropdowns are clipping-proof =
* Added a defensive CSS layer (`components/header-overflow-fix.css`) that
  forces `overflow: visible` on every Elementor / Theme Builder header
  section, container, column and widget wrapper. This means dropdowns inside
  your header (live search, account menu, mini-cart, mega menu sub-panels)
  can NEVER be cut off below the header again — even if an Elementor section's
  "Overflow" setting is accidentally flipped to Hidden (a very easy mistake
  to make in the Elementor UI).
* Scope is strictly limited to the header (`.elementor-location-header`); page
  content, footer, single product, shop and other layouts are untouched.
* Shipped after a real-world incident where this exact misconfiguration caused
  every header dropdown on the site to be cut off below the header.

= 5.7.8 — Recently Viewed uses the same card as your homepage =
* Improved: when the **ZYMARG WC Product Grid plugin v1.5.2+** is active,
  the My Account → Recently Viewed section now renders via its new
  `[zymarg_wcpg_recently_viewed]` shortcode, using the SAME product-card
  template as your homepage / search / category pages. Consistent design
  everywhere.
* Falls back gracefully:
    1. ZYMARG WC Product Grid shortcode (best — matching cards)
    2. ZYMARG Insights server-side renderer (still cross-device)
    3. A friendly "enable a plugin" prompt if neither is installed.
* No other theme code changed.

= 5.7.7 — Recently Viewed now cross-device via ZYMARG Insights =
* Fixed: the My Account → "Recently Viewed" list was always empty. The old
  tracker lived in `assets/js/account.js`, which only loads on the account
  page — so product views were never recorded and the list had nothing to
  show.
* Recently Viewed is now powered server-side by the new, free **ZYMARG
  Insights** plugin. Benefits: it works across all of a signed-in customer's
  devices, survives browser/cache clears, and records views via a fast,
  non-blocking beacon that never slows product pages.
* `inc/account-sections.php` now renders the plugin's grid when ZYMARG
  Insights is active (`zymarg_insights_render_recently_viewed()`), and shows a
  friendly "enable the plugin" prompt otherwise — no blank panel.
* Removed the dead localStorage tracker block from `assets/js/account.js`
  (a no-op stub remains so the SPA loader keeps working unchanged).
* No other functionality changed. If you don't install ZYMARG Insights, the
  rest of My Account works exactly as before.

= 5.7.6 — Wishlist removed from theme; pluggable from your product-grid plugin =
* Removed the theme's built-in wishlist module entirely to keep ZYMARG OS
  lightweight. Deleted files (~597 lines): `inc/wishlist.php`,
  `assets/js/wishlist.js`, `components/wishlist.css`. The single source of
  truth is now your product-grid plugin.
* The My Account → Wishlist tab in the sidebar stays — but it is now POWERED
  by whichever wishlist-providing plugin you have active, so users can still
  find their saved items whenever they want. Two ways to wire it up:
    * **Shortcode** (no code): Customize → ZYMARG OS → Wishlist Integration →
      paste your plugin's shortcode name (without brackets). Defaults to
      `zymarg_wcpg_wishlist` (shipped by ZYMARG WC Product Grid v1.4.6+).
    * **Filter** (for developers): hook `zymarg_os_account_wishlist_content`
      and return HTML.
* If neither is configured, the tab shows a friendly empty state instead of
  rendering blank.
* The dashboard "Wishlist" tile is preserved (icon + label) but no longer
  shows a count (the count lived in the removed storage layer).
* Admin → ZYMARG Help: replaced the old Wishlist card with a new card
  documenting the integration.
* The `zymarg_os_modules` registry entry for `wishlist` is kept for backward
  compatibility (default off) but has no effect — `wishlist.php` no longer
  ships with the theme.

= 5.7.5 — Login card: spark -4px, tighter OR-divider, +2px under Google =
* Discovery Spark in the login card pushed up a further 2 px (now translateY
  -4 px total) on `.zymarg-login .zymarg-spark`.
* OR-divider between Login button and "Continue with Google" reduced again:
  margin-y mobile 13 -> 8, tablet 14 -> 9, desktop 19 -> 12.
* Gap below "Continue with Google" (above "Forgot Password?") bumped by 2 px
  via the inline style on the link: 8 -> 10.

= 5.7.4 — Login card: nip the Google -> Forgot gap; nudge the Discovery Spark =
* Login card: the gap between the "Continue with Google" button and the
  "Forgot Password?" link was actually being controlled by an INLINE style
  (`margin-top: 30px !important`) in `inc/login.php`, which is why the CSS
  reductions in 5.7.2 / 5.7.3 could not affect it. Reduced that inline value
  from 30 px down to 8 px so the link now sits tight under the Google button
  on all viewports.
* Discovery Spark in the login card pushed up by 2 px via
  `transform: translateY(-2px)` on `.zymarg-login .zymarg-spark`. Layout-
  neutral (uses transform, so surrounding elements do not reflow).

= 5.7.3 — Login card: deeper squeeze on the area below the Login button =
* Following on from 5.7.2, the rows below the Login button were cut further
  (visible reduction this time). `components/login.css`:
  * Google sign-in button vertical padding: 11 -> 8.
  * Forgot password link: padding 3 -> 0; mobile-only top margin 24 -> 12.
  * Footer padding-top / padding-bottom:
    mobile  13/19 -> 8/12, tablet 14/19 -> 9/12, desktop 19/26 -> 12/16.
  * Footer text margin-bottom: 10 -> 6.
  * Footer divider margin-top + padding-top:
    mobile 10+10 -> 6+6, tablet+ 13+13 -> 8+8.
* Compounded vs 5.7.1 baseline: roughly 50 px shorter below the button on
  mobile, 40 px on tablet and 50 px on desktop.
* Untouched: page wrapper, header, brand, tabs, error banner, all form fields,
  the Login button itself, the OR-divider and the v5.7.2 logo size.

= 5.7.2 — Login card: tighten everything below the Login button =
* Branded login card (the front-end `/my-account/` card rendered by the
  `[zymarg_login]` shortcode) — reduced ~20% of all vertical spacing BELOW the
  Login button. Applies on mobile, tablet and desktop. Nothing above or
  including the Login button is changed; side margins/paddings preserved so the
  layout does not shift horizontally.
* Specific tightenings (`components/login.css`): the OR-divider, the Google
  sign-in button (vertical padding 14 -> 11), the Forgot password link
  (mobile-only 30px top margin -> 24px; padding 4 -> 3), the Footer paddings
  and inner text/divider gaps.
* Site logo on the login card reduced ~5% (mobile 24 -> 23 px; tablet+
  31 -> 29 px) for a slightly more compact header.
* Result: ~21 px shorter on mobile, ~21 px shorter on tablet and ~28 px shorter
  on desktop, with no change to the form fields, the button itself, or the
  centred page wrapper.

= 5.7.1 — Fix: Elementor header "dancing" / layout shift on load =
* Fix: pages no longer visibly "dance" (settle-in / layout shift) on load when
  an Elementor header is active. The theme now freezes transitions and entrance
  animations during the first paints on EVERY page (previously only on account/
  product), so the page and header snap straight to their final layout. The
  freeze is removed a moment after load, with a 1.5s safety timer so it can
  never get stuck, and content stays visible throughout.
* The behaviour is filterable: add_filter( 'zymarg_os_anti_dance', '__return_false' )
  to disable it.

= 5.7.0 — Removed Algolia engine + built-in Reviews system =
* Removed: the native Algolia search engine (inc/algolia.php, the ZYMARG OS ->
  Search Engine admin page, indexing/sync, and its help/menu entries). Live
  Search now runs purely on the built-in, cached WP_Query engine — the AJAX
  handler for that already lived in smart-ux.php, so search keeps working. The
  Algolia code path was also removed from live-search.js and smart-ux.php.
* Removed: the built-in Reviews system (inc/reviews.php, inc/review-rules.php,
  inc/reviews-admin.php, the inc/reviews/ classes + templates, and the
  zymarg-reviews / review-sort assets). Product reviews now use the default
  WooCommerce reviews. Nothing else referenced this system, so removal is clean.
* Net effect: a lighter theme (fewer files + assets) with no functional loss to
  the features you kept.

= 5.6.0 — Marketplace description + ZYMARG Theme Builder rename =
* Change: refreshed the theme description to state it powers a fully functional
  multi-vendor marketplace and requires two companion plugins — ZYMARG Theme
  Builder and ZYMARG Vendor Dashboard.
* Change: renamed "ZYMARG Powerhouse" to "ZYMARG Theme Builder" everywhere
  (recommended-plugins notice, Performance page, helper functions/filters). The
  detection helper now matches both the new and legacy plugin signatures, so
  nothing breaks. Filters are now zymarg_os_theme_builder_active and
  zymarg_os_theme_builder_install_url.

= 5.5.0 — Vendor Dashboard moved to its own plugin =
* Change: the entire Vendor Dashboard (Phases 0-5) has been extracted from the
  theme into a dedicated plugin, "ZYMARG Vendor Dashboard" (v1.0.0). This is the
  correct architecture — functionality and vendor data (messages, coupons,
  reviews) now survive theme changes. Install that plugin to keep the vendor OS.
* Kept in the theme: the global ZYMARG design language (the --zymarg-gradient
  token, gradient buttons, rounded soft-shadow cards) and the My Account
  styling. The plugin automatically uses these tokens + the Discovery Spark mark
  when the theme is active, and falls back to built-in styling otherwise.
* Removed the now-unused "Vendor Dashboard" module toggle.

= 5.4.0 — Vendor Dashboard Phase 5: Messages & Customers =
* New: Messages — a Messenger-style buyer<->vendor inbox (works on Dokan Lite).
  Two-pane layout with a conversation list and a chat thread (bubbles + a
  composer). Messages are stored privately (zymarg_message post type) per
  vendor/customer pair; vendors can open any of their customers and chat. The
  inbox is seeded from the vendor's order customers so it is useful immediately.
  Mobile shows a list -> thread drill-down with a back button.
* New: Customers — Recent / Repeat / Top Buyers tabs aggregated from the
  vendor's orders, each row showing orders, total spent (vendor share), last
  order date, and a one-tap Message button that deep-links into the inbox.
* All endpoints are ownership-checked and nonce-protected.
* Note: the buyer-facing reply UI (so customers can message back from the
  storefront) is the natural follow-up; the storage + vendor side are in place.

= 5.3.0 — Vendor Dashboard Phase 4: Promotions & Reviews =
* New: Promotions section with a native vendor COUPON creator that works on
  Dokan Lite (no Pro needed). Set code, type (%/fixed cart/fixed product),
  amount, expiry, usage limit and min spend. New coupons are automatically
  restricted to the vendor's own products so they never discount another
  seller. Includes a coupon list with delete. All ownership-checked + nonce-
  protected.
* New: Reviews section — manage reviews on your products with rating filter
  tabs (All / 5-1 stars), a public Reply, Hide/Unhide (approve/hold) and Report
  (flags the review for the marketplace admin). Vendors can only act on reviews
  of their own products.
* Change: the Coupon and Promotion Quick Actions now open the native Promotions
  screen.

= 5.2.0 — Vendor Dashboard Phase 3: Earnings & Analytics =
* New: Earnings section — Today's Earnings, This Week, This Month, plus
  Available Balance, Withdrawn and Pending Withdrawal, a 30-day earnings trend
  chart, and a Withdraw button that hands off to Dokan. Balance/withdrawn/
  pending read Dokan's payout data when available; the period totals are always
  computed from orders.
* New: Analytics section — Revenue, Orders, Visitors and Conversion stat cards,
  a 30-day revenue chart, and a Top Products ranking (by units sold, with a
  relative sales bar). Visitors/conversion light up via the new
  zymarg_os_vendor_visitors filter (hook your analytics/view source).
* Change: Earnings and Analytics sidebar items now open these native ZYMARG
  screens; the revenue chart now supports sparse x-axis labels for clean 30-day
  views.

= 5.1.0 — Global ZYMARG design language (gradient + cards) =
* New: the dashboard's signature look is now the theme-wide default, driven by a
  single global token. Added --zymarg-gradient (+ --zymarg-gradient-hover) and
  --zymarg-shadow-soft so the entire look can be tuned or reverted from one place.
* Change: primary buttons (.zymarg-btn) and WooCommerce buttons (shop, cart,
  checkout, single add-to-cart) now use the purple->magenta->pink gradient.
  Secondary/ghost buttons explicitly keep their outline/transparent style.
* Change: global cards (.zymarg-card) adopt the dashboard's 18px corners and the
  softer layered shadow.
* Change: the .zymarg-gradient-primary / .zymarg-gradient-text helpers and the
  Vendor Dashboard + My Account (--zv-grad) now all reference the one global
  gradient token — single source of truth, so colour/Customizer/dark-mode
  changes flow everywhere automatically.
* Note: product-grid cards on the shop keep their existing layout for now (the
  global gradient buttons + card token still apply); a dedicated shop product
  card restyle can follow if desired.

= 5.0.0 — Vendor Dashboard Phase 2: Products & Orders =
* New: Products section — a beautiful card grid (no more WooCommerce tables)
  showing each product's image, name, price, stock, units sold and views, with
  a status badge and a featured star. Includes search and pagination.
* New: per-product actions menu (•••) — Edit and View (open Dokan/WordPress),
  plus live AJAX actions: Feature/Unfeature, Hide/Unhide (catalog visibility),
  Duplicate (uses WooCommerce's own duplicator), and Delete (to trash). All are
  ownership-checked (a vendor can only manage their own products) and nonce-
  protected.
* New: Orders section — tabbed by lifecycle (Pending, Processing, Shipped,
  Delivered, Cancelled, Refunds) with per-tab counts, customer, date, item
  count, vendor revenue share and a View link to the Dokan order. Orders are
  scoped to the vendor's items (whole-store for admin preview).
* Change: the Products and Orders sidebar items now open these native ZYMARG
  screens inside the dashboard shell; "Add Product" and the Quick Actions still
  use Dokan's real forms for the write flows (no functionality reimplemented).
* Adds the vendor product-action AJAX endpoint and the supporting tab / menu
  JavaScript. Works on Dokan Lite; deeper per-section tooling continues in later
  phases (Earnings, Analytics, Promotions, Reviews, Messages, Customers).

= 4.11.1 — My Account: deepen the in-panel dashboard match =
* Improve: the content that loads when you press a sidebar menu item now fully
  matches the Vendor Dashboard — card icon tiles use the signature gradient with
  white icons, primary/submit buttons use the brand gradient, status chips are
  fully-rounded pills, tab bars are pill-style, and order totals use brand
  purple. (v4.11.0 only restyled the sidebar + card radius/shadow.)
* Still visual-only and scoped to the account page; no markup, scripts or
  behaviour changed.

= 4.11.0 — My Account matches the Vendor Dashboard design =
* New: the customer My Account page is now visually harmonized with the ZYMARG
  Vendor Dashboard — white sidebar, the signature gradient active-nav pill, a
  card-style user header, and a unified card radius / shadow / hover across all
  panels (Dashboard, Orders, Wishlist, Addresses, etc.).
* This is a styling-only layer appended to the account stylesheet and scoped to
  the account page; no markup, scripts, endpoints or behaviour were changed, so
  all existing functionality (SPA section nav, avatar upload, forms, modals,
  address book) remains intact.

= 4.10.1 — Vendor Dashboard: correct greeting for the visitor's timezone =
* Fix: the Dashboard greeting ("Good morning/afternoon/evening") now reads the
  visitor's LOCAL device time instead of the server/site timezone, so it is
  correct for vendors everywhere (e.g. Bangladesh, UTC+6) regardless of how the
  WordPress timezone is configured. The server still renders an initial value;
  the browser corrects it on load.

= 4.10.0 — ZYMARG Vendor Dashboard (Phase 0 + 1) =
* New: a custom, on-brand Vendor Dashboard — a seller "business operating
  system" built on top of Dokan Lite (free). Unlike a re-skin, it is a custom
  ZYMARG shell so the vendor experience matches the buyer account and mirrors
  the data the mobile app pulls from Dokan's REST API.
* New: the dashboard automatically takes over the vendor dashboard page
  (slug: `dashboard`, where Dokan's [dokan-dashboard] normally lives) via a
  the_content filter, and is also available anywhere via the
  [zymarg_vendor_dashboard] shortcode.
* New: Phase 0 shell — branded sidebar (Dashboard, Products, Orders, Earnings,
  Analytics, Promotions, Reviews, Messages, Customers, Shipping, Payments,
  Store Settings, Notifications, Support, Settings, Logout), store card,
  responsive mobile drawer (hamburger + overlay), and a logout confirmation
  modal.
* New: Phase 1 signature Dashboard screen — warm time-aware greeting
  ("Good morning, {name} 👋"), Quick Actions row (+ Product, + Coupon,
  + Withdraw, + Store Banner, + Promotion), four stat cards (Today's Sales,
  Today's Orders, Pending Orders, Store Rating), a dependency-free inline-SVG
  7-day revenue chart, Latest Orders, Low Stock and Recent Reviews.
* New: access control — Dokan sellers see the dashboard; admins/shop managers
  get a clearly labelled preview; logged-out and non-vendor users get
  sign-in / "become a vendor" prompts.
* New: "Vendor Dashboard" module toggle under Customize → ZYMARG OS → Modules
  (enabled by default; needs WooCommerce, and Dokan for live seller data).
* Data layer is best-effort with safe fallbacks, so the screen renders cleanly
  on a brand-new store with no data yet.

= 3.6.6 — Fix My Account content rendering (template override) =
* Fixed: the right-side content panels were rendering "far below" and the
  word "count" appeared on the top-left of the Dashboard. Root cause: the
  hook-based template wrapping approach (woocommerce_before/after_account_
  navigation + removing woocommerce_account_content) did not fully suppress
  WooCommerce's default dashboard output — WC's default "Hello [name]…" and
  dashboard paragraphs rendered FIRST, then our panels rendered below them.
* Fix: replaced the hook-based approach with a proper WooCommerce template
  override at woocommerce/myaccount/my-account.php. For logged-in users,
  the template renders the ZYMARG layout directly (sidebar, orbs, section
  panel). For logged-out users, it renders WC's standard login form. This
  gives us full control over the page output — no stray WC content leaks.
* Fixed: "count" text leaking was caused by the PHP expression
  `count( zymarg_os_get_wishlist() )` evaluating when the wishlist module
  hadn't fully initialized. Now guarded with `zymarg_os_wishlist_enabled()`
  and an `is_array()` check.
* Added CSS safety net: `.zymarg-myaccount-wrap .woocommerce` is forced
  to `display: block` to override any WC grid/flex that might leak through.
* No changes outside the My Account page.

= 3.6.5 — New My Account page design (sidebar + 13 sections) =
* Brand-new, app-like My Account experience replacing the previous default
  WooCommerce layout. Fixed sidebar on desktop with user avatar + navigation,
  mobile bottom nav, 13 section panels with smooth fade-in transitions.
* Sections fully wired to real WooCommerce data:
  - Dashboard: order count, wishlist count, quick-action cards with inline
    detail expand/collapse.
  - Orders: real orders from wc_get_orders() with tab filtering by status
    (All / Processing / Shipped / Delivered / Cancelled), status badges, view
    links. Quick Actions (Track Order, Refund Request, Buy Again).
  - Wishlist: renders the theme's built-in [zymarg_wishlist] shortcode.
  - Addresses: WooCommerce's native my-address.php template.
  - Profile: WooCommerce's native form-edit-account.php template.
  - Security: custom password change form (validates current password,
    re-authenticates after update so user stays logged in), active sessions
    display, and a Delete Account modal with password confirmation that calls
    wp_delete_user() (admins blocked from self-deletion).
  - Vouchers (formerly "Coupons"): queries real WC coupons available to the
    user (email-restricted or unrestricted), with Available / Used / Expired
    tabs.
  - Reviews: "My Reviews" tab queries real comment-type reviews; "Pending
    Reviews" tab shows completed-order products the user hasn't reviewed yet.
* Sections wired to Dokan Pro (feature-gated, graceful fallback):
  - Returns & Refunds: queries Dokan's dokan_rma_request table; falls back
    to showing WC refunded orders when Dokan isn't active.
  - Support: lists Dokan Store Support tickets (dokan_store_support CPT);
    shows Contact Support / Help Center links when Dokan isn't active.
  - Notifications: shows Dokan announcements when available; notification
    preference toggles save to user meta via AJAX.
* Lightweight theme-built features:
  - Recently Viewed: localStorage-based product tracker. Auto-records
    product visits on single-product pages; renders the history as action
    cards on the account page. No plugin needed, no cookies, GDPR-friendly.
  - Preferences: email preference toggles (Newsletter, Order Emails,
    Promotional) saved to user meta via AJAX. Instant toggle with no page
    reload.
* Design system: 767-line account.css using ZYMARG design tokens with
  hardcoded fallbacks. Sidebar, section panels, cards grid, action cards,
  status badges, forms, buttons, toggle switches, tabs, dashboard cards,
  inline detail, empty states, delete-account modal, bottom nav, order items,
  settings cards, and WooCommerce form overrides.
* Mobile-first: single-column at <768px, bottom nav visible, sidebar hidden.
  Desktop: fixed 260px sidebar + fluid content area (max 960px).
* WooCommerce endpoint registration for 9 custom sections (wishlist,
  recently-viewed, notifications, reviews, coupons, returns, support,
  preferences, security). Flush rewrite rules on theme activation.
* "Coupons" renamed to "Vouchers" per brand decision.
* No changes outside the My Account page. Shop, product, cart, checkout,
  Dokan vendor store, blog, header, footer, mega menu are all untouched.

= 3.6.4 — Reverted My Account page to default WooCommerce styling =
* The "Supercharged My Account" module (welcome hero, stat cards,
  quick-action buttons, premium menu icons, branded sidebar / content
  panel / tables / address cards / forms / buttons / notices) has been
  removed. The WooCommerce My Account page now renders with default
  WooCommerce styling so a new account-page design can be introduced
  cleanly in a follow-up release.
* Files removed:
  - inc/account-dashboard.php (PHP module, all hero / stats / quick-action
    rendering, body-class additions, Customizer "My Account" section,
    dynamic CSS for the hero gradient).
  - woocommerce/account.css (all .woocommerce-account / .zymarg-account-*
    / .zymarg-acc-* rules).
* Files restructured:
  - The previous account.css contained Dokan vendor-store + dashboard
    styling alongside the My Account rules. Those Dokan rules have been
    moved to a new dedicated woocommerce/dokan.css file so multivendor
    UIs stay on-brand. Enqueue updated accordingly (woo-account ->
    woo-dokan).
  - inc/dynamic-css.php no longer references the deleted account hero
    CSS function.
  - inc/admin-help.php: the long "My Account page (supercharged)" help
    card is removed; the separate "My Account header icon" subsection
    (a different feature — the customizable account icon for the site
    header, [zymarg_account_icon]) has been promoted to its own help
    card with a short note explaining that the account page itself now
    uses default WooCommerce styling.
* Kept (separate features, not part of the My Account page design):
  - inc/account-icon.php + components/account-icon.css — the
    customizable header My Account icon.
  - The reviews module's "Write a review" column on the Orders table
    (functionality, not styling).
* No styling changes anywhere outside the My Account page. Shop, single
  product, cart, checkout, Dokan, blog, header, footer, mega menu are
  all untouched.

= 3.6.3 — Bulletproof My Account hero (initials avatar + mobile layout) =
* Fixed: when Gravatar was slow or blocked (common on networks outside
  the US/EU), the My Account hero rendered the alt text "FirstName" as
  plain text where the avatar should be — making the dashboard look
  broken with the user's name showing twice. The hero now wraps the
  avatar in a brand-coloured initials circle that is ALWAYS visible.
  The Gravatar image overlays the circle when (and only when) it loads;
  if the network blocks it, the polished initials remain. The image's
  alt is now empty so it can never leak into the layout.
* Refined: the avatar circle uses a subtle two-layer gradient (the
  signature ZYMARG primary -> primary-container plus a soft brand-text
  overlay) and a soft outline derived from the hero's text colour, so
  the fallback feels like a designed brand mark rather than a placeholder.
* Fixed: "Member since" date could drift by a day for users registered
  near midnight UTC (date_i18n( ..., strtotime( $user->user_registered ) )
  treated the UTC string as server-local). Now uses wp_date() with the
  site timezone for accurate display.
* Fixed (mobile layout):
  - Welcome hero stacks vertically and centres below ~520 px, so long
    greetings + emails no longer get crushed into a 70 px wide column.
  - Account content panel + hero padding tighten from space-lg (40 px)
    to space-md (24 px) below 600 px, recovering inner content width.
  - Sticky sidebar navigation is released to static positioning below
    768 px, so the 6-tab nav no longer glues to the top of the
    viewport while you scroll the dashboard on a phone.
  - Quick-action pills become a full-width CTA bar below 520 px instead
    of stranded left-hugging pills.
* Refined: hero gets `overflow: hidden` so any over-long content stays
  inside the rounded gradient corner.
* No styling changes anywhere outside the My Account page.

= 3.6.2 — Elegant My Account icons (specificity fix + refined glyphs) =
* Fixed: every tab in the My Account sidebar (Dashboard, Orders, Downloads,
  Addresses, Account details, Logout) was rendering the same generic circle
  instead of its own icon. Caused by a CSS specificity bug in
  woocommerce/account.css — the per-endpoint icon rules (specificity 0,2,2)
  were being overridden by the base + fallback rules (0,2,3). The base now
  uses mask longhands (no more shorthand mask-image reset), and the generic
  fallback is wrapped in :where() so it has zero specificity.
* Refined: the per-endpoint icons themselves are redrawn with consistent
  visual weight, rounded geometry and better legibility at 16-20px
  (modular grid for Dashboard, shopping bag for Orders, arrow-into-tray
  for Downloads, soft pin for Addresses, refined user for Account details,
  exit-door for Logout).
* Refined: the active accent bar on the sidebar nav now uses the signature
  ZYMARG gradient (primary -> primary-inverse) with a soft glow, so it
  reads as a polished brand mark in both light and dark mode.
* Refined: stat-card values (Orders, Total spent, Wishlist) use tabular
  lining numerals so currency and counts align column-perfectly across
  cards.
* Cleaned: removed dead `.woocommerce-account.logged-out` selector and the
  redundant "re-assert" icon block at the bottom of account.css.
* No styling changes anywhere outside the My Account page.

= 3.6.1 — Smart-switch default mode (dark-by-default + switchable) =
* New "Smart switch — default mode" option (Customize -> ZYMARG OS -> Colours):
  choose whether the visitor-controlled switch starts on Auto, Light or Dark.
  So you can default the site to Dark while still letting visitors switch to
  Light — the previous behaviour always started on Auto.
* Clarified that the "Light" and "Dark" schemes are fixed and do NOT allow
  switching (the [zymarg_theme_toggle] button only works in "Smart switch"
  mode). This was a common trap — selecting "Dark" locked the site to dark and
  the toggle did nothing. Help page updated with a clear callout.
* The switch no longer persists the default to the browser until the visitor
  actually clicks, so changing the default later is respected.

= 3.6.0 — Site logo shortcode =
* New [zymarg_logo] shortcode outputs your WordPress Custom Logo (Customize →
  Site Identity → Logo) so you can place it anywhere — e.g. a Shortcode element
  in your Elementor header. Options: size (max height px), link (true/false),
  alt and class. Falls back to the site title when no logo is set. Documented
  in the Help page (which now covers every theme shortcode).

= 3.5.9 — Flexible dark/light toggle button =
* The [zymarg_theme_toggle] switch now accepts options so it fits any header:
  size ("sm" / "md" / "lg"), show_label ("true" shows a visible "Theme: …"
  label beside the icon), label (custom accessible text) and class. Defaults
  are unchanged (icon-only, md). Set the colour scheme to "Toggle" in
  Customize -> ZYMARG OS -> Colours, then place the shortcode in your header
  (e.g. an Elementor Shortcode widget) so visitors can pick Auto / Light /
  Dark. Help page updated.

= 3.5.8 — Smarter caching detection in the Performance report =
* The Performance report now detects host / edge caches that have no plugin
  (Pantheon Global CDN, WP Engine, Kinsta, SiteGround, Cloudways, Cloudflare)
  as well as the major caching plugins (WP Rocket, W3 Total Cache, LiteSpeed,
  WP Super Cache, WP Fastest Cache, Cache Enabler, Autoptimize) and object
  caches — and names the provider. Fixes the false "No caching detected"
  warning on hosts like Pantheon. Declarable via the zymarg_os_detected_cache
  filter.

= 3.5.7 — Performance report + recommended-plugins notice =
* New "Performance" dashboard page (ZYMARG OS -> Performance) with detailed
  diagnostics: environment (theme/WP/PHP/memory/HTTPS/caching/debug), active
  integrations (ZYMARG Theme Builder, Elementor, WooCommerce), every module's
  on/off state, a map of what assets load and when, and tailored
  recommendations.
* New post-activation admin notice recommending the ZYMARG Theme Builder and
  Elementor plugins (the theme works hand-in-hand with them). Lists only what
  is missing, links to install/activate, and is dismissible per user.
  Detection is filterable (zymarg_os_theme_builder_active /
  zymarg_os_theme_builder_install_url).
* Note on lazy loading: the existing "Lazy Images" module lazy-loads
  images/iframes; separately, the theme already lazy-loads its own CSS/JS
  (only enqueuing what each page needs) — both are surfaced in the new report.

= 3.5.6 — Removed content top/bottom gap (zero by default) =
* Removed the content area's top/bottom padding entirely — the theme now adds
  ZERO vertical gap by default. Create page spacing with your page builder
  (e.g. Elementor) instead.
* Removed the related controls: "Content vertical padding" and the two
  "remove top/bottom gap" toggles (Customize -> ZYMARG OS -> Spacing), plus
  their dynamic CSS. The Spacing section now only holds the content-width
  controls. Lighter and simpler for builder-first sites.

= 3.5.5 — Fix: My Account rendered unstyled (vertical) on shortcode pages =
* The My Account styles now load and apply on ANY page that contains the
  [woocommerce_my_account] shortcode — not only the page WordPress flags as
  the official account page. Previously, if your My Account page wasn't the
  one assigned in WooCommerce → Settings → Advanced, account.css never loaded
  and the body lacked the woocommerce-account class, so the page rendered
  completely unstyled (everything stacked vertically). The theme now adds the
  needed context (loads account.css + adds the woocommerce-account body class)
  whenever the shortcode is present, so the two-column layout always renders.

= 3.5.4 — Fix: My Account two-column layout could scramble =
* Hardened the My Account grid so only the navigation menu and the content
  area form the two columns. Any other direct child of the WooCommerce wrapper
  (notices, "Hi name" wrappers, headings, etc.) now spans the full width
  instead of being placed into a grid cell — which previously scrambled the
  menu/content alignment and looked broken. No markup or feature changes.

= 3.5.3 — Removed the built-in header/footer (lighter, builder-first) =
* Removed the optional built-in Header & Footer builder so the theme is leaner
  for sites that build their header/footer with a page builder (e.g. Elementor)
  or the ZYMARG plugin.
* Deleted inc/header-footer.php and components/header-footer.css; stripped the
  related header/top-bar/search JS from the front-end script; removed the
  Header & Footer Customizer section, the announcement bar, the header
  action area, the per-page "Hide header/footer" toggles, the header/footer
  block patterns, and the related Help/menu entries.
* header.php and footer.php remain as minimal document scaffolding (head,
  body, #page wrapper, wp_head/wp_body_open/wp_footer) — your builder/plugin
  injects the actual header & footer.
* The "remove top/bottom gap" Spacing toggles remain (useful when an external
  header/footer sits against your content). No other features affected.

= 3.5.2 — Fluid / percentage content width =
* New "Content width mode" in Customize -> ZYMARG OS -> Spacing: choose Fixed
  (a constant pixel width, as before) or Fluid (a percentage of the screen).
* Fluid mode fills a configurable share of the viewport (50–100%) but is capped
  by the "Content max width" value, so the layout breathes on ultra-wide / 4K /
  8K displays while keeping text line-length readable. Implemented as
  min(<pct>vw, <cap>px) on the content container.
* Raised the Content max width ceiling from 1920px to 2560px to suit large
  displays.

= 3.5.1 — Secure SVG uploads =
* New "SVG Uploads" module (Customize -> ZYMARG OS -> Modules): lets
  administrators upload SVG images to the Media Library, which WordPress
  blocks by default.
* Every uploaded SVG is sanitized server-side before it is saved — <script>,
  event handlers (on*), foreignObject/iframe/embed/object, javascript: links
  and DOCTYPE/ENTITY (XXE) are stripped or rejected.
* Uploads are restricted to users who can manage the site (filterable via
  zymarg_os_svg_upload_cap), and SVGs now preview correctly in the Media
  Library and image pickers (Account Icon, login logo). On by default.

= 3.5.0 — Discovery Spark™ accent timing tweak =
* The accent spark now pulses at 0.20s (twice as fast) while the companion and
  hero sparks stay at 0.40s, giving the mark a livelier lead beat. Shape,
  colours and sizes unchanged.

= 3.4.11 — Discovery Spark™ motion refresh =
* Updated the ZYMARG Discovery Spark™ animation to the new, faster sequential
  pulse: accent → companion → hero, each firing once per 0.40s cycle (down
  from 1.2s), pulsing in place on its own re-centred origin.
* The mark's shape, colours (purple #6833EA / gold #FFD166) and the full size
  matrix (xs–xl) are unchanged, so every existing placement stays the same
  size — only the motion is new. Updated the design-system demo to match.

= 3.4.10 — Fix: missing medium shadow token =
* Added the --zymarg-shadow-md design token (light + dark + auto), which was
  referenced by the login card and the My Account address cards but never
  defined — so those elements now show their intended soft elevation instead
  of no shadow.

= 3.4.9 — Clearer login pop-up instructions =
* Help page: added a clear note that the login pop-up options (frequency,
  delay, account-icon trigger and the page-targeting rules) only appear after
  you tick "Enable first-visit login pop-up", and that the "Page IDs" field
  shows only when "Only specific pages" / "All pages except…" is selected.

= 3.4.8 — Native Algolia search engine (no plugin required) =
* ZYMARG OS now connects to Algolia by ITSELF — no "WP Search with Algolia"
  (or any) plugin needed. This is the theme's search specialty.
* New dashboard page: ZYMARG OS -> Search Engine. Enter your Algolia keys,
  pick an index, choose what to index, and run a one-click reindex with a live
  progress bar.
* Indexes Products, Product Categories and Brands (brand taxonomy auto-detected;
  Categories and Brands individually toggleable).
* Real-time auto-sync: products, categories and brands update in Algolia
  automatically on add / edit / delete.
* Algolia is now the DEFAULT engine; built-in WordPress search is the automatic
  fallback when Algolia is not configured (so search never breaks).
* Security: the Admin API key is stored server-side and used only for indexing
  — it is never exposed to the browser; only the Search-Only key reaches
  visitors.
* All existing search-bar features are unchanged: instant search-as-you-type,
  the Trending + Recent searches panel, and "See all results".
* Search settings moved out of the Customizer into the new Search Engine page;
  Help page rewritten to document the native, plugin-free setup.

= 3.4.7 — Branded login screen, login card & first-visit pop-up =
* New "Login" feature (Customize -> ZYMARG OS -> Login), three parts:
  * Branded WordPress login screen (wp-login.php) — your logo, brand
    background, accent colour and the ZYMARG orb glow.
  * Front-end login card via the [zymarg_login] shortcode (Login / Register /
    Lost-password tabs) for any page, plus a [zymarg_login_button] that opens
    the pop-up.
  * An elegant first-visit login pop-up (modal) for logged-out visitors with a
    backdrop blur and smooth scale-in.
* Pop-up frequency: once per visitor / once per session / once every X days /
  every visit, with a configurable delay.
* Three INDEPENDENT pop-up sizes — set width + max-height separately for
  desktop, tablet and mobile (with an optional full-screen mobile sheet).
* Page targeting: Entire site / Only specific pages / All pages except…
  (never shown to logged-in users). Opens from the header account icon too.
* Customizable card title, subtitle, accent colour and card background. Brand
  defaults, dark-mode safe. Documented in the ZYMARG OS Help page.

= 3.4.6 — Fully customizable header + announcement bar =
* The built-in (Simple) header is now fully customizable from Customize ->
  ZYMARG OS -> Header & Footer, no code or page builder required:
  * Layout & spacing — logo position, contained/full width, content max-width,
    horizontal padding, header height and logo max-height.
  * Colours & borders — background, text/link colour, link hover colour, a
    bottom border (width + colour) and an optional drop shadow.
  * Menu typography — font size, weight, UPPERCASE toggle and item spacing.
  * Sticky — pin on scroll, a separate "scrolled" background colour, and an
    optional shrink-on-scroll effect.
  * Transparent (overlay) header — sits over your first/hero section with its
    own text colour and turns solid on scroll.
  * Action area — search icon (with a slide-down search box), account icon,
    wishlist count, cart icon + live count, and a coloured CTA button.
  * Mobile — configurable hamburger breakpoint and hamburger colour.
* New announcement / promo bar above the header (text with basic HTML, an
  optional whole-bar link, background + text colours, and an optional dismiss
  that is remembered per browser). Works with plugin / Block headers too.
* All header values are driven by the Customizer via dynamic CSS, default to
  the brand palette and are dark-mode safe. Documented everything in the
  ZYMARG OS Help page.

= 3.4.5 — Supercharged, fully customizable My Account page =
* New "My Account" feature that gives the WooCommerce account page a premium,
  branded makeover (Customize -> ZYMARG OS -> My Account):
  * Welcome hero — gradient banner with the customer's avatar, a personal
    {first_name} greeting and a "member since" line. Configurable gradient
    colours, text colour and avatar shape (circle / rounded / square).
  * Live stat cards — total orders, total spent and wishlist count (each
    toggleable).
  * Quick-action buttons — up to three (Browse shop / Track orders / Edit
    details by default); each label + link is editable, with smart defaults.
  * Premium menu icons — a brand-tinted icon on every account tab (Dashboard,
    Orders, Downloads, Addresses, Account details, Logout).
* Every piece has its own on/off switch; turn the master toggle off to revert
  to the standard WooCommerce layout. Colours default to the brand palette and
  are dark-mode safe.
* Documented the full My Account feature set (plus the Account Icon) in the
  ZYMARG OS Help page.

= 3.4.4 — Fully customizable My Account icon =
* New "Account Icon" feature: a My Account icon you can drop into the header
  menu (enable it in Customize -> ZYMARG OS -> Account Icon) or place anywhere
  with the [zymarg_account_icon] shortcode (works inside plugin / page-builder
  headers too).
* Icon style: choose from 7 built-in SVGs (User, User solid, User in circle,
  User in square, Account badge, Storefront, Heart) OR upload your own image
  (PNG / SVG / JPG).
* Background: pick a shape (none / circle / rounded square / square) plus a
  background colour and a separate hover colour.
* Icon (foreground) colour and overall size controls, an optional text label,
  a custom link (auto-links to the WooCommerce My Account page by default) and
  an open-in-new-tab toggle.
* Fully token-driven defaults (brand primary #9500a5) so it matches the site
  out of the box and flips correctly in dark mode.

= 3.4.3 — Elegant, on-brand My Account page =
* Redesigned the WooCommerce My Account page end-to-end so the whole screen —
  not just the navigation — feels intentional and on-brand.
* Two-column layout: a sticky, card-style navigation with an animated primary
  accent bar on the active/hover item, beside a clean rounded content panel.
* Styled the previously-bare areas: orders & downloads tables (rounded, header
  shading, row hover), address cards (responsive grid with hover lift), the
  account-details / address forms (token inputs with a primary focus ring),
  primary + outlined buttons, and notices.
* Fully token-driven (brand primary #9500a5, radius, spacing, shadow,
  transition tokens) so it inherits Customizer colours and flips correctly in
  dark mode. Responsive: collapses to a single column on small screens.

= 3.4.2 — Centered, perfected product tabs (mobile one-line) =
* Single product tabs (Description, Additional information, Reviews, More
  Products, …) are now centered with a clean, pixel-aligned underline.
* Fixed a specificity clash where ui/tabs.css painted the tabs as grey "pills"
  and overrode the intended underline style; the PDP underline style now wins.
* Mobile: tabs stay on a single horizontal line (tightened spacing; the row
  scrolls instead of wrapping, and each tab stays reachable).

= 3.4.1 — No WooCommerce sidebar (kills the stray default-widget sidebar) =
* The theme now disables WooCommerce's default sidebar
  (remove_action 'woocommerce_sidebar' / woocommerce_get_sidebar). WooCommerce
  pages (shop, product, product-category) no longer call get_sidebar('shop'),
  so no sidebar.php is ever loaded on them.
* Added intentionally empty sidebar.php and sidebar-shop.php templates. On
  install/deploy these overwrite any stray or legacy sidebar.php left in the
  theme folder, so the old Kubrick-style sidebar (Search / Pages / Archives /
  Categories) can never render again.
* sidebar.php only outputs anything if you deliberately enable the optional
  Sidebar widget area (Customize → ZYMARG OS → Widget Areas) and add widgets.

= 3.4.0 — Single product control + widget-area cleanup =
* New "Single Product" Customizer section (ZYMARG OS -> Customize -> Single
  Product). The theme now decides what shows on the product page:
  * Product tabs: show/hide, rename, and reorder every tab — auto-discovered,
    so it covers WooCommerce core (Description, Additional information, Reviews)
    AND plugin tabs like Dokan's Shipping and Questions & Answers.
  * Sections: show/hide Related products, Up-sells, Dokan "More Products from
    this store", and the Dokan "Product Enquiry" button.
* The Dokan blocks are removed with safe, version-tolerant hook name-matching,
  with a CSS fallback as a backstop — no core/plugin templates are overridden.
* New "Widget Areas" Customizer section: the optional Sidebar widget area is now
  off by default (toggle to enable), and the Footer Column 1-4 areas only
  register when the theme's Simple footer is active. This stops WordPress from
  parking its default widgets (Search/Recent Posts/Pages/Archives/Categories…)
  in unused areas. Existing widgets move to Inactive Widgets, nothing is lost.
* Added a "Single Product page — what shows" guide to the Help page, including a
  read-only inspector that lists the tabs detected on your product pages.
* All controls default to no-ops, so existing sites look unchanged until you
  toggle something.

= 3.3.0 — Fully customizable Scroll-to-Top button =
* New "Scroll to Top" Customizer section (ZYMARG OS -> Customize -> Scroll to
  Top). Appearance: background colour, hover colour, icon colour, icon style
  (6 choices), shape (circle / rounded / pill), size and bottom-left/right
  position.
* Behaviour: editable "show after scrolling" threshold, an optional
  scroll-progress ring that fills as you scroll, and a hide-on-mobile toggle.
* Visibility: show on the entire site, the entire site except listed pages, or
  only on listed pages (by page ID or slug; also accepts "home" and "shop").
* Added a "Scroll to Top button" guide to the ZYMARG OS Help page, including
  where to find the settings.
* Colours/size flow through CSS variables (--zst-*) with token fallbacks, so
  the default look is unchanged. The zymarg_os_show_scroll_top filter still
  works for developers.

= 3.2.5 — Brand-aligned admin dashboard colours =
* Reviews dashboard: replaced the off-brand indigo accent (#4f00d0) with the
  brand magenta (#bd00d1), so the header bar / button gradients use the real
  ZYMARG brand pair (#9500a5 -> #bd00d1).
* Snapped bespoke mauve neutrals on the Reviews and Plugins screens to the
  ZYMARG colour tokens (ink #36003d, text #534152, outline #857183 / #d8bfd3,
  surfaces #eaedff / #faf8ff).
* Help screen: code-snippet text now uses the brand tint #ffd6fb instead of the
  near-match #f0d6ff.
* Semantic status chips (approved/pending/rejected) and gold rating stars are
  intentionally left as-is.

= 3.2.4 — Consistent brand orbs in dark mode =
* Dark-mode background orbs now use the same blue-violet brand pair as light
  mode and the policy page (#6833EA / #582A9F) instead of magenta, so the
  signature glow stays on-brand whether a visitor is in light or dark mode.
* No change to the primary brand colour, tints, or light-mode orbs — those
  already matched the policy page.

= 3.2.3 — Tidier review rules =
* Removed the "Override the ZYMARG Reviews plugin" setting from the Review
  rules screen (only relevant if you kept the legacy plugin). The theme
  handles reviews natively regardless.

= 3.2.2 — Reviews menu moved under ZYMARG OS =
* The Reviews screen is now a submenu inside the ZYMARG OS menu (alongside
  Welcome, Help, Customize, Update / Upload Theme, Plugins, Import / Export),
  instead of a separate top-level item next to Comments.

= 3.2.1 — Custom review-notification recipients =
* You can now set which email address(es) receive the "new review" notification
  (Reviews → Review rules). Supports multiple comma-separated addresses;
  leave blank to use the site admin email.

= 3.2.0 — Reviews dashboard + rules (superpowers) =
* New top-level "Reviews" admin menu (next to Comments) showing every product
  review you've received, with stats (total / approved / pending / average),
  filters (status, rating, product, search), sorting (newest / oldest /
  highest / lowest), pagination, and one-click Approve / Unapprove / Edit /
  Trash — all in an elegant, on-brand screen.
* New review rules ("superpowers"):
  - Who can write a review: any logged-in user, or ONLY verified purchasers
    (enforced on every form as a hard server check).
  - Override: let the theme handle reviews even if the legacy ZYMARG Reviews
    plugin is active.
  - Auto-approve (none / verified buyers / everyone).
  - Minimum review length, block reviews containing links (anti-spam), and an
    email-me-on-new-review notification.
* Mobile: the product review cards now use much more width (reduced widget
  container padding) so they no longer look cramped on phones.

= 3.1.1 — Toast consolidation hotfix =
* Removed the legacy ui/toast.css stub (it styled the same .zymarg-toast
  classes as the new unified Toast component and could clash). The new
  components/toast/toast.css is now the single source of truth.

= 3.1.0 — Wishlist, Toasts, smart search & more =
* New: Product Wishlist — heart buttons on shop + single products, saved for
  members (account) and guests (cookie), a [zymarg_wishlist] page and
  [zymarg_wishlist_count] badge, brand-styled and customizable. Toggle under
  Modules.
* New: Unified Toast notifications — one brand-styled, dark-mode-aware system
  used for add-to-cart, wishlist, login and review-submitted, with a
  window.ZymargToast API and a zymarg_os_queue_toast() PHP helper.
* New: Trending & Recent searches — the live-search box shows trending (from
  real searches, with a popular-categories fallback) and per-visitor recent
  searches on focus; they vanish on typing.
* Quick View confirmed built-in (no change needed) and documented.
* Help page expanded to document Reviews, Wishlist, Import/Export, Lazy Images,
  Smart Dark Mode, Trending/Recent search and Toasts.

= 2.13.0 — Smart dark mode (Auto / Light / Dark) =
* The theme switch is now a smart 3-way control: Auto (follow the device),
  Light, and Dark. The choice is remembered in localStorage and applied before
  first paint (no flash). Set Customize → ZYMARG OS → Colours → Color scheme to
  "Smart switch", then place the [zymarg_theme_toggle] button.
* Added semantic colour variables — --surface, --surface-2, --text-primary,
  --text-secondary — that map onto the token system and flip automatically in
  dark mode, so components use intent-based names instead of hardcoded colours.

= 2.12.0 — Reliable review sorting + Lazy Images module =
* Reviews: the sort dropdown (Most Recent / Highest Rated / Lowest Rated) now
  works reliably. Sorting uses machine-readable data (rating + epoch date) on
  each card instead of parsing the displayed date, so it is correct under any
  locale/date format, and it re-sorts after "Load more".
* New "Lazy Images" module with an on/off toggle (Customize → ZYMARG OS →
  Modules, default on). ON lazy-loads images + iframes with async decoding
  (leaving the LCP image to WordPress for safe performance); OFF disables lazy
  loading site-wide so every image loads immediately.

= 2.11.0 — Review photo uploads: 4 MB / 4 images + auto-compressor =
* Review form image upload now allows up to 4 images at 4 MB each (was 2 MB).
* Built-in client-side image compressor: large photos are resized (max
  1920px) and re-encoded to high-quality JPEG in the browser before upload,
  turning multi-MB photos into a few hundred KB — faster uploads, less
  storage, and no upload-limit errors.
* The upload box is placed on the right side of the form, with right-aligned
  thumbnail previews and a live size summary.
* Server still enforces the 4-image / 4 MB caps as a safety net. Compressor
  dimension/quality are filterable (zymarg_os_review_image_max_dimension,
  zymarg_os_review_image_quality).

= 2.10.0 — Smarter export (variations, progress bar, snapshots) =
* Product & Snapshot export now drive WooCommerce's own batched exporter, so
  variable products export WITH all their variations (full round-trip
  fidelity) instead of losing them.
* Exports run in AJAX batches with a live progress bar — no more timeouts /
  white screen on large catalogues.
* Store Snapshot is built from that correct export, so a Snapshot → Restore
  round-trip keeps variable products intact.
* Category & status filters on the product export are preserved.
* No-JS fallback also routed through the WooCommerce exporter.

= 2.9.0 — Smarter product import (progress bar, variations, warnings) =
* Product CSV import now runs in small AJAX batches with a live progress bar
  and running counts (created / updated / skipped / failed) — no more white
  screen or "did not respond in time" on large catalogues.
* Fixes variable products: the import now drives WooCommerce's own importer,
  so variable products + their variations import correctly instead of each
  variation row becoming a separate simple product.
* Reports products that were imported without an image (and lists any failed
  rows) in the results.
* Recognises standard WooCommerce export CSVs (Type, Parent, Attribute N
  name/value(s)/visible/global/default, etc.) in addition to the simple
  ZYMARG format.
* Drag-and-drop CSV preview retained; batch size filterable via
  `zymarg_os_import_batch_size`.

= 2.8.1 — Import / Export moved under the ZYMARG OS menu =
* The Import / Export screen is now a submenu inside the ZYMARG OS menu
  (alongside Welcome, Help, Customize, Update / Upload Theme, Plugins),
  instead of a separate top-level menu item.

= 2.8.0 — Import / Export hub + Store Snapshot =
* The "Import" menu is now "Import / Export" — a full store migration hub.
* Export Products (CSV): download your catalogue with optional category and
  status filters; round-trips cleanly with the importer and standard
  WooCommerce export CSVs.
* Export Categories (CSV): download the whole product-category tree
  (name, slug, parent, description).
* Store Snapshot: one-click ZIP backup containing products.csv +
  categories.csv + a manifest — a portable backup you can move between sites.
* Restore Snapshot: upload a snapshot ZIP to recreate categories (first) and
  products (after) on any ZYMARG OS site.
* Live store stats strip (published products, drafts, categories, on sale).
* Drag-and-drop uploads with an instant CSV preview (row count + detected
  columns) and button loading states.
* Everything remains native WooCommerce data; existing SKUs/terms are skipped
  so imports and restores are safe to re-run.

= 2.7.0 — Import menu (demo content + CSV) =
* New top-level "Import" admin menu with an elegant, on-brand card UI.
* Demo Content: one-click import of a bundled starter catalogue (8 sample
  products across Apparel, Accessories and Home & Living categories).
* Import Products (CSV): bulk-create products from a CSV; categories in the
  file are created automatically, including parent > child hierarchy.
* Import Categories (CSV): build your product-category tree from a CSV
  (name, slug, parent, description).
* Downloadable sample CSV templates and an in-page Instructions card.
* All items are created as native WooCommerce data (real products and
  product_cat terms), so they appear in WooCommerce Products, reports and
  the shop. Existing SKUs are skipped to avoid duplicates. Also compatible
  with a standard WooCommerce product export CSV.

= 2.6.2 — Revert thumbnail gap, keep shadow =
* Reverted the product gallery thumbnail gap back to the original 10px
  (the snug 2px spacing from 2.6.1 is undone).
* Kept the slight shadow on each thumbnail (deeper on hover / active).

= 2.6.1 — Tighter gallery thumbnails =
* The product gallery thumbnail strip now sits snug: the gap between
  thumbnails is reduced from 10px to 2px so they stick together.
* Added a slight shadow to each thumbnail (a touch deeper on hover / the
  active thumbnail) for subtle depth.

= 2.6.0 — Built-in product reviews (no plugin required) =
* New: the full ZYMARG Reviews experience is now native to the theme — no
  separate plugin and no Elementor needed. It renders inside the WooCommerce
  single-product "Reviews" tab with the exact same design (rating summary,
  star-breakdown bars, All/Media filters, review feed with photos and
  "Verified Buyer" badges).
* New: a "Write a Review" button appears on My Account → Orders (and View
  Order) for completed orders within a 15/30-day window. It links to the
  product page, auto-opens the Reviews tab and reveals the review form
  (secure, nonce-gated).
* Reviews are stored as native WooCommerce reviews, so they count toward the
  product's star average and reporting. Optional photo uploads, auto-approve
  for verified buyers, and a completion reminder email are supported.
* Admin settings live under WooCommerce → ZYMARG Reviews (review window,
  media limits, moderation, button labels, reminder email).
* Fully responsive across mobile, tablet and desktop. Render options are
  filterable via `zymarg_os_reviews_settings`.

= 2.5.20 — Summary nudge tweak =
* On tablet and desktop the Product Summary block is now positioned 4% lower
  (raised 1% from the previous 5%).

= 2.5.19 — Revert summary card; nudge it down 5% =
* Reverted the v2.5.18 change: the Product Summary boxed card is restored exactly
  as it was before.
* On tablet and desktop (two-column layout) the summary block is now positioned
  5% lower.

= 2.5.18 — Summary aligns with the product image =
* On desktop/tablet the Product Summary now sits flush and top-aligned with the
  product image: the title starts level with the top of the image instead of
  being pushed down by the summary's boxed padding. (The boxed "card" styling
  was removed from the summary to achieve this.)

= 2.5.17 — 10 products across two rows =
* Related products now show 10 items in a 5-column grid (two tidy rows on
  desktop/tablet; 2 columns on phones).
* Added a filter to request 10 items for Dokan's "More Products" section where
  the Dokan version allows it.

= 2.5.16 — Product grid alignment fix (no more ragged rows) =
* Fixed the ragged rows and phantom empty slots in the Related and "More
  Products" grids (e.g. 3+4+1 instead of clean rows, or "space for 8" when only
  6 products exist). Cause: WooCommerce's clearfix pseudo-elements and the
  "clear" on first items were leaking into the CSS grid as invisible cells.
  These are now neutralised so the grid lays out evenly.
* Columns are now consistent: 4 across on desktop and tablet (so 8 related
  products sit in two tidy rows) and 2 across on phones.

= 2.5.15 — More related products, grid fixes & swatch alignment =
* Related products increased from 4 to 8 (two rows of four; fewer show if the
  product simply has fewer related items).
* Every product list on the single product page — related, up-sells and any
  "More Products" / vendor list inside a tab — now uses one responsive grid
  (4 / 3 / 2 / 1 columns) instead of stacking as vertical cards. Hardened to
  override Dokan / legacy float styles.
* Fixed variation swatch alignment: swatch chips are now consistent auto-width
  pills that sit inline neatly next to the product image column.
* Gallery thumbnails (the small variety images under the main image) are now
  about 50% larger and fill their cells, while staying responsive.

= 2.5.14 — Visible product-page trust icons =
* Fixed the product page trust badge icons that were invisible (purple icon on a
  purple circle). The icons are now white on a lighter, brighter purple circle
  so they read clearly.

= 2.5.13 — Fix related/up-sells product grid on single product page =
* Fixed the "more products" (related & up-sells) grid on the single product page
  which could collapse into a squished half-width column. Those sections now
  always span the full width and use a properly responsive grid: 4 columns on
  desktop, 3 on tablet, 2 on phones (1 on very narrow screens). Product card
  images are normalised so they never overflow.

= 2.5.12 — Next-level single product page =
* New: a completely redesigned, conversion-focused single product page with full
  variable-product support. Sticky image gallery (zoom + lightbox + thumbnails),
  variation swatches (colour chips / button pills) synced to WooCommerce's live
  price/image/stock with unavailable options dimmed, a quantity stepper (+/-), a
  percentage-off sale badge, a trust-badge row, and restyled tabs & related
  products. Built with hooks + a scoped stylesheet (no template overrides) so it
  stays compatible with WooCommerce/Dokan updates. Toggle it in Customize →
  ZYMARG OS → Modules → "Enhanced single product page". Documented on the Help page.

= 2.5.11 — Plugins screen in the ZYMARG OS menu =
* New: "Plugins" item in the ZYMARG OS menu with a two-column page — "Add Plugin"
  (upload a plugin zip or browse the directory) and "Installed Plugins" (a live
  list with Active/Inactive badges plus a button to the full Plugins screen).
  Activate/deactivate/delete still use the native WordPress screen. Only shown to
  users who can install plugins; respects DISALLOW_FILE_MODS. Documented in Help.

= 2.5.10 — Slightly larger menu icon =
* The ZYMARG OS menu icon is now ~10% larger again for better visibility in the
  sidebar (still white on a transparent background).

= 2.5.9 — Update/Upload Theme from the ZYMARG OS menu =
* New: "Update / Upload Theme" item in the ZYMARG OS menu (and a button on the
  Welcome screen). Upload a new theme zip in one click without going to
  Appearance → Themes. Uploading an already-installed theme uses WordPress's
  built-in replace/update flow and keeps your settings. Only shown to users who
  can install themes; respects DISALLOW_FILE_MODS. Documented on the Help page.

= 2.5.8 — Help page: more feature guides =
* Added in-dashboard Help instructions for features that previously had none:
  Mega Menu (with copy-paste CSS classes and step-by-step setup), the
  WooCommerce shop features (Quick View, off-canvas cart drawer, sticky
  add-to-cart, gallery zoom/lightbox, shop columns), the product Grid Skin
  (zymarg-grid-skin) for builder/plugin grids, and a note on Scroll to Top.

= 2.5.7 — One-click header/footer gap removers =
* New: two toggles in Customize → ZYMARG OS → Spacing — "I already have a header
  above (remove the top gap)" and "I already have a footer below (remove the
  bottom gap)". For sites using a header/footer from another theme/plugin, these
  close the empty gap with one click, no CSS. Default off, so sites without an
  external header/footer keep their balanced spacing. Per site. Documented on
  the in-dashboard Help page.

= 2.5.6 — White menu icon =
* The ZYMARG OS menu icon is now solid white on a transparent background and
  5% larger, so it reads clearly against the dark admin sidebar.

= 2.5.5 — Correct menu icon size =
* Fixed the oversized menu icon. WordPress shows PNG menu icons at their raw
  pixel size (no scaling), so the icon overflowed the row. The icon is now a
  grayscale logo embedded in an SVG data URI — WordPress sizes SVG icons to 20px
  automatically (same method as the original v2.5.0 icon), so it sits correctly.

= 2.5.4 — Grayscale, balanced menu icon =
* The ZYMARG OS menu icon is now grayscale (soft black-and-white tones) and
  has padding around it so it no longer looks oversized — it now sits balanced
  next to the other sidebar items.

= 2.5.3 — Menu icon fix =
* Fixed: the dedicated "ZYMARG OS" menu showed no icon. WordPress strips inline
  "data:" PNG icons via esc_url(), so the v2.5.2 inline icon never rendered. The
  icon now ships as a tiny 2 KB PNG file (ZYMARG/menu-icon.png) and displays
  correctly in the sidebar.

= 2.5.2 — Lightweight menu icon =
* The menu icon is now embedded inline as a tiny 2 KB data URI instead of
  bundling the full 544 KB logo file. The theme stays lean and the branded
  icon still shows in the sidebar. Removed /ZYMARG/zymarg-logo.png.

= 2.5.1 — Branded menu icon =
* The dedicated "ZYMARG OS" sidebar menu now uses the official ZYMARG logo
  instead of the auto-generated monochrome Discovery Spark icon.

= 2.5.0 — Dedicated admin menu =
* ZYMARG OS now has its own top-level sidebar menu (with a monochrome Discovery
  Spark icon), like WooCommerce/Dokan/Elementor — a branded home in the
  dashboard. Includes a Welcome screen (version, big CTAs, quick-setting tiles
  to every Customizer panel) and the Help guide, which moved here from
  Appearance. Adds a "Customize" quick link too.

= 2.4.0 — Result sorting =
* Search & archive pages now have a Sort dropdown: Latest, Oldest, Name (A–Z),
  and — on WooCommerce — Price low→high and high→low. It auto-submits and
  preserves the search query. WooCommerce shop/category pages keep their own
  native ordering dropdown (now styled to match).
* All result/archive layouts remain fully responsive (3→2→1 column grids,
  mobile-friendly sort bar).

= 2.3.0 — Results & archive pages =
* Added styled search.php and archive.php templates: results/posts shown as an
  on-brand responsive card grid (with product price on WooCommerce), a query +
  result-count heading, the search form, and pagination. (WooCommerce product
  category/search pages keep using WooCommerce's own grid.)
* The [zymarg_search] bar is now a real search form: pressing Enter goes to the
  full results page, and the dropdown gains a "See all results →" link.

= 2.2.1 =
* Help page: added an "Add the search bar to your header" step-by-step card
  (synced-pattern Block header + the [zymarg_search] shortcode).

= 2.2.0 — Algolia search =
* Live Search can now run on Algolia: Customize → ZYMARG OS → Search → set
  engine to "Algolia" and enter your Application ID, Search-Only API Key and
  Index name. Searches then run directly in the visitor's browser against
  Algolia — zero search load on your WordPress server, scaling to 100k+
  products with instant, typo-tolerant results.
* The built-in WP_Query search remains as an automatic fallback (used only when
  Algolia isn't configured), so the search bar never breaks.
* Note: index your products into Algolia with the free "WP Search with Algolia"
  plugin; the theme handles the search UI + querying, not indexing.
* The Discovery Spark now appears inside the search bar by default (disable
  with [zymarg_search spark="false"]).

= 2.1.0 — SEO & Scale =
* SEO Schema module: Organization + WebSite (Sitelinks search box) JSON-LD for
  rich results, auto-deferring to Yoast/Rank Math/SEOPress/AIOSEO to avoid
  duplicates (WooCommerce keeps providing Product schema).
* Breadcrumbs module: [zymarg_breadcrumbs] shortcode + optional auto-display
  (Customize → Spacing) + BreadcrumbList JSON-LD. Smart trail for pages,
  posts, products (shop → category → product), archives and search.
* Live Search upgraded for scale: title-focused search_columns, short-term
  result caching, and a zymarg_os_live_search_args filter. Automatically uses
  ElasticPress / Relevanssi / Algolia when installed (recommended for 100k+
  products).

= 2.0.0 — Smart UX =
* Instant Load: prefetches internal pages on hover/tap so navigation feels
  instant (skips cart/checkout/account/admin; respects Save-Data).
* Scroll Animations: add the "zymarg-reveal" class (or --left/--right/--zoom)
  to any block to reveal it on scroll. Progressive + reduced-motion safe.
* Live Search: [zymarg_search] shows instant search-as-you-type results
  (products on WooCommerce sites, otherwise posts/pages) in a branded dropdown.
* All three are toggleable modules; documented in Appearance → ZYMARG OS Help.

= 1.9.0 =
* Header & Footer visibility rules: "Show header/footer on" — Entire site,
  Only specific pages, or All pages except… (comma-separated page IDs). Plus
  per-page "Hide the header/footer on this page" checkboxes in the page editor
  "ZYMARG OS" box (alongside Hide page title).
* Help page expanded: added Header & Footer (incl. visibility) and Per-page
  controls cards. Going forward, every major feature is documented in
  Appearance → ZYMARG OS Help.

= 1.8.0 =
* New optional Header & Footer (Customize -> ZYMARG OS -> Header & Footer),
  both off by default so plugin-managed setups are unaffected. Each has two
  content sources:
  - Simple: built-in layout (header = logo + menu with layout/sticky/width/
    height/background; footer = 1–4 widget columns + copyright) — 4 new Footer
    Column widget areas added.
  - Block: render a synced pattern you design in the block editor, giving
    unlimited rows, columns and custom widths/heights.
* Added "ZYMARG Header Bar" and "ZYMARG Footer" starter block patterns, a
  responsive mobile menu toggle, and header/footer styling.

= 1.7.3 =
* Added a one-click "Turn WooCommerce Coming Soon OFF" button to the dashboard
  notice. Unlike the runtime override, this actually writes WooCommerce's own
  setting to Live (woocommerce_coming_soon = no) — so WooCommerce's settings
  page reflects it too. Capability-checked and nonce-protected, with success
  feedback.

= 1.7.2 =
* Site Mode gains a "Force the site live" option: when Mode = Live, the theme
  overrides other coming-soon / maintenance systems (e.g. WooCommerce's built-in
  Coming Soon) on the front end so the site is public. The override is applied
  at runtime via pre_option filters — nothing is written to other plugins'
  settings, so it's fully reversible.
* Added dashboard notices: confirms what's being overridden when Force Live is
  on, or warns when another coming-soon system may be hiding the site while it's
  off. Extensible via the zymarg_os_force_live_overrides and
  zymarg_os_detected_coming_soon filters (+ the zymarg_os_force_live action).

= 1.7.1 =
* Site Mode now supports a Custom HTML layout: in Customize -> ZYMARG OS ->
  Site Mode, set Layout to "Custom HTML" and paste your own design for the
  Coming Soon / Maintenance page. Shortcodes (e.g. [zymarg_spark]) are
  processed; admins with unfiltered_html may include styles/scripts.

= 1.7.0 =
* New Site Mode superpower (Customize -> ZYMARG OS -> Site Mode): switch the
  site between Live, Coming Soon, and Maintenance. Visitors see a branded,
  orb-background placeholder with your headline, message, optional launch
  countdown, social links and a login link, while logged-in admins keep seeing
  the real site. Maintenance mode returns an SEO-safe HTTP 503. An admin-bar
  badge reminds you while it's active.

= 1.6.1 =
* You can now hide the page title: a "Hide the page title on this page"
  checkbox in the page editor (ZYMARG OS box), plus a global "Hide all page
  titles" toggle in Customize -> ZYMARG OS -> Spacing. (The blank-canvas and
  full-width page templates already omit the title.)

= 1.6.0 =
* Added an in-dashboard Help page (Appearance -> ZYMARG OS Help): a friendly
  guide to the Discovery Spark, dark-mode toggle, block patterns and fonts,
  with one-click "Copy" buttons for every shortcode and live Spark previews.
* Removed the bundled brand logo image files from the ZYMARG/ folder (kept the
  Discovery Spark component and demo). The theme thumbnail is unaffected.

= 1.5.1 =
* Added the official ZYMARG brand assets to the ZYMARG/ folder:
  zymarg-logo.svg (vector), zymarg-logo-horizontal.png (lockup),
  zymarg-mark.png (square mark) and zymarg-logo.jpg.
* Rebuilt the theme thumbnail (screenshot.png) to feature the official ZYMARG
  logo on the signature orb background.

= 1.5.0 =
* Dark / Light theme system: choose Light, Dark, Auto (follow the visitor's
  device) or Toggle (visitor switch) in Customize -> ZYMARG OS -> Colours.
  Dark tokens (tokens/dark.css) re-theme every component; a no-flash early
  script and a [zymarg_theme_toggle] button/​helper are included.
* Added "Container" starter patterns — Row (flex), Grid (responsive auto-fit),
  Split (content + media) and Section (full-width padded) — so you can drop in
  a container and drag items around in the free editor, Elementor-style.

= 1.4.0 =
* Gutenberg, leveled up: added a "ZYMARG OS" block-pattern library — hero with
  the orb background, feature cards, gradient CTA, stats bar, product section,
  Discovery Spark feature and vendor spotlight — so you can build pages in the
  free block editor without Elementor.
* Added custom block STYLE variations: buttons (Primary/Outline/Ghost), group
  (Card/Orb Section/Gradient Band), rounded image and brand separator. These
  preview correctly inside the editor (token + block CSS loaded there too).
* Added a decoupled product-grid SKIN (components/grid-skin.css): add the
  class "zymarg-grid-skin" to your product-grid plugin's Elementor widget (or
  any wrapper) and its cards, images, prices and buttons inherit ZYMARG styling.

= 1.3.0 =
* Fonts: "Self-host" now AUTO-DOWNLOADS Inter + Sora from Google to
  /uploads/zymarg-os-fonts/ and serves them locally (faster + GDPR-friendly).
  Runs on Customizer publish, with a manual "Download fonts now" admin button
  and a safe fallback to the static stylesheet / system fonts.
* Updates: added a self-hosted theme update mechanism. Point the theme at a
  JSON manifest via the ZYMARG_OS_UPDATE_URI constant or the
  zymarg_os_update_manifest_url filter and updates appear in Dashboard ->
  Updates like any theme. Inactive (safe) until a URL is configured.
* Added the ZYMARG/ folder with the ZYMARG Discovery Spark component:
  zymarg-discovery-spark.css, a reusable PHP helper [zymarg_discovery_spark()]
  + [zymarg_spark] shortcode with size (xs-xl), motion and colour variations,
  and a standalone demo matrix (discovery-spark-demo.html).

= 1.2.0 =
* Reorganised the CSS into a cleaner, de-duplicated architecture:
  - tokens/ — split design tokens into colors, typography, spacing, radius,
    shadows, opacity (new), transitions and z-index (single source of truth).
  - base/ — reset + element typography.
  - helpers/ — utility classes (colors, spacing, grid, flex, visibility),
    moved out of the old design-system/ and layouts/.
  - ui/ — new reusable primitives: modal, drawer, toast, tooltip, dropdown,
    tabs and loading (spinner/overlay/skeleton).
* WooCommerce Quick View now reuses the generic ui/modal, and the off-canvas
  cart reuses the generic ui/drawer (no more duplicated modal/drawer CSS).
* Removed the old design-system/ folder and components/skeleton.css after
  moving their contents; rewired the enqueue cascade accordingly.
* New opacity tokens now drive disabled buttons and input placeholders.

= 1.1.1 =
* Added screenshot.png (1200x900) so the theme shows a branded preview on the
  Appearance -> Themes screen.

= 1.1.0 =
* Refactored the CSS into a modular architecture: design-system/ (variables,
  colors, typography, spacing, grid), components/ (buttons, cards, forms,
  badges, skeleton, navigation), layouts/ (container, section, responsive) and
  woocommerce/ (product, cart, checkout, account).
* Added assets/icons/ (SVG sprite + helper classes) and assets/animations/
  (keyframes + animation utilities, incl. skeleton shimmer and optional orb
  drift).
* Stylesheets now load in cascade order and WooCommerce CSS is split so only
  the relevant files load on shop/Dokan contexts.
* New utility classes for colour, spacing, grid/flex, typography and badges.

= 1.0.0 =
* Initial release.
* Modular activation system with Performance, WooCommerce, Mega Menu,
  Scroll to Top, Custom Fonts, White Label and LearnDash modules.
* ZYMARG design tokens, dual-orb background, Inter/Sora typography.
* Customizer controls for colours, typography (incl. custom font upload),
  spacing and buttons, with live colour preview.
* WooCommerce + Dokan integration: Quick View, off-canvas cart, sticky
  add-to-cart, configurable shop columns.
* Custom layout hooks, theme.json palette, blank-canvas and full-width page
  templates.
