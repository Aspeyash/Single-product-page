<?php
/**
 * The template for displaying single posts and attachments.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

get_header();

zymarg_os_before_content();
?>
<div id="content" class="zymarg-container zymarg-site-content">
	<?php zymarg_os_content_top(); ?>

	<main id="main" class="zymarg-main">
		<?php
		while ( have_posts() ) {
			the_post();
			?>
			<article id="post-<?php the_ID(); ?>" <?php post_class( 'zymarg-entry' ); ?>>
				<header class="zymarg-entry__header">
					<?php the_title( '<h1 class="zymarg-entry__title">', '</h1>' ); ?>
				</header>

				<?php if ( has_post_thumbnail() ) : ?>
					<figure class="zymarg-entry__thumb">
						<?php the_post_thumbnail( 'large' ); ?>
					</figure>
				<?php endif; ?>

				<div class="zymarg-entry__content">
					<?php
					the_content();

					wp_link_pages(
						array(
							'before' => '<div class="zymarg-page-links">' . esc_html__( 'Pages:', 'zymarg-os' ),
							'after'  => '</div>',
						)
					);
					?>
				</div>
			</article>
			<?php

			if ( comments_open() || get_comments_number() ) {
				comments_template();
			}
		}
		?>
	</main>

	<?php zymarg_os_content_bottom(); ?>
</div>
<?php
zymarg_os_after_content();

get_footer();
