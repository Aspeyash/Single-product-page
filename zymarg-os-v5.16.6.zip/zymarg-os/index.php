<?php
/**
 * The main template file.
 *
 * The catch-all fallback. Since ZYMARG OS is built for page-builder /
 * marketplace use, this stays simple: a content wrapper, the loop, and the
 * theme's custom layout hooks so plugins can inject around the content.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

get_header();

zymarg_os_before_content();
?>
<div id="content" class="zymarg-container zymarg-site-content">
	<?php zymarg_os_content_top(); ?>

	<main id="main" class="zymarg-main">
		<?php
		if ( have_posts() ) {
			while ( have_posts() ) {
				the_post();
				?>
				<article id="post-<?php the_ID(); ?>" <?php post_class( 'zymarg-entry' ); ?>>
					<header class="zymarg-entry__header">
						<?php the_title( '<h1 class="zymarg-entry__title">', '</h1>' ); ?>
					</header>
					<div class="zymarg-entry__content">
						<?php the_content(); ?>
					</div>
				</article>
				<?php
			}

			the_posts_pagination(
				array(
					'mid_size'  => 1,
					'prev_text' => esc_html__( 'Previous', 'zymarg-os' ),
					'next_text' => esc_html__( 'Next', 'zymarg-os' ),
				)
			);
		} else {
			?>
			<p><?php esc_html_e( 'Nothing found.', 'zymarg-os' ); ?></p>
			<?php
		}
		?>
	</main>

	<?php zymarg_os_content_bottom(); ?>
</div>
<?php
zymarg_os_after_content();

get_footer();
