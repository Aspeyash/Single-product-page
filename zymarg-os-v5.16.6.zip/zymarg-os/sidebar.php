<?php
/**
 * Sidebar (intentionally minimal).
 *
 * ZYMARG OS ships no sidebar by design — the theme owns its layouts end to end.
 * This file exists so that any get_sidebar() call (e.g. from WooCommerce or a
 * plugin) loads a clean, empty sidebar instead of falling back to a stray or
 * legacy sidebar.php that could print WordPress's default widgets (Search,
 * Pages, Archives, Categories…).
 *
 * It renders nothing unless you deliberately enable the optional Sidebar widget
 * area (Customize → ZYMARG OS → Widget Areas) and add your own widgets.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

if ( is_active_sidebar( 'sidebar-1' ) ) {
	?>
	<aside id="secondary" class="zymarg-sidebar widget-area" role="complementary">
		<?php dynamic_sidebar( 'sidebar-1' ); ?>
	</aside>
	<?php
}
