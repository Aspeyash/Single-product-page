<?php
/**
 * Page title visibility control.
 *
 * The theme prints the page <h1> title at the top of pages. This adds a way to
 * hide it:
 *   - Per page: a "Hide page title" checkbox in the page editor (Page panel).
 *   - Globally: Customize -> ZYMARG OS -> Modules-style toggle isn't used; the
 *     global switch lives under the Layout option via the filter below.
 *
 * Helper: zymarg_os_show_page_title() returns whether to render the title.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/** Meta key storing the per-page hide flag. */
if ( ! defined( 'ZYMARG_OS_HIDE_TITLE_META' ) ) {
	define( 'ZYMARG_OS_HIDE_TITLE_META', '_zymarg_hide_title' );
}

/**
 * Register the meta box on pages.
 *
 * @return void
 */
function zymarg_os_add_title_metabox() {
	add_meta_box(
		'zymarg_os_title_box',
		__( 'ZYMARG OS', 'zymarg-os' ),
		'zymarg_os_render_title_metabox',
		'page',
		'side',
		'default'
	);
}
add_action( 'add_meta_boxes', 'zymarg_os_add_title_metabox' );

/**
 * Render the meta box checkbox.
 *
 * @param WP_Post $post Current post.
 * @return void
 */
function zymarg_os_render_title_metabox( $post ) {
	$hidden = (bool) get_post_meta( $post->ID, ZYMARG_OS_HIDE_TITLE_META, true );
	wp_nonce_field( 'zymarg_os_title_box', 'zymarg_os_title_nonce' );
	?>
	<p>
		<label>
			<input type="checkbox" name="zymarg_os_hide_title" value="1" <?php checked( $hidden ); ?> />
			<?php esc_html_e( 'Hide the page title on this page', 'zymarg-os' ); ?>
		</label>
	</p>
	<p class="description"><?php esc_html_e( 'Useful when your page builder or plugin already shows the title.', 'zymarg-os' ); ?></p>
	<?php
}

/**
 * Save the meta box value.
 *
 * @param int $post_id Post ID.
 * @return void
 */
function zymarg_os_save_title_metabox( $post_id ) {
	if ( ! isset( $_POST['zymarg_os_title_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['zymarg_os_title_nonce'] ) ), 'zymarg_os_title_box' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_page', $post_id ) ) {
		return;
	}

	if ( ! empty( $_POST['zymarg_os_hide_title'] ) ) {
		update_post_meta( $post_id, ZYMARG_OS_HIDE_TITLE_META, '1' );
	} else {
		delete_post_meta( $post_id, ZYMARG_OS_HIDE_TITLE_META );
	}
}
add_action( 'save_post_page', 'zymarg_os_save_title_metabox' );

/**
 * Global setting: hide page titles everywhere.
 *
 * @param WP_Customize_Manager $wp_customize Customizer manager.
 * @return void
 */
function zymarg_os_title_customizer( $wp_customize ) {
	if ( ! $wp_customize->get_section( 'zymarg_os_spacing_section' ) ) {
		return;
	}

	$wp_customize->add_setting(
		'zymarg_hide_page_titles',
		array(
			'default'           => false,
			'sanitize_callback' => 'zymarg_os_sanitize_checkbox',
		)
	);
	$wp_customize->add_control(
		'zymarg_hide_page_titles',
		array(
			'type'        => 'checkbox',
			'label'       => __( 'Hide all page titles', 'zymarg-os' ),
			'description' => __( 'Hide the title heading on every page (you can still override per page).', 'zymarg-os' ),
			'section'     => 'zymarg_os_spacing_section',
		)
	);
}
add_action( 'customize_register', 'zymarg_os_title_customizer', 20 );

/**
 * Whether the current page title should be rendered.
 *
 * @return bool
 */
function zymarg_os_show_page_title() {
	// Never on the front page.
	if ( is_front_page() ) {
		return false;
	}

	// Global toggle.
	if ( get_theme_mod( 'zymarg_hide_page_titles', false ) ) {
		return false;
	}

	// Per-page checkbox.
	$post_id = get_queried_object_id();
	if ( $post_id && get_post_meta( $post_id, ZYMARG_OS_HIDE_TITLE_META, true ) ) {
		return false;
	}

	/**
	 * Filter the final decision.
	 *
	 * @param bool $show Whether to show the page title.
	 */
	return (bool) apply_filters( 'zymarg_os_show_page_title', true );
}
