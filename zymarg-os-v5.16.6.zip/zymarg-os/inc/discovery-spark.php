<?php
/**
 * ZYMARG Discovery Spark™ component.
 *
 * Renders the animated triple-spark mark anywhere, with variations. Use:
 *
 *   PHP:        <?php zymarg_the_discovery_spark( array( 'size' => 'lg' ) ); ?>
 *   String:     $html = zymarg_discovery_spark( array( 'size' => 'md' ) );
 *   Shortcode:  [zymarg_spark size="xl" label="Featured"]
 *
 * Variations (args / shortcode atts):
 *   size    xs | sm | md | lg | xl   (default md — 16/20/24/32/48px)
 *   animate true | false             (default true; false adds --static)
 *   label   string                   accessible label (aria-label)
 *   class   string                   extra CSS classes
 *   purple  hex                      override --zds-spark-purple
 *   gold    hex                      override --zds-spark-gold
 *
 * The stylesheet (ZYMARG/zymarg-discovery-spark.css) is registered up front and
 * only enqueued the first time a spark is actually rendered, keeping pages lean.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register the Discovery Spark stylesheet (enqueued on demand).
 *
 * @return void
 */
function zymarg_os_register_discovery_spark() {
	wp_register_style(
		'zymarg-os-discovery-spark',
		ZYMARG_OS_URI . '/ZYMARG/zymarg-discovery-spark.css',
		array(),
		ZYMARG_OS_VERSION
	);
}
add_action( 'wp_enqueue_scripts', 'zymarg_os_register_discovery_spark' );
add_action( 'admin_enqueue_scripts', 'zymarg_os_register_discovery_spark' );

/**
 * The inner SVG (shared by every size variation).
 *
 * @return string
 */
function zymarg_os_discovery_spark_svg() {
	return '<svg class="zymarg-spark__svg" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">'
		. '<g class="zymarg-spark-group--accent">'
		. '<path class="zymarg-spark-item--purple" d="M10.4 5.4c0 1.32-0.24 2.4-1.44 2.4 1.2 0 1.44 1.08 1.44 2.4 0-1.32 0.24-2.4 1.44-2.4-1.2 0-1.44-1.08-1.44-2.4z"></path>'
		. '<path class="zymarg-spark-item--gold" d="M10.4 6.0c0 0.96-0.18 1.8-1.08 1.8 0.9 0 1.08 0.84 1.08 1.8 0-0.9 0.18-1.8 1.08-1.8-0.9 0-1.08-0.84-1.08-1.8z"></path>'
		. '</g>'
		. '<g class="zymarg-spark-group--companion">'
		. '<path class="zymarg-spark-item--purple" d="M9.5 10.92c0 2.25-0.45 4.12-2.4 4.12 1.95 0 2.4 1.87 2.4 4.12 0-2.25 0.45-4.12 2.4-4.12-1.95 0-2.4-1.87-2.4-4.12z"></path>'
		. '<path class="zymarg-spark-item--gold" d="M9.5 11.5c0 1.9-0.38 3.54-2.0 3.54 1.62 0 2.0 1.64 2.0 3.54 0-1.9 0.38-3.54 2.0-3.54-1.62 0-2.0-1.64-2.0-3.54z"></path>'
		. '</g>'
		. '<g class="zymarg-spark-group--hero">'
		. '<path class="zymarg-spark-item--purple" d="M15.2 5.6c0 3.45-0.69 6.3-4.08 6.3 3.39 0 4.08 2.85 4.08 6.3 0-3.45 0.69-6.3 4.08-6.3-3.39 0-4.08-2.85-4.08-6.3z"></path>'
		. '<path class="zymarg-spark-item--gold" d="M15.2 6.5c0 2.9-0.58 5.4-3.39 5.4 2.81 0 3.39 2.5 3.39 5.4 0-2.9 0.58-5.4 3.39-5.4-2.81 0-3.39-2.5-3.39-5.4z"></path>'
		. '</g>'
		. '</svg>';
}

/**
 * Build the Discovery Spark markup.
 *
 * @param array $args See file header for accepted keys.
 * @return string HTML.
 */
function zymarg_discovery_spark( $args = array() ) {
	$defaults = array(
		'size'    => 'md',
		'animate' => true,
		'label'   => __( 'ZYMARG Discovery Spark', 'zymarg-os' ),
		'class'   => '',
		'purple'  => '',
		'gold'    => '',
	);
	$args = wp_parse_args( $args, $defaults );

	// Validate the size variation.
	$allowed_sizes = array( 'xs', 'sm', 'md', 'lg', 'xl' );
	$size          = in_array( $args['size'], $allowed_sizes, true ) ? $args['size'] : 'md';

	// Enqueue the stylesheet the first time a spark is rendered.
	if ( ! wp_style_is( 'zymarg-os-discovery-spark', 'enqueued' ) ) {
		wp_enqueue_style( 'zymarg-os-discovery-spark' );
	}

	$classes = array( 'zymarg-spark', 'zymarg-spark--' . $size );
	if ( empty( $args['animate'] ) || 'false' === $args['animate'] || '0' === (string) $args['animate'] ) {
		$classes[] = 'zymarg-spark--static';
	}
	if ( $args['class'] ) {
		$classes[] = sanitize_html_class( $args['class'] );
	}

	// Optional inline colour overrides.
	$style = '';
	if ( $args['purple'] && preg_match( '/^#[0-9a-fA-F]{3,8}$/', $args['purple'] ) ) {
		$style .= '--zds-spark-purple:' . $args['purple'] . ';';
	}
	if ( $args['gold'] && preg_match( '/^#[0-9a-fA-F]{3,8}$/', $args['gold'] ) ) {
		$style .= '--zds-spark-gold:' . $args['gold'] . ';';
	}

	return sprintf(
		'<span class="%1$s" role="img" aria-label="%2$s"%3$s>%4$s</span>',
		esc_attr( implode( ' ', $classes ) ),
		esc_attr( $args['label'] ),
		$style ? ' style="' . esc_attr( $style ) . '"' : '',
		zymarg_os_discovery_spark_svg()
	);
}

/**
 * Echo the Discovery Spark.
 *
 * @param array $args See zymarg_discovery_spark().
 * @return void
 */
function zymarg_the_discovery_spark( $args = array() ) {
	echo zymarg_discovery_spark( $args ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- markup escaped internally.
}

/**
 * Shortcode: [zymarg_spark size="md" animate="true" label="..." class="" purple="#6833EA" gold="#FFD166"]
 *
 * @param array $atts Shortcode attributes.
 * @return string
 */
function zymarg_os_discovery_spark_shortcode( $atts ) {
	$atts = shortcode_atts(
		array(
			'size'    => 'md',
			'animate' => 'true',
			'label'   => __( 'ZYMARG Discovery Spark', 'zymarg-os' ),
			'class'   => '',
			'purple'  => '',
			'gold'    => '',
		),
		$atts,
		'zymarg_spark'
	);

	$atts['animate'] = filter_var( $atts['animate'], FILTER_VALIDATE_BOOLEAN );

	return zymarg_discovery_spark( $atts );
}
add_shortcode( 'zymarg_spark', 'zymarg_os_discovery_spark_shortcode' );
