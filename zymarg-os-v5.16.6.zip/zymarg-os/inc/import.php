<?php
/**
 * ZYMARG OS — Import / Export.
 *
 * A dedicated top-level "Import / Export" admin menu with an elegant, on-brand
 * card UI. Everything is native to the theme — no extra plugin — and works on
 * real WooCommerce data (products + product_cat terms).
 *
 * IMPORT
 *   - Demo Content       : one-click bundled starter catalogue.
 *   - Products (CSV)      : bulk-create products (auto-creates categories).
 *   - Categories (CSV)    : build the product-category tree.
 *
 * EXPORT & BACKUP
 *   - Products (CSV)      : export your catalogue (round-trips with the importer).
 *   - Categories (CSV)    : export your category tree.
 *   - Store Snapshot      : one ZIP with products.csv + categories.csv + a
 *                           manifest — a portable, move-between-sites backup.
 *   - Restore Snapshot    : upload a snapshot ZIP to recreate it elsewhere.
 *
 * EXTRAS
 *   - Live store stats strip.
 *   - Drag-and-drop uploads with an instant CSV preview (rows + columns).
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/* ====================================================================== *
 * Capability + small helpers
 * ====================================================================== */

/**
 * Capability required to use the Import / Export screen.
 *
 * @return string
 */
function zymarg_os_import_cap() {
	return class_exists( 'WooCommerce' ) ? 'manage_woocommerce' : 'manage_options';
}

/**
 * Absolute URL of the Import / Export admin screen.
 *
 * @return string
 */
function zymarg_os_import_page_url() {
	return admin_url( 'admin.php?page=zymarg-os-import' );
}

/**
 * Whether WooCommerce is available (products / categories need it).
 *
 * @return bool
 */
function zymarg_os_import_woo_ready() {
	return class_exists( 'WooCommerce' ) && function_exists( 'wc_get_product' );
}

/* ====================================================================== *
 * Menu + assets
 * ====================================================================== */

/**
 * Get / set the Import / Export page hook suffix.
 *
 * Stored when the submenu is registered so the asset loader can match the
 * exact admin-page hook (which differs for submenu pages).
 *
 * @param string|null $set Hook suffix to store (internal).
 * @return string
 */
function zymarg_os_import_page_hook( $set = null ) {
	static $hook = '';
	if ( null !== $set ) {
		$hook = (string) $set;
	}
	return $hook;
}

/**
 * Register "Import / Export" as a submenu under the ZYMARG OS menu.
 *
 * Runs at priority 20 so the parent "zymarg-os" menu (registered in
 * inc/admin-menu.php) already exists.
 *
 * @return void
 */
function zymarg_os_import_register_menu() {
	$hook = add_submenu_page(
		'zymarg-os',
		__( 'Import / Export', 'zymarg-os' ),
		__( 'Import / Export', 'zymarg-os' ),
		zymarg_os_import_cap(),
		'zymarg-os-import',
		'zymarg_os_import_render_page'
	);
	if ( $hook ) {
		zymarg_os_import_page_hook( $hook );
	}
}
add_action( 'admin_menu', 'zymarg_os_import_register_menu', 20 );

/**
 * Enqueue the Import / Export screen assets (only on our page).
 *
 * @param string $hook Current admin page hook.
 * @return void
 */
function zymarg_os_import_enqueue( $hook ) {
	$page_hook = zymarg_os_import_page_hook();
	if ( '' === $page_hook || $hook !== $page_hook ) {
		return;
	}
	$ver = defined( 'ZYMARG_OS_VERSION' ) ? ZYMARG_OS_VERSION : '1.0.0';

	wp_enqueue_style(
		'zymarg-os-admin-import',
		ZYMARG_OS_URI . '/assets/css/admin-import.css',
		array(),
		$ver
	);

	wp_enqueue_script(
		'zymarg-os-admin-import',
		ZYMARG_OS_URI . '/assets/js/admin-import.js',
		array(),
		$ver,
		true
	);
	wp_localize_script(
		'zymarg-os-admin-import',
		'ZymargImport',
		array(
			'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
			'uploadNonce' => wp_create_nonce( 'zymarg_import_upload' ),
			'batchNonce'  => wp_create_nonce( 'zymarg_import_batch' ),
			'exportNonce' => wp_create_nonce( 'zymarg_export' ),
			'batchSize'   => (int) apply_filters( 'zymarg_os_import_batch_size', 6 ),
			'i18n'        => array(
				'working'    => __( 'Working…', 'zymarg-os' ),
				'rows'       => __( 'rows detected', 'zymarg-os' ),
				'columns'    => __( 'Columns', 'zymarg-os' ),
				'drop'       => __( 'Drop your CSV here, or click to choose', 'zymarg-os' ),
				'notCsv'     => __( 'That does not look like a .csv file.', 'zymarg-os' ),
				'selected'   => __( 'Selected', 'zymarg-os' ),
				'uploading'  => __( 'Uploading file…', 'zymarg-os' ),
				'importing'  => __( 'Importing products…', 'zymarg-os' ),
				'complete'   => __( 'Import complete', 'zymarg-os' ),
				'imported'   => __( 'created', 'zymarg-os' ),
				'updated'    => __( 'updated', 'zymarg-os' ),
				'skipped'    => __( 'skipped', 'zymarg-os' ),
				'failed'     => __( 'failed', 'zymarg-os' ),
				'noImageHd'  => __( 'Imported without an image', 'zymarg-os' ),
				'failHd'     => __( 'Issues', 'zymarg-os' ),
				'viewProd'   => __( 'View products', 'zymarg-os' ),
				'genericErr' => __( 'Something went wrong. Please try again.', 'zymarg-os' ),
				'andMore'    => __( '…and %d more', 'zymarg-os' ),
				'exporting'  => __( 'Preparing export…', 'zymarg-os' ),
				'exported'   => __( 'exported', 'zymarg-os' ),
				'dlReady'    => __( 'Your download is ready.', 'zymarg-os' ),
				'download'   => __( 'Download', 'zymarg-os' ),
			),
			'productsUrl' => admin_url( 'edit.php?post_type=product' ),
		)
	);
}
add_action( 'admin_enqueue_scripts', 'zymarg_os_import_enqueue' );

/* ====================================================================== *
 * Result transient (Post/Redirect/Get feedback)
 * ====================================================================== */

/**
 * Store an import/export result for the current user, to show after redirect.
 *
 * @param array $result Result payload.
 * @return void
 */
function zymarg_os_import_store_result( $result ) {
	set_transient( 'zymarg_os_import_result_' . get_current_user_id(), $result, 120 );
}

/**
 * Fetch and clear the stored result for the current user.
 *
 * @return array|false
 */
function zymarg_os_import_take_result() {
	$key    = 'zymarg_os_import_result_' . get_current_user_id();
	$result = get_transient( $key );
	if ( false !== $result ) {
		delete_transient( $key );
	}
	return $result;
}

/**
 * Redirect back to the Import / Export screen after handling a form.
 *
 * @param array $result Result payload to display.
 * @return void
 */
function zymarg_os_import_redirect_back( $result ) {
	zymarg_os_import_store_result( $result );
	wp_safe_redirect( zymarg_os_import_page_url() );
	exit;
}

/* ====================================================================== *
 * CSV reading + header normalisation
 * ====================================================================== */

/**
 * Map a raw CSV header to a canonical field key.
 *
 * Accepts both ZYMARG's simple headers and WooCommerce's export headers.
 *
 * @param string $header Raw header cell.
 * @return string Canonical key (may be the slugified original if unknown).
 */
function zymarg_os_import_normalize_header( $header ) {
	$h = strtolower( trim( $header ) );
	$h = preg_replace( '/[^a-z0-9]+/', '_', $h );
	$h = trim( $h, '_' );

	$map = array(
		'name'              => 'name',
		'product_name'      => 'name',
		'title'             => 'name',
		'sku'               => 'sku',
		'regular_price'     => 'regular_price',
		'price'             => 'regular_price',
		'sale_price'        => 'sale_price',
		'categories'        => 'categories',
		'category'          => 'categories',
		'description'       => 'description',
		'short_description' => 'short_description',
		'stock'             => 'stock',
		'in_stock'          => 'stock',
		'quantity'          => 'stock',
		'published'         => 'published',
		'status'            => 'published',
		'images'            => 'images',
		'image'             => 'images',
		// Category CSV.
		'slug'              => 'slug',
		'parent'            => 'parent',
	);

	return isset( $map[ $h ] ) ? $map[ $h ] : $h;
}

/**
 * Read a CSV file into an array of associative rows keyed by canonical header.
 *
 * @param string $path Path to a readable CSV file.
 * @return array|WP_Error
 */
function zymarg_os_import_read_csv( $path ) {
	if ( ! is_readable( $path ) ) {
		return new WP_Error( 'zymarg_csv', __( 'The CSV file could not be read.', 'zymarg-os' ) );
	}

	$handle = fopen( $path, 'r' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
	if ( false === $handle ) {
		return new WP_Error( 'zymarg_csv', __( 'The CSV file could not be opened.', 'zymarg-os' ) );
	}

	$header = fgetcsv( $handle, 0, ',', '"', '' );
	if ( ! is_array( $header ) ) {
		fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		return new WP_Error( 'zymarg_csv', __( 'The CSV file appears to be empty.', 'zymarg-os' ) );
	}

	// Strip a UTF-8 BOM from the first header cell if present.
	if ( isset( $header[0] ) ) {
		$header[0] = preg_replace( '/^\xEF\xBB\xBF/', '', $header[0] );
	}

	$keys  = array_map( 'zymarg_os_import_normalize_header', $header );
	$count = count( $keys );
	$rows  = array();

	while ( ( $data = fgetcsv( $handle, 0, ',', '"', '' ) ) !== false ) {
		$non_empty = array_filter(
			$data,
			static function ( $v ) {
				return '' !== trim( (string) $v );
			}
		);
		if ( empty( $non_empty ) ) {
			continue;
		}

		$data   = array_slice( $data, 0, $count );
		$data   = array_pad( $data, $count, '' );
		$rows[] = array_combine( $keys, $data );
	}

	fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
	return $rows;
}

/**
 * Validate + locate an uploaded file of a given extension, returning its path.
 *
 * @param string $field    $_FILES key.
 * @param string $ext_want Expected extension ('csv' or 'zip').
 * @return string|WP_Error Temp path on success.
 */
function zymarg_os_import_uploaded_file( $field, $ext_want = 'csv' ) {
	if ( empty( $_FILES[ $field ] ) || ! isset( $_FILES[ $field ]['tmp_name'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
		/* translators: %s: file extension */
		return new WP_Error( 'zymarg_file', sprintf( __( 'Please choose a .%s file to upload.', 'zymarg-os' ), $ext_want ) );
	}

	$file = $_FILES[ $field ]; // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash

	if ( ! empty( $file['error'] ) ) {
		return new WP_Error( 'zymarg_file', __( 'The file failed to upload. Please try again.', 'zymarg-os' ) );
	}
	if ( empty( $file['tmp_name'] ) || ! is_uploaded_file( $file['tmp_name'] ) ) {
		return new WP_Error( 'zymarg_file', __( 'No valid upload was received.', 'zymarg-os' ) );
	}

	$name = isset( $file['name'] ) ? sanitize_file_name( wp_unslash( $file['name'] ) ) : '';
	$ext  = strtolower( pathinfo( $name, PATHINFO_EXTENSION ) );

	if ( $ext_want !== $ext ) {
		/* translators: %s: file extension */
		return new WP_Error( 'zymarg_file', sprintf( __( 'Please upload a .%s file.', 'zymarg-os' ), $ext_want ) );
	}

	return $file['tmp_name'];
}

/* ====================================================================== *
 * Category resolution
 * ====================================================================== */

/**
 * Resolve a WooCommerce "Categories" cell into term IDs, creating any missing
 * terms. Supports multiple categories separated by commas and hierarchy with
 * the ">" character, e.g. "Apparel > T-Shirts, Sale".
 *
 * @param string $value Raw categories cell.
 * @return array<int> Term IDs.
 */
function zymarg_os_import_resolve_categories( $value ) {
	$ids   = array();
	$value = trim( (string) $value );
	if ( '' === $value ) {
		return $ids;
	}

	foreach ( explode( ',', $value ) as $group ) {
		$levels = array_map( 'trim', explode( '>', $group ) );
		$parent = 0;

		foreach ( $levels as $name ) {
			if ( '' === $name ) {
				continue;
			}

			$existing = term_exists( $name, 'product_cat', $parent );
			if ( $existing && ! is_wp_error( $existing ) ) {
				$term_id = (int) $existing['term_id'];
			} else {
				$created = wp_insert_term( $name, 'product_cat', array( 'parent' => $parent ) );
				if ( is_wp_error( $created ) ) {
					break;
				}
				$term_id = (int) $created['term_id'];
			}
			$parent = $term_id;
		}

		if ( $parent ) {
			$ids[] = $parent;
		}
	}

	return array_values( array_unique( $ids ) );
}

/* ====================================================================== *
 * Product import
 * ====================================================================== */

/**
 * Create a single product from a normalised CSV row.
 *
 * @param array $row   Row keyed by canonical headers.
 * @param array $stats Stats accumulator (passed by reference).
 * @return void
 */
function zymarg_os_import_create_product( $row, &$stats ) {
	$name = isset( $row['name'] ) ? trim( wp_strip_all_tags( $row['name'] ) ) : '';
	if ( '' === $name ) {
		$stats['skipped']++;
		return;
	}

	$sku = isset( $row['sku'] ) ? trim( $row['sku'] ) : '';
	if ( '' !== $sku && wc_get_product_id_by_sku( $sku ) ) {
		$stats['skipped']++;
		return;
	}

	$product = new WC_Product_Simple();
	$product->set_name( $name );

	if ( '' !== $sku ) {
		$product->set_sku( $sku );
	}

	if ( isset( $row['description'] ) && '' !== trim( $row['description'] ) ) {
		$product->set_description( wp_kses_post( $row['description'] ) );
	}
	if ( isset( $row['short_description'] ) && '' !== trim( $row['short_description'] ) ) {
		$product->set_short_description( wp_kses_post( $row['short_description'] ) );
	}

	// Pricing.
	$regular = isset( $row['regular_price'] ) ? trim( $row['regular_price'] ) : '';
	$sale    = isset( $row['sale_price'] ) ? trim( $row['sale_price'] ) : '';
	if ( '' !== $regular && is_numeric( $regular ) ) {
		$product->set_regular_price( wc_format_decimal( $regular ) );
	}
	if ( '' !== $sale && is_numeric( $sale ) && ( '' === $regular || (float) $sale < (float) $regular ) ) {
		$product->set_sale_price( wc_format_decimal( $sale ) );
	}

	// Stock.
	if ( isset( $row['stock'] ) && is_numeric( trim( $row['stock'] ) ) ) {
		$qty = (int) $row['stock'];
		$product->set_manage_stock( true );
		$product->set_stock_quantity( $qty );
		$product->set_stock_status( $qty > 0 ? 'instock' : 'outofstock' );
	} else {
		$product->set_stock_status( 'instock' );
	}

	// Status.
	$published = isset( $row['published'] ) ? strtolower( trim( $row['published'] ) ) : '1';
	$is_draft  = in_array( $published, array( '0', 'no', 'false', 'draft', 'private', '-1' ), true );
	$product->set_status( $is_draft ? 'draft' : 'publish' );

	// Categories.
	if ( isset( $row['categories'] ) && '' !== trim( $row['categories'] ) ) {
		$cat_ids = zymarg_os_import_resolve_categories( $row['categories'] );
		if ( ! empty( $cat_ids ) ) {
			$product->set_category_ids( $cat_ids );
		}
	}

	$product_id = $product->save();

	if ( ! $product_id ) {
		$stats['errors'][] = sprintf(
			/* translators: %s: product name */
			__( 'Could not create "%s".', 'zymarg-os' ),
			$name
		);
		return;
	}

	// Images (best-effort, after save so we have an ID).
	if ( isset( $row['images'] ) && '' !== trim( $row['images'] ) ) {
		zymarg_os_import_sideload_images( $row['images'], $product );
	}

	$stats['created']++;
}

/**
 * Side-load image URLs onto a product (featured + gallery). Best effort.
 *
 * @param string     $value   Comma-separated image URLs.
 * @param WC_Product $product Product object (already saved).
 * @return void
 */
function zymarg_os_import_sideload_images( $value, $product ) {
	$urls = array_filter( array_map( 'trim', explode( ',', (string) $value ) ) );
	if ( empty( $urls ) ) {
		return;
	}

	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';

	$ids = array();
	foreach ( $urls as $i => $url ) {
		if ( $i >= 6 ) {
			break; // Safety cap.
		}
		if ( ! filter_var( $url, FILTER_VALIDATE_URL ) ) {
			continue;
		}
		$attachment_id = media_sideload_image( $url, $product->get_id(), null, 'id' );
		if ( ! is_wp_error( $attachment_id ) ) {
			$ids[] = (int) $attachment_id;
		}
	}

	if ( empty( $ids ) ) {
		return;
	}

	$product->set_image_id( array_shift( $ids ) );
	if ( ! empty( $ids ) ) {
		$product->set_gallery_image_ids( $ids );
	}
	$product->save();
}

/**
 * Import products from an array of normalised rows.
 *
 * @param array  $rows   Rows.
 * @param string $source Label for the result message ("demo" / "csv" / "snapshot").
 * @return array Result payload.
 */
function zymarg_os_import_products_from_rows( $rows, $source = 'csv' ) {
	$stats = array(
		'type'    => 'products',
		'source'  => $source,
		'created' => 0,
		'skipped' => 0,
		'errors'  => array(),
	);

	if ( ! is_array( $rows ) || empty( $rows ) ) {
		$stats['errors'][] = __( 'No rows were found in the file.', 'zymarg-os' );
		return $stats;
	}

	if ( function_exists( 'wc_set_time_limit' ) ) {
		wc_set_time_limit( 0 );
	}

	foreach ( $rows as $row ) {
		zymarg_os_import_create_product( $row, $stats );
	}

	return $stats;
}

/* ====================================================================== *
 * Category import
 * ====================================================================== */

/**
 * Import product categories from an array of normalised rows.
 *
 * Columns: name (required), slug, parent (name or slug), description.
 *
 * @param array $rows Rows.
 * @return array Result payload.
 */
function zymarg_os_import_categories_from_rows( $rows ) {
	$stats = array(
		'type'    => 'categories',
		'source'  => 'csv',
		'created' => 0,
		'skipped' => 0,
		'errors'  => array(),
	);

	if ( ! is_array( $rows ) || empty( $rows ) ) {
		$stats['errors'][] = __( 'No rows were found in the file.', 'zymarg-os' );
		return $stats;
	}

	foreach ( $rows as $row ) {
		$name = isset( $row['name'] ) ? trim( wp_strip_all_tags( $row['name'] ) ) : '';
		if ( '' === $name ) {
			$stats['skipped']++;
			continue;
		}

		// Resolve parent (by slug then name), creating it if needed.
		$parent_id   = 0;
		$parent_name = isset( $row['parent'] ) ? trim( $row['parent'] ) : '';
		if ( '' !== $parent_name ) {
			$parent_term = get_term_by( 'slug', sanitize_title( $parent_name ), 'product_cat' );
			if ( ! $parent_term ) {
				$parent_term = get_term_by( 'name', $parent_name, 'product_cat' );
			}
			if ( $parent_term ) {
				$parent_id = (int) $parent_term->term_id;
			} else {
				$new_parent = wp_insert_term( $parent_name, 'product_cat' );
				if ( ! is_wp_error( $new_parent ) ) {
					$parent_id = (int) $new_parent['term_id'];
				}
			}
		}

		if ( term_exists( $name, 'product_cat', $parent_id ) ) {
			$stats['skipped']++;
			continue;
		}

		$args = array( 'parent' => $parent_id );
		if ( isset( $row['slug'] ) && '' !== trim( $row['slug'] ) ) {
			$args['slug'] = sanitize_title( $row['slug'] );
		}
		if ( isset( $row['description'] ) && '' !== trim( $row['description'] ) ) {
			$args['description'] = wp_kses_post( $row['description'] );
		}

		$result = wp_insert_term( $name, 'product_cat', $args );
		if ( is_wp_error( $result ) ) {
			$stats['errors'][] = $name . ': ' . $result->get_error_message();
		} else {
			$stats['created']++;
		}
	}

	return $stats;
}

/* ====================================================================== *
 * EXPORT — CSV builders
 * ====================================================================== */

/**
 * Build a CSV string from a header + rows (RFC-4180-ish via fputcsv).
 *
 * @param array $header Header cells.
 * @param array $rows   Array of row arrays.
 * @return string
 */
function zymarg_os_export_build_csv( $header, $rows ) {
	$tmp = fopen( 'php://temp', 'r+' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
	fputcsv( $tmp, $header, ',', '"', '' );
	foreach ( $rows as $row ) {
		fputcsv( $tmp, $row, ',', '"', '' );
	}
	rewind( $tmp );
	$csv = stream_get_contents( $tmp );
	fclose( $tmp ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
	return $csv;
}

/**
 * Stream a CSV download to the browser and exit.
 *
 * @param string $filename Download filename.
 * @param string $csv      CSV body.
 * @return void
 */
function zymarg_os_export_send_csv( $filename, $csv ) {
	nocache_headers();
	header( 'Content-Type: text/csv; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename=' . $filename );
	// UTF-8 BOM so Excel opens accents correctly.
	echo "\xEF\xBB\xBF" . $csv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	exit;
}

/**
 * Build the "A > B" path string for a category term.
 *
 * @param int $term_id Term ID.
 * @return string
 */
function zymarg_os_export_category_path( $term_id ) {
	$names = array();
	foreach ( array_reverse( get_ancestors( $term_id, 'product_cat' ) ) as $aid ) {
		$t = get_term( $aid, 'product_cat' );
		if ( $t && ! is_wp_error( $t ) ) {
			$names[] = $t->name;
		}
	}
	$t = get_term( $term_id, 'product_cat' );
	if ( $t && ! is_wp_error( $t ) ) {
		$names[] = $t->name;
	}
	return implode( ' > ', $names );
}

/**
 * Categories cell for a product ("A > B, C").
 *
 * @param WC_Product $product Product.
 * @return string
 */
function zymarg_os_export_product_categories( $product ) {
	$paths = array();
	foreach ( $product->get_category_ids() as $cid ) {
		$path = zymarg_os_export_category_path( $cid );
		if ( '' !== $path ) {
			$paths[] = $path;
		}
	}
	return implode( ', ', $paths );
}

/**
 * Comma-separated image URLs for a product (featured first, then gallery).
 *
 * @param WC_Product $product Product.
 * @return string
 */
function zymarg_os_export_product_images( $product ) {
	$urls = array();
	$fid  = $product->get_image_id();
	if ( $fid ) {
		$u = wp_get_attachment_url( $fid );
		if ( $u ) {
			$urls[] = $u;
		}
	}
	foreach ( $product->get_gallery_image_ids() as $gid ) {
		$u = wp_get_attachment_url( $gid );
		if ( $u ) {
			$urls[] = $u;
		}
	}
	return implode( ', ', $urls );
}

/**
 * Collect product rows for export.
 *
 * @param int    $category_id Optional category term ID filter.
 * @param string $status      'any' or a specific post status.
 * @return array Header + rows: array( 'header' => [], 'rows' => [] ).
 */
function zymarg_os_export_product_data( $category_id = 0, $status = 'any' ) {
	$header = array( 'name', 'sku', 'regular_price', 'sale_price', 'categories', 'stock', 'short_description', 'description', 'published', 'images' );

	$statuses = ( 'any' === $status ) ? array( 'publish', 'draft', 'pending', 'private' ) : array( $status );
	$args     = array(
		'status'  => $statuses,
		'limit'   => -1,
		'orderby' => 'date',
		'order'   => 'DESC',
		'return'  => 'objects',
	);
	if ( $category_id ) {
		$term = get_term( $category_id, 'product_cat' );
		if ( $term && ! is_wp_error( $term ) ) {
			$args['category'] = array( $term->slug );
		}
	}

	$rows     = array();
	$products = wc_get_products( $args );
	foreach ( $products as $product ) {
		if ( ! $product instanceof WC_Product ) {
			continue;
		}
		$rows[] = array(
			$product->get_name(),
			$product->get_sku(),
			$product->get_regular_price(),
			$product->get_sale_price(),
			zymarg_os_export_product_categories( $product ),
			$product->managing_stock() ? (string) $product->get_stock_quantity() : '',
			wp_strip_all_tags( $product->get_short_description() ),
			wp_strip_all_tags( $product->get_description() ),
			( 'publish' === $product->get_status() ) ? '1' : '0',
			zymarg_os_export_product_images( $product ),
		);
	}

	return array( 'header' => $header, 'rows' => $rows );
}

/**
 * Collect category rows for export.
 *
 * @return array Header + rows.
 */
function zymarg_os_export_category_data() {
	$header = array( 'name', 'slug', 'parent', 'description' );
	$rows   = array();

	$terms = get_terms(
		array(
			'taxonomy'   => 'product_cat',
			'hide_empty' => false,
			'orderby'    => 'parent',
			'order'      => 'ASC',
		)
	);
	if ( is_wp_error( $terms ) ) {
		return array( 'header' => $header, 'rows' => $rows );
	}

	foreach ( $terms as $term ) {
		$parent_slug = '';
		if ( $term->parent ) {
			$pt = get_term( $term->parent, 'product_cat' );
			if ( $pt && ! is_wp_error( $pt ) ) {
				$parent_slug = $pt->slug;
			}
		}
		$rows[] = array( $term->name, $term->slug, $parent_slug, $term->description );
	}

	return array( 'header' => $header, 'rows' => $rows );
}

/* ====================================================================== *
 * Form handlers (admin-post) — IMPORT
 * ====================================================================== */

/**
 * Handle: import bundled demo content.
 *
 * @return void
 */
function zymarg_os_import_handle_demo() {
	if ( ! current_user_can( zymarg_os_import_cap() ) ) {
		wp_die( esc_html__( 'You are not allowed to do this.', 'zymarg-os' ) );
	}
	check_admin_referer( 'zymarg_os_import_demo' );

	if ( ! zymarg_os_import_woo_ready() ) {
		zymarg_os_import_redirect_back( array( 'type' => 'products', 'source' => 'demo', 'created' => 0, 'skipped' => 0, 'errors' => array( __( 'WooCommerce must be active to import products.', 'zymarg-os' ) ) ) );
	}

	$csv  = trailingslashit( ZYMARG_OS_DIR ) . 'inc/import/demo/demo-products.csv';
	$rows = zymarg_os_import_read_csv( $csv );
	if ( is_wp_error( $rows ) ) {
		zymarg_os_import_redirect_back( array( 'type' => 'products', 'source' => 'demo', 'created' => 0, 'skipped' => 0, 'errors' => array( $rows->get_error_message() ) ) );
	}

	$result = zymarg_os_import_products_from_rows( $rows, 'demo' );
	zymarg_os_import_redirect_back( $result );
}
add_action( 'admin_post_zymarg_os_import_demo', 'zymarg_os_import_handle_demo' );

/**
 * Handle: import products from an uploaded CSV.
 *
 * @return void
 */
function zymarg_os_import_handle_products() {
	if ( ! current_user_can( zymarg_os_import_cap() ) ) {
		wp_die( esc_html__( 'You are not allowed to do this.', 'zymarg-os' ) );
	}
	check_admin_referer( 'zymarg_os_import_products' );

	if ( ! zymarg_os_import_woo_ready() ) {
		zymarg_os_import_redirect_back( array( 'type' => 'products', 'source' => 'csv', 'created' => 0, 'skipped' => 0, 'errors' => array( __( 'WooCommerce must be active to import products.', 'zymarg-os' ) ) ) );
	}

	$path = zymarg_os_import_uploaded_file( 'zymarg_csv', 'csv' );
	if ( is_wp_error( $path ) ) {
		zymarg_os_import_redirect_back( array( 'type' => 'products', 'source' => 'csv', 'created' => 0, 'skipped' => 0, 'errors' => array( $path->get_error_message() ) ) );
	}

	// No-JS fallback: run WooCommerce's importer in one pass (correct for
	// variable products + variations + images). The JS flow batches this for
	// progress + no timeouts; this single-pass path is only used without JS.
	$headers = zymarg_os_import_read_headers( $path );
	$mapping = zymarg_os_import_build_wc_mapping( $headers );
	$res     = zymarg_os_import_run_wc( $path, 0, -1, $mapping );

	if ( is_wp_error( $res ) ) {
		zymarg_os_import_redirect_back( array( 'type' => 'products', 'source' => 'csv', 'created' => 0, 'skipped' => 0, 'errors' => array( $res->get_error_message() ) ) );
	}

	zymarg_os_import_redirect_back(
		array(
			'type'    => 'products',
			'source'  => 'csv',
			'created' => (int) $res['imported'] + (int) $res['updated'],
			'skipped' => (int) $res['skipped'],
			'errors'  => $res['failed_messages'],
			'extra'   => array( 'no_image' => count( $res['warnings'] ) ),
		)
	);
}
add_action( 'admin_post_zymarg_os_import_products', 'zymarg_os_import_handle_products' );

/* ====================================================================== *
 * Advanced product import engine (WooCommerce core importer, batched)
 *
 * Drives WooCommerce's own WC_Product_CSV_Importer so variable products,
 * variations, attributes and images are handled correctly. Runs in small
 * AJAX batches with a live progress bar to avoid timeouts, and reports
 * "imported without an image" warnings.
 * ====================================================================== */

/**
 * Load WooCommerce's CSV importer classes (located robustly via glob, so we
 * don't depend on an exact filename across WC versions).
 *
 * @return bool Whether WC_Product_CSV_Importer is available.
 */
function zymarg_os_import_load_wc_importer() {
	if ( class_exists( 'WC_Product_CSV_Importer' ) ) {
		return true;
	}
	if ( ! defined( 'WC_ABSPATH' ) ) {
		return false;
	}
	$dir = WC_ABSPATH . 'includes/import/';
	// Abstract base (filename has varied: abstract-class-* / abstract-wc-*).
	foreach ( (array) glob( $dir . 'abstract-*product-importer.php' ) as $abstract ) {
		include_once $abstract;
	}
	$csv = $dir . 'class-wc-product-csv-importer.php';
	if ( file_exists( $csv ) ) {
		include_once $csv;
	}
	return class_exists( 'WC_Product_CSV_Importer' );
}

/**
 * Read only the header row of a CSV (trimmed, BOM-stripped).
 *
 * @param string $path File path.
 * @return array
 */
function zymarg_os_import_read_headers( $path ) {
	$headers = array();
	if ( ! is_readable( $path ) ) {
		return $headers;
	}
	$fh = fopen( $path, 'r' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
	if ( $fh ) {
		$row = fgetcsv( $fh, 0, ',', '"', '' );
		fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		if ( is_array( $row ) ) {
			if ( isset( $row[0] ) ) {
				$row[0] = preg_replace( '/^\xEF\xBB\xBF/', '', $row[0] );
			}
			$headers = array_map( 'trim', $row );
		}
	}
	return $headers;
}

/**
 * Build a header → WooCommerce-importer-key mapping.
 *
 * Recognises both ZYMARG's simple headers and standard WooCommerce export
 * headers (including "Attribute N name/value(s)/visible/global/default", which
 * is what makes variable products import correctly). Unknown headers are left
 * out (WooCommerce then ignores them).
 *
 * @param array $raw_headers Header cells (trimmed).
 * @return array Map of raw header => importer key.
 */
function zymarg_os_import_build_wc_mapping( $raw_headers ) {
	$lookup = array(
		'id'                    => 'id',
		'type'                  => 'type',
		'sku'                   => 'sku',
		'gtin'                  => 'global_unique_id',
		'name'                  => 'name',
		'title'                 => 'name',
		'product_name'          => 'name',
		'published'             => 'published',
		'status'                => 'published',
		'is_featured'           => 'featured',
		'featured'              => 'featured',
		'visibility_in_catalog' => 'catalog_visibility',
		'catalog_visibility'    => 'catalog_visibility',
		'visibility'            => 'catalog_visibility',
		'short_description'     => 'short_description',
		'description'           => 'description',
		'regular_price'         => 'regular_price',
		'price'                 => 'regular_price',
		'sale_price'            => 'sale_price',
		'date_sale_price_starts'=> 'date_on_sale_from',
		'date_sale_price_ends'  => 'date_on_sale_to',
		'categories'            => 'category_ids',
		'category'              => 'category_ids',
		'tags'                  => 'tag_ids',
		'tag'                   => 'tag_ids',
		'images'                => 'images',
		'image'                 => 'images',
		'stock'                 => 'stock_quantity',
		'stock_quantity'        => 'stock_quantity',
		'quantity'              => 'stock_quantity',
		'in_stock'              => 'stock_status',
		'stock_status'          => 'stock_status',
		'backorders'            => 'backorders',
		'backorders_allowed'    => 'backorders',
		'low_stock_amount'      => 'low_stock_amount',
		'sold_individually'     => 'sold_individually',
		'weight'                => 'weight',
		'weight_kg'             => 'weight',
		'length'                => 'length',
		'length_cm'             => 'length',
		'width'                 => 'width',
		'width_cm'              => 'width',
		'height'                => 'height',
		'height_cm'             => 'height',
		'tax_status'            => 'tax_status',
		'tax_class'             => 'tax_class',
		'shipping_class'        => 'shipping_class_id',
		'parent'                => 'parent_id',
		'parent_sku'            => 'parent_id',
		'grouped_products'      => 'grouped_products',
		'upsells'               => 'upsell_ids',
		'cross_sells'           => 'cross_sell_ids',
		'external_url'          => 'product_url',
		'button_text'           => 'button_text',
		'position'              => 'menu_order',
		'menu_order'            => 'menu_order',
		'purchase_note'         => 'purchase_note',
		'download_limit'        => 'download_limit',
		'download_expiry_days'  => 'download_expiry',
		'allow_customer_reviews'=> 'reviews_allowed',
	);

	$map = array();
	foreach ( (array) $raw_headers as $raw ) {
		$raw  = (string) $raw;
		$norm = strtolower( trim( $raw ) );
		$norm = preg_replace( '/[^a-z0-9]+/', '_', $norm );
		$norm = trim( $norm, '_' );
		if ( '' === $norm ) {
			continue;
		}

		$key = '';
		if ( preg_match( '/^attribute_(\d+)_name$/', $norm, $m ) ) {
			$key = 'attributes:name' . (int) $m[1];
		} elseif ( preg_match( '/^attribute_(\d+)_value/', $norm, $m ) ) {
			$key = 'attributes:value' . (int) $m[1];
		} elseif ( preg_match( '/^attribute_(\d+)_visible$/', $norm, $m ) ) {
			$key = 'attributes:visible' . (int) $m[1];
		} elseif ( preg_match( '/^attribute_(\d+)_global$/', $norm, $m ) ) {
			$key = 'attributes:taxonomy' . (int) $m[1];
		} elseif ( preg_match( '/^attribute_(\d+)_default$/', $norm, $m ) ) {
			$key = 'attributes:default' . (int) $m[1];
		} elseif ( isset( $lookup[ $norm ] ) ) {
			$key = $lookup[ $norm ];
		}

		if ( '' !== $key ) {
			$map[ trim( $raw ) ] = $key;
		}
	}

	return $map;
}

/**
 * Collect "imported but has no image" product names into $warnings.
 *
 * @param array $ids       Imported product IDs.
 * @param array $warnings  Accumulator (by reference).
 * @return void
 */
function zymarg_os_import_collect_image_warnings( $ids, &$warnings ) {
	foreach ( (array) $ids as $id ) {
		if ( is_array( $id ) && isset( $id['id'] ) ) {
			$id = $id['id'];
		}
		$id = (int) $id;
		if ( ! $id ) {
			continue;
		}
		$product = wc_get_product( $id );
		if ( ! $product || 'variation' === $product->get_type() ) {
			continue;
		}
		if ( ! $product->get_image_id() ) {
			$warnings[] = $product->get_name();
		}
	}
}

/**
 * Run one slice of the WooCommerce importer and normalise its result.
 *
 * @param string $file    CSV path.
 * @param int    $start   Byte position to resume from.
 * @param int    $lines   Rows to process this run (-1 = all).
 * @param array  $mapping Header → key map.
 * @return array|WP_Error
 */
function zymarg_os_import_run_wc( $file, $start, $lines, $mapping ) {
	if ( ! zymarg_os_import_load_wc_importer() ) {
		return new WP_Error( 'zymarg_wc', __( 'Could not load the WooCommerce product importer on this site.', 'zymarg-os' ) );
	}
	if ( function_exists( 'wc_set_time_limit' ) ) {
		wc_set_time_limit( 0 );
	}

	$importer = new WC_Product_CSV_Importer(
		$file,
		array(
			'start_pos'        => max( 0, (int) $start ),
			'lines'            => (int) $lines,
			'mapping'          => is_array( $mapping ) ? $mapping : array(),
			'parse'            => true,
			'update_existing'  => false,
			'prevent_timeouts' => true,
			'delimiter'        => ',',
		)
	);

	$results = $importer->import();

	$imported = isset( $results['imported'] ) ? (array) $results['imported'] : array();
	$updated  = isset( $results['updated'] ) ? (array) $results['updated'] : array();
	$skipped  = isset( $results['skipped'] ) ? (array) $results['skipped'] : array();
	$failed   = isset( $results['failed'] ) ? (array) $results['failed'] : array();

	$failed_messages = array();
	foreach ( $failed as $err ) {
		if ( is_wp_error( $err ) ) {
			$failed_messages[] = $err->get_error_message();
		}
	}

	$warnings = array();
	zymarg_os_import_collect_image_warnings( $imported, $warnings );

	return array(
		'position'        => (int) $importer->get_file_position(),
		'percent'         => (int) $importer->get_percent_complete(),
		'imported'        => count( $imported ),
		'updated'         => count( $updated ),
		'skipped'         => count( $skipped ),
		'failed'          => count( $failed ),
		'failed_messages' => array_slice( $failed_messages, 0, 10 ),
		'warnings'        => $warnings,
	);
}

/**
 * AJAX: receive the uploaded products CSV, stash it, build the mapping.
 *
 * @return void
 */
function zymarg_os_import_ajax_upload() {
	if ( ! current_user_can( zymarg_os_import_cap() ) ) {
		wp_send_json_error( array( 'message' => __( 'You are not allowed to do this.', 'zymarg-os' ) ) );
	}
	check_ajax_referer( 'zymarg_import_upload', 'nonce' );

	if ( ! zymarg_os_import_woo_ready() ) {
		wp_send_json_error( array( 'message' => __( 'WooCommerce must be active to import products.', 'zymarg-os' ) ) );
	}

	$tmp = zymarg_os_import_uploaded_file( 'file', 'csv' );
	if ( is_wp_error( $tmp ) ) {
		wp_send_json_error( array( 'message' => $tmp->get_error_message() ) );
	}

	$updir = wp_upload_dir();
	$dir   = trailingslashit( $updir['basedir'] ) . 'zymarg-import';
	if ( ! file_exists( $dir ) ) {
		wp_mkdir_p( $dir );
	}
	// Keep the directory non-browsable.
	if ( ! file_exists( $dir . '/index.html' ) ) {
		@file_put_contents( $dir . '/index.html', '' ); // phpcs:ignore
	}

	$token = wp_generate_password( 20, false, false );
	$dest  = $dir . '/' . $token . '.csv';

	if ( ! @move_uploaded_file( $tmp, $dest ) && ! @copy( $tmp, $dest ) ) { // phpcs:ignore
		wp_send_json_error( array( 'message' => __( 'Could not store the uploaded file. Check folder permissions.', 'zymarg-os' ) ) );
	}

	$headers = zymarg_os_import_read_headers( $dest );
	if ( empty( $headers ) ) {
		@unlink( $dest ); // phpcs:ignore
		wp_send_json_error( array( 'message' => __( 'The CSV appears to be empty.', 'zymarg-os' ) ) );
	}

	$mapping = zymarg_os_import_build_wc_mapping( $headers );

	set_transient(
		'zymarg_import_job_' . $token,
		array(
			'file'    => $dest,
			'user'    => get_current_user_id(),
			'mapping' => $mapping,
		),
		2 * HOUR_IN_SECONDS
	);

	wp_send_json_success(
		array(
			'token'   => $token,
			'columns' => array_values( array_filter( array_map( 'strval', $headers ) ) ),
		)
	);
}
add_action( 'wp_ajax_zymarg_import_upload', 'zymarg_os_import_ajax_upload' );

/**
 * AJAX: process one batch of the stashed CSV and return progress.
 *
 * @return void
 */
function zymarg_os_import_ajax_batch() {
	if ( ! current_user_can( zymarg_os_import_cap() ) ) {
		wp_send_json_error( array( 'message' => __( 'You are not allowed to do this.', 'zymarg-os' ) ) );
	}
	check_ajax_referer( 'zymarg_import_batch', 'nonce' );

	$token    = isset( $_POST['token'] ) ? sanitize_text_field( wp_unslash( $_POST['token'] ) ) : '';
	$position = isset( $_POST['position'] ) ? max( 0, (int) $_POST['position'] ) : 0;

	$job = $token ? get_transient( 'zymarg_import_job_' . $token ) : false;
	if ( ! $job || ! is_array( $job ) || (int) $job['user'] !== get_current_user_id() || empty( $job['file'] ) || ! file_exists( $job['file'] ) ) {
		wp_send_json_error( array( 'message' => __( 'Your import session expired. Please choose the file again.', 'zymarg-os' ) ) );
	}

	$batch = (int) apply_filters( 'zymarg_os_import_batch_size', 6 );
	$batch = max( 1, min( 50, $batch ) );

	$res = zymarg_os_import_run_wc( $job['file'], $position, $batch, $job['mapping'] );
	if ( is_wp_error( $res ) ) {
		wp_send_json_error( array( 'message' => $res->get_error_message() ) );
	}

	$done = ( $res['percent'] >= 100 ) || ( $res['position'] <= $position );
	if ( $done ) {
		@unlink( $job['file'] ); // phpcs:ignore
		delete_transient( 'zymarg_import_job_' . $token );
		$res['percent'] = 100;
	}
	$res['done'] = $done;

	wp_send_json_success( $res );
}
add_action( 'wp_ajax_zymarg_import_batch', 'zymarg_os_import_ajax_batch' );

/**
 * Handle: import categories from an uploaded CSV.
 *
 * @return void
 */
function zymarg_os_import_handle_categories() {
	if ( ! current_user_can( zymarg_os_import_cap() ) ) {
		wp_die( esc_html__( 'You are not allowed to do this.', 'zymarg-os' ) );
	}
	check_admin_referer( 'zymarg_os_import_categories' );

	if ( ! zymarg_os_import_woo_ready() ) {
		zymarg_os_import_redirect_back( array( 'type' => 'categories', 'source' => 'csv', 'created' => 0, 'skipped' => 0, 'errors' => array( __( 'WooCommerce must be active to import product categories.', 'zymarg-os' ) ) ) );
	}

	$path = zymarg_os_import_uploaded_file( 'zymarg_csv', 'csv' );
	if ( is_wp_error( $path ) ) {
		zymarg_os_import_redirect_back( array( 'type' => 'categories', 'source' => 'csv', 'created' => 0, 'skipped' => 0, 'errors' => array( $path->get_error_message() ) ) );
	}

	$rows = zymarg_os_import_read_csv( $path );
	if ( is_wp_error( $rows ) ) {
		zymarg_os_import_redirect_back( array( 'type' => 'categories', 'source' => 'csv', 'created' => 0, 'skipped' => 0, 'errors' => array( $rows->get_error_message() ) ) );
	}

	$result = zymarg_os_import_categories_from_rows( $rows );
	zymarg_os_import_redirect_back( $result );
}
add_action( 'admin_post_zymarg_os_import_categories', 'zymarg_os_import_handle_categories' );

/**
 * Handle: download a sample CSV template (products or categories).
 *
 * @return void
 */
function zymarg_os_import_handle_sample() {
	if ( ! current_user_can( zymarg_os_import_cap() ) ) {
		wp_die( esc_html__( 'You are not allowed to do this.', 'zymarg-os' ) );
	}
	check_admin_referer( 'zymarg_os_import_sample' );

	$which = isset( $_GET['which'] ) ? sanitize_key( wp_unslash( $_GET['which'] ) ) : 'products';

	if ( 'categories' === $which ) {
		$filename = 'zymarg-sample-categories.csv';
		$body     = "name,slug,parent,description\n"
			. "Apparel,apparel,,\"Clothing and wearables\"\n"
			. "T-Shirts,t-shirts,Apparel,\"Short-sleeve tees\"\n"
			. "Accessories,accessories,,\"Bags, caps and extras\"\n";
	} else {
		$filename = 'zymarg-sample-products.csv';
		$body     = "name,sku,regular_price,sale_price,categories,stock,short_description,description,published\n"
			. "Sample Tee,SAMPLE-01,19.99,14.99,Apparel > T-Shirts,100,\"A short summary.\",\"A longer product description.\",1\n"
			. "Sample Cap,SAMPLE-02,22.00,,Accessories,50,\"A short summary.\",\"A longer product description.\",1\n";
	}

	zymarg_os_export_send_csv( $filename, $body );
}
add_action( 'admin_post_zymarg_os_import_sample', 'zymarg_os_import_handle_sample' );

/* ====================================================================== *
 * Form handlers (admin-post) — EXPORT
 * ====================================================================== */

/**
 * Handle: export products to CSV (with optional category + status filter).
 *
 * @return void
 */
/**
 * Load WooCommerce's product CSV exporter (so variations export correctly).
 *
 * @return bool
 */
function zymarg_os_export_load_wc_exporter() {
	if ( class_exists( 'WC_Product_CSV_Exporter' ) ) {
		return true;
	}
	if ( ! defined( 'WC_ABSPATH' ) ) {
		return false;
	}
	// The exporter constructor references WC_Admin_Exporters::get_product_types().
	if ( ! class_exists( 'WC_Admin_Exporters' ) && file_exists( WC_ABSPATH . 'includes/admin/class-wc-admin-exporters.php' ) ) {
		include_once WC_ABSPATH . 'includes/admin/class-wc-admin-exporters.php';
	}
	$file = WC_ABSPATH . 'includes/export/class-wc-product-csv-exporter.php';
	if ( file_exists( $file ) ) {
		include_once $file;
	}
	return class_exists( 'WC_Product_CSV_Exporter' );
}

/**
 * Resolve a category term ID to its slug (the exporter filters by slug).
 *
 * @param int $category_id Term ID.
 * @return string
 */
function zymarg_os_export_category_slug( $category_id ) {
	$category_id = (int) $category_id;
	if ( ! $category_id ) {
		return '';
	}
	$term = get_term( $category_id, 'product_cat' );
	return ( $term && ! is_wp_error( $term ) ) ? $term->slug : '';
}

/**
 * Generate one page of the WooCommerce product export to a file on disk.
 *
 * @param string $filename Stable export filename (reused across pages).
 * @param string $cat_slug Category slug filter ('' = all).
 * @param string $status   'any' | 'publish' | 'draft'.
 * @param int    $page     Page number (1-based).
 * @param int    $limit    Rows per page.
 * @return WC_Product_CSV_Exporter
 */
function zymarg_os_export_generate_page( $filename, $cat_slug, $status, $page, $limit ) {
	$exporter = new WC_Product_CSV_Exporter();
	$exporter->set_filename( $filename );
	$exporter->set_limit( max( 1, (int) $limit ) );
	if ( '' !== $cat_slug ) {
		$exporter->set_product_category_to_export( array( $cat_slug ) );
	}
	$exporter->set_page( max( 1, (int) $page ) );

	$cb = null;
	if ( in_array( $status, array( 'publish', 'draft' ), true ) ) {
		$cb = function ( $args ) use ( $status ) {
			$args['status'] = array( $status );
			return $args;
		};
		add_filter( 'woocommerce_product_export_product_query_args', $cb );
	}

	$exporter->generate_file();

	if ( $cb ) {
		remove_filter( 'woocommerce_product_export_product_query_args', $cb );
	}

	return $exporter;
}

/**
 * Build a WooCommerce CSV download URL for an already-generated export file.
 * Reuses WooCommerce's own (admin_init) handler, which streams then deletes.
 *
 * @param string $filename Export filename.
 * @return string
 */
function zymarg_os_export_wc_download_url( $filename ) {
	return add_query_arg(
		array(
			'action'   => 'download_product_csv',
			'nonce'    => wp_create_nonce( 'product-csv' ),
			'filename' => rawurlencode( $filename ),
		),
		admin_url()
	);
}

/**
 * Handle: export products to CSV (no-JS fallback). Loops all pages with the
 * WooCommerce exporter, then hands off to its download handler. The JS flow
 * batches this for a progress bar instead.
 *
 * @return void
 */
function zymarg_os_export_handle_products() {
	if ( ! current_user_can( zymarg_os_import_cap() ) ) {
		wp_die( esc_html__( 'You are not allowed to do this.', 'zymarg-os' ) );
	}
	check_admin_referer( 'zymarg_os_export_products' );

	if ( ! zymarg_os_import_woo_ready() || ! zymarg_os_export_load_wc_exporter() ) {
		zymarg_os_import_redirect_back( array( 'type' => 'export', 'source' => 'export', 'created' => 0, 'skipped' => 0, 'errors' => array( __( 'WooCommerce must be active to export products.', 'zymarg-os' ) ) ) );
	}

	$cat_slug = zymarg_os_export_category_slug( isset( $_POST['category'] ) ? absint( $_POST['category'] ) : 0 );
	$status   = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : 'any';
	$limit    = (int) apply_filters( 'zymarg_os_export_batch_limit', 40 );
	$filename = 'zymarg-products-' . gmdate( 'Ymd-His' ) . '-' . wp_generate_password( 6, false, false ) . '.csv';

	if ( function_exists( 'wc_set_time_limit' ) ) {
		wc_set_time_limit( 0 );
	}

	$page  = 1;
	$guard = 0;
	do {
		$exporter = zymarg_os_export_generate_page( $filename, $cat_slug, $status, $page, $limit );
		$percent  = $exporter->get_percent_complete();
		$page++;
		$guard++;
	} while ( $percent < 100 && $guard < 100000 );

	wp_safe_redirect( zymarg_os_export_wc_download_url( $exporter->get_filename() ) );
	exit;
}
add_action( 'admin_post_zymarg_os_export_products', 'zymarg_os_export_handle_products' );

/**
 * Handle: export product categories to CSV.
 *
 * @return void
 */
function zymarg_os_export_handle_categories() {
	if ( ! current_user_can( zymarg_os_import_cap() ) ) {
		wp_die( esc_html__( 'You are not allowed to do this.', 'zymarg-os' ) );
	}
	check_admin_referer( 'zymarg_os_export_categories' );

	if ( ! zymarg_os_import_woo_ready() ) {
		zymarg_os_import_redirect_back( array( 'type' => 'export', 'source' => 'export', 'created' => 0, 'skipped' => 0, 'errors' => array( __( 'WooCommerce must be active to export categories.', 'zymarg-os' ) ) ) );
	}

	$data = zymarg_os_export_category_data();
	$csv  = zymarg_os_export_build_csv( $data['header'], $data['rows'] );
	zymarg_os_export_send_csv( 'zymarg-categories-' . gmdate( 'Ymd-Hi' ) . '.csv', $csv );
}
add_action( 'admin_post_zymarg_os_export_categories', 'zymarg_os_export_handle_categories' );

/**
 * Handle: export a full Store Snapshot ZIP (products + categories + manifest).
 *
 * @return void
 */
/**
 * Build a Store Snapshot ZIP from an already-generated products export file.
 *
 * @param string $products_filename Export filename (already on disk).
 * @return string|WP_Error Path to the ZIP.
 */
function zymarg_os_export_build_snapshot( $products_filename ) {
	if ( ! class_exists( 'ZipArchive' ) ) {
		return new WP_Error( 'zymarg_zip', __( 'The PHP “ZipArchive” extension is not available on this server.', 'zymarg-os' ) );
	}
	if ( ! zymarg_os_export_load_wc_exporter() ) {
		return new WP_Error( 'zymarg_zip', __( 'Could not load the WooCommerce exporter.', 'zymarg-os' ) );
	}

	// Read the generated products CSV (BOM + headers + rows) via the exporter.
	$exporter     = new WC_Product_CSV_Exporter();
	$exporter->set_filename( $products_filename );
	$products_csv = $exporter->get_headers_row_file() . $exporter->get_file();

	$base = trailingslashit( wp_upload_dir()['basedir'] );
	// Clean up the raw WC export files now that we have the contents.
	@unlink( $base . $exporter->get_filename() ); // phpcs:ignore
	@unlink( $base . $exporter->get_filename() . '.headers' ); // phpcs:ignore

	$cats   = zymarg_os_export_category_data();
	$catcsv = zymarg_os_export_build_csv( $cats['header'], $cats['rows'] );

	$manifest = array(
		'generator'     => 'ZYMARG OS',
		'theme_version' => defined( 'ZYMARG_OS_VERSION' ) ? ZYMARG_OS_VERSION : '',
		'site_name'     => get_bloginfo( 'name' ),
		'site_url'      => home_url( '/' ),
		'created_gmt'   => gmdate( 'c' ),
		'counts'        => array(
			'product_rows' => max( 0, substr_count( $products_csv, "\n" ) - 1 ),
			'categories'   => count( $cats['rows'] ),
		),
	);

	$dir = $base . 'zymarg-import';
	if ( ! file_exists( $dir ) ) {
		wp_mkdir_p( $dir );
	}
	if ( ! file_exists( $dir . '/index.html' ) ) {
		@file_put_contents( $dir . '/index.html', '' ); // phpcs:ignore
	}
	$zip_path = $dir . '/zymarg-store-snapshot-' . gmdate( 'Ymd-Hi' ) . '-' . wp_generate_password( 6, false, false ) . '.zip';

	$zip = new ZipArchive();
	if ( true !== $zip->open( $zip_path, ZipArchive::CREATE | ZipArchive::OVERWRITE ) ) {
		return new WP_Error( 'zymarg_zip', __( 'Could not create the snapshot archive.', 'zymarg-os' ) );
	}
	$zip->addFromString( 'products.csv', $products_csv );
	$zip->addFromString( 'categories.csv', "\xEF\xBB\xBF" . $catcsv );
	$zip->addFromString( 'manifest.json', wp_json_encode( $manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) );
	$zip->close();

	return $zip_path;
}

/**
 * Stream a snapshot ZIP to the browser, then delete it.
 *
 * @param string $zip_path Path.
 * @return void
 */
function zymarg_os_export_stream_snapshot( $zip_path ) {
	if ( ! $zip_path || ! file_exists( $zip_path ) ) {
		wp_die( esc_html__( 'Snapshot file not found.', 'zymarg-os' ) );
	}
	nocache_headers();
	header( 'Content-Type: application/zip' );
	header( 'Content-Disposition: attachment; filename=' . basename( $zip_path ) );
	header( 'Content-Length: ' . filesize( $zip_path ) );
	readfile( $zip_path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile
	@unlink( $zip_path ); // phpcs:ignore
	exit;
}

/**
 * Register a one-time snapshot download token and return its URL.
 *
 * @param string $zip_path Path to the ZIP.
 * @return string
 */
function zymarg_os_export_snapshot_download_url( $zip_path ) {
	$token = wp_generate_password( 20, false, false );
	set_transient(
		'zymarg_export_dl_' . $token,
		array( 'file' => $zip_path, 'user' => get_current_user_id() ),
		HOUR_IN_SECONDS
	);
	return wp_nonce_url(
		admin_url( 'admin-post.php?action=zymarg_os_export_snapshot_dl&token=' . $token ),
		'zymarg_export_dl_' . $token
	);
}

/**
 * Download handler for a batched snapshot (token-based, one-time).
 *
 * @return void
 */
function zymarg_os_export_handle_snapshot_dl() {
	if ( ! current_user_can( zymarg_os_import_cap() ) ) {
		wp_die( esc_html__( 'You are not allowed to do this.', 'zymarg-os' ) );
	}
	$token = isset( $_GET['token'] ) ? preg_replace( '/[^A-Za-z0-9]/', '', wp_unslash( $_GET['token'] ) ) : '';
	check_admin_referer( 'zymarg_export_dl_' . $token );

	$job = $token ? get_transient( 'zymarg_export_dl_' . $token ) : false;
	if ( ! $job || ! is_array( $job ) || (int) $job['user'] !== get_current_user_id() || empty( $job['file'] ) || ! file_exists( $job['file'] ) ) {
		wp_die( esc_html__( 'This download link has expired.', 'zymarg-os' ) );
	}
	delete_transient( 'zymarg_export_dl_' . $token );
	zymarg_os_export_stream_snapshot( $job['file'] );
}
add_action( 'admin_post_zymarg_os_export_snapshot_dl', 'zymarg_os_export_handle_snapshot_dl' );

/**
 * Handle: export Store Snapshot (no-JS fallback). Loops all pages, builds the
 * ZIP, then streams it.
 *
 * @return void
 */
function zymarg_os_export_handle_snapshot() {
	if ( ! current_user_can( zymarg_os_import_cap() ) ) {
		wp_die( esc_html__( 'You are not allowed to do this.', 'zymarg-os' ) );
	}
	check_admin_referer( 'zymarg_os_export_snapshot' );

	if ( ! zymarg_os_import_woo_ready() || ! zymarg_os_export_load_wc_exporter() ) {
		zymarg_os_import_redirect_back( array( 'type' => 'export', 'source' => 'export', 'created' => 0, 'skipped' => 0, 'errors' => array( __( 'WooCommerce must be active to build a snapshot.', 'zymarg-os' ) ) ) );
	}
	if ( ! class_exists( 'ZipArchive' ) ) {
		zymarg_os_import_redirect_back( array( 'type' => 'export', 'source' => 'export', 'created' => 0, 'skipped' => 0, 'errors' => array( __( 'The PHP “ZipArchive” extension is not available on this server, so snapshots cannot be built. You can still export the CSV files individually.', 'zymarg-os' ) ) ) );
	}

	if ( function_exists( 'wc_set_time_limit' ) ) {
		wc_set_time_limit( 0 );
	}

	$limit    = (int) apply_filters( 'zymarg_os_export_batch_limit', 40 );
	$filename = 'zymarg-snap-' . gmdate( 'Ymd-His' ) . '-' . wp_generate_password( 6, false, false ) . '.csv';

	$page  = 1;
	$guard = 0;
	do {
		$exporter = zymarg_os_export_generate_page( $filename, '', 'any', $page, $limit );
		$percent  = $exporter->get_percent_complete();
		$page++;
		$guard++;
	} while ( $percent < 100 && $guard < 100000 );

	$zip = zymarg_os_export_build_snapshot( $exporter->get_filename() );
	if ( is_wp_error( $zip ) ) {
		zymarg_os_import_redirect_back( array( 'type' => 'export', 'source' => 'export', 'created' => 0, 'skipped' => 0, 'errors' => array( $zip->get_error_message() ) ) );
	}

	zymarg_os_export_stream_snapshot( $zip );
}
add_action( 'admin_post_zymarg_os_export_snapshot', 'zymarg_os_export_handle_snapshot' );

/**
 * AJAX: batched export (products CSV or full snapshot) with progress.
 *
 * @return void
 */
function zymarg_os_export_ajax_batch() {
	if ( ! current_user_can( zymarg_os_import_cap() ) ) {
		wp_send_json_error( array( 'message' => __( 'You are not allowed to do this.', 'zymarg-os' ) ) );
	}
	check_ajax_referer( 'zymarg_export', 'nonce' );

	if ( ! zymarg_os_import_woo_ready() || ! zymarg_os_export_load_wc_exporter() ) {
		wp_send_json_error( array( 'message' => __( 'WooCommerce must be active to export.', 'zymarg-os' ) ) );
	}

	$mode  = isset( $_POST['mode'] ) ? sanitize_key( wp_unslash( $_POST['mode'] ) ) : 'products';
	$step  = isset( $_POST['step'] ) ? max( 1, (int) $_POST['step'] ) : 1;
	$token = isset( $_POST['token'] ) ? preg_replace( '/[^A-Za-z0-9]/', '', wp_unslash( $_POST['token'] ) ) : '';
	if ( '' === $token ) {
		$token = wp_generate_password( 12, false, false );
	}
	$cat_slug = zymarg_os_export_category_slug( isset( $_POST['category'] ) ? absint( $_POST['category'] ) : 0 );
	$status   = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : 'any';

	if ( 'snapshot' === $mode && ! class_exists( 'ZipArchive' ) ) {
		wp_send_json_error( array( 'message' => __( 'Snapshots need the PHP “ZipArchive” extension, which is not enabled here.', 'zymarg-os' ) ) );
	}

	if ( function_exists( 'wc_set_time_limit' ) ) {
		wc_set_time_limit( 0 );
	}

	$prefix   = ( 'snapshot' === $mode ) ? 'zymarg-snap-' : 'zymarg-products-';
	$filename = $prefix . $token . '.csv';
	$limit    = (int) apply_filters( 'zymarg_os_export_batch_limit', 40 );

	$exporter = zymarg_os_export_generate_page(
		$filename,
		( 'snapshot' === $mode ) ? '' : $cat_slug,
		( 'snapshot' === $mode ) ? 'any' : $status,
		$step,
		$limit
	);
	$percent  = (int) $exporter->get_percent_complete();
	$exported = (int) $exporter->get_total_exported();

	if ( $percent >= 100 ) {
		if ( 'snapshot' === $mode ) {
			$zip = zymarg_os_export_build_snapshot( $exporter->get_filename() );
			if ( is_wp_error( $zip ) ) {
				wp_send_json_error( array( 'message' => $zip->get_error_message() ) );
			}
			$url = zymarg_os_export_snapshot_download_url( $zip );
		} else {
			$url = zymarg_os_export_wc_download_url( $exporter->get_filename() );
		}
		wp_send_json_success( array( 'done' => true, 'percent' => 100, 'exported' => $exported, 'url' => $url ) );
	}

	wp_send_json_success( array( 'done' => false, 'percent' => $percent, 'exported' => $exported, 'step' => $step + 1, 'token' => $token ) );
}
add_action( 'wp_ajax_zymarg_export_batch', 'zymarg_os_export_ajax_batch' );

/**
 * Handle: restore a Store Snapshot ZIP (categories first, then products).
 *
 * @return void
 */
function zymarg_os_import_handle_snapshot() {
	if ( ! current_user_can( zymarg_os_import_cap() ) ) {
		wp_die( esc_html__( 'You are not allowed to do this.', 'zymarg-os' ) );
	}
	check_admin_referer( 'zymarg_os_import_snapshot' );

	if ( ! zymarg_os_import_woo_ready() ) {
		zymarg_os_import_redirect_back( array( 'type' => 'snapshot', 'source' => 'snapshot', 'created' => 0, 'skipped' => 0, 'errors' => array( __( 'WooCommerce must be active to restore a snapshot.', 'zymarg-os' ) ) ) );
	}

	$zip_path = zymarg_os_import_uploaded_file( 'zymarg_zip', 'zip' );
	if ( is_wp_error( $zip_path ) ) {
		zymarg_os_import_redirect_back( array( 'type' => 'snapshot', 'source' => 'snapshot', 'created' => 0, 'skipped' => 0, 'errors' => array( $zip_path->get_error_message() ) ) );
	}

	require_once ABSPATH . 'wp-admin/includes/file.php';
	WP_Filesystem();

	$dest = trailingslashit( get_temp_dir() ) . 'zymarg-snap-' . wp_generate_password( 10, false, false );
	$unz  = unzip_file( $zip_path, $dest );
	if ( is_wp_error( $unz ) ) {
		zymarg_os_import_redirect_back( array( 'type' => 'snapshot', 'source' => 'snapshot', 'created' => 0, 'skipped' => 0, 'errors' => array( __( 'Could not open the snapshot ZIP. Make sure it is a ZYMARG store snapshot.', 'zymarg-os' ) ) ) );
	}

	$cat_res  = array( 'created' => 0, 'skipped' => 0, 'errors' => array() );
	$prod_res = array( 'created' => 0, 'skipped' => 0, 'errors' => array() );

	// Categories first so product → category links resolve.
	if ( file_exists( $dest . '/categories.csv' ) ) {
		$rows = zymarg_os_import_read_csv( $dest . '/categories.csv' );
		if ( ! is_wp_error( $rows ) ) {
			$cat_res = zymarg_os_import_categories_from_rows( $rows );
		}
	}
	if ( file_exists( $dest . '/products.csv' ) ) {
		$rows = zymarg_os_import_read_csv( $dest . '/products.csv' );
		if ( ! is_wp_error( $rows ) ) {
			$prod_res = zymarg_os_import_products_from_rows( $rows, 'snapshot' );
		}
	}

	// Clean up the extracted temp directory.
	global $wp_filesystem;
	if ( $wp_filesystem && is_dir( $dest ) ) {
		$wp_filesystem->delete( $dest, true );
	}

	$result = array(
		'type'    => 'snapshot',
		'source'  => 'snapshot',
		'created' => (int) $prod_res['created'],
		'skipped' => (int) $prod_res['skipped'],
		'errors'  => array_merge( $cat_res['errors'], $prod_res['errors'] ),
		'extra'   => array(
			'categories_created' => (int) $cat_res['created'],
			'categories_skipped' => (int) $cat_res['skipped'],
		),
	);
	zymarg_os_import_redirect_back( $result );
}
add_action( 'admin_post_zymarg_os_import_snapshot', 'zymarg_os_import_handle_snapshot' );

/* ====================================================================== *
 * Store stats
 * ====================================================================== */

/**
 * Gather lightweight store stats for the header strip.
 *
 * @return array<int,array{label:string,value:string,icon:string}>
 */
function zymarg_os_import_stats() {
	if ( ! zymarg_os_import_woo_ready() ) {
		return array();
	}

	$counts    = wp_count_posts( 'product' );
	$published = isset( $counts->publish ) ? (int) $counts->publish : 0;
	$drafts    = isset( $counts->draft ) ? (int) $counts->draft : 0;

	$cat_total = wp_count_terms(
		array(
			'taxonomy'   => 'product_cat',
			'hide_empty' => false,
		)
	);
	$cat_total = is_wp_error( $cat_total ) ? 0 : (int) $cat_total;

	$on_sale = function_exists( 'wc_get_product_ids_on_sale' ) ? count( wc_get_product_ids_on_sale() ) : 0;

	return array(
		array( 'label' => __( 'Published products', 'zymarg-os' ), 'value' => number_format_i18n( $published ), 'icon' => 'cube' ),
		array( 'label' => __( 'Drafts', 'zymarg-os' ), 'value' => number_format_i18n( $drafts ), 'icon' => 'pencil' ),
		array( 'label' => __( 'Categories', 'zymarg-os' ), 'value' => number_format_i18n( $cat_total ), 'icon' => 'tags' ),
		array( 'label' => __( 'On sale', 'zymarg-os' ), 'value' => number_format_i18n( $on_sale ), 'icon' => 'sale' ),
	);
}

/* ====================================================================== *
 * Inline SVG icons for the cards / stats
 * ====================================================================== */

/**
 * Return an inline SVG icon.
 *
 * @param string $name Icon name.
 * @return string SVG markup (pre-sanitised).
 */
function zymarg_os_import_icon( $name ) {
	$icons = array(
		'gift'        => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 7h-2.18c.11-.31.18-.65.18-1a3 3 0 0 0-5.5-1.65L12 5l-.5-.65A3 3 0 0 0 6 6c0 .35.07.69.18 1H4a2 2 0 0 0-2 2v2h20V9a2 2 0 0 0-2-2zm-6.5-2a1 1 0 1 1 0 2H13l.5-1.35zM9 4a1 1 0 0 1 1 1l.5 1H9a1 1 0 0 1 0-2zM3 13v7a2 2 0 0 0 2 2h6v-9zm10 9h6a2 2 0 0 0 2-2v-7h-8z"/></svg>',
		'spreadsheet' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zm0 2 4 4h-4zM7 12h4v2H7zm0 4h4v2H7zm6 0h4v2h-4zm0-4h4v2h-4z"/></svg>',
		'tags'        => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12.4 2H6a2 2 0 0 0-2 2v6.4a2 2 0 0 0 .6 1.4l8 8a2 2 0 0 0 2.8 0l5.6-5.6a2 2 0 0 0 0-2.8l-8-8A2 2 0 0 0 12.4 2zM7.5 8A1.5 1.5 0 1 1 9 6.5 1.5 1.5 0 0 1 7.5 8z"/></svg>',
		'info'        => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm1 15h-2v-6h2zm0-8h-2V7h2z"/></svg>',
		'export'      => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3a1 1 0 0 1 1 1v8.59l2.3-2.3a1 1 0 0 1 1.4 1.42l-4 4a1 1 0 0 1-1.4 0l-4-4a1 1 0 1 1 1.4-1.42l2.3 2.3V4a1 1 0 0 1 1-1zM5 19h14a1 1 0 0 1 0 2H5a1 1 0 0 1 0-2z"/></svg>',
		'snapshot'    => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 6.5 4.2 4h15.6L21 6.5V8H3zM4 9h16v9a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2zm5 3v2h6v-2z"/></svg>',
		'restore'     => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21a1 1 0 0 1-1-1v-8.59l-2.3 2.3a1 1 0 1 1-1.4-1.42l4-4a1 1 0 0 1 1.4 0l4 4a1 1 0 0 1-1.4 1.42L13 11.41V20a1 1 0 0 1-1 1zM5 5h14a1 1 0 0 1 0-2H5a1 1 0 0 0 0 2z" transform="translate(0 0)"/><path d="M5 3h14a1 1 0 0 1 0 2H5a1 1 0 0 1 0-2z"/></svg>',
		'cube'        => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2 3 7v10l9 5 9-5V7zm0 2.3 6.5 3.6L12 11.5 5.5 7.9zM5 9.7l6 3.3v6.6l-6-3.3zm14 0v6.6l-6 3.3V13z"/></svg>',
		'pencil'      => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75zM20.71 7.04a1 1 0 0 0 0-1.41l-2.34-2.34a1 1 0 0 0-1.41 0l-1.83 1.83 3.75 3.75z"/></svg>',
		'sale'        => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12.4 2H6a2 2 0 0 0-2 2v6.4a2 2 0 0 0 .6 1.4l8 8a2 2 0 0 0 2.8 0l5.6-5.6a2 2 0 0 0 0-2.8l-8-8A2 2 0 0 0 12.4 2zM7.5 8A1.5 1.5 0 1 1 9 6.5 1.5 1.5 0 0 1 7.5 8z"/></svg>',
	);
	return isset( $icons[ $name ] ) ? $icons[ $name ] : '';
}

/* ====================================================================== *
 * Page render
 * ====================================================================== */

/**
 * Output a progress panel (used by the batched import/export JS).
 *
 * @return void
 */
function zymarg_os_import_progress_panel() {
	?>
	<div class="zymarg-import-progress" data-import-progress hidden>
		<div class="zymarg-import-progress__track"><span class="zymarg-import-progress__fill" style="width:0%"></span></div>
		<div class="zymarg-import-progress__row">
			<span class="zymarg-import-progress__status"></span>
			<span class="zymarg-import-progress__pct">0%</span>
		</div>
		<div class="zymarg-import-progress__counts" data-progress-counts hidden></div>
		<div class="zymarg-import-progress__note" data-progress-note hidden></div>
		<div class="zymarg-import-progress__actions" data-progress-actions hidden></div>
	</div>
	<?php
}

/**
 * Render the result banner from the stored transient (if any).
 *
 * @return void
 */
function zymarg_os_import_render_result() {
	$result = zymarg_os_import_take_result();
	if ( empty( $result ) || ! is_array( $result ) ) {
		return;
	}

	$created = (int) ( $result['created'] ?? 0 );
	$skipped = (int) ( $result['skipped'] ?? 0 );
	$errors  = isset( $result['errors'] ) && is_array( $result['errors'] ) ? $result['errors'] : array();
	$extra   = isset( $result['extra'] ) && is_array( $result['extra'] ) ? $result['extra'] : array();
	$type    = $result['type'] ?? '';
	$source  = $result['source'] ?? '';
	$is_err  = ( 0 === $created && empty( $extra ) && ! empty( $errors ) );

	if ( 'snapshot' === $type ) {
		$heading = __( 'Snapshot restored.', 'zymarg-os' );
	} elseif ( 'export' === $type ) {
		$heading = __( 'Export', 'zymarg-os' );
	} elseif ( 'demo' === $source ) {
		$heading = __( 'Demo content import finished.', 'zymarg-os' );
	} else {
		$thing   = ( 'categories' === $type ) ? __( 'categories', 'zymarg-os' ) : __( 'products', 'zymarg-os' );
		$heading = sprintf( /* translators: %s: products or categories */ __( 'Import of %s finished.', 'zymarg-os' ), $thing );
	}

	$is_snapshot = ( 'snapshot' === $type );
	?>
	<div class="zymarg-import__result <?php echo $is_err ? 'is-error' : ''; ?>">
		<h3><?php echo esc_html( $heading ); ?></h3>
		<?php if ( 'export' !== $type ) : ?>
			<div class="zymarg-import__chips">
				<span class="zymarg-import__chip"><b><?php echo esc_html( number_format_i18n( $created ) ); ?></b> <?php echo $is_snapshot ? esc_html__( 'products created', 'zymarg-os' ) : esc_html__( 'created', 'zymarg-os' ); ?></span>
				<span class="zymarg-import__chip"><b><?php echo esc_html( number_format_i18n( $skipped ) ); ?></b> <?php echo $is_snapshot ? esc_html__( 'products skipped', 'zymarg-os' ) : esc_html__( 'skipped (already existed)', 'zymarg-os' ); ?></span>
				<?php if ( $is_snapshot ) : ?>
					<span class="zymarg-import__chip"><b><?php echo esc_html( number_format_i18n( (int) ( $extra['categories_created'] ?? 0 ) ) ); ?></b> <?php esc_html_e( 'categories created', 'zymarg-os' ); ?></span>
					<span class="zymarg-import__chip"><b><?php echo esc_html( number_format_i18n( (int) ( $extra['categories_skipped'] ?? 0 ) ) ); ?></b> <?php esc_html_e( 'categories skipped', 'zymarg-os' ); ?></span>
				<?php endif; ?>
				<?php if ( ! empty( $errors ) ) : ?>
					<span class="zymarg-import__chip"><b><?php echo esc_html( number_format_i18n( count( $errors ) ) ); ?></b> <?php esc_html_e( 'issues', 'zymarg-os' ); ?></span>
				<?php endif; ?>
			</div>
		<?php endif; ?>
		<?php if ( ! empty( $errors ) ) : ?>
			<ul class="zymarg-import__errors">
				<?php foreach ( array_slice( $errors, 0, 10 ) as $err ) : ?>
					<li><?php echo esc_html( $err ); ?></li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
	</div>
	<?php
}

/**
 * Render the full Import / Export admin screen.
 *
 * @return void
 */
function zymarg_os_import_render_page() {
	if ( ! current_user_can( zymarg_os_import_cap() ) ) {
		wp_die( esc_html__( 'You do not have permission to access this page.', 'zymarg-os' ) );
	}

	$post_url  = esc_url( admin_url( 'admin-post.php' ) );
	$woo_ready = zymarg_os_import_woo_ready();
	$has_zip   = class_exists( 'ZipArchive' );
	$sample_p  = wp_nonce_url( admin_url( 'admin-post.php?action=zymarg_os_import_sample&which=products' ), 'zymarg_os_import_sample' );
	$sample_c  = wp_nonce_url( admin_url( 'admin-post.php?action=zymarg_os_import_sample&which=categories' ), 'zymarg_os_import_sample' );
	$disabled  = $woo_ready ? '' : 'disabled';

	$cat_terms = array();
	if ( $woo_ready ) {
		$cat_terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false, 'orderby' => 'name' ) );
		if ( is_wp_error( $cat_terms ) ) {
			$cat_terms = array();
		}
	}
	?>
	<div class="wrap zymarg-import">
		<h1>
			<?php if ( function_exists( 'zymarg_discovery_spark' ) ) { echo zymarg_discovery_spark( array( 'size' => 'lg' ) ); } // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<?php esc_html_e( 'Import / Export', 'zymarg-os' ); ?>
			<span class="zymarg-import__v">v<?php echo esc_html( defined( 'ZYMARG_OS_VERSION' ) ? ZYMARG_OS_VERSION : '' ); ?></span>
		</h1>
		<p class="zymarg-import__intro"><?php esc_html_e( 'Your store’s migration hub. Load demo content, bulk import or export products and categories, or take a full Store Snapshot you can restore on any other ZYMARG OS site. Everything is native WooCommerce data.', 'zymarg-os' ); ?></p>

		<?php zymarg_os_import_render_result(); ?>

		<?php if ( ! $woo_ready ) : ?>
			<div class="zymarg-import__result is-error">
				<h3><?php esc_html_e( 'WooCommerce is required', 'zymarg-os' ); ?></h3>
				<p style="margin:0;"><?php esc_html_e( 'Products and categories need WooCommerce. Please install and activate WooCommerce, then return here.', 'zymarg-os' ); ?></p>
			</div>
		<?php endif; ?>

		<?php
		$stats = zymarg_os_import_stats();
		if ( ! empty( $stats ) ) :
			?>
			<div class="zymarg-import__stats">
				<?php foreach ( $stats as $stat ) : ?>
					<div class="zymarg-import-stat">
						<span class="zymarg-import-stat__icon"><?php echo zymarg_os_import_icon( $stat['icon'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
						<span class="zymarg-import-stat__value"><?php echo esc_html( $stat['value'] ); ?></span>
						<span class="zymarg-import-stat__label"><?php echo esc_html( $stat['label'] ); ?></span>
					</div>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>

		<!-- ============ IMPORT ============ -->
		<h2 class="zymarg-import__section-title"><span><?php esc_html_e( 'Import', 'zymarg-os' ); ?></span></h2>
		<div class="zymarg-import__grid">

			<!-- Demo content -->
			<div class="zymarg-import-card">
				<div class="zymarg-import-card__head">
					<span class="zymarg-import-card__icon"><?php echo zymarg_os_import_icon( 'gift' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
					<h2 class="zymarg-import-card__title"><?php esc_html_e( 'Demo Content', 'zymarg-os' ); ?></h2>
				</div>
				<p class="zymarg-import-card__desc"><?php esc_html_e( 'One click loads a starter catalogue — 8 sample products across Apparel, Accessories and Home & Living — so you can see your store come to life.', 'zymarg-os' ); ?></p>
				<div class="zymarg-import-card__body">
					<form method="post" action="<?php echo $post_url; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
						<input type="hidden" name="action" value="zymarg_os_import_demo">
						<?php wp_nonce_field( 'zymarg_os_import_demo' ); ?>
						<button type="submit" class="button zymarg-import-btn" <?php echo esc_attr( $disabled ); ?>><?php esc_html_e( 'Import Demo Content', 'zymarg-os' ); ?></button>
					</form>
					<p class="zymarg-import__hint"><?php esc_html_e( 'Safe to run again — products with an existing SKU are skipped, never duplicated.', 'zymarg-os' ); ?></p>
				</div>
			</div>

			<!-- Products CSV -->
			<div class="zymarg-import-card">
				<div class="zymarg-import-card__head">
					<span class="zymarg-import-card__icon"><?php echo zymarg_os_import_icon( 'spreadsheet' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
					<h2 class="zymarg-import-card__title"><?php esc_html_e( 'Import Products (CSV)', 'zymarg-os' ); ?></h2>
				</div>
				<p class="zymarg-import-card__desc"><?php esc_html_e( 'Upload a CSV to create products in bulk. Categories in the file are created automatically, including parent › child hierarchy.', 'zymarg-os' ); ?></p>
				<div class="zymarg-import-card__body">
					<form method="post" action="<?php echo $post_url; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" enctype="multipart/form-data" data-zymarg-import-form="products">
						<input type="hidden" name="action" value="zymarg_os_import_products">
						<?php wp_nonce_field( 'zymarg_os_import_products' ); ?>
						<label class="zymarg-import-file" data-dropzone>
							<input type="file" name="zymarg_csv" accept=".csv,text/csv" required>
						</label>
						<button type="submit" class="button zymarg-import-btn" data-default-label="<?php esc_attr_e( 'Import Products', 'zymarg-os' ); ?>" <?php echo esc_attr( $disabled ); ?>><?php esc_html_e( 'Import Products', 'zymarg-os' ); ?></button>
					</form>

					<div class="zymarg-import-progress" data-import-progress hidden>
						<div class="zymarg-import-progress__track"><span class="zymarg-import-progress__fill" style="width:0%"></span></div>
						<div class="zymarg-import-progress__row">
							<span class="zymarg-import-progress__status"></span>
							<span class="zymarg-import-progress__pct">0%</span>
						</div>
						<div class="zymarg-import-progress__counts" data-progress-counts hidden></div>
						<div class="zymarg-import-progress__note" data-progress-note hidden></div>
						<div class="zymarg-import-progress__actions" data-progress-actions hidden></div>
					</div>

					<a class="zymarg-import__link" href="<?php echo esc_url( $sample_p ); ?>"><?php echo zymarg_os_import_icon( 'spreadsheet' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> <?php esc_html_e( 'Download sample CSV', 'zymarg-os' ); ?></a>
				</div>
			</div>

			<!-- Categories CSV -->
			<div class="zymarg-import-card">
				<div class="zymarg-import-card__head">
					<span class="zymarg-import-card__icon"><?php echo zymarg_os_import_icon( 'tags' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
					<h2 class="zymarg-import-card__title"><?php esc_html_e( 'Import Categories (CSV)', 'zymarg-os' ); ?></h2>
				</div>
				<p class="zymarg-import-card__desc"><?php esc_html_e( 'Upload a CSV of product categories — set a name, slug, parent and description to build your whole category tree at once.', 'zymarg-os' ); ?></p>
				<div class="zymarg-import-card__body">
					<form method="post" action="<?php echo $post_url; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" enctype="multipart/form-data">
						<input type="hidden" name="action" value="zymarg_os_import_categories">
						<?php wp_nonce_field( 'zymarg_os_import_categories' ); ?>
						<label class="zymarg-import-file" data-dropzone>
							<input type="file" name="zymarg_csv" accept=".csv,text/csv" required>
						</label>
						<button type="submit" class="button zymarg-import-btn" <?php echo esc_attr( $disabled ); ?>><?php esc_html_e( 'Import Categories', 'zymarg-os' ); ?></button>
					</form>
					<a class="zymarg-import__link" href="<?php echo esc_url( $sample_c ); ?>"><?php echo zymarg_os_import_icon( 'spreadsheet' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> <?php esc_html_e( 'Download sample CSV', 'zymarg-os' ); ?></a>
				</div>
			</div>

		</div>

		<!-- ============ EXPORT & BACKUP ============ -->
		<h2 class="zymarg-import__section-title"><span><?php esc_html_e( 'Export &amp; Backup', 'zymarg-os' ); ?></span></h2>
		<div class="zymarg-import__grid">

			<!-- Export products -->
			<div class="zymarg-import-card">
				<div class="zymarg-import-card__head">
					<span class="zymarg-import-card__icon"><?php echo zymarg_os_import_icon( 'export' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
					<h2 class="zymarg-import-card__title"><?php esc_html_e( 'Export Products (CSV)', 'zymarg-os' ); ?></h2>
				</div>
				<p class="zymarg-import-card__desc"><?php esc_html_e( 'Download your catalogue as a CSV — optionally narrowed by category and status. The file re-imports cleanly here or into any WooCommerce store.', 'zymarg-os' ); ?></p>
				<div class="zymarg-import-card__body">
					<form method="post" action="<?php echo $post_url; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" data-zymarg-export-form="products">
						<input type="hidden" name="action" value="zymarg_os_export_products">
						<?php wp_nonce_field( 'zymarg_os_export_products' ); ?>
						<div class="zymarg-import-filters">
							<label class="zymarg-import-select">
								<span><?php esc_html_e( 'Category', 'zymarg-os' ); ?></span>
								<select name="category">
									<option value="0"><?php esc_html_e( 'All categories', 'zymarg-os' ); ?></option>
									<?php foreach ( $cat_terms as $term ) : ?>
										<option value="<?php echo esc_attr( $term->term_id ); ?>"><?php echo esc_html( $term->name ); ?></option>
									<?php endforeach; ?>
								</select>
							</label>
							<label class="zymarg-import-select">
								<span><?php esc_html_e( 'Status', 'zymarg-os' ); ?></span>
								<select name="status">
									<option value="any"><?php esc_html_e( 'Any', 'zymarg-os' ); ?></option>
									<option value="publish"><?php esc_html_e( 'Published', 'zymarg-os' ); ?></option>
									<option value="draft"><?php esc_html_e( 'Draft', 'zymarg-os' ); ?></option>
								</select>
							</label>
						</div>
						<button type="submit" class="button zymarg-import-btn" <?php echo esc_attr( $disabled ); ?>><?php esc_html_e( 'Export Products', 'zymarg-os' ); ?></button>
					</form>
					<?php zymarg_os_import_progress_panel(); ?>
				</div>
			</div>

			<!-- Export categories -->
			<div class="zymarg-import-card">
				<div class="zymarg-import-card__head">
					<span class="zymarg-import-card__icon"><?php echo zymarg_os_import_icon( 'tags' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
					<h2 class="zymarg-import-card__title"><?php esc_html_e( 'Export Categories (CSV)', 'zymarg-os' ); ?></h2>
				</div>
				<p class="zymarg-import-card__desc"><?php esc_html_e( 'Download your full product-category tree (name, slug, parent, description) — perfect for cloning your taxonomy to another site.', 'zymarg-os' ); ?></p>
				<div class="zymarg-import-card__body">
					<form method="post" action="<?php echo $post_url; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">
						<input type="hidden" name="action" value="zymarg_os_export_categories">
						<?php wp_nonce_field( 'zymarg_os_export_categories' ); ?>
						<button type="submit" class="button zymarg-import-btn" <?php echo esc_attr( $disabled ); ?>><?php esc_html_e( 'Export Categories', 'zymarg-os' ); ?></button>
					</form>
				</div>
			</div>

			<!-- Store snapshot -->
			<div class="zymarg-import-card zymarg-import-card--feature">
				<span class="zymarg-import-card__badge"><?php esc_html_e( 'Backup', 'zymarg-os' ); ?></span>
				<div class="zymarg-import-card__head">
					<span class="zymarg-import-card__icon"><?php echo zymarg_os_import_icon( 'snapshot' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
					<h2 class="zymarg-import-card__title"><?php esc_html_e( 'Store Snapshot', 'zymarg-os' ); ?></h2>
				</div>
				<p class="zymarg-import-card__desc"><?php esc_html_e( 'Download one ZIP containing all products, the full category tree and a manifest — a portable backup you can restore on any other ZYMARG OS site in seconds.', 'zymarg-os' ); ?></p>
				<div class="zymarg-import-card__body">
					<form method="post" action="<?php echo $post_url; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" data-zymarg-export-form="snapshot">
						<input type="hidden" name="action" value="zymarg_os_export_snapshot">
						<?php wp_nonce_field( 'zymarg_os_export_snapshot' ); ?>
						<button type="submit" class="button zymarg-import-btn" <?php echo esc_attr( ( $woo_ready && $has_zip ) ? '' : 'disabled' ); ?>><?php esc_html_e( 'Download Snapshot (.zip)', 'zymarg-os' ); ?></button>
					</form>
					<?php zymarg_os_import_progress_panel(); ?>
					<?php if ( ! $has_zip ) : ?>
						<p class="zymarg-import__hint"><?php esc_html_e( 'Snapshots need the PHP “ZipArchive” extension, which is not enabled here. CSV export still works.', 'zymarg-os' ); ?></p>
					<?php endif; ?>
				</div>
			</div>

			<!-- Restore snapshot -->
			<div class="zymarg-import-card">
				<div class="zymarg-import-card__head">
					<span class="zymarg-import-card__icon"><?php echo zymarg_os_import_icon( 'restore' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
					<h2 class="zymarg-import-card__title"><?php esc_html_e( 'Restore Snapshot', 'zymarg-os' ); ?></h2>
				</div>
				<p class="zymarg-import-card__desc"><?php esc_html_e( 'Upload a Store Snapshot ZIP to recreate its categories and products here. Existing items (by SKU / name) are skipped, so it is safe to run.', 'zymarg-os' ); ?></p>
				<div class="zymarg-import-card__body">
					<form method="post" action="<?php echo $post_url; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" enctype="multipart/form-data">
						<input type="hidden" name="action" value="zymarg_os_import_snapshot">
						<?php wp_nonce_field( 'zymarg_os_import_snapshot' ); ?>
						<label class="zymarg-import-file" data-dropzone>
							<input type="file" name="zymarg_zip" accept=".zip,application/zip" required>
						</label>
						<button type="submit" class="button zymarg-import-btn" <?php echo esc_attr( $disabled ); ?>><?php esc_html_e( 'Restore Snapshot', 'zymarg-os' ); ?></button>
					</form>
				</div>
			</div>

		</div>

		<!-- ============ INSTRUCTIONS ============ -->
		<h2 class="zymarg-import__section-title"><span><?php esc_html_e( 'Instructions', 'zymarg-os' ); ?></span></h2>
		<div class="zymarg-import__grid">
			<div class="zymarg-import-card zymarg-import-card--wide">
				<div class="zymarg-import-card__head">
					<span class="zymarg-import-card__icon"><?php echo zymarg_os_import_icon( 'info' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
					<h2 class="zymarg-import-card__title"><?php esc_html_e( 'How it works', 'zymarg-os' ); ?></h2>
				</div>

				<div class="zymarg-import-notes">
					<div class="zymarg-import-notes__col">
						<h4><span class="zymarg-import-step">1</span> <?php esc_html_e( 'Product CSV columns', 'zymarg-os' ); ?></h4>
						<ul>
							<li><code>name</code> <?php esc_html_e( '(required)', 'zymarg-os' ); ?></li>
							<li><code>sku</code>, <code>regular_price</code>, <code>sale_price</code></li>
							<li><code>categories</code> — <?php esc_html_e( 'comma-separated; use › for hierarchy, e.g.', 'zymarg-os' ); ?> <code>Apparel &gt; T-Shirts</code></li>
							<li><code>stock</code>, <code>short_description</code>, <code>description</code></li>
							<li><code>images</code> — <?php esc_html_e( 'comma-separated image URLs (optional)', 'zymarg-os' ); ?></li>
							<li><code>published</code> — <code>1</code> <?php esc_html_e( 'or', 'zymarg-os' ); ?> <code>0</code> <?php esc_html_e( 'for draft', 'zymarg-os' ); ?></li>
						</ul>
					</div>

					<div class="zymarg-import-notes__col">
						<h4><span class="zymarg-import-step">2</span> <?php esc_html_e( 'Category CSV columns', 'zymarg-os' ); ?></h4>
						<ul>
							<li><code>name</code> <?php esc_html_e( '(required)', 'zymarg-os' ); ?>, <code>slug</code>, <code>description</code></li>
							<li><code>parent</code> — <?php esc_html_e( 'an existing or listed category name/slug', 'zymarg-os' ); ?></li>
						</ul>
						<h4 style="margin-top:14px;"><span class="zymarg-import-step">3</span> <?php esc_html_e( 'Store Snapshot', 'zymarg-os' ); ?></h4>
						<ul>
							<li><?php esc_html_e( 'A ZIP holding products.csv + categories.csv + manifest.json.', 'zymarg-os' ); ?></li>
							<li><?php esc_html_e( 'On restore, categories import first, then products.', 'zymarg-os' ); ?></li>
							<li><?php esc_html_e( 'Great for staging → live, or cloning a starter store.', 'zymarg-os' ); ?></li>
						</ul>
					</div>

					<div class="zymarg-import-notes__col">
						<h4><span class="zymarg-import-step">4</span> <?php esc_html_e( 'Good to know', 'zymarg-os' ); ?></h4>
						<ul>
							<li><?php esc_html_e( 'Drag a file onto an upload box to see its rows & columns before importing.', 'zymarg-os' ); ?></li>
							<li><?php esc_html_e( 'Rows whose SKU already exists are skipped (no duplicates).', 'zymarg-os' ); ?></li>
							<li><?php esc_html_e( 'Everything becomes native WooCommerce data (Products + product_cat).', 'zymarg-os' ); ?></li>
							<li><?php esc_html_e( 'Also compatible with a standard WooCommerce product export CSV.', 'zymarg-os' ); ?></li>
						</ul>
					</div>
				</div>

				<div class="zymarg-import-callout">
					<?php esc_html_e( 'Tip: moving to a new site? Take a Store Snapshot here, then upload it under Restore Snapshot on the new site — your catalogue and categories travel together. Large catalogues with image URLs take a little longer while images are fetched.', 'zymarg-os' ); ?>
				</div>
			</div>
		</div>

	</div>
	<?php
}
