<?php
/**
 * Lazy Images module.
 *
 * Toggle under Customize → ZYMARG OS → Modules (default ON).
 *
 *   ON  — Images and iframes load lazily, with decoding="async" for faster
 *         rendering. The first / above-the-fold image is left to WordPress's
 *         own LCP handling (we never force lazy on it), so this is safe.
 *   OFF — Lazy loading is disabled site-wide: WordPress core lazy loading is
 *         turned off and any loading="lazy" is stripped, so every image loads
 *         immediately.
 *
 * Loaded on every request so the OFF state can take effect too; all work is
 * gated behind the module toggle.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

if ( zymarg_os_module_enabled( 'lazy_images' ) ) {

	// Make sure core lazy loading is on.
	add_filter( 'wp_lazy_loading_enabled', '__return_true', 5 );

	// Add async decoding to attachment images (loading is left to core's
	// smart per-image decision so the LCP image is not lazy-loaded).
	add_filter( 'wp_get_attachment_image_attributes', 'zymarg_os_lazy_attachment_attrs', 20 );

	// Enhance images/iframes in common HTML streams.
	$streams = array( 'the_content', 'post_thumbnail_html', 'get_avatar', 'widget_text_content', 'woocommerce_single_product_image_thumbnail_html' );
	foreach ( $streams as $stream ) {
		add_filter( $stream, 'zymarg_os_lazy_enhance_html', 25 );
	}
} else {

	// Module OFF → disable lazy loading completely.
	add_filter( 'wp_lazy_loading_enabled', '__return_false', 5 );

	$streams = array( 'the_content', 'post_thumbnail_html', 'get_avatar', 'widget_text_content', 'woocommerce_single_product_image_thumbnail_html' );
	foreach ( $streams as $stream ) {
		add_filter( $stream, 'zymarg_os_lazy_strip_html', 25 );
	}
}

/**
 * Add decoding="async" to attachment image attributes (if not already set).
 *
 * @param array $attr Image attributes.
 * @return array
 */
function zymarg_os_lazy_attachment_attrs( $attr ) {
	if ( empty( $attr['decoding'] ) ) {
		$attr['decoding'] = 'async';
	}
	return $attr;
}

/**
 * Enhance an HTML blob: lazy-load iframes and add async decoding to images.
 *
 * Image `loading` is intentionally left to WordPress core (which skips the
 * first/LCP image), so we never regress Largest Contentful Paint. Honors
 * `skip-lazy` / `no-lazy` opt-out classes.
 *
 * @param string $html HTML.
 * @return string
 */
function zymarg_os_lazy_enhance_html( $html ) {
	if ( is_admin() || is_feed() || ! is_string( $html ) || '' === $html || false === strpos( $html, '<' ) ) {
		return $html;
	}

	// iframes → loading="lazy" when missing.
	$html = preg_replace_callback(
		'/<iframe\b[^>]*>/i',
		function ( $m ) {
			$tag = $m[0];
			if ( preg_match( '/\b(?:skip-lazy|no-lazy)\b/i', $tag ) ) {
				return $tag;
			}
			if ( ! preg_match( '/\bloading\s*=/i', $tag ) ) {
				$tag = preg_replace( '/<iframe\b/i', '<iframe loading="lazy"', $tag, 1 );
			}
			return $tag;
		},
		$html
	);

	// images → decoding="async" when missing (loading handled by core).
	$html = preg_replace_callback(
		'/<img\b[^>]*>/i',
		function ( $m ) {
			$tag = $m[0];
			if ( preg_match( '/\b(?:skip-lazy|no-lazy)\b/i', $tag ) ) {
				return $tag;
			}
			if ( ! preg_match( '/\bdecoding\s*=/i', $tag ) ) {
				$tag = preg_replace( '/<img\b/i', '<img decoding="async"', $tag, 1 );
			}
			return $tag;
		},
		$html
	);

	return $html;
}

/**
 * Strip loading="lazy" from images/iframes so they load eagerly (module OFF).
 *
 * @param string $html HTML.
 * @return string
 */
function zymarg_os_lazy_strip_html( $html ) {
	if ( ! is_string( $html ) || '' === $html || false === strpos( $html, '<' ) ) {
		return $html;
	}
	return preg_replace(
		'/(<(?:img|iframe)\b[^>]*?)\s+loading\s*=\s*([\'"])lazy\2/i',
		'$1',
		$html
	);
}
