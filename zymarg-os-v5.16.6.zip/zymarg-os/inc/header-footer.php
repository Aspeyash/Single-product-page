<?php
/**
 * Header & Footer builder.
 *
 * Optional, fully toggleable header and footer. Two content sources each:
 *   - Simple  : built-in layout (logo + menu for the header; widget columns +
 *               copyright for the footer) with sizing controls.
 *   - Block   : render a synced pattern / reusable block you design in the
 *               block editor — giving unlimited rows, columns and custom
 *               width/height (the editor handles all of that).
 *
 * Both are OFF by default, so sites that manage header/footer via a plugin are
 * unaffected. Controls live in Customize -> ZYMARG OS -> Header & Footer.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/* ---------------------------------------------------------------------- *
 * Footer widget areas (used by the Simple footer)
 * ---------------------------------------------------------------------- */
function zymarg_os_footer_widgets_init() {
	for ( $i = 1; $i <= 4; $i++ ) {
		register_sidebar(
			array(
				/* translators: %d: footer column number. */
				'name'          => sprintf( __( 'Footer Column %d', 'zymarg-os' ), $i ),
				'id'            => 'footer-' . $i,
				'description'   => __( 'Appears in the Simple footer.', 'zymarg-os' ),
				'before_widget' => '<section id="%1$s" class="widget %2$s">',
				'after_widget'  => '</section>',
				'before_title'  => '<h3 class="widget-title">',
				'after_title'   => '</h3>',
			)
		);
	}
}
add_action( 'widgets_init', 'zymarg_os_footer_widgets_init' );

/* ---------------------------------------------------------------------- *
 * Helpers
 * ---------------------------------------------------------------------- */

/**
 * Dropdown choices of available synced patterns / reusable blocks.
 *
 * @return array<int,string>
 */
function zymarg_os_block_choices() {
	$choices = array( 0 => __( '— None —', 'zymarg-os' ) );
	$blocks  = get_posts(
		array(
			'post_type'   => 'wp_block',
			'numberposts' => 100,
			'post_status' => 'publish',
			'orderby'     => 'title',
			'order'       => 'ASC',
		)
	);
	foreach ( $blocks as $block ) {
		$choices[ $block->ID ] = $block->post_title ? $block->post_title : ( '#' . $block->ID );
	}
	return $choices;
}

function zymarg_os_header_is_block() {
	return 'block' === get_theme_mod( 'zymarg_header_source', 'simple' );
}
function zymarg_os_header_is_simple() {
	return get_theme_mod( 'zymarg_header_enable', false ) && 'simple' === get_theme_mod( 'zymarg_header_source', 'simple' );
}
function zymarg_os_footer_is_block() {
	return 'block' === get_theme_mod( 'zymarg_footer_source', 'simple' );
}
function zymarg_os_footer_is_simple() {
	return get_theme_mod( 'zymarg_footer_enable', false ) && 'simple' === get_theme_mod( 'zymarg_footer_source', 'simple' );
}

/** Sanitizers. */
function zymarg_os_sanitize_hf_source( $v ) {
	return in_array( $v, array( 'simple', 'block' ), true ) ? $v : 'simple';
}
function zymarg_os_sanitize_hf_width( $v ) {
	return in_array( $v, array( 'contained', 'full' ), true ) ? $v : 'contained';
}
function zymarg_os_sanitize_header_layout( $v ) {
	return in_array( $v, array( 'logo-left', 'centered', 'logo-right' ), true ) ? $v : 'logo-left';
}
function zymarg_os_sanitize_hf_display( $v ) {
	return in_array( $v, array( 'all', 'include', 'exclude' ), true ) ? $v : 'all';
}

/**
 * Parse a comma-separated list of page IDs into an array of ints.
 *
 * @param string $csv Comma-separated IDs.
 * @return int[]
 */
function zymarg_os_parse_ids( $csv ) {
	$out = array();
	foreach ( explode( ',', (string) $csv ) as $part ) {
		$id = absint( trim( $part ) );
		if ( $id ) {
			$out[] = $id;
		}
	}
	return $out;
}

/**
 * Whether the header/footer should be visible on the current request, honouring
 * the enable toggle, the global display rule, and any per-page hide override.
 *
 * @param string $which 'header' or 'footer'.
 * @return bool
 */
function zymarg_os_hf_visible( $which ) {
	if ( ! get_theme_mod( 'zymarg_' . $which . '_enable', false ) ) {
		return false;
	}

	$id = (int) get_queried_object_id();

	// Per-page override (set in the page editor "ZYMARG OS" box).
	if ( $id && get_post_meta( $id, '_zymarg_hide_' . $which, true ) ) {
		return false;
	}

	$mode = get_theme_mod( 'zymarg_' . $which . '_display', 'all' );
	if ( 'all' === $mode ) {
		return true;
	}

	$list = zymarg_os_parse_ids( get_theme_mod( 'zymarg_' . $which . '_pages', '' ) );
	$in   = ( $id && in_array( $id, $list, true ) );

	if ( 'include' === $mode ) {
		return $in;            // Show ONLY on the listed pages.
	}
	if ( 'exclude' === $mode ) {
		return ! $in;          // Show everywhere EXCEPT the listed pages.
	}

	return true;
}

/* ---------------------------------------------------------------------- *
 * Customizer
 * ---------------------------------------------------------------------- */
function zymarg_os_headerfooter_customizer( $wp_customize ) {
	$wp_customize->add_section(
		'zymarg_os_headerfooter_section',
		array(
			'title'       => __( 'Header & Footer', 'zymarg-os' ),
			'description' => __( 'Optional header/footer. For unlimited rows/columns & custom sizes, choose "Block" and pick a synced pattern you build in the editor.', 'zymarg-os' ),
			'panel'       => 'zymarg_os_panel',
			'priority'    => 7,
		)
	);

	$s = 'zymarg_os_headerfooter_section';

	/* ===== HEADER ===== */
	$wp_customize->add_setting( 'zymarg_header_enable', array( 'default' => false, 'sanitize_callback' => 'zymarg_os_sanitize_checkbox' ) );
	$wp_customize->add_control( 'zymarg_header_enable', array( 'type' => 'checkbox', 'label' => __( 'Enable header', 'zymarg-os' ), 'section' => $s ) );

	$wp_customize->add_setting( 'zymarg_header_source', array( 'default' => 'simple', 'sanitize_callback' => 'zymarg_os_sanitize_hf_source' ) );
	$wp_customize->add_control( 'zymarg_header_source', array(
		'type' => 'select', 'label' => __( 'Header content', 'zymarg-os' ), 'section' => $s,
		'choices' => array( 'simple' => __( 'Simple (logo + menu)', 'zymarg-os' ), 'block' => __( 'Block (synced pattern — full control)', 'zymarg-os' ) ),
		'active_callback' => function () { return (bool) get_theme_mod( 'zymarg_header_enable', false ); },
	) );

	$wp_customize->add_setting( 'zymarg_header_block', array( 'default' => 0, 'sanitize_callback' => 'absint' ) );
	$wp_customize->add_control( 'zymarg_header_block', array(
		'type' => 'select', 'label' => __( 'Header block', 'zymarg-os' ),
		'description' => __( 'Build a synced pattern in the editor (rows/columns/sizes), then pick it here.', 'zymarg-os' ),
		'section' => $s, 'choices' => zymarg_os_block_choices(), 'active_callback' => 'zymarg_os_header_is_block',
	) );

	$wp_customize->add_setting( 'zymarg_header_layout', array( 'default' => 'logo-left', 'sanitize_callback' => 'zymarg_os_sanitize_header_layout' ) );
	$wp_customize->add_control( 'zymarg_header_layout', array(
		'type' => 'select', 'label' => __( 'Header layout', 'zymarg-os' ), 'section' => $s,
		'choices' => array( 'logo-left' => __( 'Logo left, menu right', 'zymarg-os' ), 'centered' => __( 'Centered', 'zymarg-os' ), 'logo-right' => __( 'Logo right, menu left', 'zymarg-os' ) ),
		'active_callback' => 'zymarg_os_header_is_simple',
	) );

	$wp_customize->add_setting( 'zymarg_header_sticky', array( 'default' => false, 'sanitize_callback' => 'zymarg_os_sanitize_checkbox' ) );
	$wp_customize->add_control( 'zymarg_header_sticky', array( 'type' => 'checkbox', 'label' => __( 'Sticky header', 'zymarg-os' ), 'section' => $s, 'active_callback' => function () { return (bool) get_theme_mod( 'zymarg_header_enable', false ); } ) );

	$wp_customize->add_setting( 'zymarg_header_width', array( 'default' => 'contained', 'sanitize_callback' => 'zymarg_os_sanitize_hf_width' ) );
	$wp_customize->add_control( 'zymarg_header_width', array(
		'type' => 'select', 'label' => __( 'Header width', 'zymarg-os' ), 'section' => $s,
		'choices' => array( 'contained' => __( 'Contained', 'zymarg-os' ), 'full' => __( 'Full width', 'zymarg-os' ) ),
		'active_callback' => function () { return (bool) get_theme_mod( 'zymarg_header_enable', false ); },
	) );

	$wp_customize->add_setting( 'zymarg_header_bg', array( 'default' => '#ffffff', 'sanitize_callback' => 'sanitize_hex_color' ) );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'zymarg_header_bg', array( 'label' => __( 'Header background', 'zymarg-os' ), 'section' => $s, 'active_callback' => function () { return (bool) get_theme_mod( 'zymarg_header_enable', false ); } ) ) );

	$wp_customize->add_setting( 'zymarg_header_padding', array( 'default' => 16, 'sanitize_callback' => 'absint' ) );
	$wp_customize->add_control( 'zymarg_header_padding', array(
		'type' => 'number', 'label' => __( 'Header height (vertical padding, px)', 'zymarg-os' ), 'section' => $s,
		'input_attrs' => array( 'min' => 0, 'max' => 80, 'step' => 1 ),
		'active_callback' => function () { return (bool) get_theme_mod( 'zymarg_header_enable', false ); },
	) );

	$wp_customize->add_setting( 'zymarg_header_display', array( 'default' => 'all', 'sanitize_callback' => 'zymarg_os_sanitize_hf_display' ) );
	$wp_customize->add_control( 'zymarg_header_display', array(
		'type' => 'select', 'label' => __( 'Show header on', 'zymarg-os' ), 'section' => $s,
		'choices' => array(
			'all'     => __( 'Entire site', 'zymarg-os' ),
			'include' => __( 'Only specific pages', 'zymarg-os' ),
			'exclude' => __( 'All pages except…', 'zymarg-os' ),
		),
		'active_callback' => function () { return (bool) get_theme_mod( 'zymarg_header_enable', false ); },
	) );
	$wp_customize->add_setting( 'zymarg_header_pages', array( 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'zymarg_header_pages', array(
		'type' => 'text', 'label' => __( 'Page IDs', 'zymarg-os' ),
		'description' => __( 'Comma-separated page IDs (e.g. 12, 45). A page ID is the "post=" number in its edit URL. You can also hide the header per page from the page editor.', 'zymarg-os' ),
		'section' => $s,
		'active_callback' => function () { return (bool) get_theme_mod( 'zymarg_header_enable', false ) && 'all' !== get_theme_mod( 'zymarg_header_display', 'all' ); },
	) );

	/* ===== FOOTER ===== */
	$wp_customize->add_setting( 'zymarg_footer_enable', array( 'default' => false, 'sanitize_callback' => 'zymarg_os_sanitize_checkbox' ) );
	$wp_customize->add_control( 'zymarg_footer_enable', array( 'type' => 'checkbox', 'label' => __( 'Enable footer', 'zymarg-os' ), 'section' => $s ) );

	$wp_customize->add_setting( 'zymarg_footer_source', array( 'default' => 'simple', 'sanitize_callback' => 'zymarg_os_sanitize_hf_source' ) );
	$wp_customize->add_control( 'zymarg_footer_source', array(
		'type' => 'select', 'label' => __( 'Footer content', 'zymarg-os' ), 'section' => $s,
		'choices' => array( 'simple' => __( 'Simple (widget columns)', 'zymarg-os' ), 'block' => __( 'Block (synced pattern — full control)', 'zymarg-os' ) ),
		'active_callback' => function () { return (bool) get_theme_mod( 'zymarg_footer_enable', false ); },
	) );

	$wp_customize->add_setting( 'zymarg_footer_block', array( 'default' => 0, 'sanitize_callback' => 'absint' ) );
	$wp_customize->add_control( 'zymarg_footer_block', array(
		'type' => 'select', 'label' => __( 'Footer block', 'zymarg-os' ), 'section' => $s,
		'choices' => zymarg_os_block_choices(), 'active_callback' => 'zymarg_os_footer_is_block',
	) );

	$wp_customize->add_setting( 'zymarg_footer_columns', array( 'default' => 3, 'sanitize_callback' => 'absint' ) );
	$wp_customize->add_control( 'zymarg_footer_columns', array(
		'type' => 'number', 'label' => __( 'Footer widget columns (1–4)', 'zymarg-os' ), 'section' => $s,
		'input_attrs' => array( 'min' => 1, 'max' => 4, 'step' => 1 ), 'active_callback' => 'zymarg_os_footer_is_simple',
	) );

	$wp_customize->add_setting( 'zymarg_footer_text', array( 'default' => '', 'sanitize_callback' => 'wp_kses_post' ) );
	$wp_customize->add_control( 'zymarg_footer_text', array(
		'type' => 'textarea', 'label' => __( 'Footer bottom text', 'zymarg-os' ),
		'description' => __( 'Copyright / bottom line. Leave blank for an auto © line.', 'zymarg-os' ),
		'section' => $s, 'active_callback' => 'zymarg_os_footer_is_simple',
	) );

	$wp_customize->add_setting( 'zymarg_footer_width', array( 'default' => 'contained', 'sanitize_callback' => 'zymarg_os_sanitize_hf_width' ) );
	$wp_customize->add_control( 'zymarg_footer_width', array(
		'type' => 'select', 'label' => __( 'Footer width', 'zymarg-os' ), 'section' => $s,
		'choices' => array( 'contained' => __( 'Contained', 'zymarg-os' ), 'full' => __( 'Full width', 'zymarg-os' ) ),
		'active_callback' => function () { return (bool) get_theme_mod( 'zymarg_footer_enable', false ); },
	) );

	$wp_customize->add_setting( 'zymarg_footer_bg', array( 'default' => '#faf8ff', 'sanitize_callback' => 'sanitize_hex_color' ) );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'zymarg_footer_bg', array( 'label' => __( 'Footer background', 'zymarg-os' ), 'section' => $s, 'active_callback' => function () { return (bool) get_theme_mod( 'zymarg_footer_enable', false ); } ) ) );

	$wp_customize->add_setting( 'zymarg_footer_padding', array( 'default' => 40, 'sanitize_callback' => 'absint' ) );
	$wp_customize->add_control( 'zymarg_footer_padding', array(
		'type' => 'number', 'label' => __( 'Footer vertical padding (px)', 'zymarg-os' ), 'section' => $s,
		'input_attrs' => array( 'min' => 0, 'max' => 120, 'step' => 2 ),
		'active_callback' => function () { return (bool) get_theme_mod( 'zymarg_footer_enable', false ); },
	) );

	$wp_customize->add_setting( 'zymarg_footer_display', array( 'default' => 'all', 'sanitize_callback' => 'zymarg_os_sanitize_hf_display' ) );
	$wp_customize->add_control( 'zymarg_footer_display', array(
		'type' => 'select', 'label' => __( 'Show footer on', 'zymarg-os' ), 'section' => $s,
		'choices' => array(
			'all'     => __( 'Entire site', 'zymarg-os' ),
			'include' => __( 'Only specific pages', 'zymarg-os' ),
			'exclude' => __( 'All pages except…', 'zymarg-os' ),
		),
		'active_callback' => function () { return (bool) get_theme_mod( 'zymarg_footer_enable', false ); },
	) );
	$wp_customize->add_setting( 'zymarg_footer_pages', array( 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'zymarg_footer_pages', array(
		'type' => 'text', 'label' => __( 'Page IDs', 'zymarg-os' ),
		'description' => __( 'Comma-separated page IDs. You can also hide the footer per page from the page editor.', 'zymarg-os' ),
		'section' => $s,
		'active_callback' => function () { return (bool) get_theme_mod( 'zymarg_footer_enable', false ) && 'all' !== get_theme_mod( 'zymarg_footer_display', 'all' ); },
	) );
}
add_action( 'customize_register', 'zymarg_os_headerfooter_customizer' );

/* ---------------------------------------------------------------------- *
 * Rendering
 * ---------------------------------------------------------------------- */

/**
 * Render the site header (called from header.php).
 *
 * @return void
 */
function zymarg_os_render_site_header() {
	if ( ! zymarg_os_hf_visible( 'header' ) ) {
		return;
	}

	$source = get_theme_mod( 'zymarg_header_source', 'simple' );
	$sticky = get_theme_mod( 'zymarg_header_sticky', false );
	$bg     = get_theme_mod( 'zymarg_header_bg', '#ffffff' );
	$pad    = absint( get_theme_mod( 'zymarg_header_padding', 16 ) );
	$width  = get_theme_mod( 'zymarg_header_width', 'contained' );
	$layout = get_theme_mod( 'zymarg_header_layout', 'logo-left' );

	$classes = 'zymarg-site-header';
	if ( $sticky ) {
		$classes .= ' zymarg-sticky';
	}
	$style       = ( $bg ? 'background:' . $bg . ';' : '' ) . ( $pad ? 'padding-block:' . $pad . 'px;' : '' );
	$inner_class = ( 'full' === $width ) ? 'zymarg-container--fluid' : 'zymarg-container';
	$inner_class .= ' zymarg-header__inner is-' . sanitize_html_class( $layout );

	echo '<header class="' . esc_attr( $classes ) . '"' . ( $style ? ' style="' . esc_attr( $style ) . '"' : '' ) . '>'; // phpcs:ignore
	echo '<div class="' . esc_attr( $inner_class ) . '">';

	if ( 'block' === $source ) {
		zymarg_os_render_block_part( absint( get_theme_mod( 'zymarg_header_block', 0 ) ) );
	} else {
		zymarg_os_render_simple_header();
	}

	echo '</div></header>';
}

/**
 * The built-in simple header markup.
 *
 * @return void
 */
function zymarg_os_render_simple_header() {
	echo '<div class="zymarg-header__brand">';
	if ( has_custom_logo() ) {
		the_custom_logo();
	} else {
		printf( '<a class="zymarg-header__title" href="%s">%s</a>', esc_url( home_url( '/' ) ), esc_html( get_bloginfo( 'name' ) ) );
	}
	echo '</div>';

	if ( has_nav_menu( 'primary' ) ) {
		echo '<button class="zymarg-header__toggle" aria-label="' . esc_attr__( 'Menu', 'zymarg-os' ) . '" aria-expanded="false"><span></span><span></span><span></span></button>';
		echo '<nav class="zymarg-nav zymarg-header__nav" aria-label="' . esc_attr__( 'Primary', 'zymarg-os' ) . '">';
		wp_nav_menu(
			array(
				'theme_location' => 'primary',
				'container'      => false,
				'menu_class'     => 'zymarg-menu',
				'fallback_cb'    => false,
				'walker'         => class_exists( 'ZYMARG_OS_Mega_Menu_Walker' ) ? new ZYMARG_OS_Mega_Menu_Walker() : '',
			)
		);
		echo '</nav>';
	}
}

/**
 * Render the site footer (called from footer.php).
 *
 * @return void
 */
function zymarg_os_render_site_footer() {
	if ( ! zymarg_os_hf_visible( 'footer' ) ) {
		return;
	}

	$source = get_theme_mod( 'zymarg_footer_source', 'simple' );
	$bg     = get_theme_mod( 'zymarg_footer_bg', '#faf8ff' );
	$pad    = absint( get_theme_mod( 'zymarg_footer_padding', 40 ) );
	$width  = get_theme_mod( 'zymarg_footer_width', 'contained' );

	$style       = ( $bg ? 'background:' . $bg . ';' : '' ) . ( $pad ? 'padding-block:' . $pad . 'px;' : '' );
	$inner_class = ( 'full' === $width ) ? 'zymarg-container--fluid' : 'zymarg-container';

	echo '<footer class="zymarg-site-footer"' . ( $style ? ' style="' . esc_attr( $style ) . '"' : '' ) . '>'; // phpcs:ignore
	echo '<div class="' . esc_attr( $inner_class ) . '">';

	if ( 'block' === $source ) {
		zymarg_os_render_block_part( absint( get_theme_mod( 'zymarg_footer_block', 0 ) ) );
	} else {
		zymarg_os_render_simple_footer();
	}

	echo '</div></footer>';
}

/**
 * The built-in simple footer markup.
 *
 * @return void
 */
function zymarg_os_render_simple_footer() {
	$cols = min( 4, max( 1, absint( get_theme_mod( 'zymarg_footer_columns', 3 ) ) ) );

	echo '<div class="zymarg-footer__widgets" style="grid-template-columns:repeat(' . (int) $cols . ',1fr)">';
	for ( $i = 1; $i <= $cols; $i++ ) {
		echo '<div class="zymarg-footer__col">';
		if ( is_active_sidebar( 'footer-' . $i ) ) {
			dynamic_sidebar( 'footer-' . $i );
		}
		echo '</div>';
	}
	echo '</div>';

	$text = get_theme_mod( 'zymarg_footer_text', '' );
	if ( '' === trim( (string) $text ) ) {
		/* translators: 1: year, 2: site name. */
		$text = sprintf( esc_html__( '© %1$s %2$s. All rights reserved.', 'zymarg-os' ), gmdate( 'Y' ), get_bloginfo( 'name' ) );
	}
	echo '<div class="zymarg-footer__bottom">' . wp_kses_post( $text ) . '</div>';
}

/**
 * Render a synced pattern / reusable block by ID.
 *
 * @param int $block_id Block post ID.
 * @return void
 */
function zymarg_os_render_block_part( $block_id ) {
	if ( ! $block_id ) {
		echo '<p class="zymarg-hf-empty">' . esc_html__( 'Select a block in Customize → ZYMARG OS → Header & Footer.', 'zymarg-os' ) . '</p>';
		return;
	}
	$post = get_post( $block_id );
	if ( $post && 'wp_block' === $post->post_type && 'publish' === $post->post_status ) {
		echo do_blocks( $post->post_content ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- block output.
	}
}
