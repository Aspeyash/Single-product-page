<?php
/**
 * Smart UX bundle.
 *
 * Two "wow" features, each a toggleable module:
 *   - Instant Load: prefetch a page on hover/tap so clicks feel instant.
 *   - Scroll Animations: reveal elements with the .zymarg-reveal class on scroll.
 *
 * Live Search was REMOVED in v5.12.15 — search-as-you-type is now provided by a
 * dedicated plugin. The [zymarg_search] shortcode, its AJAX endpoints
 * (zymarg_live_search) and the trending-searches tracker no longer ship with the
 * theme. The standard WordPress search form (searchform.php) and the search
 * results template (search.php) are unaffected.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register + conditionally enqueue the Smart UX assets.
 *
 * @return void
 */
function zymarg_os_smart_ux_assets() {
	$ver = ZYMARG_OS_VERSION;

	// Scroll reveal (global, tiny).
	if ( zymarg_os_module_enabled( 'scroll_animations' ) ) {
		wp_enqueue_script( 'zymarg-os-scroll-reveal', ZYMARG_OS_URI . '/assets/js/scroll-reveal.js', array(), $ver, true );
	}

	// Instant load (global, tiny).
	if ( zymarg_os_module_enabled( 'instant_load' ) ) {
		wp_enqueue_script( 'zymarg-os-instant-load', ZYMARG_OS_URI . '/assets/js/instant-load.js', array(), $ver, true );
	}
}
add_action( 'wp_enqueue_scripts', 'zymarg_os_smart_ux_assets', 16 );
