<?php
/**
 * Admin Help page.
 *
 * Adds Appearance -> ZYMARG OS Help: a friendly, in-dashboard guide showing how
 * to use the theme's features (Discovery Spark, dark-mode toggle, block
 * patterns, fonts/colours) with one-click "Copy" buttons for every shortcode —
 * so nothing needs to be memorised or unzipped.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Enqueue the Discovery Spark stylesheet on ZYMARG OS admin pages so previews
 * and the header Spark render.
 *
 * @param string $hook Current admin page hook.
 * @return void
 */
function zymarg_os_help_assets( $hook ) {
	if ( false === strpos( (string) $hook, 'zymarg-os' ) ) {
		return;
	}
	if ( wp_style_is( 'zymarg-os-discovery-spark', 'registered' ) ) {
		wp_enqueue_style( 'zymarg-os-discovery-spark' );
	}
}
add_action( 'admin_enqueue_scripts', 'zymarg_os_help_assets' );

/**
 * Output one "copy a shortcode" row.
 *
 * @param string $code The shortcode/text to copy.
 * @param string $desc A short description.
 * @return void
 */
function zymarg_os_help_copy_row( $code, $desc ) {
	printf(
		'<div class="zymarg-help-row"><code class="zymarg-help-code">%1$s</code>'
		. '<button type="button" class="button zymarg-copy" data-clip="%2$s">%3$s</button>'
		. '<span class="zymarg-help-desc">%4$s</span></div>',
		esc_html( $code ),
		esc_attr( $code ),
		esc_html__( 'Copy', 'zymarg-os' ),
		esc_html( $desc )
	);
}

/**
 * Render the Help page.
 *
 * @return void
 */
function zymarg_os_render_help_page() {
	$customize_url = admin_url( 'customize.php' );
	?>
	<div class="wrap zymarg-help">
		<h1>
			<?php if ( function_exists( 'zymarg_discovery_spark' ) ) { echo zymarg_discovery_spark( array( 'size' => 'lg' ) ); } // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<?php esc_html_e( 'ZYMARG OS Help', 'zymarg-os' ); ?>
			<span class="zymarg-help-version">v<?php echo esc_html( ZYMARG_OS_VERSION ); ?></span>
		</h1>
		<p class="zymarg-help-intro"><?php esc_html_e( 'Everything you need to use ZYMARG OS — copy any shortcode with one click. No memorising required.', 'zymarg-os' ); ?></p>

		<div class="zymarg-help-grid">

			<!-- Updating the theme -->
			<section class="zymarg-help-card">
				<h2><?php esc_html_e( 'Updating the theme (one click)', 'zymarg-os' ); ?></h2>
				<p><?php esc_html_e( 'When you get a newer ZYMARG OS zip, you no longer need to go to Appearance → Themes. Update it straight from this menu:', 'zymarg-os' ); ?></p>
				<ol>
					<li><?php esc_html_e( 'In the sidebar, open ZYMARG OS → "Update / Upload Theme".', 'zymarg-os' ); ?></li>
					<li><?php esc_html_e( 'Choose your new theme .zip file and click "Install / Update Now".', 'zymarg-os' ); ?></li>
					<li><?php esc_html_e( 'Because the theme is already installed, WordPress asks you to confirm replacing it — click "Replace current with uploaded". Your settings are kept.', 'zymarg-os' ); ?></li>
				</ol>
				<p class="zymarg-help-desc"><?php esc_html_e( 'There is also an "Update / Upload Theme" button on the Welcome screen. (Only users who can install themes see this option.)', 'zymarg-os' ); ?></p>
			</section>

			<!-- Plugins -->
			<section class="zymarg-help-card">
				<h2><?php esc_html_e( 'Plugins (add & review)', 'zymarg-os' ); ?></h2>
				<p><?php esc_html_e( 'ZYMARG OS → Plugins gives you a two-column screen so you do not have to hunt around the dashboard:', 'zymarg-os' ); ?></p>
				<ul>
					<li><strong><?php esc_html_e( 'Add Plugin:', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'upload a plugin .zip and click Install Now, or use the button to browse the official plugin directory.', 'zymarg-os' ); ?></li>
					<li><strong><?php esc_html_e( 'Installed Plugins:', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'a list of everything installed with an Active or Inactive badge, plus a button to the full Plugins screen to activate, deactivate or delete.', 'zymarg-os' ); ?></li>
				</ul>
				<p class="zymarg-help-desc"><?php esc_html_e( 'Activating, deactivating and deleting still happen on the standard WordPress Plugins screen (one click away) so nothing risky is duplicated. Only users who can install plugins see this option.', 'zymarg-os' ); ?></p>
			</section>

			<!-- Single Product controls -->
			<section class="zymarg-help-card">
				<h2><?php esc_html_e( 'Single Product page — what shows', 'zymarg-os' ); ?></h2>
				<p><?php esc_html_e( 'Your theme can decide what appears on the single product page — the tabs and the extra sections — no matter which plugin added them (WooCommerce, Dokan, etc.).', 'zymarg-os' ); ?></p>

				<h3><?php esc_html_e( 'Where to find the settings', 'zymarg-os' ); ?></h3>
				<p>
					<?php
					printf(
						/* translators: %s: link to the Customizer section. */
						esc_html__( 'Open %s.', 'zymarg-os' ),
						'<a href="' . esc_url( add_query_arg( 'autofocus[section]', 'zymarg_os_pdp_section', $customize_url ) ) . '">' . esc_html__( 'Customize → ZYMARG OS → Single Product', 'zymarg-os' ) . '</a>'
					);
					?>
				</p>
				<p class="zymarg-help-desc"><?php esc_html_e( 'Tip: visit any product on the front end once. The theme then lists every tab your plugins register, so you get a checkbox for each.', 'zymarg-os' ); ?></p>

				<h3><?php esc_html_e( 'Tabs', 'zymarg-os' ); ?></h3>
				<ul>
					<li><strong><?php esc_html_e( 'Show / hide', 'zymarg-os' ); ?></strong> <?php esc_html_e( '— turn any tab on or off (Description, Additional information, Reviews, Shipping, Questions & Answers, …).', 'zymarg-os' ); ?></li>
					<li><strong><?php esc_html_e( 'Rename', 'zymarg-os' ); ?></strong> <?php esc_html_e( '— give any tab a custom title.', 'zymarg-os' ); ?></li>
					<li><strong><?php esc_html_e( 'Reorder', 'zymarg-os' ); ?></strong> <?php esc_html_e( '— set an order number (lower shows first).', 'zymarg-os' ); ?></li>
				</ul>

				<h3><?php esc_html_e( 'Sections', 'zymarg-os' ); ?></h3>
				<ul>
					<li><?php esc_html_e( 'Related products', 'zymarg-os' ); ?> <span class="zymarg-help-desc">(<?php esc_html_e( 'WooCommerce', 'zymarg-os' ); ?>)</span></li>
					<li><?php esc_html_e( 'You may also like / Up-sells', 'zymarg-os' ); ?> <span class="zymarg-help-desc">(<?php esc_html_e( 'WooCommerce', 'zymarg-os' ); ?>)</span></li>
					<li><?php esc_html_e( 'More Products from this store', 'zymarg-os' ); ?> <span class="zymarg-help-desc">(<?php esc_html_e( 'Dokan', 'zymarg-os' ); ?>)</span></li>
					<li><?php esc_html_e( 'Product Enquiry button', 'zymarg-os' ); ?> <span class="zymarg-help-desc">(<?php esc_html_e( 'Dokan', 'zymarg-os' ); ?>)</span></li>
				</ul>

				<h3><?php esc_html_e( 'Tabs detected on your product pages', 'zymarg-os' ); ?></h3>
				<?php
				$zymarg_pdp_tabs = get_option( 'zymarg_os_pdp_tabs', array() );
				if ( empty( $zymarg_pdp_tabs ) || ! is_array( $zymarg_pdp_tabs ) ) :
					?>
					<p class="zymarg-help-desc"><?php esc_html_e( 'No tabs detected yet — open any product on the front end once, then refresh this page.', 'zymarg-os' ); ?></p>
				<?php else : ?>
					<table class="widefat striped zymarg-help-table">
						<thead><tr><th><?php esc_html_e( 'Tab title', 'zymarg-os' ); ?></th><th><?php esc_html_e( 'Internal key', 'zymarg-os' ); ?></th></tr></thead>
						<tbody>
							<?php foreach ( $zymarg_pdp_tabs as $zymarg_tab_key => $zymarg_tab_title ) : ?>
								<tr><td><?php echo esc_html( $zymarg_tab_title ); ?></td><td><code><?php echo esc_html( $zymarg_tab_key ); ?></code></td></tr>
							<?php endforeach; ?>
						</tbody>
					</table>
					<p class="zymarg-help-desc"><?php esc_html_e( 'These are the tabs the theme found — each one has show / rename / order controls in the Single Product Customizer section.', 'zymarg-os' ); ?></p>
				<?php endif; ?>
			</section>

			<!-- Scroll to Top button -->
			<section class="zymarg-help-card">
				<h2><?php esc_html_e( 'Scroll to Top button', 'zymarg-os' ); ?></h2>
				<p><?php esc_html_e( 'The floating "back to top" button that appears in the bottom corner once a visitor scrolls down. It is fully customizable — colours, icon, shape, position, behaviour and where it appears.', 'zymarg-os' ); ?></p>

				<h3><?php esc_html_e( 'Where to find the settings', 'zymarg-os' ); ?></h3>
				<ol>
					<li><?php esc_html_e( 'First make sure it is on: ZYMARG OS → Customize → Modules → "Scroll to Top".', 'zymarg-os' ); ?></li>
					<li>
						<?php
						printf(
							/* translators: %s: link to the Customizer section. */
							esc_html__( 'Then open %s to style and control it.', 'zymarg-os' ),
							'<a href="' . esc_url( add_query_arg( 'autofocus[section]', 'zymarg_os_scrolltop_section', $customize_url ) ) . '">' . esc_html__( 'Customize → ZYMARG OS → Scroll to Top', 'zymarg-os' ) . '</a>'
						);
						?>
					</li>
				</ol>

				<h3><?php esc_html_e( 'Appearance', 'zymarg-os' ); ?></h3>
				<ul>
					<li><strong><?php esc_html_e( 'Background colour', 'zymarg-os' ); ?></strong> <?php esc_html_e( '— and a separate hover colour.', 'zymarg-os' ); ?></li>
					<li><strong><?php esc_html_e( 'Icon colour', 'zymarg-os' ); ?></strong> <?php esc_html_e( '— the colour of the arrow inside.', 'zymarg-os' ); ?></li>
					<li><strong><?php esc_html_e( 'Icon', 'zymarg-os' ); ?></strong> <?php esc_html_e( '— pick from Arrow, Chevron, Caret, Double chevron, Align-top bar, or Arrow-in-circle.', 'zymarg-os' ); ?></li>
					<li><strong><?php esc_html_e( 'Shape, size & position', 'zymarg-os' ); ?></strong> <?php esc_html_e( '— circle / rounded square / pill, a size in pixels, and bottom-right or bottom-left.', 'zymarg-os' ); ?></li>
				</ul>

				<h3><?php esc_html_e( 'Behaviour', 'zymarg-os' ); ?></h3>
				<ul>
					<li><strong><?php esc_html_e( 'Show after scrolling (px)', 'zymarg-os' ); ?></strong> <?php esc_html_e( '— how far down the page before it appears.', 'zymarg-os' ); ?></li>
					<li><strong><?php esc_html_e( 'Scroll-progress ring', 'zymarg-os' ); ?></strong> <?php esc_html_e( '— an optional ring around the button that fills as the visitor scrolls.', 'zymarg-os' ); ?></li>
					<li><strong><?php esc_html_e( 'Hide on mobile', 'zymarg-os' ); ?></strong> <?php esc_html_e( '— hide it on screens under 600px.', 'zymarg-os' ); ?></li>
				</ul>

				<h3><?php esc_html_e( 'Where it appears (per-page control)', 'zymarg-os' ); ?></h3>
				<p><?php esc_html_e( 'Use "Where to show" to choose one of:', 'zymarg-os' ); ?></p>
				<ul>
					<li><strong><?php esc_html_e( 'Entire site', 'zymarg-os' ); ?></strong> <?php esc_html_e( '— show it everywhere (default).', 'zymarg-os' ); ?></li>
					<li><strong><?php esc_html_e( 'Entire site, except these pages', 'zymarg-os' ); ?></strong> <?php esc_html_e( '— show everywhere but the pages you list.', 'zymarg-os' ); ?></li>
					<li><strong><?php esc_html_e( 'Only on these pages', 'zymarg-os' ); ?></strong> <?php esc_html_e( '— show it only on the pages you list.', 'zymarg-os' ); ?></li>
				</ul>
				<p class="zymarg-help-desc"><?php esc_html_e( 'In the "Pages (IDs or slugs)" field, enter a comma-separated list of page IDs or slugs — for example: 42, about, contact. You can also use the keywords "home" (front page) and "shop" (WooCommerce shop).', 'zymarg-os' ); ?></p>
			</section>

			<!-- Discovery Spark -->
			<section class="zymarg-help-card">
				<h2><?php esc_html_e( 'Discovery Spark', 'zymarg-os' ); ?></h2>
				<p><?php esc_html_e( 'The animated ZYMARG mark. Paste a shortcode into a "Shortcode" block (or anywhere that accepts shortcodes).', 'zymarg-os' ); ?></p>

				<div class="zymarg-help-preview">
					<?php
					if ( function_exists( 'zymarg_discovery_spark' ) ) {
						echo zymarg_discovery_spark( array( 'size' => 'sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						echo zymarg_discovery_spark( array( 'size' => 'md' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						echo zymarg_discovery_spark( array( 'size' => 'lg' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						echo zymarg_discovery_spark( array( 'size' => 'xl' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					}
					?>
				</div>

				<h3><?php esc_html_e( 'Copy a shortcode', 'zymarg-os' ); ?></h3>
				<?php
				zymarg_os_help_copy_row( '[zymarg_spark]', __( 'Default (24px, animated)', 'zymarg-os' ) );
				zymarg_os_help_copy_row( '[zymarg_spark size="xl"]', __( 'Bigger (48px)', 'zymarg-os' ) );
				zymarg_os_help_copy_row( '[zymarg_spark animate="false"]', __( 'No animation (static)', 'zymarg-os' ) );
				zymarg_os_help_copy_row( '[zymarg_spark size="lg" purple="#9500a5" gold="#ffd166"]', __( 'Custom size + colours', 'zymarg-os' ) );
				?>

				<h3><?php esc_html_e( 'Available sizes', 'zymarg-os' ); ?></h3>
				<table class="widefat striped zymarg-help-table">
					<thead><tr><th><?php esc_html_e( 'size value', 'zymarg-os' ); ?></th><th><?php esc_html_e( 'Pixels', 'zymarg-os' ); ?></th><th><?php esc_html_e( 'Good for', 'zymarg-os' ); ?></th></tr></thead>
					<tbody>
						<tr><td><code>xs</code></td><td>16px</td><td><?php esc_html_e( 'Inline with text', 'zymarg-os' ); ?></td></tr>
						<tr><td><code>sm</code></td><td>20px</td><td><?php esc_html_e( 'Buttons, small UI', 'zymarg-os' ); ?></td></tr>
						<tr><td><code>md</code></td><td>24px</td><td><?php esc_html_e( 'Default', 'zymarg-os' ); ?></td></tr>
						<tr><td><code>lg</code></td><td>32px</td><td><?php esc_html_e( 'Section headers', 'zymarg-os' ); ?></td></tr>
						<tr><td><code>xl</code></td><td>48px</td><td><?php esc_html_e( 'Heroes, splash', 'zymarg-os' ); ?></td></tr>
					</tbody>
				</table>
			</section>

			<!-- Smart dark mode -->
			<section class="zymarg-help-card">
				<h2><?php esc_html_e( 'Smart Dark Mode (Auto / Light / Dark)', 'zymarg-os' ); ?></h2>
				<p><?php esc_html_e( 'Set the colour scheme in Customize → ZYMARG OS → Colours → Color scheme:', 'zymarg-os' ); ?></p>
				<ul>
					<li><strong><?php esc_html_e( 'Light / Dark:', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'force one scheme site-wide — visitors CANNOT switch (the toggle button will not work in these modes).', 'zymarg-os' ); ?></li>
					<li><strong><?php esc_html_e( 'Auto:', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'follow each visitor\'s device preference (no switch).', 'zymarg-os' ); ?></li>
					<li><strong><?php esc_html_e( 'Smart switch:', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'the only mode where visitors can switch. It cycles Auto → Light → Dark, remembers their choice and applies it before first paint (no flash).', 'zymarg-os' ); ?></li>
				</ul>
				<p class="zymarg-help-callout"><strong><?php esc_html_e( 'Want dark by default but let visitors switch?', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'Choose "Smart switch" (NOT "Dark"), then set "Smart switch — default mode" to Dark. Picking "Dark" locks the site to dark and disables the toggle.', 'zymarg-os' ); ?></p>
				<p><?php esc_html_e( 'To let visitors choose: set the scheme to "Toggle / Smart switch", then place the button where they can reach it (e.g. a Shortcode widget in your Elementor header):', 'zymarg-os' ); ?></p>
				<?php
				zymarg_os_help_copy_row( '[zymarg_theme_toggle]', __( 'Icon switch — Auto / Light / Dark (remembers the choice)', 'zymarg-os' ) );
				zymarg_os_help_copy_row( '[zymarg_theme_toggle show_label="true"]', __( 'Icon + visible label (e.g. "Theme: Light")', 'zymarg-os' ) );
				zymarg_os_help_copy_row( '[zymarg_theme_toggle size="lg"]', __( 'Bigger button (sizes: sm / md / lg)', 'zymarg-os' ) );
				?>
				<p class="zymarg-help-desc"><?php esc_html_e( 'Options: size (sm / md / lg), show_label (true / false), label (custom accessible text), class (extra CSS class). The switch only loads its script in Toggle mode. Developers: use the semantic CSS variables --surface, --surface-2, --text-primary and --text-secondary; they flip automatically in dark mode.', 'zymarg-os' ); ?></p>
			</section>

			<!-- Block patterns -->
			<section class="zymarg-help-card">
				<h2><?php esc_html_e( 'Page Building (no shortcode)', 'zymarg-os' ); ?></h2>
				<p><?php esc_html_e( 'Build pages in the free block editor with ready-made ZYMARG sections:', 'zymarg-os' ); ?></p>
				<ol>
					<li><?php esc_html_e( 'Edit a page → click the + (top-left).', 'zymarg-os' ); ?></li>
					<li><?php esc_html_e( 'Open the "Patterns" tab → choose the "ZYMARG OS" category.', 'zymarg-os' ); ?></li>
					<li><?php esc_html_e( 'Insert a Hero, Feature Cards, Gradient CTA, Container (Row/Grid/Split/Section), and more.', 'zymarg-os' ); ?></li>
				</ol>
				<p><?php esc_html_e( 'For your own buttons/cards, pick a "ZYMARG" style from the block Styles panel.', 'zymarg-os' ); ?></p>
			</section>

			<!-- Content width & spacing -->
			<section class="zymarg-help-card">
				<h2><?php esc_html_e( 'Content width & spacing', 'zymarg-os' ); ?></h2>
				<p><?php esc_html_e( 'Control how wide your content is in Customize → ZYMARG OS → Spacing. The theme adds no top/bottom gap by default — create page spacing with your page builder.', 'zymarg-os' ); ?></p>
				<ul>
					<li><strong><?php esc_html_e( 'Content width mode:', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'Fixed = a constant pixel width. Fluid = a percentage of the screen that grows with the display but is capped for readability — ideal for ultra-wide and 4K/8K monitors.', 'zymarg-os' ); ?></li>
					<li><strong><?php esc_html_e( 'Fluid width (%):', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'in Fluid mode, the share of the screen the content fills (50–100%).', 'zymarg-os' ); ?></li>
					<li><strong><?php esc_html_e( 'Content max width (px):', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'the fixed width in Fixed mode, or the maximum cap in Fluid mode (up to 2560px) so long lines never hurt readability.', 'zymarg-os' ); ?></li>
				</ul>
				<p class="zymarg-help-desc"><?php esc_html_e( 'Tip: Fluid mode keeps text readable while letting the layout breathe on big screens. For edge-to-edge hero sections, use a full-width page template or your page builder.', 'zymarg-os' ); ?></p>
			</section>

			<!-- Per-page controls -->
			<section class="zymarg-help-card">
				<h2><?php esc_html_e( 'Per-page controls', 'zymarg-os' ); ?></h2>
				<p><?php esc_html_e( 'When editing any page, the "ZYMARG OS" box (right sidebar) lets you, just for that page:', 'zymarg-os' ); ?></p>
				<ul>
					<li><?php esc_html_e( 'Hide the page title', 'zymarg-os' ); ?></li>
				</ul>
				<p><?php esc_html_e( 'A global "Hide all page titles" toggle also lives in Customize → ZYMARG OS → Spacing.', 'zymarg-os' ); ?></p>
			</section>

			<!-- Smart UX -->
			<section class="zymarg-help-card">
				<h2><?php esc_html_e( 'Smart UX', 'zymarg-os' ); ?></h2>
				<p><?php esc_html_e( 'Two "wow" features — toggle them in Customize → ZYMARG OS → Modules.', 'zymarg-os' ); ?></p>
				<ul>
					<li><strong><?php esc_html_e( 'Instant Load:', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'pages preload on hover so clicks feel instant. Automatic — nothing to configure.', 'zymarg-os' ); ?></li>
					<li><strong><?php esc_html_e( 'Scroll Animations:', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'add the class "zymarg-reveal" to any block (Advanced → CSS class) to make it fade in on scroll. Variations: zymarg-reveal--left / --right / --zoom.', 'zymarg-os' ); ?></li>
				</ul>
				<p class="zymarg-help-desc"><?php esc_html_e( 'Also automatic: "Scroll to Top" adds a floating button that smoothly returns visitors to the top of the page. Toggle it in Customize → ZYMARG OS → Modules.', 'zymarg-os' ); ?></p>
			</section>

			<!-- Mega Menu -->
			<section class="zymarg-help-card">
				<h2><?php esc_html_e( 'Mega Menu (multi-column dropdowns)', 'zymarg-os' ); ?></h2>
				<p><?php esc_html_e( 'Turn any top-level menu item into a big, multi-column dropdown — great for shops with lots of categories. No coding; you just add a CSS class to the menu item.', 'zymarg-os' ); ?></p>
				<ol>
					<li><?php esc_html_e( 'Make sure the "Mega Menu" module is ON: Customize → ZYMARG OS → Modules.', 'zymarg-os' ); ?></li>
					<li><?php esc_html_e( 'Go to Appearance → Menus.', 'zymarg-os' ); ?></li>
					<li><?php esc_html_e( 'Click "Screen Options" (top-right) and tick "CSS Classes" — this reveals the box you need.', 'zymarg-os' ); ?></li>
					<li><?php esc_html_e( 'Open a top-level menu item and, in its "CSS Classes" box, add the class below.', 'zymarg-os' ); ?></li>
					<li><?php esc_html_e( 'Add child items beneath it — they arrange into the dropdown columns. Click "Save Menu".', 'zymarg-os' ); ?></li>
				</ol>
				<?php
				zymarg_os_help_copy_row( 'mega-menu', __( 'Makes that item a mega dropdown', 'zymarg-os' ) );
				zymarg_os_help_copy_row( 'mega-menu mega-cols-4', __( 'Mega dropdown with 4 columns (use 2–6)', 'zymarg-os' ) );
				?>
				<p class="zymarg-help-desc"><?php esc_html_e( 'Works with the theme menu and with menus your header plugin renders using the "zymarg-nav" class. It is keyboard- and touch-friendly automatically.', 'zymarg-os' ); ?></p>
			</section>

			<!-- WooCommerce shop features -->
			<section class="zymarg-help-card">
				<h2><?php esc_html_e( 'WooCommerce shop features', 'zymarg-os' ); ?></h2>
				<p><?php esc_html_e( 'These switch on automatically when WooCommerce is active and the "WooCommerce" module is ON (Customize → ZYMARG OS → Modules). Nothing to configure:', 'zymarg-os' ); ?></p>
				<ul>
					<li><strong><?php esc_html_e( 'Quick View:', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'a "Quick View" button appears on each product in the shop. Clicking it opens a popup with the product summary — no page reload.', 'zymarg-os' ); ?></li>
					<li><strong><?php esc_html_e( 'Off-canvas cart drawer:', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'the cart slides in from the side and updates its totals live as items are added.', 'zymarg-os' ); ?></li>
					<li><strong><?php esc_html_e( 'Gallery zoom + lightbox:', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'product images support hover zoom, a full-screen lightbox and a slider.', 'zymarg-os' ); ?></li>
					<li><strong><?php esc_html_e( 'Shop columns:', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'products show 3 per row by default and adapt on mobile.', 'zymarg-os' ); ?></li>
				</ul>
				<p class="zymarg-help-desc"><?php esc_html_e( 'Dokan multi-vendor stores are styled to match too. Turning the WooCommerce module off removes all of the above.', 'zymarg-os' ); ?></p>
			</section>

			<!-- Enhanced single product page -->
			<section class="zymarg-help-card">
				<h2><?php esc_html_e( 'Enhanced Single Product Page', 'zymarg-os' ); ?></h2>
				<p><?php esc_html_e( 'Your product pages get a modern, conversion-focused makeover automatically — including full support for variable products:', 'zymarg-os' ); ?></p>
				<ul>
					<li><strong><?php esc_html_e( 'Sticky gallery:', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'a large image with thumbnails, hover zoom and a full-screen lightbox that stays in view while you scroll the details.', 'zymarg-os' ); ?></li>
					<li><strong><?php esc_html_e( 'Variation swatches:', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'dropdowns for variable products become tap-friendly colour chips and button pills. The price, image and stock update live, and unavailable combinations are dimmed.', 'zymarg-os' ); ?></li>
					<li><strong><?php esc_html_e( 'Quantity stepper:', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'easy + / − buttons around the quantity field.', 'zymarg-os' ); ?></li>
					<li><strong><?php esc_html_e( 'Percentage sale badge:', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'on-sale products show how much is saved, e.g. -25%.', 'zymarg-os' ); ?></li>
					<li><strong><?php esc_html_e( 'Trust badges:', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'a reassurance row (secure checkout, shipping, returns, support) under the add-to-cart button.', 'zymarg-os' ); ?></li>
					<li><strong><?php esc_html_e( 'Styled tabs & related products:', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'the description / reviews tabs and related items match your theme colours.', 'zymarg-os' ); ?></li>
				</ul>
				<p class="zymarg-help-desc"><?php esc_html_e( 'Colour swatches recognise common colour names automatically; any name the browser does not know shows as a labelled pill instead. To turn the whole enhanced layout off (for example if you build product pages with a page builder), go to Customize → ZYMARG OS → Modules and untick "Enhanced single product page".', 'zymarg-os' ); ?></p>
			</section>

			<!-- Product Grid Skin -->
			<section class="zymarg-help-card">
				<h2><?php esc_html_e( 'Style your product grid (Grid Skin)', 'zymarg-os' ); ?></h2>
				<p><?php esc_html_e( 'If you display products with a page-builder widget or another plugin, you can apply the theme\'s clean grid styling by adding one CSS class to the grid wrapper.', 'zymarg-os' ); ?></p>
				<ul>
					<li><?php esc_html_e( 'Elementor: open the widget → Advanced → CSS Classes → add the class below.', 'zymarg-os' ); ?></li>
					<li><?php esc_html_e( 'HTML/shortcode: wrap your grid in a <div> that has the class below.', 'zymarg-os' ); ?></li>
				</ul>
				<?php zymarg_os_help_copy_row( 'zymarg-grid-skin', __( 'Adds the ZYMARG grid styling (3 columns by default)', 'zymarg-os' ) ); ?>
				<p class="zymarg-help-desc"><?php esc_html_e( 'Change the number of columns with the --zymarg-grid-skin-cols value (default 3).', 'zymarg-os' ); ?></p>
			</section>

			<!-- Site Mode -->			<section class="zymarg-help-card">
				<h2><?php esc_html_e( 'Go Live / Coming Soon', 'zymarg-os' ); ?></h2>
				<p><?php esc_html_e( 'Show a branded placeholder to visitors while you build. You always see the real site as an admin.', 'zymarg-os' ); ?></p>
				<ul>
					<li><?php esc_html_e( 'Customize → ZYMARG OS → Site Mode → choose Live, Coming Soon, or Maintenance.', 'zymarg-os' ); ?></li>
					<li><?php esc_html_e( 'Add a headline, message, social links and an optional launch-date countdown.', 'zymarg-os' ); ?></li>
					<li><?php esc_html_e( 'When it is on, the admin bar shows a reminder at the top.', 'zymarg-os' ); ?></li>
					<li><?php esc_html_e( 'Another plugin (e.g. WooCommerce) showing its own Coming Soon? Enable "Force the site live" to override it and go public — a dashboard notice confirms what is being overridden.', 'zymarg-os' ); ?></li>
				</ul>
			</section>

			<!-- SEO & Breadcrumbs -->
			<section class="zymarg-help-card">
				<h2><?php esc_html_e( 'SEO & Breadcrumbs', 'zymarg-os' ); ?></h2>
				<ul>
					<li><strong><?php esc_html_e( 'Schema:', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'Organization + search-box structured data is output automatically for rich results. It steps aside if Yoast/Rank Math/SEOPress/AIOSEO is active (to avoid duplicates).', 'zymarg-os' ); ?></li>
					<li><strong><?php esc_html_e( 'Breadcrumbs:', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'enable auto-display in Customize → ZYMARG OS → Spacing, or place it manually:', 'zymarg-os' ); ?></li>
				</ul>
				<?php zymarg_os_help_copy_row( '[zymarg_breadcrumbs]', __( 'Breadcrumb trail', 'zymarg-os' ) ); ?>
			</section>

			<!-- Design System Reference -->
			<section class="zymarg-help-card">
				<h2><?php esc_html_e( 'Design System — Full Control Reference', 'zymarg-os' ); ?></h2>
				<p><?php esc_html_e( 'Everything is in Appearance → Customize → ZYMARG OS. Below is what each setting controls so you always know where to go.', 'zymarg-os' ); ?></p>

				<h3><?php esc_html_e( 'Colours', 'zymarg-os' ); ?></h3>
				<table class="widefat striped zymarg-help-table">
					<thead><tr><th><?php esc_html_e( 'Setting', 'zymarg-os' ); ?></th><th><?php esc_html_e( 'What it changes', 'zymarg-os' ); ?></th></tr></thead>
					<tbody>
						<tr><td><?php esc_html_e( 'Primary', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'Main brand purple — buttons, links, accents, gradient start', 'zymarg-os' ); ?></td></tr>
						<tr><td><?php esc_html_e( 'Primary Container', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'Deeper magenta — hover states, gradient middle', 'zymarg-os' ); ?></td></tr>
						<tr><td><?php esc_html_e( 'Primary Inverse', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'Bright pink — gradient end, text on dark backgrounds', 'zymarg-os' ); ?></td></tr>
						<tr><td><?php esc_html_e( 'On Primary', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'Text colour ON primary buttons (usually white)', 'zymarg-os' ); ?></td></tr>
						<tr><td><?php esc_html_e( 'Heading colour', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'All H1–H6 headings', 'zymarg-os' ); ?></td></tr>
						<tr><td><?php esc_html_e( 'Body text', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'Paragraphs, lists, regular text', 'zymarg-os' ); ?></td></tr>
						<tr><td><?php esc_html_e( 'Muted text', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'Descriptions, helper text, meta info', 'zymarg-os' ); ?></td></tr>
						<tr><td><?php esc_html_e( 'Surface', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'Page background colour', 'zymarg-os' ); ?></td></tr>
						<tr><td><?php esc_html_e( 'Surface Container', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'Cards, sections, dropdown backgrounds', 'zymarg-os' ); ?></td></tr>
						<tr><td><?php esc_html_e( 'Borders / outline', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'Input borders, dividers, card outlines', 'zymarg-os' ); ?></td></tr>
						<tr><td><?php esc_html_e( 'Secondary', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'Secondary buttons, badges', 'zymarg-os' ); ?></td></tr>
					</tbody>
				</table>

				<h3><?php esc_html_e( 'Brand Gradient', 'zymarg-os' ); ?></h3>
				<table class="widefat striped zymarg-help-table">
					<thead><tr><th><?php esc_html_e( 'Setting', 'zymarg-os' ); ?></th><th><?php esc_html_e( 'What it changes', 'zymarg-os' ); ?></th></tr></thead>
					<tbody>
						<tr><td><?php esc_html_e( 'Gradient angle', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'Direction of the gradient (135° = diagonal). Used on primary buttons, headers, login card bar', 'zymarg-os' ); ?></td></tr>
						<tr><td><?php esc_html_e( 'Stop 1 / 2 / 3 (%)', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'Where each colour starts in the gradient. Default: 0% / 60% / 130%', 'zymarg-os' ); ?></td></tr>
					</tbody>
				</table>

				<h3><?php esc_html_e( 'Dark Mode Colours', 'zymarg-os' ); ?></h3>
				<p><?php esc_html_e( 'Only appears when Color scheme is Dark / Auto / Smart switch. Lets you pick different colours for dark mode — primary, heading, body, muted, surface, cards, borders.', 'zymarg-os' ); ?></p>

				<h3><?php esc_html_e( 'Typography', 'zymarg-os' ); ?></h3>
				<table class="widefat striped zymarg-help-table">
					<thead><tr><th><?php esc_html_e( 'Setting', 'zymarg-os' ); ?></th><th><?php esc_html_e( 'What it changes', 'zymarg-os' ); ?></th></tr></thead>
					<tbody>
						<tr><td><?php esc_html_e( 'Heading font (Google name)', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'Font used for all H1–H6. Type any Google Fonts name (e.g. Sora, Poppins, Montserrat)', 'zymarg-os' ); ?></td></tr>
						<tr><td><?php esc_html_e( 'Body font (Google name)', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'Font used for paragraphs, buttons, inputs. Type any Google Fonts name (e.g. Inter, Roboto)', 'zymarg-os' ); ?></td></tr>
						<tr><td><?php esc_html_e( 'Font loading', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'How fonts are delivered: Google CDN, Self-host (GDPR), Upload your own files, or System fonts', 'zymarg-os' ); ?></td></tr>
						<tr><td><?php esc_html_e( 'Base font size (px)', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'Global text size — everything scales from this (default 16px)', 'zymarg-os' ); ?></td></tr>
						<tr><td><?php esc_html_e( 'Body line height', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'Space between lines of body text (default 1.6)', 'zymarg-os' ); ?></td></tr>
						<tr><td><?php esc_html_e( 'Body text weight', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'Thickness of body text: Light (300), Regular (400), Medium (500), Semi-bold (600)', 'zymarg-os' ); ?></td></tr>
						<tr><td><?php esc_html_e( 'Heading weight', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'Thickness of headings: Regular to Extra-bold (400–800)', 'zymarg-os' ); ?></td></tr>
						<tr><td><?php esc_html_e( 'Heading line height', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'Space between lines in headings (default 1.2)', 'zymarg-os' ); ?></td></tr>
						<tr><td><?php esc_html_e( 'H1–H6 size (small screens)', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'The minimum heading size on mobile (rem). Combined with the large-screen size to create responsive fluid scaling', 'zymarg-os' ); ?></td></tr>
						<tr><td><?php esc_html_e( 'H1–H6 size (large screens)', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'The maximum heading size on desktop (rem). Leave both at default to keep the original responsive sizing', 'zymarg-os' ); ?></td></tr>
					</tbody>
				</table>

				<h3><?php esc_html_e( 'Spacing', 'zymarg-os' ); ?></h3>
				<table class="widefat striped zymarg-help-table">
					<thead><tr><th><?php esc_html_e( 'Setting', 'zymarg-os' ); ?></th><th><?php esc_html_e( 'What it changes', 'zymarg-os' ); ?></th></tr></thead>
					<tbody>
						<tr><td><?php esc_html_e( 'Content width mode', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'Fixed pixel width OR Fluid percentage (scales with screen)', 'zymarg-os' ); ?></td></tr>
						<tr><td><?php esc_html_e( 'Content max width (px)', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'The width of your main content area (default 1200px)', 'zymarg-os' ); ?></td></tr>
						<tr><td><?php esc_html_e( 'Spacing XS (rem)', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'Smallest gap — tight padding, inline spacing (default 0.5rem / 8px)', 'zymarg-os' ); ?></td></tr>
						<tr><td><?php esc_html_e( 'Spacing SM (rem)', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'Small gap — paragraph margin, card padding (default 1rem / 16px)', 'zymarg-os' ); ?></td></tr>
						<tr><td><?php esc_html_e( 'Spacing MD (rem)', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'Medium gap — section inner padding, form gaps (default 1.5rem / 24px)', 'zymarg-os' ); ?></td></tr>
						<tr><td><?php esc_html_e( 'Spacing LG (rem)', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'Large gap — section margins, before/after blocks (default 2.5rem / 40px)', 'zymarg-os' ); ?></td></tr>
						<tr><td><?php esc_html_e( 'Spacing XL (rem)', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'Extra large — page-level vertical rhythm (default 4rem / 64px)', 'zymarg-os' ); ?></td></tr>
					</tbody>
				</table>

				<h3><?php esc_html_e( 'Buttons & Cards', 'zymarg-os' ); ?></h3>
				<table class="widefat striped zymarg-help-table">
					<thead><tr><th><?php esc_html_e( 'Setting', 'zymarg-os' ); ?></th><th><?php esc_html_e( 'What it changes', 'zymarg-os' ); ?></th></tr></thead>
					<tbody>
						<tr><td><?php esc_html_e( 'Button corner radius (px)', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'Roundness of all buttons + form inputs (default 8px). Set to 0 for sharp, 50 for pill-shaped', 'zymarg-os' ); ?></td></tr>
						<tr><td><?php esc_html_e( 'Card corner radius (px)', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'Roundness of product cards, content cards, payment boxes (default 12px)', 'zymarg-os' ); ?></td></tr>
					</tbody>
				</table>

				<h3><?php esc_html_e( 'Brand Spark', 'zymarg-os' ); ?></h3>
				<table class="widefat striped zymarg-help-table">
					<thead><tr><th><?php esc_html_e( 'Setting', 'zymarg-os' ); ?></th><th><?php esc_html_e( 'What it changes', 'zymarg-os' ); ?></th></tr></thead>
					<tbody>
						<tr><td><?php esc_html_e( 'Spark purple', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'The purple shimmer colour of the animated Discovery Spark mark (default #6833EA)', 'zymarg-os' ); ?></td></tr>
						<tr><td><?php esc_html_e( 'Spark gold', 'zymarg-os' ); ?></td><td><?php esc_html_e( 'The gold accent colour of the Discovery Spark mark (default #FFD166)', 'zymarg-os' ); ?></td></tr>
					</tbody>
				</table>

				<p><a class="button button-primary" href="<?php echo esc_url( $customize_url ); ?>"><?php esc_html_e( 'Open the Customizer', 'zymarg-os' ); ?></a></p>
			</section>

			<!-- Site logo -->
			<section class="zymarg-help-card">
				<h2><?php esc_html_e( 'Site logo', 'zymarg-os' ); ?></h2>
				<p><?php esc_html_e( 'Set your logo in Customize → Site Identity → Logo. Then place it anywhere (e.g. a Shortcode element in your Elementor header) with:', 'zymarg-os' ); ?></p>
				<?php
				zymarg_os_help_copy_row( '[zymarg_logo]', __( 'Your logo, linked to the homepage', 'zymarg-os' ) );
				zymarg_os_help_copy_row( '[zymarg_logo size="48"]', __( 'Cap the logo height at 48px', 'zymarg-os' ) );
				zymarg_os_help_copy_row( '[zymarg_logo link="false"]', __( 'Show the logo without the homepage link', 'zymarg-os' ) );
				?>
				<p class="zymarg-help-desc"><?php esc_html_e( 'Options: size (max height in px), link (true / false), alt (custom alt text) and class. If no logo is set in Site Identity, it falls back to your site title.', 'zymarg-os' ); ?></p>
			</section>


			<!-- Product Reviews -->
			<section class="zymarg-help-card">
				<h2><?php esc_html_e( 'Product Reviews (ZYMARG Reviews Engine)', 'zymarg-os' ); ?></h2>
				<p><?php esc_html_e( 'A full review experience renders inside the product "Reviews" tab. This is provided by the ZYMARG Reviews Engine plugin, which must be active. Reviews are stored as native WooCommerce reviews, so they survive switching theme or plugin.', 'zymarg-os' ); ?></p>
				<ul>
					<li><strong><?php esc_html_e( 'Write a Review:', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'a button appears on My Account for completed orders still inside the review window (one setting, 15 days by default); it opens the product page with the form revealed. Only buyers of that product can write one.', 'zymarg-os' ); ?></li>
					<li><strong><?php esc_html_e( 'Photos:', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'shoppers can attach up to 4 files per review by default, configurable in the engine settings. Uploads are still bounded by your server’s upload_max_filesize and post_max_size.', 'zymarg-os' ); ?></li>
					<li><strong><?php esc_html_e( 'Summary, bars, filters, sort:', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'rating average + star breakdown, All/Media filters, and Most Recent / Highest / Lowest sorting.', 'zymarg-os' ); ?></li>
				</ul>
				<p class="zymarg-help-desc"><?php esc_html_e( 'Settings live under the top-level ZYMARG Reviews menu in wp-admin (review window, media limits, moderation, form visibility).', 'zymarg-os' ); ?></p>
			</section>

			<!-- Wishlist (delegated to your product-grid plugin) -->
			<section class="zymarg-help-card">
				<h2><?php esc_html_e( 'Wishlist (delegated to your plugin)', 'zymarg-os' ); ?></h2>
				<p><?php esc_html_e( 'The theme\'s built-in wishlist module was removed in v5.7.6 to keep ZYMARG OS lightweight. The My Account → Wishlist tab is now powered by your product-grid plugin (e.g. ZYMARG WC Product Grid v1.4.6+).', 'zymarg-os' ); ?></p>
				<ol>
					<li><?php esc_html_e( 'Make sure your wishlist-providing plugin is active.', 'zymarg-os' ); ?></li>
					<li><?php esc_html_e( 'Go to Customize → ZYMARG OS → Wishlist Integration.', 'zymarg-os' ); ?></li>
					<li><?php esc_html_e( 'Paste the plugin\'s shortcode name (without brackets) — defaults to zymarg_wcpg_wishlist for the ZYMARG WC Product Grid plugin.', 'zymarg-os' ); ?></li>
				</ol>
				<p class="zymarg-help-desc"><?php esc_html_e( 'Developers: hook the `zymarg_os_account_wishlist_content` filter and return HTML to override the shortcode-based wiring.', 'zymarg-os' ); ?></p>
			</section>

			<!-- Wishlist + Recently Viewed shortcodes (from ZYMARG WC Product Grid) -->
			<section class="zymarg-help-card">
				<h2><?php esc_html_e( 'Wishlist & Recently Viewed shortcodes', 'zymarg-os' ); ?></h2>
				<p>
					<?php esc_html_e( 'The ZYMARG WC Product Grid plugin (v1.5.2+) ships two shortcodes that render product grids using the SAME card template as your homepage, search results and category pages — so the cards match your store design everywhere.', 'zymarg-os' ); ?>
				</p>
				<p class="zymarg-help-desc">
					<?php esc_html_e( 'You don\'t need to add them manually to the My Account page — the theme wires them in automatically when the plugin is active. Use the shortcodes below when you want to drop the same grids into a different page (empty-cart, 404, thank-you, footer, popup, etc.).', 'zymarg-os' ); ?>
				</p>

				<h3><?php esc_html_e( 'Recently Viewed', 'zymarg-os' ); ?></h3>
				<p><?php esc_html_e( 'Renders the current visitor\'s recently viewed products. Logged-in customers see the same list across all their devices; guests get a cookie-based list that merges into their account on sign-in.', 'zymarg-os' ); ?></p>
				<?php zymarg_os_help_copy_row( '[zymarg_wcpg_recently_viewed]', __( 'Default — 4 columns, up to 20 items', 'zymarg-os' ) ); ?>
				<?php zymarg_os_help_copy_row( '[zymarg_wcpg_recently_viewed columns="3" limit="12"]', __( 'Custom column count and item limit', 'zymarg-os' ) ); ?>
				<?php zymarg_os_help_copy_row( '[zymarg_wcpg_recently_viewed empty_message="Start browsing to see your history here."]', __( 'Custom empty-state message', 'zymarg-os' ) ); ?>
				<ul>
					<li><strong>columns</strong> — <?php esc_html_e( '1 to 6 (default 4).', 'zymarg-os' ); ?></li>
					<li><strong>limit</strong> — <?php esc_html_e( '1 to 20 (default 20).', 'zymarg-os' ); ?></li>
					<li><strong>empty_message</strong> — <?php esc_html_e( 'Override the default empty-state text.', 'zymarg-os' ); ?></li>
				</ul>

				<h3><?php esc_html_e( 'Wishlist', 'zymarg-os' ); ?></h3>
				<p><?php esc_html_e( 'Renders the current visitor\'s saved (heart-tagged) products. Auth-aware: logged-in lists persist in user meta; guest lists ride a 1-year cookie that merges on sign-in.', 'zymarg-os' ); ?></p>
				<?php zymarg_os_help_copy_row( '[zymarg_wcpg_wishlist]', __( 'Default — 3 columns', 'zymarg-os' ) ); ?>
				<?php zymarg_os_help_copy_row( '[zymarg_wcpg_wishlist columns="4"]', __( 'Custom column count', 'zymarg-os' ) ); ?>
				<?php zymarg_os_help_copy_row( '[zymarg_wcpg_wishlist empty_message="Save something you love to find it here."]', __( 'Custom empty-state message', 'zymarg-os' ) ); ?>
				<ul>
					<li><strong>columns</strong> — <?php esc_html_e( '1 to 6 (default 3).', 'zymarg-os' ); ?></li>
					<li><strong>empty_message</strong> — <?php esc_html_e( 'Override the default empty-state text.', 'zymarg-os' ); ?></li>
				</ul>

				<h3><?php esc_html_e( 'Useful places to drop them', 'zymarg-os' ); ?></h3>
				<ul>
					<li><?php esc_html_e( 'Empty cart page — keep shoppers engaged when their cart clears.', 'zymarg-os' ); ?></li>
					<li><?php esc_html_e( 'Order confirmation / "Thank you" page — drive the next purchase while the card is still warm.', 'zymarg-os' ); ?></li>
					<li><?php esc_html_e( '404 page — turn a dead end into a soft landing.', 'zymarg-os' ); ?></li>
					<li><?php esc_html_e( 'Single product page — a "You recently viewed" row below related/upsells.', 'zymarg-os' ); ?></li>
					<li><?php esc_html_e( 'Footer or sidebar — persistent re-engagement.', 'zymarg-os' ); ?></li>
				</ul>
				<p class="zymarg-help-desc">
					<?php esc_html_e( 'Developer note: card features (badges, vendor row, price position, sold count, etc.) can be customised per-shortcode via the filters `zymarg_wcpg_recently_viewed_card_settings` and `zymarg_wcpg_wishlist_card_settings`.', 'zymarg-os' ); ?>
				</p>
			</section>

			<!-- My Account header icon -->
			<section class="zymarg-help-card">
				<h2><?php esc_html_e( 'My Account header icon', 'zymarg-os' ); ?></h2>
				<p>
					<?php
					printf(
						/* translators: %s: link to the Customizer section. */
						esc_html__( 'Add a customizable account icon to your header in %s.', 'zymarg-os' ),
						'<a href="' . esc_url( add_query_arg( 'autofocus[section]', 'zymarg_os_account_icon_section', $customize_url ) ) . '">' . esc_html__( 'Customize → ZYMARG OS → Account Icon', 'zymarg-os' ) . '</a>'
					);
					?>
				</p>
				<ul>
					<li><?php esc_html_e( 'Pick from 7 built-in icons or upload your own image (PNG / SVG / JPG).', 'zymarg-os' ); ?></li>
					<li><?php esc_html_e( 'Choose a background shape (none / circle / rounded / square), plus background, hover and icon colours and a size.', 'zymarg-os' ); ?></li>
					<li><?php esc_html_e( 'It auto-links to the My Account page; set a custom link and an optional label if you prefer.', 'zymarg-os' ); ?></li>
				</ul>
				<p class="zymarg-help-desc"><?php esc_html_e( 'It appears in the theme header menu when enabled, and can be placed anywhere (including plugin / page-builder headers) with the shortcode:', 'zymarg-os' ); ?></p>
				<?php zymarg_os_help_copy_row( '[zymarg_account_icon]', __( 'The customizable My Account icon', 'zymarg-os' ) ); ?>
			</section>

			<!-- My Account page (custom dashboard) -->
			<section class="zymarg-help-card">
				<h2><?php esc_html_e( 'My Account page (custom dashboard)', 'zymarg-os' ); ?></h2>
				<p><?php esc_html_e( 'The WooCommerce My Account page uses a custom app-like dashboard: a sidebar with Dashboard, Orders, Wishlist, Recently Viewed, Addresses, Profile, Notifications, Reviews, Vouchers, Returns, Support, Preferences and Security.', 'zymarg-os' ); ?></p>

				<h3><?php esc_html_e( 'Setting the Support / Help / Track links', 'zymarg-os' ); ?></h3>
				<p>
					<?php
					printf(
						/* translators: %s: link to the Customizer section. */
						esc_html__( 'Open %s and set three URLs:', 'zymarg-os' ),
						'<a href="' . esc_url( add_query_arg( 'autofocus[section]', 'zymarg_account_links', $customize_url ) ) . '">' . esc_html__( 'Customize → My Account — Links', 'zymarg-os' ) . '</a>'
					);
					?>
				</p>
				<ul>
					<li><strong><?php esc_html_e( 'Contact / Support URL', 'zymarg-os' ); ?></strong> — <?php esc_html_e( 'used by the “Contact Support” card in the Support section.', 'zymarg-os' ); ?></li>
					<li><strong><?php esc_html_e( 'Help Center URL', 'zymarg-os' ); ?></strong> — <?php esc_html_e( 'used by the “Help Center” card.', 'zymarg-os' ); ?></li>
					<li><strong><?php esc_html_e( 'Track Order URL', 'zymarg-os' ); ?></strong> — <?php esc_html_e( 'optional. The “Track Order” quick action links here (e.g. your courier’s tracking page). Leave blank to send customers to their Orders list.', 'zymarg-os' ); ?></li>
				</ul>

				<h3><?php esc_html_e( 'Orders “Shipped” tab & courier tracking (RedX, Steadfast, Pathao)', 'zymarg-os' ); ?></h3>
				<p><?php esc_html_e( 'WooCommerce has no native “shipped” status. Install your courier’s plugin (RedX / Steadfast / Pathao / Dokan shipment tracking) — when it marks an order as shipped, that order appears under the Shipped tab. If your courier plugin uses a custom order status, point the theme at it with this filter in a child theme or snippet:', 'zymarg-os' ); ?></p>
				<?php zymarg_os_help_copy_row( "add_filter( 'zymarg_os_shipped_statuses', function( \$s ){ return array( 'wc-your-status' ); } );", __( 'Map the Shipped tab to your courier’s status', 'zymarg-os' ) ); ?>

				<h3><?php esc_html_e( 'Promotional / newsletter email preference', 'zymarg-os' ); ?></h3>
				<p><?php esc_html_e( 'Customers can toggle Promotional Emails and Newsletter under Notifications & Preferences. Transactional order emails always send (customers need them). For marketing email, your newsletter integration should respect the customer’s choice by checking:', 'zymarg-os' ); ?></p>
				<?php zymarg_os_help_copy_row( 'zymarg_os_user_allows_marketing( $user_id )', __( 'Returns true only if the customer opted in to marketing email', 'zymarg-os' ) ); ?>
			</section>

			<!-- Login -->
			<section class="zymarg-help-card">
				<h2><?php esc_html_e( 'Login (branded screen, card & pop-up)', 'zymarg-os' ); ?></h2>
				<p>
					<?php
					printf(
						/* translators: %s: link to the Customizer section. */
						esc_html__( 'Three login features, all under %s.', 'zymarg-os' ),
						'<a href="' . esc_url( add_query_arg( 'autofocus[section]', 'zymarg_os_login_section', $customize_url ) ) . '">' . esc_html__( 'Customize → ZYMARG OS → Login', 'zymarg-os' ) . '</a>'
					);
					?>
				</p>

				<h3><?php esc_html_e( '1) Branded WordPress login screen (wp-login.php)', 'zymarg-os' ); ?></h3>
				<p><?php esc_html_e( 'The admin login screen gets your logo, brand background, accent colour, the signature ZYMARG gradient bar and orb glow. Set the background, accent and a custom logo (defaults to your site logo).', 'zymarg-os' ); ?></p>

				<h3><?php esc_html_e( '2) Front-end login card (shortcode)', 'zymarg-os' ); ?></h3>
				<p><?php esc_html_e( 'Drop a branded login card onto any page. Features Password/OTP tabs, Google sign-in, and "Become a Vendor" CTA:', 'zymarg-os' ); ?></p>
				<?php
				zymarg_os_help_copy_row( '[zymarg_login]', __( 'The branded login card (Password/OTP tabs + Google)', 'zymarg-os' ) );
				zymarg_os_help_copy_row( '[zymarg_login_button label="Sign in"]', __( 'A button that opens the login pop-up', 'zymarg-os' ) );
				?>

				<h3><?php esc_html_e( '3) Login Pop-up (auto for guests)', 'zymarg-os' ); ?></h3>
				<p><?php esc_html_e( 'An elegant modal that auto-opens for logged-out (guest) visitors. Never shows to logged-in users. Enabled by default with a 2-second delay.', 'zymarg-os' ); ?></p>

				<h4><?php esc_html_e( 'How it works:', 'zymarg-os' ); ?></h4>
				<ul>
					<li><?php esc_html_e( 'If the user is already logged in → the pop-up NEVER appears.', 'zymarg-os' ); ?></li>
					<li><?php esc_html_e( 'If the user is not logged in (guest) → the pop-up opens automatically after the configured delay (default: 2 seconds).', 'zymarg-os' ); ?></li>
					<li><?php esc_html_e( 'A close button (✕) is on the top-right corner. Clicking outside or pressing ESC also closes it.', 'zymarg-os' ); ?></li>
				</ul>

				<h4><?php esc_html_e( 'Customizer settings (Customize → ZYMARG OS → Login):', 'zymarg-os' ); ?></h4>
				<table class="zymarg-help-table" style="width:100%;border-collapse:collapse;font-size:13px;margin:12px 0;">
					<thead>
						<tr><th style="text-align:left;padding:8px;border-bottom:2px solid #d6c0d2;"><?php esc_html_e( 'Setting', 'zymarg-os' ); ?></th><th style="text-align:left;padding:8px;border-bottom:2px solid #d6c0d2;"><?php esc_html_e( 'Options', 'zymarg-os' ); ?></th><th style="text-align:left;padding:8px;border-bottom:2px solid #d6c0d2;"><?php esc_html_e( 'Default', 'zymarg-os' ); ?></th></tr>
					</thead>
					<tbody>
						<tr><td style="padding:6px 8px;border-bottom:1px solid #eee;"><strong><?php esc_html_e( 'Enable pop-up', 'zymarg-os' ); ?></strong></td><td style="padding:6px 8px;border-bottom:1px solid #eee;"><?php esc_html_e( 'Toggle on/off', 'zymarg-os' ); ?></td><td style="padding:6px 8px;border-bottom:1px solid #eee;"><?php esc_html_e( 'On', 'zymarg-os' ); ?></td></tr>
						<tr><td style="padding:6px 8px;border-bottom:1px solid #eee;"><strong><?php esc_html_e( 'Frequency', 'zymarg-os' ); ?></strong></td><td style="padding:6px 8px;border-bottom:1px solid #eee;"><?php esc_html_e( 'Once per visitor / Once per session / Once every X days / Every visit', 'zymarg-os' ); ?></td><td style="padding:6px 8px;border-bottom:1px solid #eee;"><?php esc_html_e( 'Once per visitor', 'zymarg-os' ); ?></td></tr>
						<tr><td style="padding:6px 8px;border-bottom:1px solid #eee;"><strong><?php esc_html_e( 'Delay (ms)', 'zymarg-os' ); ?></strong></td><td style="padding:6px 8px;border-bottom:1px solid #eee;"><?php esc_html_e( '0 – 15000 milliseconds', 'zymarg-os' ); ?></td><td style="padding:6px 8px;border-bottom:1px solid #eee;"><?php esc_html_e( '2000 (2 seconds)', 'zymarg-os' ); ?></td></tr>
						<tr><td style="padding:6px 8px;border-bottom:1px solid #eee;"><strong><?php esc_html_e( 'Days between showings', 'zymarg-os' ); ?></strong></td><td style="padding:6px 8px;border-bottom:1px solid #eee;"><?php esc_html_e( '1 – 365 days (only when frequency = "Once every X days")', 'zymarg-os' ); ?></td><td style="padding:6px 8px;border-bottom:1px solid #eee;"><?php esc_html_e( '7', 'zymarg-os' ); ?></td></tr>
						<tr><td style="padding:6px 8px;border-bottom:1px solid #eee;"><strong><?php esc_html_e( 'Show on', 'zymarg-os' ); ?></strong></td><td style="padding:6px 8px;border-bottom:1px solid #eee;"><?php esc_html_e( 'Entire site / Only specific pages / All pages except…', 'zymarg-os' ); ?></td><td style="padding:6px 8px;border-bottom:1px solid #eee;"><?php esc_html_e( 'Entire site', 'zymarg-os' ); ?></td></tr>
						<tr><td style="padding:6px 8px;border-bottom:1px solid #eee;"><strong><?php esc_html_e( 'Page IDs', 'zymarg-os' ); ?></strong></td><td style="padding:6px 8px;border-bottom:1px solid #eee;"><?php esc_html_e( 'Comma-separated page IDs (e.g. 12, 45, 89)', 'zymarg-os' ); ?></td><td style="padding:6px 8px;border-bottom:1px solid #eee;"><?php esc_html_e( 'Empty (all pages)', 'zymarg-os' ); ?></td></tr>
						<tr><td style="padding:6px 8px;"><strong><?php esc_html_e( 'Account icon trigger', 'zymarg-os' ); ?></strong></td><td style="padding:6px 8px;"><?php esc_html_e( 'Header account icon also opens the pop-up', 'zymarg-os' ); ?></td><td style="padding:6px 8px;"><?php esc_html_e( 'On', 'zymarg-os' ); ?></td></tr>
					</tbody>
				</table>

				<p class="zymarg-help-callout"><strong><?php esc_html_e( 'Tip:', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'Exclude your checkout and cart pages from the pop-up so it never interrupts a purchase. Use "All pages except…" and enter those page IDs.', 'zymarg-os' ); ?></p>

				<h4><?php esc_html_e( 'Per-page delay overrides:', 'zymarg-os' ); ?></h4>
				<p>
					<?php
					printf(
						/* translators: %s: link to the Login Customizer section */
						esc_html__( 'Need different delays for different pages? Go to %s and scroll to the "Select pages" and "Per-page popup delays" sections.', 'zymarg-os' ),
						'<a href="' . esc_url( add_query_arg( 'autofocus[section]', 'zymarg_os_login_section', $customize_url ) ) . '"><strong>' . esc_html__( 'Customize → ZYMARG OS → Login', 'zymarg-os' ) . '</strong></a>'
					);
					?>
				</p>
				<ul>
					<li><?php esc_html_e( 'Pick a page from a dropdown (no need to find page IDs)', 'zymarg-os' ); ?></li>
					<li><?php esc_html_e( 'Set the delay in milliseconds (live preview shows the seconds)', 'zymarg-os' ); ?></li>
					<li><?php esc_html_e( 'Add as many pages as you want — each with its own delay', 'zymarg-os' ); ?></li>
					<li><?php esc_html_e( 'General site delay and My Account delay are also editable on the same page', 'zymarg-os' ); ?></li>
				</ul>
				<p class="zymarg-help-callout"><strong><?php esc_html_e( 'Priority:', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'Per-page delay > My Account delay > General site delay.', 'zymarg-os' ); ?></p>

				<h4><?php esc_html_e( 'My Account page (separate trigger):', 'zymarg-os' ); ?></h4>
				<p><?php esc_html_e( 'When a logged-out user visits /my-account/, the popup opens INSTANTLY (0ms delay by default) — because they navigated to that page specifically to log in. This is a separate setting from the general site popup delay.', 'zymarg-os' ); ?></p>
				<table class="zymarg-help-table" style="width:100%;border-collapse:collapse;font-size:13px;margin:12px 0;">
					<thead>
						<tr><th style="text-align:left;padding:8px;border-bottom:2px solid #d6c0d2;"><?php esc_html_e( 'Setting', 'zymarg-os' ); ?></th><th style="text-align:left;padding:8px;border-bottom:2px solid #d6c0d2;"><?php esc_html_e( 'Description', 'zymarg-os' ); ?></th><th style="text-align:left;padding:8px;border-bottom:2px solid #d6c0d2;"><?php esc_html_e( 'Default', 'zymarg-os' ); ?></th></tr>
					</thead>
					<tbody>
						<tr><td style="padding:6px 8px;border-bottom:1px solid #eee;"><strong><?php esc_html_e( 'My Account popup delay', 'zymarg-os' ); ?></strong></td><td style="padding:6px 8px;border-bottom:1px solid #eee;"><?php esc_html_e( '0–5000 ms. How fast the popup opens on /my-account/. 0 = instant.', 'zymarg-os' ); ?></td><td style="padding:6px 8px;border-bottom:1px solid #eee;"><?php esc_html_e( '0 (instant)', 'zymarg-os' ); ?></td></tr>
						<tr><td style="padding:6px 8px;"><strong><?php esc_html_e( 'My Account placeholder text', 'zymarg-os' ); ?></strong></td><td style="padding:6px 8px;"><?php esc_html_e( 'Text shown behind the popup on /my-account/ for logged-out users.', 'zymarg-os' ); ?></td><td style="padding:6px 8px;"><?php esc_html_e( '"Please sign in to access your account."', 'zymarg-os' ); ?></td></tr>
					</tbody>
				</table>

				<h4><?php esc_html_e( 'Closing the pop-up:', 'zymarg-os' ); ?></h4>
				<ul>
					<li><?php esc_html_e( 'Click the ✕ button (top-right corner)', 'zymarg-os' ); ?></li>
					<li><?php esc_html_e( 'Press the ESC key', 'zymarg-os' ); ?></li>
					<li><?php esc_html_e( 'Click the dark overlay behind the card', 'zymarg-os' ); ?></li>
				</ul>

				<h4><?php esc_html_e( 'Additional features:', 'zymarg-os' ); ?></h4>
				<ul>
					<li><strong><?php esc_html_e( 'Password / OTP tabs:', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'Visitors can log in via password or request a one-time password (OTP).', 'zymarg-os' ); ?></li>
					<li><strong><?php esc_html_e( 'Google sign-in:', 'zymarg-os' ); ?></strong> <?php esc_html_e( '"Continue with Google" button. Auto-wires to Nextend Social Login or miniOrange Google plugin (see setup instructions below).', 'zymarg-os' ); ?></li>
					<li><strong><?php esc_html_e( 'Vendor CTA:', 'zymarg-os' ); ?></strong> <?php esc_html_e( '"Become a Vendor →" link in the footer (URL configurable in Customizer).', 'zymarg-os' ); ?></li>
					<li><strong><?php esc_html_e( 'Per-device sizes:', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'Set independent width and max-height for desktop, tablet and mobile. Optional full-screen on mobile.', 'zymarg-os' ); ?></li>
				</ul>

				<h4 style="margin-top:24px;">🔑 <?php esc_html_e( 'Setting up Google login', 'zymarg-os' ); ?></h4>
				<p><?php esc_html_e( 'The "Continue with Google" button needs a social-login plugin. The theme auto-detects two popular plugins — no extra config needed:', 'zymarg-os' ); ?></p>
				<ol style="margin-left:20px;">
					<li>
						<strong><?php esc_html_e( 'Install a social-login plugin:', 'zymarg-os' ); ?></strong><br>
						<?php
						printf(
							/* translators: 1: Nextend plugin link, 2: miniOrange plugin link */
							esc_html__( 'Recommended: %1$s (most popular) or %2$s.', 'zymarg-os' ),
							'<a href="' . esc_url( admin_url( 'plugin-install.php?s=nextend+social+login&tab=search&type=term' ) ) . '"><strong>Nextend Social Login</strong></a>',
							'<a href="' . esc_url( admin_url( 'plugin-install.php?s=login+with+google+miniorange&tab=search&type=term' ) ) . '">miniOrange Login with Google</a>'
						);
						?>
					</li>
					<li>
						<strong><?php esc_html_e( 'Get Google OAuth credentials:', 'zymarg-os' ); ?></strong><br>
						<?php
						printf(
							/* translators: %s: Google Cloud Console link */
							esc_html__( 'Go to %s → Create a project → APIs & Services → Credentials → Create OAuth 2.0 Client ID. Set application type to "Web application".', 'zymarg-os' ),
							'<a href="https://console.cloud.google.com/" target="_blank" rel="noopener noreferrer">Google Cloud Console</a>'
						);
						?>
					</li>
					<li>
						<strong><?php esc_html_e( 'Configure the plugin:', 'zymarg-os' ); ?></strong><br>
						<?php esc_html_e( 'Paste the Google redirect URI (shown by your plugin) into Google Cloud Console. Then paste the Client ID + Secret back into the plugin and enable Google.', 'zymarg-os' ); ?>
					</li>
					<li>
						<strong><?php esc_html_e( 'Done — the theme wires it automatically:', 'zymarg-os' ); ?></strong><br>
						<?php esc_html_e( 'The "Continue with Google" button on the branded login screen will start working immediately. No manual integration needed.', 'zymarg-os' ); ?>
					</li>
				</ol>
				<p class="zymarg-help-callout"><strong><?php esc_html_e( 'Using a different plugin or custom OAuth?', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'Paste your Google login URL into Customize → ZYMARG OS → Login → "Google login URL (manual override)".', 'zymarg-os' ); ?></p>
			</section>

			<!-- Import / Export -->
			<section class="zymarg-help-card">
				<h2><?php esc_html_e( 'Import / Export & Store Snapshot', 'zymarg-os' ); ?></h2>
				<p><?php esc_html_e( 'A migration hub at ZYMARG OS → Import / Export. Everything is created as native WooCommerce data.', 'zymarg-os' ); ?></p>
				<ul>
					<li><strong><?php esc_html_e( 'Import:', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'one-click demo content, or bulk product / category CSV import with a live progress bar (handles variable products + variations).', 'zymarg-os' ); ?></li>
					<li><strong><?php esc_html_e( 'Export:', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'products (with category/status filters) and categories to CSV, batched with progress.', 'zymarg-os' ); ?></li>
					<li><strong><?php esc_html_e( 'Store Snapshot:', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'download one ZIP (products + categories + manifest) and Restore it on another ZYMARG OS site.', 'zymarg-os' ); ?></li>
				</ul>
			</section>

			<!-- Lazy Images -->
			<section class="zymarg-help-card">
				<h2><?php esc_html_e( 'Lazy Images', 'zymarg-os' ); ?></h2>
				<p><?php esc_html_e( 'Toggle in Customize → ZYMARG OS → Modules → Lazy Images (on by default).', 'zymarg-os' ); ?></p>
				<ul>
					<li><strong><?php esc_html_e( 'On:', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'images and iframes load lazily with async decoding for faster pages. The first/above-the-fold image is left to WordPress so your Largest Contentful Paint is not hurt.', 'zymarg-os' ); ?></li>
					<li><strong><?php esc_html_e( 'Off:', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'lazy loading is disabled site-wide and every image loads immediately.', 'zymarg-os' ); ?></li>
				</ul>
				<p class="zymarg-help-desc"><?php esc_html_e( 'Add the class "skip-lazy" (or "no-lazy") to any image/iframe to opt it out.', 'zymarg-os' ); ?></p>
			</section>

			<!-- SVG Uploads -->
			<section class="zymarg-help-card">
				<h2><?php esc_html_e( 'SVG Uploads (secure)', 'zymarg-os' ); ?></h2>
				<p><?php esc_html_e( 'WordPress blocks SVG uploads by default because an SVG can contain scripts. This theme lets you upload them safely. Toggle it in Customize → ZYMARG OS → Modules → SVG Uploads (on by default).', 'zymarg-os' ); ?></p>
				<ul>
					<li><strong><?php esc_html_e( 'Admins only:', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'only users who can manage the site may upload SVGs.', 'zymarg-os' ); ?></li>
					<li><strong><?php esc_html_e( 'Auto-sanitized:', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'every uploaded SVG is cleaned before it is saved — scripts, event handlers (onclick/onload), foreignObject/iframe/embed, javascript: links and DOCTYPE/ENTITY (XXE) are stripped or rejected.', 'zymarg-os' ); ?></li>
					<li><strong><?php esc_html_e( 'Displays properly:', 'zymarg-os' ); ?></strong> <?php esc_html_e( 'SVGs preview correctly in the Media Library and in image pickers (e.g. the Account Icon and login logo).', 'zymarg-os' ); ?></li>
				</ul>
				<p class="zymarg-help-desc"><?php esc_html_e( 'Developers: change who can upload with the zymarg_os_svg_upload_cap filter. For ultra-high-security sites a dedicated plugin like Safe SVG remains an option; this covers the common XSS vectors and restricts uploads to admins.', 'zymarg-os' ); ?></p>
			</section>

			<!-- Toasts -->
			<section class="zymarg-help-card">
				<h2><?php esc_html_e( 'Toast Notifications', 'zymarg-os' ); ?></h2>
				<p><?php esc_html_e( 'A single, brand-styled notification system used across the theme — add to cart, wishlist, login, review submitted. It adapts to dark mode automatically.', 'zymarg-os' ); ?></p>
				<p class="zymarg-help-desc"><?php esc_html_e( 'For developers — trigger a toast from anywhere:', 'zymarg-os' ); ?></p>
				<?php
				zymarg_os_help_copy_row( "ZymargToast.success('Saved!')", __( 'JS: success / error / info / warning', 'zymarg-os' ) );
				zymarg_os_help_copy_row( 'zymarg_os_queue_toast( $message, $type );', __( 'PHP: show on the next page load', 'zymarg-os' ) );
				?>
				<p class="zymarg-help-desc"><?php esc_html_e( 'Position and duration are filterable (zymarg_os_toast_position, zymarg_os_toast_duration).', 'zymarg-os' ); ?></p>
			</section>

		</div>
	</div>

	<style>
		.zymarg-help h1 { display:flex; align-items:center; gap:10px; }
		.zymarg-help-version { font-size:12px; font-weight:600; color:#fff; background:#9500a5; border-radius:999px; padding:2px 10px; }
		.zymarg-help-intro { font-size:14px; color:#534152; max-width:720px; }
		.zymarg-help-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(340px,1fr)); gap:20px; margin-top:16px; }
		.zymarg-help-card { background:#fff; border:1px solid #d8bfd3; border-radius:12px; padding:20px 22px; box-shadow:0 8px 30px rgba(53,0,61,.06); }
		.zymarg-help-card h2 { margin-top:0; color:#36003d; }
		.zymarg-help-card h3 { color:#36003d; margin:18px 0 8px; }
		.zymarg-help-preview { display:flex; align-items:center; gap:18px; padding:18px; background:#faf8ff; border-radius:10px; margin:8px 0 4px; }
		.zymarg-help-row { display:flex; align-items:center; gap:10px; flex-wrap:wrap; margin:8px 0; }
		.zymarg-help-code { background:#211b28; color:#ffd6fb; padding:6px 10px; border-radius:6px; font-size:13px; }
		.zymarg-help-desc { color:#534152; font-size:13px; }
		.zymarg-help-callout { background:#faf2fb; border:1px solid #e7c9e6; border-left:4px solid #9500a5; border-radius:8px; padding:10px 12px; color:#43113f; font-size:13px; }
		.zymarg-copy.is-copied { background:#9500a5; color:#fff; border-color:#9500a5; }
		.zymarg-help-table { max-width:520px; margin-top:6px; }
		.zymarg-help-table code { background:#eaedff; padding:2px 6px; border-radius:4px; }
	</style>
	<script>
	( function () {
		document.querySelectorAll( '.zymarg-copy' ).forEach( function ( btn ) {
			btn.addEventListener( 'click', function () {
				var text = btn.getAttribute( 'data-clip' );
				var done = function () {
					var original = btn.textContent;
					btn.textContent = '<?php echo esc_js( __( 'Copied!', 'zymarg-os' ) ); ?>';
					btn.classList.add( 'is-copied' );
					setTimeout( function () { btn.textContent = original; btn.classList.remove( 'is-copied' ); }, 1500 );
				};
				if ( navigator.clipboard && navigator.clipboard.writeText ) {
					navigator.clipboard.writeText( text ).then( done, function () { window.prompt( '<?php echo esc_js( __( 'Copy this:', 'zymarg-os' ) ); ?>', text ); } );
				} else {
					window.prompt( '<?php echo esc_js( __( 'Copy this:', 'zymarg-os' ) ); ?>', text );
				}
			} );
		} );
	}() );
	</script>
	<?php
}
