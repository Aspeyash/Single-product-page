<?php
/**
 * Dark / Light theme system.
 *
 * Adds a colour-scheme mode (Customize -> ZYMARG OS -> Colours -> Color scheme):
 *   light  — always light (default)
 *   dark   — always dark
 *   auto   — follow the visitor's operating-system preference
 *   toggle — start from system, and show a switch so visitors can choose
 *            (their choice is remembered in localStorage)
 *
 * The scheme is applied via a data-theme attribute on <html>; the dark token
 * overrides live in tokens/dark.css.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Get the configured colour scheme.
 *
 * @return string light|dark|auto|toggle
 */
function zymarg_os_color_scheme() {
	$scheme  = get_theme_mod( 'zymarg_color_scheme', 'light' );
	$allowed = array( 'light', 'dark', 'auto', 'toggle' );

	if ( ! in_array( $scheme, $allowed, true ) ) {
		$scheme = 'light';
	}

	return (string) apply_filters( 'zymarg_os_color_scheme', $scheme );
}

/**
 * The default starting mode for "Smart switch" (before a visitor chooses).
 *
 * @return string auto|light|dark
 */
function zymarg_os_color_scheme_default() {
	$default = get_theme_mod( 'zymarg_color_scheme_default', 'auto' );
	if ( ! in_array( $default, array( 'auto', 'light', 'dark' ), true ) ) {
		$default = 'auto';
	}
	return (string) apply_filters( 'zymarg_os_color_scheme_default', $default );
}

/**
 * Sanitize the Smart-switch default mode.
 *
 * @param string $value Raw value.
 * @return string
 */
function zymarg_os_sanitize_scheme_default( $value ) {
	return in_array( $value, array( 'auto', 'light', 'dark' ), true ) ? $value : 'auto';
}

/**
 * The initial data-theme value rendered server-side.
 *
 * @return string
 */
function zymarg_os_initial_theme_attr() {
	$scheme = zymarg_os_color_scheme();

	// "toggle" starts from the configured default mode; the early script then
	// applies any saved visitor choice on top.
	if ( 'toggle' === $scheme ) {
		return zymarg_os_color_scheme_default();
	}

	return $scheme;
}

/**
 * Add the data-theme attribute (and, in toggle mode, the default mode) to <html>.
 *
 * @param string $output The language attributes string.
 * @return string
 */
function zymarg_os_html_theme_attr( $output ) {
	$output .= ' data-theme="' . esc_attr( zymarg_os_initial_theme_attr() ) . '"';
	if ( 'toggle' === zymarg_os_color_scheme() ) {
		$output .= ' data-theme-default="' . esc_attr( zymarg_os_color_scheme_default() ) . '"';
	}
	return $output;
}
add_filter( 'language_attributes', 'zymarg_os_html_theme_attr' );

/**
 * Print an early inline script (no-flash) when toggle mode is on, so a saved
 * visitor preference applies before first paint.
 *
 * @return void
 */
function zymarg_os_no_flash_script() {
	if ( 'toggle' !== zymarg_os_color_scheme() ) {
		return;
	}
	?>
<script id="zymarg-os-theme-init">
(function(){try{var s=localStorage.getItem('zymarg-theme');if(s==='dark'||s==='light'||s==='auto'){document.documentElement.setAttribute('data-theme',s);}}catch(e){}})();
</script>
	<?php
}
add_action( 'wp_head', 'zymarg_os_no_flash_script', 1 );

/**
 * Enqueue the toggle script only when toggle mode is active.
 *
 * @return void
 */
function zymarg_os_dark_mode_assets() {
	if ( 'toggle' !== zymarg_os_color_scheme() ) {
		return;
	}

	wp_enqueue_script(
		'zymarg-os-dark-mode',
		ZYMARG_OS_URI . '/assets/js/dark-mode.js',
		array(),
		ZYMARG_OS_VERSION,
		true
	);
}
add_action( 'wp_enqueue_scripts', 'zymarg_os_dark_mode_assets' );

/**
 * Build the theme-toggle button markup.
 *
 * @param array $args Optional. 'class' and 'label'.
 * @return string
 */
function zymarg_os_theme_toggle( $args = array() ) {
	// Only meaningful in toggle mode, but render anyway if explicitly requested.
	$args = wp_parse_args(
		$args,
		array(
			'class'      => '',
			'label'      => __( 'Toggle dark mode', 'zymarg-os' ),
			'size'       => 'md',   // sm | md | lg
			'show_label' => false,  // show a visible text label next to the icon
		)
	);

	$size       = in_array( $args['size'], array( 'sm', 'md', 'lg' ), true ) ? $args['size'] : 'md';
	$show_label = filter_var( $args['show_label'], FILTER_VALIDATE_BOOLEAN );

	$classes = 'zymarg-theme-toggle zymarg-theme-toggle--' . $size;
	if ( $show_label ) {
		$classes .= ' has-label';
	}
	if ( $args['class'] ) {
		$classes .= ' ' . sanitize_html_class( $args['class'] );
	}

	$l_auto  = __( 'Theme: Auto (match system)', 'zymarg-os' );
	$l_light = __( 'Theme: Light', 'zymarg-os' );
	$l_dark  = __( 'Theme: Dark', 'zymarg-os' );

	// The visible label (when shown) starts on "Auto" to avoid a flash; the
	// hidden accessible label keeps the descriptive default. JS updates both.
	$label_class   = $show_label ? 'zymarg-theme-toggle__label' : 'screen-reader-text';
	$initial_label = $show_label ? $l_auto : $args['label'];

	return sprintf(
		'<button type="button" class="%1$s" data-zymarg-theme-toggle data-mode="auto" data-l-auto="%3$s" data-l-light="%4$s" data-l-dark="%5$s" aria-label="%2$s" title="%2$s">'
		. '<svg class="zymarg-theme-toggle__auto" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="9"/><path d="M12 3v18a9 9 0 0 0 0-18z" fill="currentColor" stroke="none"/></svg>'
		. '<svg class="zymarg-theme-toggle__sun" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 7a5 5 0 1 0 0 10 5 5 0 0 0 0-10zm0-5v3m0 14v3M2 12h3m14 0h3M4.9 4.9l2.1 2.1m10 10 2.1 2.1m0-14.2-2.1 2.1m-10 10-2.1 2.1"/></svg>'
		. '<svg class="zymarg-theme-toggle__moon" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>'
		. '<span class="%6$s" data-zymarg-theme-label>%7$s</span>'
		. '</button>',
		esc_attr( $classes ),
		esc_attr( $args['label'] ),
		esc_attr( $l_auto ),
		esc_attr( $l_light ),
		esc_attr( $l_dark ),
		esc_attr( $label_class ),
		esc_html( $initial_label )
	);
}

/**
 * Echo the theme toggle.
 *
 * @param array $args See zymarg_os_theme_toggle().
 * @return void
 */
function zymarg_os_the_theme_toggle( $args = array() ) {
	echo zymarg_os_theme_toggle( $args ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- markup escaped internally.
}

/**
 * Shortcode: [zymarg_theme_toggle]
 *
 * @param array $atts Attributes.
 * @return string
 */
function zymarg_os_theme_toggle_shortcode( $atts ) {
	$atts = shortcode_atts(
		array(
			'class'      => '',
			'label'      => __( 'Toggle dark mode', 'zymarg-os' ),
			'size'       => 'md',
			'show_label' => 'false',
		),
		$atts,
		'zymarg_theme_toggle'
	);

	$atts['show_label'] = filter_var( $atts['show_label'], FILTER_VALIDATE_BOOLEAN );

	return zymarg_os_theme_toggle( $atts );
}
add_shortcode( 'zymarg_theme_toggle', 'zymarg_os_theme_toggle_shortcode' );

/* ====================================================================== *
 * Toggle-switch variant — a binary slider switch (light <-> dark) for
 * sidebar / settings contexts. Shares state with the icon-button variant
 * via the same data-theme attribute on <html>.
 * ====================================================================== */

/**
 * Build the dark-mode toggle-switch markup.
 *
 * @param array $args { label?: string, class?: string }.
 * @return string
 */
function zymarg_os_theme_switch( $args = array() ) {
	$args = wp_parse_args( $args, array(
		'label' => __( 'Dark mode', 'zymarg-os' ),
		'class' => '',
	) );
	$classes = 'zymarg-theme-switch';
	if ( ! empty( $args['class'] ) ) {
		$classes .= ' ' . sanitize_html_class( $args['class'] );
	}
	return sprintf(
		'<label class="%1$s">'
		. '<span class="zymarg-theme-switch__label">%2$s</span>'
		. '<span class="zymarg-theme-switch__control">'
		. '<input type="checkbox" data-zymarg-theme-switch aria-label="%2$s">'
		. '<span class="zymarg-theme-switch__slider" aria-hidden="true"></span>'
		. '</span>'
		. '</label>',
		esc_attr( $classes ),
		esc_html( $args['label'] )
	);
}

/**
 * Shortcode: [zymarg_theme_switch label="Dark mode"]
 *
 * @param array $atts Attributes.
 * @return string
 */
function zymarg_os_theme_switch_shortcode( $atts ) {
	$atts = shortcode_atts(
		array(
			'label' => __( 'Dark mode', 'zymarg-os' ),
			'class' => '',
		),
		$atts,
		'zymarg_theme_switch'
	);
	return zymarg_os_theme_switch( $atts );
}
add_shortcode( 'zymarg_theme_switch', 'zymarg_os_theme_switch_shortcode' );

/**
 * Inline CSS for the toggle switch — printed in <head> so it's available on
 * every page (buyer's My Account AND vendor's Dashboard plugin pages).
 *
 * @return void
 */
function zymarg_os_theme_switch_inline_css() {
	?>
	<style id="zymarg-os-theme-switch-css">
		.zymarg-theme-switch {
			display: inline-flex;
			align-items: center;
			justify-content: space-between;
			gap: 12px;
			cursor: pointer;
			user-select: none;
			-webkit-user-select: none;
		}
		.zymarg-theme-switch__label {
			font-size: 14px;
			font-weight: 600;
			color: var(--color-text-body, #131b2e);
		}
		.zymarg-theme-switch__control {
			position: relative;
			display: inline-block;
			width: 40px;
			height: 22px;
			flex: 0 0 40px;
		}
		.zymarg-theme-switch__control input {
			opacity: 0;
			width: 0;
			height: 0;
			position: absolute;
			margin: 0;
		}
		.zymarg-theme-switch__slider {
			position: absolute;
			inset: 0;
			background: var(--color-outline-variant, #d8bfd3);
			border-radius: 22px;
			transition: background 0.2s ease;
			cursor: pointer;
		}
		.zymarg-theme-switch__slider::before {
			content: '';
			position: absolute;
			width: 18px;
			height: 18px;
			left: 2px;
			top: 2px;
			background: #fff;
			border-radius: 50%;
			transition: transform 0.2s ease;
			box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
		}
		.zymarg-theme-switch__control input:checked + .zymarg-theme-switch__slider {
			background: var(--color-primary, #9500a5);
		}
		.zymarg-theme-switch__control input:checked + .zymarg-theme-switch__slider::before {
			transform: translateX(18px);
		}
		.zymarg-theme-switch__control input:focus-visible + .zymarg-theme-switch__slider {
			outline: 2px solid var(--color-primary, #9500a5);
			outline-offset: 2px;
		}
	</style>
	<?php
}
add_action( 'wp_head', 'zymarg_os_theme_switch_inline_css' );
