<?php
/**
 * Login experience — Redesign v4.4.3.
 *
 * Three fully customizable login surfaces:
 *
 *   1. A branded WordPress admin login screen (wp-login.php).
 *   2. A front-end login card via the [zymarg_login] shortcode with
 *      Password/OTP tabs, Google sign-in, and vendor CTA.
 *   3. An elegant login pop-up (modal) with per-device sizing and
 *      page-targeting rules.
 *
 * Visual styling lives in components/login.css; colours + per-device sizes
 * arrive as scoped custom properties via dynamic-css.php.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;


/**
 * Default options.
 *
 * @return array<string,mixed>
 */
function zymarg_os_login_defaults() {
	return array(
		// Pop-up.
		'popup'           => true,
		'frequency'       => 'once',
		'days'            => 7,
		'delay'           => 2000,
		'trigger_account' => true,
		'display'         => 'all',
		'pages'           => '',

		// Card content.
		'title'           => '',
		'subtitle'        => '',

		// Appearance.
		'accent'          => '#9500a5',
		'card_bg'         => '#ffffff',

		// Per-device sizes.
		'desktop_width'   => 560,
		'desktop_maxh'    => 680,
		'tablet_width'    => 520,
		'tablet_maxh'     => 560,
		'mobile_width'    => 340,
		'mobile_maxh'     => 600,
		'mobile_full'     => false,

		// wp-login.php branding.
		'brand'           => true,
		'brand_bg'        => '#faf8ff',
		'brand_accent'    => '#9500a5',
		'brand_logo'      => '',

		// Social login.
		'google'          => true,
		'google_url'      => '',

		// Links.
		'register_url'    => '',
		'vendor_url'      => '',

		// My Account page popup — separate fast trigger (default: instant).
		'account_delay'   => 0,
		'account_message' => '',

		// Per-page delay overrides — format: "page_id:delay_ms, page_id:delay_ms"
		// e.g. "12:1000, 45:3000, 89:0"
		'per_page_delays' => '',
	);
}


/**
 * Get one login option (theme_mod) with its default.
 *
 * @param string $key Option key (without the zymarg_login_ prefix).
 * @return mixed
 */
function zymarg_os_login_opt( $key ) {
	$defaults = zymarg_os_login_defaults();
	$default  = isset( $defaults[ $key ] ) ? $defaults[ $key ] : '';
	return get_theme_mod( 'zymarg_login_' . $key, $default );
}

/**
 * Is the auto pop-up enabled?
 *
 * @return bool
 */
function zymarg_os_login_popup_enabled() {
	return (bool) apply_filters( 'zymarg_os_login_popup_enabled', (bool) zymarg_os_login_opt( 'popup' ) );
}

/**
 * Is new-user registration enabled?
 *
 * Returns true when EITHER WordPress's "Anyone can register" option is on
 * OR WooCommerce's "Allow customers to create an account on the My account
 * page" option is on — many WC sites enable only the WC option, and we
 * want the branded card to respect both signals.
 *
 * @return bool
 */
function zymarg_os_registration_enabled() {
	$wp_open = (bool) get_option( 'users_can_register' );
	$wc_open = ( 'yes' === get_option( 'woocommerce_enable_myaccount_registration', 'no' ) );

	/**
	 * Allow other code to force-show or force-hide the register link.
	 *
	 * @param bool $enabled Whether registration is enabled.
	 */
	return (bool) apply_filters( 'zymarg_os_registration_enabled', ( $wp_open || $wc_open ) );
}

/**
 * Resolve the Google login URL.
 *
 * Priority order:
 *   1. Customizer override (zymarg_login_google_url)
 *   2. Nextend Social Login plugin (auto-detected)
 *   3. miniOrange Login with Google plugin (auto-detected)
 *   4. Filter override (zymarg_os_google_login_url)
 *   5. Empty (button shows "not configured" toast)
 *
 * @return string
 */
function zymarg_os_resolve_google_login_url() {
	// 1. Manual Customizer override.
	$manual = trim( (string) zymarg_os_login_opt( 'google_url' ) );
	if ( '' !== $manual ) {
		return esc_url( $manual );
	}

	$url = '';

	// 2. Nextend Social Login plugin.
	if ( class_exists( 'NextendSocialLogin' ) ) {
		if ( shortcode_exists( 'nextend_social_login' ) ) {
			// Use shortcode-rendered link if available.
			$rendered = do_shortcode( '[nextend_social_login provider="google" style="link"]' );
			if ( preg_match( '/href=["\']([^"\']+)["\']/i', (string) $rendered, $m ) ) {
				$url = html_entity_decode( $m[1] );
			}
		}
	}

	// 3. miniOrange "Login with Google" plugin.
	if ( '' === $url && function_exists( 'mo_openid_get_provider_url' ) ) {
		$url = mo_openid_get_provider_url( 'google' );
	}

	// 4. Filter for custom integrations.
	$url = (string) apply_filters( 'zymarg_os_google_login_url', $url );

	return $url ? esc_url( $url ) : '';
}


/**
 * Parse the per-page delays setting into an array map: page_id => delay_ms.
 *
 * Input format: "12:1000, 45:3000, 89:0" (page_id:delay_ms pairs, comma-separated).
 *
 * @return array<int,int>
 */
function zymarg_os_login_parse_per_page_delays() {
	$raw = (string) zymarg_os_login_opt( 'per_page_delays' );
	$map = array();
	if ( '' === trim( $raw ) ) {
		return $map;
	}
	foreach ( explode( ',', $raw ) as $pair ) {
		$parts = explode( ':', trim( $pair ) );
		if ( count( $parts ) !== 2 ) {
			continue;
		}
		$pid   = absint( trim( $parts[0] ) );
		$delay = absint( trim( $parts[1] ) );
		if ( $pid > 0 ) {
			$map[ $pid ] = $delay;
		}
	}
	return $map;
}

/**
 * Resolve the popup delay (in ms) for the current request.
 *
 * Priority order:
 *   1. Per-page override (if current page_id matches an entry in per_page_delays)
 *   2. My Account override (if on /my-account/)
 *   3. General site delay (default 2000ms)
 *
 * @return int Delay in milliseconds.
 */
function zymarg_os_login_resolve_delay() {
	$current_id = (int) get_queried_object_id();
	$per_page   = zymarg_os_login_parse_per_page_delays();

	// 1. Per-page override has the highest priority.
	if ( $current_id && isset( $per_page[ $current_id ] ) ) {
		return (int) $per_page[ $current_id ];
	}

	// 2. My Account override.
	if ( function_exists( 'is_account_page' ) && is_account_page() ) {
		return (int) zymarg_os_login_opt( 'account_delay' );
	}

	// 3. General site delay.
	return (int) zymarg_os_login_opt( 'delay' );
}


/* ---------------------------------------------------------------------- *
 * The branded login card (shared by the shortcode and the pop-up)
 * ---------------------------------------------------------------------- */

/**
 * Build the login card markup — Password/OTP tabs, Google sign-in.
 *
 * @param string $context Where it renders: 'inline' or 'modal'.
 * @return string
 */
function zymarg_os_login_card_markup( $context = 'inline' ) {
	static $n = 0;
	++$n;
	$uid = 'zlg-' . $context . '-' . $n;

	$redirect     = zymarg_os_login_get_current_url();
	$register_url = trim( (string) zymarg_os_login_opt( 'register_url' ) );
	$vendor_url   = trim( (string) zymarg_os_login_opt( 'vendor_url' ) );

	if ( '' === $register_url ) {
		$register_url = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : wp_registration_url();
	}
	if ( '' === $vendor_url ) {
		$vendor_url = function_exists( 'dokan_get_page_url' ) ? dokan_get_page_url( 'myaccount', 'woocommerce' ) : home_url( '/vendor-registration/' );
	}

	$show_google = (bool) zymarg_os_login_opt( 'google' );

	ob_start();
	?>
	<div class="zymarg-login zymarg-login--<?php echo esc_attr( $context ); ?>" data-zymarg-login>
		<!-- Gradient top bar -->
		<div class="zymarg-login__gradient-bar"></div>


		<!-- Header -->
		<div class="zymarg-login__head">
			<div class="zymarg-login__brand">
				<div class="zymarg-login__brand-inner">
					<span class="zymarg-spark" role="img" aria-label="<?php esc_attr_e( 'ZYMARG Discovery Spark', 'zymarg-os' ); ?>">
						<svg class="zymarg-spark__svg" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
							<g class="zymarg-spark-group--accent">
								<path class="zymarg-spark-item--purple" d="M10.4 5.4c0 1.32-0.24 2.4-1.44 2.4 1.2 0 1.44 1.08 1.44 2.4 0-1.32 0.24-2.4 1.44-2.4-1.2 0-1.44-1.08-1.44-2.4z"/>
								<path class="zymarg-spark-item--gold" d="M10.4 6.0c0 0.96-0.18 1.8-1.08 1.8 0.9 0 1.08 0.84 1.08 1.8 0-0.9 0.18-1.8 1.08-1.8-0.9 0-1.08-0.84-1.08-1.8z"/>
							</g>
							<g class="zymarg-spark-group--companion">
								<path class="zymarg-spark-item--purple" d="M9.5 10.92c0 2.25-0.45 4.12-2.4 4.12 1.95 0 2.4 1.87 2.4 4.12 0-2.25 0.45-4.12 2.4-4.12-1.95 0-2.4-1.87-2.4-4.12z"/>
								<path class="zymarg-spark-item--gold" d="M9.5 11.5c0 1.9-0.38 3.54-2.0 3.54 1.62 0 2.0 1.64 2.0 3.54 0-1.9 0.38-3.54 2.0-3.54-1.62 0-2.0-1.64-2.0-3.54z"/>
							</g>
							<g class="zymarg-spark-group--hero">
								<path class="zymarg-spark-item--purple" d="M15.2 5.6c0 3.45-0.69 6.3-4.08 6.3 3.39 0 4.08 2.85 4.08 6.3 0-3.45 0.69-6.3 4.08-6.3-3.39 0-4.08-2.85-4.08-6.3z"/>
								<path class="zymarg-spark-item--gold" d="M15.2 6.5c0 2.9-0.58 5.4-3.39 5.4 2.81 0 3.39 2.5 3.39 5.4 0-2.9 0.58-5.4 3.39-5.4-2.81 0-3.39-2.5-3.39-5.4z"/>
							</g>
						</svg>
					</span>
					<div class="zymarg-login__logo">
						<?php if ( has_custom_logo() ) : ?>
							<?php
							$logo_id  = (int) get_theme_mod( 'custom_logo' );
							$logo_src = wp_get_attachment_image_url( $logo_id, 'full' );
							if ( $logo_src ) :
							?>
								<img src="<?php echo esc_url( $logo_src ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
							<?php endif; ?>
						<?php else : ?>
							<span class="zymarg-login__brand-text" style="display:inline;"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></span>
						<?php endif; ?>
					</div>
				</div>
			</div>
			<p class="zymarg-login__subtitle"><?php esc_html_e( 'Access your account securely', 'zymarg-os' ); ?></p>
		</div>

		<?php
		// Error banner — shown when redirected back from a failed login attempt.
		$show_error = ! empty( $_GET['login_error'] ); // phpcs:ignore WordPress.Security.NonceVerification
		$is_empty   = ! empty( $_GET['empty'] ); // phpcs:ignore WordPress.Security.NonceVerification
		if ( $show_error ) :
			$msg = $is_empty
				? __( 'Please enter both your email/username and password.', 'zymarg-os' )
				: __( 'Login failed. Please check your email/username and password and try again.', 'zymarg-os' );
		?>
		<div class="zymarg-login__error" role="alert">
			<svg class="zymarg-login__error-icon" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2L1 21h22L12 2zm0 5l7.5 13h-15L12 7zm-1 4v4h2v-4h-2zm0 6v2h2v-2h-2z"/></svg>
			<span><?php echo esc_html( $msg ); ?></span>
		</div>
		<?php endif; ?>


		<!-- Tabs: Password / OTP -->
		<div class="zymarg-login__tabs" role="tablist">
			<button type="button" class="zymarg-login__tab is-active" data-tab="password" role="tab" aria-selected="true">
				<svg class="zymarg-login__tab-icon" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
				<?php esc_html_e( 'Via Password', 'zymarg-os' ); ?>
			</button>
			<button type="button" class="zymarg-login__tab" data-tab="otp" role="tab" aria-selected="false">
				<svg class="zymarg-login__tab-icon" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 24 24"><path d="M13 3L4 14h7l-1 7 9-11h-7l1-7z"/></svg>
				<?php esc_html_e( 'Via OTP', 'zymarg-os' ); ?>
			</button>
		</div>


		<!-- Forms -->
		<div class="zymarg-login__panels">
			<!-- Password form -->
			<div class="zymarg-login__panel is-active" data-panel="password">
				<form method="post" action="<?php echo esc_url( site_url( 'wp-login.php', 'login_post' ) ); ?>" id="<?php echo esc_attr( $uid ); ?>-form-pw">
					<div class="zymarg-login__field">
						<label for="<?php echo esc_attr( $uid ); ?>-user"><?php esc_html_e( 'Email / Phone Number', 'zymarg-os' ); ?></label>
						<input type="text" name="log" id="<?php echo esc_attr( $uid ); ?>-user" placeholder="<?php esc_attr_e( 'Enter your email or phone number', 'zymarg-os' ); ?>" inputmode="email" autocomplete="username" autocapitalize="none" autocorrect="off" spellcheck="false" required>
					</div>
					<div class="zymarg-login__field">
						<label for="<?php echo esc_attr( $uid ); ?>-pass"><?php esc_html_e( 'Password', 'zymarg-os' ); ?></label>
						<div class="zymarg-login__password-wrap">
							<input type="password" name="pwd" id="<?php echo esc_attr( $uid ); ?>-pass" placeholder="<?php esc_attr_e( 'Enter your password', 'zymarg-os' ); ?>" autocomplete="current-password" required>
							<button type="button" class="zymarg-login__pw-toggle" data-zlg-pw-toggle aria-label="<?php esc_attr_e( 'Show password', 'zymarg-os' ); ?>">
								<svg class="zymarg-login__pw-icon zymarg-login__pw-icon--show" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
								<svg class="zymarg-login__pw-icon zymarg-login__pw-icon--hide" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" hidden aria-hidden="true"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>
							</button>
						</div>
					</div>
					<input type="hidden" name="redirect_to" value="<?php echo esc_url( $redirect ); ?>">
					<input type="hidden" name="rememberme" value="forever">
					<?php wp_nonce_field( 'zymarg-login-nonce', '_zlg_nonce' ); ?>
					<button type="submit" class="zymarg-login__submit" data-zlg-submit>
						<span><?php esc_html_e( 'Log In', 'zymarg-os' ); ?></span>
					</button>
				</form>
			</div>


			<!-- OTP form -->
			<div class="zymarg-login__panel" data-panel="otp" hidden>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>" id="<?php echo esc_attr( $uid ); ?>-form-otp" data-zlg-otp-form>
					<div class="zymarg-login__field">
						<label for="<?php echo esc_attr( $uid ); ?>-otp-user"><?php esc_html_e( 'Email / Phone Number', 'zymarg-os' ); ?></label>
						<input type="text" name="otp_identifier" id="<?php echo esc_attr( $uid ); ?>-otp-user" placeholder="<?php esc_attr_e( 'Enter your email or phone number', 'zymarg-os' ); ?>" inputmode="email" autocapitalize="none" autocorrect="off" spellcheck="false" required>
					</div>
					<input type="hidden" name="action" value="zymarg_send_otp">
					<?php wp_nonce_field( 'zymarg-otp-nonce', '_zlg_otp_nonce' ); ?>
					<button type="submit" class="zymarg-login__submit" data-zlg-submit>
						<span><?php esc_html_e( 'Send OTP', 'zymarg-os' ); ?></span>
					</button>
				</form>
			</div>

			<!-- Lost Password form (revealed when Forgot Password? is clicked) -->
			<div class="zymarg-login__panel zymarg-login__panel--lost" data-panel="lost" hidden>
				<p class="zymarg-login__lost-intro"><?php esc_html_e( 'Enter your email or username. We\'ll send you a link to reset your password.', 'zymarg-os' ); ?></p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>" id="<?php echo esc_attr( $uid ); ?>-form-lost" data-zlg-lost-form>
					<div class="zymarg-login__field">
						<label for="<?php echo esc_attr( $uid ); ?>-lost-user"><?php esc_html_e( 'Email / Username', 'zymarg-os' ); ?></label>
						<input type="text" name="user_login" id="<?php echo esc_attr( $uid ); ?>-lost-user" placeholder="<?php esc_attr_e( 'Enter your email or username', 'zymarg-os' ); ?>" autocapitalize="none" autocorrect="off" spellcheck="false" required>
					</div>
					<?php /* Anti-bot: honeypot (invisible) + render timestamp. */ ?>
					<div class="zymarg-login__hp" aria-hidden="true">
						<label for="<?php echo esc_attr( $uid ); ?>-lost-hp"><?php esc_html_e( 'Website', 'zymarg-os' ); ?></label>
						<input type="text" name="zlg_website" id="<?php echo esc_attr( $uid ); ?>-lost-hp" tabindex="-1" autocomplete="off">
					</div>
					<input type="hidden" name="zlg_form_ts" value="<?php echo (int) time(); ?>">
					<input type="hidden" name="action" value="zymarg_lost_password">
					<button type="submit" class="zymarg-login__submit" data-zlg-submit>
						<span><?php esc_html_e( 'Send Reset Link', 'zymarg-os' ); ?></span>
					</button>
					<button type="button" class="zymarg-login__back-link" data-zlg-back-to-login>
						<?php esc_html_e( '← Back to login', 'zymarg-os' ); ?>
					</button>
					<div class="zymarg-login__inline-message" data-zlg-lost-message hidden></div>
				</form>
			</div>

			<!-- Register form (revealed when "Create New Account" is clicked) -->
			<?php if ( zymarg_os_registration_enabled() ) : ?>
			<div class="zymarg-login__panel zymarg-login__panel--register" data-panel="register" hidden>
				<p class="zymarg-login__lost-intro"><?php esc_html_e( 'Create your account in seconds.', 'zymarg-os' ); ?></p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>" id="<?php echo esc_attr( $uid ); ?>-form-register" data-zlg-register-form>
					<div class="zymarg-login__field">
						<label for="<?php echo esc_attr( $uid ); ?>-reg-email"><?php esc_html_e( 'Email Address', 'zymarg-os' ); ?></label>
						<input type="email" name="user_email" id="<?php echo esc_attr( $uid ); ?>-reg-email" placeholder="<?php esc_attr_e( 'you@example.com', 'zymarg-os' ); ?>" autocapitalize="none" autocorrect="off" spellcheck="false" autocomplete="email" required>
					</div>
					<div class="zymarg-login__field">
						<label for="<?php echo esc_attr( $uid ); ?>-reg-pass"><?php esc_html_e( 'Password', 'zymarg-os' ); ?></label>
						<div class="zymarg-login__password-wrap">
							<input type="password" name="user_pass" id="<?php echo esc_attr( $uid ); ?>-reg-pass" placeholder="<?php esc_attr_e( 'Choose a strong password (min 8 chars)', 'zymarg-os' ); ?>" minlength="8" autocomplete="new-password" required>
							<button type="button" class="zymarg-login__pw-toggle" data-zlg-pw-toggle aria-label="<?php esc_attr_e( 'Show password', 'zymarg-os' ); ?>">
								<svg class="zymarg-login__pw-icon zymarg-login__pw-icon--show" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
								<svg class="zymarg-login__pw-icon zymarg-login__pw-icon--hide" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" hidden aria-hidden="true"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>
							</button>
						</div>
					</div>
					<div class="zymarg-login__field-row">
						<div class="zymarg-login__field zymarg-login__field--half">
							<label for="<?php echo esc_attr( $uid ); ?>-reg-first"><?php esc_html_e( 'First Name', 'zymarg-os' ); ?></label>
							<input type="text" name="first_name" id="<?php echo esc_attr( $uid ); ?>-reg-first" placeholder="<?php esc_attr_e( 'John', 'zymarg-os' ); ?>" autocomplete="given-name" maxlength="50" required>
						</div>
						<div class="zymarg-login__field zymarg-login__field--half">
							<label for="<?php echo esc_attr( $uid ); ?>-reg-last"><?php esc_html_e( 'Last Name', 'zymarg-os' ); ?></label>
							<input type="text" name="last_name" id="<?php echo esc_attr( $uid ); ?>-reg-last" placeholder="<?php esc_attr_e( 'Doe', 'zymarg-os' ); ?>" autocomplete="family-name" maxlength="50" required>
						</div>
					</div>
					<div class="zymarg-login__field">
						<label for="<?php echo esc_attr( $uid ); ?>-reg-mobile"><?php esc_html_e( 'Mobile Number', 'zymarg-os' ); ?> <span class="zymarg-login__field-opt"><?php esc_html_e( '(optional)', 'zymarg-os' ); ?></span></label>
						<input type="tel" name="mobile_number" id="<?php echo esc_attr( $uid ); ?>-reg-mobile" placeholder="<?php esc_attr_e( '+880 1700 000000', 'zymarg-os' ); ?>" autocomplete="tel" maxlength="30">
					</div>
					<div class="zymarg-login__field">
						<label for="<?php echo esc_attr( $uid ); ?>-reg-address"><?php esc_html_e( 'Address', 'zymarg-os' ); ?> <span class="zymarg-login__field-opt"><?php esc_html_e( '(optional)', 'zymarg-os' ); ?></span></label>
						<textarea name="address" id="<?php echo esc_attr( $uid ); ?>-reg-address" placeholder="<?php esc_attr_e( 'Street, City, State, ZIP', 'zymarg-os' ); ?>" rows="2" autocomplete="street-address" maxlength="500"></textarea>
					</div>
					<?php /* Anti-bot: honeypot (invisible) + render timestamp. */ ?>
					<div class="zymarg-login__hp" aria-hidden="true">
						<label for="<?php echo esc_attr( $uid ); ?>-reg-hp"><?php esc_html_e( 'Website', 'zymarg-os' ); ?></label>
						<input type="text" name="zlg_website" id="<?php echo esc_attr( $uid ); ?>-reg-hp" tabindex="-1" autocomplete="off">
					</div>
					<input type="hidden" name="zlg_form_ts" value="<?php echo (int) time(); ?>">
					<input type="hidden" name="action" value="zymarg_register_user">
					<button type="submit" class="zymarg-login__submit" data-zlg-submit>
						<span><?php esc_html_e( 'Create Account', 'zymarg-os' ); ?></span>
					</button>
					<button type="button" class="zymarg-login__back-link" data-zlg-back-to-login>
						<?php esc_html_e( '← Back to login', 'zymarg-os' ); ?>
					</button>
					<div class="zymarg-login__inline-message" data-zlg-register-message hidden></div>
				</form>
			</div>
			<?php endif; ?>
		</div>


		<!-- Divider -->
		<div class="zymarg-login__divider">
			<span class="zymarg-login__divider-text"><?php esc_html_e( 'Or', 'zymarg-os' ); ?></span>
		</div>

		<!-- Google sign-in button -->
		<?php if ( $show_google ) : ?>
		<?php $google_url = zymarg_os_resolve_google_login_url(); ?>
		<button type="button" class="zymarg-login__google" data-zlg-google<?php echo $google_url ? ' data-google-url="' . esc_attr( $google_url ) . '"' : ''; ?>>
			<svg fill="none" height="18" viewBox="0 0 24 24" width="18" xmlns="http://www.w3.org/2000/svg">
				<path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
				<path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
				<path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"/>
				<path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.47 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
			</svg>
			<?php esc_html_e( 'Continue with Google', 'zymarg-os' ); ?>
		</button>
		<?php endif; ?>


		<!-- Forgot Password -->
		<a class="zymarg-login__forgot" style="margin-top:10px !important;display:block !important;" href="<?php echo esc_url( wp_lostpassword_url( $redirect ) ); ?>" data-zlg-show-lost><?php esc_html_e( 'Forgot Password?', 'zymarg-os' ); ?></a>

		<!-- Footer links -->
		<?php if ( zymarg_os_registration_enabled() ) : ?>
		<div class="zymarg-login__footer">
			<p class="zymarg-login__footer-text">
				<?php esc_html_e( "Don't have an account?", 'zymarg-os' ); ?>
				<a class="zymarg-login__footer-link" href="<?php echo esc_url( $register_url ); ?>" data-zlg-show-register><?php esc_html_e( 'Create New Account', 'zymarg-os' ); ?></a>
			</p>
		</div>
		<?php endif; ?>
	</div>
	<?php
	return (string) ob_get_clean();
}


/**
 * Shortcode: [zymarg_login] — the branded login card, inline on any page.
 *
 * @return string
 */
function zymarg_os_login_shortcode() {
	if ( is_user_logged_in() ) {
		$url = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : admin_url();
		return '<div class="zymarg-login zymarg-login--done"><p>' . esc_html__( 'You are already signed in.', 'zymarg-os' )
			. ' <a href="' . esc_url( $url ) . '">' . esc_html__( 'Go to your account', 'zymarg-os' ) . '</a></p></div>';
	}
	return zymarg_os_login_card_markup( 'inline' );
}
add_shortcode( 'zymarg_login', 'zymarg_os_login_shortcode' );

/**
 * Shortcode: [zymarg_login_button label="Sign in"] — opens the pop-up.
 *
 * @param array<string,string> $atts Attributes.
 * @return string
 */
function zymarg_os_login_button_shortcode( $atts ) {
	if ( is_user_logged_in() ) {
		return '';
	}
	$atts = shortcode_atts( array( 'label' => __( 'Sign in', 'zymarg-os' ) ), $atts, 'zymarg_login_button' );
	return '<button type="button" class="zymarg-login-trigger" data-zymarg-login-open>' . esc_html( $atts['label'] ) . '</button>';
}
add_shortcode( 'zymarg_login_button', 'zymarg_os_login_button_shortcode' );


/* ---------------------------------------------------------------------- *
 * The pop-up (modal)
 * ---------------------------------------------------------------------- */

/**
 * Should the login pop-up render on this request?
 *
 * @return bool
 */
function zymarg_os_login_popup_visible() {
	if ( ! zymarg_os_login_popup_enabled() ) {
		return false;
	}
	if ( is_user_logged_in() ) {
		return false;
	}

	$id   = (int) get_queried_object_id();
	$mode = zymarg_os_login_opt( 'display' );

	if ( 'all' === $mode ) {
		return true;
	}

	$list = array();
	foreach ( explode( ',', (string) zymarg_os_login_opt( 'pages' ) ) as $part ) {
		$pid = absint( trim( $part ) );
		if ( $pid ) {
			$list[] = $pid;
		}
	}
	$in = ( $id && in_array( $id, $list, true ) );

	if ( 'include' === $mode ) {
		return $in;
	}
	if ( 'exclude' === $mode ) {
		return ! $in;
	}

	return true;
}


/**
 * Render the login pop-up in the footer.
 *
 * @return void
 */
function zymarg_os_render_login_popup() {
	if ( ! zymarg_os_login_popup_visible() ) {
		return;
	}

	$frequency = (string) zymarg_os_login_opt( 'frequency' );
	$days      = absint( zymarg_os_login_opt( 'days' ) );
	$delay     = zymarg_os_login_resolve_delay();
	$trigger   = zymarg_os_login_opt( 'trigger_account' ) ? '1' : '0';

	printf(
		'<div class="zymarg-login-modal" id="zymarg-login-modal" data-zymarg-login-modal data-auto="1" data-frequency="%1$s" data-days="%2$d" data-delay="%3$d" data-trigger-account="%4$s" hidden>',
		esc_attr( $frequency ),
		(int) $days,
		(int) $delay,
		esc_attr( $trigger )
	);
	echo '<div class="zymarg-login-modal__overlay" data-zymarg-login-close></div>';
	echo '<div class="zymarg-login-modal__dialog" role="dialog" aria-modal="true" aria-label="' . esc_attr__( 'Login', 'zymarg-os' ) . '">';
	echo '<button type="button" class="zymarg-login-modal__close" data-zymarg-login-close aria-label="' . esc_attr__( 'Close', 'zymarg-os' ) . '">&times;</button>';
	echo zymarg_os_login_card_markup( 'modal' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo '</div></div>';

	// Toast notification element.
	?>
	<div class="zymarg-login-toast" id="zymarg-login-toast" aria-live="polite" aria-atomic="true">
		<svg class="zymarg-login-toast__icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>
		<span class="zymarg-login-toast__message" id="zymarg-login-toast-msg"><?php esc_html_e( 'Welcome back!', 'zymarg-os' ); ?></span>
	</div>
	<?php
}
add_action( 'wp_footer', 'zymarg_os_render_login_popup' );


/* ---------------------------------------------------------------------- *
 * wp-login.php branding
 * ---------------------------------------------------------------------- */

/**
 * Brand the WordPress admin login screen.
 *
 * @return void
 */
function zymarg_os_login_brand() {
	if ( ! get_theme_mod( 'zymarg_login_brand', true ) ) {
		return;
	}

	$bg     = sanitize_hex_color( (string) zymarg_os_login_opt( 'brand_bg' ) );
	$accent = sanitize_hex_color( (string) zymarg_os_login_opt( 'brand_accent' ) );
	$bg     = $bg ? $bg : '#faf8ff';
	$accent = $accent ? $accent : '#9500a5';

	$logo = trim( (string) zymarg_os_login_opt( 'brand_logo' ) );
	if ( '' === $logo && has_custom_logo() ) {
		$img = wp_get_attachment_image_src( (int) get_theme_mod( 'custom_logo' ), 'full' );
		if ( $img ) {
			$logo = $img[0];
		}
	}

	$logo_css = '';
	if ( '' !== $logo ) {
		$logo_css = '.login h1 a{background-image:url(' . esc_url( $logo ) . ');background-size:contain;width:100%;height:72px;}';
	}
	?>
	<style id="zymarg-os-login-brand">
		body.login{background:<?php echo esc_html( $bg ); ?>;position:relative;overflow:hidden;font-family:'Inter',sans-serif;}
		body.login::before,body.login::after{content:"";position:absolute;width:520px;height:520px;border-radius:50%;filter:blur(70px);opacity:.18;z-index:0;pointer-events:none;}
		body.login::before{background:<?php echo esc_html( $accent ); ?>;top:-180px;left:-160px;}
		body.login::after{background:<?php echo esc_html( $accent ); ?>;bottom:-200px;right:-160px;}
		#login{position:relative;z-index:1;padding-top:6%;}
		<?php echo $logo_css; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		.login form{border-radius:24px;border:1px solid rgba(214,192,210,0.3);box-shadow:0 25px 50px -12px rgba(0,0,0,0.12),0 12px 24px -8px rgba(149,0,165,0.08);overflow:hidden;position:relative;}
		.login form::before{content:"";position:absolute;top:0;left:0;right:0;height:2.5px;background:linear-gradient(to right,#9500a5,#fea9ff);}
		.login label{color:#524250;font-weight:500;font-size:0.875rem;}
		.login input[type=text],.login input[type=password]{border-radius:18px;background:#faf8ff;border:1px solid #d6c0d2;padding:12px 16px;font-size:0.875rem;}
		.login input[type=text]:focus,.login input[type=password]:focus{border-color:<?php echo esc_html( $accent ); ?>;box-shadow:0 0 0 4px rgba(149,0,165,0.1);outline:none;}
		.wp-core-ui .button-primary{background:<?php echo esc_html( $accent ); ?>;border-color:<?php echo esc_html( $accent ); ?>;border-radius:12px;text-shadow:none;box-shadow:0 10px 15px -3px rgba(149,0,165,0.1);font-weight:600;padding:12px 16px;font-size:0.875rem;height:auto;line-height:1.5;}
		.wp-core-ui .button-primary:hover,.wp-core-ui .button-primary:focus{background:#a400b5;border-color:#a400b5;}
		.login #nav a,.login #backtoblog a{color:#524250;font-size:0.875rem;}
		.login #nav a:hover,.login #backtoblog a:hover{color:<?php echo esc_html( $accent ); ?>;}
		.login .message,.login .success{border-left-color:<?php echo esc_html( $accent ); ?>;border-radius:12px;}
	</style>
	<?php
}
add_action( 'login_enqueue_scripts', 'zymarg_os_login_brand' );


/* ---------------------------------------------------------------------- *
 * Force all login activity through the branded login screen.
 * ---------------------------------------------------------------------- *
 * - Redirect default /wp-login.php to /my-account/ for logged-out visitors
 *   so they see the branded card instead of WordPress's default form.
 * - Preserve special actions (lostpassword, rp, register, logout) — those
 *   still use wp-login.php (but get branded styling via zymarg_os_login_brand).
 * - On failed login, redirect back to /my-account/?login_error=1 so the
 *   error is shown inside the branded card, not on wp-login.php.
 * ---------------------------------------------------------------------- */

/**
 * Redirect default /wp-login.php to /my-account/ so visitors see the branded
 * login card instead of WordPress's default form.
 *
 * @return void
 */
function zymarg_os_force_branded_login() {
	// Logged-in users: let wp-login.php handle the re-auth/redirect flow.
	if ( is_user_logged_in() ) {
		return;
	}

	$action = isset( $_REQUEST['action'] ) ? sanitize_key( wp_unslash( $_REQUEST['action'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification

	// Allow these flows to use wp-login.php (still branded via zymarg_os_login_brand).
	$allowed = array( 'lostpassword', 'retrievepassword', 'rp', 'resetpass', 'register', 'logout', 'postpass', 'confirm_admin_email', 'confirmaction' );
	if ( in_array( $action, $allowed, true ) ) {
		return;
	}

	// Don't intercept POST submissions — let WordPress authenticate the form.
	$method = isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) ) : 'GET';
	if ( 'POST' === $method ) {
		return;
	}

	// Don't intercept the interim login window (WP popup re-auth).
	if ( ! empty( $_REQUEST['interim-login'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return;
	}

	// Redirect to /my-account/ where the branded login card lives.
	$account = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : home_url( '/my-account/' );
	if ( $account ) {
		wp_safe_redirect( $account );
		exit;
	}
}
add_action( 'login_init', 'zymarg_os_force_branded_login' );

/**
 * On failed login attempt, redirect back to /my-account/ with an error flag
 * so the error message is shown inside the branded card.
 *
 * @param string $username Username that was attempted.
 * @return void
 */
function zymarg_os_login_failed_redirect( $username ) {
	if ( empty( $_POST['log'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return;
	}

	$account = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : home_url( '/my-account/' );
	if ( ! $account ) {
		return;
	}

	$redirect = add_query_arg( array(
		'login_error' => '1',
		'username'    => rawurlencode( (string) $username ),
	), $account );

	wp_safe_redirect( $redirect );
	exit;
}
add_action( 'wp_login_failed', 'zymarg_os_login_failed_redirect' );

/**
 * Catch empty username/password submissions before WP's default auth errors.
 *
 * @param WP_User|WP_Error|null $user     User object on success, error otherwise.
 * @param string                $username Submitted username.
 * @param string                $password Submitted password.
 * @return mixed
 */
function zymarg_os_check_empty_login( $user, $username, $password ) {
	if ( ( empty( $username ) || empty( $password ) ) && ( ! empty( $_POST['log'] ) || ! empty( $_POST['pwd'] ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		$account = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : home_url( '/my-account/' );
		if ( $account ) {
			$redirect = add_query_arg( array(
				'login_error' => '1',
				'empty'       => '1',
			), $account );
			wp_safe_redirect( $redirect );
			exit;
		}
	}
	return $user;
}
add_filter( 'authenticate', 'zymarg_os_check_empty_login', 30, 3 );

/**
 * Get the current page URL for same-page redirect after login.
 *
 * Returns the URL the visitor is currently on so they return to the same page
 * after logging in. Falls back to My Account for customers and Dashboard for
 * vendors (handled by the login_redirect filter).
 *
 * @return string Current page URL.
 */
function zymarg_os_login_get_current_url() {
	// If we're rendering the login card, capture the page the user is viewing.
	if ( ! empty( $_SERVER['REQUEST_URI'] ) ) {
		$url = home_url( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) );
		// Don't redirect back to wp-login.php or admin-ajax.
		if ( false === strpos( $url, 'wp-login.php' ) && false === strpos( $url, 'admin-ajax.php' ) ) {
			return $url;
		}
	}
	return function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : home_url( '/' );
}

/**
 * After successful login, redirect Dokan vendors to /dashboard/ instead of
 * /my-account/ so they land on their vendor dashboard. Customers and other
 * roles stay on the same page (the redirect_to from the form).
 *
 * If the redirect_to is the My Account page and the user is a vendor, override
 * to dashboard. If the redirect_to is the dashboard and user is a customer,
 * override to My Account.
 *
 * @param string             $redirect_to Where WP wants to send the user.
 * @param string             $request     Submitted redirect_to.
 * @param WP_User|WP_Error   $user        The newly logged-in user.
 * @return string
 */
function zymarg_os_vendor_login_redirect( $redirect_to, $request, $user ) {
	if ( is_wp_error( $user ) || ! ( $user instanceof WP_User ) ) {
		return $redirect_to;
	}

	$roles       = (array) $user->roles;
	$is_vendor   = in_array( 'seller', $roles, true ) || in_array( 'vendor_staff', $roles, true );
	$myaccount   = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : home_url( '/my-account/' );
	$dashboard   = function_exists( 'dokan_get_navigation_url' ) ? dokan_get_navigation_url( 'dashboard' ) : home_url( '/dashboard/' );

	if ( $is_vendor ) {
		// If vendor would land on My Account, send to dashboard instead.
		if ( zymarg_os_url_matches_page( $redirect_to, $myaccount ) ) {
			return $dashboard;
		}
	} else {
		// If customer would land on vendor dashboard, send to My Account instead.
		if ( zymarg_os_url_matches_page( $redirect_to, $dashboard ) ) {
			return $myaccount;
		}
	}

	return $redirect_to;
}
add_filter( 'login_redirect', 'zymarg_os_vendor_login_redirect', 10, 3 );

/**
 * Check if a URL matches a given page URL (by path prefix).
 *
 * @param string $url  The URL to check.
 * @param string $page The page URL to match against.
 * @return bool
 */
function zymarg_os_url_matches_page( $url, $page ) {
	$url_path  = trailingslashit( wp_parse_url( $url, PHP_URL_PATH ) ?: '/' );
	$page_path = trailingslashit( wp_parse_url( $page, PHP_URL_PATH ) ?: '/' );
	return 0 === strpos( $url_path, $page_path );
}

/**
 * Page access restriction — prevent customers from seeing vendor dashboard
 * and vendors from seeing My Account page.
 *
 * Fires on template_redirect so it catches the page before any output.
 *
 * @return void
 */
function zymarg_os_restrict_role_pages() {
	if ( ! is_user_logged_in() ) {
		return;
	}

	$user  = wp_get_current_user();
	$roles = (array) $user->roles;

	// Admins can see everything.
	$admin_roles = apply_filters( 'zymarg_os_admin_roles', array( 'administrator', 'editor' ) );
	if ( array_intersect( $admin_roles, $roles ) ) {
		return;
	}

	$is_vendor = in_array( 'seller', $roles, true ) || in_array( 'vendor_staff', $roles, true );

	// Vendor trying to access My Account → redirect to dashboard.
	if ( $is_vendor && function_exists( 'is_account_page' ) && is_account_page() ) {
		$dashboard = function_exists( 'dokan_get_navigation_url' )
			? dokan_get_navigation_url( 'dashboard' )
			: home_url( '/dashboard/' );
		wp_safe_redirect( $dashboard );
		exit;
	}

	// Customer trying to access vendor dashboard → redirect to My Account.
	if ( ! $is_vendor && function_exists( 'dokan_is_seller_dashboard' ) && dokan_is_seller_dashboard() ) {
		$myaccount = function_exists( 'wc_get_page_permalink' )
			? wc_get_page_permalink( 'myaccount' )
			: home_url( '/my-account/' );
		wp_safe_redirect( $myaccount );
		exit;
	}
}
add_action( 'template_redirect', 'zymarg_os_restrict_role_pages' );



/** Point the login logo link at the site, with the site name as its text. */
function zymarg_os_login_header_url() {
	return home_url( '/' );
}
add_filter( 'login_headerurl', 'zymarg_os_login_header_url' );

function zymarg_os_login_header_text() {
	return get_bloginfo( 'name' );
}
add_filter( 'login_headertext', 'zymarg_os_login_header_text' );

/* ---------------------------------------------------------------------- *
 * Sanitizers
 * ---------------------------------------------------------------------- */
function zymarg_os_sanitize_login_frequency( $v ) {
	return in_array( $v, array( 'once', 'session', 'days', 'every' ), true ) ? $v : 'once';
}
function zymarg_os_sanitize_login_display( $v ) {
	return in_array( $v, array( 'all', 'include', 'exclude' ), true ) ? $v : 'all';
}


/* ---------------------------------------------------------------------- *
 * Customizer
 * ---------------------------------------------------------------------- */

/**
 * Register the Login Customizer section + controls.
 *
 * @param WP_Customize_Manager $wp_customize Customizer manager.
 * @return void
 */
function zymarg_os_login_customizer( $wp_customize ) {
	$d = zymarg_os_login_defaults();

	$wp_customize->add_section(
		'zymarg_os_login_section',
		array(
			'title'       => __( 'Login', 'zymarg-os' ),
			'description' => __( 'Branded login with Password/OTP tabs, Google sign-in, and a first-visit pop-up with independent sizes for mobile, tablet, desktop.', 'zymarg-os' ),
			'panel'       => 'zymarg_os_panel',
			'priority'    => 10,
		)
	);

	$s = 'zymarg_os_login_section';

	/* ===== Pop-up ===== */
	$wp_customize->add_setting( 'zymarg_login_popup', array( 'default' => $d['popup'], 'sanitize_callback' => 'zymarg_os_sanitize_checkbox' ) );
	$wp_customize->add_control( 'zymarg_login_popup', array( 'type' => 'checkbox', 'label' => __( 'Enable first-visit login pop-up', 'zymarg-os' ), 'section' => $s ) );

	$popup = function () { return (bool) get_theme_mod( 'zymarg_login_popup', false ); };

	$wp_customize->add_setting( 'zymarg_login_frequency', array( 'default' => $d['frequency'], 'sanitize_callback' => 'zymarg_os_sanitize_login_frequency' ) );
	$wp_customize->add_control( 'zymarg_login_frequency', array(
		'type' => 'select', 'label' => __( 'Show the pop-up', 'zymarg-os' ), 'section' => $s,
		'choices' => array(
			'once'    => __( 'Once per visitor', 'zymarg-os' ),
			'session' => __( 'Once per browser session', 'zymarg-os' ),
			'days'    => __( 'Once every X days', 'zymarg-os' ),
			'every'   => __( 'Every visit', 'zymarg-os' ),
		),
		'active_callback' => $popup,
	) );


	$wp_customize->add_setting( 'zymarg_login_days', array( 'default' => $d['days'], 'sanitize_callback' => 'absint' ) );
	$wp_customize->add_control( 'zymarg_login_days', array(
		'type' => 'number', 'label' => __( 'Days between showings', 'zymarg-os' ), 'section' => $s,
		'input_attrs' => array( 'min' => 1, 'max' => 365, 'step' => 1 ),
		'active_callback' => function () { return (bool) get_theme_mod( 'zymarg_login_popup', false ) && 'days' === get_theme_mod( 'zymarg_login_frequency', 'once' ); },
	) );

	$wp_customize->add_setting( 'zymarg_login_delay', array( 'default' => $d['delay'], 'sanitize_callback' => 'absint' ) );
	$wp_customize->add_control( 'zymarg_login_delay', array(
		'type' => 'number', 'label' => __( 'Delay before opening (ms)', 'zymarg-os' ), 'section' => $s,
		'input_attrs' => array( 'min' => 0, 'max' => 15000, 'step' => 100 ), 'active_callback' => $popup,
	) );

	$wp_customize->add_setting( 'zymarg_login_trigger_account', array( 'default' => $d['trigger_account'], 'sanitize_callback' => 'zymarg_os_sanitize_checkbox' ) );
	$wp_customize->add_control( 'zymarg_login_trigger_account', array(
		'type' => 'checkbox', 'label' => __( 'Header account icon opens the pop-up', 'zymarg-os' ), 'section' => $s, 'active_callback' => $popup,
	) );

	$wp_customize->add_setting( 'zymarg_login_display', array( 'default' => $d['display'], 'sanitize_callback' => 'zymarg_os_sanitize_login_display' ) );
	$wp_customize->add_control( 'zymarg_login_display', array(
		'type' => 'select', 'label' => __( 'Show the pop-up on', 'zymarg-os' ), 'section' => $s,
		'choices' => array(
			'all'     => __( 'Entire site', 'zymarg-os' ),
			'include' => __( 'Only specific pages', 'zymarg-os' ),
			'exclude' => __( 'All pages except…', 'zymarg-os' ),
		),
		'active_callback' => $popup,
	) );
	$wp_customize->add_setting( 'zymarg_login_pages', array( 'default' => $d['pages'], 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( new Zymarg_Customize_Page_Checkboxes_Control( $wp_customize, 'zymarg_login_pages', array(
		'label'           => __( 'Select pages', 'zymarg-os' ),
		'description'     => __( 'Tick the pages this rule applies to. Tip: exclude your checkout and cart pages.', 'zymarg-os' ),
		'section'         => $s,
		'active_callback' => function () { return (bool) get_theme_mod( 'zymarg_login_popup', false ) && 'all' !== get_theme_mod( 'zymarg_login_display', 'all' ); },
	) ) );


	/* ===== Appearance ===== */
	$wp_customize->add_setting( 'zymarg_login_accent', array( 'default' => $d['accent'], 'sanitize_callback' => 'sanitize_hex_color' ) );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'zymarg_login_accent', array( 'label' => __( 'Accent colour (buttons, tabs)', 'zymarg-os' ), 'section' => $s ) ) );

	$wp_customize->add_setting( 'zymarg_login_card_bg', array( 'default' => $d['card_bg'], 'sanitize_callback' => 'sanitize_hex_color' ) );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'zymarg_login_card_bg', array( 'label' => __( 'Card background', 'zymarg-os' ), 'section' => $s ) ) );

	/* ===== Social login ===== */
	$wp_customize->add_setting( 'zymarg_login_google', array( 'default' => $d['google'], 'sanitize_callback' => 'zymarg_os_sanitize_checkbox' ) );
	$wp_customize->add_control( 'zymarg_login_google', array( 'type' => 'checkbox', 'label' => __( 'Show "Continue with Google" button', 'zymarg-os' ), 'section' => $s ) );

	$wp_customize->add_setting( 'zymarg_login_google_url', array( 'default' => $d['google_url'], 'sanitize_callback' => 'esc_url_raw' ) );
	$wp_customize->add_control( 'zymarg_login_google_url', array(
		'type'        => 'url',
		'label'       => __( 'Google login URL (manual override)', 'zymarg-os' ),
		'description' => __( 'Auto-detected from Nextend Social Login / miniOrange. Only fill this if you want to use a different plugin or custom OAuth URL.', 'zymarg-os' ),
		'section'     => $s,
	) );

	/* ===== Links ===== */
	$wp_customize->add_setting( 'zymarg_login_register_url', array( 'default' => $d['register_url'], 'sanitize_callback' => 'esc_url_raw' ) );
	$wp_customize->add_control( 'zymarg_login_register_url', array(
		'type' => 'url', 'label' => __( 'Registration page URL', 'zymarg-os' ), 'section' => $s,
		'description' => __( 'Defaults to My Account page if left empty.', 'zymarg-os' ),
	) );

	$wp_customize->add_setting( 'zymarg_login_vendor_url', array( 'default' => $d['vendor_url'], 'sanitize_callback' => 'esc_url_raw' ) );
	$wp_customize->add_control( 'zymarg_login_vendor_url', array(
		'type' => 'url', 'label' => __( 'Vendor registration URL', 'zymarg-os' ), 'section' => $s,
		'description' => __( 'Defaults to /vendor-registration/ or Dokan page.', 'zymarg-os' ),
	) );

	/* ===== My Account page popup (separate from general site popup) ===== */
	$wp_customize->add_setting( 'zymarg_login_account_delay', array( 'default' => $d['account_delay'], 'sanitize_callback' => 'absint' ) );
	$wp_customize->add_control( 'zymarg_login_account_delay', array(
		'type' => 'number', 'label' => __( 'My Account popup delay (ms)', 'zymarg-os' ), 'section' => $s,
		'input_attrs' => array( 'min' => 0, 'max' => 5000, 'step' => 100 ),
		'description' => __( 'How fast the popup opens on /my-account/ for logged-out visitors. 0 = instant. Default: 0.', 'zymarg-os' ),
	) );

	$wp_customize->add_setting( 'zymarg_login_account_message', array( 'default' => $d['account_message'], 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'zymarg_login_account_message', array(
		'type' => 'text', 'label' => __( 'My Account placeholder text', 'zymarg-os' ), 'section' => $s,
		'description' => __( 'Text shown behind the popup on /my-account/. Default: "Please sign in to access your account."', 'zymarg-os' ),
	) );

	/* ===== Per-page delay overrides ===== */
	$wp_customize->add_setting( 'zymarg_login_per_page_delays', array( 'default' => $d['per_page_delays'], 'sanitize_callback' => 'sanitize_textarea_field' ) );
	$wp_customize->add_control( new Zymarg_Customize_Page_Delays_Control( $wp_customize, 'zymarg_login_per_page_delays', array(
		'label'       => __( 'Per-page popup delays', 'zymarg-os' ),
		'description' => __( 'Pick a page and set a custom delay (in ms). 0 = instant. Pages not listed use the General delay above.', 'zymarg-os' ),
		'section'     => $s,
	) ) );


	/* ===== Per-device sizes ===== */
	$sizes = array(
		'desktop_width' => __( 'Desktop width (px)', 'zymarg-os' ),
		'desktop_maxh'  => __( 'Desktop max height (px)', 'zymarg-os' ),
		'tablet_width'  => __( 'Tablet width (px)', 'zymarg-os' ),
		'tablet_maxh'   => __( 'Tablet max height (px)', 'zymarg-os' ),
		'mobile_width'  => __( 'Mobile width (px)', 'zymarg-os' ),
		'mobile_maxh'   => __( 'Mobile max height (px)', 'zymarg-os' ),
	);
	foreach ( $sizes as $key => $label ) {
		$wp_customize->add_setting( 'zymarg_login_' . $key, array( 'default' => $d[ $key ], 'sanitize_callback' => 'absint' ) );
		$wp_customize->add_control( 'zymarg_login_' . $key, array(
			'type' => 'number', 'label' => $label, 'section' => $s,
			'input_attrs' => array( 'min' => 240, 'max' => 1200, 'step' => 4 ),
		) );
	}

	$wp_customize->add_setting( 'zymarg_login_mobile_full', array( 'default' => $d['mobile_full'], 'sanitize_callback' => 'zymarg_os_sanitize_checkbox' ) );
	$wp_customize->add_control( 'zymarg_login_mobile_full', array( 'type' => 'checkbox', 'label' => __( 'Full-screen on mobile', 'zymarg-os' ), 'section' => $s ) );

	/* ===== wp-login.php branding ===== */
	$wp_customize->add_setting( 'zymarg_login_brand', array( 'default' => $d['brand'], 'sanitize_callback' => 'zymarg_os_sanitize_checkbox' ) );
	$wp_customize->add_control( 'zymarg_login_brand', array( 'type' => 'checkbox', 'label' => __( 'Brand the WordPress login screen', 'zymarg-os' ), 'section' => $s ) );

	$brand = function () { return (bool) get_theme_mod( 'zymarg_login_brand', true ); };

	$wp_customize->add_setting( 'zymarg_login_brand_bg', array( 'default' => $d['brand_bg'], 'sanitize_callback' => 'sanitize_hex_color' ) );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'zymarg_login_brand_bg', array( 'label' => __( 'Login screen background', 'zymarg-os' ), 'section' => $s, 'active_callback' => $brand ) ) );

	$wp_customize->add_setting( 'zymarg_login_brand_accent', array( 'default' => $d['brand_accent'], 'sanitize_callback' => 'sanitize_hex_color' ) );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'zymarg_login_brand_accent', array( 'label' => __( 'Login screen accent / orb', 'zymarg-os' ), 'section' => $s, 'active_callback' => $brand ) ) );

	$wp_customize->add_setting( 'zymarg_login_brand_logo', array( 'default' => $d['brand_logo'], 'sanitize_callback' => 'esc_url_raw' ) );
	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'zymarg_login_brand_logo', array(
		'label' => __( 'Login screen logo', 'zymarg-os' ),
		'description' => __( 'Defaults to your site logo if left empty.', 'zymarg-os' ),
		'section' => $s, 'active_callback' => $brand,
	) ) );
}
add_action( 'customize_register', 'zymarg_os_login_customizer' );


/* ---------------------------------------------------------------------- *
 * Front-end dynamic CSS (accent, card bg, per-device sizes)
 * ---------------------------------------------------------------------- */

/**
 * Build the login dynamic CSS.
 *
 * @return string
 */
function zymarg_os_login_dynamic_css() {
	if ( ! function_exists( 'zymarg_os_login_opt' ) ) {
		return '';
	}

	$accent  = sanitize_hex_color( (string) zymarg_os_login_opt( 'accent' ) );
	$card_bg = sanitize_hex_color( (string) zymarg_os_login_opt( 'card_bg' ) );

	$dw = absint( zymarg_os_login_opt( 'desktop_width' ) );
	$dh = absint( zymarg_os_login_opt( 'desktop_maxh' ) );
	$tw = absint( zymarg_os_login_opt( 'tablet_width' ) );
	$th = absint( zymarg_os_login_opt( 'tablet_maxh' ) );
	$mw = absint( zymarg_os_login_opt( 'mobile_width' ) );
	$mh = absint( zymarg_os_login_opt( 'mobile_maxh' ) );
	$mf = (bool) zymarg_os_login_opt( 'mobile_full' );

	$css = '';

	$vars = array();
	if ( $accent ) {
		$vars[] = '--zlg-accent:' . $accent;
	}
	if ( $card_bg ) {
		$vars[] = '--zlg-card:' . $card_bg;
	}
	if ( $vars ) {
		$css .= '.zymarg-login,.zymarg-login-modal{' . implode( ';', $vars ) . ';}';
	}

	if ( $dw || $dh ) {
		$rule = array();
		if ( $dw ) { $rule[] = 'width:' . $dw . 'px'; }
		if ( $dh ) { $rule[] = 'max-height:' . $dh . 'px'; }
		$css .= '.zymarg-login-modal__dialog{' . implode( ';', $rule ) . ';}';
	}
	if ( $dw ) {
		$css .= '.zymarg-login--inline{max-width:' . $dw . 'px;}';
	}

	if ( $tw || $th ) {
		$rule = array();
		if ( $tw ) { $rule[] = 'width:' . $tw . 'px'; }
		if ( $th ) { $rule[] = 'max-height:' . $th . 'px'; }
		$css .= '@media (max-width:1024px){.zymarg-login-modal__dialog{' . implode( ';', $rule ) . ';}}';
	}

	$mobile = '@media (max-width:600px){';
	if ( $mf ) {
		$mobile .= '.zymarg-login-modal__dialog{width:100vw;height:100dvh;max-width:100vw;max-height:100dvh;border-radius:0;}';
	} else {
		$rule = array( 'width:' . ( $mw ? $mw . 'px' : 'min(92vw,360px)' ) );
		if ( $mh ) { $rule[] = 'max-height:' . $mh . 'px'; }
		$mobile .= '.zymarg-login-modal__dialog{' . implode( ';', $rule ) . ';}';
	}
	$mobile .= '}';
	$css    .= $mobile;

	return $css;
}


/* ---------------------------------------------------------------------- *
 * Assets
 * ---------------------------------------------------------------------- */

/**
 * Whether the login script/styles are needed on this request.
 *
 * @return bool
 */
function zymarg_os_login_needs_assets() {
	if ( is_user_logged_in() ) {
		$needed = false;
	} else {
		$needed = zymarg_os_login_popup_visible();
	}

	if ( ! $needed ) {
		$post = get_post();
		if ( $post instanceof WP_Post && ( has_shortcode( (string) $post->post_content, 'zymarg_login' ) || has_shortcode( (string) $post->post_content, 'zymarg_login_button' ) ) ) {
			$needed = true;
		}
	}

	// Always load on the My Account page when logged out (branded login card replaces WC form).
	if ( ! $needed && ! is_user_logged_in() && function_exists( 'is_account_page' ) && is_account_page() ) {
		$needed = true;
	}

	return (bool) apply_filters( 'zymarg_os_login_needs_assets', $needed );
}

/**
 * Enqueue the login stylesheet + script when needed.
 *
 * @return void
 */
function zymarg_os_login_enqueue() {
	if ( ! zymarg_os_login_needs_assets() ) {
		return;
	}

	wp_enqueue_style(
		'zymarg-os-component-login',
		ZYMARG_OS_URI . '/components/login.css',
		array( 'zymarg-os-token-colors' ),
		ZYMARG_OS_VERSION
	);

	// Ensure Discovery Spark CSS is loaded for the animated brand mark in the login card.
	if ( wp_style_is( 'zymarg-os-discovery-spark', 'registered' ) ) {
		wp_enqueue_style( 'zymarg-os-discovery-spark' );
	}

	wp_enqueue_script(
		'zymarg-os-login',
		ZYMARG_OS_URI . '/assets/js/login.js',
		array(),
		ZYMARG_OS_VERSION,
		true
	);

	wp_localize_script( 'zymarg-os-login', 'ZymargLogin', array(
		'ajaxUrl'       => admin_url( 'admin-ajax.php' ),
		'nonce'         => wp_create_nonce( 'zymarg-login-nonce' ),
		'nonceLogin'    => wp_create_nonce( 'zymarg-login-nonce' ),
		'nonceLost'     => wp_create_nonce( 'zymarg-lost-password-nonce' ),
		'nonceRegister' => wp_create_nonce( 'zymarg-register-nonce' ),
		'nonceOtp'      => wp_create_nonce( 'zymarg-otp-nonce' ),
	) );
}
add_action( 'wp_enqueue_scripts', 'zymarg_os_login_enqueue', 20 );



/* ---------------------------------------------------------------------- *
 * BULLETPROOF: My Account page integration.
 * ---------------------------------------------------------------------- *
 * Multiple layers ensure the branded login card shows on /my-account/
 * even if Elementor Theme Builder or Dokan overrides the WC template.
 * ---------------------------------------------------------------------- */

/**
 * Force-enable login assets + popup on the account page for logged-out users.
 *
 * @return void
 */
function zymarg_os_force_login_on_myaccount() {
	if ( is_admin() || is_user_logged_in() ) {
		return;
	}
	if ( ! function_exists( 'is_account_page' ) || ! is_account_page() ) {
		return;
	}

	// Force the login popup on this page.
	add_filter( 'zymarg_os_login_popup_enabled', '__return_true' );
	add_filter( 'zymarg_os_login_needs_assets', '__return_true' );
}
add_action( 'wp', 'zymarg_os_force_login_on_myaccount', 5 );

/**
 * Hide WooCommerce's default login form if it renders (e.g. via plugin override)
 * so only the branded ZYMARG popup is visible on /my-account/ for logged-out users.
 *
 * @return void
 */
function zymarg_os_myaccount_login_fallback() {
	if ( is_user_logged_in() ) {
		return;
	}
	if ( ! function_exists( 'is_account_page' ) || ! is_account_page() ) {
		return;
	}
	?>
	<style id="zymarg-myaccount-login-overrides">
	/* Hide WooCommerce's default login/register form on /my-account/
	   so only the branded ZYMARG popup is visible. */
	body.woocommerce-account:not(.logged-in) .woocommerce-form-login,
	body.woocommerce-account:not(.logged-in) .woocommerce-form-register,
	body.woocommerce-account:not(.logged-in) .u-columns,
	body.woocommerce-account:not(.logged-in) .u-column1,
	body.woocommerce-account:not(.logged-in) .u-column2,
	body.woocommerce-account:not(.logged-in) form.login,
	body.woocommerce-account:not(.logged-in) form.register,
	body.woocommerce-account:not(.logged-in) #customer_login {
		display: none !important;
	}
	/* Centered placeholder behind the popup. */
	.zymarg-myaccount-loggedout {
		min-height: 60vh;
		display: flex;
		align-items: center;
		justify-content: center;
		padding: 24px 16px;
	}
	.zymarg-myaccount-loggedout__placeholder p {
		font-size: 1rem;
		color: var(--color-on-surface-variant, #524250);
		margin: 0;
		text-align: center;
	}
	</style>
	<?php
}
add_action( 'wp_footer', 'zymarg_os_myaccount_login_fallback', 5 );



/**
 * Verify the request came from this same site (cookie-free CSRF check).
 * Works in cached-page contexts where nonces fail.
 *
 * Normalizes 'www.' prefix so a site hosted at example.com still accepts
 * referers from www.example.com (and vice versa).
 *
 * @return bool
 */
function zymarg_os_verify_referer() {
	$referer = isset( $_SERVER['HTTP_REFERER'] ) ? esc_url_raw( wp_unslash( $_SERVER['HTTP_REFERER'] ) ) : '';
	if ( empty( $referer ) ) {
		return false;
	}
	$referer_host = strtolower( (string) wp_parse_url( $referer, PHP_URL_HOST ) );
	$site_host    = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
	if ( '' === $referer_host || '' === $site_host ) {
		return false;
	}
	// Normalize www. on both sides.
	$referer_host = preg_replace( '/^www\./', '', $referer_host );
	$site_host    = preg_replace( '/^www\./', '', $site_host );
	return $referer_host === $site_host;
}

/**
 * Get the real client IP behind common proxies (Cloudflare, Pantheon edge).
 *
 * REMOTE_ADDR alone can return the proxy IP — that would cause a single
 * "client" (the proxy) to consume everyone's rate limit. This helper checks
 * trusted proxy headers in a safe order.
 *
 * @return string
 */
function zymarg_os_get_client_ip() {
	// Cloudflare's authoritative header (cannot be spoofed when CF is the entry).
	if ( ! empty( $_SERVER['HTTP_CF_CONNECTING_IP'] ) ) {
		return sanitize_text_field( wp_unslash( $_SERVER['HTTP_CF_CONNECTING_IP'] ) );
	}
	// Pantheon-style real IP header.
	if ( ! empty( $_SERVER['HTTP_X_REAL_IP'] ) ) {
		return sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_REAL_IP'] ) );
	}
	// X-Forwarded-For is only trustworthy when REMOTE_ADDR is a private/loopback
	// address, which is a reliable sign that a trusted reverse proxy (Nginx, an
	// internal load balancer, etc.) is forwarding the request. If REMOTE_ADDR is
	// a public IP, the header could be forged by the client — reading it would let
	// an attacker rotate fake IPs and bypass the rate limit entirely.
	$remote = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';

	$from_trusted_proxy = $remote && (
		// IPv4 private / loopback ranges.
		substr( $remote, 0, 4 ) === '127.'     ||
		substr( $remote, 0, 3 ) === '10.'      ||
		substr( $remote, 0, 8 ) === '192.168.' ||
		preg_match( '/^172\.(1[6-9]|2\d|3[01])\./', $remote ) ||
		// IPv6 loopback.
		$remote === '::1'
	);

	if ( $from_trusted_proxy && ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
		$xff   = sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_FORWARDED_FOR'] ) );
		$parts = explode( ',', $xff );
		$ip    = trim( $parts[0] );
		if ( $ip ) {
			return $ip;
		}
	}

	return $remote;
}

/**
 * Simple IP-based rate limit using transients (no cookies needed).
 *
 * @param string $action  Action key (e.g. 'register', 'lost_password').
 * @param int    $max     Max requests in the window.
 * @param int    $window  Window in seconds.
 * @return bool True if request is allowed, false if rate-limited.
 */
function zymarg_os_rate_limit( $action, $max = 8, $window = 60 ) {
	$ip = zymarg_os_get_client_ip();
	if ( empty( $ip ) ) {
		return true; // Cannot determine IP, allow.
	}
	$key  = 'zymarg_rl_' . $action . '_' . md5( $ip );
	$hits = (int) get_transient( $key );
	if ( $hits >= $max ) {
		return false;
	}
	set_transient( $key, $hits + 1, $window );
	return true;
}

/**
 * Anti-bot check: honeypot field.
 *
 * Bots fill ALL fields including invisible honeypots. Humans don't.
 *
 * Note: An earlier version also enforced a minimum form-submission time
 * (must be >2s after render), but that caused false positives for users
 * with password managers / browser autofill who can submit in <2s. The
 * honeypot alone catches the vast majority of bots without UX friction.
 *
 * @return bool True if the request looks human, false if it looks like a bot.
 */
function zymarg_os_anti_bot_check() {
	// Honeypot — hidden field 'zlg_website'. Real users leave this blank.
	if ( isset( $_POST['zlg_website'] ) && '' !== trim( (string) wp_unslash( $_POST['zlg_website'] ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return false;
	}
	return true;
}

/* ---------------------------------------------------------------------- *
 * AJAX: Lost Password (inline, no redirect to wp-login.php)
 * ---------------------------------------------------------------------- */

/**
 * AJAX handler — send a password-reset email when the user submits the
 * lost-password form inside the branded card.
 *
 * @return void
 */
function zymarg_os_ajax_lost_password() {
	// Cache-friendly verification (works on cached pages where nonces fail).
	if ( ! zymarg_os_verify_referer() ) {
		wp_send_json_error( array( 'message' => __( 'Security check failed. Please refresh the page and try again.', 'zymarg-os' ) ) );
	}
	if ( ! zymarg_os_rate_limit( 'lost_password', 5, 60 ) ) {
		wp_send_json_error( array( 'message' => __( 'Too many attempts. Please wait a minute and try again.', 'zymarg-os' ) ) );
	}
	// Bot defense: honeypot + form-submission timing. Respond with generic
	// success on bot detection so they can't enumerate accounts via this path.
	if ( ! zymarg_os_anti_bot_check() ) {
		wp_send_json_success( array(
			'message' => __( "If an account exists, a password reset link has been sent.\nCheck your inbox (and spam folder).", 'zymarg-os' ),
		) );
	}

	$user_login = isset( $_POST['user_login'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['user_login'] ) ) ) : '';

	if ( '' === $user_login ) {
		wp_send_json_error( array( 'message' => __( 'Please enter your email or username.', 'zymarg-os' ) ) );
	}

	// Look up the user.
	$user = is_email( $user_login )
		? get_user_by( 'email', $user_login )
		: get_user_by( 'login', $user_login );

	// For security, always return success — never reveal whether an account exists.
	$generic_success = array(
		'message' => __( "If an account exists, a password reset link has been sent.\nCheck your inbox (and spam folder).", 'zymarg-os' ),
	);

	if ( ! $user ) {
		wp_send_json_success( $generic_success );
	}

	// Generate the reset key using WordPress core helpers.
	$key = get_password_reset_key( $user );
	if ( is_wp_error( $key ) ) {
		wp_send_json_error( array( 'message' => $key->get_error_message() ) );
	}

	// Build the reset URL (goes to wp-login.php?action=rp which is branded).
	$reset_url = add_query_arg(
		array(
			'action' => 'rp',
			'key'    => $key,
			'login'  => rawurlencode( $user->user_login ),
		),
		wp_login_url()
	);

	// Compose the email.
	$site_name = wp_specialchars_decode( get_option( 'blogname' ), ENT_QUOTES );
	/* translators: %s: site name */
	$subject = sprintf( __( '[%s] Password Reset Request', 'zymarg-os' ), $site_name );
	/* translators: 1: user display name, 2: reset URL */
	$message = sprintf(
		__( "Hi %1\$s,\n\nSomeone requested a password reset for your account.\nIf this was you, click the link below to set a new password (valid for 24 hours):\n\n%2\$s\n\nIf this wasn't you, you can safely ignore this email.\n", 'zymarg-os' ),
		$user->display_name,
		$reset_url
	);

	$message = (string) apply_filters( 'zymarg_os_lost_password_email', $message, $user, $reset_url );

	// Capture wp_mail delivery errors so we can show a helpful message.
	$mail_error_message = '';
	$capture_error = function ( $wp_error ) use ( &$mail_error_message ) {
		if ( is_wp_error( $wp_error ) ) {
			$mail_error_message = $wp_error->get_error_message();
		}
	};
	add_action( 'wp_mail_failed', $capture_error );

	$sent = wp_mail( $user->user_email, $subject, $message );

	remove_action( 'wp_mail_failed', $capture_error );

	if ( $sent && '' === $mail_error_message ) {
		wp_send_json_success( $generic_success );
	}

	// Delivery failed — most likely no SMTP configured.
	$debug_hint = ( '' !== $mail_error_message ) ? "\n(" . $mail_error_message . ')' : '';
	wp_send_json_error( array(
		'message' => __( "Couldn't send the email.\nYour site likely needs an SMTP plugin (e.g. WP Mail SMTP).", 'zymarg-os' ) . $debug_hint,
	) );
}
add_action( 'wp_ajax_nopriv_zymarg_lost_password', 'zymarg_os_ajax_lost_password' );
add_action( 'wp_ajax_zymarg_lost_password', 'zymarg_os_ajax_lost_password' );

/* ---------------------------------------------------------------------- *
 * AJAX: Register new user (inline, no redirect to wp-login.php)
 * ---------------------------------------------------------------------- */

/**
 * AJAX handler — create a new user account when the user submits the
 * register form inside the branded card, then auto-login them.
 *
 * @return void
 */
function zymarg_os_ajax_register_user() {
	// Cache-friendly verification (works on cached pages where nonces fail).
	if ( ! zymarg_os_verify_referer() ) {
		wp_send_json_error( array( 'message' => __( 'Security check failed. Please refresh the page and try again.', 'zymarg-os' ) ) );
	}
	if ( ! zymarg_os_rate_limit( 'register', 5, 60 ) ) {
		wp_send_json_error( array( 'message' => __( 'Too many attempts. Please wait a minute and try again.', 'zymarg-os' ) ) );
	}
	// Bot defense: honeypot + form-submission timing. We respond with a
	// generic success on honeypot match so bots can't tell they're caught.
	if ( ! zymarg_os_anti_bot_check() ) {
		wp_send_json_success( array( 'message' => __( 'Account created.', 'zymarg-os' ) ) );
	}

	// Block registration if disabled (uses the same helper as the link visibility).
	if ( ! zymarg_os_registration_enabled() ) {
		wp_send_json_error( array( 'message' => __( 'New registrations are currently disabled.', 'zymarg-os' ) ) );
	}

	$email    = isset( $_POST['user_email'] ) ? sanitize_email( wp_unslash( $_POST['user_email'] ) ) : '';
	$password = isset( $_POST['user_pass'] ) ? (string) wp_unslash( $_POST['user_pass'] ) : ''; // phpcs:ignore WordPress.Security

	// Profile fields.
	$first_name = isset( $_POST['first_name'] ) ? sanitize_text_field( wp_unslash( $_POST['first_name'] ) ) : '';
	$last_name  = isset( $_POST['last_name'] ) ? sanitize_text_field( wp_unslash( $_POST['last_name'] ) ) : '';
	$mobile_raw = isset( $_POST['mobile_number'] ) ? sanitize_text_field( wp_unslash( $_POST['mobile_number'] ) ) : '';
	$address    = isset( $_POST['address'] ) ? sanitize_textarea_field( wp_unslash( $_POST['address'] ) ) : '';

	// Strip HTML tags + length-limit names (anti-XSS belt-and-braces — wp_insert_user
	// also sanitizes, but multi-layered defence is good).
	$first_name = mb_substr( trim( wp_strip_all_tags( $first_name ) ), 0, 50 );
	$last_name  = mb_substr( trim( wp_strip_all_tags( $last_name ) ), 0, 50 );
	$address    = mb_substr( trim( $address ), 0, 500 );

	// Phone: keep only digits, +, -, spaces, and parentheses.
	$mobile = preg_replace( '/[^0-9+\-\s()]/', '', $mobile_raw );
	$mobile = mb_substr( trim( $mobile ), 0, 30 );

	// Validate email.
	if ( ! is_email( $email ) ) {
		wp_send_json_error( array( 'message' => __( 'Please enter a valid email address.', 'zymarg-os' ) ) );
	}
	if ( email_exists( $email ) ) {
		wp_send_json_error( array( 'message' => __( 'An account with this email already exists. Try logging in instead.', 'zymarg-os' ) ) );
	}

	// Validate required profile fields.
	if ( '' === $first_name ) {
		wp_send_json_error( array( 'message' => __( 'Please enter your first name.', 'zymarg-os' ) ) );
	}
	if ( '' === $last_name ) {
		wp_send_json_error( array( 'message' => __( 'Please enter your last name.', 'zymarg-os' ) ) );
	}

	// Password strength: 8+ characters AND at least one number OR special char.
	if ( strlen( $password ) < 8 ) {
		wp_send_json_error( array( 'message' => __( 'Password must be at least 8 characters.', 'zymarg-os' ) ) );
	}
	if ( ! preg_match( '/[0-9]/', $password ) && ! preg_match( '/[^a-zA-Z0-9]/', $password ) ) {
		wp_send_json_error( array( 'message' => __( 'Password must include at least one number or special character.', 'zymarg-os' ) ) );
	}

	// Bypass WooCommerce's wc_create_new_customer() chain on purpose: that
	// function runs the `woocommerce_registration_errors` filter, which Dokan
	// hooks to enforce its own vendor-form nonce check — producing the
	// "Nonce verification failed" error users were hitting from our branded
	// card. Going straight through wp_insert_user() with the 'customer' role
	// short-circuits Dokan's filter and still produces a normal WC customer.
	$username = sanitize_user( current( explode( '@', $email ) ), true );
	$base     = $username;
	$i        = 1;
	while ( username_exists( $username ) ) {
		$username = $base . $i;
		$i++;
	}

	$role    = function_exists( 'wc_create_new_customer' ) ? 'customer' : 'subscriber';
	$user_id = wp_insert_user( array(
		'user_login'           => $username,
		'user_email'           => $email,
		'user_pass'            => $password,
		'role'                 => $role,
		'first_name'           => $first_name,
		'last_name'            => $last_name,
		'display_name'         => trim( $first_name . ' ' . $last_name ),
		'nickname'             => $first_name ? $first_name : $username,
		'show_admin_bar_front' => 'false',
	) );

	if ( is_wp_error( $user_id ) ) {
		wp_send_json_error( array( 'message' => wp_strip_all_tags( $user_id->get_error_message() ) ) );
	}
	$user_id = (int) $user_id;

	// Persist the profile + WC billing fields so checkout has them pre-filled.
	update_user_meta( $user_id, 'first_name', $first_name );
	update_user_meta( $user_id, 'last_name', $last_name );
	update_user_meta( $user_id, 'billing_first_name', $first_name );
	update_user_meta( $user_id, 'billing_last_name', $last_name );
	update_user_meta( $user_id, 'billing_email', $email );
	if ( '' !== $mobile ) {
		update_user_meta( $user_id, 'billing_phone', $mobile );
	}
	if ( '' !== $address ) {
		update_user_meta( $user_id, 'billing_address_1', $address );
	}

	// Trigger WooCommerce's branded welcome email if WC is active. This is
	// the same notification wc_create_new_customer() would have sent.
	if ( function_exists( 'WC' ) ) {
		do_action( 'woocommerce_created_customer', $user_id, array( 'user_email' => $email, 'user_login' => $username, 'role' => $role ), true );
	}

	// Auto-login the new user. Detect HTTPS even when SSL is terminated at
	// the edge (Pantheon, Cloudflare) so the auth cookie gets the correct
	// 'Secure' flag and actually persists on the navigation that follows.
	wp_set_current_user( $user_id );
	$secure_cookie = is_ssl()
		|| ( isset( $_SERVER['HTTP_X_FORWARDED_PROTO'] ) && 'https' === strtolower( (string) $_SERVER['HTTP_X_FORWARDED_PROTO'] ) )
		|| ( isset( $_SERVER['HTTP_X_FORWARDED_SSL'] ) && 'on' === strtolower( (string) $_SERVER['HTTP_X_FORWARDED_SSL'] ) );
	wp_set_auth_cookie( $user_id, true, $secure_cookie );

	// Build a redirect URL that is GUARANTEED different from the current
	// page URL — otherwise window.location.href = same_url is a no-op in
	// most browsers and the user sits on the popup screen wondering why
	// nothing happened. Adding ?registered=1 also lets the destination
	// page show a "welcome aboard" message if desired.
	$redirect = '';
	if ( function_exists( 'wc_get_page_permalink' ) ) {
		$redirect = wc_get_page_permalink( 'myaccount' );
	}
	if ( empty( $redirect ) ) {
		$redirect = home_url( '/my-account/' );
	}
	$redirect = add_query_arg( array( 'registered' => '1' ), $redirect );

	wp_send_json_success( array(
		'message'       => __( 'Account created! Redirecting…', 'zymarg-os' ),
		'redirect'      => esc_url_raw( $redirect ),
		'theme_version' => defined( 'ZYMARG_OS_VERSION' ) ? ZYMARG_OS_VERSION : 'unknown',
	) );
}
add_action( 'wp_ajax_nopriv_zymarg_register_user', 'zymarg_os_ajax_register_user' );



/* ---------------------------------------------------------------------- *
 * AJAX: Get a fresh nonce (cache-proof)
 * ---------------------------------------------------------------------- *
 * Returns a freshly generated nonce for one of our login actions. Called
 * by the JS form handlers IMMEDIATELY before submitting, so even if the
 * form HTML AND the inline localized-nonce script are both served from
 * an aggressive page cache, the AJAX submission uses a guaranteed-fresh
 * nonce that admin-ajax.php (never cached) generated this exact request.
 * ---------------------------------------------------------------------- */

/**
 * AJAX handler — return a fresh nonce for the requested action.
 *
 * @return void
 */
function zymarg_os_ajax_get_nonce() {
	$for = isset( $_REQUEST['for'] ) ? sanitize_key( wp_unslash( $_REQUEST['for'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification

	$allowed = array(
		'zymarg-login-nonce',
		'zymarg-lost-password-nonce',
		'zymarg-register-nonce',
		'zymarg-otp-nonce',
	);

	if ( ! in_array( $for, $allowed, true ) ) {
		wp_send_json_error( array( 'message' => 'invalid_action' ) );
	}

	nocache_headers();
	wp_send_json_success( array( 'nonce' => wp_create_nonce( $for ) ) );
}
add_action( 'wp_ajax_nopriv_zymarg_get_nonce', 'zymarg_os_ajax_get_nonce' );
add_action( 'wp_ajax_zymarg_get_nonce', 'zymarg_os_ajax_get_nonce' );



/* ---------------------------------------------------------------------- *
 * Diagnostic: version endpoint
 * ---------------------------------------------------------------------- *
 * Visit /wp-admin/admin-ajax.php?action=zymarg_version in a browser to
 * confirm which version of the theme PHP is actually serving. Useful
 * when caching / OPcache makes it unclear whether new code is deployed.
 * ---------------------------------------------------------------------- */
function zymarg_os_ajax_version() {
	nocache_headers();
	wp_send_json_success( array(
		'theme'         => 'ZYMARG OS',
		'version'       => defined( 'ZYMARG_OS_VERSION' ) ? ZYMARG_OS_VERSION : 'unknown',
		'nonce_removed' => true,
		'auth_method'   => 'referer + rate-limit (no nonce since v4.8.10)',
		'timestamp'     => time(),
	) );
}
add_action( 'wp_ajax_nopriv_zymarg_version', 'zymarg_os_ajax_version' );
add_action( 'wp_ajax_zymarg_version', 'zymarg_os_ajax_version' );
