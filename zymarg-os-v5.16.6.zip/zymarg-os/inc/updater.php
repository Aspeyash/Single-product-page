<?php
/**
 * Self-hosted theme updater.
 *
 * Because ZYMARG OS is not distributed through the WordPress.org theme
 * directory, this hooks into WordPress's native theme-update system so updates
 * appear under Dashboard -> Updates / Appearance -> Themes just like any other
 * theme.
 *
 * HOW IT WORKS
 * ------------
 * Point the theme at a small JSON "manifest" you host anywhere (your site, an
 * S3 bucket, a GitHub release asset, etc.) by either:
 *
 *   define( 'ZYMARG_OS_UPDATE_URI', 'https://example.com/zymarg-os/update.json' );
 *
 * or via filter:
 *
 *   add_filter( 'zymarg_os_update_manifest_url', fn() => 'https://.../update.json' );
 *
 * The manifest must be JSON shaped like:
 * {
 *   "version":      "1.4.0",
 *   "download_url": "https://example.com/zymarg-os/zymarg-os-v1.4.0.zip",
 *   "details_url":  "https://example.com/zymarg-os/changelog",
 *   "requires":     "6.0",
 *   "requires_php": "7.4",
 *   "tested":       "6.7"
 * }
 *
 * When the manifest version is higher than the installed version, WordPress
 * shows the update and can install it with one click. If no manifest URL is
 * configured, this file does nothing — so it's safe out of the box.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Resolve the manifest URL from the constant or filter. Empty = updater off.
 *
 * @return string
 */
function zymarg_os_update_manifest_url() {
	$url = defined( 'ZYMARG_OS_UPDATE_URI' ) ? ZYMARG_OS_UPDATE_URI : '';

	/**
	 * Filter the update manifest URL.
	 *
	 * @param string $url Manifest URL.
	 */
	return (string) apply_filters( 'zymarg_os_update_manifest_url', $url );
}

/**
 * Fetch + cache the remote manifest.
 *
 * @param bool $force Bypass the cache.
 * @return array|null Decoded manifest or null on failure / when disabled.
 */
function zymarg_os_get_update_manifest( $force = false ) {
	$url = zymarg_os_update_manifest_url();
	if ( '' === $url ) {
		return null;
	}

	$cache_key = 'zymarg_os_update_manifest';

	if ( ! $force ) {
		$cached = get_transient( $cache_key );
		if ( is_array( $cached ) ) {
			return $cached;
		}
	}

	$response = wp_remote_get( $url, array( 'timeout' => 15 ) );
	if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
		set_transient( $cache_key, array(), HOUR_IN_SECONDS );
		return null;
	}

	$data = json_decode( wp_remote_retrieve_body( $response ), true );
	if ( ! is_array( $data ) || empty( $data['version'] ) ) {
		set_transient( $cache_key, array(), HOUR_IN_SECONDS );
		return null;
	}

	// Cache for 6 hours.
	set_transient( $cache_key, $data, 6 * HOUR_IN_SECONDS );

	return $data;
}

/**
 * Inject update info into the themes update transient.
 *
 * @param mixed $transient Update transient.
 * @return mixed
 */
function zymarg_os_check_for_update( $transient ) {
	if ( empty( $transient ) || ! is_object( $transient ) ) {
		return $transient;
	}

	$manifest = zymarg_os_get_update_manifest();
	if ( null === $manifest ) {
		return $transient;
	}

	$slug = get_template(); // 'zymarg-os'.

	if ( version_compare( ZYMARG_OS_VERSION, $manifest['version'], '>=' ) ) {
		// Up to date — make sure no stale entry lingers.
		unset( $transient->response[ $slug ] );
		return $transient;
	}

	$transient->response[ $slug ] = array(
		'theme'       => $slug,
		'new_version' => $manifest['version'],
		'url'         => isset( $manifest['details_url'] ) ? $manifest['details_url'] : '',
		'package'     => isset( $manifest['download_url'] ) ? $manifest['download_url'] : '',
		'requires'    => isset( $manifest['requires'] ) ? $manifest['requires'] : '',
		'requires_php'=> isset( $manifest['requires_php'] ) ? $manifest['requires_php'] : '',
	);

	return $transient;
}
add_filter( 'pre_set_site_transient_update_themes', 'zymarg_os_check_for_update' );

/**
 * Clear the cached manifest when WordPress refreshes update data so checks stay
 * reasonably fresh.
 *
 * @return void
 */
function zymarg_os_flush_update_cache() {
	delete_transient( 'zymarg_os_update_manifest' );
}
add_action( 'upgrader_process_complete', 'zymarg_os_flush_update_cache' );
