<?php
/**
 * LearnDash / LMS integration.
 *
 * Applies the ZYMARG colour tokens to common LearnDash UI elements (buttons,
 * progress bars, focus mode accents) without shipping a heavy stylesheet — the
 * rules are injected inline only on LearnDash pages.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Inject LearnDash accent styling inline.
 *
 * @return void
 */
function zymarg_os_learndash_styles() {
	if ( ! defined( 'LEARNDASH_VERSION' ) ) {
		return;
	}

	$css = '
		.learndash-wrapper .ld-button,
		.learndash-wrapper .ld-primary-background,
		.learndash-wrapper .ld-progress-bar .ld-progress-bar-percentage {
			background-color: var(--color-primary) !important;
			color: var(--color-on-primary) !important;
			border-radius: var(--zymarg-radius-sm);
		}
		.learndash-wrapper .ld-button:hover {
			background-color: var(--color-primary-container) !important;
		}
		.learndash-wrapper .ld-primary-color,
		.learndash-wrapper a {
			color: var(--color-primary) !important;
		}
		.learndash-wrapper .ld-focus .ld-focus-sidebar {
			background-color: var(--color-surface);
		}
		.learndash-wrapper .ld-item-list .ld-item-list-item.ld-is-current-item {
			border-color: var(--color-primary);
		}
	';

	$handle = wp_style_is( 'zymarg-os-token-colors', 'enqueued' ) ? 'zymarg-os-token-colors' : 'zymarg-os-style';
	wp_add_inline_style( $handle, $css );
}
add_action( 'wp_enqueue_scripts', 'zymarg_os_learndash_styles', 22 );
