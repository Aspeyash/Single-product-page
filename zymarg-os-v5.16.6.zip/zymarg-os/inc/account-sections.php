<?php
/**
 * My Account — Section renderers.
 *
 * Each function renders one section panel for the redesigned My Account page.
 * Called by zymarg_os_account_render_section() which is invoked from
 * inc/account-dashboard.php based on the active endpoint.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Main dispatcher — renders the section panel for the given key.
 *
 * @param string $section Section key.
 */
function zymarg_os_account_render_section( $section ) {
	/*
	 * WooCommerce order sub-pages (single order view, order received, pay for
	 * order, add payment method) have their own endpoint content. Render that
	 * via woocommerce_account_content() so the "View" button on an order opens
	 * the real order details inside our branded shell — rather than falling
	 * through to the Dashboard.
	 */
	if ( function_exists( 'is_wc_endpoint_url' ) && (
		is_wc_endpoint_url( 'view-order' )
		|| is_wc_endpoint_url( 'order-received' )
		|| is_wc_endpoint_url( 'order-pay' )
		|| is_wc_endpoint_url( 'add-payment-method' )
	) ) {
		echo '<div class="section-panel active">';
		woocommerce_account_content();
		echo '</div>';
		return;
	}

	$fn = 'zymarg_os_acc_section_' . str_replace( '-', '_', $section );
	if ( function_exists( $fn ) ) {
		echo '<div class="section-panel active">';
		call_user_func( $fn );
		echo '</div>';
		return;
	}

	// Plugin-registered sections (e.g. Payments from the ZYMARG Wallet plugin).
	if ( function_exists( 'zymarg_os_account_extra_sections' ) ) {
		$extra = zymarg_os_account_extra_sections();
		if ( isset( $extra[ $section ] ) && is_callable( $extra[ $section ]['render_cb'] ) ) {
			echo '<div class="section-panel active">';
			call_user_func( $extra[ $section ]['render_cb'] );
			echo '</div>';
			return;
		}
	}

	// Fallback: let WooCommerce render the default content.
	woocommerce_account_content();
}


/* ======================================================================
   1. DASHBOARD
   ====================================================================== */
function zymarg_os_acc_section_dashboard() {
	$user        = wp_get_current_user();
	$account     = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : home_url( '/my-account/' );
	$order_count = function_exists( 'wc_get_customer_order_count' ) ? (int) wc_get_customer_order_count( $user->ID ) : 0;
	?>
	<div class="panel-header">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="panel-header-home" title="<?php esc_attr_e( 'Go to Homepage', 'zymarg-os' ); ?>"><?php echo zymarg_os_account_icon( 'home' ); ?></a>
		<h2><?php esc_html_e( 'Dashboard', 'zymarg-os' ); ?></h2>
	</div>
	<p class="panel-desc"><?php
		/* translators: %s: user display name */
		printf( esc_html__( 'Welcome back, %s! Here\'s a quick overview of your account activity.', 'zymarg-os' ), esc_html( $user->display_name ) );
	?></p>
	<div class="dash-cards">
		<div class="dash-card" data-goto="orders">
			<div class="dc-icon"><?php echo zymarg_os_account_icon( 'bag' ); ?></div>
			<div class="dc-title"><?php esc_html_e( 'Recent Orders', 'zymarg-os' ); ?></div>
			<div class="dc-desc"><?php printf( esc_html__( '%d orders placed', 'zymarg-os' ), $order_count ); ?></div>
		</div>
		<div class="dash-card" data-goto="wishlist">
			<div class="dc-icon"><?php echo zymarg_os_account_icon( 'heart' ); ?></div>
			<div class="dc-title"><?php esc_html_e( 'Wishlist', 'zymarg-os' ); ?></div>
			<div class="dc-desc"><?php esc_html_e( 'Items you\'ve saved for later', 'zymarg-os' ); ?></div>
		</div>
		<div class="dash-card" data-goto="recently-viewed">
			<div class="dc-icon"><?php echo zymarg_os_account_icon( 'clock' ); ?></div>
			<div class="dc-title"><?php esc_html_e( 'Recently Viewed', 'zymarg-os' ); ?></div>
			<div class="dc-desc"><?php esc_html_e( 'Products you browsed', 'zymarg-os' ); ?></div>
		</div>
		<div class="dash-card" data-goto="notifications">
			<div class="dc-icon"><?php echo zymarg_os_account_icon( 'bell' ); ?></div>
			<div class="dc-title"><?php esc_html_e( 'Notifications', 'zymarg-os' ); ?></div>
			<div class="dc-desc"><?php esc_html_e( 'Updates & alerts', 'zymarg-os' ); ?></div>
		</div>
		<div class="dash-card" data-goto="coupons">
			<div class="dc-icon"><?php echo zymarg_os_account_icon( 'ticket' ); ?></div>
			<div class="dc-title"><?php esc_html_e( 'Vouchers', 'zymarg-os' ); ?></div>
			<div class="dc-desc"><?php esc_html_e( 'Discounts ready to use', 'zymarg-os' ); ?></div>
		</div>
	</div>
	<div class="dash-detail" id="dash-detail" style="display:none">
		<div class="gradient-bar"></div>
		<div id="dash-detail-content"></div>
	</div>
	<?php
}


/* ======================================================================
   2. ORDERS
   ====================================================================== */
function zymarg_os_acc_section_orders() {
	$user = wp_get_current_user();
	?>
	<div class="panel-header">
		<?php echo zymarg_os_account_icon( 'bag' ); ?>
		<h2><?php esc_html_e( 'Orders', 'zymarg-os' ); ?></h2>
	</div>
	<div class="tab-bar" data-tabgroup="orders">
		<button class="active" data-tab="orders-all"><?php esc_html_e( 'All', 'zymarg-os' ); ?></button>
		<button data-tab="orders-processing"><?php esc_html_e( 'Processing', 'zymarg-os' ); ?></button>
		<button data-tab="orders-shipped"><?php esc_html_e( 'Shipped', 'zymarg-os' ); ?></button>
		<button data-tab="orders-delivered"><?php esc_html_e( 'Delivered', 'zymarg-os' ); ?></button>
		<button data-tab="orders-cancelled"><?php esc_html_e( 'Cancelled', 'zymarg-os' ); ?></button>
	</div>
	<?php
	// Fetch ALL the customer's recent orders in ONE query, then bucket them
	// in memory per tab (previously this ran 5 separate queries — one per tab).
	$all_orders = wc_get_orders( array(
		'customer_id' => $user->ID,
		'limit'       => 50,
		'orderby'     => 'date',
		'order'       => 'DESC',
	) );

	// "Shipped" statuses are filterable (courier plugins). Normalise to no 'wc-' prefix.
	$shipped_statuses = array_map(
		function ( $s ) { return preg_replace( '/^wc-/', '', $s ); },
		(array) apply_filters( 'zymarg_os_shipped_statuses', array( 'wc-shipped', 'wc-in-transit', 'wc-on-hold' ) )
	);

	$buckets = array( 'all' => array(), 'processing' => array(), 'shipped' => array(), 'delivered' => array(), 'cancelled' => array() );
	foreach ( $all_orders as $o ) {
		$buckets['all'][] = $o;
		$st = $o->get_status();
		if ( 'processing' === $st ) { $buckets['processing'][] = $o; }
		if ( in_array( $st, $shipped_statuses, true ) ) { $buckets['shipped'][] = $o; }
		if ( 'completed' === $st ) { $buckets['delivered'][] = $o; }
		if ( in_array( $st, array( 'cancelled', 'failed' ), true ) ) { $buckets['cancelled'][] = $o; }
	}

	foreach ( $buckets as $tab_key => $orders ) :
		$is_active = ( 'all' === $tab_key ) ? ' active' : '';
		?>
		<div class="tab-content<?php echo $is_active; ?>" id="orders-<?php echo esc_attr( $tab_key ); ?>">
			<?php if ( empty( $orders ) ) : ?>
				<div class="empty-state">
					<?php echo zymarg_os_account_icon( 'bag' ); ?>
					<p><?php esc_html_e( 'No orders found.', 'zymarg-os' ); ?></p>
				</div>
			<?php else : ?>
				<?php foreach ( $orders as $order ) : ?>
					<div class="order-item">
						<div class="order-info">
							<div class="order-id">#<?php echo esc_html( $order->get_order_number() ); ?></div>
							<div class="order-date"><?php echo esc_html( wc_format_datetime( $order->get_date_created() ) ); ?></div>
						</div>
						<div class="order-total"><?php echo wp_kses_post( $order->get_formatted_order_total() ); ?></div>
						<div class="order-actions">
							<span class="status-badge <?php echo esc_attr( sanitize_html_class( $order->get_status() ) ); ?>"><?php echo esc_html( wc_get_order_status_name( $order->get_status() ) ); ?></span>
							<a href="<?php echo esc_url( $order->get_view_order_url() ); ?>" class="btn btn-outline btn-sm"><?php esc_html_e( 'View', 'zymarg-os' ); ?></a>
						</div>
					</div>
				<?php endforeach; ?>
			<?php endif; ?>
		</div>
	<?php endforeach; ?>

	<div style="margin-top:1.5rem">
		<h4 style="font-size:14px;font-weight:600;margin-bottom:12px;color:var(--color-text-body,#131b2e)"><?php esc_html_e( 'Quick Actions', 'zymarg-os' ); ?></h4>
		<?php
		$account_url = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : home_url( '/my-account/' );
		$track_url   = function_exists( 'zymarg_os_account_link' ) ? zymarg_os_account_link( 'track' ) : '';
		if ( ! $track_url ) {
			$track_url = function_exists( 'wc_get_endpoint_url' ) ? wc_get_endpoint_url( 'orders', '', $account_url ) : $account_url;
		}
		$returns_url = function_exists( 'wc_get_endpoint_url' ) ? wc_get_endpoint_url( 'returns', '', $account_url ) : $account_url;

		// "Buy Again" → re-order the most recent order, else go to shop.
		$buy_again_url = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' );
		$last_orders   = wc_get_orders( array( 'customer_id' => $user->ID, 'limit' => 1, 'orderby' => 'date', 'order' => 'DESC', 'status' => array( 'wc-completed', 'wc-processing' ) ) );
		if ( ! empty( $last_orders ) ) {
			$lo = $last_orders[0];
			$buy_again_url = wp_nonce_url( add_query_arg( 'order_again', $lo->get_id(), $buy_again_url ), 'woocommerce-order_again' );
		}
		?>
		<div class="cards-grid">
			<a class="action-card" href="<?php echo esc_url( $track_url ); ?>">
				<div class="ac-icon"><?php echo zymarg_os_account_icon( 'clock' ); ?></div>
				<div><div class="ac-label"><?php esc_html_e( 'Track Order', 'zymarg-os' ); ?></div><div class="ac-sub"><?php esc_html_e( 'Check delivery status', 'zymarg-os' ); ?></div></div>
			</a>
			<a class="action-card" href="<?php echo esc_url( $returns_url ); ?>">
				<div class="ac-icon"><?php echo zymarg_os_account_icon( 'refresh' ); ?></div>
				<div><div class="ac-label"><?php esc_html_e( 'Refund Request', 'zymarg-os' ); ?></div><div class="ac-sub"><?php esc_html_e( 'Start a return', 'zymarg-os' ); ?></div></div>
			</a>
			<a class="action-card" href="<?php echo esc_url( $buy_again_url ); ?>">
				<div class="ac-icon"><?php echo zymarg_os_account_icon( 'bag' ); ?></div>
				<div><div class="ac-label"><?php esc_html_e( 'Buy Again', 'zymarg-os' ); ?></div><div class="ac-sub"><?php esc_html_e( 'Reorder your items', 'zymarg-os' ); ?></div></div>
			</a>
		</div>
	</div>
	<?php
}


/* ======================================================================
   3. WISHLIST
   ====================================================================== */
function zymarg_os_acc_section_wishlist() {
	?>
	<div class="panel-header">
		<?php echo zymarg_os_account_icon( 'heart' ); ?>
		<h2><?php esc_html_e( 'Wishlist', 'zymarg-os' ); ?></h2>
	</div>
	<p class="panel-desc"><?php esc_html_e( 'Items you\'ve saved for later. Add to cart, remove, or move items anytime.', 'zymarg-os' ); ?></p>
	<?php
	/*
	 * Pluggable wishlist content (v5.7.6).
	 *
	 * The theme no longer ships its own wishlist storage/UI. The My Account →
	 * Wishlist tab is now powered by whichever product-grid / wishlist plugin
	 * you have active. There are two ways to wire it up:
	 *
	 *   1. PHP filter `zymarg_os_account_wishlist_content` — your plugin
	 *      returns the wishlist HTML directly.
	 *   2. Customize → ZYMARG OS → Wishlist Integration → paste your plugin's
	 *      shortcode name (without brackets). Defaults to `zymarg_wcpg_wishlist`,
	 *      the shortcode shipped by the ZYMARG WC Product Grid plugin v1.4.6+.
	 *
	 * If neither is configured (or the shortcode resolves to an empty string),
	 * a friendly empty state is shown so the panel is never blank.
	 */

	// 1. Try the filter first.
	$content = (string) apply_filters( 'zymarg_os_account_wishlist_content', '' );

	// 2. Fall back to the Customizer-set shortcode.
	if ( '' === $content ) {
		$shortcode = trim( (string) get_theme_mod( 'zymarg_os_account_wishlist_shortcode', 'zymarg_wcpg_wishlist' ) );
		if ( '' !== $shortcode && shortcode_exists( $shortcode ) ) {
			$content = do_shortcode( '[' . $shortcode . ']' );
		}
	}

	if ( '' !== trim( wp_strip_all_tags( $content ) ) ) {
		echo $content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- HTML from plugin/shortcode is intentional.
		return;
	}

	// 3. No integration configured → friendly empty state.
	?>
	<div class="empty-state">
		<?php echo zymarg_os_account_icon( 'heart' ); ?>
		<p><?php esc_html_e( 'Your wishlist is empty. Browse products and tap the heart icon to save items.', 'zymarg-os' ); ?></p>
	</div>
	<?php
}

/* ======================================================================
   4. RECENTLY VIEWED
   ====================================================================== */
function zymarg_os_acc_section_recently_viewed() {
	?>
	<div class="panel-header">
		<?php echo zymarg_os_account_icon( 'clock' ); ?>
		<h2><?php esc_html_e( 'Recently Viewed', 'zymarg-os' ); ?></h2>
	</div>
	<p class="panel-desc"><?php esc_html_e( 'Products you\'ve browsed recently — across all your devices. Quick access to items you liked.', 'zymarg-os' ); ?></p>
	<?php
	// Recently Viewed renderer priority order:
	//   1. ZYMARG WC Product Grid shortcode [zymarg_wcpg_recently_viewed] —
	//      renders with the SAME card design as the homepage / category pages.
	//      Available from Product Grid plugin v1.5.2+.
	//   2. ZYMARG Insights' renderer — works even without the Grid plugin,
	//      keeps cross-device server-side history.
	//   3. Friendly "enable plugin" prompt if neither is present.
	if ( shortcode_exists( 'zymarg_wcpg_recently_viewed' ) ) {
		echo do_shortcode( '[zymarg_wcpg_recently_viewed columns="4" limit="20"]' );
	} elseif ( function_exists( 'zymarg_insights_render_recently_viewed' ) ) {
		zymarg_insights_render_recently_viewed( array( 'limit' => 20 ) );
	} else {
		?>
		<div class="empty-state" id="zymarg-recently-viewed-empty">
			<?php echo zymarg_os_account_icon( 'clock' ); ?>
			<p><?php esc_html_e( 'Recently Viewed needs the free ZYMARG Insights or ZYMARG WC Product Grid plugin. Once one is active, the products you browse will appear here automatically.', 'zymarg-os' ); ?></p>
		</div>
		<?php
	}
}


/* ======================================================================
   5. ADDRESSES
   ====================================================================== */
function zymarg_os_acc_section_addresses() {
	// Custom Bangladesh multi-address book (see inc/account-addresses.php).
	if ( function_exists( 'zymarg_os_render_address_book' ) ) {
		zymarg_os_render_address_book();
		return;
	}
	?>
	<div class="panel-header">
		<?php echo zymarg_os_account_icon( 'map-pin' ); ?>
		<h2><?php esc_html_e( 'Addresses', 'zymarg-os' ); ?></h2>
	</div>
	<p class="panel-desc"><?php esc_html_e( 'Manage your delivery addresses.', 'zymarg-os' ); ?></p>
	<?php
	wc_get_template( 'myaccount/my-address.php' );
}

/* ======================================================================
   6. PROFILE (edit-account)
   ====================================================================== */
function zymarg_os_acc_section_profile() {
	?>
	<div class="panel-header">
		<?php echo zymarg_os_account_icon( 'user' ); ?>
		<h2><?php esc_html_e( 'Profile', 'zymarg-os' ); ?></h2>
	</div>
	<p class="panel-desc"><?php esc_html_e( 'Manage your personal information.', 'zymarg-os' ); ?></p>
	<div style="max-width:480px">
	<?php
	// Render WooCommerce's native account edit form.
	wc_get_template( 'myaccount/form-edit-account.php', array( 'user' => wp_get_current_user() ) );
	?>
	</div>
	<?php
}

/* ======================================================================
   7. NOTIFICATIONS
   ====================================================================== */
function zymarg_os_acc_section_notifications() {
	$user_id = get_current_user_id();
	?>
	<div class="panel-header">
		<?php echo zymarg_os_account_icon( 'bell' ); ?>
		<h2><?php esc_html_e( 'Notifications', 'zymarg-os' ); ?></h2>
	</div>
	<p class="panel-desc"><?php esc_html_e( 'Control what notifications you receive.', 'zymarg-os' ); ?></p>

	<!-- Card 1: Alerts -->
	<div class="settings-card" style="margin-bottom:1.5rem">
		<h4 style="font-size:14px;font-weight:600;margin-bottom:12px"><?php esc_html_e( 'Alerts', 'zymarg-os' ); ?></h4>
		<?php
		$alert_prefs = array(
			'order_updates' => array( __( 'Order Updates', 'zymarg-os' ), __( 'Shipping, delivery, and order status changes', 'zymarg-os' ), true ),
			'price_drops'   => array( __( 'Price Drops', 'zymarg-os' ), __( 'Alerts when wishlist items go on sale', 'zymarg-os' ), true ),
			'restock'       => array( __( 'Restock Alerts', 'zymarg-os' ), __( 'Notify when out-of-stock items return', 'zymarg-os' ), false ),
		);
		foreach ( $alert_prefs as $key => $pref ) :
			$saved = get_user_meta( $user_id, 'zymarg_notif_' . $key, true );
			$checked = ( '' === $saved ) ? $pref[2] : (bool) $saved;
			?>
			<div class="toggle-row">
				<div>
					<div class="toggle-label"><?php echo esc_html( $pref[0] ); ?></div>
					<div class="toggle-sub"><?php echo esc_html( $pref[1] ); ?></div>
				</div>
				<label class="toggle-switch">
					<input type="checkbox" name="zymarg_notif_<?php echo esc_attr( $key ); ?>" value="1" <?php checked( $checked ); ?> data-pref="<?php echo esc_attr( $key ); ?>">
					<span class="slider"></span>
				</label>
			</div>
		<?php endforeach; ?>
	</div>

	<!-- Card 2: Email Communication -->
	<div class="settings-card" style="margin-bottom:1.5rem">
		<h4 style="font-size:14px;font-weight:600;margin-bottom:12px"><?php esc_html_e( 'Email Communication', 'zymarg-os' ); ?></h4>
		<?php
		$email_prefs = array(
			'newsletter'   => array( __( 'Newsletter', 'zymarg-os' ), __( 'Weekly curated product picks', 'zymarg-os' ), true ),
			'promo_emails' => array( __( 'Promotional Emails', 'zymarg-os' ), __( 'Sales and special offers', 'zymarg-os' ), false ),
			'order_emails' => array( __( 'Order Emails', 'zymarg-os' ), __( 'Confirmations and updates', 'zymarg-os' ), true ),
		);
		foreach ( $email_prefs as $key => $pref ) :
			$saved = get_user_meta( $user_id, 'zymarg_pref_' . $key, true );
			$checked = ( '' === $saved ) ? $pref[2] : (bool) $saved;
			?>
			<div class="toggle-row">
				<div>
					<div class="toggle-label"><?php echo esc_html( $pref[0] ); ?></div>
					<div class="toggle-sub"><?php echo esc_html( $pref[1] ); ?></div>
				</div>
				<label class="toggle-switch">
					<input type="checkbox" name="zymarg_pref_<?php echo esc_attr( $key ); ?>" value="1" <?php checked( $checked ); ?> data-pref="<?php echo esc_attr( $key ); ?>">
					<span class="slider"></span>
				</label>
			</div>
		<?php endforeach; ?>
	</div>

	<?php
	// Dokan announcements (if available).
	if ( function_exists( 'dokan_get_announcements' ) ) {
		$announcements = dokan_get_announcements( array( 'per_page' => 10 ) );
		if ( ! empty( $announcements ) ) {
			echo '<h4 style="font-size:14px;font-weight:600;margin:1.5rem 0 12px">' . esc_html__( 'Announcements', 'zymarg-os' ) . '</h4>';
			foreach ( $announcements as $ann ) {
				echo '<div class="order-item"><div class="order-info"><div class="order-id">' . esc_html( $ann->post_title ) . '</div><div class="order-date">' . esc_html( get_the_date( '', $ann ) ) . '</div></div></div>';
			}
		}
	}
}


/* ======================================================================
   8. REVIEWS
   ====================================================================== */
function zymarg_os_acc_section_reviews() {
	$user = wp_get_current_user();
	?>
	<div class="panel-header">
		<?php echo zymarg_os_account_icon( 'star' ); ?>
		<h2><?php esc_html_e( 'Reviews', 'zymarg-os' ); ?></h2>
	</div>
	<div class="tab-bar" data-tabgroup="reviews">
		<button class="active" data-tab="reviews-my"><?php esc_html_e( 'My Reviews', 'zymarg-os' ); ?></button>
		<button data-tab="reviews-pending"><?php esc_html_e( 'Pending Reviews', 'zymarg-os' ); ?></button>
	</div>
	<div class="tab-content active" id="reviews-my">
		<?php
		// 'all' rather than 'approve': a buyer must be able to see their own
		// review while it is still held for moderation, otherwise it looks like
		// the submission failed and they write it again.
		$reviews = get_comments( array(
			'user_id' => $user->ID,
			'type'    => 'review',
			'number'  => (int) apply_filters( 'zymarg_os_my_reviews_limit', 50 ),
			'status'  => 'all',
		) );
		// Spam and trashed reviews stay hidden.
		$reviews = array_filter(
			(array) $reviews,
			static function ( $c ) {
				return ! in_array( (string) $c->comment_approved, array( 'spam', 'trash' ), true );
			}
		);
		if ( empty( $reviews ) ) :
		?>
			<div class="empty-state">
				<?php echo zymarg_os_account_icon( 'star' ); ?>
				<p><?php esc_html_e( 'You haven\'t written any reviews yet.', 'zymarg-os' ); ?></p>
			</div>
		<?php else : ?>
			<?php foreach ( $reviews as $review ) : ?>
				<div class="order-item">
					<div class="order-info">
						<div class="order-id"><?php echo esc_html( get_the_title( $review->comment_post_ID ) ); ?></div>
						<div class="order-date"><?php echo esc_html( get_comment_date( '', $review ) ); ?> &mdash; <?php echo esc_html( wp_trim_words( $review->comment_content, 15 ) ); ?></div>
					</div>
					<?php
					$zos_rating   = (int) get_comment_meta( $review->comment_ID, 'rating', true );
					$zos_approved = '1' === (string) $review->comment_approved;
					if ( ! $zos_approved ) :
						?>
						<span class="status-badge pending"><?php esc_html_e( 'Awaiting approval', 'zymarg-os' ); ?></span>
					<?php elseif ( $zos_rating > 0 ) : ?>
						<span class="status-badge delivered"><?php echo esc_html( $zos_rating ); ?> &#9733;</span>
					<?php else : ?>
						<span class="status-badge"><?php esc_html_e( 'No rating', 'zymarg-os' ); ?></span>
					<?php endif; ?>
				</div>
			<?php endforeach; ?>
		<?php endif; ?>
	</div>
	<div class="tab-content" id="reviews-pending">
		<?php
		// The Reviews Engine owns review eligibility. When it is active we ask it
		// directly, per ORDER ITEM, so this list always agrees with what the
		// product page will actually accept. A "Write Review" button that leads to
		// a page with no form is worse than no button at all.
		$has_engine = class_exists( '\ZymargReviewsEngine\Review_Tracker' );

		// Fallback path only (engine inactive): product IDs already reviewed,
		// in ONE query (was an N+1: a query per product per order).
		global $wpdb;
		$reviewed_ids = $wpdb->get_col( $wpdb->prepare(
			"SELECT DISTINCT comment_post_ID FROM {$wpdb->comments} WHERE user_id = %d AND comment_type = 'review'",
			$user->ID
		) );
		$reviewed_ids = array_map( 'intval', (array) $reviewed_ids );

		$orders = wc_get_orders( array(
			'customer_id' => $user->ID,
			'status'      => array( 'wc-completed' ),
			'limit'       => (int) apply_filters( 'zymarg_os_pending_reviews_order_limit', 50 ),
		) );
		$has_pending = false;
		$seen        = array();
		if ( ! empty( $orders ) ) {
			foreach ( $orders as $order ) {
				// Past the review window the engine refuses the submission, so do
				// not offer a button that is guaranteed to fail.
				if ( $has_engine && ! \ZymargReviewsEngine\Review_Tracker::is_within_window( $order ) ) {
					continue;
				}
				foreach ( $order->get_items() as $item_id => $item ) {
					if ( ! is_a( $item, 'WC_Order_Item_Product' ) ) {
						continue;
					}
					$product_id = (int) $item->get_product_id();
					if ( ! $product_id ) {
						continue;
					}

					if ( $has_engine ) {
						// Tracked per order item, matching the engine: buying the
						// same product twice earns two review prompts.
						if ( \ZymargReviewsEngine\Review_Tracker::is_item_reviewed( $item_id ) ) {
							continue;
						}
						$review_url = \ZymargReviewsEngine\Review_Tracker::get_review_url( $product_id, $order->get_id(), (int) $item_id );
						if ( '' === $review_url ) {
							continue;
						}
					} else {
						// Without the engine we can only dedupe by product.
						if ( isset( $seen[ $product_id ] ) || in_array( $product_id, $reviewed_ids, true ) ) {
							continue;
						}
						$seen[ $product_id ] = true;
						$review_url          = get_permalink( $product_id ) . '#reviews';
					}

					$has_pending = true;
					echo '<div class="order-item">';
					echo '<div class="order-info"><div class="order-id">' . esc_html( get_the_title( $product_id ) ) . '</div><div class="order-date">' . esc_html__( 'Purchased', 'zymarg-os' ) . ' ' . esc_html( wc_format_datetime( $order->get_date_created() ) ) . '</div></div>';
					echo '<a href="' . esc_url( $review_url ) . '" class="btn btn-outline btn-sm">' . esc_html__( 'Write Review', 'zymarg-os' ) . '</a>';
					echo '</div>';
				}
			}
		}
		if ( ! $has_pending ) :
		?>
			<div class="empty-state"><p><?php esc_html_e( 'No pending reviews. Purchase items to leave reviews.', 'zymarg-os' ); ?></p></div>
		<?php endif; ?>
	</div>
	<?php
}


/* ======================================================================
   9. VOUCHERS (endpoint slug: coupons)
   ====================================================================== */
function zymarg_os_acc_section_coupons() {
	$user = wp_get_current_user();
	?>
	<div class="panel-header">
		<?php echo zymarg_os_account_icon( 'ticket' ); ?>
		<h2><?php esc_html_e( 'Vouchers', 'zymarg-os' ); ?></h2>
	</div>
	<div class="tab-bar" data-tabgroup="vouchers">
		<button class="active" data-tab="coupons-available"><?php esc_html_e( 'Available', 'zymarg-os' ); ?></button>
		<button data-tab="coupons-used"><?php esc_html_e( 'Used', 'zymarg-os' ); ?></button>
		<button data-tab="coupons-expired"><?php esc_html_e( 'Expired', 'zymarg-os' ); ?></button>
	</div>
	<?php
	// Query coupons and bucket into available / used / expired for this user.
	$user_id_str = (string) $user->ID;
	$available = array();
	$used      = array();
	$expired   = array();

	$coupon_posts = get_posts( array(
		'post_type'      => 'shop_coupon',
		'posts_per_page' => 50,
		'post_status'    => 'publish',
	) );
	foreach ( $coupon_posts as $cp ) {
		$coupon = new WC_Coupon( $cp->ID );
		$emails = $coupon->get_email_restrictions();
		// Skip coupons restricted to other people's emails.
		if ( ! empty( $emails ) && ! in_array( $user->user_email, $emails, true ) ) {
			continue;
		}

		$used_by      = (array) $coupon->get_used_by();
		$has_used     = in_array( $user_id_str, $used_by, true ) || in_array( $user->user_email, $used_by, true );
		$expiry       = $coupon->get_date_expires();
		$is_expired   = $expiry && $expiry->getTimestamp() < time();

		if ( $has_used ) {
			$used[] = $coupon;
		} elseif ( $is_expired ) {
			$expired[] = $coupon;
		} else {
			$available[] = $coupon;
		}
	}
	?>
	<div class="tab-content active" id="coupons-available">
		<?php if ( empty( $available ) ) : ?>
			<div class="empty-state">
				<?php echo zymarg_os_account_icon( 'ticket' ); ?>
				<p><?php esc_html_e( 'No vouchers available right now. Check back for exclusive deals!', 'zymarg-os' ); ?></p>
			</div>
		<?php else : ?>
			<?php foreach ( $available as $coupon ) : ?>
				<div class="order-item">
					<div class="order-info">
						<div class="order-id"><?php echo esc_html( strtoupper( $coupon->get_code() ) ); ?></div>
						<div class="order-date"><?php echo esc_html( $coupon->get_description() ?: $coupon->get_discount_type() . ' - ' . $coupon->get_amount() ); ?></div>
					</div>
					<span class="status-badge approved"><?php esc_html_e( 'Active', 'zymarg-os' ); ?></span>
				</div>
			<?php endforeach; ?>
		<?php endif; ?>
	</div>
	<div class="tab-content" id="coupons-used">
		<?php if ( empty( $used ) ) : ?>
			<div class="empty-state"><p><?php esc_html_e( 'No used vouchers yet.', 'zymarg-os' ); ?></p></div>
		<?php else : ?>
			<?php foreach ( $used as $coupon ) : ?>
				<div class="order-item">
					<div class="order-info">
						<div class="order-id"><?php echo esc_html( strtoupper( $coupon->get_code() ) ); ?></div>
						<div class="order-date"><?php echo esc_html( $coupon->get_description() ?: $coupon->get_discount_type() . ' - ' . $coupon->get_amount() ); ?></div>
					</div>
					<span class="status-badge refunded"><?php esc_html_e( 'Used', 'zymarg-os' ); ?></span>
				</div>
			<?php endforeach; ?>
		<?php endif; ?>
	</div>
	<div class="tab-content" id="coupons-expired">
		<?php if ( empty( $expired ) ) : ?>
			<div class="empty-state"><p><?php esc_html_e( 'No expired vouchers.', 'zymarg-os' ); ?></p></div>
		<?php else : ?>
			<?php foreach ( $expired as $coupon ) : ?>
				<div class="order-item">
					<div class="order-info">
						<div class="order-id"><?php echo esc_html( strtoupper( $coupon->get_code() ) ); ?></div>
						<div class="order-date"><?php esc_html_e( 'Expired', 'zymarg-os' ); ?> <?php echo esc_html( $coupon->get_date_expires() ? wc_format_datetime( $coupon->get_date_expires() ) : '' ); ?></div>
					</div>
					<span class="status-badge cancelled"><?php esc_html_e( 'Expired', 'zymarg-os' ); ?></span>
				</div>
			<?php endforeach; ?>
		<?php endif; ?>
	</div>
	<?php
}


/* ======================================================================
   10. RETURNS & REFUNDS (Dokan Pro)
   ====================================================================== */
function zymarg_os_acc_section_returns() {
	$user = wp_get_current_user();
	?>
	<div class="panel-header">
		<?php echo zymarg_os_account_icon( 'refresh' ); ?>
		<h2><?php esc_html_e( 'Returns & Refunds', 'zymarg-os' ); ?></h2>
	</div>
	<p class="panel-desc"><?php esc_html_e( 'Manage your return requests and track refund status.', 'zymarg-os' ); ?></p>
	<?php
	// Dokan Pro Return & Warranty module integration.
	$has_dokan_rma = class_exists( 'Dokan_RMA' ) || function_exists( 'dokan_rma' );
	if ( $has_dokan_rma ) {
		// Query Dokan refund/return requests for this customer.
		global $wpdb;
		$requests = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}dokan_rma_request WHERE customer_id = %d ORDER BY id DESC LIMIT 20",
			$user->ID
		) );
		if ( ! empty( $requests ) ) {
			foreach ( $requests as $req ) {
				$status_class = sanitize_html_class( $req->status );
				echo '<div class="order-item">';
				echo '<div class="order-info">';
				echo '<div class="order-id">' . esc_html__( 'Request', 'zymarg-os' ) . ' #' . esc_html( $req->id ) . ' &mdash; ' . esc_html__( 'Order', 'zymarg-os' ) . ' #' . esc_html( $req->order_id ) . '</div>';
				echo '<div class="order-date">' . esc_html( $req->created_at ) . '</div>';
				echo '</div>';
				echo '<span class="status-badge ' . $status_class . '">' . esc_html( ucfirst( $req->status ) ) . '</span>';
				echo '</div>';
			}
		} else {
			echo '<div class="empty-state">';
			echo zymarg_os_account_icon( 'refresh' );
			echo '<p>' . esc_html__( 'No return or refund requests. All orders are in good shape!', 'zymarg-os' ) . '</p>';
			echo '</div>';
		}
	} else {
		// Fallback: query WooCommerce refunded orders.
		$refunds = wc_get_orders( array(
			'customer_id' => $user->ID,
			'status'      => array( 'wc-refunded' ),
			'limit'       => 10,
		) );
		if ( ! empty( $refunds ) ) {
			foreach ( $refunds as $order ) {
				echo '<div class="order-item">';
				echo '<div class="order-info"><div class="order-id">#' . esc_html( $order->get_order_number() ) . '</div><div class="order-date">' . esc_html( wc_format_datetime( $order->get_date_created() ) ) . '</div></div>';
				echo '<span class="status-badge refunded">' . esc_html__( 'Refunded', 'zymarg-os' ) . '</span>';
				echo '</div>';
			}
		} else {
			echo '<div class="empty-state">';
			echo zymarg_os_account_icon( 'refresh' );
			echo '<p>' . esc_html__( 'No return or refund requests. All orders are in good shape!', 'zymarg-os' ) . '</p>';
			echo '</div>';
		}
	}
}

/* ======================================================================
   11. SUPPORT (Dokan Store Support)
   ====================================================================== */
function zymarg_os_acc_section_support() {
	?>
	<div class="panel-header">
		<?php echo zymarg_os_account_icon( 'message' ); ?>
		<h2><?php esc_html_e( 'Support', 'zymarg-os' ); ?></h2>
	</div>
	<p class="panel-desc"><?php esc_html_e( 'Get help with your orders, account, or any issues.', 'zymarg-os' ); ?></p>
	<div class="cards-grid">
		<a class="action-card" href="<?php echo esc_url( zymarg_os_account_link( 'contact' ) ); ?>">
			<div class="ac-icon"><?php echo zymarg_os_account_icon( 'message' ); ?></div>
			<div><div class="ac-label"><?php esc_html_e( 'Contact Support', 'zymarg-os' ); ?></div><div class="ac-sub"><?php esc_html_e( 'Chat or email our team', 'zymarg-os' ); ?></div></div>
		</a>
		<a class="action-card" href="<?php echo esc_url( zymarg_os_account_link( 'help' ) ); ?>">
			<div class="ac-icon"><?php echo zymarg_os_account_icon( 'globe' ); ?></div>
			<div><div class="ac-label"><?php esc_html_e( 'Help Center', 'zymarg-os' ); ?></div><div class="ac-sub"><?php esc_html_e( 'FAQs and guides', 'zymarg-os' ); ?></div></div>
		</a>
	</div>
	<?php
	// Dokan Store Support tickets (if module is active).
	if ( class_exists( 'Dokan_Store_Support' ) || function_exists( 'dokan_get_support_topics' ) ) {
		echo '<h4 style="font-size:14px;font-weight:600;margin:1.5rem 0 12px">' . esc_html__( 'Your Support Tickets', 'zymarg-os' ) . '</h4>';
		$topics = get_posts( array(
			'post_type'   => 'dokan_store_support',
			'author'      => get_current_user_id(),
			'numberposts' => 10,
			'post_status' => 'any',
		) );
		if ( ! empty( $topics ) ) {
			foreach ( $topics as $topic ) {
				$status = get_post_status( $topic->ID ) === 'publish' ? 'delivered' : 'processing';
				echo '<div class="order-item">';
				echo '<div class="order-info"><div class="order-id">' . esc_html( $topic->post_title ) . '</div><div class="order-date">' . esc_html( get_the_date( '', $topic ) ) . '</div></div>';
				echo '<span class="status-badge ' . esc_attr( $status ) . '">' . esc_html( ucfirst( get_post_status( $topic->ID ) ) ) . '</span>';
				echo '</div>';
			}
		} else {
			echo '<div class="empty-state"><p>' . esc_html__( 'No support tickets yet.', 'zymarg-os' ) . '</p></div>';
		}
	}
}


/* ======================================================================
   13. SECURITY
   ====================================================================== */
function zymarg_os_acc_section_security() {
	$user = wp_get_current_user();
	?>
	<div class="panel-header">
		<?php echo zymarg_os_account_icon( 'lock' ); ?>
		<h2><?php esc_html_e( 'Security', 'zymarg-os' ); ?></h2>
	</div>
	<p class="panel-desc"><?php esc_html_e( 'Manage your password, active sessions, and account security.', 'zymarg-os' ); ?></p>
	<div style="max-width:480px">
		<h4 style="font-size:14px;font-weight:600;margin-bottom:12px"><?php esc_html_e( 'Change Password', 'zymarg-os' ); ?></h4>
		<form method="post" class="zymarg-password-form">
			<?php wp_nonce_field( 'zymarg_change_password', 'zymarg_pw_nonce' ); ?>
			<div class="form-group">
				<label><?php esc_html_e( 'Current Password', 'zymarg-os' ); ?></label>
				<input type="password" name="password_current" placeholder="<?php esc_attr_e( 'Enter current password', 'zymarg-os' ); ?>" required>
			</div>
			<div class="form-group">
				<label><?php esc_html_e( 'New Password', 'zymarg-os' ); ?></label>
				<input type="password" name="password_1" placeholder="<?php esc_attr_e( 'Enter new password', 'zymarg-os' ); ?>" required>
			</div>
			<div class="form-group">
				<label><?php esc_html_e( 'Confirm New Password', 'zymarg-os' ); ?></label>
				<input type="password" name="password_2" placeholder="<?php esc_attr_e( 'Confirm new password', 'zymarg-os' ); ?>" required>
			</div>
			<button type="submit" class="btn btn-primary" style="margin-bottom:2rem"><?php esc_html_e( 'Update Password', 'zymarg-os' ); ?></button>
		</form>

		<h4 style="font-size:14px;font-weight:600;margin-bottom:12px"><?php esc_html_e( 'Active Sessions', 'zymarg-os' ); ?></h4>
		<div class="settings-card" style="margin-bottom:1.5rem">
			<div style="display:flex;justify-content:space-between;align-items:center">
				<div>
					<div style="font-size:13px;font-weight:600"><?php esc_html_e( 'Current Device', 'zymarg-os' ); ?></div>
					<div style="font-size:11px;color:var(--color-text-muted,#524250);margin-top:2px"><?php echo esc_html( substr( sanitize_text_field( $_SERVER['HTTP_USER_AGENT'] ?? '' ), 0, 60 ) ); ?> &bull; <?php esc_html_e( 'Active now', 'zymarg-os' ); ?></div>
				</div>
				<span class="status-badge delivered"><?php esc_html_e( 'Active', 'zymarg-os' ); ?></span>
			</div>
		</div>

		<h4 style="font-size:14px;font-weight:600;margin-bottom:12px;color:#ba1a1a"><?php esc_html_e( 'Danger Zone', 'zymarg-os' ); ?></h4>
		<button class="btn btn-danger btn-sm" id="btn-delete-account"><?php esc_html_e( 'Delete Account', 'zymarg-os' ); ?></button>
		<p style="font-size:11px;color:var(--color-text-muted,#534152);margin-top:6px"><?php esc_html_e( 'This action is permanent and cannot be undone.', 'zymarg-os' ); ?></p>
	</div>

	<!-- Delete Account Modal -->
	<div class="zymarg-modal-overlay" id="delete-modal">
		<div class="zymarg-modal-box">
			<div class="modal-header-danger">
				<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M10.3 3.2L1.6 18a2 2 0 0 0 1.7 3h17.4a2 2 0 0 0 1.7-3L13.7 3.2a2 2 0 0 0-3.4 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
			</div>
			<h3 class="modal-title"><?php esc_html_e( 'Delete Your Account?', 'zymarg-os' ); ?></h3>
			<div class="modal-warnings">
				<div class="warning-item"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg><span><?php esc_html_e( 'All your orders, wishlist, and purchase history will be permanently deleted', 'zymarg-os' ); ?></span></div>
				<div class="warning-item"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg><span><?php esc_html_e( 'Your saved addresses, reviews, and vouchers will be removed', 'zymarg-os' ); ?></span></div>
				<div class="warning-item"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg><span><?php esc_html_e( 'Any pending orders or refunds will be cancelled', 'zymarg-os' ); ?></span></div>
				<div class="warning-item"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg><span><?php esc_html_e( 'This action is irreversible and cannot be undone', 'zymarg-os' ); ?></span></div>
			</div>
			<form method="post" id="zymarg-delete-form">
				<?php wp_nonce_field( 'zymarg_delete_account', 'zymarg_del_nonce' ); ?>
				<div class="form-group">
					<label><?php esc_html_e( 'Enter your password to confirm', 'zymarg-os' ); ?></label>
					<input type="password" name="confirm_password" id="delete-password" placeholder="<?php esc_attr_e( 'Enter your password', 'zymarg-os' ); ?>" required>
				</div>
				<div class="modal-actions">
					<button type="button" class="btn btn-outline" id="delete-cancel"><?php esc_html_e( 'Cancel', 'zymarg-os' ); ?></button>
					<button type="submit" class="btn btn-danger"><?php esc_html_e( 'Delete My Account', 'zymarg-os' ); ?></button>
				</div>
			</form>
		</div>
	</div>
	<?php
}
