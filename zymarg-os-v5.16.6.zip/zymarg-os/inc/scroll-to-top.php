<?php
/**
 * Scroll-to-top button.
 *
 * Prints a lightweight, accessible floating button just before wp_footer.
 * Fully customizable from the Customizer (ZYMARG OS -> Scroll to Top):
 * background + hover colour, icon colour, icon style, shape, size, position,
 * show-after threshold, an optional scroll-progress ring, hide-on-mobile, and
 * per-page visibility (entire site / exclude pages / only on pages).
 *
 * Behaviour (show/hide on scroll, smooth scroll, progress ring) is handled by
 * assets/js/theme.js.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Default options for the scroll-to-top button.
 *
 * @return array<string,mixed>
 */
function zymarg_os_scrolltop_defaults() {
	return array(
		'bg'          => '#9500a5',
		'bg_hover'    => '#bd00d1',
		'icon_color'  => '#ffffff',
		'icon'        => 'arrow',
		'shape'       => 'circle',   // circle | rounded | pill
		'size'        => 44,         // px
		'position'    => 'right',    // right | left
		'offset'      => 400,        // px scrolled before it appears
		'progress'    => false,      // scroll-progress ring
		'hide_mobile' => false,
		'display'     => 'all',      // all | exclude | include
		'pages'       => '',         // comma-separated IDs / slugs
	);
}

/**
 * Get a single scroll-to-top option (theme_mod) with its default.
 *
 * @param string $key Option key (without the zymarg_scrolltop_ prefix).
 * @return mixed
 */
function zymarg_os_scrolltop_option( $key ) {
	$defaults = zymarg_os_scrolltop_defaults();
	$default  = isset( $defaults[ $key ] ) ? $defaults[ $key ] : '';
	return get_theme_mod( 'zymarg_scrolltop_' . $key, $default );
}

/**
 * The available icon set: key => array( label, svg-inner-markup ).
 *
 * Each SVG uses a 24x24 viewBox and `currentColor` so the icon colour control
 * applies. Markup is static and safe to print.
 *
 * @return array<string,array{label:string,svg:string}>
 */
function zymarg_os_scrolltop_icons() {
	return array(
		'arrow'   => array(
			'label' => __( 'Arrow', 'zymarg-os' ),
			'svg'   => '<path d="M12 5l-7 7 1.41 1.41L11 8.83V19h2V8.83l4.59 4.58L19 12z"/>',
		),
		'chevron' => array(
			'label' => __( 'Chevron', 'zymarg-os' ),
			'svg'   => '<path d="M7.41 15.41 12 10.83l4.59 4.58L18 14l-6-6-6 6z"/>',
		),
		'caret'   => array(
			'label' => __( 'Caret (solid)', 'zymarg-os' ),
			'svg'   => '<path d="M7 14l5-5 5 5z"/>',
		),
		'double'  => array(
			'label' => __( 'Double chevron', 'zymarg-os' ),
			'svg'   => '<path d="M6 17.59 7.41 19 12 14.42 16.59 19 18 17.59l-6-6zM6 11l1.41 1.41L12 7.83l4.59 4.58L18 11l-6-6z"/>',
		),
		'top'     => array(
			'label' => __( 'Align top (bar)', 'zymarg-os' ),
			'svg'   => '<path d="M8 11h3v10h2V11h3l-4-4-4 4zM4 3v2h16V3H4z"/>',
		),
		'circle'  => array(
			'label' => __( 'Arrow in circle', 'zymarg-os' ),
			'svg'   => '<path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 13V9.83l-2.59 2.58L7 11l5-5 5 5-1.41 1.41L13 9.83V15h-2z"/>',
		),
	);
}

/**
 * Whether the current page matches a comma-separated list of IDs / slugs.
 *
 * Recognises numeric post/page IDs, post slugs, and the special tokens
 * "home" (front page / blog) and "shop" (WooCommerce shop).
 *
 * @param string $list Comma-separated list.
 * @return bool
 */
function zymarg_os_scrolltop_page_matches( $list ) {
	$items = array_filter( array_map( 'trim', explode( ',', (string) $list ) ) );
	if ( empty( $items ) ) {
		return false;
	}

	$current_id = (int) get_queried_object_id();
	$slug       = '';
	$object     = get_queried_object();
	if ( $object instanceof WP_Post ) {
		$slug = $object->post_name;
	}

	foreach ( $items as $item ) {
		if ( is_numeric( $item ) ) {
			if ( (int) $item === $current_id ) {
				return true;
			}
			continue;
		}

		$token = sanitize_title( $item );
		if ( '' === $token ) {
			continue;
		}
		if ( 'home' === $token && ( is_front_page() || is_home() ) ) {
			return true;
		}
		if ( 'shop' === $token && function_exists( 'is_shop' ) && is_shop() ) {
			return true;
		}
		if ( $token === $slug ) {
			return true;
		}
	}

	return false;
}

/**
 * Decide whether the button should render on the current request.
 *
 * @return bool
 */
function zymarg_os_scrolltop_should_display() {
	if ( ! zymarg_os_module_enabled( 'scroll_to_top' ) ) {
		return false;
	}

	$mode = zymarg_os_scrolltop_option( 'display' );
	$list = zymarg_os_scrolltop_option( 'pages' );
	$show = true;

	if ( 'exclude' === $mode ) {
		$show = ! zymarg_os_scrolltop_page_matches( $list );
	} elseif ( 'include' === $mode ) {
		$show = zymarg_os_scrolltop_page_matches( $list );
	}

	/**
	 * Filter whether the scroll-to-top button is shown on this request.
	 *
	 * @param bool $show Whether to render the button.
	 */
	return (bool) apply_filters( 'zymarg_os_show_scroll_top', $show );
}

/**
 * Feed the visitor-configured "show after" threshold into the JS config.
 *
 * @param int $offset Default offset in px.
 * @return int
 */
function zymarg_os_scrolltop_filter_offset( $offset ) {
	$value = (int) zymarg_os_scrolltop_option( 'offset' );
	return $value > 0 ? $value : $offset;
}
add_filter( 'zymarg_os_scroll_top_offset', 'zymarg_os_scrolltop_filter_offset' );

/**
 * Render the scroll-to-top button.
 *
 * @return void
 */
function zymarg_os_render_scroll_to_top() {
	if ( ! zymarg_os_scrolltop_should_display() ) {
		return;
	}

	$icons    = zymarg_os_scrolltop_icons();
	$icon_key = (string) zymarg_os_scrolltop_option( 'icon' );
	if ( ! isset( $icons[ $icon_key ] ) ) {
		$icon_key = 'arrow';
	}
	$icon_svg = $icons[ $icon_key ]['svg'];

	$shape       = (string) zymarg_os_scrolltop_option( 'shape' );
	$position    = 'left' === zymarg_os_scrolltop_option( 'position' ) ? 'left' : 'right';
	$progress    = (bool) zymarg_os_scrolltop_option( 'progress' );
	$hide_mobile = (bool) zymarg_os_scrolltop_option( 'hide_mobile' );

	$classes = array( 'zymarg-scroll-top' );
	$classes[] = 'zymarg-scroll-top--' . ( in_array( $shape, array( 'circle', 'rounded', 'pill' ), true ) ? $shape : 'circle' );
	$classes[] = 'zymarg-scroll-top--' . $position;
	if ( $progress ) {
		$classes[] = 'zymarg-scroll-top--progress';
	}
	if ( $hide_mobile ) {
		$classes[] = 'zymarg-scroll-top--hide-mobile';
	}
	?>
	<button type="button" class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>" aria-label="<?php esc_attr_e( 'Scroll back to top', 'zymarg-os' ); ?>">
		<?php if ( $progress ) : ?>
			<svg class="zymarg-scroll-top__ring" viewBox="0 0 44 44" aria-hidden="true" focusable="false">
				<circle class="zymarg-scroll-top__ring-track" cx="22" cy="22" r="20" fill="none" stroke-width="3"></circle>
				<circle class="zymarg-scroll-top__ring-bar" cx="22" cy="22" r="20" fill="none" stroke-width="3" pathLength="100"></circle>
			</svg>
		<?php endif; ?>
		<svg class="zymarg-scroll-top__icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><?php echo $icon_svg; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped — static, trusted SVG markup. ?></svg>
	</button>
	<?php
}
add_action( 'zymarg_os_footer', 'zymarg_os_render_scroll_to_top' );
