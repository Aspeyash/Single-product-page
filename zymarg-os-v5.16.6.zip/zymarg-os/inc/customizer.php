<?php
/**
 * Customizer controls.
 *
 * Adds the "ZYMARG OS" panel with sections for Modules, Colours, Typography
 * (including font source + custom font uploads), Spacing and Buttons. All
 * values are turned into CSS variables by inc/dynamic-css.php.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * The colour settings the Customizer exposes, mapped to CSS variables.
 *
 * @return array<string,array{label:string,default:string,var:string}>
 */
function zymarg_os_color_settings() {
	return array(
		'zymarg_color_primary'            => array( 'label' => __( 'Primary', 'zymarg-os' ), 'default' => '#9500a5', 'var' => '--color-primary' ),
		'zymarg_color_primary_container'  => array( 'label' => __( 'Primary Container', 'zymarg-os' ), 'default' => '#bd00d1', 'var' => '--color-primary-container' ),
		'zymarg_color_on_primary'         => array( 'label' => __( 'On Primary (text on buttons)', 'zymarg-os' ), 'default' => '#ffffff', 'var' => '--color-on-primary' ),
		'zymarg_color_on_primary_fixed'   => array( 'label' => __( 'Heading colour', 'zymarg-os' ), 'default' => '#36003d', 'var' => '--color-on-primary-fixed' ),
		'zymarg_color_secondary'          => array( 'label' => __( 'Secondary', 'zymarg-os' ), 'default' => '#505f76', 'var' => '--color-secondary' ),
		'zymarg_color_text_body'          => array( 'label' => __( 'Body text', 'zymarg-os' ), 'default' => '#131b2e', 'var' => '--color-text-body' ),
		'zymarg_color_text_muted'         => array( 'label' => __( 'Muted text', 'zymarg-os' ), 'default' => '#534152', 'var' => '--color-text-muted' ),
		'zymarg_color_surface'            => array( 'label' => __( 'Surface', 'zymarg-os' ), 'default' => '#faf8ff', 'var' => '--color-surface' ),
		'zymarg_color_surface_container'  => array( 'label' => __( 'Surface Container', 'zymarg-os' ), 'default' => '#eaedff', 'var' => '--color-surface-container' ),
		'zymarg_color_outline_variant'    => array( 'label' => __( 'Borders / outline', 'zymarg-os' ), 'default' => '#d8bfd3', 'var' => '--color-outline-variant' ),
	);
}

/**
 * Dark-mode colour settings, mapped to the same CSS variables (emitted under
 * a [data-theme="dark"] block by inc/dynamic-css.php). Defaults match
 * tokens/dark.css so nothing changes until a value is edited.
 *
 * @return array<string,array{label:string,default:string,var:string}>
 */
function zymarg_os_dark_color_settings() {
	return array(
		'zymarg_dark_primary'           => array( 'label' => __( 'Primary', 'zymarg-os' ), 'default' => '#f0b0ff', 'var' => '--color-primary' ),
		'zymarg_dark_primary_container' => array( 'label' => __( 'Primary Container', 'zymarg-os' ), 'default' => '#8c009d', 'var' => '--color-primary-container' ),
		'zymarg_dark_on_primary_fixed'  => array( 'label' => __( 'Heading colour', 'zymarg-os' ), 'default' => '#ffd6fb', 'var' => '--color-on-primary-fixed' ),
		'zymarg_dark_text_body'         => array( 'label' => __( 'Body text', 'zymarg-os' ), 'default' => '#e8e2ec', 'var' => '--color-text-body' ),
		'zymarg_dark_text_muted'        => array( 'label' => __( 'Muted text', 'zymarg-os' ), 'default' => '#c3b6c6', 'var' => '--color-text-muted' ),
		'zymarg_dark_surface'           => array( 'label' => __( 'Surface (page background)', 'zymarg-os' ), 'default' => '#15111a', 'var' => '--color-surface' ),
		'zymarg_dark_surface_container' => array( 'label' => __( 'Surface Container (cards)', 'zymarg-os' ), 'default' => '#211b28', 'var' => '--color-surface-container' ),
		'zymarg_dark_outline_variant'   => array( 'label' => __( 'Borders / outline', 'zymarg-os' ), 'default' => '#4d444c', 'var' => '--color-outline-variant' ),
	);
}

/**
 * Register Customizer panel, sections, settings and controls.
 *
 * @param WP_Customize_Manager $wp_customize Customizer manager.
 * @return void
 */
function zymarg_os_customize_register( $wp_customize ) {

	$wp_customize->add_panel(
		'zymarg_os_panel',
		array(
			'title'    => __( 'ZYMARG OS', 'zymarg-os' ),
			'priority' => 10,
		)
	);

	/* ------------------------------------------------------------------ *
	 * Modules
	 * ------------------------------------------------------------------ */
	$wp_customize->add_section(
		'zymarg_os_modules_section',
		array(
			'title'       => __( 'Modules', 'zymarg-os' ),
			'description' => __( 'Turn features on/off. Disabled modules load no CSS or JS — keeping the site lean.', 'zymarg-os' ),
			'panel'       => 'zymarg_os_panel',
		)
	);

	foreach ( zymarg_os_default_modules() as $key => $meta ) {
		$setting_id = 'zymarg_os_modules[' . $key . ']';

		$wp_customize->add_setting(
			$setting_id,
			array(
				'type'              => 'option',
				'default'           => ! empty( $meta['default'] ),
				'sanitize_callback' => 'zymarg_os_sanitize_checkbox',
				'capability'        => 'edit_theme_options',
			)
		);

		$wp_customize->add_control(
			$setting_id,
			array(
				'type'        => 'checkbox',
				'label'       => $meta['label'],
				'description' => isset( $meta['description'] ) ? $meta['description'] : '',
				'section'     => 'zymarg_os_modules_section',
			)
		);
	}

	/* ------------------------------------------------------------------ *
	 * Colours
	 * ------------------------------------------------------------------ */
	$wp_customize->add_section(
		'zymarg_os_colors_section',
		array(
			'title' => __( 'Colours', 'zymarg-os' ),
			'panel' => 'zymarg_os_panel',
		)
	);

	// Colour scheme: light / dark / auto / toggle.
	$wp_customize->add_setting(
		'zymarg_color_scheme',
		array(
			'default'           => 'light',
			'sanitize_callback' => 'zymarg_os_sanitize_scheme',
		)
	);
	$wp_customize->add_control(
		'zymarg_color_scheme',
		array(
			'type'        => 'select',
			'label'       => __( 'Color scheme', 'zymarg-os' ),
			'description' => __( 'Choose Light, Dark, Auto (follow the visitor\'s device), or Smart switch — a visitor-controlled Auto / Light / Dark switcher via the [zymarg_theme_toggle] button (choice remembered).', 'zymarg-os' ),
			'section'     => 'zymarg_os_colors_section',
			'choices'     => array(
				'light'  => __( 'Light (default)', 'zymarg-os' ),
				'dark'   => __( 'Dark', 'zymarg-os' ),
				'auto'   => __( 'Auto (follow device)', 'zymarg-os' ),
				'toggle' => __( 'Smart switch (Auto / Light / Dark)', 'zymarg-os' ),
			),
		)
	);

	// Default starting mode for "Smart switch" (before a visitor picks their own).
	$wp_customize->add_setting(
		'zymarg_color_scheme_default',
		array(
			'default'           => 'auto',
			'sanitize_callback' => 'zymarg_os_sanitize_scheme_default',
		)
	);
	$wp_customize->add_control(
		'zymarg_color_scheme_default',
		array(
			'type'            => 'select',
			'label'           => __( 'Smart switch — default mode', 'zymarg-os' ),
			'description'     => __( 'Which mode visitors see first (before they choose). They can still switch, and their choice is remembered.', 'zymarg-os' ),
			'section'         => 'zymarg_os_colors_section',
			'choices'         => array(
				'auto'  => __( 'Auto (follow device)', 'zymarg-os' ),
				'light' => __( 'Light', 'zymarg-os' ),
				'dark'  => __( 'Dark', 'zymarg-os' ),
			),
			'active_callback' => function () {
				return 'toggle' === get_theme_mod( 'zymarg_color_scheme', 'light' );
			},
		)
	);

	foreach ( zymarg_os_color_settings() as $setting_id => $data ) {
		$wp_customize->add_setting(
			$setting_id,
			array(
				'default'           => $data['default'],
				'sanitize_callback' => 'sanitize_hex_color',
				'transport'         => 'postMessage',
			)
		);

		$wp_customize->add_control(
			new WP_Customize_Color_Control(
				$wp_customize,
				$setting_id,
				array(
					'label'   => $data['label'],
					'section' => 'zymarg_os_colors_section',
				)
			)
		);
	}

	// Primary Inverse (the third/brightest gradient colour). Exposed so the
	// brand gradient's end colour is fully controllable.
	$wp_customize->add_setting(
		'zymarg_color_primary_inverse',
		array(
			'default'           => '#fea9ff',
			'sanitize_callback' => 'sanitize_hex_color',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'zymarg_color_primary_inverse',
			array(
				'label'   => __( 'Primary Inverse (gradient end / bright pink)', 'zymarg-os' ),
				'section' => 'zymarg_os_colors_section',
			)
		)
	);

	// Brand gradient — angle + three colour-stop positions.
	$wp_customize->add_setting(
		'zymarg_gradient_angle',
		array(
			'default'           => 135,
			'sanitize_callback' => 'absint',
		)
	);
	$wp_customize->add_control(
		'zymarg_gradient_angle',
		array(
			'type'        => 'number',
			'label'       => __( 'Brand gradient angle (deg)', 'zymarg-os' ),
			'description' => __( 'Direction of the purple → magenta → pink gradient used on primary buttons, headers and cards.', 'zymarg-os' ),
			'section'     => 'zymarg_os_colors_section',
			'input_attrs' => array( 'min' => 0, 'max' => 360, 'step' => 1 ),
		)
	);

	$gradient_stops = array(
		'zymarg_gradient_stop1' => array( 'label' => __( 'Gradient stop 1 — start %', 'zymarg-os' ), 'default' => 0 ),
		'zymarg_gradient_stop2' => array( 'label' => __( 'Gradient stop 2 — middle %', 'zymarg-os' ), 'default' => 60 ),
		'zymarg_gradient_stop3' => array( 'label' => __( 'Gradient stop 3 — end %', 'zymarg-os' ), 'default' => 130 ),
	);
	foreach ( $gradient_stops as $setting_id => $data ) {
		$wp_customize->add_setting(
			$setting_id,
			array(
				'default'           => $data['default'],
				'sanitize_callback' => 'absint',
			)
		);
		$wp_customize->add_control(
			$setting_id,
			array(
				'type'        => 'number',
				'label'       => $data['label'],
				'section'     => 'zymarg_os_colors_section',
				'input_attrs' => array( 'min' => 0, 'max' => 200, 'step' => 1 ),
			)
		);
	}

	/* ------------------------------------------------------------------ *
	 * Dark Mode Colours
	 * ------------------------------------------------------------------ */
	$wp_customize->add_section(
		'zymarg_os_dark_colors_section',
		array(
			'title'       => __( 'Dark Mode Colours', 'zymarg-os' ),
			'description' => __( 'Colours used when the site is in Dark mode (or Auto on a dark device). Only applies when the Color scheme above is Dark, Auto or Smart switch.', 'zymarg-os' ),
			'panel'       => 'zymarg_os_panel',
		)
	);

	$show_dark = function () {
		return in_array( get_theme_mod( 'zymarg_color_scheme', 'light' ), array( 'dark', 'auto', 'toggle' ), true );
	};

	foreach ( zymarg_os_dark_color_settings() as $setting_id => $data ) {
		$wp_customize->add_setting(
			$setting_id,
			array(
				'default'           => $data['default'],
				'sanitize_callback' => 'sanitize_hex_color',
			)
		);
		$wp_customize->add_control(
			new WP_Customize_Color_Control(
				$wp_customize,
				$setting_id,
				array(
					'label'           => $data['label'],
					'section'         => 'zymarg_os_dark_colors_section',
					'active_callback' => $show_dark,
				)
			)
		);
	}

	/* ------------------------------------------------------------------ *
	 * Typography
	 * ------------------------------------------------------------------ */
	$wp_customize->add_section(
		'zymarg_os_typography_section',
		array(
			'title' => __( 'Typography', 'zymarg-os' ),
			'panel' => 'zymarg_os_panel',
		)
	);

	// Font source.
	$wp_customize->add_setting(
		'zymarg_font_source',
		array(
			'default'           => 'google',
			'sanitize_callback' => 'zymarg_os_sanitize_font_source',
		)
	);
	$wp_customize->add_control(
		'zymarg_font_source',
		array(
			'type'        => 'select',
			'label'       => __( 'Font loading', 'zymarg-os' ),
			'description' => __( 'How fonts are delivered. "Self-host" and "System" are fastest; "Custom upload" lets you use your own files.', 'zymarg-os' ),
			'section'     => 'zymarg_os_typography_section',
			'choices'     => array(
				'google' => __( 'Google Fonts (optimised: preconnect + swap)', 'zymarg-os' ),
				'local'  => __( 'Self-host Inter + Sora (auto-download, GDPR-friendly)', 'zymarg-os' ),
				'custom' => __( 'Upload my own fonts', 'zymarg-os' ),
				'system' => __( 'System fonts (no requests)', 'zymarg-os' ),
			),
		)
	);

	// Heading font family NAME (Google Fonts). Shown for the Google source.
	$wp_customize->add_setting(
		'zymarg_font_heading_name',
		array(
			'default'           => 'Sora',
			'sanitize_callback' => 'sanitize_text_field',
		)
	);
	$wp_customize->add_control(
		'zymarg_font_heading_name',
		array(
			'type'            => 'text',
			'label'           => __( 'Heading font (Google Fonts name)', 'zymarg-os' ),
			'description'     => __( 'Type any Google Fonts family name, e.g. Sora, Poppins, Montserrat. Default: Sora.', 'zymarg-os' ),
			'section'         => 'zymarg_os_typography_section',
			'active_callback' => 'zymarg_os_is_google_font_source',
		)
	);

	// Body font family NAME (Google Fonts). Shown for the Google source.
	$wp_customize->add_setting(
		'zymarg_font_body_name',
		array(
			'default'           => 'Inter',
			'sanitize_callback' => 'sanitize_text_field',
		)
	);
	$wp_customize->add_control(
		'zymarg_font_body_name',
		array(
			'type'            => 'text',
			'label'           => __( 'Body font (Google Fonts name)', 'zymarg-os' ),
			'description'     => __( 'Type any Google Fonts family name, e.g. Inter, Roboto, Open Sans. Default: Inter.', 'zymarg-os' ),
			'section'         => 'zymarg_os_typography_section',
			'active_callback' => 'zymarg_os_is_google_font_source',
		)
	);

	// Custom font uploads (shown when source = custom).
	$wp_customize->add_setting(
		'zymarg_custom_font_heading',
		array(
			'default'           => '',
			'sanitize_callback' => 'esc_url_raw',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Upload_Control(
			$wp_customize,
			'zymarg_custom_font_heading',
			array(
				'label'           => __( 'Heading font file', 'zymarg-os' ),
				'description'     => __( 'Upload a .woff2 / .woff / .ttf file for headings.', 'zymarg-os' ),
				'section'         => 'zymarg_os_typography_section',
				'active_callback' => 'zymarg_os_is_custom_font_source',
			)
		)
	);

	$wp_customize->add_setting(
		'zymarg_custom_font_body',
		array(
			'default'           => '',
			'sanitize_callback' => 'esc_url_raw',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Upload_Control(
			$wp_customize,
			'zymarg_custom_font_body',
			array(
				'label'           => __( 'Body font file', 'zymarg-os' ),
				'description'     => __( 'Upload a .woff2 / .woff / .ttf file for body text.', 'zymarg-os' ),
				'section'         => 'zymarg_os_typography_section',
				'active_callback' => 'zymarg_os_is_custom_font_source',
			)
		)
	);

	// Granular typography: base size, line height, heading weight.
	$wp_customize->add_setting(
		'zymarg_font_base_size',
		array(
			'default'           => 16,
			'sanitize_callback' => 'absint',
		)
	);
	$wp_customize->add_control(
		'zymarg_font_base_size',
		array(
			'type'        => 'number',
			'label'       => __( 'Base font size (px)', 'zymarg-os' ),
			'section'     => 'zymarg_os_typography_section',
			'input_attrs' => array(
				'min'  => 12,
				'max'  => 24,
				'step' => 1,
			),
		)
	);

	$wp_customize->add_setting(
		'zymarg_line_height',
		array(
			'default'           => '1.6',
			'sanitize_callback' => 'zymarg_os_sanitize_float',
		)
	);
	$wp_customize->add_control(
		'zymarg_line_height',
		array(
			'type'        => 'number',
			'label'       => __( 'Body line height', 'zymarg-os' ),
			'section'     => 'zymarg_os_typography_section',
			'input_attrs' => array(
				'min'  => 1,
				'max'  => 2.2,
				'step' => 0.05,
			),
		)
	);

	$wp_customize->add_setting(
		'zymarg_heading_weight',
		array(
			'default'           => 600,
			'sanitize_callback' => 'absint',
		)
	);
	$wp_customize->add_control(
		'zymarg_heading_weight',
		array(
			'type'    => 'select',
			'label'   => __( 'Heading weight', 'zymarg-os' ),
			'section' => 'zymarg_os_typography_section',
			'choices' => array(
				400 => __( 'Regular (400)', 'zymarg-os' ),
				500 => __( 'Medium (500)', 'zymarg-os' ),
				600 => __( 'Semi-bold (600)', 'zymarg-os' ),
				700 => __( 'Bold (700)', 'zymarg-os' ),
				800 => __( 'Extra-bold (800)', 'zymarg-os' ),
			),
		)
	);

	// Body font weight.
	$wp_customize->add_setting(
		'zymarg_body_weight',
		array(
			'default'           => 400,
			'sanitize_callback' => 'absint',
		)
	);
	$wp_customize->add_control(
		'zymarg_body_weight',
		array(
			'type'    => 'select',
			'label'   => __( 'Body text weight', 'zymarg-os' ),
			'section' => 'zymarg_os_typography_section',
			'choices' => array(
				300 => __( 'Light (300)', 'zymarg-os' ),
				400 => __( 'Regular (400)', 'zymarg-os' ),
				500 => __( 'Medium (500)', 'zymarg-os' ),
				600 => __( 'Semi-bold (600)', 'zymarg-os' ),
			),
		)
	);

	// Heading line height.
	$wp_customize->add_setting(
		'zymarg_heading_line_height',
		array(
			'default'           => '1.2',
			'sanitize_callback' => 'zymarg_os_sanitize_float',
		)
	);
	$wp_customize->add_control(
		'zymarg_heading_line_height',
		array(
			'type'        => 'number',
			'label'       => __( 'Heading line height', 'zymarg-os' ),
			'section'     => 'zymarg_os_typography_section',
			'input_attrs' => array(
				'min'  => 1,
				'max'  => 2,
				'step' => 0.05,
			),
		)
	);

	// Individual heading sizes — responsive. Each heading has a "small screens"
	// (min) and "large screens" (max) value; the theme builds a fluid clamp()
	// that scales smoothly between them. Leave BOTH at their defaults to keep
	// the theme's original responsive sizing untouched.
	$heading_sizes = array(
		'zymarg_h1_size' => array( 'label' => __( 'H1 size — large screens (rem)', 'zymarg-os' ), 'default' => '3',    'min' => '2',    'min_label' => __( 'H1 size — small screens (rem)', 'zymarg-os' ) ),
		'zymarg_h2_size' => array( 'label' => __( 'H2 size — large screens (rem)', 'zymarg-os' ), 'default' => '2.25', 'min' => '1.6',  'min_label' => __( 'H2 size — small screens (rem)', 'zymarg-os' ) ),
		'zymarg_h3_size' => array( 'label' => __( 'H3 size — large screens (rem)', 'zymarg-os' ), 'default' => '1.75', 'min' => '1.3',  'min_label' => __( 'H3 size — small screens (rem)', 'zymarg-os' ) ),
		'zymarg_h4_size' => array( 'label' => __( 'H4 size — large screens (rem)', 'zymarg-os' ), 'default' => '1.25', 'min' => '1.25', 'min_label' => __( 'H4 size — small screens (rem)', 'zymarg-os' ) ),
		'zymarg_h5_size' => array( 'label' => __( 'H5 size — large screens (rem)', 'zymarg-os' ), 'default' => '1.1',  'min' => '1.1',  'min_label' => __( 'H5 size — small screens (rem)', 'zymarg-os' ) ),
		'zymarg_h6_size' => array( 'label' => __( 'H6 size — large screens (rem)', 'zymarg-os' ), 'default' => '1',    'min' => '1',    'min_label' => __( 'H6 size — small screens (rem)', 'zymarg-os' ) ),
	);
	foreach ( $heading_sizes as $setting_id => $data ) {
		// Min (small screens).
		$wp_customize->add_setting(
			$setting_id . '_min',
			array(
				'default'           => $data['min'],
				'sanitize_callback' => 'zymarg_os_sanitize_float',
			)
		);
		$wp_customize->add_control(
			$setting_id . '_min',
			array(
				'type'        => 'number',
				'label'       => $data['min_label'],
				'section'     => 'zymarg_os_typography_section',
				'input_attrs' => array(
					'min'  => 0.75,
					'max'  => 6,
					'step' => 0.05,
				),
			)
		);

		// Max (large screens) — reuses the Phase 1 setting id.
		$wp_customize->add_setting(
			$setting_id,
			array(
				'default'           => $data['default'],
				'sanitize_callback' => 'zymarg_os_sanitize_float',
			)
		);
		$wp_customize->add_control(
			$setting_id,
			array(
				'type'        => 'number',
				'label'       => $data['label'],
				'section'     => 'zymarg_os_typography_section',
				'input_attrs' => array(
					'min'  => 0.75,
					'max'  => 6,
					'step' => 0.05,
				),
			)
		);
	}

	/* ------------------------------------------------------------------ *
	 * Spacing
	 * ------------------------------------------------------------------ */
	$wp_customize->add_section(
		'zymarg_os_spacing_section',
		array(
			'title' => __( 'Spacing', 'zymarg-os' ),
			'panel' => 'zymarg_os_panel',
		)
	);

	$wp_customize->add_setting(
		'zymarg_content_width_mode',
		array(
			'default'           => 'fixed',
			'sanitize_callback' => 'sanitize_key',
		)
	);
	$wp_customize->add_control(
		'zymarg_content_width_mode',
		array(
			'type'        => 'select',
			'label'       => __( 'Content width mode', 'zymarg-os' ),
			'description' => __( 'Fixed = a constant pixel width. Fluid = a percentage of the screen, capped for readability (great for ultra-wide / 4K displays).', 'zymarg-os' ),
			'section'     => 'zymarg_os_spacing_section',
			'choices'     => array(
				'fixed' => __( 'Fixed width (px)', 'zymarg-os' ),
				'fluid' => __( 'Fluid (% of screen, capped)', 'zymarg-os' ),
			),
		)
	);

	$wp_customize->add_setting(
		'zymarg_content_fluid_pct',
		array(
			'default'           => 90,
			'sanitize_callback' => 'absint',
		)
	);
	$wp_customize->add_control(
		'zymarg_content_fluid_pct',
		array(
			'type'            => 'number',
			'label'           => __( 'Fluid width (% of screen)', 'zymarg-os' ),
			'description'     => __( 'Used in Fluid mode. The content fills this percentage of the screen, but never exceeds the max width below.', 'zymarg-os' ),
			'section'         => 'zymarg_os_spacing_section',
			'input_attrs'     => array(
				'min'  => 50,
				'max'  => 100,
				'step' => 1,
			),
			'active_callback' => function () {
				return 'fluid' === get_theme_mod( 'zymarg_content_width_mode', 'fixed' );
			},
		)
	);

	$wp_customize->add_setting(
		'zymarg_content_width',
		array(
			'default'           => 1200,
			'sanitize_callback' => 'absint',
		)
	);
	$wp_customize->add_control(
		'zymarg_content_width',
		array(
			'type'        => 'number',
			'label'       => __( 'Content max width (px)', 'zymarg-os' ),
			'description' => __( 'In Fixed mode this is the content width. In Fluid mode it is the maximum width cap (so lines stay readable on big screens).', 'zymarg-os' ),
			'section'     => 'zymarg_os_spacing_section',
			'input_attrs' => array(
				'min'  => 700,
				'max'  => 2560,
				'step' => 10,
			),
		)
	);

	// Spacing scale (rem). Drives margins/padding across the theme.
	$spacing_scale = array(
		'zymarg_space_xs' => array( 'label' => __( 'Spacing XS — rem', 'zymarg-os' ), 'default' => '0.5' ),
		'zymarg_space_sm' => array( 'label' => __( 'Spacing SM — rem', 'zymarg-os' ), 'default' => '1' ),
		'zymarg_space_md' => array( 'label' => __( 'Spacing MD — rem', 'zymarg-os' ), 'default' => '1.5' ),
		'zymarg_space_lg' => array( 'label' => __( 'Spacing LG — rem', 'zymarg-os' ), 'default' => '2.5' ),
		'zymarg_space_xl' => array( 'label' => __( 'Spacing XL — rem', 'zymarg-os' ), 'default' => '4' ),
	);
	foreach ( $spacing_scale as $setting_id => $data ) {
		$wp_customize->add_setting(
			$setting_id,
			array(
				'default'           => $data['default'],
				'sanitize_callback' => 'zymarg_os_sanitize_float',
			)
		);
		$wp_customize->add_control(
			$setting_id,
			array(
				'type'        => 'number',
				'label'       => $data['label'],
				'section'     => 'zymarg_os_spacing_section',
				'input_attrs' => array(
					'min'  => 0,
					'max'  => 10,
					'step' => 0.25,
				),
			)
		);
	}

	/* ------------------------------------------------------------------ *
	 * Buttons
	 * ------------------------------------------------------------------ */
	$wp_customize->add_section(
		'zymarg_os_buttons_section',
		array(
			'title' => __( 'Buttons', 'zymarg-os' ),
			'panel' => 'zymarg_os_panel',
		)
	);

	$wp_customize->add_setting(
		'zymarg_button_radius',
		array(
			'default'           => 8,
			'sanitize_callback' => 'absint',
		)
	);
	$wp_customize->add_control(
		'zymarg_button_radius',
		array(
			'type'        => 'number',
			'label'       => __( 'Button corner radius (px)', 'zymarg-os' ),
			'section'     => 'zymarg_os_buttons_section',
			'input_attrs' => array(
				'min'  => 0,
				'max'  => 50,
				'step' => 1,
			),
		)
	);

	// Card corner radius.
	$wp_customize->add_setting(
		'zymarg_card_radius',
		array(
			'default'           => 12,
			'sanitize_callback' => 'absint',
		)
	);
	$wp_customize->add_control(
		'zymarg_card_radius',
		array(
			'type'        => 'number',
			'label'       => __( 'Card corner radius (px)', 'zymarg-os' ),
			'section'     => 'zymarg_os_buttons_section',
			'input_attrs' => array(
				'min'  => 0,
				'max'  => 40,
				'step' => 1,
			),
		)
	);

	$wp_customize->add_section(
		'zymarg_os_spark_section',
		array(
			'title'       => __( 'Brand Spark', 'zymarg-os' ),
			'description' => __( 'Colours of the animated ZYMARG Discovery Spark mark.', 'zymarg-os' ),
			'panel'       => 'zymarg_os_panel',
		)
	);

	$spark_colors = array(
		'zymarg_spark_purple' => array( 'label' => __( 'Spark purple', 'zymarg-os' ), 'default' => '#6833EA' ),
		'zymarg_spark_gold'   => array( 'label' => __( 'Spark gold', 'zymarg-os' ), 'default' => '#FFD166' ),
	);
	foreach ( $spark_colors as $setting_id => $data ) {
		$wp_customize->add_setting(
			$setting_id,
			array(
				'default'           => $data['default'],
				'sanitize_callback' => 'sanitize_hex_color',
			)
		);
		$wp_customize->add_control(
			new WP_Customize_Color_Control(
				$wp_customize,
				$setting_id,
				array(
					'label'   => $data['label'],
					'section' => 'zymarg_os_spark_section',
				)
			)
		);
	}

	/* ------------------------------------------------------------------ *
	 * Scroll to Top
	 * ------------------------------------------------------------------ */
	$wp_customize->add_section(
		'zymarg_os_scrolltop_section',
		array(
			'title'       => __( 'Scroll to Top', 'zymarg-os' ),
			'description' => __( 'Style and control the floating "back to top" button. Requires the Scroll to Top module (ZYMARG OS -> Modules) to be on.', 'zymarg-os' ),
			'panel'       => 'zymarg_os_panel',
		)
	);

	$scrolltop_defaults = zymarg_os_scrolltop_defaults();

	// --- Appearance: colours ---
	$scrolltop_colors = array(
		'zymarg_scrolltop_bg'         => __( 'Background colour', 'zymarg-os' ),
		'zymarg_scrolltop_bg_hover'   => __( 'Background colour (hover)', 'zymarg-os' ),
		'zymarg_scrolltop_icon_color' => __( 'Icon colour', 'zymarg-os' ),
	);
	$scrolltop_color_keys = array(
		'zymarg_scrolltop_bg'         => 'bg',
		'zymarg_scrolltop_bg_hover'   => 'bg_hover',
		'zymarg_scrolltop_icon_color' => 'icon_color',
	);
	foreach ( $scrolltop_colors as $setting_id => $label ) {
		$key = $scrolltop_color_keys[ $setting_id ];
		$wp_customize->add_setting(
			$setting_id,
			array(
				'default'           => $scrolltop_defaults[ $key ],
				'sanitize_callback' => 'sanitize_hex_color',
			)
		);
		$wp_customize->add_control(
			new WP_Customize_Color_Control(
				$wp_customize,
				$setting_id,
				array(
					'label'           => $label,
					'section'         => 'zymarg_os_scrolltop_section',
					'active_callback' => 'zymarg_os_scrolltop_is_enabled',
				)
			)
		);
	}

	// --- Appearance: icon style ---
	$icon_choices = array();
	foreach ( zymarg_os_scrolltop_icons() as $icon_key => $icon_data ) {
		$icon_choices[ $icon_key ] = $icon_data['label'];
	}
	$wp_customize->add_setting(
		'zymarg_scrolltop_icon',
		array(
			'default'           => $scrolltop_defaults['icon'],
			'sanitize_callback' => 'zymarg_os_sanitize_scrolltop_icon',
		)
	);
	$wp_customize->add_control(
		'zymarg_scrolltop_icon',
		array(
			'type'            => 'select',
			'label'           => __( 'Icon', 'zymarg-os' ),
			'section'         => 'zymarg_os_scrolltop_section',
			'choices'         => $icon_choices,
			'active_callback' => 'zymarg_os_scrolltop_is_enabled',
		)
	);

	// --- Appearance: shape ---
	$wp_customize->add_setting(
		'zymarg_scrolltop_shape',
		array(
			'default'           => $scrolltop_defaults['shape'],
			'sanitize_callback' => 'zymarg_os_sanitize_scrolltop_shape',
		)
	);
	$wp_customize->add_control(
		'zymarg_scrolltop_shape',
		array(
			'type'            => 'select',
			'label'           => __( 'Shape', 'zymarg-os' ),
			'section'         => 'zymarg_os_scrolltop_section',
			'choices'         => array(
				'circle'  => __( 'Circle', 'zymarg-os' ),
				'rounded' => __( 'Rounded square', 'zymarg-os' ),
				'pill'    => __( 'Pill', 'zymarg-os' ),
			),
			'active_callback' => 'zymarg_os_scrolltop_is_enabled',
		)
	);

	// --- Appearance: size ---
	$wp_customize->add_setting(
		'zymarg_scrolltop_size',
		array(
			'default'           => $scrolltop_defaults['size'],
			'sanitize_callback' => 'absint',
		)
	);
	$wp_customize->add_control(
		'zymarg_scrolltop_size',
		array(
			'type'            => 'number',
			'label'           => __( 'Button size (px)', 'zymarg-os' ),
			'section'         => 'zymarg_os_scrolltop_section',
			'input_attrs'     => array(
				'min'  => 32,
				'max'  => 80,
				'step' => 1,
			),
			'active_callback' => 'zymarg_os_scrolltop_is_enabled',
		)
	);

	// --- Appearance: horizontal position ---
	$wp_customize->add_setting(
		'zymarg_scrolltop_position',
		array(
			'default'           => $scrolltop_defaults['position'],
			'sanitize_callback' => 'zymarg_os_sanitize_scrolltop_position',
		)
	);
	$wp_customize->add_control(
		'zymarg_scrolltop_position',
		array(
			'type'            => 'select',
			'label'           => __( 'Position', 'zymarg-os' ),
			'section'         => 'zymarg_os_scrolltop_section',
			'choices'         => array(
				'right' => __( 'Bottom right', 'zymarg-os' ),
				'left'  => __( 'Bottom left', 'zymarg-os' ),
			),
			'active_callback' => 'zymarg_os_scrolltop_is_enabled',
		)
	);

	// --- Behaviour: show-after threshold ---
	$wp_customize->add_setting(
		'zymarg_scrolltop_offset',
		array(
			'default'           => $scrolltop_defaults['offset'],
			'sanitize_callback' => 'absint',
		)
	);
	$wp_customize->add_control(
		'zymarg_scrolltop_offset',
		array(
			'type'            => 'number',
			'label'           => __( 'Show after scrolling (px)', 'zymarg-os' ),
			'description'     => __( 'How far down the page a visitor scrolls before the button appears.', 'zymarg-os' ),
			'section'         => 'zymarg_os_scrolltop_section',
			'input_attrs'     => array(
				'min'  => 0,
				'max'  => 4000,
				'step' => 50,
			),
			'active_callback' => 'zymarg_os_scrolltop_is_enabled',
		)
	);

	// --- Behaviour: scroll-progress ring ---
	$wp_customize->add_setting(
		'zymarg_scrolltop_progress',
		array(
			'default'           => $scrolltop_defaults['progress'],
			'sanitize_callback' => 'zymarg_os_sanitize_checkbox',
		)
	);
	$wp_customize->add_control(
		'zymarg_scrolltop_progress',
		array(
			'type'            => 'checkbox',
			'label'           => __( 'Show scroll-progress ring', 'zymarg-os' ),
			'description'     => __( 'Draw a ring around the button that fills as the visitor scrolls down the page.', 'zymarg-os' ),
			'section'         => 'zymarg_os_scrolltop_section',
			'active_callback' => 'zymarg_os_scrolltop_is_enabled',
		)
	);

	// --- Behaviour: hide on mobile ---
	$wp_customize->add_setting(
		'zymarg_scrolltop_hide_mobile',
		array(
			'default'           => $scrolltop_defaults['hide_mobile'],
			'sanitize_callback' => 'zymarg_os_sanitize_checkbox',
		)
	);
	$wp_customize->add_control(
		'zymarg_scrolltop_hide_mobile',
		array(
			'type'            => 'checkbox',
			'label'           => __( 'Hide on mobile', 'zymarg-os' ),
			'description'     => __( 'Hide the button on small screens (under 600px).', 'zymarg-os' ),
			'section'         => 'zymarg_os_scrolltop_section',
			'active_callback' => 'zymarg_os_scrolltop_is_enabled',
		)
	);

	// --- Visibility: display mode ---
	$wp_customize->add_setting(
		'zymarg_scrolltop_display',
		array(
			'default'           => $scrolltop_defaults['display'],
			'sanitize_callback' => 'zymarg_os_sanitize_scrolltop_display',
		)
	);
	$wp_customize->add_control(
		'zymarg_scrolltop_display',
		array(
			'type'            => 'select',
			'label'           => __( 'Where to show', 'zymarg-os' ),
			'section'         => 'zymarg_os_scrolltop_section',
			'choices'         => array(
				'all'     => __( 'Entire site', 'zymarg-os' ),
				'exclude' => __( 'Entire site, except these pages', 'zymarg-os' ),
				'include' => __( 'Only on these pages', 'zymarg-os' ),
			),
			'active_callback' => 'zymarg_os_scrolltop_is_enabled',
		)
	);

	// --- Visibility: page list ---
	$wp_customize->add_setting(
		'zymarg_scrolltop_pages',
		array(
			'default'           => $scrolltop_defaults['pages'],
			'sanitize_callback' => 'sanitize_text_field',
		)
	);
	$wp_customize->add_control(
		'zymarg_scrolltop_pages',
		array(
			'type'            => 'text',
			'label'           => __( 'Pages (IDs or slugs)', 'zymarg-os' ),
			'description'     => __( 'Comma-separated page IDs or slugs for the include/exclude option above. You can also use "home" and "shop". Example: 42, about, contact', 'zymarg-os' ),
			'section'         => 'zymarg_os_scrolltop_section',
			'active_callback' => 'zymarg_os_scrolltop_display_has_list',
		)
	);

	/* ------------------------------------------------------------------ *
	 * Widget Areas
	 * ------------------------------------------------------------------ */
	$wp_customize->add_section(
		'zymarg_os_widgets_section',
		array(
			'title'       => __( 'Widget Areas', 'zymarg-os' ),
			'description' => __( 'Decide which widget areas the theme registers. Turning an area off removes it from Appearance -> Widgets so WordPress cannot auto-fill it with default widgets. Widgets already placed there are kept (moved to Inactive Widgets) and return if you switch the area back on.', 'zymarg-os' ),
			'panel'       => 'zymarg_os_panel',
		)
	);

	$wp_customize->add_setting(
		'zymarg_register_sidebar',
		array(
			'default'           => false,
			'sanitize_callback' => 'zymarg_os_sanitize_checkbox',
		)
	);
	$wp_customize->add_control(
		'zymarg_register_sidebar',
		array(
			'type'        => 'checkbox',
			'label'       => __( 'Enable Sidebar widget area', 'zymarg-os' ),
			'description' => __( 'Off by default. The theme does not display this sidebar anywhere on the front end; enable it only if a plugin needs a registered sidebar.', 'zymarg-os' ),
			'section'     => 'zymarg_os_widgets_section',
		)
	);

	$wp_customize->add_setting(
		'zymarg_widgets_footer_note',
		array(
			'default'           => '',
			'sanitize_callback' => '__return_empty_string',
		)
	);
	$wp_customize->add_control(
		'zymarg_widgets_footer_note',
		array(
			'type'        => 'hidden',
			'label'       => __( 'Footer columns', 'zymarg-os' ),
			'description' => __( 'The Footer Column 1-4 widget areas are registered automatically only when the theme\'s built-in Simple footer is enabled (Header & Footer -> Footer). If you use the ZYMARG Footer plugin or a Block footer, those columns are not registered.', 'zymarg-os' ),
			'section'     => 'zymarg_os_widgets_section',
		)
	);

	/* ------------------------------------------------------------------ *
	 * Wishlist Integration (v5.7.6+)
	 *
	 * The theme's built-in wishlist module was removed in v5.7.6 to keep
	 * ZYMARG OS lightweight. The My Account → Wishlist tab is now powered
	 * by whichever product-grid / wishlist plugin you have active.
	 *
	 * Easiest setup: paste your plugin's shortcode name (without brackets)
	 * below. Defaults to `zymarg_wcpg_wishlist` which is shipped by the
	 * ZYMARG WC Product Grid plugin v1.4.6+.
	 *
	 * For programmatic integration, your plugin can hook the
	 * `zymarg_os_account_wishlist_content` filter and return raw HTML.
	 * ------------------------------------------------------------------ */
	$wp_customize->add_section(
		'zymarg_os_wishlist_integration_section',
		array(
			'title'       => __( 'Wishlist Integration', 'zymarg-os' ),
			'description' => __( 'Wire the My Account → Wishlist tab to your product-grid plugin\'s wishlist. Paste the shortcode name (without brackets) your plugin exposes, e.g. zymarg_wcpg_wishlist. Leave empty to show an empty state in the tab.', 'zymarg-os' ),
			'panel'       => 'zymarg_os_panel',
		)
	);

	$wp_customize->add_setting(
		'zymarg_os_account_wishlist_shortcode',
		array(
			'default'           => 'zymarg_wcpg_wishlist',
			'sanitize_callback' => 'sanitize_key',
		)
	);
	$wp_customize->add_control(
		'zymarg_os_account_wishlist_shortcode',
		array(
			'type'        => 'text',
			'label'       => __( 'Wishlist shortcode (without brackets)', 'zymarg-os' ),
			'description' => __( 'e.g. zymarg_wcpg_wishlist. Your plugin must register this shortcode. The theme will render its output inside the My Account → Wishlist tab.', 'zymarg-os' ),
			'section'     => 'zymarg_os_wishlist_integration_section',
		)
	);

	// Live preview for colours.
	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->get_setting( 'blogname' ) && null;
	}
}
add_action( 'customize_register', 'zymarg_os_customize_register' );

/* ---------------------------------------------------------------------- *
 * Sanitisation + active callbacks
 * ---------------------------------------------------------------------- */

/**
 * Sanitize the colour-scheme select.
 *
 * @param string $value Raw value.
 * @return string
 */
function zymarg_os_sanitize_scheme( $value ) {
	$allowed = array( 'light', 'dark', 'auto', 'toggle' );
	return in_array( $value, $allowed, true ) ? $value : 'light';
}

/**
 * Sanitize a checkbox to a strict boolean.
 *
 * @param mixed $checked Raw value.
 * @return bool
 */
function zymarg_os_sanitize_checkbox( $checked ) {
	return ( isset( $checked ) && true === (bool) $checked );
}

/**
 * Sanitize the font-source select.
 *
 * @param string $value Raw value.
 * @return string
 */
function zymarg_os_sanitize_font_source( $value ) {
	$allowed = array( 'google', 'local', 'custom', 'system' );
	return in_array( $value, $allowed, true ) ? $value : 'google';
}

/**
 * Sanitize a float value.
 *
 * @param mixed $value Raw value.
 * @return float
 */
function zymarg_os_sanitize_float( $value ) {
	return (float) $value;
}

/**
 * Active callback: only show custom-font controls when that source is chosen.
 *
 * @return bool
 */
function zymarg_os_is_custom_font_source() {
	return 'custom' === get_theme_mod( 'zymarg_font_source', 'google' );
}

/**
 * Active callback: only show the Google font-name fields when the Google
 * source is chosen (typing a name only loads from Google in that mode).
 *
 * @return bool
 */
function zymarg_os_is_google_font_source() {
	return 'google' === get_theme_mod( 'zymarg_font_source', 'google' );
}

/**
 * Active callback: only show scroll-to-top controls when that module is on.
 *
 * @return bool
 */
function zymarg_os_scrolltop_is_enabled() {
	return function_exists( 'zymarg_os_module_enabled' ) && zymarg_os_module_enabled( 'scroll_to_top' );
}

/**
 * Active callback: show the page-list field only when include/exclude is chosen
 * (and the module is on).
 *
 * @return bool
 */
function zymarg_os_scrolltop_display_has_list() {
	if ( ! zymarg_os_scrolltop_is_enabled() ) {
		return false;
	}
	$mode = get_theme_mod( 'zymarg_scrolltop_display', 'all' );
	return in_array( $mode, array( 'include', 'exclude' ), true );
}

/**
 * Sanitize the scroll-to-top icon choice.
 *
 * @param string $value Raw value.
 * @return string
 */
function zymarg_os_sanitize_scrolltop_icon( $value ) {
	$allowed = array_keys( zymarg_os_scrolltop_icons() );
	return in_array( $value, $allowed, true ) ? $value : 'arrow';
}

/**
 * Sanitize the scroll-to-top shape.
 *
 * @param string $value Raw value.
 * @return string
 */
function zymarg_os_sanitize_scrolltop_shape( $value ) {
	$allowed = array( 'circle', 'rounded', 'pill' );
	return in_array( $value, $allowed, true ) ? $value : 'circle';
}

/**
 * Sanitize the scroll-to-top horizontal position.
 *
 * @param string $value Raw value.
 * @return string
 */
function zymarg_os_sanitize_scrolltop_position( $value ) {
	return 'left' === $value ? 'left' : 'right';
}

/**
 * Sanitize the scroll-to-top display mode.
 *
 * @param string $value Raw value.
 * @return string
 */
function zymarg_os_sanitize_scrolltop_display( $value ) {
	$allowed = array( 'all', 'exclude', 'include' );
	return in_array( $value, $allowed, true ) ? $value : 'all';
}

/**
 * Enqueue the Customizer live-preview script for colours.
 *
 * @return void
 */
function zymarg_os_customize_preview_js() {
	wp_enqueue_script(
		'zymarg-os-customize-preview',
		ZYMARG_OS_URI . '/assets/js/customize-preview.js',
		array( 'customize-preview' ),
		ZYMARG_OS_VERSION,
		true
	);
}
add_action( 'customize_preview_init', 'zymarg_os_customize_preview_js' );
