<?php
/**
 * Breadcrumbs.
 *
 * A breadcrumb trail with: a helper function, the [zymarg_breadcrumbs]
 * shortcode, optional auto-display (Customize -> ZYMARG OS -> Layout/Spacing),
 * and BreadcrumbList JSON-LD for rich results (unless an SEO plugin handles it).
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Build the breadcrumb trail.
 *
 * @return array<int,array{name:string,url:string}>
 */
function zymarg_os_breadcrumb_items() {
	$items = array();
	$items[] = array(
		'name' => __( 'Home', 'zymarg-os' ),
		'url'  => home_url( '/' ),
	);

	if ( is_front_page() ) {
		return apply_filters( 'zymarg_os_breadcrumb_items', $items );
	}

	if ( function_exists( 'is_shop' ) && is_shop() ) {
		$items[] = array( 'name' => post_type_archive_title( '', false ), 'url' => '' );
	} elseif ( is_singular() ) {
		$post = get_queried_object();
		$type = get_post_type( $post );

		if ( 'product' === $type && function_exists( 'wc_get_page_id' ) ) {
			$shop_id = wc_get_page_id( 'shop' );
			if ( $shop_id > 0 ) {
				$items[] = array( 'name' => get_the_title( $shop_id ), 'url' => get_permalink( $shop_id ) );
			}
			$terms = get_the_terms( $post->ID, 'product_cat' );
			if ( $terms && ! is_wp_error( $terms ) ) {
				$term    = $terms[0];
				$items[] = array( 'name' => $term->name, 'url' => get_term_link( $term ) );
			}
			$items[] = array( 'name' => get_the_title( $post ), 'url' => '' );
		} elseif ( 'page' === $type ) {
			foreach ( array_reverse( get_post_ancestors( $post ) ) as $ancestor ) {
				$items[] = array( 'name' => get_the_title( $ancestor ), 'url' => get_permalink( $ancestor ) );
			}
			$items[] = array( 'name' => get_the_title( $post ), 'url' => '' );
		} elseif ( 'post' === $type ) {
			$cats = get_the_category( $post->ID );
			if ( ! empty( $cats ) ) {
				$items[] = array( 'name' => $cats[0]->name, 'url' => get_category_link( $cats[0] ) );
			}
			$items[] = array( 'name' => get_the_title( $post ), 'url' => '' );
		} else {
			$items[] = array( 'name' => get_the_title( $post ), 'url' => '' );
		}
	} elseif ( is_category() || is_tag() || is_tax() ) {
		$items[] = array( 'name' => single_term_title( '', false ), 'url' => '' );
	} elseif ( is_search() ) {
		/* translators: %s: search query. */
		$items[] = array( 'name' => sprintf( __( 'Search: %s', 'zymarg-os' ), get_search_query() ), 'url' => '' );
	} elseif ( is_author() ) {
		$items[] = array( 'name' => get_the_author(), 'url' => '' );
	} elseif ( is_404() ) {
		$items[] = array( 'name' => __( 'Not found', 'zymarg-os' ), 'url' => '' );
	} elseif ( is_archive() ) {
		$items[] = array( 'name' => wp_strip_all_tags( get_the_archive_title() ), 'url' => '' );
	}

	/**
	 * Filter the breadcrumb items.
	 *
	 * @param array $items Breadcrumb trail.
	 */
	return apply_filters( 'zymarg_os_breadcrumb_items', $items );
}

/**
 * Return the breadcrumb HTML.
 *
 * @return string
 */
function zymarg_os_get_breadcrumbs() {
	$items = zymarg_os_breadcrumb_items();
	if ( count( $items ) < 2 ) {
		return '';
	}

	$sep  = apply_filters( 'zymarg_os_breadcrumb_separator', '/' );
	$html = '<nav class="zymarg-breadcrumbs" aria-label="' . esc_attr__( 'Breadcrumb', 'zymarg-os' ) . '"><ol>';
	$last = count( $items ) - 1;

	foreach ( $items as $i => $item ) {
		$html .= '<li class="zymarg-breadcrumbs__item">';
		if ( $item['url'] && $i !== $last ) {
			$html .= '<a href="' . esc_url( $item['url'] ) . '">' . esc_html( $item['name'] ) . '</a>';
		} else {
			$html .= '<span aria-current="page">' . esc_html( $item['name'] ) . '</span>';
		}
		$html .= '</li>';
		if ( $i !== $last ) {
			$html .= '<li class="zymarg-breadcrumbs__sep" aria-hidden="true">' . esc_html( $sep ) . '</li>';
		}
	}

	$html .= '</ol></nav>';
	return $html;
}

/**
 * Echo the breadcrumbs.
 *
 * @return void
 */
function zymarg_os_breadcrumbs() {
	echo zymarg_os_get_breadcrumbs(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in builder.
}

/** Shortcode: [zymarg_breadcrumbs] */
function zymarg_os_breadcrumbs_shortcode() {
	return zymarg_os_get_breadcrumbs();
}
add_shortcode( 'zymarg_breadcrumbs', 'zymarg_os_breadcrumbs_shortcode' );

/**
 * Auto-display before content when enabled.
 *
 * @return void
 */
function zymarg_os_auto_breadcrumbs() {
	if ( ! get_theme_mod( 'zymarg_breadcrumbs_auto', false ) || is_front_page() ) {
		return;
	}
	echo zymarg_os_get_breadcrumbs(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}
add_action( 'zymarg_os_content_top', 'zymarg_os_auto_breadcrumbs' );
if ( class_exists( 'WooCommerce' ) ) {
	// Remove WooCommerce's default breadcrumb so only the ZYMARG OS breadcrumb
	// is displayed — prevents duplicate breadcrumb trails on shop/product pages.
	remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20 );
	add_action( 'woocommerce_before_main_content', 'zymarg_os_auto_breadcrumbs', 20 );
}

/**
 * Customizer toggle for auto-display.
 *
 * @param WP_Customize_Manager $wp_customize Manager.
 * @return void
 */
function zymarg_os_breadcrumbs_customizer( $wp_customize ) {
	if ( ! $wp_customize->get_section( 'zymarg_os_spacing_section' ) ) {
		return;
	}
	$wp_customize->add_setting( 'zymarg_breadcrumbs_auto', array( 'default' => false, 'sanitize_callback' => 'zymarg_os_sanitize_checkbox' ) );
	$wp_customize->add_control( 'zymarg_breadcrumbs_auto', array(
		'type'        => 'checkbox',
		'label'       => __( 'Show breadcrumbs automatically', 'zymarg-os' ),
		'description' => __( 'Display the breadcrumb trail above content (pages, posts, shop). Or place [zymarg_breadcrumbs] manually.', 'zymarg-os' ),
		'section'     => 'zymarg_os_spacing_section',
	) );
}
add_action( 'customize_register', 'zymarg_os_breadcrumbs_customizer', 20 );

/**
 * Output BreadcrumbList JSON-LD (only if the Schema module is on and no SEO
 * plugin is handling structured data).
 *
 * @return void
 */
function zymarg_os_breadcrumb_schema() {
	if ( ! zymarg_os_module_enabled( 'schema' ) || zymarg_os_seo_plugin_active() || is_front_page() ) {
		return;
	}

	$items = zymarg_os_breadcrumb_items();
	if ( count( $items ) < 2 ) {
		return;
	}

	$list = array();
	$pos  = 1;
	foreach ( $items as $item ) {
		$entry = array(
			'@type'    => 'ListItem',
			'position' => $pos,
			'name'     => $item['name'],
		);
		if ( $item['url'] ) {
			$entry['item'] = $item['url'];
		}
		$list[] = $entry;
		$pos++;
	}

	$data = array(
		'@context'        => 'https://schema.org',
		'@type'           => 'BreadcrumbList',
		'itemListElement' => $list,
	);

	echo "\n" . '<script type="application/ld+json">' . wp_json_encode( $data ) . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}
add_action( 'wp_head', 'zymarg_os_breadcrumb_schema' );
