<?php
/**
 * Custom Customizer Controls for ZYMARG OS.
 *
 * Provides:
 *   - Zymarg_Customize_Page_Checkboxes_Control: a scrollable list of page
 *     checkboxes that saves a comma-separated string of page IDs.
 *   - Zymarg_Customize_Page_Delays_Control: a row-based control where each
 *     row is (page dropdown + delay number input), with add/remove buttons.
 *     Saves a comma-separated 'page_id:delay_ms' string.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register the custom controls with the Customizer.
 */
function zymarg_os_register_customize_control_classes() {
	if ( ! class_exists( 'WP_Customize_Control' ) ) {
		return;
	}

	if ( ! class_exists( 'Zymarg_Customize_Page_Checkboxes_Control' ) ) {
		/**
		 * Multi-page checkbox control.
		 */
		class Zymarg_Customize_Page_Checkboxes_Control extends WP_Customize_Control {
			public $type = 'zymarg_page_checkboxes';

			public function render_content() {
				$raw_value = (string) $this->value();
				$selected  = array();
				foreach ( explode( ',', $raw_value ) as $pid ) {
					$pid = absint( trim( $pid ) );
					if ( $pid > 0 ) {
						$selected[] = $pid;
					}
				}
				$pages = get_pages( array(
					'post_status' => 'publish',
					'sort_column' => 'menu_order,post_title',
					'number'      => 500,
				) );
				$uid = 'zymarg-pages-' . wp_unique_id();
				?>
				<?php if ( ! empty( $this->label ) ) : ?>
					<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
				<?php endif; ?>
				<?php if ( ! empty( $this->description ) ) : ?>
					<span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
				<?php endif; ?>
				<div class="zymarg-pages-list" id="<?php echo esc_attr( $uid ); ?>" style="max-height:260px;overflow-y:auto;background:#fff;border:1px solid #ddd;border-radius:6px;padding:10px 12px;margin-top:6px;">
					<?php if ( empty( $pages ) ) : ?>
						<p style="margin:0;color:#777;font-style:italic;"><?php esc_html_e( 'No published pages found.', 'zymarg-os' ); ?></p>
					<?php else : ?>
						<?php foreach ( $pages as $page ) : ?>
							<label style="display:block;padding:4px 0;font-size:13px;cursor:pointer;">
								<input type="checkbox" class="zymarg-page-check" data-page-id="<?php echo esc_attr( $page->ID ); ?>" <?php checked( in_array( $page->ID, $selected, true ) ); ?>>
								<?php echo esc_html( $page->post_title ); ?>
								<span style="color:#999;font-size:11px;">(ID: <?php echo esc_html( $page->ID ); ?>)</span>
							</label>
						<?php endforeach; ?>
					<?php endif; ?>
				</div>
				<input type="hidden" class="zymarg-pages-value" <?php $this->link(); ?> value="<?php echo esc_attr( $raw_value ); ?>">
				<script>
				(function() {
					var wrap = document.getElementById('<?php echo esc_js( $uid ); ?>');
					if (!wrap) return;
					var hidden = wrap.parentNode.querySelector('.zymarg-pages-value');
					wrap.querySelectorAll('.zymarg-page-check').forEach(function(cb) {
						cb.addEventListener('change', function() {
							var ids = [];
							wrap.querySelectorAll('.zymarg-page-check:checked').forEach(function(c) {
								ids.push(c.getAttribute('data-page-id'));
							});
							hidden.value = ids.join(', ');
							hidden.dispatchEvent(new Event('change'));
						});
					});
				})();
				</script>
				<?php
			}
		}
	}

	if ( ! class_exists( 'Zymarg_Customize_Page_Delays_Control' ) ) {
		/**
		 * Per-page delay rows control: page dropdown + delay input + remove btn.
		 */
		class Zymarg_Customize_Page_Delays_Control extends WP_Customize_Control {
			public $type = 'zymarg_page_delays';

			public function render_content() {
				$raw_value = (string) $this->value();
				$rows      = array();
				if ( '' !== trim( $raw_value ) ) {
					foreach ( explode( ',', $raw_value ) as $pair ) {
						$parts = explode( ':', trim( $pair ) );
						if ( count( $parts ) !== 2 ) {
							continue;
						}
						$pid   = absint( trim( $parts[0] ) );
						$delay = absint( trim( $parts[1] ) );
						if ( $pid > 0 ) {
							$rows[] = array( 'id' => $pid, 'delay' => $delay );
						}
					}
				}
				$pages = get_pages( array(
					'post_status' => 'publish',
					'sort_column' => 'menu_order,post_title',
					'number'      => 500,
				) );
				$uid = 'zymarg-delays-' . wp_unique_id();

				// Build the page-options HTML once for reuse.
				ob_start();
				echo '<option value="">' . esc_html__( '— Select a page —', 'zymarg-os' ) . '</option>';
				foreach ( $pages as $page ) {
					printf( '<option value="%d">%s (ID: %d)</option>', (int) $page->ID, esc_html( $page->post_title ), (int) $page->ID );
				}
				$page_options = ob_get_clean();
				?>
				<?php if ( ! empty( $this->label ) ) : ?>
					<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
				<?php endif; ?>
				<?php if ( ! empty( $this->description ) ) : ?>
					<span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
				<?php endif; ?>
				<div class="zymarg-delays-wrap" id="<?php echo esc_attr( $uid ); ?>" style="margin-top:8px;">
					<div class="zymarg-delays-rows">
						<?php if ( empty( $rows ) ) : ?>
							<p class="zymarg-delays-empty" style="color:#777;font-style:italic;margin:0 0 8px;"><?php esc_html_e( 'No per-page delays set.', 'zymarg-os' ); ?></p>
						<?php else : ?>
							<?php foreach ( $rows as $row ) : ?>
								<div class="zymarg-delay-row" style="display:flex;gap:6px;margin-bottom:6px;align-items:center;">
									<select class="zymarg-delay-page" style="flex:1;min-width:0;">
										<?php
										echo str_replace(
											'value="' . esc_attr( $row['id'] ) . '"',
											'value="' . esc_attr( $row['id'] ) . '" selected',
											$page_options
										); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
										?>
									</select>
									<input type="number" class="zymarg-delay-ms" value="<?php echo esc_attr( $row['delay'] ); ?>" min="0" max="15000" step="100" style="width:80px;" placeholder="ms">
									<button type="button" class="button button-link-delete zymarg-delay-remove" title="<?php esc_attr_e( 'Remove', 'zymarg-os' ); ?>">×</button>
								</div>
							<?php endforeach; ?>
						<?php endif; ?>
					</div>
					<button type="button" class="button zymarg-delay-add" style="margin-top:4px;">+ <?php esc_html_e( 'Add Page', 'zymarg-os' ); ?></button>
				</div>
				<input type="hidden" class="zymarg-delays-value" <?php $this->link(); ?> value="<?php echo esc_attr( $raw_value ); ?>">
				<template class="zymarg-delay-row-tmpl">
					<div class="zymarg-delay-row" style="display:flex;gap:6px;margin-bottom:6px;align-items:center;">
						<select class="zymarg-delay-page" style="flex:1;min-width:0;"><?php echo $page_options; // phpcs:ignore ?></select>
						<input type="number" class="zymarg-delay-ms" value="2000" min="0" max="15000" step="100" style="width:80px;" placeholder="ms">
						<button type="button" class="button button-link-delete zymarg-delay-remove" title="<?php esc_attr_e( 'Remove', 'zymarg-os' ); ?>">×</button>
					</div>
				</template>
				<script>
				(function() {
					var wrap = document.getElementById('<?php echo esc_js( $uid ); ?>');
					if (!wrap) return;
					var rowsCt = wrap.querySelector('.zymarg-delays-rows');
					var addBtn = wrap.querySelector('.zymarg-delay-add');
					var hidden = wrap.parentNode.querySelector('.zymarg-delays-value');
					var tmpl   = wrap.parentNode.querySelector('.zymarg-delay-row-tmpl');

					function serialize() {
						var pairs = [];
						rowsCt.querySelectorAll('.zymarg-delay-row').forEach(function(row) {
							var pid = row.querySelector('.zymarg-delay-page').value;
							var ms  = row.querySelector('.zymarg-delay-ms').value;
							if (pid && pid !== '') {
								pairs.push(pid + ':' + (ms === '' ? '0' : ms));
							}
						});
						hidden.value = pairs.join(', ');
						hidden.dispatchEvent(new Event('change'));
					}

					function attachRow(row) {
						row.querySelectorAll('.zymarg-delay-page, .zymarg-delay-ms').forEach(function(el) {
							el.addEventListener('change', serialize);
							el.addEventListener('input', serialize);
						});
						row.querySelector('.zymarg-delay-remove').addEventListener('click', function() {
							row.remove();
							serialize();
							if (!rowsCt.querySelector('.zymarg-delay-row')) {
								var empty = document.createElement('p');
								empty.className = 'zymarg-delays-empty';
								empty.style.cssText = 'color:#777;font-style:italic;margin:0 0 8px;';
								empty.textContent = '<?php echo esc_js( __( 'No per-page delays set.', 'zymarg-os' ) ); ?>';
								rowsCt.appendChild(empty);
							}
						});
					}

					rowsCt.querySelectorAll('.zymarg-delay-row').forEach(attachRow);

					addBtn.addEventListener('click', function() {
						var empty = rowsCt.querySelector('.zymarg-delays-empty');
						if (empty) empty.remove();
						var clone = tmpl.content.cloneNode(true);
						var row = clone.querySelector('.zymarg-delay-row');
						rowsCt.appendChild(row);
						attachRow(row);
						serialize();
					});
				})();
				</script>
				<?php
			}
		}
	}
}
add_action( 'customize_register', 'zymarg_os_register_customize_control_classes', 1 );
