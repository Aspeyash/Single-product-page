<?php
/**
 * Unified Toast Notifications loader.
 *
 * Registers and enqueues the shared toast component (components/toast/toast.css
 * + assets/js/modules/toast.js) on the front end, exposes a small server-side
 * helper to queue a toast for the next page load, and wires the "login success"
 * notification. Add-to-cart and review-submitted toasts are auto-wired in JS;
 * wishlist/compare call window.ZymargToast directly.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register + enqueue the toast assets on the front end.
 *
 * @return void
 */
function zymarg_os_toast_assets() {
	$ver = defined( 'ZYMARG_OS_VERSION' ) ? ZYMARG_OS_VERSION : '1.0.0';

	wp_register_style( 'zymarg-os-toast', ZYMARG_OS_URI . '/components/toast/toast.css', array(), $ver );
	wp_register_script( 'zymarg-os-toast', ZYMARG_OS_URI . '/assets/js/modules/toast.js', array(), $ver, true );

	wp_localize_script(
		'zymarg-os-toast',
		'ZymargToastCfg',
		array(
			'position' => (string) apply_filters( 'zymarg_os_toast_position', 'bottom-right' ),
			'duration' => (int) apply_filters( 'zymarg_os_toast_duration', 3800 ),
			'cartUrl'  => function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : '',
			'i18n'     => array(
				'addedToCart' => __( 'Added to cart', 'zymarg-os' ),
				'viewCart'    => __( 'View cart', 'zymarg-os' ),
			),
		)
	);

	wp_enqueue_style( 'zymarg-os-toast' );
	wp_enqueue_script( 'zymarg-os-toast' );
}
add_action( 'wp_enqueue_scripts', 'zymarg_os_toast_assets', 8 );

/**
 * Queue a toast to show on the current user's next front-end page load.
 *
 * @param string $message Message text.
 * @param string $type    success|error|info|warning.
 * @param string $title   Optional title.
 * @return void
 */
function zymarg_os_queue_toast( $message, $type = 'info', $title = '' ) {
	$uid = get_current_user_id();
	if ( ! $uid ) {
		return;
	}
	$queue = get_transient( 'zymarg_toast_queue_' . $uid );
	if ( ! is_array( $queue ) ) {
		$queue = array();
	}
	$queue[] = array(
		'message' => (string) $message,
		'type'    => (string) $type,
		'title'   => (string) $title,
	);
	set_transient( 'zymarg_toast_queue_' . $uid, $queue, 5 * MINUTE_IN_SECONDS );
}

/**
 * Flush any queued toasts as inline JS in the footer.
 *
 * @return void
 */
function zymarg_os_toast_flush_queue() {
	if ( ! is_user_logged_in() ) {
		return;
	}
	$uid   = get_current_user_id();
	$queue = get_transient( 'zymarg_toast_queue_' . $uid );
	if ( empty( $queue ) || ! is_array( $queue ) ) {
		return;
	}
	delete_transient( 'zymarg_toast_queue_' . $uid );

	echo '<script id="zymarg-toast-queue">(function(){var q=' . wp_json_encode( array_values( $queue ) ) . ';function fire(){if(!window.ZymargToast){return setTimeout(fire,60);}q.forEach(function(t){window.ZymargToast.show(t);});}fire();})();</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}
add_action( 'wp_footer', 'zymarg_os_toast_flush_queue', 100 );

/**
 * Queue a "welcome back" toast on successful login.
 *
 * @param string  $user_login Username.
 * @param WP_User $user       User object.
 * @return void
 */
function zymarg_os_toast_on_login( $user_login, $user = null ) {
	if ( ! $user instanceof WP_User ) {
		$user = get_user_by( 'login', $user_login );
	}
	if ( ! $user ) {
		return;
	}
	$name = $user->display_name ? $user->display_name : $user_login;
	set_transient(
		'zymarg_toast_queue_' . $user->ID,
		array(
			array(
				'message' => sprintf( /* translators: %s: display name */ __( 'Welcome back, %s!', 'zymarg-os' ), $name ),
				'type'    => 'success',
				'title'   => '',
			),
		),
		5 * MINUTE_IN_SECONDS
	);
}
add_action( 'wp_login', 'zymarg_os_toast_on_login', 10, 2 );
