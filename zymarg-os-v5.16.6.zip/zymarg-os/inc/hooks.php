<?php
/**
 * Custom layout hooks.
 *
 * ZYMARG OS exposes a set of action hooks so you (or the ZYMARG plugin) can
 * inject content at predictable points without editing template files. Mirrors
 * the "Custom Layouts" idea: attach headers, footers, banners, vendor notices,
 * etc. to any of these locations.
 *
 *   zymarg_os_body_open      — right after <body> opens
 *   zymarg_os_before_content — before the main content wrapper
 *   zymarg_os_content_top    — inside the wrapper, before the loop
 *   zymarg_os_content_bottom — inside the wrapper, after the loop
 *   zymarg_os_after_content  — after the main content wrapper
 *   zymarg_os_footer         — just before wp_footer()
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Render the dreamy dual-orb background as the first thing in the body.
 *
 * @return void
 */
function zymarg_os_render_orbs() {
	if ( ! apply_filters( 'zymarg_os_show_orbs', true ) ) {
		return;
	}
	?>
	<div class="zymarg-orbs" aria-hidden="true">
		<span class="zymarg-orbs__orb zymarg-orbs__orb--1"></span>
		<span class="zymarg-orbs__orb zymarg-orbs__orb--2"></span>
	</div>
	<?php
}
add_action( 'zymarg_os_body_open', 'zymarg_os_render_orbs', 5 );

/**
 * Fire body-open hook on the standard WordPress wp_body_open action so the orbs
 * and any injected content appear even if a child template forgets to call it.
 *
 * @return void
 */
function zymarg_os_body_open() {
	/**
	 * Inject content immediately after the opening <body> tag.
	 */
	do_action( 'zymarg_os_body_open' );
}
add_action( 'wp_body_open', 'zymarg_os_body_open' );

/**
 * Convenience wrappers so templates stay clean and the hook names are
 * discoverable in one place.
 */
function zymarg_os_before_content() {
	do_action( 'zymarg_os_before_content' );
}

function zymarg_os_content_top() {
	do_action( 'zymarg_os_content_top' );
}

function zymarg_os_content_bottom() {
	do_action( 'zymarg_os_content_bottom' );
}

function zymarg_os_after_content() {
	do_action( 'zymarg_os_after_content' );
}

/**
 * Fire the theme footer hook just before wp_footer so plugins can inject
 * end-of-page content in a predictable spot.
 *
 * @return void
 */
function zymarg_os_footer_hook() {
	do_action( 'zymarg_os_footer' );
}
add_action( 'wp_footer', 'zymarg_os_footer_hook', 5 );
