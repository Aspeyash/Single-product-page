<?php
/**
 * Gutenberg block patterns + block styles.
 *
 * Turns the free WordPress block editor into a ZYMARG-branded page builder:
 *   - A "ZYMARG OS" pattern category with ready-made sections (hero with the
 *     orb background, feature cards, gradient CTA, stats bar, product section,
 *     Discovery Spark feature, vendor spotlight).
 *   - Custom block STYLE variations (buttons, card group, orb section, gradient
 *     band, rounded image, brand separator) so core blocks look on-brand.
 *
 * Styling lives in assets/css/blocks.css (front + editor).
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register the pattern category + custom block styles.
 *
 * @return void
 */
function zymarg_os_register_block_styles() {
	if ( function_exists( 'register_block_pattern_category' ) ) {
		register_block_pattern_category(
			'zymarg-os',
			array( 'label' => __( 'ZYMARG OS', 'zymarg-os' ) )
		);
	}

	if ( ! function_exists( 'register_block_style' ) ) {
		return;
	}

	$styles = array(
		'core/button'    => array(
			array( 'zymarg-primary', __( 'ZYMARG Primary', 'zymarg-os' ) ),
			array( 'zymarg-secondary', __( 'ZYMARG Outline', 'zymarg-os' ) ),
			array( 'zymarg-ghost', __( 'ZYMARG Ghost', 'zymarg-os' ) ),
		),
		'core/group'     => array(
			array( 'zymarg-card', __( 'ZYMARG Card', 'zymarg-os' ) ),
			array( 'zymarg-orb-section', __( 'ZYMARG Orb Section', 'zymarg-os' ) ),
			array( 'zymarg-gradient', __( 'ZYMARG Gradient Band', 'zymarg-os' ) ),
		),
		'core/image'     => array(
			array( 'zymarg-rounded', __( 'ZYMARG Rounded', 'zymarg-os' ) ),
		),
		'core/separator' => array(
			array( 'zymarg-brand', __( 'ZYMARG Brand', 'zymarg-os' ) ),
		),
	);

	foreach ( $styles as $block => $variations ) {
		foreach ( $variations as $variation ) {
			register_block_style(
				$block,
				array(
					'name'  => $variation[0],
					'label' => $variation[1],
				)
			);
		}
	}
}
add_action( 'init', 'zymarg_os_register_block_styles' );

/**
 * Register the block patterns.
 *
 * @return void
 */
function zymarg_os_register_block_patterns() {
	if ( ! function_exists( 'register_block_pattern' ) ) {
		return;
	}

	$cat = array( 'zymarg-os' );

	/* ---- Hero with orb background ------------------------------------- */
	register_block_pattern(
		'zymarg-os/hero-orb',
		array(
			'title'      => __( 'ZYMARG Hero (orb background)', 'zymarg-os' ),
			'categories' => $cat,
			'content'    => '<!-- wp:group {"align":"full","className":"is-style-zymarg-orb-section","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull is-style-zymarg-orb-section"><!-- wp:heading {"textAlign":"center","level":1} -->
<h1 class="wp-block-heading has-text-align-center">Discover. Shop. Support local vendors.</h1>
<!-- /wp:heading -->
<!-- wp:paragraph {"align":"center","textColor":"text-muted"} -->
<p class="has-text-align-center has-text-muted-color has-text-color">A multivendor marketplace powered by ZYMARG OS — fast, beautiful and built for sellers.</p>
<!-- /wp:paragraph -->
<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons"><!-- wp:button {"className":"is-style-zymarg-primary"} -->
<div class="wp-block-button is-style-zymarg-primary"><a class="wp-block-button__link wp-element-button" href="#">Start shopping</a></div>
<!-- /wp:button -->
<!-- wp:button {"className":"is-style-zymarg-secondary"} -->
<div class="wp-block-button is-style-zymarg-secondary"><a class="wp-block-button__link wp-element-button" href="#">Become a vendor</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->',
		)
	);

	/* ---- Feature cards (3 columns) ------------------------------------ */
	register_block_pattern(
		'zymarg-os/feature-cards',
		array(
			'title'      => __( 'ZYMARG Feature Cards (3 columns)', 'zymarg-os' ),
			'categories' => $cat,
			'content'    => '<!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"is-style-zymarg-card","layout":{"type":"constrained"}} -->
<div class="wp-block-group is-style-zymarg-card"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Trusted vendors</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Every seller is verified so buyers shop with confidence.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"is-style-zymarg-card","layout":{"type":"constrained"}} -->
<div class="wp-block-group is-style-zymarg-card"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Fast checkout</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>A streamlined cart and checkout that converts on every device.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"is-style-zymarg-card","layout":{"type":"constrained"}} -->
<div class="wp-block-group is-style-zymarg-card"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Secure payouts</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Automated vendor payouts you and your sellers can rely on.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->',
		)
	);

	/* ---- Gradient CTA band -------------------------------------------- */
	register_block_pattern(
		'zymarg-os/gradient-cta',
		array(
			'title'      => __( 'ZYMARG Gradient CTA', 'zymarg-os' ),
			'categories' => $cat,
			'content'    => '<!-- wp:group {"align":"wide","className":"is-style-zymarg-gradient","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide is-style-zymarg-gradient"><!-- wp:heading {"textAlign":"center","level":2} -->
<h2 class="wp-block-heading has-text-align-center">Start selling on our marketplace today</h2>
<!-- /wp:heading -->
<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">Join hundreds of vendors growing their business with ZYMARG.</p>
<!-- /wp:paragraph -->
<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons"><!-- wp:button {"className":"is-style-zymarg-ghost"} -->
<div class="wp-block-button is-style-zymarg-ghost"><a class="wp-block-button__link wp-element-button" href="#">Open your store</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->',
		)
	);

	/* ---- Stats bar (4 columns) ---------------------------------------- */
	register_block_pattern(
		'zymarg-os/stats-bar',
		array(
			'title'      => __( 'ZYMARG Stats Bar', 'zymarg-os' ),
			'categories' => $cat,
			'content'    => '<!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"textAlign":"center","level":2,"textColor":"primary"} -->
<h2 class="wp-block-heading has-text-align-center has-primary-color has-text-color">2,500+</h2>
<!-- /wp:heading -->
<!-- wp:paragraph {"align":"center","textColor":"text-muted"} -->
<p class="has-text-align-center has-text-muted-color has-text-color">Products</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"textAlign":"center","level":2,"textColor":"primary"} -->
<h2 class="wp-block-heading has-text-align-center has-primary-color has-text-color">300+</h2>
<!-- /wp:heading -->
<!-- wp:paragraph {"align":"center","textColor":"text-muted"} -->
<p class="has-text-align-center has-text-muted-color has-text-color">Vendors</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"textAlign":"center","level":2,"textColor":"primary"} -->
<h2 class="wp-block-heading has-text-align-center has-primary-color has-text-color">50k</h2>
<!-- /wp:heading -->
<!-- wp:paragraph {"align":"center","textColor":"text-muted"} -->
<p class="has-text-align-center has-text-muted-color has-text-color">Orders</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"textAlign":"center","level":2,"textColor":"primary"} -->
<h2 class="wp-block-heading has-text-align-center has-primary-color has-text-color">4.9★</h2>
<!-- /wp:heading -->
<!-- wp:paragraph {"align":"center","textColor":"text-muted"} -->
<p class="has-text-align-center has-text-muted-color has-text-color">Avg. rating</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->',
		)
	);

	/* ---- Product section (drop in YOUR grid shortcode) ---------------- */
	register_block_pattern(
		'zymarg-os/product-section',
		array(
			'title'       => __( 'ZYMARG Product Section (your grid)', 'zymarg-os' ),
			'categories'  => $cat,
			'description' => __( 'A titled section with a placeholder for your product-grid shortcode.', 'zymarg-os' ),
			'content'     => '<!-- wp:group {"align":"wide","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide"><!-- wp:heading {"textAlign":"center"} -->
<h2 class="wp-block-heading has-text-align-center">Featured products</h2>
<!-- /wp:heading -->
<!-- wp:separator {"className":"is-style-zymarg-brand","align":"center"} -->
<hr class="wp-block-separator aligncenter is-style-zymarg-brand"/>
<!-- /wp:separator -->
<!-- wp:paragraph {"align":"center","textColor":"text-muted"} -->
<p class="has-text-align-center has-text-muted-color has-text-color">Replace the shortcode below with your product-grid plugin shortcode.</p>
<!-- /wp:paragraph -->
<!-- wp:shortcode -->
[your_product_grid]
<!-- /wp:shortcode --></div>
<!-- /wp:group -->',
		)
	);

	/* ---- Discovery Spark feature -------------------------------------- */
	register_block_pattern(
		'zymarg-os/spark-feature',
		array(
			'title'      => __( 'ZYMARG Discovery Spark Feature', 'zymarg-os' ),
			'categories' => $cat,
			'content'    => '<!-- wp:group {"align":"wide","className":"is-style-zymarg-orb-section","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide is-style-zymarg-orb-section"><!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">[zymarg_spark size="xl" label="Discover"]</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"textAlign":"center"} -->
<h2 class="wp-block-heading has-text-align-center">Discovery, sparked.</h2>
<!-- /wp:heading -->
<!-- wp:paragraph {"align":"center","textColor":"text-muted"} -->
<p class="has-text-align-center has-text-muted-color has-text-color">Help shoppers find exactly what they want across every vendor.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->',
		)
	);

	/* ---- Vendor spotlight --------------------------------------------- */
	register_block_pattern(
		'zymarg-os/vendor-spotlight',
		array(
			'title'      => __( 'ZYMARG Vendor Spotlight', 'zymarg-os' ),
			'categories' => $cat,
			'content'    => '<!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide"><!-- wp:column {"width":"33.33%"} -->
<div class="wp-block-column" style="flex-basis:33.33%"><!-- wp:group {"className":"is-style-zymarg-card","layout":{"type":"constrained"}} -->
<div class="wp-block-group is-style-zymarg-card"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Vendor of the week</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"text-muted"} -->
<p class="has-text-muted-color has-text-color">Spotlight a top-performing seller and link to their store.</p>
<!-- /wp:paragraph -->
<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"className":"is-style-zymarg-secondary"} -->
<div class="wp-block-button is-style-zymarg-secondary"><a class="wp-block-button__link wp-element-button" href="#">Visit store</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->
<!-- wp:column {"width":"66.66%"} -->
<div class="wp-block-column" style="flex-basis:66.66%"><!-- wp:paragraph -->
<p>Use this wider column for the vendor story, a featured product image, or your product-grid shortcode scoped to one vendor.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->',
		)
	);
	/* ---- Container: Row (flex, drag items left/right) ----------------- */
	register_block_pattern(
		'zymarg-os/container-row',
		array(
			'title'       => __( 'ZYMARG Container — Row', 'zymarg-os' ),
			'categories'  => $cat,
			'description' => __( 'A horizontal flex container. Drag items to reorder; use the Justify control to push left / center / right.', 'zymarg-os' ),
			'content'     => '<!-- wp:group {"align":"wide","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"center"}} -->
<div class="wp-block-group alignwide"><!-- wp:group {"className":"is-style-zymarg-card","layout":{"type":"constrained"}} -->
<div class="wp-block-group is-style-zymarg-card"><!-- wp:paragraph -->
<p>Item one</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
<!-- wp:group {"className":"is-style-zymarg-card","layout":{"type":"constrained"}} -->
<div class="wp-block-group is-style-zymarg-card"><!-- wp:paragraph -->
<p>Item two</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
<!-- wp:group {"className":"is-style-zymarg-card","layout":{"type":"constrained"}} -->
<div class="wp-block-group is-style-zymarg-card"><!-- wp:paragraph -->
<p>Item three</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->',
		)
	);

	/* ---- Container: Grid (responsive auto-fit) ------------------------ */
	register_block_pattern(
		'zymarg-os/container-grid',
		array(
			'title'       => __( 'ZYMARG Container — Grid', 'zymarg-os' ),
			'categories'  => $cat,
			'description' => __( 'A responsive grid container. Add or drag items; columns wrap automatically.', 'zymarg-os' ),
			'content'     => '<!-- wp:group {"align":"wide","layout":{"type":"grid","minimumColumnWidth":"16rem"}} -->
<div class="wp-block-group alignwide"><!-- wp:group {"className":"is-style-zymarg-card","layout":{"type":"constrained"}} -->
<div class="wp-block-group is-style-zymarg-card"><!-- wp:paragraph -->
<p>Cell one</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
<!-- wp:group {"className":"is-style-zymarg-card","layout":{"type":"constrained"}} -->
<div class="wp-block-group is-style-zymarg-card"><!-- wp:paragraph -->
<p>Cell two</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
<!-- wp:group {"className":"is-style-zymarg-card","layout":{"type":"constrained"}} -->
<div class="wp-block-group is-style-zymarg-card"><!-- wp:paragraph -->
<p>Cell three</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
<!-- wp:group {"className":"is-style-zymarg-card","layout":{"type":"constrained"}} -->
<div class="wp-block-group is-style-zymarg-card"><!-- wp:paragraph -->
<p>Cell four</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->',
		)
	);

	/* ---- Container: Split (content + media) --------------------------- */
	register_block_pattern(
		'zymarg-os/container-split',
		array(
			'title'       => __( 'ZYMARG Container — Split', 'zymarg-os' ),
			'categories'  => $cat,
			'description' => __( 'Two-column split: content on one side, media on the other. Swap the columns by dragging.', 'zymarg-os' ),
			'content'     => '<!-- wp:columns {"align":"wide","verticalAlignment":"center"} -->
<div class="wp-block-columns alignwide are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:heading -->
<h2 class="wp-block-heading">Built to move with you</h2>
<!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"text-muted"} -->
<p class="has-text-muted-color has-text-color">Use this column for your message; drag the columns to flip the layout left or right.</p>
<!-- /wp:paragraph -->
<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"className":"is-style-zymarg-primary"} -->
<div class="wp-block-button is-style-zymarg-primary"><a class="wp-block-button__link wp-element-button" href="#">Learn more</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:group {"className":"is-style-zymarg-card","style":{"dimensions":{"minHeight":"260px"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group is-style-zymarg-card" style="min-height:260px"><!-- wp:paragraph {"align":"center","textColor":"text-muted"} -->
<p class="has-text-align-center has-text-muted-color has-text-color">Add an image or media block here</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->',
		)
	);

	/* ---- Container: Section wrapper (full-width, padded) -------------- */
	register_block_pattern(
		'zymarg-os/container-section',
		array(
			'title'       => __( 'ZYMARG Container — Section', 'zymarg-os' ),
			'categories'  => $cat,
			'description' => __( 'A full-width, padded section wrapper to drop other blocks/containers inside.', 'zymarg-os' ),
			'content'     => '<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"backgroundColor":"surface","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-surface-background-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:heading {"textAlign":"center"} -->
<h2 class="wp-block-heading has-text-align-center">Section title</h2>
<!-- /wp:heading -->
<!-- wp:paragraph {"align":"center","textColor":"text-muted"} -->
<p class="has-text-align-center has-text-muted-color has-text-color">Drop your content, rows or grids inside this section.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->',
		)
	);
	/* ---- Section placeholder removed: header/footer patterns retired ---- */
}
add_action( 'init', 'zymarg_os_register_block_patterns' );

/**
 * Enqueue the block-style CSS on the front end and in the editor.
 *
 * @return void
 */
function zymarg_os_block_styles_assets() {
	// Front end: depends on the token layer so variables resolve.
	if ( ! is_admin() ) {
		wp_enqueue_style(
			'zymarg-os-blocks',
			ZYMARG_OS_URI . '/assets/css/blocks.css',
			array( 'zymarg-os-token-colors' ),
			ZYMARG_OS_VERSION
		);
	}
}
add_action( 'wp_enqueue_scripts', 'zymarg_os_block_styles_assets', 15 );
