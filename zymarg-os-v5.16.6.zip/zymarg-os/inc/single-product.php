<?php
/**
 * Enhanced single product page.
 *
 * Turns the default WooCommerce single-product layout into a modern,
 * conversion-focused page WITHOUT overriding core templates (so it stays
 * compatible with WooCommerce / Dokan updates and page builders). Everything
 * is additive via hooks + a scoped stylesheet (woocommerce/single-product.css)
 * and script (assets/js/single-product.js):
 *
 *   - Two-column grid: sticky gallery (zoom + lightbox) | summary card
 *   - Variation swatches (colour chips / button pills) for variable products,
 *     synced to WooCommerce's own variation engine (live price, image, stock)
 *   - Quantity stepper (+ / −)
 *   - Percentage-off sale badge
 *   - Trust badge row (secure checkout, shipping, returns, support)
 *   - Restyled product tabs & related products
 *
 * Gated by the "woocommerce" module and the `zymarg_enhanced_pdp` Customizer
 * toggle (default on). Disable it to fall back to the plain WooCommerce layout.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Whether the enhanced single-product experience is enabled.
 *
 * @return bool
 */
function zymarg_os_enhanced_pdp_enabled() {
	return (bool) apply_filters( 'zymarg_os_enhanced_pdp', (bool) get_theme_mod( 'zymarg_enhanced_pdp', true ) );
}

/**
 * Add a body class on enhanced single-product pages so all CSS/JS can scope to it.
 *
 * @param array $classes Body classes.
 * @return array
 */
function zymarg_os_pdp_body_class( $classes ) {
	if ( function_exists( 'is_product' ) && is_product() && zymarg_os_enhanced_pdp_enabled() ) {
		$classes[] = 'zymarg-pdp';
	}
	return $classes;
}
add_filter( 'body_class', 'zymarg_os_pdp_body_class' );

/* ---------------------------------------------------------------------- *
 * Percentage-off sale badge
 * ---------------------------------------------------------------------- */

/**
 * Work out the biggest discount percentage for a product (handles variable).
 *
 * @param WC_Product $product Product.
 * @return int Percentage 0–100 (0 = no usable discount).
 */
function zymarg_os_discount_percent( $product ) {
	$max = 0;

	if ( $product->is_type( 'variable' ) ) {
		foreach ( $product->get_children() as $child_id ) {
			$variation = wc_get_product( $child_id );
			if ( ! $variation || ! $variation->is_on_sale() ) {
				continue;
			}
			$regular = (float) $variation->get_regular_price();
			$sale    = (float) $variation->get_sale_price();
			if ( $regular > 0 && $sale >= 0 && $sale < $regular ) {
				$percent = (int) round( ( 1 - ( $sale / $regular ) ) * 100 );
				$max     = max( $max, $percent );
			}
		}
	} elseif ( $product->is_on_sale() ) {
		$regular = (float) $product->get_regular_price();
		$sale    = (float) $product->get_sale_price();
		if ( $regular > 0 && $sale >= 0 && $sale < $regular ) {
			$max = (int) round( ( 1 - ( $sale / $regular ) ) * 100 );
		}
	}

	return $max;
}

/**
 * Replace the plain "Sale!" flash with a "-XX%" badge where we can compute it.
 *
 * @param string     $html    Default markup.
 * @param WP_Post    $post    Post object.
 * @param WC_Product $product Product object.
 * @return string
 */
function zymarg_os_pdp_sale_flash( $html, $post, $product ) {
	if ( ! zymarg_os_enhanced_pdp_enabled() || ! is_product() ) {
		return $html;
	}

	$percent = zymarg_os_discount_percent( $product );
	if ( $percent > 0 ) {
		return '<span class="onsale zymarg-onsale">-' . esc_html( $percent ) . '%</span>';
	}

	return $html;
}
add_filter( 'woocommerce_sale_flash', 'zymarg_os_pdp_sale_flash', 10, 3 );

/* ---------------------------------------------------------------------- *
 * Trust badges (after the add-to-cart area, before the product meta)
 * ---------------------------------------------------------------------- */

/**
 * Output a row of reassurance/trust badges on the single product summary.
 *
 * Filter `zymarg_os_pdp_trust_badges` to change/disable them (return an empty
 * array to hide the row entirely).
 *
 * @return void
 */
function zymarg_os_pdp_trust_badges() {
	if ( ! zymarg_os_enhanced_pdp_enabled() ) {
		return;
	}

	$icons = array(
		'shield'  => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2l8 3v6c0 5-3.4 9.3-8 11-4.6-1.7-8-6-8-11V5l8-3z"/></svg>',
		'truck'   => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 5h11v10H3zM14 8h4l3 3v4h-7zM7 18a2 2 0 1 0 0-4 2 2 0 0 0 0 4zm10 0a2 2 0 1 0 0-4 2 2 0 0 0 0 4z"/></svg>',
		'returns' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5V2L7 6l5 4V7a5 5 0 1 1-5 5H5a7 7 0 1 0 7-7z"/></svg>',
		'support' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2a8 8 0 0 0-8 8v5a3 3 0 0 0 3 3h1v-7H6v-1a6 6 0 1 1 12 0v1h-2v7h1a3 3 0 0 0 3-3v-5a8 8 0 0 0-8-8z"/></svg>',
	);

	$badges = apply_filters(
		'zymarg_os_pdp_trust_badges',
		array(
			array( 'icon' => 'shield', 'title' => __( 'Secure checkout', 'zymarg-os' ), 'text' => __( 'SSL encrypted payment', 'zymarg-os' ) ),
			array( 'icon' => 'truck', 'title' => __( 'Fast shipping', 'zymarg-os' ), 'text' => __( 'Tracked & insured', 'zymarg-os' ) ),
			array( 'icon' => 'returns', 'title' => __( 'Easy returns', 'zymarg-os' ), 'text' => __( 'Hassle-free policy', 'zymarg-os' ) ),
			array( 'icon' => 'support', 'title' => __( 'Friendly support', 'zymarg-os' ), 'text' => __( 'Here to help', 'zymarg-os' ) ),
		)
	);

	if ( empty( $badges ) ) {
		return;
	}

	echo '<div class="zymarg-pdp-trust">';
	foreach ( $badges as $badge ) {
		$icon = isset( $icons[ $badge['icon'] ] ) ? $icons[ $badge['icon'] ] : $icons['shield'];
		echo '<div class="zymarg-pdp-trust__item">';
		echo '<span class="zymarg-pdp-trust__icon">' . $icon . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '<span class="zymarg-pdp-trust__text"><strong>' . esc_html( $badge['title'] ) . '</strong><span>' . esc_html( $badge['text'] ) . '</span></span>';
		echo '</div>';
	}
	echo '</div>';
}
add_action( 'woocommerce_single_product_summary', 'zymarg_os_pdp_trust_badges', 35 );

/* ---------------------------------------------------------------------- *
 * Customizer toggle (added to the existing Modules section)
 * ---------------------------------------------------------------------- */

/**
 * Register the enable/disable toggle for the enhanced PDP.
 *
 * @param WP_Customize_Manager $wp_customize Customizer.
 * @return void
 */
function zymarg_os_pdp_customizer( $wp_customize ) {
	$wp_customize->add_setting(
		'zymarg_enhanced_pdp',
		array(
			'default'           => true,
			'sanitize_callback' => 'zymarg_os_sanitize_checkbox',
		)
	);
	$wp_customize->add_control(
		'zymarg_enhanced_pdp',
		array(
			'type'        => 'checkbox',
			'label'       => __( 'Enhanced single product page', 'zymarg-os' ),
			'description' => __( 'Beautiful product layout: sticky gallery, variation swatches, quantity stepper, trust badges. Turn off to use the plain WooCommerce layout (e.g. if you build product pages with a page builder).', 'zymarg-os' ),
			'section'     => 'zymarg_os_modules_section',
		)
	);
}
add_action( 'customize_register', 'zymarg_os_pdp_customizer', 20 );

/* ---------------------------------------------------------------------- *
 * Related / up-sells output (consistent full rows)
 * ---------------------------------------------------------------------- */

/**
 * Show related products as a tidy row of four.
 *
 * @param array $args Related products args.
 * @return array
 */
function zymarg_os_pdp_related_args( $args ) {
	if ( ! zymarg_os_enhanced_pdp_enabled() ) {
		return $args;
	}
	$args['posts_per_page'] = 10;
	$args['columns']        = 5;
	return $args;
}
add_filter( 'woocommerce_output_related_products_args', 'zymarg_os_pdp_related_args' );

/**
 * Best-effort: ask Dokan to show 10 "More Products from this store".
 *
 * Dokan controls its own "More Products" count; this filter nudges it to 10
 * where the Dokan version exposes it. If a Dokan build hard-codes the number,
 * this is simply ignored (harmless).
 *
 * @param int $count Current count.
 * @return int
 */
function zymarg_os_pdp_dokan_more_products_count( $count ) {
	return zymarg_os_enhanced_pdp_enabled() ? 10 : $count;
}
add_filter( 'dokan_get_more_products_per_page', 'zymarg_os_pdp_dokan_more_products_count' );

/**
 * Show up-sells as a tidy row of four (CSS handles the responsive columns).
 *
 * @param array $args Up-sell display args.
 * @return array
 */
function zymarg_os_pdp_upsell_args( $args ) {
	if ( ! zymarg_os_enhanced_pdp_enabled() ) {
		return $args;
	}
	$args['posts_per_page'] = 4;
	$args['columns']        = 4;
	return $args;
}
add_filter( 'woocommerce_upsell_display_args', 'zymarg_os_pdp_upsell_args' );


/* ---------------------------------------------------------------------- *
 * Single Product — full content control (tabs + sections)
 *
 * Lets the THEME decide what appears on the single product page, from the
 * Customizer (ZYMARG OS -> Single Product), regardless of which plugin added
 * the content (WooCommerce core, Dokan, etc.). All defaults are no-ops, so the
 * page is unchanged until you actually toggle something.
 * ---------------------------------------------------------------------- */

/**
 * Core WooCommerce tabs, always offered in the Customizer even before a product
 * page has been visited (so the controls are never empty).
 *
 * @return array<string,string> key => default title.
 */
function zymarg_os_pdp_core_tabs() {
	return array(
		'description'            => __( 'Description', 'zymarg-os' ),
		'additional_information' => __( 'Additional information', 'zymarg-os' ),
		'reviews'                => __( 'Reviews', 'zymarg-os' ),
	);
}

/**
 * Convert a tab key into a Customizer-setting-safe slug fragment.
 *
 * @param string $key Tab key.
 * @return string
 */
function zymarg_os_pdp_tab_setting_id( $key ) {
	return preg_replace( '/[^a-z0-9_]/', '_', strtolower( (string) $key ) );
}

/**
 * Tabs the theme has discovered on product pages (key => title), merged with
 * the known core tabs.
 *
 * @return array<string,string>
 */
function zymarg_os_pdp_known_tabs() {
	$stored = get_option( 'zymarg_os_pdp_tabs', array() );
	if ( ! is_array( $stored ) ) {
		$stored = array();
	}
	return array_merge( zymarg_os_pdp_core_tabs(), $stored );
}

/**
 * Capture the registered product tabs (for the Customizer list) and apply the
 * user's show/hide, rename and reorder settings.
 *
 * Runs very late (priority 9999) so every plugin has added its tabs first.
 * Writes the discovered tab map to an option only when it changes.
 *
 * @param array $tabs WooCommerce product tabs.
 * @return array
 */
function zymarg_os_pdp_filter_tabs( $tabs ) {
	if ( ! is_array( $tabs ) ) {
		return $tabs;
	}

	// 1) Capture the full list (key => title) for the Customizer UI.
	$map = array();
	foreach ( $tabs as $key => $tab ) {
		$map[ $key ] = ( is_array( $tab ) && isset( $tab['title'] ) ) ? wp_strip_all_tags( (string) $tab['title'] ) : (string) $key;
	}
	$stored = get_option( 'zymarg_os_pdp_tabs', array() );
	if ( $map !== $stored ) {
		update_option( 'zymarg_os_pdp_tabs', $map, false );
	}

	// 2) Apply the user's settings (no-op by default).
	foreach ( $tabs as $key => $tab ) {
		$sid = zymarg_os_pdp_tab_setting_id( $key );

		if ( ! get_theme_mod( 'zymarg_pdp_tab_show_' . $sid, true ) ) {
			unset( $tabs[ $key ] );
			continue;
		}

		$title = trim( (string) get_theme_mod( 'zymarg_pdp_tab_title_' . $sid, '' ) );
		if ( '' !== $title ) {
			$tabs[ $key ]['title'] = $title;
		}

		$order = get_theme_mod( 'zymarg_pdp_tab_order_' . $sid, '' );
		if ( '' !== $order && is_numeric( $order ) ) {
			$tabs[ $key ]['priority'] = (int) $order;
		}
	}

	return $tabs;
}
add_filter( 'woocommerce_product_tabs', 'zymarg_os_pdp_filter_tabs', 9999 );

/**
 * Sanitize an optional "order" number field: empty string keeps the default,
 * otherwise a positive integer.
 *
 * @param mixed $value Raw value.
 * @return string
 */
function zymarg_os_sanitize_pdp_order( $value ) {
	if ( '' === $value || null === $value ) {
		return '';
	}
	return is_numeric( $value ) ? (string) absint( $value ) : '';
}

/**
 * Register the "Single Product" Customizer section and the per-tab controls.
 *
 * @param WP_Customize_Manager $wp_customize Customizer.
 * @return void
 */
function zymarg_os_pdp_controls_customizer( $wp_customize ) {
	$wp_customize->add_section(
		'zymarg_os_pdp_section',
		array(
			'title'       => __( 'Single Product', 'zymarg-os' ),
			'description' => __( 'Decide what appears on the single product page. Tip: open any product on the front end once so the theme can list every tab your plugins add (WooCommerce, Dokan, etc.). Leave a control at its default to keep that item unchanged.', 'zymarg-os' ),
			'panel'       => 'zymarg_os_panel',
		)
	);

	// ---- Product tabs: show / rename / reorder ----
	foreach ( zymarg_os_pdp_known_tabs() as $key => $title ) {
		$sid = zymarg_os_pdp_tab_setting_id( $key );

		$wp_customize->add_setting(
			'zymarg_pdp_tab_show_' . $sid,
			array(
				'default'           => true,
				'sanitize_callback' => 'zymarg_os_sanitize_checkbox',
			)
		);
		$wp_customize->add_control(
			'zymarg_pdp_tab_show_' . $sid,
			array(
				'type'    => 'checkbox',
				'section' => 'zymarg_os_pdp_section',
				/* translators: %s: tab name. */
				'label'   => sprintf( __( 'Show the "%s" tab', 'zymarg-os' ), $title ),
			)
		);

		$wp_customize->add_setting(
			'zymarg_pdp_tab_title_' . $sid,
			array(
				'default'           => '',
				'sanitize_callback' => 'sanitize_text_field',
			)
		);
		$wp_customize->add_control(
			'zymarg_pdp_tab_title_' . $sid,
			array(
				'type'    => 'text',
				'section' => 'zymarg_os_pdp_section',
				/* translators: %s: tab name. */
				'label'   => sprintf( __( 'Rename "%s" (optional)', 'zymarg-os' ), $title ),
			)
		);

		$wp_customize->add_setting(
			'zymarg_pdp_tab_order_' . $sid,
			array(
				'default'           => '',
				'sanitize_callback' => 'zymarg_os_sanitize_pdp_order',
			)
		);
		$wp_customize->add_control(
			'zymarg_pdp_tab_order_' . $sid,
			array(
				'type'        => 'number',
				'section'     => 'zymarg_os_pdp_section',
				'input_attrs' => array(
					'min'  => 1,
					'max'  => 200,
					'step' => 1,
				),
				/* translators: %s: tab name. */
				'label'       => sprintf( __( 'Order for "%s" (optional, lower = first)', 'zymarg-os' ), $title ),
			)
		);
	}
}
add_action( 'customize_register', 'zymarg_os_pdp_controls_customizer', 25 );


/* ---------------------------------------------------------------------- *
 * Single Product — SECTION control (non-tab content)
 *
 * Show/hide the page sections that aren't tabs: WooCommerce "Related products"
 * and "Up-sells", and the Dokan "More Products from this store" block and
 * "Product Enquiry" button. Woo sections are removed with the standard
 * remove_action(); the Dokan items are removed by safe, version-tolerant
 * name-matching of whatever they hooked, with a CSS fallback as a backstop.
 * ---------------------------------------------------------------------- */

/**
 * Register the section-visibility toggles (added to the Single Product section).
 *
 * @param WP_Customize_Manager $wp_customize Customizer.
 * @return void
 */
function zymarg_os_pdp_section_controls_customizer( $wp_customize ) {
	$toggles = array(
		'zymarg_pdp_show_related'    => __( 'Show "Related products"', 'zymarg-os' ),
		'zymarg_pdp_show_upsells'    => __( 'Show "You may also like" (up-sells)', 'zymarg-os' ),
		'zymarg_pdp_show_dokan_more' => __( 'Show Dokan "More Products from this store"', 'zymarg-os' ),
		'zymarg_pdp_show_enquiry'    => __( 'Show Dokan "Product Enquiry" button', 'zymarg-os' ),
	);

	foreach ( $toggles as $setting_id => $label ) {
		$wp_customize->add_setting(
			$setting_id,
			array(
				'default'           => true,
				'sanitize_callback' => 'zymarg_os_sanitize_checkbox',
			)
		);
		$wp_customize->add_control(
			$setting_id,
			array(
				'type'    => 'checkbox',
				'section' => 'zymarg_os_pdp_section',
				'label'   => $label,
			)
		);
	}
}
add_action( 'customize_register', 'zymarg_os_pdp_section_controls_customizer', 26 );

/**
 * Resolve a hook callback to a readable "Class::method" or "function" name.
 * Returns '' for closures / unnameable callbacks (which we never auto-remove).
 *
 * @param mixed $function The registered callback.
 * @return string
 */
function zymarg_os_pdp_callback_name( $function ) {
	if ( is_string( $function ) ) {
		return $function;
	}
	if ( is_array( $function ) && isset( $function[0], $function[1] ) ) {
		$class = is_object( $function[0] ) ? get_class( $function[0] ) : (string) $function[0];
		return $class . '::' . (string) $function[1];
	}
	return '';
}

/**
 * Remove any callbacks on the given hooks whose (named) callback contains one
 * of the needle strings. Closures are skipped so we never remove something we
 * can't positively identify.
 *
 * @param array $hooks   Hook names to scan.
 * @param array $needles Case-insensitive substrings to match in callback names.
 * @return bool True if anything was removed.
 */
function zymarg_os_pdp_remove_hooks_matching( $hooks, $needles ) {
	global $wp_filter;
	$removed = false;

	foreach ( (array) $hooks as $hook ) {
		if ( empty( $wp_filter[ $hook ] ) || ! is_object( $wp_filter[ $hook ] ) ) {
			continue;
		}
		// Copy so removing during iteration is safe.
		$by_priority = $wp_filter[ $hook ]->callbacks;
		foreach ( $by_priority as $priority => $callbacks ) {
			foreach ( $callbacks as $cb ) {
				if ( ! isset( $cb['function'] ) ) {
					continue;
				}
				$name = zymarg_os_pdp_callback_name( $cb['function'] );
				if ( '' === $name ) {
					continue; // Anonymous — leave it alone.
				}
				foreach ( (array) $needles as $needle ) {
					if ( false !== stripos( $name, $needle ) ) {
						remove_action( $hook, $cb['function'], $priority );
						$removed = true;
						break;
					}
				}
			}
		}
	}

	return $removed;
}

/**
 * Apply the section-visibility settings on single product pages.
 *
 * @return void
 */
function zymarg_os_pdp_apply_section_visibility() {
	if ( ! function_exists( 'is_product' ) || ! is_product() ) {
		return;
	}

	// WooCommerce core sections — standard, safe removals.
	if ( ! get_theme_mod( 'zymarg_pdp_show_related', true ) ) {
		remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );
	}
	if ( ! get_theme_mod( 'zymarg_pdp_show_upsells', true ) ) {
		remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15 );
	}

	// Dokan non-tab blocks — scan likely hooks and remove by name match.
	$dokan_hooks = array(
		'woocommerce_after_single_product_summary',
		'woocommerce_single_product_summary',
		'woocommerce_after_add_to_cart_form',
		'woocommerce_after_add_to_cart_button',
		'woocommerce_product_meta_end',
		'woocommerce_after_single_product',
		'dokan_after_single_product',
	);

	if ( ! get_theme_mod( 'zymarg_pdp_show_dokan_more', true ) ) {
		zymarg_os_pdp_remove_hooks_matching(
			$dokan_hooks,
			array( 'more_products', 'more-products', 'from_seller', 'from-seller', 'store_products', 'seller_products', 'other_products' )
		);
	}

	if ( ! get_theme_mod( 'zymarg_pdp_show_enquiry', true ) ) {
		zymarg_os_pdp_remove_hooks_matching(
			$dokan_hooks,
			array( 'enquiry', 'inquiry', 'ask_question', 'ask-question' )
		);
	}
}
add_action( 'template_redirect', 'zymarg_os_pdp_apply_section_visibility', 20 );

/**
 * CSS fallback: hide the Dokan blocks even if their markup is printed by a hook
 * we couldn't match (e.g. an anonymous closure). Only prints the rules that are
 * actually needed. Selectors are Dokan-namespaced and filterable.
 *
 * @return void
 */
function zymarg_os_pdp_section_visibility_css() {
	if ( ! function_exists( 'is_product' ) || ! is_product() ) {
		return;
	}

	$selectors = array();

	if ( ! get_theme_mod( 'zymarg_pdp_show_dokan_more', true ) ) {
		$more = apply_filters(
			'zymarg_os_pdp_more_products_selectors',
			array( '.dokan-store-products-more', '.seller-more-products', '.dokan-other-products', '#dokan-store-products-more' )
		);
		$selectors = array_merge( $selectors, (array) $more );
	}

	if ( ! get_theme_mod( 'zymarg_pdp_show_enquiry', true ) ) {
		$enq = apply_filters(
			'zymarg_os_pdp_enquiry_selectors',
			array( '.dokan-product-enquiry', '.dokan-product-enquiry-button', '.dokan-enquiry-button', '#dokan-product-enquiry' )
		);
		$selectors = array_merge( $selectors, (array) $enq );
	}

	$selectors = array_filter( array_unique( $selectors ) );
	if ( empty( $selectors ) ) {
		return;
	}

	echo '<style id="zymarg-pdp-visibility">' . esc_html( implode( ',', $selectors ) ) . '{display:none !important;}</style>' . "\n";
}
add_action( 'wp_head', 'zymarg_os_pdp_section_visibility_css', 99 );
