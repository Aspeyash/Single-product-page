<?php
/**
 * Result sorting for search.php and archive.php.
 *
 * Adds a sort dropdown (Latest, Oldest, Name, and — on WooCommerce — Price low
 * to high / high to low) to the theme's own search & archive templates. It does
 * NOT interfere with WooCommerce shop/category pages, which keep their native
 * ordering dropdown.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Available sort options (key => label).
 *
 * @return array<string,string>
 */
function zymarg_os_sort_options() {
	$opts = array(
		'latest' => __( 'Latest', 'zymarg-os' ),
		'oldest' => __( 'Oldest', 'zymarg-os' ),
		'title'  => __( 'Name (A–Z)', 'zymarg-os' ),
	);

	if ( class_exists( 'WooCommerce' ) ) {
		$opts['price-low']  = __( 'Price: low to high', 'zymarg-os' );
		$opts['price-high'] = __( 'Price: high to low', 'zymarg-os' );
	}

	return apply_filters( 'zymarg_os_sort_options', $opts );
}

/**
 * The currently selected sort key.
 *
 * @return string
 */
function zymarg_os_current_sort() {
	$sort = isset( $_GET['zsort'] ) ? sanitize_key( wp_unslash( $_GET['zsort'] ) ) : 'latest'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	return array_key_exists( $sort, zymarg_os_sort_options() ) ? $sort : 'latest';
}

/**
 * Apply the chosen sort to the main search/archive query (not WooCommerce's
 * own pages, which manage their own ordering).
 *
 * @param WP_Query $query Query.
 * @return void
 */
function zymarg_os_apply_sorting( $query ) {
	if ( is_admin() || ! $query->is_main_query() ) {
		return;
	}
	if ( function_exists( 'is_woocommerce' ) && is_woocommerce() ) {
		return; // Let WooCommerce handle shop/category/product-tax ordering.
	}
	if ( ! ( $query->is_search() || $query->is_archive() ) ) {
		return;
	}
	if ( ! isset( $_GET['zsort'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return; // Only override when the visitor picks a sort.
	}

	switch ( zymarg_os_current_sort() ) {
		case 'oldest':
			$query->set( 'orderby', 'date' );
			$query->set( 'order', 'ASC' );
			break;
		case 'title':
			$query->set( 'orderby', 'title' );
			$query->set( 'order', 'ASC' );
			break;
		case 'price-low':
			$query->set( 'meta_key', '_price' ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			$query->set( 'orderby', 'meta_value_num' );
			$query->set( 'order', 'ASC' );
			break;
		case 'price-high':
			$query->set( 'meta_key', '_price' ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			$query->set( 'orderby', 'meta_value_num' );
			$query->set( 'order', 'DESC' );
			break;
		case 'latest':
		default:
			$query->set( 'orderby', 'date' );
			$query->set( 'order', 'DESC' );
			break;
	}
}
add_action( 'pre_get_posts', 'zymarg_os_apply_sorting' );

/**
 * Render the sort bar (a GET form that preserves the current query and
 * auto-submits on change).
 *
 * @return void
 */
function zymarg_os_sorting_bar() {
	$current = zymarg_os_current_sort();
	?>
	<form class="zymarg-sortbar" method="get" role="search">
		<?php
		// Preserve other query vars (search term, post_type, taxonomy, etc.).
		foreach ( $_GET as $key => $value ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			if ( in_array( $key, array( 'zsort', 'paged', 'page' ), true ) || is_array( $value ) ) {
				continue;
			}
			printf(
				'<input type="hidden" name="%1$s" value="%2$s" />',
				esc_attr( sanitize_key( $key ) ),
				esc_attr( sanitize_text_field( wp_unslash( $value ) ) )
			);
		}
		?>
		<label class="zymarg-sortbar__label" for="zymarg-zsort"><?php esc_html_e( 'Sort by', 'zymarg-os' ); ?></label>
		<select id="zymarg-zsort" name="zsort" class="zymarg-sortbar__select" onchange="this.form.submit()">
			<?php foreach ( zymarg_os_sort_options() as $key => $label ) : ?>
				<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $current, $key ); ?>><?php echo esc_html( $label ); ?></option>
			<?php endforeach; ?>
		</select>
		<noscript><button type="submit" class="zymarg-btn zymarg-btn--sm"><?php esc_html_e( 'Sort', 'zymarg-os' ); ?></button></noscript>
	</form>
	<?php
}
