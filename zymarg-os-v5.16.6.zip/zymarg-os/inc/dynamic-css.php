<?php
/**
 * Dynamic CSS.
 *
 * Builds a small inline stylesheet from the Customizer settings: colour token
 * overrides, typography (font stacks, size, line-height, heading weight),
 * spacing, button radius and any custom @font-face rules. Attached to the base
 * stylesheet so it loads with zero extra requests.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Compose the dynamic CSS string.
 *
 * @return string
 */
function zymarg_os_build_dynamic_css() {
	$vars = array();

	// Colours — only emit overrides the merchant actually changed from the
	// default (tokens/colors.css already sets the defaults). Emitting defaults
	// here would clobber the [data-theme="dark"] block because :root and
	// [data-theme="dark"] have equal specificity and the inline style loads
	// after tokens/dark.css in source order.
	foreach ( zymarg_os_color_settings() as $setting_id => $data ) {
		$value = sanitize_hex_color( (string) get_theme_mod( $setting_id, $data['default'] ) );
		if ( $value && strtolower( $value ) !== strtolower( $data['default'] ) ) {
			$vars[ $data['var'] ] = $value;
		}
	}

	// Primary Inverse (gradient end colour) — its own control.
	$primary_inverse = sanitize_hex_color( (string) get_theme_mod( 'zymarg_color_primary_inverse', '#fea9ff' ) );
	if ( $primary_inverse && strtolower( $primary_inverse ) !== '#fea9ff' ) {
		$vars['--color-primary-inverse'] = $primary_inverse;
	}

	// Brand gradient — rebuild only when angle or stops differ from defaults.
	$g_angle = absint( get_theme_mod( 'zymarg_gradient_angle', 135 ) );
	$g_stop1 = absint( get_theme_mod( 'zymarg_gradient_stop1', 0 ) );
	$g_stop2 = absint( get_theme_mod( 'zymarg_gradient_stop2', 60 ) );
	$g_stop3 = absint( get_theme_mod( 'zymarg_gradient_stop3', 130 ) );
	if ( 135 !== $g_angle || 0 !== $g_stop1 || 60 !== $g_stop2 || 130 !== $g_stop3 ) {
		$vars['--zymarg-gradient'] = 'linear-gradient(' . $g_angle . 'deg, var(--color-primary) ' . $g_stop1 . '%, var(--color-primary-container) ' . $g_stop2 . '%, var(--color-primary-inverse) ' . $g_stop3 . '%)';
	}

	// Typography stacks.
	$stacks                       = zymarg_os_font_stacks();
	$vars['--zymarg-font-body']    = $stacks['body'];
	$vars['--zymarg-font-heading'] = $stacks['heading'];

	// Type scale.
	$base_size = absint( get_theme_mod( 'zymarg_font_base_size', 16 ) );
	if ( $base_size ) {
		$vars['--zymarg-font-size-base'] = $base_size . 'px';
	}

	$line_height = (float) get_theme_mod( 'zymarg_line_height', 1.6 );
	if ( $line_height ) {
		$vars['--zymarg-line-height'] = $line_height;
	}

	$heading_weight = absint( get_theme_mod( 'zymarg_heading_weight', 600 ) );
	if ( $heading_weight ) {
		$vars['--zymarg-heading-weight'] = $heading_weight;
	}

	// Body weight.
	$body_weight = absint( get_theme_mod( 'zymarg_body_weight', 400 ) );
	if ( $body_weight ) {
		$vars['--zymarg-body-weight'] = $body_weight;
	}

	// Heading line height.
	$heading_lh = (float) get_theme_mod( 'zymarg_heading_line_height', 1.2 );
	if ( $heading_lh ) {
		$vars['--zymarg-heading-line-height'] = $heading_lh;
	}

	// Individual heading sizes — responsive. Build a fluid clamp() from the
	// "small screens" (min) and "large screens" (max) values. Only emit when
	// min or max differs from its default, so the theme's original responsive
	// sizing is preserved until the merchant deliberately changes it.
	$heading_size_defaults = array(
		'zymarg_h1_size' => array( 'var' => '--zymarg-h1-size', 'max' => '3',    'min' => '2' ),
		'zymarg_h2_size' => array( 'var' => '--zymarg-h2-size', 'max' => '2.25', 'min' => '1.6' ),
		'zymarg_h3_size' => array( 'var' => '--zymarg-h3-size', 'max' => '1.75', 'min' => '1.3' ),
		'zymarg_h4_size' => array( 'var' => '--zymarg-h4-size', 'max' => '1.25', 'min' => '1.25' ),
		'zymarg_h5_size' => array( 'var' => '--zymarg-h5-size', 'max' => '1.1',  'min' => '1.1' ),
		'zymarg_h6_size' => array( 'var' => '--zymarg-h6-size', 'max' => '1',    'min' => '1' ),
	);
	foreach ( $heading_size_defaults as $setting_id => $data ) {
		$max = (float) get_theme_mod( $setting_id, $data['max'] );
		$min = (float) get_theme_mod( $setting_id . '_min', $data['min'] );

		$max_changed = abs( $max - (float) $data['max'] ) > 0.0001;
		$min_changed = abs( $min - (float) $data['min'] ) > 0.0001;

		if ( ! $max_changed && ! $min_changed ) {
			continue; // Keep the original CSS clamp() for this heading.
		}

		if ( $max <= 0 ) {
			$max = (float) $data['max'];
		}
		if ( $min <= 0 ) {
			$min = $max;
		}
		// Guard: a min larger than max would invert the clamp — swap them.
		if ( $min > $max ) {
			$tmp = $min;
			$min = $max;
			$max = $tmp;
		}

		$min_s = rtrim( rtrim( number_format( $min, 3, '.', '' ), '0' ), '.' );
		$max_s = rtrim( rtrim( number_format( $max, 3, '.', '' ), '0' ), '.' );

		if ( abs( $max - $min ) < 0.0001 ) {
			// No fluid range — a fixed size.
			$vars[ $data['var'] ] = $max_s . 'rem';
		} else {
			// Fluid clamp between a 320px (20rem) and 1280px (80rem) viewport.
			$delta = rtrim( rtrim( number_format( $max - $min, 3, '.', '' ), '0' ), '.' );
			$vars[ $data['var'] ] = 'clamp(' . $min_s . 'rem, calc(' . $min_s . 'rem + ' . $delta . ' * ((100vw - 20rem) / 60)), ' . $max_s . 'rem)';
		}
	}

	// Spacing + layout.
	$content_width = absint( get_theme_mod( 'zymarg_content_width', 1200 ) );
	$width_mode    = get_theme_mod( 'zymarg_content_width_mode', 'fixed' );
	if ( 'fluid' === $width_mode ) {
		// Fluid: a percentage of the viewport, capped so line length stays
		// readable on very wide / 4K screens.
		$pct = (float) get_theme_mod( 'zymarg_content_fluid_pct', 90 );
		if ( $pct < 50 ) {
			$pct = 50;
		} elseif ( $pct > 100 ) {
			$pct = 100;
		}
		if ( $content_width ) {
			$vars['--zymarg-content-width'] = 'min(' . rtrim( rtrim( number_format( $pct, 2, '.', '' ), '0' ), '.' ) . 'vw, ' . $content_width . 'px)';
		} else {
			$vars['--zymarg-content-width'] = $pct . 'vw';
		}
	} elseif ( $content_width ) {
		$vars['--zymarg-content-width'] = $content_width . 'px';
	}

	// Spacing scale.
	$spacing_scale = array(
		'zymarg_space_xs' => array( 'var' => '--zymarg-space-xs', 'default' => '0.5' ),
		'zymarg_space_sm' => array( 'var' => '--zymarg-space-sm', 'default' => '1' ),
		'zymarg_space_md' => array( 'var' => '--zymarg-space-md', 'default' => '1.5' ),
		'zymarg_space_lg' => array( 'var' => '--zymarg-space-lg', 'default' => '2.5' ),
		'zymarg_space_xl' => array( 'var' => '--zymarg-space-xl', 'default' => '4' ),
	);
	foreach ( $spacing_scale as $setting_id => $data ) {
		$value = (float) get_theme_mod( $setting_id, $data['default'] );
		if ( $value >= 0 ) {
			$vars[ $data['var'] ] = rtrim( rtrim( number_format( $value, 2, '.', '' ), '0' ), '.' ) . 'rem';
		}
	}

	// Buttons.
	$radius = absint( get_theme_mod( 'zymarg_button_radius', 8 ) );
	$vars['--zymarg-radius-sm'] = $radius . 'px';

	// Card radius.
	$card_radius = absint( get_theme_mod( 'zymarg_card_radius', 12 ) );
	$vars['--zymarg-radius'] = $card_radius . 'px';

	// Discovery Spark colours.
	$spark_purple = sanitize_hex_color( (string) get_theme_mod( 'zymarg_spark_purple', '#6833EA' ) );
	$spark_gold   = sanitize_hex_color( (string) get_theme_mod( 'zymarg_spark_gold', '#FFD166' ) );
	if ( $spark_purple ) {
		$vars['--zymarg-spark-purple'] = $spark_purple;
	}
	if ( $spark_gold ) {
		$vars['--zymarg-spark-gold'] = $spark_gold;
	}

	// Build the :root block.
	$css = ':root{';
	foreach ( $vars as $name => $value ) {
		$css .= $name . ':' . $value . ';';
	}
	$css .= '}';

	// Dark-mode colour overrides (only the values the merchant changed).
	$css .= zymarg_os_build_dark_css();

	// Custom @font-face rules (only when source = custom).
	$css .= zymarg_os_custom_fontface_css();

	// Scroll-to-top button overrides (colours, size, shape, position).
	$css .= zymarg_os_scrolltop_dynamic_css();

	// Account-icon overrides (colours, size).
	if ( function_exists( 'zymarg_os_account_icon_dynamic_css' ) ) {
		$css .= zymarg_os_account_icon_dynamic_css();
	}

	// Login card + pop-up (accent, card background, per-device modal sizes).
	if ( function_exists( 'zymarg_os_login_dynamic_css' ) ) {
		$css .= zymarg_os_login_dynamic_css();
	}

	/**
	 * Filter the final dynamic CSS string.
	 *
	 * @param string $css  Generated CSS.
	 * @param array  $vars The variable map used to build it.
	 */
	return apply_filters( 'zymarg_os_dynamic_css', $css, $vars );
}

/**
 * Build dark-mode colour overrides from the Customizer "Dark Mode Colours"
 * controls. Only emits the variables the merchant actually changed (so
 * tokens/dark.css stays the source of truth for everything else). Emits both
 * the explicit [data-theme="dark"] block and the [data-theme="auto"] block
 * inside a prefers-color-scheme media query.
 *
 * @return string
 */
function zymarg_os_build_dark_css() {
	if ( ! function_exists( 'zymarg_os_dark_color_settings' ) ) {
		return '';
	}

	// Only relevant when a dark-capable scheme is active.
	$scheme = get_theme_mod( 'zymarg_color_scheme', 'light' );
	if ( ! in_array( $scheme, array( 'dark', 'auto', 'toggle' ), true ) ) {
		return '';
	}

	$pairs = array();
	foreach ( zymarg_os_dark_color_settings() as $setting_id => $data ) {
		$value = sanitize_hex_color( (string) get_theme_mod( $setting_id, $data['default'] ) );
		if ( $value && strtolower( $value ) !== strtolower( $data['default'] ) ) {
			$pairs[ $data['var'] ] = $value;
		}
	}

	// Always emit the critical text tokens so dark mode text stays readable
	// even when a merchant customized the light-mode body/muted text colour
	// (which gets written to :root and could otherwise win by source order).
	$always_emit = array( '--color-text-body', '--color-text-muted' );
	foreach ( zymarg_os_dark_color_settings() as $setting_id => $data ) {
		if ( in_array( $data['var'], $always_emit, true ) && ! isset( $pairs[ $data['var'] ] ) ) {
			$value = sanitize_hex_color( (string) get_theme_mod( $setting_id, $data['default'] ) );
			if ( $value ) {
				$pairs[ $data['var'] ] = $value;
			}
		}
	}

	if ( empty( $pairs ) ) {
		return '';
	}

	$decls = '';
	foreach ( $pairs as $name => $value ) {
		$decls .= $name . ':' . $value . ';';
	}

	// Explicit dark + auto (OS-dark) so both activation paths pick up the
	// merchant's overrides.
	$css  = '[data-theme="dark"]{' . $decls . '}';
	$css .= '@media (prefers-color-scheme:dark){[data-theme="auto"]{' . $decls . '}}';

	return $css;
}

/**
 * Build the scroll-to-top button's dynamic CSS.
 *
 * Emits a `.zymarg-scroll-top` scoped block of CSS custom properties so the
 * Customizer values flow into components/buttons.css (which reads them with
 * token fallbacks). Returns an empty string when the module is off.
 *
 * @return string
 */
function zymarg_os_scrolltop_dynamic_css() {
	if ( ! function_exists( 'zymarg_os_scrolltop_option' ) || ! zymarg_os_module_enabled( 'scroll_to_top' ) ) {
		return '';
	}

	$bg       = sanitize_hex_color( (string) zymarg_os_scrolltop_option( 'bg' ) );
	$bg_hover = sanitize_hex_color( (string) zymarg_os_scrolltop_option( 'bg_hover' ) );
	$icon     = sanitize_hex_color( (string) zymarg_os_scrolltop_option( 'icon_color' ) );
	$size     = absint( zymarg_os_scrolltop_option( 'size' ) );
	if ( $size < 32 || $size > 80 ) {
		$size = 44;
	}
	$icon_size = (int) round( $size * 0.45 );

	$props = array();
	if ( $bg ) {
		$props[] = '--zst-bg:' . $bg;
	}
	if ( $bg_hover ) {
		$props[] = '--zst-bg-hover:' . $bg_hover;
	}
	if ( $icon ) {
		$props[] = '--zst-icon:' . $icon;
	}
	$props[] = '--zst-size:' . $size . 'px';
	$props[] = '--zst-icon-size:' . $icon_size . 'px';

	if ( empty( $props ) ) {
		return '';
	}

	return '.zymarg-scroll-top{' . implode( ';', $props ) . ';}';
}

/**
 * Attach the dynamic CSS to the base stylesheet.
 *
 * @return void
 */
function zymarg_os_print_dynamic_css() {
	$css = zymarg_os_build_dynamic_css();

	if ( '' === trim( $css ) ) {
		return;
	}

	// Attach to the LAST-loading token handle (token-dark) so the inline
	// overrides win over BOTH tokens/colors.css AND tokens/dark.css — the
	// latter matters for the dark-mode colour overrides, which share the same
	// [data-theme="dark"] specificity and must come after dark.css to apply.
	$handle = wp_style_is( 'zymarg-os-token-dark', 'enqueued' ) ? 'zymarg-os-token-dark' : 'zymarg-os-token-colors';
	wp_add_inline_style( $handle, $css );
}
add_action( 'wp_enqueue_scripts', 'zymarg_os_print_dynamic_css', 20 );
