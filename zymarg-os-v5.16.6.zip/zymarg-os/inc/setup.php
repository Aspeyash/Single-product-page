<?php
/**
 * Theme setup: supports, menus and registrations.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register theme support flags.
 *
 * @return void
 */
function zymarg_os_setup() {
	// Make theme available for translation.
	load_theme_textdomain( 'zymarg-os', ZYMARG_OS_DIR . '/languages' );

	// Let WordPress manage the document title.
	add_theme_support( 'title-tag' );

	// Featured images.
	add_theme_support( 'post-thumbnails' );

	// Custom logo (the visual header is plugin-driven, but logo support is handy).
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 60,
			'width'       => 200,
			'flex-height' => true,
			'flex-width'  => true,
		)
	);

	// HTML5 markup.
	add_theme_support(
		'html5',
		array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' )
	);

	// Editor / block features.
	add_theme_support( 'align-wide' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'editor-styles' );
	add_theme_support( 'wp-block-styles' );
	add_editor_style(
		array(
			'tokens/colors.css',
			'tokens/typography.css',
			'tokens/spacing.css',
			'tokens/radius.css',
			'tokens/shadows.css',
			'tokens/transitions.css',
			'assets/css/blocks.css',
			'assets/css/editor.css',
		)
	);

	// Selective refresh for widgets in the Customizer.
	add_theme_support( 'customize-selective-refresh-widgets' );

	// Automatic feed links.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Navigation menus. Header/footer locations are provided for convenience even
	 * though the visual header/footer are handled by the ZYMARG plugin — they let
	 * the mega menu attach to a real menu location if you choose to use them.
	 */
	register_nav_menus(
		array(
			'primary' => __( 'Primary Menu', 'zymarg-os' ),
			'mega'    => __( 'Mega Menu', 'zymarg-os' ),
		)
	);
}
add_action( 'after_setup_theme', 'zymarg_os_setup' );

/**
 * Set the content width.
 *
 * @return void
 */
function zymarg_os_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'zymarg_os_content_width', 1200 );
}
add_action( 'after_setup_theme', 'zymarg_os_content_width', 0 );

/**
 * Register a widget area (optional; available for plugins that expect one).
 *
 * @return void
 */
function zymarg_os_widgets_init() {
	// Only register the optional sidebar when explicitly enabled from the
	// Customizer (ZYMARG OS -> Widget Areas). Off by default so WordPress does
	// not auto-fill an unused area with its default widgets.
	if ( ! get_theme_mod( 'zymarg_register_sidebar', false ) ) {
		return;
	}
	register_sidebar(
		array(
			'name'          => __( 'Sidebar', 'zymarg-os' ),
			'id'            => 'sidebar-1',
			'description'   => __( 'Optional sidebar widget area.', 'zymarg-os' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s zymarg-card">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
}
add_action( 'widgets_init', 'zymarg_os_widgets_init' );

/**
 * Add helpful template classes to <body> so CSS can react to Elementor / block
 * canvas templates and drop theme padding when a full-width layout is used.
 *
 * @param array $classes Body classes.
 * @return array
 */
function zymarg_os_body_classes( $classes ) {
	$classes[] = 'zymarg-os';

	if ( is_page_template( 'templates/template-canvas.php' ) ) {
		$classes[] = 'zymarg-template-canvas';
	}

	if ( is_page_template( 'templates/template-full-width.php' ) ) {
		$classes[] = 'zymarg-template-full-width';
	}

	return $classes;
}
add_filter( 'body_class', 'zymarg_os_body_classes' );
