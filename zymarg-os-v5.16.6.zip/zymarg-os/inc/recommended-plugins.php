<?php
/**
 * Recommended plugins notice.
 *
 * ZYMARG OS is designed to work hand-in-hand with the ZYMARG Theme Builder
 * plugin and Elementor. This shows a friendly, dismissible admin notice after
 * the theme is activated, listing whichever of those are not yet active, with
 * one-click links to install / activate them.
 *
 * Detection is filterable so you can wire it to the exact plugin once its slug
 * is known:
 *   - zymarg_os_theme_builder_active      (bool)
 *   - zymarg_os_theme_builder_install_url (string)
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Is Elementor active?
 *
 * @return bool
 */
function zymarg_os_elementor_active() {
	return (bool) ( did_action( 'elementor/loaded' ) || class_exists( '\\Elementor\\Plugin' ) );
}

/**
 * Is the ZYMARG Theme Builder companion plugin active?
 *
 * Best-effort detection across common signatures (new and legacy); override
 * with the `zymarg_os_theme_builder_active` filter if your build differs.
 *
 * @return bool
 */
function zymarg_os_theme_builder_active() {
	$active = defined( 'ZYMARG_THEME_BUILDER_VERSION' )
		|| defined( 'ZYMARG_TB_VERSION' )
		|| class_exists( 'ZYMARG_Theme_Builder' )
		|| function_exists( 'zymarg_theme_builder' )
		// Legacy "Powerhouse" signatures, in case the plugin still ships them.
		|| defined( 'ZYMARG_POWERHOUSE_VERSION' )
		|| class_exists( 'ZYMARG_Powerhouse' )
		|| function_exists( 'zymarg_powerhouse' );

	if ( ! $active ) {
		if ( ! function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$candidates = array(
			'zymarg-theme-builder/zymarg-theme-builder.php',
			'zymarg-theme-builder/zymarg-os-theme-builder.php',
			// Legacy paths.
			'zymarg-powerhouse/zymarg-powerhouse.php',
			'zymarg-powerhouse/zymarg-os-powerhouse.php',
		);
		foreach ( $candidates as $file ) {
			if ( is_plugin_active( $file ) ) {
				$active = true;
				break;
			}
		}
	}

	return (bool) apply_filters( 'zymarg_os_theme_builder_active', $active );
}

/**
 * Build the list of recommended plugins that are NOT yet active.
 *
 * @return array<string,array{name:string,desc:string,url:string,required:bool}>
 */
function zymarg_os_missing_recommended_plugins() {
	$missing = array();

	if ( ! zymarg_os_theme_builder_active() ) {
		$missing['theme_builder'] = array(
			'name'     => __( 'ZYMARG Theme Builder', 'zymarg-os' ),
			'desc'     => __( 'The core companion plugin (header, footer and building blocks) — the theme is not complete without it.', 'zymarg-os' ),
			'url'      => apply_filters( 'zymarg_os_theme_builder_install_url', self_admin_url( 'plugin-install.php' ) ),
			'required' => true,
		);
	}

	if ( ! zymarg_os_elementor_active() ) {
		$missing['elementor'] = array(
			'name'     => __( 'Elementor', 'zymarg-os' ),
			'desc'     => __( 'The page builder used to design your header, footer and pages.', 'zymarg-os' ),
			'url'      => self_admin_url( 'plugin-install.php?s=Elementor%20Website%20Builder&tab=search&type=term' ),
			'required' => true,
		);
	}

	return $missing;
}

/**
 * Handle dismissing the notice (per user).
 *
 * @return void
 */
function zymarg_os_dismiss_plugin_notice() {
	if ( ! isset( $_GET['zymarg_dismiss_plugins'] ) ) {
		return;
	}
	if ( ! isset( $_GET['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'zymarg_dismiss_plugins' ) ) {
		return;
	}
	update_user_meta( get_current_user_id(), 'zymarg_os_dismissed_plugin_notice', '1' );
	wp_safe_redirect( remove_query_arg( array( 'zymarg_dismiss_plugins', '_wpnonce' ) ) );
	exit;
}
add_action( 'admin_init', 'zymarg_os_dismiss_plugin_notice' );

/**
 * Render the recommended-plugins admin notice.
 *
 * @return void
 */
function zymarg_os_recommended_plugins_notice() {
	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}
	if ( get_user_meta( get_current_user_id(), 'zymarg_os_dismissed_plugin_notice', true ) ) {
		return;
	}

	$missing = zymarg_os_missing_recommended_plugins();
	if ( empty( $missing ) ) {
		return;
	}

	$dismiss_url = wp_nonce_url( add_query_arg( 'zymarg_dismiss_plugins', '1' ), 'zymarg_dismiss_plugins' );
	$spark       = function_exists( 'zymarg_discovery_spark' ) ? zymarg_discovery_spark( array( 'size' => 'md' ) ) : '';
	?>
	<div class="notice notice-info zymarg-recommend-notice" style="border-left-color:#9500a5;padding:14px 16px;position:relative;">
		<h3 style="margin:0 0 4px;display:flex;align-items:center;gap:8px;color:#36003d;">
			<?php echo $spark; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<?php esc_html_e( 'Finish setting up ZYMARG OS', 'zymarg-os' ); ?>
		</h3>
		<p style="margin:.2em 0 .8em;color:#534152;">
			<?php esc_html_e( 'ZYMARG OS is built to work hand-in-hand with the following. Install them for the complete experience:', 'zymarg-os' ); ?>
		</p>
		<ul style="margin:0 0 .6em;padding:0;list-style:none;display:flex;flex-wrap:wrap;gap:10px;">
			<?php foreach ( $missing as $plugin ) : ?>
				<li style="background:#faf2fb;border:1px solid #e7c9e6;border-radius:8px;padding:10px 12px;flex:1 1 280px;">
					<strong style="color:#36003d;"><?php echo esc_html( $plugin['name'] ); ?></strong>
					<span style="display:block;color:#534152;font-size:13px;margin:2px 0 8px;"><?php echo esc_html( $plugin['desc'] ); ?></span>
					<a class="button button-primary" href="<?php echo esc_url( $plugin['url'] ); ?>"><?php esc_html_e( 'Install / Activate', 'zymarg-os' ); ?></a>
				</li>
			<?php endforeach; ?>
		</ul>
		<p style="margin:.2em 0 0;">
			<a href="<?php echo esc_url( $dismiss_url ); ?>" style="color:#857183;text-decoration:none;font-size:13px;"><?php esc_html_e( 'Dismiss', 'zymarg-os' ); ?></a>
		</p>
	</div>
	<?php
}
add_action( 'admin_notices', 'zymarg_os_recommended_plugins_notice' );
