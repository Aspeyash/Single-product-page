<?php
/**
 * Session Control — Master session-length override.
 *
 * Gives the theme full control over how long each user role stays logged in.
 * Three independent Customizer dropdowns (Customer / Vendor / Admin) override
 * WordPress's default 2-day / 14-day cookie lifetimes via the
 * `auth_cookie_expiration` filter.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/* ---------------------------------------------------------------------- *
 * 1. Duration map — option value => seconds.
 * ---------------------------------------------------------------------- */

/**
 * Return the available session-length choices.
 *
 * @return array<string, array{label: string, seconds: int}>
 */
function zymarg_os_session_choices() {
	return array(
		'2_days'   => array(
			'label'   => __( '2 Days', 'zymarg-os' ),
			'seconds' => 2 * DAY_IN_SECONDS,
		),
		'1_week'   => array(
			'label'   => __( '1 Week', 'zymarg-os' ),
			'seconds' => 7 * DAY_IN_SECONDS,
		),
		'1_month'  => array(
			'label'   => __( '1 Month', 'zymarg-os' ),
			'seconds' => 30 * DAY_IN_SECONDS,
		),
		'3_months' => array(
			'label'   => __( '3 Months', 'zymarg-os' ),
			'seconds' => 90 * DAY_IN_SECONDS,
		),
		'1_year'   => array(
			'label'   => __( '1 Year', 'zymarg-os' ),
			'seconds' => 365 * DAY_IN_SECONDS,
		),
		'10_years' => array(
			'label'   => __( '10 Years (Forever)', 'zymarg-os' ),
			'seconds' => 10 * 365 * DAY_IN_SECONDS,
		),
	);
}

/* ---------------------------------------------------------------------- *
 * 2. Role detection — which dropdown applies to this user?
 * ---------------------------------------------------------------------- */

/**
 * Determine whether a user is a "vendor", "admin", or "customer" for
 * session-length purposes.
 *
 * @param WP_User $user The user object.
 * @return string One of 'admin', 'vendor', 'customer'.
 */
function zymarg_os_session_role_type( $user ) {
	if ( ! $user instanceof WP_User || ! $user->exists() ) {
		return 'customer';
	}

	// Admin roles.
	$admin_roles = apply_filters( 'zymarg_os_admin_roles', array( 'administrator', 'editor' ) );
	if ( array_intersect( $admin_roles, (array) $user->roles ) ) {
		return 'admin';
	}

	// Vendor roles (Dokan, WC Vendors, WCFM, etc.).
	$vendor_roles = apply_filters( 'zymarg_os_vendor_roles', array(
		'seller',
		'shop_manager',
		'dokandar',
		'wcfm_vendor',
		'vendor',
		'dc_vendor',
	) );
	if ( array_intersect( $vendor_roles, (array) $user->roles ) ) {
		return 'vendor';
	}

	return 'customer';
}

/* ---------------------------------------------------------------------- *
 * 3. Resolve the configured duration in seconds for a role type.
 * ---------------------------------------------------------------------- */

/**
 * Get the session duration (seconds) the admin has chosen for a role type.
 *
 * @param string $role_type One of 'customer', 'vendor', 'admin'.
 * @return int Duration in seconds.
 */
function zymarg_os_session_duration( $role_type ) {
	$choices = zymarg_os_session_choices();
	$default = '2_days';

	$setting_key = 'zymarg_session_' . $role_type;
	$chosen      = get_theme_mod( $setting_key, $default );

	if ( isset( $choices[ $chosen ] ) ) {
		return $choices[ $chosen ]['seconds'];
	}

	// Fallback: WordPress default 2 days.
	return 2 * DAY_IN_SECONDS;
}

/* ---------------------------------------------------------------------- *
 * 4. The master hook — override auth cookie expiration.
 * ---------------------------------------------------------------------- */

/**
 * Filter the authentication cookie expiration.
 *
 * This gives the theme master control over session length, regardless of
 * how the user logged in (branded form, wp-login.php, OTP, WooCommerce,
 * Dokan dashboard, any method).
 *
 * @param int  $length   Default expiration in seconds.
 * @param int  $user_id  User ID.
 * @param bool $remember Whether "remember me" was checked.
 * @return int Overridden expiration in seconds.
 */
function zymarg_os_auth_cookie_expiration( $length, $user_id, $remember ) {
	$user = get_userdata( $user_id );
	if ( ! $user ) {
		return $length;
	}

	$role_type = zymarg_os_session_role_type( $user );
	return zymarg_os_session_duration( $role_type );
}
add_filter( 'auth_cookie_expiration', 'zymarg_os_auth_cookie_expiration', 99, 3 );

/* ---------------------------------------------------------------------- *
 * 5. Customizer: Session Length controls inside the Login section.
 * ---------------------------------------------------------------------- */

/**
 * Register Session Length Customizer controls inside the Login section.
 *
 * @param WP_Customize_Manager $wp_customize Customizer manager.
 * @return void
 */
function zymarg_os_session_customizer( $wp_customize ) {
	$choices_raw = zymarg_os_session_choices();
	$choices     = array();
	foreach ( $choices_raw as $key => $data ) {
		$choices[ $key ] = $data['label'];
	}

	// Add controls to the existing Login section (no separate section).
	$s = 'zymarg_os_login_section';

	// --- Customer dropdown ---
	$wp_customize->add_setting( 'zymarg_session_customer', array(
		'default'           => '2_days',
		'sanitize_callback' => 'zymarg_os_sanitize_session_choice',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'zymarg_session_customer', array(
		'type'        => 'select',
		'label'       => __( 'Customer session length', 'zymarg-os' ),
		'description' => __( 'How long regular customers (buyers, subscribers) stay logged in.', 'zymarg-os' ),
		'section'     => $s,
		'choices'     => $choices,
		'priority'    => 200,
	) );

	// --- Vendor dropdown ---
	$wp_customize->add_setting( 'zymarg_session_vendor', array(
		'default'           => '2_days',
		'sanitize_callback' => 'zymarg_os_sanitize_session_choice',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'zymarg_session_vendor', array(
		'type'        => 'select',
		'label'       => __( 'Vendor session length', 'zymarg-os' ),
		'description' => __( 'How long vendors (sellers, shop managers) stay logged in.', 'zymarg-os' ),
		'section'     => $s,
		'choices'     => $choices,
		'priority'    => 201,
	) );

	// --- Admin dropdown ---
	$wp_customize->add_setting( 'zymarg_session_admin', array(
		'default'           => '2_days',
		'sanitize_callback' => 'zymarg_os_sanitize_session_choice',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'zymarg_session_admin', array(
		'type'        => 'select',
		'label'       => __( 'Admin session length', 'zymarg-os' ),
		'description' => __( 'How long administrators and editors stay logged in.', 'zymarg-os' ),
		'section'     => $s,
		'choices'     => $choices,
		'priority'    => 202,
	) );
}
add_action( 'customize_register', 'zymarg_os_session_customizer' );

/* ---------------------------------------------------------------------- *
 * 6. Sanitize callback.
 * ---------------------------------------------------------------------- */

/**
 * Sanitize a session-length dropdown value.
 *
 * @param string $value The submitted value.
 * @return string Sanitized value (falls back to '2_days' if invalid).
 */
function zymarg_os_sanitize_session_choice( $value ) {
	$valid = array_keys( zymarg_os_session_choices() );
	return in_array( $value, $valid, true ) ? $value : '2_days';
}
