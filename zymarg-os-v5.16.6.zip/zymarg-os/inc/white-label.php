<?php
/**
 * White label.
 *
 * Lets agencies rebrand how the theme appears in the admin (theme name, author,
 * description on the Appearance -> Themes screen). Controlled by the White Label
 * module + filters. No front-end impact.
 *
 * Configure via filters (e.g. in a small mu-plugin):
 *   add_filter( 'zymarg_os_white_label', function ( $info ) {
 *       $info['name']   = 'Acme Marketplace OS';
 *       $info['author'] = 'Acme Studio';
 *       return $info;
 *   } );
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Get white-label overrides.
 *
 * @return array{name:string,author:string,description:string,uri:string}
 */
function zymarg_os_white_label_info() {
	$defaults = array(
		'name'        => '',
		'author'      => '',
		'description' => '',
		'uri'         => '',
	);

	$info = apply_filters( 'zymarg_os_white_label', $defaults );

	return wp_parse_args( is_array( $info ) ? $info : array(), $defaults );
}

/**
 * Filter the theme headers shown in the admin.
 *
 * @param array $headers Theme headers.
 * @return array
 */
function zymarg_os_white_label_headers( $headers ) {
	$info = zymarg_os_white_label_info();

	if ( ! empty( $info['name'] ) ) {
		$headers['Name'] = $info['name'];
	}
	if ( ! empty( $info['author'] ) ) {
		$headers['Author'] = $info['author'];
	}
	if ( ! empty( $info['description'] ) ) {
		$headers['Description'] = $info['description'];
	}
	if ( ! empty( $info['uri'] ) ) {
		$headers['ThemeURI'] = $info['uri'];
	}

	return $headers;
}
add_filter( 'wp_get_theme_data_headers', 'zymarg_os_white_label_headers' );

/**
 * Also adjust the theme name returned by wp_get_theme()->get('Name') in admin
 * listings for older WordPress versions that don't fire the headers filter.
 *
 * @param string $translation Translated text.
 * @param string $text        Original text.
 * @return string
 */
function zymarg_os_white_label_name( $translation, $text ) {
	$info = zymarg_os_white_label_info();

	if ( ! empty( $info['name'] ) && 'ZYMARG OS' === $text ) {
		return $info['name'];
	}

	return $translation;
}
add_filter( 'gettext', 'zymarg_os_white_label_name', 10, 2 );
