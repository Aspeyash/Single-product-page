<?php
/**
 * Font localizer — "Load Google Fonts locally".
 *
 * When the Customizer Font Loading is set to "Self-host", the theme will
 * automatically download the Inter + Sora font files from Google to the site's
 * uploads directory (/uploads/zymarg-os-fonts/) and serve them from there —
 * faster and GDPR-friendly, with no manual file dropping.
 *
 * The download runs on YOUR live server (which has internet), triggered when
 * you Publish in the Customizer, or manually via the admin notice button. If
 * the download ever fails, the theme falls back to the static
 * /assets/fonts/fonts.css (and then to system fonts) so the site never breaks.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/** Option key storing localized-font metadata. */
if ( ! defined( 'ZYMARG_OS_LOCAL_FONTS_OPTION' ) ) {
	define( 'ZYMARG_OS_LOCAL_FONTS_OPTION', 'zymarg_os_localized_fonts' );
}

/**
 * Get the uploads sub-directory used for localized fonts.
 *
 * @return array{dir:string,url:string}
 */
function zymarg_os_fonts_dir() {
	$uploads = wp_get_upload_dir();
	return array(
		'dir' => trailingslashit( $uploads['basedir'] ) . 'zymarg-os-fonts',
		'url' => trailingslashit( $uploads['baseurl'] ) . 'zymarg-os-fonts',
	);
}

/**
 * Get the URL of the generated local font stylesheet, if it exists.
 *
 * @return string Empty string when fonts have not been localized.
 */
function zymarg_os_localized_fonts_css_url() {
	$data = get_option( ZYMARG_OS_LOCAL_FONTS_OPTION, array() );

	if ( ! empty( $data['css_url'] ) && ! empty( $data['css_path'] ) && file_exists( $data['css_path'] ) ) {
		return $data['css_url'];
	}

	return '';
}

/**
 * Whether the localized fonts are present and current for this theme version.
 *
 * @return bool
 */
function zymarg_os_fonts_are_localized() {
	$data = get_option( ZYMARG_OS_LOCAL_FONTS_OPTION, array() );

	return (
		! empty( $data['css_path'] )
		&& file_exists( $data['css_path'] )
		&& isset( $data['version'] )
		&& ZYMARG_OS_VERSION === $data['version']
	);
}

/**
 * Download the Google Fonts (Inter + Sora) to the uploads directory and write a
 * local @font-face stylesheet pointing at them.
 *
 * @return true|WP_Error True on success, WP_Error on failure.
 */
function zymarg_os_localize_google_fonts() {
	$css_url = zymarg_os_google_fonts_url();
	if ( ! $css_url ) {
		return new WP_Error( 'no_url', __( 'No Google Fonts URL to localize.', 'zymarg-os' ) );
	}

	// Fetch the Google CSS with a modern UA so we get woff2 sources.
	$response = wp_remote_get(
		$css_url,
		array(
			'timeout'    => 20,
			'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36',
		)
	);

	if ( is_wp_error( $response ) ) {
		return $response;
	}

	$css = wp_remote_retrieve_body( $response );
	if ( '' === trim( (string) $css ) ) {
		return new WP_Error( 'empty_css', __( 'Google Fonts returned an empty stylesheet.', 'zymarg-os' ) );
	}

	// Prepare the uploads directory + filesystem.
	$paths = zymarg_os_fonts_dir();
	if ( ! wp_mkdir_p( $paths['dir'] ) ) {
		return new WP_Error( 'mkdir', __( 'Could not create the fonts directory.', 'zymarg-os' ) );
	}

	require_once ABSPATH . 'wp-admin/includes/file.php';
	global $wp_filesystem;
	if ( ! WP_Filesystem() ) {
		return new WP_Error( 'filesystem', __( 'Could not initialise the filesystem.', 'zymarg-os' ) );
	}

	// Find every font-file URL in the CSS and download it locally.
	if ( ! preg_match_all( '/url\((https:\/\/[^)]+\.woff2?)\)/i', $css, $matches ) ) {
		return new WP_Error( 'no_files', __( 'No downloadable font files were found.', 'zymarg-os' ) );
	}

	$replaced = $css;
	foreach ( array_unique( $matches[1] ) as $remote_url ) {
		$filename = sanitize_file_name( basename( wp_parse_url( $remote_url, PHP_URL_PATH ) ) );
		if ( '' === $filename ) {
			continue;
		}

		$file_resp = wp_remote_get( $remote_url, array( 'timeout' => 20 ) );
		if ( is_wp_error( $file_resp ) || 200 !== wp_remote_retrieve_response_code( $file_resp ) ) {
			continue;
		}

		$body = wp_remote_retrieve_body( $file_resp );
		if ( '' === $body ) {
			continue;
		}

		if ( ! $wp_filesystem->put_contents( trailingslashit( $paths['dir'] ) . $filename, $body, FS_CHMOD_FILE ) ) {
			continue;
		}

		// Point the CSS at the local copy.
		$replaced = str_replace( $remote_url, trailingslashit( $paths['url'] ) . $filename, $replaced );
	}

	// Save the rewritten stylesheet.
	$css_path = trailingslashit( $paths['dir'] ) . 'fonts.css';
	if ( ! $wp_filesystem->put_contents( $css_path, $replaced, FS_CHMOD_FILE ) ) {
		return new WP_Error( 'write_css', __( 'Could not write the local fonts stylesheet.', 'zymarg-os' ) );
	}

	update_option(
		ZYMARG_OS_LOCAL_FONTS_OPTION,
		array(
			'css_path' => $css_path,
			'css_url'  => trailingslashit( $paths['url'] ) . 'fonts.css',
			'version'  => ZYMARG_OS_VERSION,
			'time'     => time(),
		)
	);

	return true;
}

/**
 * Auto-localize when the user publishes the Customizer with "Self-host" chosen
 * and the fonts aren't already downloaded for this version.
 *
 * @return void
 */
function zymarg_os_maybe_localize_on_save() {
	if ( 'local' !== zymarg_os_font_source() ) {
		return;
	}

	if ( zymarg_os_fonts_are_localized() ) {
		return;
	}

	zymarg_os_localize_google_fonts();
}
add_action( 'customize_save_after', 'zymarg_os_maybe_localize_on_save' );

/**
 * Admin-post handler for the manual "Download fonts now" button.
 *
 * @return void
 */
function zymarg_os_handle_localize_request() {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		wp_die( esc_html__( 'You are not allowed to do this.', 'zymarg-os' ) );
	}

	check_admin_referer( 'zymarg_os_localize_fonts' );

	$result = zymarg_os_localize_google_fonts();
	$status = is_wp_error( $result ) ? 'error' : 'success';

	wp_safe_redirect( add_query_arg( 'zymarg_fonts', $status, wp_get_referer() ? wp_get_referer() : admin_url( 'themes.php' ) ) );
	exit;
}
add_action( 'admin_post_zymarg_os_localize_fonts', 'zymarg_os_handle_localize_request' );

/**
 * Build the nonce-protected URL that triggers a manual font download.
 *
 * @return string
 */
function zymarg_os_localize_fonts_url() {
	return wp_nonce_url(
		admin_url( 'admin-post.php?action=zymarg_os_localize_fonts' ),
		'zymarg_os_localize_fonts'
	);
}

/**
 * Show an admin notice prompting a manual download if "Self-host" is selected
 * but the fonts have not been localized yet.
 *
 * @return void
 */
function zymarg_os_fonts_admin_notice() {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		return;
	}

	// Result feedback after a manual run.
	if ( isset( $_GET['zymarg_fonts'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$status = sanitize_key( wp_unslash( $_GET['zymarg_fonts'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$class  = ( 'success' === $status ) ? 'notice-success' : 'notice-error';
		$msg    = ( 'success' === $status )
			? __( 'ZYMARG OS: Google Fonts were downloaded and are now served locally.', 'zymarg-os' )
			: __( 'ZYMARG OS: Could not download the fonts. Check that your server can reach the internet, then try again.', 'zymarg-os' );
		printf( '<div class="notice %1$s is-dismissible"><p>%2$s</p></div>', esc_attr( $class ), esc_html( $msg ) );
	}

	if ( 'local' === zymarg_os_font_source() && ! zymarg_os_fonts_are_localized() ) {
		printf(
			'<div class="notice notice-warning"><p>%1$s <a class="button button-primary" href="%2$s">%3$s</a></p></div>',
			esc_html__( 'ZYMARG OS is set to self-host fonts, but they have not been downloaded yet.', 'zymarg-os' ),
			esc_url( zymarg_os_localize_fonts_url() ),
			esc_html__( 'Download fonts now', 'zymarg-os' )
		);
	}
}
add_action( 'admin_notices', 'zymarg_os_fonts_admin_notice' );
