<?php
/**
 * wp-admin colour scheme policy.
 *
 * wp-admin is pinned to LIGHT, on purpose.
 *
 * WordPress core chrome (body background, list tables, metaboxes, form
 * fields) is core CSS that a theme does not own. Loading dark tokens in
 * admin turned plugin text light while core stayed light grey, which made
 * text unreadable. A partial dark mode is worse than none, so rather than
 * half-applying it we pin admin to light and leave the front end alone.
 *
 * The front end is completely unaffected: this filter only runs in admin.
 *
 * Want a dark wp-admin today? Users -> Your Profile -> Admin Color Scheme
 * -> Midnight. That is core-maintained and complete.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Force the light scheme inside wp-admin only.
 *
 * @param string $scheme Configured scheme.
 * @return string
 */
if ( ! function_exists( 'zymarg_os_force_light_admin' ) ) {
	function zymarg_os_force_light_admin( $scheme ) {
		return is_admin() ? 'light' : $scheme;
	}
}
add_filter( 'zymarg_os_color_scheme', 'zymarg_os_force_light_admin', 99 );

/**
 * Load the LIGHT colour tokens in wp-admin, plus the shared screen chrome.
 *
 * tokens/dark.css is deliberately NOT loaded here.
 *
 * @return void
 */
if ( ! function_exists( 'zymarg_os_admin_screen_assets' ) ) {
	function zymarg_os_admin_screen_assets() {
		$ver = defined( 'ZYMARG_OS_VERSION' ) ? ZYMARG_OS_VERSION : false;

		wp_enqueue_style(
			'zymarg-os-token-colors',
			ZYMARG_OS_URI . '/tokens/colors.css',
			array(),
			$ver
		);

		wp_enqueue_style(
			'zymarg-os-admin-screens',
			ZYMARG_OS_URI . '/assets/css/admin-screens.css',
			array( 'zymarg-os-token-colors' ),
			$ver
		);

		/*
		 * Sidebar width. Bumps desktop from core's 160px to 190px so long
		 * plugin labels ("Connection Engine", "Login & Security", any
		 * future ZYMARG plugin) sit on one line -- matching what WP core
		 * already does on the responsive mobile drawer. No token
		 * dependency: the file only overrides width and margin-left. See
		 * assets/css/admin-sidebar.css for the full note.
		 */
		wp_enqueue_style(
			'zymarg-os-admin-sidebar',
			ZYMARG_OS_URI . '/assets/css/admin-sidebar.css',
			array(),
			$ver
		);
	}
}
add_action( 'admin_enqueue_scripts', 'zymarg_os_admin_screen_assets' );
