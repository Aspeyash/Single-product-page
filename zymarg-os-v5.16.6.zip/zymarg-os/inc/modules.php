<?php
/**
 * Modular activation system.
 *
 * Lets each feature of ZYMARG OS be switched on/off so only the code you use is
 * loaded — keeping the front end lean. Defaults are defined here; the Customizer
 * (ZYMARG OS -> Modules) writes overrides into a single option, and developers
 * can override anything via the `zymarg_os_modules` / `zymarg_os_module_enabled`
 * filters.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * The option key that stores module on/off state.
 */
if ( ! defined( 'ZYMARG_OS_MODULES_OPTION' ) ) {
	define( 'ZYMARG_OS_MODULES_OPTION', 'zymarg_os_modules' );
}

/**
 * Default module registry.
 *
 * @return array<string,array<string,mixed>> Map of module key => metadata.
 */
function zymarg_os_default_modules() {
	$modules = array(
		'performance'   => array(
			'label'       => __( 'Performance', 'zymarg-os' ),
			'description' => __( 'Disable emojis, dequeue unused assets, defer scripts and add resource hints.', 'zymarg-os' ),
			'default'     => true,
		),
		'lazy_images'   => array(
			'label'       => __( 'Lazy Images', 'zymarg-os' ),
			'description' => __( 'Lazy-load images and iframes (with async decoding) for faster pages. Turn off to load every image immediately.', 'zymarg-os' ),
			'default'     => true,
		),
		'svg_upload'    => array(
			'label'       => __( 'SVG Uploads', 'zymarg-os' ),
			'description' => __( 'Let administrators upload SVG images to the Media Library. Each SVG is automatically sanitized (scripts and event handlers stripped) before it is saved.', 'zymarg-os' ),
			'default'     => true,
		),
		'woocommerce'   => array(
			'label'       => __( 'WooCommerce', 'zymarg-os' ),
			'description' => __( 'Shop layouts, Quick View, off-canvas cart and Dokan styling.', 'zymarg-os' ),
			'default'     => true,
		),
		'theme_cart_styling' => array(
			'label'       => __( 'Theme Cart Styling', 'zymarg-os' ),
			'description' => __( 'Load the theme\'s cart page CSS. Turn OFF if you use a custom cart plugin (e.g. ZYMARG Cart) that provides its own styling.', 'zymarg-os' ),
			'default'     => true,
		),
		'theme_checkout_styling' => array(
			'label'       => __( 'Theme Checkout Styling', 'zymarg-os' ),
			'description' => __( 'Load the theme\'s checkout page CSS + anti-shift system. Turn OFF if you use a custom checkout plugin (e.g. ZYMARG Checkout) that provides its own styling.', 'zymarg-os' ),
			'default'     => true,
		),
		'mega_menu'     => array(
			'label'       => __( 'Mega Menu', 'zymarg-os' ),
			'description' => __( 'Multi-column dropdown menus and sticky navigation support.', 'zymarg-os' ),
			'default'     => true,
		),
		'scroll_to_top' => array(
			'label'       => __( 'Scroll to Top', 'zymarg-os' ),
			'description' => __( 'A floating button that smoothly scrolls back to the top.', 'zymarg-os' ),
			'default'     => true,
		),
		'custom_fonts'  => array(
			'label'       => __( 'Custom Fonts', 'zymarg-os' ),
			'description' => __( 'Upload your own font files and assign them to headings and body text.', 'zymarg-os' ),
			'default'     => true,
		),
		'white_label'   => array(
			'label'       => __( 'White Label', 'zymarg-os' ),
			'description' => __( 'Rebrand the theme name and author in the admin (agency mode).', 'zymarg-os' ),
			'default'     => false,
		),
		'learndash'     => array(
			'label'       => __( 'LearnDash / LMS', 'zymarg-os' ),
			'description' => __( 'Styling and layout integration for LearnDash course sites.', 'zymarg-os' ),
			'default'     => true,
		),
		'instant_load'  => array(
			'label'       => __( 'Instant Load', 'zymarg-os' ),
			'description' => __( 'Preload pages on hover/tap so navigation feels instant.', 'zymarg-os' ),
			'default'     => true,
		),
		'scroll_animations' => array(
			'label'       => __( 'Scroll Animations', 'zymarg-os' ),
			'description' => __( 'Reveal elements with the "zymarg-reveal" class as they scroll into view.', 'zymarg-os' ),
			'default'     => true,
		),
		'breadcrumbs'   => array(
			'label'       => __( 'Breadcrumbs', 'zymarg-os' ),
			'description' => __( 'Breadcrumb trail via [zymarg_breadcrumbs], with optional auto-display and schema.', 'zymarg-os' ),
			'default'     => true,
		),
		'schema'        => array(
			'label'       => __( 'SEO Schema', 'zymarg-os' ),
			'description' => __( 'Organization + WebSite (search box) structured data for rich results. Defers to active SEO plugins.', 'zymarg-os' ),
			'default'     => true,
		),
	);

	/**
	 * Filter the registry of available modules.
	 *
	 * @param array $modules Module registry.
	 */
	return apply_filters( 'zymarg_os_modules', $modules );
}

/**
 * Get the saved module state merged with defaults.
 *
 * @return array<string,bool> Map of module key => enabled.
 */
function zymarg_os_get_modules_state() {
	$defaults = array();
	foreach ( zymarg_os_default_modules() as $key => $meta ) {
		$defaults[ $key ] = ! empty( $meta['default'] );
	}

	$saved = get_option( ZYMARG_OS_MODULES_OPTION, array() );
	if ( ! is_array( $saved ) ) {
		$saved = array();
	}

	return wp_parse_args( $saved, $defaults );
}

/**
 * Check whether a given module is enabled.
 *
 * @param string $module Module key, e.g. 'woocommerce'.
 * @return bool
 */
function zymarg_os_module_enabled( $module ) {
	$state   = zymarg_os_get_modules_state();
	$enabled = isset( $state[ $module ] ) ? (bool) $state[ $module ] : false;

	/**
	 * Filter whether a single module is enabled.
	 *
	 * @param bool   $enabled Whether the module is enabled.
	 * @param string $module  Module key.
	 */
	return (bool) apply_filters( 'zymarg_os_module_enabled', $enabled, $module );
}
