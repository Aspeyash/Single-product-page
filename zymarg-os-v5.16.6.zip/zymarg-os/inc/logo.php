<?php
/**
 * Site logo shortcode.
 *
 * Outputs the WordPress Custom Logo (Customize -> Site Identity -> Logo) so it
 * can be dropped into a page builder (e.g. an Elementor Shortcode widget),
 * a widget, or any content. Falls back to the site title when no logo is set.
 *
 *   [zymarg_logo]                       Logo, linked to the homepage
 *   [zymarg_logo size="48"]             Cap the height at 48px
 *   [zymarg_logo link="false"]          Render without the homepage link
 *   [zymarg_logo class="my-logo"]       Add a custom CSS class
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Build the site-logo markup.
 *
 * @param array<string,mixed> $atts Shortcode attributes.
 * @return string
 */
function zymarg_os_logo_shortcode( $atts ) {
	$atts = shortcode_atts(
		array(
			'size'  => '',      // max height in px (optional)
			'link'  => 'true',  // wrap in a homepage link
			'class' => '',
			'alt'   => '',       // custom alt text (defaults to site name)
		),
		$atts,
		'zymarg_logo'
	);

	$link    = filter_var( $atts['link'], FILTER_VALIDATE_BOOLEAN );
	$classes = 'zymarg-logo';
	if ( $atts['class'] ) {
		$classes .= ' ' . sanitize_html_class( $atts['class'] );
	}

	// Inner content: the custom logo image, or the site title as a fallback.
	if ( has_custom_logo() ) {
		$logo_id   = (int) get_theme_mod( 'custom_logo' );
		$alt       = ( '' !== $atts['alt'] ) ? $atts['alt'] : get_bloginfo( 'name' );
		$img_style = 'height:auto;width:auto;display:block;';
		if ( '' !== $atts['size'] && is_numeric( $atts['size'] ) ) {
			$img_style .= 'max-height:' . absint( $atts['size'] ) . 'px;';
		}
		$inner = wp_get_attachment_image(
			$logo_id,
			'full',
			false,
			array(
				'class' => 'zymarg-logo__img',
				'alt'   => esc_attr( $alt ),
				'style' => $img_style,
			)
		);
		if ( ! $inner ) {
			$inner = '<span class="zymarg-logo__text">' . esc_html( get_bloginfo( 'name' ) ) . '</span>';
		}
	} else {
		$size_css = ( '' !== $atts['size'] && is_numeric( $atts['size'] ) ) ? 'font-size:' . absint( $atts['size'] ) . 'px;' : '';
		$inner    = '<span class="zymarg-logo__text" style="font-family:var(--zymarg-font-heading);font-weight:700;line-height:1;' . esc_attr( $size_css ) . '">' . esc_html( get_bloginfo( 'name' ) ) . '</span>';
	}

	if ( $link ) {
		$out = '<a class="' . esc_attr( $classes ) . '" href="' . esc_url( home_url( '/' ) ) . '" rel="home" style="display:inline-block;line-height:0;text-decoration:none;color:inherit;">' . $inner . '</a>';
	} else {
		$out = '<span class="' . esc_attr( $classes ) . '" style="display:inline-block;line-height:0;">' . $inner . '</span>';
	}

	/**
	 * Filter the site-logo shortcode output.
	 *
	 * @param string $out  Markup.
	 * @param array  $atts Attributes.
	 */
	return apply_filters( 'zymarg_os_logo_markup', $out, $atts );
}
add_shortcode( 'zymarg_logo', 'zymarg_os_logo_shortcode' );
