<?php
/**
 * Login source monitor — alerts on BOTH channels whenever the login source
 * changes: (1) an email, and (2) a native wp-admin dashboard notification.
 *
 * Two states:
 *   1. "plugin"  — the ZYMARG Login & Security plugin is active and owns the
 *                  login card, popup, wp-login branding, session, Google/OTP/
 *                  passkeys/REST API.
 *   2. "theme"   — the plugin is not active; the theme's built-in login.php +
 *                  session-control.php are handling login (as a fallback).
 *
 * EMAIL: on every admin page load (admin_init) this file detects the current
 * state and compares it to the LAST KNOWN state stored in the DB. If it
 * changed, it emails the configured address ONCE. No repeated emails while
 * the state stays the same.
 *
 * WP-ADMIN NOTICE: independently, a dismissible notice is shown on every
 * wp-admin screen whenever the current state differs from the state the
 * admin last ACKNOWLEDGED (dismissed). This tracks separately from the email
 * so dismissing one never silences the other.
 *
 * Recipient (checked in this order):
 *   1. Customizer field "Login source alert email" (theme_mod
 *      zymarg_login_source_alert_email) — Customize -> ZYMARG OS -> Login.
 *      This is ALWAYS registered by this file, regardless of whether the
 *      theme or the plugin is currently handling login, so the field never
 *      disappears on you.
 *   2. Legacy option zymarg_os_login_source_email (kept for anyone who set
 *      it via code before this Customizer field existed).
 *   3. The site's admin_email.
 *
 * Options used:
 *   zymarg_os_login_source_state   — 'plugin' | 'theme' | '' (never seen)
 *
 * Filters:
 *   zymarg_os_login_source_notify_enabled  — bool, kill-switch (default true)
 *   zymarg_os_login_source_email           — string, recipient (final override)
 *   zymarg_os_login_source_email_subject   — string, email subject
 *   zymarg_os_login_source_email_body      — string, email body
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Is the ZYMARG Login & Security plugin active this request?
 *
 * @return bool
 */
function zymarg_os_zls_plugin_active() {
	return defined( 'ZLS_VERSION' );
}

/**
 * Define the read-only Customizer status-control class.
 *
 * CRITICAL: this MUST run inside a function that is only ever called from
 * within the 'customize_register' action (see the hook at the bottom of this
 * block). `WP_Customize_Control` is a WordPress core class that is ONLY
 * loaded while the Customizer is actually bootstrapping — it does NOT exist
 * on regular admin pages (Dashboard, Plugins, etc.) or the front end. A
 * previous version of this file defined the class at file-scope (executed
 * immediately whenever this always-loaded file was required), which crashed
 * the entire site with "Class WP_Customize_Control not found" on every
 * request. This mirrors the safe pattern already used by the theme's own
 * inc/customize-controls.php: guard with class_exists( 'WP_Customize_Control' )
 * and only define the class from inside a customize_register callback.
 *
 * @return void
 */
function zymarg_os_register_login_source_status_control() {
	if ( ! class_exists( 'WP_Customize_Control' ) ) {
		return;
	}
	if ( class_exists( 'Zymarg_Customize_Login_Source_Status_Control' ) ) {
		return;
	}

	/**
	 * Read-only Customizer control: shows which system is currently running
	 * login (plugin vs. theme fallback).
	 *
	 * This is deliberately a STATUS READOUT, not a switch — which login
	 * system runs is decided automatically by whether the plugin is active,
	 * and letting an admin manually "turn off" the theme fallback while the
	 * plugin is also inactive would leave the site with no login screen at
	 * all. So instead of a toggle, this control tells you the truth at a
	 * glance, plus a link to the one place that actually controls it (the
	 * Plugins page).
	 */
	class Zymarg_Customize_Login_Source_Status_Control extends WP_Customize_Control {
		public $type = 'zymarg_login_source_status';

		/**
		 * Render the read-only status card.
		 *
		 * @return void
		 */
		public function render_content() {
			$is_plugin   = zymarg_os_zls_plugin_active();
			$plugins_url = admin_url( 'plugins.php' );

			if ( $is_plugin ) {
				$dot_color = '#1a7f37';
				$label     = __( 'Plugin is running your login screen', 'zymarg-os' );
				$sub       = __( 'ZYMARG Login & Security is active — Google sign-in, OTP, passkeys, sessions and the REST API are all on. The theme\'s built-in login code is not loaded.', 'zymarg-os' );
			} else {
				$dot_color = '#b32d2e';
				$label     = __( 'Theme fallback is running your login screen', 'zymarg-os' );
				$sub       = __( 'The ZYMARG Login & Security plugin is not active, so the theme\'s built-in login has automatically taken over. Basic sign-in still works, but Google sign-in, OTP, passkeys, sessions and the REST API are OFF.', 'zymarg-os' );
			}
			?>
			<div style="margin-bottom:10px;">
				<span class="customize-control-title"><?php esc_html_e( 'Login source (read-only status)', 'zymarg-os' ); ?></span>
			</div>
			<div style="display:flex;align-items:flex-start;gap:8px;padding:10px 12px;background:#f6f7f7;border:1px solid #dcdcde;border-radius:4px;">
				<span style="flex-shrink:0;width:10px;height:10px;margin-top:4px;border-radius:50%;background:<?php echo esc_attr( $dot_color ); ?>;"></span>
				<div>
					<p style="margin:0 0 4px;font-weight:600;"><?php echo esc_html( $label ); ?></p>
					<p style="margin:0;font-size:12px;color:#555;"><?php echo esc_html( $sub ); ?></p>
				</div>
			</div>
			<p class="description" style="margin-top:8px;">
				<?php
				printf(
					/* translators: %s: link to the Plugins page */
					wp_kses_post( __( 'This switches automatically — there is no manual on/off here. To change it, activate or deactivate the plugin on the %s.', 'zymarg-os' ) ),
					'<a href="' . esc_url( $plugins_url ) . '" target="_blank" rel="noopener">' . esc_html__( 'Plugins page', 'zymarg-os' ) . '</a>'
				);
				?>
			</p>
			<?php
		}
	}
}
// Priority 1: run BEFORE zymarg_os_login_source_customizer() below (default
// priority 10) so the class already exists by the time it's instantiated.
// This is safe irrespective of ordering vs. WP_Customize_Control's own
// availability — WordPress core guarantees that class is loaded before ANY
// customize_register callback fires, regardless of priority.
add_action( 'customize_register', 'zymarg_os_register_login_source_status_control', 1 );

/**
 * Register the login-source status readout + the alert-email field.
 *
 * Both attach to the existing 'zymarg_os_login_section' section — that
 * section is registered by whichever of the theme or the plugin is currently
 * active (both use the identical slug), so these controls are always
 * reachable from Customize -> ZYMARG OS -> Login, no matter which system is
 * running login.
 *
 * @param WP_Customize_Manager $wp_customize Customizer manager.
 * @return void
 */
function zymarg_os_login_source_customizer( $wp_customize ) {
	if ( ! class_exists( 'Zymarg_Customize_Login_Source_Status_Control' ) ) {
		return; // Defensive — should never happen given the priority-1 hook above.
	}

	// Status readout — a setting is required by the Customizer API even
	// though this control never actually saves anything meaningful.
	$wp_customize->add_setting( 'zymarg_login_source_status', array(
		'default'            => '',
		'sanitize_callback'  => '__return_empty_string',
		'capability'         => 'activate_plugins',
	) );
	$wp_customize->add_control( new Zymarg_Customize_Login_Source_Status_Control( $wp_customize, 'zymarg_login_source_status', array(
		'section'  => 'zymarg_os_login_section',
		'priority' => 0, // Show it at the very top of the Login section.
	) ) );

	$wp_customize->add_setting( 'zymarg_login_source_alert_email', array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_email',
	) );
	$wp_customize->add_control( 'zymarg_login_source_alert_email', array(
		'type'        => 'email',
		'label'       => __( 'Login source alert email', 'zymarg-os' ),
		'description' => __( 'Get emailed whenever login switches between the ZYMARG Login & Security plugin and the theme fallback. Leave blank to use the site admin email.', 'zymarg-os' ),
		'section'     => 'zymarg_os_login_section',
		'priority'    => 500, // After every other Login section field.
	) );
}
add_action( 'customize_register', 'zymarg_os_login_source_customizer' );

/**
 * Detect the current login source and email the admin if it changed.
 *
 * @return void
 */
function zymarg_os_login_source_monitor() {
	// Kill-switch filter.
	if ( ! apply_filters( 'zymarg_os_login_source_notify_enabled', true ) ) {
		return;
	}

	$current_state = zymarg_os_zls_plugin_active() ? 'plugin' : 'theme';
	$stored_state  = get_option( 'zymarg_os_login_source_state', '' );

	// First-ever run: save state silently (no email on initial install).
	if ( '' === $stored_state ) {
		update_option( 'zymarg_os_login_source_state', $current_state, false );
		return;
	}

	// No change → nothing to do.
	if ( $current_state === $stored_state ) {
		return;
	}

	// State changed! Persist first, then email.
	update_option( 'zymarg_os_login_source_state', $current_state, false );
	zymarg_os_login_source_send_email( $current_state );
}
add_action( 'admin_init', 'zymarg_os_login_source_monitor' );

/**
 * Send the "login source changed" notification email.
 *
 * @param string $new_state 'plugin' or 'theme'.
 * @return void
 */
function zymarg_os_login_source_send_email( $new_state ) {
	// Recipient, checked in order: Customizer field -> legacy option -> admin_email.
	$recipient = trim( (string) get_theme_mod( 'zymarg_login_source_alert_email', '' ) );
	if ( '' === $recipient ) {
		$recipient = trim( (string) get_option( 'zymarg_os_login_source_email', '' ) );
	}
	if ( '' === $recipient ) {
		$recipient = get_option( 'admin_email' );
	}
	$recipient = apply_filters( 'zymarg_os_login_source_email', $recipient );

	if ( empty( $recipient ) || ! is_email( $recipient ) ) {
		return;
	}

	$site_name   = wp_specialchars_decode( get_option( 'blogname' ), ENT_QUOTES );
	$login_url   = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : home_url( '/my-account/' );
	$plugins_url = admin_url( 'plugins.php' );
	$now         = wp_date( 'Y-m-d H:i:s T' );

	if ( 'plugin' === $new_state ) {
		$subject = sprintf(
			/* translators: %s: site name */
			__( '[%s] Login is now running via ZYMARG Login & Security plugin', 'zymarg-os' ),
			$site_name
		);

		$lines = array(
			sprintf( __( 'Login source changed on %s at %s.', 'zymarg-os' ), $site_name, $now ),
			'',
			__( 'CURRENT SOURCE: ZYMARG Login & Security plugin (full features)', 'zymarg-os' ),
			'',
			__( 'The plugin is active and handling:', 'zymarg-os' ),
			__( '  + Branded login card + popup', 'zymarg-os' ),
			__( '  + Google sign-in / One Tap', 'zymarg-os' ),
			__( '  + Phone / OTP sign-in', 'zymarg-os' ),
			__( '  + Passkeys (biometric sign-in)', 'zymarg-os' ),
			__( '  + Session management, audit log, ban list', 'zymarg-os' ),
			__( '  + New-device alerts, suspicious-login detection', 'zymarg-os' ),
			__( '  + Mobile-app REST API (/wp-json/zls/v1)', 'zymarg-os' ),
			__( '  + Sign-in funnel + Bangladesh heatmap insights', 'zymarg-os' ),
			__( '  + Admin Power (impersonate + merge)', 'zymarg-os' ),
			'',
			__( 'The theme login code is NOT loaded (zero redundancy).', 'zymarg-os' ),
			'',
			sprintf( __( 'Login page: %s', 'zymarg-os' ), $login_url ),
			'',
			__( 'No action needed — this is the expected state.', 'zymarg-os' ),
		);
	} else {
		$subject = sprintf(
			/* translators: %s: site name */
			__( '[%s] Login is running on the THEME fallback', 'zymarg-os' ),
			$site_name
		);

		$lines = array(
			sprintf( __( 'Login source changed on %s at %s.', 'zymarg-os' ), $site_name, $now ),
			'',
			__( 'CURRENT SOURCE: ZYMARG OS theme (fallback mode)', 'zymarg-os' ),
			'',
			__( 'The "ZYMARG Login & Security" plugin appears INACTIVE.', 'zymarg-os' ),
			__( "The theme's built-in login screen has taken over, so customers and vendors can still sign in.", 'zymarg-os' ),
			'',
			__( 'But these plugin-only features are currently OFF:', 'zymarg-os' ),
			__( '  - Google sign-in / One Tap', 'zymarg-os' ),
			__( '  - Phone / OTP sign-in', 'zymarg-os' ),
			__( '  - Passkeys (biometric sign-in)', 'zymarg-os' ),
			__( '  - Session management, audit log, ban list', 'zymarg-os' ),
			__( '  - New-device alerts, suspicious-login detection', 'zymarg-os' ),
			__( '  - Mobile-app REST API (/wp-json/zls/v1)', 'zymarg-os' ),
			__( '  - Sign-in funnel + Bangladesh heatmap insights', 'zymarg-os' ),
			__( '  - Admin Power (impersonate + merge)', 'zymarg-os' ),
			'',
			__( 'What to do: reactivate the plugin to restore the full login experience.', 'zymarg-os' ),
			'',
			sprintf( __( 'Plugins page: %s', 'zymarg-os' ), $plugins_url ),
			sprintf( __( 'Login page:   %s', 'zymarg-os' ), $login_url ),
		);
	}

	$lines[] = '';
	$lines[] = __( 'You get this email once per state change. No repeats until the source switches again.', 'zymarg-os' );
	$lines[] = '';
	$lines[] = '-- ZYMARG OS';

	$subject = (string) apply_filters( 'zymarg_os_login_source_email_subject', $subject, $new_state, $site_name );
	$message = implode( "\n", $lines );
	$message = (string) apply_filters( 'zymarg_os_login_source_email_body', $message, $new_state, $site_name );

	wp_mail( $recipient, $subject, $message );
}

/**
 * WordPress admin notification (in addition to the email).
 *
 * Shows a native wp-admin notice whenever the CURRENT login source is
 * different from the last state the admin ACKNOWLEDGED (dismissed). This is
 * intentionally separate from the email's "state" tracking so the two never
 * interfere: dismissing the on-screen notice does not stop future emails, and
 * vice versa.
 *
 *   - Login running via the PLUGIN  → green success notice.
 *   - Login running via the THEME fallback → yellow warning notice, plus a
 *     link straight to the Plugins page.
 *
 * Clicking "Dismiss" fires a tiny AJAX call (zymarg_os_ack_login_notice) that
 * records the current state as acknowledged, so the notice disappears and
 * stays gone until the source changes AGAIN.
 *
 * @return void
 */
function zymarg_os_login_source_admin_notice() {
	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}

	$current_state = zymarg_os_zls_plugin_active() ? 'plugin' : 'theme';
	$acked_state   = get_option( 'zymarg_os_login_source_notice_ack', '' );

	// First-ever run: seed the ack state silently so there's no notice before
	// the admin has ever seen a real transition (mirrors the email behaviour).
	if ( '' === $acked_state ) {
		update_option( 'zymarg_os_login_source_notice_ack', $current_state, false );
		return;
	}

	// Already acknowledged this exact state → nothing to show.
	if ( $current_state === $acked_state ) {
		return;
	}

	$plugins_url = admin_url( 'plugins.php' );
	$nonce       = wp_create_nonce( 'zymarg_os_ack_login_notice' );

	if ( 'plugin' === $current_state ) {
		$notice_class = 'notice-success';
		$message      = esc_html__( 'Login is now running via the ZYMARG Login & Security plugin. Google sign-in, OTP, passkeys, sessions and the REST API are all active.', 'zymarg-os' );
		$link         = '';
	} else {
		$notice_class = 'notice-warning';
		$message      = esc_html__( 'Login has switched to the theme fallback. The "ZYMARG Login & Security" plugin is not active — Google sign-in, OTP, passkeys, sessions and the REST API are OFF.', 'zymarg-os' );
		$link         = ' <a href="' . esc_url( $plugins_url ) . '">' . esc_html__( 'Open Plugins', 'zymarg-os' ) . '</a>';
	}

	printf(
		'<div class="notice %1$s is-dismissible zymarg-os-login-source-notice" data-state="%2$s" data-nonce="%3$s"><p><strong>%4$s</strong> %5$s%6$s</p></div>',
		esc_attr( $notice_class ),
		esc_attr( $current_state ),
		esc_attr( $nonce ),
		esc_html__( 'ZYMARG OS:', 'zymarg-os' ),
		$message, // Already escaped above.
		$link // Already escaped above.
	);

	// Tiny inline script: on WP's own dismiss click (the built-in "is-dismissible"
	// button), fire the AJAX ack call so this exact state won't be re-shown.
	?>
	<script>
	( function () {
		document.addEventListener( 'click', function ( e ) {
			var notice = e.target.closest( '.zymarg-os-login-source-notice' );
			if ( ! notice ) {
				return;
			}
			var btn = e.target.closest( '.notice-dismiss' );
			if ( ! btn ) {
				return;
			}
			var body = new FormData();
			body.append( 'action', 'zymarg_os_ack_login_notice' );
			body.append( 'state', notice.getAttribute( 'data-state' ) );
			body.append( 'nonce', notice.getAttribute( 'data-nonce' ) );
			fetch( ajaxurl, { method: 'POST', credentials: 'same-origin', body: body } );
		}, true );
	} )();
	</script>
	<?php
}
add_action( 'admin_notices', 'zymarg_os_login_source_admin_notice' );

/**
 * AJAX: acknowledge the on-screen login-source notice.
 *
 * Records the state the admin just dismissed, so that exact state won't
 * trigger the notice again until the login source changes.
 *
 * @return void
 */
function zymarg_os_ajax_ack_login_notice() {
	check_ajax_referer( 'zymarg_os_ack_login_notice', 'nonce' );

	if ( ! current_user_can( 'activate_plugins' ) ) {
		wp_send_json_error( array( 'message' => 'forbidden' ), 403 );
	}

	$state = isset( $_POST['state'] ) ? sanitize_key( wp_unslash( $_POST['state'] ) ) : '';
	if ( ! in_array( $state, array( 'plugin', 'theme' ), true ) ) {
		wp_send_json_error( array( 'message' => 'invalid_state' ) );
	}

	update_option( 'zymarg_os_login_source_notice_ack', $state, false );
	wp_send_json_success();
}
add_action( 'wp_ajax_zymarg_os_ack_login_notice', 'zymarg_os_ajax_ack_login_notice' );
