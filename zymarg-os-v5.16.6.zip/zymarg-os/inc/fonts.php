<?php
/**
 * Font engine.
 *
 * ZYMARG OS gives you four ways to load fonts, chosen via the Customizer
 * (ZYMARG OS -> Typography -> Font Loading):
 *
 *   1. google  — Inter + Sora from Google Fonts, but optimised: preconnect
 *                resource hints + `display=swap` + only the weights used. This
 *                is the fast default.
 *   2. local   — Self-hosted Inter + Sora served from /assets/fonts via an
 *                @font-face stylesheet. GDPR-friendly and the fastest option
 *                once the .woff2 files are present.
 *   3. custom  — Upload your OWN font files (.woff2/.woff/.ttf) for headings
 *                and/or body and the theme generates the @font-face rules.
 *   4. system  — Use the visitor's system fonts (zero requests).
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Small helper to read a theme mod with a default.
 *
 * @param string $key     Theme mod key.
 * @param mixed  $default Fallback value.
 * @return mixed
 */
function zymarg_os_get_option( $key, $default = '' ) {
	return get_theme_mod( $key, $default );
}

/**
 * Which font source is active.
 *
 * @return string One of 'google', 'local', 'custom', 'system'.
 */
function zymarg_os_font_source() {
	$source  = zymarg_os_get_option( 'zymarg_font_source', 'google' );
	$allowed = array( 'google', 'local', 'custom', 'system' );

	if ( ! in_array( $source, $allowed, true ) ) {
		$source = 'google';
	}

	return $source;
}

/**
 * The chosen heading + body font family NAMES (just the names, e.g. "Inter",
 * "Poppins"). Defaults to the brand pairing Sora (heading) + Inter (body).
 * Customizer text controls let the merchant type any Google Fonts family name.
 *
 * @return array{heading:string,body:string}
 */
function zymarg_os_font_families() {
	$heading = trim( (string) zymarg_os_get_option( 'zymarg_font_heading_name', 'Sora' ) );
	$body    = trim( (string) zymarg_os_get_option( 'zymarg_font_body_name', 'Inter' ) );

	if ( '' === $heading ) {
		$heading = 'Sora';
	}
	if ( '' === $body ) {
		$body = 'Inter';
	}

	return array(
		'heading' => $heading,
		'body'    => $body,
	);
}

/**
 * Font weights to load (kept small for performance). Keyed by the chosen
 * family names so a custom Google font loads the full weight range the theme
 * uses (300–800 covers every heading-weight and body-weight choice).
 *
 * @return array<string,string> family => weight list.
 */
function zymarg_os_font_weights() {
	$families = zymarg_os_font_families();

	// A broad-but-reasonable weight set so any heading/body weight choice works.
	$weights = array(
		$families['body']    => '300;400;500;600;700',
		$families['heading'] => '400;500;600;700;800',
	);

	// If heading and body are the SAME family, merge to one request.
	if ( $families['heading'] === $families['body'] ) {
		$weights = array(
			$families['body'] => '300;400;500;600;700;800',
		);
	}

	return apply_filters( 'zymarg_os_font_weights', $weights );
}

/**
 * Add preconnect resource hints for Google Fonts (only when that source is
 * active). Speeds up the handshake to Google's CDN.
 *
 * @param array  $urls           URLs to print.
 * @param string $relation_type  Relation type being filtered.
 * @return array
 */
function zymarg_os_resource_hints( $urls, $relation_type ) {
	if ( 'preconnect' === $relation_type && 'google' === zymarg_os_font_source() ) {
		$urls[] = array(
			'href' => 'https://fonts.googleapis.com',
		);
		$urls[] = array(
			'href'        => 'https://fonts.gstatic.com',
			'crossorigin' => 'anonymous',
		);
	}

	return $urls;
}
add_filter( 'wp_resource_hints', 'zymarg_os_resource_hints', 10, 2 );

/**
 * Build the optimised Google Fonts URL.
 *
 * @return string
 */
function zymarg_os_google_fonts_url() {
	$weights = zymarg_os_font_weights();
	$parts   = array();

	foreach ( $weights as $family => $weight ) {
		$parts[] = 'family=' . rawurlencode( $family ) . ':wght@' . $weight;
	}

	if ( empty( $parts ) ) {
		return '';
	}

	return 'https://fonts.googleapis.com/css2?' . implode( '&', $parts ) . '&display=swap';
}

/**
 * Enqueue fonts according to the chosen source.
 *
 * @return void
 */
function zymarg_os_enqueue_fonts() {
	$source = zymarg_os_font_source();

	if ( 'google' === $source ) {
		$url = zymarg_os_google_fonts_url();
		if ( $url ) {
			wp_enqueue_style( 'zymarg-os-google-fonts', $url, array(), null );
		}
		return;
	}

	if ( 'local' === $source ) {
		// Prefer auto-downloaded fonts in /uploads (see inc/font-localizer.php);
		// fall back to the static self-host stylesheet in /assets/fonts.
		$localized = function_exists( 'zymarg_os_localized_fonts_css_url' ) ? zymarg_os_localized_fonts_css_url() : '';

		if ( $localized ) {
			wp_enqueue_style( 'zymarg-os-local-fonts', $localized, array(), ZYMARG_OS_VERSION );
		} else {
			wp_enqueue_style(
				'zymarg-os-local-fonts',
				ZYMARG_OS_URI . '/assets/fonts/fonts.css',
				array(),
				ZYMARG_OS_VERSION
			);
		}
		return;
	}

	// 'custom' and 'system' inject @font-face / variables inline (see below).
}
add_action( 'wp_enqueue_scripts', 'zymarg_os_enqueue_fonts', 5 );

/**
 * Generate @font-face CSS for user-uploaded custom fonts.
 *
 * Reads the Customizer upload URLs and produces @font-face blocks with
 * `font-display: swap`. Returns an empty string when no custom fonts are set.
 *
 * @return string
 */
function zymarg_os_custom_fontface_css() {
	if ( 'custom' !== zymarg_os_font_source() ) {
		return '';
	}

	$css   = '';
	$faces = array(
		'heading' => zymarg_os_get_option( 'zymarg_custom_font_heading', '' ),
		'body'    => zymarg_os_get_option( 'zymarg_custom_font_body', '' ),
	);

	foreach ( $faces as $slot => $url ) {
		$url = trim( (string) $url );
		if ( '' === $url ) {
			continue;
		}

		$format = zymarg_os_font_format_from_url( $url );
		$family = ( 'heading' === $slot ) ? 'ZymargCustomHeading' : 'ZymargCustomBody';

		$css .= sprintf(
			'@font-face{font-family:"%1$s";font-style:normal;font-weight:400 700;font-display:swap;src:url(%2$s) format("%3$s");}',
			$family,
			esc_url( $url ),
			esc_attr( $format )
		);
	}

	return $css;
}

/**
 * Guess the CSS font format from a file URL.
 *
 * @param string $url Font file URL.
 * @return string
 */
function zymarg_os_font_format_from_url( $url ) {
	$ext = strtolower( pathinfo( wp_parse_url( $url, PHP_URL_PATH ), PATHINFO_EXTENSION ) );

	$map = array(
		'woff2' => 'woff2',
		'woff'  => 'woff',
		'ttf'   => 'truetype',
		'otf'   => 'opentype',
		'svg'   => 'svg',
		'eot'   => 'embedded-opentype',
	);

	return isset( $map[ $ext ] ) ? $map[ $ext ] : 'woff2';
}

/**
 * Resolve the effective font-family stacks for body and headings, taking the
 * custom-upload slots into account.
 *
 * @return array{body:string,heading:string}
 */
function zymarg_os_font_stacks() {
	$families = zymarg_os_font_families();

	// Build stacks from the chosen family names, with safe system fallbacks.
	$body    = '"' . $families['body'] . '", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif';
	$heading = '"' . $families['heading'] . '", "' . $families['body'] . '", -apple-system, BlinkMacSystemFont, sans-serif';

	if ( 'system' === zymarg_os_font_source() ) {
		$system  = '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif';
		$body    = $system;
		$heading = $system;
	}

	if ( 'custom' === zymarg_os_font_source() ) {
		if ( zymarg_os_get_option( 'zymarg_custom_font_body', '' ) ) {
			$body = '"ZymargCustomBody", ' . $body;
		}
		if ( zymarg_os_get_option( 'zymarg_custom_font_heading', '' ) ) {
			$heading = '"ZymargCustomHeading", ' . $heading;
		}
	}

	// Power-user override: a full font-family stack string wins over everything.
	$body_override    = trim( (string) zymarg_os_get_option( 'zymarg_font_body_family', '' ) );
	$heading_override = trim( (string) zymarg_os_get_option( 'zymarg_font_heading_family', '' ) );
	if ( '' !== $body_override ) {
		$body = $body_override;
	}
	if ( '' !== $heading_override ) {
		$heading = $heading_override;
	}

	return array(
		'body'    => $body,
		'heading' => $heading,
	);
}
