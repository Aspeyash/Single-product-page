<?php
/**
 * My Account icon.
 *
 * A fully-customizable account icon that links to the WooCommerce My Account
 * page (or any custom URL). Everything is controllable from the Customizer
 * (ZYMARG OS -> Account Icon):
 *   - Icon style: pick a built-in SVG OR upload your own image (PNG/SVG/JPG).
 *   - Background: shape (none / circle / rounded / square) + colour + hover.
 *   - Icon (foreground) colour and overall size.
 *   - Optional text label and link target (auto or custom), open in new tab.
 *
 * It is injected automatically into the theme's Simple header primary menu when
 * enabled, and is ALSO available anywhere via the [zymarg_account_icon]
 * shortcode — so it works inside plugin / page-builder headers too.
 *
 * Styling lives in components/account-icon.css (reads scoped --zai-* custom
 * properties); the Customizer values flow in via dynamic-css.php.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Default options for the account icon.
 *
 * @return array<string,mixed>
 */
function zymarg_os_account_icon_defaults() {
	return array(
		'enable'     => false,
		'source'     => 'builtin',  // builtin | upload
		'icon'       => 'user',     // key from zymarg_os_account_icon_styles()
		'image'      => '',         // uploaded image URL (when source = upload)
		'shape'      => 'circle',   // none | circle | rounded | square
		'bg'         => '#9500a5',  // background colour
		'bg_hover'   => '#bd00d1',  // background hover colour
		'icon_color' => '#ffffff',  // icon / foreground colour
		'size'       => 40,         // overall control size in px
		'label'      => '',         // optional text label (blank = icon only)
		'show_label' => false,      // render the label next to the icon
		'link'       => '',         // custom URL (blank = auto: Woo account / login)
		'new_tab'    => false,      // open link in a new tab
	);
}

/**
 * Get a single account-icon option (theme_mod) with its default.
 *
 * @param string $key Option key (without the zymarg_account_icon_ prefix).
 * @return mixed
 */
function zymarg_os_account_icon_option( $key ) {
	$defaults = zymarg_os_account_icon_defaults();
	$default  = isset( $defaults[ $key ] ) ? $defaults[ $key ] : '';
	return get_theme_mod( 'zymarg_account_icon_' . $key, $default );
}

/**
 * Whether the account icon should auto-render in the theme header.
 *
 * @return bool
 */
function zymarg_os_account_icon_enabled() {
	return (bool) apply_filters( 'zymarg_os_account_icon_enabled', (bool) zymarg_os_account_icon_option( 'enable' ) );
}

/**
 * The built-in icon set: key => array( label, svg-inner-markup ).
 *
 * Each SVG uses a 24x24 viewBox and `currentColor` so the icon-colour control
 * applies. Markup is static and safe to print.
 *
 * @return array<string,array{label:string,svg:string}>
 */
function zymarg_os_account_icon_styles() {
	return array(
		'user'        => array(
			'label' => __( 'User', 'zymarg-os' ),
			'svg'   => '<path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4" fill="none" stroke="currentColor" stroke-width="2"/>',
		),
		'user-solid'  => array(
			'label' => __( 'User (solid)', 'zymarg-os' ),
			'svg'   => '<path d="M12 12a5 5 0 1 0 0-10 5 5 0 0 0 0 10zm0 2c-5.33 0-8 2.67-8 6v1h16v-1c0-3.33-2.67-6-8-6z"/>',
		),
		'user-circle' => array(
			'label' => __( 'User in circle', 'zymarg-os' ),
			'svg'   => '<path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm0 4a3 3 0 1 1 0 6 3 3 0 0 1 0-6zm0 14a8 8 0 0 1-5.3-2c.1-1.6 3.3-2.5 5.3-2.5s5.2.9 5.3 2.5A8 8 0 0 1 12 20z"/>',
		),
		'user-square' => array(
			'label' => __( 'User in square', 'zymarg-os' ),
			'svg'   => '<path fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" d="M4 4h16v16H4z"/><circle cx="12" cy="10" r="2.6" fill="none" stroke="currentColor" stroke-width="2"/><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" d="M7.5 18a4.5 4.5 0 0 1 9 0"/>',
		),
		'account'     => array(
			'label' => __( 'Account badge', 'zymarg-os' ),
			'svg'   => '<path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm0 5a2.7 2.7 0 1 1 0 5.4A2.7 2.7 0 0 1 12 7zm0 12.2a6.5 6.5 0 0 1-4.5-1.8c.6-1.4 2.9-2.1 4.5-2.1s3.9.7 4.5 2.1A6.5 6.5 0 0 1 12 19.2z"/>',
		),
		'store'       => array(
			'label' => __( 'Storefront', 'zymarg-os' ),
			'svg'   => '<path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M3 9l1.5-5h15L21 9M4 9h16v3a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V9zM5 14v6h14v-6"/>',
		),
		'heart'       => array(
			'label' => __( 'Heart', 'zymarg-os' ),
			'svg'   => '<path d="M12 21s-7.5-4.9-10-9.5C.9 9.1 2 6 5 6c2 0 3.2 1.2 4 2.3C9.8 7.2 11 6 13 6c3 0 4.1 3.1 3 5.5C18.5 16.1 12 21 12 21z"/>',
		),
	);
}

/**
 * Resolve the icon's link target.
 *
 * Priority: an explicit custom URL, then the WooCommerce My Account page, then
 * the WordPress login URL as a final fallback.
 *
 * @return string
 */
function zymarg_os_account_icon_url() {
	$custom = trim( (string) zymarg_os_account_icon_option( 'link' ) );
	if ( '' !== $custom ) {
		return esc_url( $custom );
	}

	if ( function_exists( 'wc_get_page_permalink' ) ) {
		$url = wc_get_page_permalink( 'myaccount' );
		if ( $url ) {
			return esc_url( $url );
		}
	}

	return esc_url( wp_login_url() );
}

/**
 * Build the account-icon HTML.
 *
 * @return string
 */
function zymarg_os_account_icon_markup() {
	$source = ( 'upload' === zymarg_os_account_icon_option( 'source' ) ) ? 'upload' : 'builtin';
	$shape  = (string) zymarg_os_account_icon_option( 'shape' );
	$shape  = in_array( $shape, array( 'none', 'circle', 'rounded', 'square' ), true ) ? $shape : 'circle';

	$label_text = trim( (string) zymarg_os_account_icon_option( 'label' ) );
	if ( '' === $label_text ) {
		$label_text = __( 'My Account', 'zymarg-os' );
	}
	$show_label = (bool) zymarg_os_account_icon_option( 'show_label' );
	$new_tab    = (bool) zymarg_os_account_icon_option( 'new_tab' );

	// Resolve the media (uploaded image or a built-in SVG).
	$media = '';
	if ( 'upload' === $source ) {
		$image = trim( (string) zymarg_os_account_icon_option( 'image' ) );
		if ( '' !== $image ) {
			$media = '<img class="zymarg-account-icon__img" src="' . esc_url( $image ) . '" alt="" aria-hidden="true" />';
		}
	}

	if ( '' === $media ) {
		// Built-in SVG (also the fallback if "upload" is chosen but no image set).
		$styles   = zymarg_os_account_icon_styles();
		$icon_key = (string) zymarg_os_account_icon_option( 'icon' );
		if ( ! isset( $styles[ $icon_key ] ) ) {
			$icon_key = 'user';
		}
		$media = '<svg class="zymarg-account-icon__svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">'
			. $styles[ $icon_key ]['svg']
			. '</svg>';
	}

	$classes = array( 'zymarg-account-icon', 'zymarg-account-icon--' . $shape, 'is-' . $source );
	if ( $show_label ) {
		$classes[] = 'has-label';
	}

	$attrs = array(
		'class'      => implode( ' ', array_map( 'sanitize_html_class', $classes ) ),
		'href'       => zymarg_os_account_icon_url(),
		'aria-label' => esc_attr( $label_text ),
	);
	if ( $new_tab ) {
		$attrs['target'] = '_blank';
		$attrs['rel']    = 'noopener noreferrer';
	}

	$attr_str = '';
	foreach ( $attrs as $key => $value ) {
		$attr_str .= ' ' . $key . '="' . $value . '"';
	}

	$html  = '<a' . $attr_str . '>';
	$html .= '<span class="zymarg-account-icon__media">' . $media . '</span>'; // phpcs:ignore — static/escaped markup.
	if ( $show_label ) {
		$html .= '<span class="zymarg-account-icon__label">' . esc_html( $label_text ) . '</span>';
	} else {
		$html .= '<span class="screen-reader-text">' . esc_html( $label_text ) . '</span>';
	}
	$html .= '</a>';

	/**
	 * Filter the rendered account-icon markup.
	 *
	 * @param string $html The HTML string.
	 */
	return apply_filters( 'zymarg_os_account_icon_markup', $html );
}

/**
 * Shortcode: [zymarg_account_icon]
 *
 * Lets the icon be placed inside plugin / page-builder headers, blocks, widgets
 * or menus regardless of the "enable" toggle (which only governs the theme's
 * own Simple header auto-injection).
 *
 * @return string
 */
function zymarg_os_account_icon_shortcode() {
	return zymarg_os_account_icon_markup();
}
add_shortcode( 'zymarg_account_icon', 'zymarg_os_account_icon_shortcode' );

/**
 * Auto-inject the icon into the theme's Simple header primary menu.
 *
 * @param string   $items The HTML list of menu items.
 * @param stdClass $args  wp_nav_menu arguments.
 * @return string
 */
function zymarg_os_account_icon_nav_item( $items, $args ) {
	if ( ! zymarg_os_account_icon_enabled() ) {
		return $items;
	}
	if ( empty( $args->theme_location ) || 'primary' !== $args->theme_location ) {
		return $items;
	}

	$items .= '<li class="menu-item menu-item-zymarg-account">' . zymarg_os_account_icon_markup() . '</li>';

	return $items;
}
add_filter( 'wp_nav_menu_items', 'zymarg_os_account_icon_nav_item', 20, 2 );

/* ---------------------------------------------------------------------- *
 * Sanitizers
 * ---------------------------------------------------------------------- */
function zymarg_os_sanitize_account_icon_source( $v ) {
	return in_array( $v, array( 'builtin', 'upload' ), true ) ? $v : 'builtin';
}
function zymarg_os_sanitize_account_icon_shape( $v ) {
	return in_array( $v, array( 'none', 'circle', 'rounded', 'square' ), true ) ? $v : 'circle';
}
function zymarg_os_sanitize_account_icon_style( $v ) {
	$styles = zymarg_os_account_icon_styles();
	return isset( $styles[ $v ] ) ? $v : 'user';
}

/* ---------------------------------------------------------------------- *
 * Customizer
 * ---------------------------------------------------------------------- */
/**
 * Register the Account Icon Customizer section and controls.
 *
 * @param WP_Customize_Manager $wp_customize Customizer manager.
 * @return void
 */
function zymarg_os_account_icon_customizer( $wp_customize ) {
	$d = zymarg_os_account_icon_defaults();

	$wp_customize->add_section(
		'zymarg_os_account_icon_section',
		array(
			'title'       => __( 'Account Icon', 'zymarg-os' ),
			'description' => __( 'A customizable My Account icon. Enable it to add the icon to the theme header menu, or place it anywhere with the [zymarg_account_icon] shortcode.', 'zymarg-os' ),
			'panel'       => 'zymarg_os_panel',
			'priority'    => 8,
		)
	);

	$s = 'zymarg_os_account_icon_section';

	// Enable.
	$wp_customize->add_setting( 'zymarg_account_icon_enable', array( 'default' => $d['enable'], 'sanitize_callback' => 'zymarg_os_sanitize_checkbox' ) );
	$wp_customize->add_control( 'zymarg_account_icon_enable', array(
		'type'    => 'checkbox',
		'label'   => __( 'Add account icon to the header menu', 'zymarg-os' ),
		'section' => $s,
	) );

	$active = function () { return (bool) get_theme_mod( 'zymarg_account_icon_enable', false ); };

	// Icon source: built-in vs upload.
	$wp_customize->add_setting( 'zymarg_account_icon_source', array( 'default' => $d['source'], 'sanitize_callback' => 'zymarg_os_sanitize_account_icon_source' ) );
	$wp_customize->add_control( 'zymarg_account_icon_source', array(
		'type'    => 'select',
		'label'   => __( 'Icon source', 'zymarg-os' ),
		'section' => $s,
		'choices' => array(
			'builtin' => __( 'Built-in icon', 'zymarg-os' ),
			'upload'  => __( 'Upload my own', 'zymarg-os' ),
		),
		'active_callback' => $active,
	) );

	// Built-in icon style.
	$style_choices = array();
	foreach ( zymarg_os_account_icon_styles() as $key => $meta ) {
		$style_choices[ $key ] = $meta['label'];
	}
	$wp_customize->add_setting( 'zymarg_account_icon_icon', array( 'default' => $d['icon'], 'sanitize_callback' => 'zymarg_os_sanitize_account_icon_style' ) );
	$wp_customize->add_control( 'zymarg_account_icon_icon', array(
		'type'    => 'select',
		'label'   => __( 'Icon style', 'zymarg-os' ),
		'section' => $s,
		'choices' => $style_choices,
		'active_callback' => function () { return (bool) get_theme_mod( 'zymarg_account_icon_enable', false ) && 'upload' !== get_theme_mod( 'zymarg_account_icon_source', 'builtin' ); },
	) );

	// Custom uploaded image.
	$wp_customize->add_setting( 'zymarg_account_icon_image', array( 'default' => $d['image'], 'sanitize_callback' => 'esc_url_raw' ) );
	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'zymarg_account_icon_image', array(
		'label'       => __( 'Upload icon image', 'zymarg-os' ),
		'description' => __( 'PNG, SVG or JPG. Best as a square image. Shown in place of the built-in icon.', 'zymarg-os' ),
		'section'     => $s,
		'active_callback' => function () { return (bool) get_theme_mod( 'zymarg_account_icon_enable', false ) && 'upload' === get_theme_mod( 'zymarg_account_icon_source', 'builtin' ); },
	) ) );

	// Background shape.
	$wp_customize->add_setting( 'zymarg_account_icon_shape', array( 'default' => $d['shape'], 'sanitize_callback' => 'zymarg_os_sanitize_account_icon_shape' ) );
	$wp_customize->add_control( 'zymarg_account_icon_shape', array(
		'type'    => 'select',
		'label'   => __( 'Background shape', 'zymarg-os' ),
		'section' => $s,
		'choices' => array(
			'none'    => __( 'None (icon only)', 'zymarg-os' ),
			'circle'  => __( 'Circle', 'zymarg-os' ),
			'rounded' => __( 'Rounded square', 'zymarg-os' ),
			'square'  => __( 'Square', 'zymarg-os' ),
		),
		'active_callback' => $active,
	) );

	// Background colour.
	$wp_customize->add_setting( 'zymarg_account_icon_bg', array( 'default' => $d['bg'], 'sanitize_callback' => 'sanitize_hex_color' ) );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'zymarg_account_icon_bg', array(
		'label'   => __( 'Background colour', 'zymarg-os' ),
		'section' => $s,
		'active_callback' => function () { return (bool) get_theme_mod( 'zymarg_account_icon_enable', false ) && 'none' !== get_theme_mod( 'zymarg_account_icon_shape', 'circle' ); },
	) ) );

	// Background hover colour.
	$wp_customize->add_setting( 'zymarg_account_icon_bg_hover', array( 'default' => $d['bg_hover'], 'sanitize_callback' => 'sanitize_hex_color' ) );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'zymarg_account_icon_bg_hover', array(
		'label'   => __( 'Background hover colour', 'zymarg-os' ),
		'section' => $s,
		'active_callback' => function () { return (bool) get_theme_mod( 'zymarg_account_icon_enable', false ) && 'none' !== get_theme_mod( 'zymarg_account_icon_shape', 'circle' ); },
	) ) );

	// Icon (foreground) colour.
	$wp_customize->add_setting( 'zymarg_account_icon_icon_color', array( 'default' => $d['icon_color'], 'sanitize_callback' => 'sanitize_hex_color' ) );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'zymarg_account_icon_icon_color', array(
		'label'   => __( 'Icon colour', 'zymarg-os' ),
		'section' => $s,
		'active_callback' => $active,
	) ) );

	// Size.
	$wp_customize->add_setting( 'zymarg_account_icon_size', array( 'default' => $d['size'], 'sanitize_callback' => 'absint' ) );
	$wp_customize->add_control( 'zymarg_account_icon_size', array(
		'type'        => 'number',
		'label'       => __( 'Icon size (px)', 'zymarg-os' ),
		'section'     => $s,
		'input_attrs' => array( 'min' => 24, 'max' => 72, 'step' => 1 ),
		'active_callback' => $active,
	) );

	// Optional label.
	$wp_customize->add_setting( 'zymarg_account_icon_show_label', array( 'default' => $d['show_label'], 'sanitize_callback' => 'zymarg_os_sanitize_checkbox' ) );
	$wp_customize->add_control( 'zymarg_account_icon_show_label', array(
		'type'    => 'checkbox',
		'label'   => __( 'Show a text label beside the icon', 'zymarg-os' ),
		'section' => $s,
		'active_callback' => $active,
	) );

	$wp_customize->add_setting( 'zymarg_account_icon_label', array( 'default' => $d['label'], 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'zymarg_account_icon_label', array(
		'type'        => 'text',
		'label'       => __( 'Label text', 'zymarg-os' ),
		'description' => __( 'Defaults to "My Account". Also used as the accessible label.', 'zymarg-os' ),
		'section'     => $s,
		'active_callback' => $active,
	) );

	// Custom link + new tab.
	$wp_customize->add_setting( 'zymarg_account_icon_link', array( 'default' => $d['link'], 'sanitize_callback' => 'esc_url_raw' ) );
	$wp_customize->add_control( 'zymarg_account_icon_link', array(
		'type'        => 'url',
		'label'       => __( 'Custom link (optional)', 'zymarg-os' ),
		'description' => __( 'Leave blank to auto-link to the WooCommerce My Account page (or login).', 'zymarg-os' ),
		'section'     => $s,
		'active_callback' => $active,
	) );

	$wp_customize->add_setting( 'zymarg_account_icon_new_tab', array( 'default' => $d['new_tab'], 'sanitize_callback' => 'zymarg_os_sanitize_checkbox' ) );
	$wp_customize->add_control( 'zymarg_account_icon_new_tab', array(
		'type'    => 'checkbox',
		'label'   => __( 'Open link in a new tab', 'zymarg-os' ),
		'section' => $s,
		'active_callback' => $active,
	) );
}
add_action( 'customize_register', 'zymarg_os_account_icon_customizer' );

/* ---------------------------------------------------------------------- *
 * Dynamic CSS
 * ---------------------------------------------------------------------- */
/**
 * Build the account-icon's dynamic CSS.
 *
 * Emits a `.zymarg-account-icon` scoped block of custom properties so the
 * Customizer values flow into components/account-icon.css.
 *
 * @return string
 */
function zymarg_os_account_icon_dynamic_css() {
	if ( ! function_exists( 'zymarg_os_account_icon_option' ) ) {
		return '';
	}

	$bg       = sanitize_hex_color( (string) zymarg_os_account_icon_option( 'bg' ) );
	$bg_hover = sanitize_hex_color( (string) zymarg_os_account_icon_option( 'bg_hover' ) );
	$icon     = sanitize_hex_color( (string) zymarg_os_account_icon_option( 'icon_color' ) );

	$size = absint( zymarg_os_account_icon_option( 'size' ) );
	if ( $size < 24 || $size > 72 ) {
		$size = 40;
	}
	$icon_size = (int) round( $size * 0.55 );

	$props = array();
	if ( $bg ) {
		$props[] = '--zai-bg:' . $bg;
	}
	if ( $bg_hover ) {
		$props[] = '--zai-bg-hover:' . $bg_hover;
	}
	if ( $icon ) {
		$props[] = '--zai-icon:' . $icon;
	}
	$props[] = '--zai-size:' . $size . 'px';
	$props[] = '--zai-icon-size:' . $icon_size . 'px';

	return '.zymarg-account-icon{' . implode( ';', $props ) . ';}';
}
