<?php
/**
 * Secure SVG uploads.
 *
 * WordPress blocks SVG uploads by default because an SVG is XML and can carry
 * scripts. This module enables SVG uploads SAFELY:
 *
 *   - Only users who can manage the site (manage_options) may upload SVGs
 *     (filterable via `zymarg_os_svg_upload_cap`).
 *   - Every uploaded SVG is sanitized server-side before it is stored:
 *     <script>, event handlers (on*), foreignObject/iframe/embed/object,
 *     javascript: links and DOCTYPE/ENTITY (XXE) are stripped or rejected.
 *   - SVGs render correctly in the Media Library grid and image controls.
 *
 * Toggle it in Customize -> ZYMARG OS -> Modules -> SVG Uploads. For very
 * high-security sites a dedicated plugin (e.g. Safe SVG) is still an option;
 * this covers the common XSS vectors and restricts uploads to admins.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * The capability required to upload SVGs.
 *
 * @return string
 */
function zymarg_os_svg_upload_cap() {
	return (string) apply_filters( 'zymarg_os_svg_upload_cap', 'manage_options' );
}

/**
 * Allow the SVG mime type — only for permitted users.
 *
 * @param array<string,string> $mimes Allowed mime types.
 * @return array<string,string>
 */
function zymarg_os_svg_upload_mimes( $mimes ) {
	if ( current_user_can( zymarg_os_svg_upload_cap() ) ) {
		$mimes['svg']  = 'image/svg+xml';
		$mimes['svgz'] = 'image/svg+xml';
	}
	return $mimes;
}
add_filter( 'upload_mimes', 'zymarg_os_svg_upload_mimes' );

/**
 * Fix WordPress's real-mime check so a .svg is recognised (and only for
 * permitted users).
 *
 * @param array  $data     ext/type/proper_filename.
 * @param string $file     Full path to the file.
 * @param string $filename The name of the file.
 * @param array  $mimes    Allowed mimes.
 * @return array
 */
function zymarg_os_svg_check_filetype( $data, $file, $filename, $mimes ) {
	if ( ! empty( $data['ext'] ) && ! empty( $data['type'] ) ) {
		return $data;
	}

	$ext = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );
	if ( 'svg' === $ext || 'svgz' === $ext ) {
		if ( current_user_can( zymarg_os_svg_upload_cap() ) ) {
			$data['ext']             = $ext;
			$data['type']            = 'image/svg+xml';
			$data['proper_filename'] = $data['proper_filename'] ?? false;
		} else {
			$data['ext']  = false;
			$data['type'] = false;
		}
	}

	return $data;
}
add_filter( 'wp_check_filetype_and_ext', 'zymarg_os_svg_check_filetype', 10, 4 );

/**
 * Sanitize an SVG string. Returns the cleaned SVG, or false if it is not a
 * valid/safe SVG.
 *
 * @param string $svg Raw SVG markup.
 * @return string|false
 */
function zymarg_os_sanitize_svg( $svg ) {
	$svg = (string) $svg;
	if ( '' === trim( $svg ) ) {
		return false;
	}

	// Strip a UTF-8 BOM if present.
	$svg = preg_replace( '/^\xEF\xBB\xBF/', '', $svg );

	// Reject custom entities (billion-laughs / XXE); strip a plain DOCTYPE.
	if ( preg_match( '/<!ENTITY/i', $svg ) ) {
		return false;
	}
	$svg = preg_replace( '/<!DOCTYPE[^>]*>/i', '', $svg );

	$previous = libxml_use_internal_errors( true );
	$dom      = new DOMDocument();
	$dom->preserveWhiteSpace = false;

	// LIBXML_NONET blocks network access; modern libxml (2.9+) does not load
	// external entities by default.
	$loaded = $dom->loadXML( $svg, LIBXML_NONET );

	libxml_clear_errors();
	libxml_use_internal_errors( $previous );

	if ( ! $loaded || ! $dom->documentElement ) {
		return false;
	}
	if ( 'svg' !== strtolower( $dom->documentElement->localName ) ) {
		return false;
	}

	// Elements that must never appear in an uploaded SVG.
	$bad_elements = array( 'script', 'foreignobject', 'iframe', 'embed', 'object', 'handler', 'base', 'link', 'meta', 'audio', 'video' );

	// Snapshot the live node list so we can safely remove nodes while looping.
	$elements = iterator_to_array( $dom->getElementsByTagName( '*' ) );

	foreach ( $elements as $el ) {
		if ( ! $el instanceof DOMElement ) {
			continue;
		}

		$name = strtolower( $el->localName );
		if ( in_array( $name, $bad_elements, true ) ) {
			if ( $el->parentNode ) {
				$el->parentNode->removeChild( $el );
			}
			continue;
		}

		if ( ! $el->hasAttributes() ) {
			continue;
		}

		$to_remove = array();
		foreach ( $el->attributes as $attr ) {
			$attr_name  = strtolower( $attr->nodeName );
			$attr_value = trim( (string) $attr->nodeValue );
			$compact    = strtolower( preg_replace( '/\s+/', '', $attr_value ) );

			// Inline event handlers (onclick, onload, …).
			if ( 0 === strpos( $attr_name, 'on' ) ) {
				$to_remove[] = $attr->nodeName;
				continue;
			}

			// Dangerous link protocols on any *href attribute.
			if ( 'href' === $attr_name || 'xlink:href' === $attr_name || ':href' === substr( $attr_name, -5 ) ) {
				if ( preg_match( '#^(javascript:|vbscript:|data:text/html|data:image/svg)#i', $compact ) ) {
					$to_remove[] = $attr->nodeName;
					continue;
				}
			}

			// Scripty CSS inside a style attribute.
			if ( 'style' === $attr_name && preg_match( '#(javascript:|expression\(|@import|url\(\s*[\'"]?\s*(javascript:|data:text/html))#i', $attr_value ) ) {
				$to_remove[] = $attr->nodeName;
			}
		}

		foreach ( $to_remove as $rn ) {
			$el->removeAttribute( $rn );
		}
	}

	$clean = $dom->saveXML( $dom->documentElement );
	return ( false === $clean ) ? false : $clean;
}

/**
 * Sanitize SVGs as they are uploaded; block non-permitted users.
 *
 * @param array $file Upload data ($_FILES entry).
 * @return array
 */
function zymarg_os_svg_sanitize_on_upload( $file ) {
	if ( empty( $file['type'] ) || 'image/svg+xml' !== $file['type'] ) {
		return $file;
	}

	if ( ! current_user_can( zymarg_os_svg_upload_cap() ) ) {
		$file['error'] = __( 'Sorry, you are not allowed to upload SVG files.', 'zymarg-os' );
		return $file;
	}

	if ( ! empty( $file['tmp_name'] ) && is_readable( $file['tmp_name'] ) ) {
		$dirty = file_get_contents( $file['tmp_name'] ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$clean = zymarg_os_sanitize_svg( $dirty );

		if ( false === $clean ) {
			$file['error'] = __( 'This SVG could not be sanitized safely, so it was not uploaded.', 'zymarg-os' );
			return $file;
		}

		file_put_contents( $file['tmp_name'], $clean ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_put_contents_file_put_contents
	}

	return $file;
}
add_filter( 'wp_handle_upload_prefilter', 'zymarg_os_svg_sanitize_on_upload' );

/**
 * Make SVGs display in the Media Library JS (grid + attachment details).
 *
 * @param array       $response   Attachment data for JS.
 * @param WP_Post     $attachment Attachment post.
 * @param array|false $meta       Attachment meta.
 * @return array
 */
function zymarg_os_svg_media_js( $response, $attachment, $meta ) {
	if ( isset( $response['mime'] ) && 'image/svg+xml' === $response['mime'] ) {
		$url = wp_get_attachment_url( $attachment->ID );
		if ( $url ) {
			$response['icon']  = $url;
			$response['image'] = array( 'src' => $url );
			$response['thumb'] = array( 'src' => $url );
			if ( empty( $response['sizes'] ) ) {
				$response['sizes'] = array(
					'full' => array(
						'url'         => $url,
						'orientation' => 'landscape',
					),
				);
			}
		}
	}
	return $response;
}
add_filter( 'wp_prepare_attachment_for_js', 'zymarg_os_svg_media_js', 10, 3 );

/**
 * Small admin CSS so SVG thumbnails size correctly in the Media Library.
 *
 * @return void
 */
function zymarg_os_svg_admin_css() {
	echo '<style>'
		. '.attachment .thumbnail img[src$=".svg"],'
		. '.media-frame .attachment-preview img[src$=".svg"],'
		. '.media-frame img[src$=".svg"]{width:100%!important;height:auto!important;}'
		. '.media-icon img[src$=".svg"]{width:48px;height:auto;}'
		. '</style>';
}
add_action( 'admin_head', 'zymarg_os_svg_admin_css' );
