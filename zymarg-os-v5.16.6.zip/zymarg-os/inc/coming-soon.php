<?php
/**
 * Site Mode: Live / Coming Soon / Maintenance.
 *
 * A built-in, on-brand "coming soon" + "maintenance" switch. Set the mode in
 * Customize -> ZYMARG OS -> Site Mode. When active, visitors see a branded
 * placeholder (orb background, your headline/message, optional countdown,
 * social links, login link) while logged-in admins keep seeing the real site.
 *
 *   live         — normal site (default)
 *   coming_soon  — placeholder, HTTP 200 (pre-launch)
 *   maintenance  — placeholder, HTTP 503 + Retry-After (SEO-safe downtime)
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Current site mode.
 *
 * @return string live|coming_soon|maintenance
 */
function zymarg_os_site_mode() {
	$mode    = get_theme_mod( 'zymarg_site_mode', 'live' );
	$allowed = array( 'live', 'coming_soon', 'maintenance' );

	if ( ! in_array( $mode, $allowed, true ) ) {
		$mode = 'live';
	}

	return (string) apply_filters( 'zymarg_os_site_mode', $mode );
}

/**
 * Register Customizer controls for Site Mode.
 *
 * @param WP_Customize_Manager $wp_customize Customizer manager.
 * @return void
 */
function zymarg_os_sitemode_customizer( $wp_customize ) {
	$wp_customize->add_section(
		'zymarg_os_sitemode_section',
		array(
			'title'       => __( 'Site Mode', 'zymarg-os' ),
			'description' => __( 'Show a branded Coming Soon / Maintenance page to visitors. Admins always see the real site.', 'zymarg-os' ),
			'panel'       => 'zymarg_os_panel',
			'priority'    => 5,
		)
	);

	$wp_customize->add_setting(
		'zymarg_site_mode',
		array(
			'default'           => 'live',
			'sanitize_callback' => 'zymarg_os_sanitize_site_mode',
		)
	);
	$wp_customize->add_control(
		'zymarg_site_mode',
		array(
			'type'    => 'select',
			'label'   => __( 'Mode', 'zymarg-os' ),
			'section' => 'zymarg_os_sitemode_section',
			'choices' => array(
				'live'        => __( 'Live (normal site)', 'zymarg-os' ),
				'coming_soon' => __( 'Coming Soon', 'zymarg-os' ),
				'maintenance' => __( 'Maintenance (HTTP 503)', 'zymarg-os' ),
			),
		)
	);

	// Force live: override other coming-soon systems (e.g. WooCommerce).
	$wp_customize->add_setting(
		'zymarg_force_live',
		array(
			'default'           => false,
			'sanitize_callback' => 'zymarg_os_sanitize_checkbox',
		)
	);
	$wp_customize->add_control(
		'zymarg_force_live',
		array(
			'type'        => 'checkbox',
			'label'       => __( 'Force the site live', 'zymarg-os' ),
			'description' => __( 'When Mode = Live, override other coming-soon / maintenance systems (such as WooCommerce) so the site is public. Their own settings are left untouched — the override is applied only on the front end.', 'zymarg-os' ),
			'section'     => 'zymarg_os_sitemode_section',
		)
	);

	$wp_customize->add_setting(
		'zymarg_cs_headline',
		array(
			'default'           => __( 'Something amazing is coming', 'zymarg-os' ),
			'sanitize_callback' => 'sanitize_text_field',
		)
	);
	$wp_customize->add_control(
		'zymarg_cs_headline',
		array(
			'type'    => 'text',
			'label'   => __( 'Headline', 'zymarg-os' ),
			'section' => 'zymarg_os_sitemode_section',
		)
	);

	$wp_customize->add_setting(
		'zymarg_cs_message',
		array(
			'default'           => __( 'Our marketplace is almost ready. Check back soon!', 'zymarg-os' ),
			'sanitize_callback' => 'sanitize_textarea_field',
		)
	);
	$wp_customize->add_control(
		'zymarg_cs_message',
		array(
			'type'    => 'textarea',
			'label'   => __( 'Message', 'zymarg-os' ),
			'section' => 'zymarg_os_sitemode_section',
		)
	);

	// Layout: branded default, or fully custom HTML.
	$wp_customize->add_setting(
		'zymarg_cs_layout',
		array(
			'default'           => 'default',
			'sanitize_callback' => 'zymarg_os_sanitize_cs_layout',
		)
	);
	$wp_customize->add_control(
		'zymarg_cs_layout',
		array(
			'type'        => 'select',
			'label'       => __( 'Layout', 'zymarg-os' ),
			'description' => __( 'Use the branded ZYMARG design, or supply your own custom HTML below.', 'zymarg-os' ),
			'section'     => 'zymarg_os_sitemode_section',
			'choices'     => array(
				'default' => __( 'Branded (ZYMARG design)', 'zymarg-os' ),
				'custom'  => __( 'Custom HTML (your own design)', 'zymarg-os' ),
			),
		)
	);

	$wp_customize->add_setting(
		'zymarg_cs_custom_html',
		array(
			'default'           => '',
			'sanitize_callback' => 'zymarg_os_sanitize_custom_html',
		)
	);
	$wp_customize->add_control(
		'zymarg_cs_custom_html',
		array(
			'type'        => 'textarea',
			'label'       => __( 'Custom HTML', 'zymarg-os' ),
			'description' => __( 'Used only when Layout = Custom HTML. Paste full HTML — include your own <style> or <link> tags for any CSS you need, since the theme stylesheet is not loaded here. Shortcodes like [zymarg_spark] work. This replaces the placeholder body entirely.', 'zymarg-os' ),
			'section'     => 'zymarg_os_sitemode_section',
			'input_attrs' => array( 'rows' => 10, 'style' => 'font-family:monospace;' ),
		)
	);

	$wp_customize->add_setting(
		'zymarg_cs_launch',
		array(
			'default'           => '',
			'sanitize_callback' => 'sanitize_text_field',
		)
	);
	$wp_customize->add_control(
		'zymarg_cs_launch',
		array(
			'type'        => 'text',
			'label'       => __( 'Launch date (optional countdown)', 'zymarg-os' ),
			'description' => __( 'e.g. 2026-08-01 18:00 — leave blank for no countdown.', 'zymarg-os' ),
			'section'     => 'zymarg_os_sitemode_section',
		)
	);

	$wp_customize->add_setting(
		'zymarg_cs_show_login',
		array(
			'default'           => true,
			'sanitize_callback' => 'zymarg_os_sanitize_checkbox',
		)
	);
	$wp_customize->add_control(
		'zymarg_cs_show_login',
		array(
			'type'    => 'checkbox',
			'label'   => __( 'Show a "Log in" link', 'zymarg-os' ),
			'section' => 'zymarg_os_sitemode_section',
		)
	);

	$socials = array(
		'facebook'  => __( 'Facebook URL', 'zymarg-os' ),
		'instagram' => __( 'Instagram URL', 'zymarg-os' ),
		'linkedin'  => __( 'LinkedIn URL', 'zymarg-os' ),
		'twitter'   => __( 'X / Twitter URL', 'zymarg-os' ),
		'youtube'   => __( 'YouTube URL', 'zymarg-os' ),
	);
	foreach ( $socials as $key => $label ) {
		$wp_customize->add_setting(
			'zymarg_cs_' . $key,
			array(
				'default'           => '',
				'sanitize_callback' => 'esc_url_raw',
			)
		);
		$wp_customize->add_control(
			'zymarg_cs_' . $key,
			array(
				'type'    => 'url',
				'label'   => $label,
				'section' => 'zymarg_os_sitemode_section',
			)
		);
	}
}
add_action( 'customize_register', 'zymarg_os_sitemode_customizer' );

/**
 * Sanitize the site-mode value.
 *
 * @param string $value Raw value.
 * @return string
 */
function zymarg_os_sanitize_site_mode( $value ) {
	$allowed = array( 'live', 'coming_soon', 'maintenance' );
	return in_array( $value, $allowed, true ) ? $value : 'live';
}

/**
 * Sanitize the layout choice.
 *
 * @param string $value Raw value.
 * @return string
 */
function zymarg_os_sanitize_cs_layout( $value ) {
	return in_array( $value, array( 'default', 'custom' ), true ) ? $value : 'default';
}

/**
 * Sanitize the custom HTML. Admins with the `unfiltered_html` capability may
 * save raw markup (incl. styles/scripts) — mirroring core's Custom HTML widget.
 * Everyone else gets wp_kses_post filtering.
 *
 * @param string $value Raw value.
 * @return string
 */
function zymarg_os_sanitize_custom_html( $value ) {
	if ( current_user_can( 'unfiltered_html' ) ) {
		return $value;
	}
	return wp_kses_post( $value );
}

/**
 * Intercept front-end requests and show the placeholder when not live.
 *
 * @return void
 */
function zymarg_os_maybe_show_placeholder() {
	$mode = zymarg_os_site_mode();

	if ( 'live' === $mode ) {
		return;
	}

	// Always allow wp-login.php and wp-admin/ through so admins can log in
	// and access the dashboard even when the site is not yet live.
	// Note: is_admin() covers /wp-admin/ requests; $pagenow covers wp-login.php
	// itself (which runs outside wp-admin/ and therefore is_admin() = false there).
	if ( is_admin() ) {
		return;
	}
	global $pagenow;
	if ( 'wp-login.php' === $pagenow ) {
		return;
	}

	// Admins (and the Customizer preview) always see the real site.
	if ( current_user_can( 'edit_theme_options' ) || is_customize_preview() ) {
		return;
	}

	// Proper status for SEO during maintenance.
	if ( 'maintenance' === $mode ) {
		status_header( 503 );
		header( 'Retry-After: 3600' );
	} else {
		status_header( 200 );
	}
	nocache_headers();

	zymarg_os_render_placeholder( $mode );
	exit;
}
add_action( 'template_redirect', 'zymarg_os_maybe_show_placeholder' );

/**
 * Block unauthenticated REST API requests when the site is not live.
 *
 * Only fires for non-live modes. Authenticated admins (edit_theme_options)
 * are always passed through so the Customizer, block editor, and plugin
 * dashboards keep working. Internal WordPress routes (oembed, batch) are
 * also whitelisted so core features are not broken.
 *
 * @param WP_Error|null|true $result  Current pre-dispatch result.
 * @param WP_REST_Server     $server  REST server instance (unused).
 * @param WP_REST_Request    $request Full REST request object.
 * @return WP_Error|null|true
 */
function zymarg_os_rest_gate( $result, $server, $request ) {
	// Already handled upstream — don't interfere.
	if ( is_wp_error( $result ) ) {
		return $result;
	}

	$mode = zymarg_os_site_mode();
	if ( 'live' === $mode ) {
		return $result;
	}

	// Admins always pass through.
	if ( current_user_can( 'edit_theme_options' ) ) {
		return $result;
	}

	// Whitelist internal WordPress REST routes that must stay open.
	// Use $request->get_route() — the reliable source at this point in the REST lifecycle.
	$route       = $request->get_route();
	$whitelisted = array( '/oembed/', '/wp/v2/themes', '/wp/v2/plugins' );
	foreach ( $whitelisted as $prefix ) {
		if ( strpos( $route, $prefix ) === 0 ) {
			return $result;
		}
	}

	$message = ( 'maintenance' === $mode )
		? __( 'The site is temporarily under maintenance. Please try again later.', 'zymarg-os' )
		: __( 'This site is not yet available to the public.', 'zymarg-os' );

	return new WP_Error(
		'zymarg_os_not_live',
		$message,
		array( 'status' => ( 'maintenance' === $mode ) ? 503 : 403 )
	);
}
add_filter( 'rest_pre_dispatch', 'zymarg_os_rest_gate', 10, 3 );

/**
 * Block unauthenticated (nopriv) AJAX requests when the site is not live.
 *
 * Runs on wp_loaded so WordPress and all plugins are fully initialised
 * before we inspect the request. Only blocks DOING_AJAX + nopriv —
 * authenticated AJAX (admin-ajax.php with a valid cookie) is never touched,
 * so logged-in vendor/customer sessions and WooCommerce keep working.
 *
 * A small safe-list of actions that must stay open (nonce refresh, heartbeat)
 * is always passed through.
 *
 * @return void
 */
function zymarg_os_ajax_gate() {
	if ( ! defined( 'DOING_AJAX' ) || ! DOING_AJAX ) {
		return;
	}

	$mode = zymarg_os_site_mode();
	if ( 'live' === $mode ) {
		return;
	}

	// Logged-in admins always pass through.
	if ( current_user_can( 'edit_theme_options' ) ) {
		return;
	}

	// Any authenticated user passes through (their cookie verified by WP).
	if ( is_user_logged_in() ) {
		return;
	}

	// Actions that must stay open even for unauthenticated visitors.
	// wp_check_password / heartbeat — WordPress core internals.
	// zymarg_lost_password  — password-reset email from the branded login card.
	// zymarg_register_user  — new account creation from the branded login card.
	// zymarg_get_nonce      — nonce refresh for cached pages (login card needs this).
	$action       = isset( $_REQUEST['action'] ) ? sanitize_key( wp_unslash( $_REQUEST['action'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$safe_actions = array( 'wp_check_password', 'heartbeat', 'zymarg_lost_password', 'zymarg_register_user', 'zymarg_get_nonce' );
	if ( in_array( $action, $safe_actions, true ) ) {
		return;
	}

	$message = ( 'maintenance' === $mode )
		? __( 'The site is temporarily under maintenance.', 'zymarg-os' )
		: __( 'This site is not yet available to the public.', 'zymarg-os' );

	wp_send_json_error( array( 'message' => $message ), ( 'maintenance' === $mode ) ? 503 : 403 );
}
add_action( 'wp_loaded', 'zymarg_os_ajax_gate', 1 );

/* ---------------------------------------------------------------------- *
 * Force Live — override other coming-soon / maintenance systems
 * ---------------------------------------------------------------------- */

/**
 * Whether "Force live" is enabled.
 *
 * @return bool
 */
function zymarg_os_force_live_enabled() {
	return (bool) get_theme_mod( 'zymarg_force_live', false );
}

/**
 * Whether the override should currently apply (Live mode + Force live on).
 *
 * @return bool
 */
function zymarg_os_force_live_active() {
	return ( 'live' === zymarg_os_site_mode() ) && zymarg_os_force_live_enabled();
}

/**
 * The option overrides applied on the front end while forcing live. Maps an
 * option name to the value it should report. Default disables WooCommerce's
 * built-in coming-soon. Extend via the filter for other option-based plugins.
 *
 * @return array<string,string>
 */
function zymarg_os_force_live_overrides_map() {
	return apply_filters(
		'zymarg_os_force_live_overrides',
		array(
			'woocommerce_coming_soon' => 'no',
		)
	);
}

/**
 * Apply the front-end overrides. Uses pre_option_* so nothing is written to the
 * database — toggling Force live off instantly restores the original behaviour.
 * Only runs on the front end so the dashboard still reads the true settings.
 *
 * @return void
 */
function zymarg_os_apply_force_live() {
	if ( is_admin() || ! zymarg_os_force_live_active() ) {
		return;
	}

	foreach ( zymarg_os_force_live_overrides_map() as $option => $value ) {
		add_filter(
			'pre_option_' . $option,
			function () use ( $value ) {
				return $value;
			}
		);
	}

	/**
	 * Fires when Force Live is overriding other systems, so integrations can
	 * neutralise non-option-based coming-soon plugins (e.g. by removing hooks).
	 */
	do_action( 'zymarg_os_force_live' );
}
add_action( 'init', 'zymarg_os_apply_force_live', 0 );

/**
 * Detect other active coming-soon / maintenance systems (read from real
 * settings; only meaningful in admin where overrides are not applied).
 *
 * @return array<string,string> Map of key => human label.
 */
function zymarg_os_detected_coming_soon() {
	$found = array();

	// WooCommerce built-in coming soon (WC 9.1+).
	if ( 'yes' === get_option( 'woocommerce_coming_soon' ) ) {
		$found['woocommerce'] = __( 'WooCommerce Coming Soon', 'zymarg-os' );
	}

	// A few well-known maintenance/coming-soon plugins (flagged if present).
	if ( class_exists( 'WP_Maintenance_Mode' ) ) {
		$found['wpmm'] = __( 'WP Maintenance Mode', 'zymarg-os' );
	}
	if ( defined( 'SEEDPROD_VERSION' ) || defined( 'SEEDPROD_PRO_VERSION' ) ) {
		$found['seedprod'] = __( 'SeedProd', 'zymarg-os' );
	}

	/**
	 * Filter the detected coming-soon systems.
	 *
	 * @param array $found Map of key => label.
	 */
	return apply_filters( 'zymarg_os_detected_coming_soon', $found );
}

/**
 * Dashboard notice: confirm overriding (when forcing) or warn (when not).
 *
 * @return void
 */
function zymarg_os_force_live_notice() {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		return;
	}

	// Only relevant when the theme itself is Live.
	if ( 'live' !== zymarg_os_site_mode() ) {
		return;
	}

	$detected = zymarg_os_detected_coming_soon();
	if ( empty( $detected ) ) {
		return;
	}

	$list        = implode( ', ', array_map( 'esc_html', $detected ) );
	$setting_url = admin_url( 'customize.php?autofocus[section]=zymarg_os_sitemode_section' );

	// One-click button to actually switch WooCommerce's own setting to Live.
	$wc_button = '';
	if ( isset( $detected['woocommerce'] ) ) {
		$wc_button = sprintf(
			' <a class="button button-small" href="%1$s">%2$s</a>',
			esc_url( zymarg_os_wc_live_url() ),
			esc_html__( 'Turn WooCommerce Coming Soon OFF', 'zymarg-os' )
		);
	}

	if ( zymarg_os_force_live_enabled() ) {
		printf(
			'<div class="notice notice-info"><p><strong>%1$s</strong> %2$s <em>%3$s</em> %4$s%5$s</p></div>',
			esc_html__( 'ZYMARG OS — Force Live is ON.', 'zymarg-os' ),
			esc_html__( 'Your site is public; the theme is overriding these on the front end:', 'zymarg-os' ),
			$list, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- pre-escaped above.
			esc_html__( '(their own settings are left unchanged).', 'zymarg-os' ),
			$wc_button // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- pre-escaped above.
		);
	} else {
		printf(
			'<div class="notice notice-warning"><p><strong>%1$s</strong> %2$s <em>%3$s</em> — %4$s <a href="%5$s">%6$s</a>.%7$s</p></div>',
			esc_html__( 'ZYMARG OS — heads up:', 'zymarg-os' ),
			esc_html__( 'another coming-soon / maintenance system is active and may hide your site from visitors even though the theme is Live:', 'zymarg-os' ),
			$list, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- pre-escaped above.
			esc_html__( 'turn it off there, or enable', 'zymarg-os' ),
			esc_url( $setting_url ),
			esc_html__( '"Force the site live"', 'zymarg-os' ),
			$wc_button // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- pre-escaped above.
		);
	}
}
add_action( 'admin_notices', 'zymarg_os_force_live_notice' );

/**
 * Build the nonce-protected URL that switches WooCommerce's coming-soon OFF.
 *
 * @return string
 */
function zymarg_os_wc_live_url() {
	return wp_nonce_url(
		admin_url( 'admin-post.php?action=zymarg_os_wc_live' ),
		'zymarg_os_wc_live'
	);
}

/**
 * Handle the "Turn WooCommerce Coming Soon OFF" button: actually write
 * WooCommerce's own setting to Live (a permanent change to its option).
 *
 * @return void
 */
function zymarg_os_handle_wc_live() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You are not allowed to do this.', 'zymarg-os' ) );
	}

	check_admin_referer( 'zymarg_os_wc_live' );

	// Flip WooCommerce's real settings to Live.
	update_option( 'woocommerce_coming_soon', 'no' );
	update_option( 'woocommerce_store_pages_only', 'no' );

	wp_safe_redirect( add_query_arg( 'zymarg_wc', 'live', wp_get_referer() ? wp_get_referer() : admin_url() ) );
	exit;
}
add_action( 'admin_post_zymarg_os_wc_live', 'zymarg_os_handle_wc_live' );

/**
 * Success feedback after switching WooCommerce to Live.
 *
 * @return void
 */
function zymarg_os_wc_live_feedback() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	if ( isset( $_GET['zymarg_wc'] ) && 'live' === sanitize_key( wp_unslash( $_GET['zymarg_wc'] ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		printf(
			'<div class="notice notice-success is-dismissible"><p>%s</p></div>',
			esc_html__( 'WooCommerce Coming Soon has been turned OFF — your store is now Live.', 'zymarg-os' )
		);
	}
}
add_action( 'admin_notices', 'zymarg_os_wc_live_feedback' );

/**
 * Output the branded placeholder page (self-contained HTML).
 *
 * @param string $mode Current mode.
 * @return void
 */
function zymarg_os_render_placeholder( $mode ) {
	$site     = get_bloginfo( 'name' );
	$headline = get_theme_mod( 'zymarg_cs_headline', __( 'Something amazing is coming', 'zymarg-os' ) );
	$message  = get_theme_mod( 'zymarg_cs_message', __( 'Our marketplace is almost ready. Check back soon!', 'zymarg-os' ) );
	$launch   = trim( (string) get_theme_mod( 'zymarg_cs_launch', '' ) );
	$show_log = (bool) get_theme_mod( 'zymarg_cs_show_login', true );

	$launch_ts = $launch ? strtotime( $launch ) : 0;
	$countdown = ( $launch_ts && $launch_ts > time() );

	$socials = array(
		'facebook'  => array( get_theme_mod( 'zymarg_cs_facebook', '' ), 'M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z' ),
		'instagram' => array( get_theme_mod( 'zymarg_cs_instagram', '' ), 'M7 2h10a5 5 0 0 1 5 5v10a5 5 0 0 1-5 5H7a5 5 0 0 1-5-5V7a5 5 0 0 1 5-5zm5 5a5 5 0 1 0 0 10 5 5 0 0 0 0-10zm0 2a3 3 0 1 1 0 6 3 3 0 0 1 0-6zm5.5-2.5a1 1 0 1 0 0 2 1 1 0 0 0 0-2z' ),
		'linkedin'  => array( get_theme_mod( 'zymarg_cs_linkedin', '' ), 'M6.94 5a2 2 0 1 1-4-.002 2 2 0 0 1 4 .002zM7 8.48H3V21h4zM13.32 8.48H9.34V21h3.94v-6.57c0-3.66 4.77-4 4.77 0V21H22v-7.93c0-6.17-7.06-5.94-8.72-2.91z' ),
		'twitter'   => array( get_theme_mod( 'zymarg_cs_twitter', '' ), 'M18.9 2H22l-7.5 8.6L23 22h-6.9l-5.4-7-6.2 7H1.4l8-9.2L1 2h7.1l4.9 6.4zm-2.4 18h1.7L7.6 3.8H5.8z' ),
		'youtube'   => array( get_theme_mod( 'zymarg_cs_youtube', '' ), 'M23 12s0-3.5-.45-5.2a2.7 2.7 0 0 0-1.9-1.9C18.9 4.5 12 4.5 12 4.5s-6.9 0-8.65.4a2.7 2.7 0 0 0-1.9 1.9C1 8.5 1 12 1 12s0 3.5.45 5.2a2.7 2.7 0 0 0 1.9 1.9c1.75.4 8.65.4 8.65.4s6.9 0 8.65-.4a2.7 2.7 0 0 0 1.9-1.9C23 15.5 23 12 23 12zM10 15.5v-7l6 3.5z' ),
	);

	$title_suffix = ( 'maintenance' === $mode ) ? __( 'Under maintenance', 'zymarg-os' ) : __( 'Coming soon', 'zymarg-os' );

	// Custom HTML layout — output the admin's own design instead of the branded page.
	$layout = get_theme_mod( 'zymarg_cs_layout', 'default' );
	$custom = (string) get_theme_mod( 'zymarg_cs_custom_html', '' );
	if ( 'custom' === $layout && '' !== trim( $custom ) ) {
		zymarg_os_render_custom_placeholder( $mode, $site, $title_suffix, $custom );
		return;
	}
	?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="<?php echo ( 'maintenance' === $mode ) ? 'noindex,follow' : 'noindex,nofollow'; ?>">
	<title><?php echo esc_html( $site . ' — ' . $title_suffix ); ?></title>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Sora:wght@600;700&display=swap">
	<style>
		:root{--p:#9500a5;--pc:#bd00d1;--h:#36003d;--t:#131b2e;--m:#534152;--ov:#d8bfd3;--s0:#fff;--s:#faf8ff;}
		*{box-sizing:border-box;}
		html,body{height:100%;}
		body{margin:0;font-family:"Inter",-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;color:var(--t);background:var(--s0);display:flex;align-items:center;justify-content:center;min-height:100vh;padding:24px;-webkit-font-smoothing:antialiased;}
		.orbs{position:fixed;inset:0;z-index:0;overflow:hidden;background:var(--s0);pointer-events:none;}
		.orbs span{position:absolute;border-radius:50%;}
		.orb1{width:50vw;height:50vw;top:-10%;left:-10%;background:radial-gradient(circle,rgba(104,51,234,.15) 0%,rgba(104,51,234,0) 70%);filter:blur(60px);}
		.orb2{width:60vw;height:60vw;bottom:-20%;right:-20%;background:radial-gradient(circle,rgba(88,42,159,.10) 0%,rgba(88,42,159,0) 70%);filter:blur(80px);}
		.cs{position:relative;z-index:1;text-align:center;max-width:640px;}
		.cs__brand{font-family:"Sora",sans-serif;font-weight:700;font-size:clamp(1.4rem,4vw,2rem);background:linear-gradient(135deg,var(--p),var(--pc));-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;color:var(--p);margin-bottom:24px;letter-spacing:-.01em;}
		.cs h1{font-family:"Sora",sans-serif;font-weight:700;font-size:clamp(2rem,6vw,3.25rem);color:var(--h);margin:0 0 16px;line-height:1.15;}
		.cs p{font-size:1.1rem;color:var(--m);margin:0 auto 28px;max-width:520px;line-height:1.6;}
		.cd{display:flex;gap:14px;justify-content:center;margin:0 0 30px;}
		.cd div{background:var(--s);border:1px solid var(--ov);border-radius:12px;padding:14px 10px;min-width:74px;}
		.cd b{display:block;font-family:"Sora",sans-serif;font-size:1.8rem;color:var(--p);line-height:1;}
		.cd small{display:block;margin-top:6px;font-size:.72rem;text-transform:uppercase;letter-spacing:.08em;color:var(--m);}
		.social{display:flex;gap:12px;justify-content:center;margin-bottom:22px;}
		.social a{display:inline-flex;align-items:center;justify-content:center;width:44px;height:44px;border-radius:50%;background:var(--s);border:1px solid var(--ov);color:var(--p);transition:all .25s ease;}
		.social a:hover{background:var(--p);color:#fff;border-color:var(--p);transform:translateY(-2px);}
		.social svg{width:20px;height:20px;fill:currentColor;}
		.login{display:inline-block;font-size:.9rem;color:var(--m);text-decoration:none;border-bottom:1px dashed var(--ov);}
		.login:hover{color:var(--p);}
	</style>
</head>
<body>
	<div class="orbs" aria-hidden="true"><span class="orb1"></span><span class="orb2"></span></div>
	<main class="cs">
		<?php if ( $site ) : ?><div class="cs__brand"><?php echo esc_html( $site ); ?></div><?php endif; ?>
		<h1><?php echo esc_html( $headline ); ?></h1>
		<?php if ( $message ) : ?><p><?php echo esc_html( $message ); ?></p><?php endif; ?>

		<?php if ( $countdown ) : ?>
		<div class="cd" id="zymarg-cd" data-deadline="<?php echo esc_attr( $launch_ts * 1000 ); ?>">
			<div><b data-d>0</b><small><?php esc_html_e( 'Days', 'zymarg-os' ); ?></small></div>
			<div><b data-h>0</b><small><?php esc_html_e( 'Hours', 'zymarg-os' ); ?></small></div>
			<div><b data-m>0</b><small><?php esc_html_e( 'Mins', 'zymarg-os' ); ?></small></div>
			<div><b data-s>0</b><small><?php esc_html_e( 'Secs', 'zymarg-os' ); ?></small></div>
		</div>
		<?php endif; ?>

		<?php
		$has_social = false;
		foreach ( $socials as $data ) {
			if ( ! empty( $data[0] ) ) {
				$has_social = true;
				break;
			}
		}
		if ( $has_social ) :
			?>
		<div class="social">
			<?php
			foreach ( $socials as $name => $data ) {
				if ( empty( $data[0] ) ) {
					continue;
				}
				printf(
					'<a href="%1$s" target="_blank" rel="noopener noreferrer" aria-label="%2$s"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="%3$s"/></svg></a>',
					esc_url( $data[0] ),
					esc_attr( ucfirst( $name ) ),
					esc_attr( $data[1] )
				);
			}
			?>
		</div>
		<?php endif; ?>

		<?php if ( $show_log ) : ?>
			<a class="login" href="<?php echo esc_url( wp_login_url() ); ?>"><?php esc_html_e( 'Log in', 'zymarg-os' ); ?></a>
		<?php endif; ?>
	</main>

	<?php if ( $countdown ) : ?>
	<script>
	(function(){var el=document.getElementById('zymarg-cd');if(!el)return;var dl=parseInt(el.getAttribute('data-deadline'),10);
	function p(n){return n<10?'0'+n:n;}
	function tick(){var t=dl-Date.now();if(t<0){t=0;}var d=Math.floor(t/86400000),h=Math.floor(t/3600000)%24,m=Math.floor(t/60000)%60,s=Math.floor(t/1000)%60;
	el.querySelector('[data-d]').textContent=d;el.querySelector('[data-h]').textContent=p(h);el.querySelector('[data-m]').textContent=p(m);el.querySelector('[data-s]').textContent=p(s);}
	tick();setInterval(tick,1000);})();
	</script>
	<?php endif; ?>
</body>
</html>
	<?php
}

/**
 * Output the admin's custom-HTML placeholder (a minimal HTML skeleton wrapping
 * their markup). Shortcodes are processed, so things like [zymarg_spark] work.
 *
 * @param string $mode         Current mode.
 * @param string $site         Site name.
 * @param string $title_suffix Title suffix.
 * @param string $custom       Custom HTML.
 * @return void
 */
function zymarg_os_render_custom_placeholder( $mode, $site, $title_suffix, $custom ) {
	?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="<?php echo ( 'maintenance' === $mode ) ? 'noindex,follow' : 'noindex,nofollow'; ?>">
	<title><?php echo esc_html( $site . ' — ' . $title_suffix ); ?></title>
</head>
<body>
<?php
	// Admin-provided markup; already capability-sanitised on save.
	echo do_shortcode( $custom ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
?>
</body>
</html>
	<?php
}

/**
 * Show a clear indicator in the admin bar when the site is not live.
 *
 * @param WP_Admin_Bar $bar Admin bar instance.
 * @return void
 */
function zymarg_os_sitemode_admin_bar( $bar ) {
	$mode = zymarg_os_site_mode();
	if ( 'live' === $mode || ! current_user_can( 'edit_theme_options' ) ) {
		return;
	}

	$label = ( 'maintenance' === $mode )
		? __( '🛠 Maintenance mode ON', 'zymarg-os' )
		: __( '🚧 Coming Soon mode ON', 'zymarg-os' );

	$bar->add_node(
		array(
			'id'    => 'zymarg-site-mode',
			'title' => $label,
			'href'  => admin_url( 'customize.php?autofocus[section]=zymarg_os_sitemode_section' ),
			'meta'  => array( 'title' => __( 'Visitors see a placeholder. Click to change in the Customizer.', 'zymarg-os' ) ),
		)
	);
}
add_action( 'admin_bar_menu', 'zymarg_os_sitemode_admin_bar', 100 );
