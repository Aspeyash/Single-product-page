<?php
/**
 * SEO structured data (Schema.org JSON-LD).
 *
 * Outputs site-wide Organization + WebSite (with a Sitelinks search box) markup
 * so Google can show rich results. It intentionally DEFERS to dedicated SEO
 * plugins (Yoast, Rank Math, SEOPress, AIOSEO) to avoid duplicate schema, and
 * does NOT output Product schema because WooCommerce already provides it.
 * Breadcrumb schema lives in inc/breadcrumbs.php.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Whether a major SEO plugin is active (it will handle structured data).
 *
 * @return bool
 */
function zymarg_os_seo_plugin_active() {
	$active = defined( 'WPSEO_VERSION' )            // Yoast.
		|| defined( 'RANK_MATH_VERSION' )           // Rank Math.
		|| defined( 'SEOPRESS_VERSION' )            // SEOPress.
		|| function_exists( 'aioseo' );             // All in One SEO.

	/**
	 * Filter SEO-plugin detection (return true to make ZYMARG defer/skip).
	 *
	 * @param bool $active Whether to defer to an SEO plugin.
	 */
	return (bool) apply_filters( 'zymarg_os_seo_plugin_active', $active );
}

/**
 * Output Organization + WebSite JSON-LD in the head.
 *
 * @return void
 */
function zymarg_os_site_schema() {
	if ( ! zymarg_os_module_enabled( 'schema' ) || zymarg_os_seo_plugin_active() ) {
		return;
	}

	$site_url = home_url( '/' );
	$name     = get_bloginfo( 'name' );

	$graph = array();

	// Organization.
	$org = array(
		'@type' => 'Organization',
		'@id'   => $site_url . '#organization',
		'name'  => $name,
		'url'   => $site_url,
	);
	$logo_id = get_theme_mod( 'custom_logo' );
	if ( $logo_id ) {
		$src = wp_get_attachment_image_src( $logo_id, 'full' );
		if ( $src ) {
			$org['logo'] = array(
				'@type' => 'ImageObject',
				'url'   => $src[0],
			);
		}
	}
	// Social profiles from the Site Mode settings, if present.
	$socials = array_filter(
		array(
			get_theme_mod( 'zymarg_cs_facebook', '' ),
			get_theme_mod( 'zymarg_cs_instagram', '' ),
			get_theme_mod( 'zymarg_cs_linkedin', '' ),
			get_theme_mod( 'zymarg_cs_twitter', '' ),
			get_theme_mod( 'zymarg_cs_youtube', '' ),
		)
	);
	if ( ! empty( $socials ) ) {
		$org['sameAs'] = array_values( $socials );
	}
	$graph[] = $org;

	// WebSite + SearchAction (sitelinks search box).
	$graph[] = array(
		'@type'           => 'WebSite',
		'@id'             => $site_url . '#website',
		'url'             => $site_url,
		'name'            => $name,
		'publisher'       => array( '@id' => $site_url . '#organization' ),
		'potentialAction' => array(
			'@type'       => 'SearchAction',
			'target'      => array(
				'@type'       => 'EntryPoint',
				'urlTemplate' => $site_url . '?s={search_term_string}',
			),
			'query-input' => 'required name=search_term_string',
		),
	);

	$data = array(
		'@context' => 'https://schema.org',
		'@graph'   => apply_filters( 'zymarg_os_schema_graph', $graph ),
	);

	echo "\n" . '<script type="application/ld+json">' . wp_json_encode( $data ) . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}
add_action( 'wp_head', 'zymarg_os_site_schema', 5 );
