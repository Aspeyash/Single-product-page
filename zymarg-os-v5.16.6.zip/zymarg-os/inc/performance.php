<?php
/**
 * Performance module.
 *
 * A set of safe, opt-out tweaks to make the front end lighter and faster:
 *   - Disable the emoji detection script + styles
 *   - Remove jQuery Migrate on the front end
 *   - Dequeue the block library + global styles CSS when no blocks are used
 *   - Defer the theme script
 *   - Add lazy/async decoding hints to content images
 *
 * Each tweak can be disabled with its own filter so nothing is forced on you.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Disable WordPress emoji scripts/styles.
 *
 * @return void
 */
function zymarg_os_disable_emojis() {
	if ( ! apply_filters( 'zymarg_os_disable_emojis', true ) ) {
		return;
	}

	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'admin_print_styles', 'print_emoji_styles' );
	remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
	remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
	remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );

	add_filter(
		'tiny_mce_plugins',
		function ( $plugins ) {
			return is_array( $plugins ) ? array_diff( $plugins, array( 'wpemoji' ) ) : array();
		}
	);
}
add_action( 'init', 'zymarg_os_disable_emojis' );

/**
 * Remove jQuery Migrate from the front end (kept in admin for compatibility).
 *
 * @param WP_Scripts $scripts Scripts manager.
 * @return void
 */
function zymarg_os_remove_jquery_migrate( $scripts ) {
	if ( is_admin() || ! apply_filters( 'zymarg_os_remove_jquery_migrate', true ) ) {
		return;
	}

	if ( ! empty( $scripts->registered['jquery'] ) ) {
		$deps = $scripts->registered['jquery']->deps;
		$scripts->registered['jquery']->deps = array_diff( $deps, array( 'jquery-migrate' ) );
	}
}
add_action( 'wp_default_scripts', 'zymarg_os_remove_jquery_migrate' );

/**
 * Conditionally dequeue the block library + global styles CSS on pages that
 * contain no blocks (e.g. Elementor-built marketplace pages). Saves a couple
 * of render-blocking requests.
 *
 * @return void
 */
function zymarg_os_maybe_dequeue_block_css() {
	if ( is_admin() || ! apply_filters( 'zymarg_os_trim_block_css', true ) ) {
		return;
	}

	$post = get_post();
	$has_blocks = $post && function_exists( 'has_blocks' ) && has_blocks( $post );

	if ( ! $has_blocks ) {
		wp_dequeue_style( 'wp-block-library' );
		wp_dequeue_style( 'wp-block-library-theme' );

		// Keep wc-blocks-style on cart & checkout — WooCommerce uses it for
		// field layout, payment box styling, and Select2 even without blocks.
		$is_wc_transactional = function_exists( 'is_checkout' ) && ( is_checkout() || is_cart() );
		if ( ! $is_wc_transactional ) {
			wp_dequeue_style( 'wc-blocks-style' );
		}

		wp_dequeue_style( 'classic-theme-styles' );
		// Global styles are only needed when block styling is in play.
		wp_dequeue_style( 'global-styles' );
	}
}
add_action( 'wp_enqueue_scripts', 'zymarg_os_maybe_dequeue_block_css', 100 );

/**
 * Defer the theme front-end script for faster first paint.
 *
 * @param string $tag    The <script> tag.
 * @param string $handle Script handle.
 * @return string
 */
function zymarg_os_defer_scripts( $tag, $handle ) {
	if ( ! apply_filters( 'zymarg_os_defer_scripts', true ) ) {
		return $tag;
	}

	$defer = apply_filters( 'zymarg_os_deferred_handles', array( 'zymarg-os-theme' ) );

	if ( in_array( $handle, $defer, true ) && false === strpos( $tag, ' defer' ) ) {
		$tag = str_replace( ' src', ' defer src', $tag );
	}

	return $tag;
}
add_filter( 'script_loader_tag', 'zymarg_os_defer_scripts', 10, 2 );

/**
 * Remove the global WP version query string is unnecessary; keep DNS prefetch
 * for the Google Fonts host disabled when not using Google fonts.
 *
 * Disable WordPress's automatic dns-prefetch for s.w.org (emoji CDN) since we
 * disable emojis above.
 *
 * @param array  $urls          Resource URLs.
 * @param string $relation_type Relation type.
 * @return array
 */
function zymarg_os_clean_resource_hints( $urls, $relation_type ) {
	if ( 'dns-prefetch' === $relation_type ) {
		$urls = array_filter(
			$urls,
			function ( $url ) {
				$href = is_array( $url ) ? ( isset( $url['href'] ) ? $url['href'] : '' ) : $url;
				return false === strpos( (string) $href, 's.w.org' );
			}
		);
	}

	return $urls;
}
add_filter( 'wp_resource_hints', 'zymarg_os_clean_resource_hints', 10, 2 );



/* ---------------------------------------------------------------------- *
 * Anti-CLS: prevent Elementor header from "dancing" on layout shift.
 * ---------------------------------------------------------------------- *
 * When the theme's full-width overrides kick in (My Account, PDP), the
 * content below the header expands to 100% causing a brief reflow. This
 * critical inline CSS stabilizes the Elementor header container so it
 * never shifts, regardless of what happens below it.
 * ---------------------------------------------------------------------- */

/**
 * Inject anti-CLS critical CSS to prevent layout shift / "dancing"
 * caused by scrollbar appearing, font swap, or full-width overrides.
 *
 * Loads at priority 1 so it's the FIRST style in <head>, before
 * any other stylesheet has a chance to cause a reflow.
 *
 * @return void
 */
function zymarg_os_elementor_header_anti_cls() {
	// Detect special pages that have full-width overrides.
	$is_account  = function_exists( 'is_account_page' ) && is_account_page();
	$is_product  = function_exists( 'is_product' ) && is_product();
	$is_checkout = function_exists( 'is_checkout' ) && is_checkout();
	$is_special  = $is_account || $is_product;

	// Master switch for the anti-"dance" boot freeze (filterable; set to false
	// via add_filter( 'zymarg_os_anti_dance', '__return_false' ) to disable).
	// DISABLED on checkout: WooCommerce fires update_checkout AJAX immediately
	// after page load which replaces DOM fragments. The boot freeze suppresses
	// transitions during that swap, causing a visible "double render" flash
	// (garbled unstyled HTML → then normal). Checkout doesn't need the freeze
	// because it has no full-width overrides or entrance animations.
	$freeze = $is_checkout ? false : (bool) apply_filters( 'zymarg_os_anti_dance', true );
	?>
	<script id="zymarg-anti-cls-init">
	/* Add HTML-level classes SYNCHRONOUSLY before any CSS parses, so the
	   full-width rules apply from the FIRST paint frame. */
	(function() {
		var h = document.documentElement;
		<?php if ( $freeze ) : ?>
		h.classList.add('zymarg-booting');
		<?php endif; ?>
		<?php if ( $is_account ) : ?>
		h.classList.add('zymarg-is-account');
		<?php endif; ?>
		<?php if ( $is_product ) : ?>
		h.classList.add('zymarg-is-product');
		<?php endif; ?>
	})();
	</script>
	<style id="zymarg-header-anti-cls">
	<?php if ( $freeze ) : ?>
	/* ─── ANTI-"DANCE" BOOT FREEZE (all pages) ─── */
	/* Freeze transitions + entrance animations during the first paints so the
	   page and the Elementor header snap straight to their final layout instead
	   of visibly settling in. JS removes .zymarg-booting a moment after load;
	   a 1.5s safety timer guarantees it can never stay stuck. Content stays
	   visible the whole time (animations resolve to their final frame). */
	html.zymarg-booting,
	html.zymarg-booting *,
	html.zymarg-booting *::before,
	html.zymarg-booting *::after {
		transition: none !important;
		animation-duration: .001ms !important;
		animation-delay: 0s !important;
		scroll-behavior: auto !important;
	}
	<?php endif; ?>

	/* ─── GLOBAL ANTI-CLS RULES (all pages) ─── */

	/* Reserve scrollbar space ALWAYS so page width never changes when
	   content goes from short to tall (the #1 cause of layout dance). */
	html {
		scrollbar-gutter: stable;
		/* Force scrollbar always visible as a fallback for older browsers
		   that don't support scrollbar-gutter (Safari < 16). */
		overflow-y: scroll;
	}

	/* Prevent horizontal overflow from anywhere triggering a reflow.
	   overflow:clip is better than overflow:hidden — doesn't break sticky. */
	html, body {
		overflow-x: clip;
		max-width: 100vw;
	}

	/* ─── ELEMENTOR HEADER ISOLATION ─── */
	/* isolation: isolate creates a new stacking context — the header
	   becomes truly independent of body layout changes below it.
	   contain: paint means the browser won't repaint the header when
	   anything below changes. transform: translateZ(0) forces GPU layer. */
	.elementor-location-header,
	[data-elementor-type="header"] {
		isolation: isolate;
		contain: paint;
		transform: translateZ(0);
		-webkit-backface-visibility: hidden;
		backface-visibility: hidden;
		position: relative;
		z-index: 100;
	}

	/* Disable transitions on the header for the first 500ms to prevent
	   "settle-in" animations from looking like a dance. */
	html.zymarg-is-account .elementor-location-header,
	html.zymarg-is-account .elementor-location-header *,
	html.zymarg-is-product .elementor-location-header,
	html.zymarg-is-product .elementor-location-header * {
		transition-duration: 0s !important;
		animation-duration: 0s !important;
	}

	/* Re-enable transitions after the page has settled. */
	html.zymarg-page-ready .elementor-location-header,
	html.zymarg-page-ready .elementor-location-header * {
		transition-duration: revert !important;
		animation-duration: revert !important;
	}

	/* ─── FULL-WIDTH OVERRIDES (account + product) ─── */
	/* These were previously scoped to body.* class which was added AFTER
	   the page started rendering, causing a flash from constrained to
	   full-width. Now scoped to html.* class (added by inline JS above)
	   so they apply from the very first paint. */
	html.zymarg-is-account .zymarg-container,
	html.zymarg-is-account .zymarg-site-content,
	html.zymarg-is-account .zymarg-entry,
	html.zymarg-is-account .zymarg-entry__content,
	html.zymarg-is-account .zymarg-main,
	html.zymarg-is-account .zymarg-woo-main,
	html.zymarg-is-account #content {
		max-width: none !important;
		width: 100% !important;
		padding: 0 !important;
		margin: 0 !important;
	}

	/* Pre-allocate header space so content doesn't jump up before
	   the Elementor header's own CSS finishes loading. */
	.elementor-location-header:empty {
		min-height: 80px;
	}
	</style>
	<script id="zymarg-page-ready">
	/* Remove the boot freeze right after the first paint (so the initial render
	   never "dances"), then mark the page ready so header transitions resume. */
	(function() {
		var html = document.documentElement;
		function unfreeze() { html.classList.remove('zymarg-booting'); }
		function pageReady() { html.classList.add('zymarg-page-ready'); }
		function onReady() {
			window.requestAnimationFrame(function() {
				window.requestAnimationFrame(unfreeze);
			});
		}
		if (document.readyState === 'loading') {
			document.addEventListener('DOMContentLoaded', onReady);
		} else {
			onReady();
		}
		window.addEventListener('load', function() {
			unfreeze();
			window.requestAnimationFrame(function() { window.setTimeout(pageReady, 300); });
		});
		/* Safety net: never stay frozen even if an event fails to fire. */
		window.setTimeout(unfreeze, 1500);
	})();
	</script>
	<?php
}
add_action( 'wp_head', 'zymarg_os_elementor_header_anti_cls', 0 );
