<?php
/**
 * Mega menu support.
 *
 * Provides a nav walker that upgrades any top-level menu item with the CSS
 * class `mega-menu` into a multi-column dropdown. Add the class in Appearance
 * -> Menus (enable "CSS Classes" via Screen Options) and optionally
 * `mega-cols-2`..`mega-cols-6` to control the column count.
 *
 * Usage in a template or via the ZYMARG plugin:
 *   wp_nav_menu( array(
 *       'theme_location' => 'mega',
 *       'container'      => false,
 *       'menu_class'     => 'zymarg-nav',
 *       'walker'         => new ZYMARG_OS_Mega_Menu_Walker(),
 *   ) );
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Walker_Nav_Menu' ) ) {
	return;
}

/**
 * Mega menu walker.
 */
class ZYMARG_OS_Mega_Menu_Walker extends Walker_Nav_Menu {

	/**
	 * Start element output. Adds mega-menu classes + column custom property.
	 *
	 * @param string   $output Passed by reference.
	 * @param WP_Post  $item   Menu item data object.
	 * @param int      $depth  Depth of menu item.
	 * @param stdClass $args   Menu arguments.
	 * @param int      $id     Current item ID.
	 */
	public function start_el( &$output, $item, $depth = 0, $args = null, $id = 0 ) {
		$classes   = empty( $item->classes ) ? array() : (array) $item->classes;
		$is_mega   = in_array( 'mega-menu', $classes, true );
		$style_att = '';

		if ( 0 === $depth && $is_mega ) {
			$classes[] = 'zymarg-mega-menu';

			// Detect a mega-cols-N class to set the column count.
			foreach ( $classes as $class ) {
				if ( preg_match( '/^mega-cols-([2-6])$/', $class, $m ) ) {
					$style_att = ' style="--zymarg-mega-columns:' . absint( $m[1] ) . '"';
					break;
				}
			}

			$item->classes = $classes;
		}

		// Let the parent build the standard markup, then inject our style attr.
		$parent_output = '';
		parent::start_el( $parent_output, $item, $depth, $args, $id );

		if ( $style_att && false !== strpos( $parent_output, '<li ' ) ) {
			$parent_output = preg_replace( '/<li /', '<li' . $style_att . ' ', $parent_output, 1 );
		}

		$output .= $parent_output;
	}
}

/**
 * Mark a wrapper as sticky-aware. Add the `zymarg-sticky` class to any element
 * (e.g. your plugin's header) and theme.js will toggle `is-stuck` on scroll.
 * This helper simply documents the contract; no PHP action is required.
 *
 * @return void
 */
function zymarg_os_mega_menu_loaded() {
	do_action( 'zymarg_os_mega_menu_loaded' );
}
add_action( 'init', 'zymarg_os_mega_menu_loaded' );
