<?php
/**
 * Product Card Delegate.
 *
 * When the ZYMARG WC Product Grid plugin is active, all product card rendering
 * in the theme delegates to the plugin's card template. When the plugin is not
 * active, the theme falls back to its own basic card markup.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

/**
 * Check whether the ZYMARG WC Product Grid plugin is active and available.
 *
 * @return bool
 */
function zymarg_os_wcpg_active() {
	return class_exists( '\Zymarg\WCPG\Template_Loader' );
}

/**
 * Get the default settings array for the plugin's product card.
 *
 * @return array
 */
function zymarg_os_wcpg_card_settings() {
	return apply_filters( 'zymarg_os_wcpg_card_settings', array(
		'show_image'           => 'yes',
		'show_discount_badge'  => 'yes',
		'show_stock_badge'     => 'yes',
		'show_wishlist'        => 'yes',
		'show_quickview'       => 'yes',
		'show_atc'             => 'yes',
		'show_title'           => 'yes',
		'show_vendor'          => 'yes',
		'show_price'           => 'yes',
		'show_rating'          => 'yes',
		'show_sold_count'      => 'yes',
		'columns'              => 4,
		'price_position'       => 'below_rating',
		'vendor_position'      => 'below_price',
		'atc_position'         => 'with_price',
		'image_hover_zoom'     => 'yes',
		'quickview_visibility' => 'desktop',
		'quickview_display'    => 'hover_only',
	) );
}

/**
 * Render a single product card.
 *
 * Uses the ZYMARG WC Product Grid plugin template when available, otherwise
 * falls back to the theme's basic card markup.
 *
 * @param WC_Product|int $product WC_Product object or product ID.
 * @return void
 */
function zymarg_os_render_product_card( $product ) {
	if ( is_numeric( $product ) ) {
		$product = wc_get_product( $product );
	}

	if ( ! $product instanceof \WC_Product ) {
		return;
	}

	if ( zymarg_os_wcpg_active() ) {
		\Zymarg\WCPG\Template_Loader::get_template( 'grid/product-card.php', array(
			'product'   => $product,
			'settings'  => zymarg_os_wcpg_card_settings(),
			'widget_id' => 'theme',
		) );
		return;
	}

	// Fallback: theme's basic card markup.
	$permalink = $product->get_permalink();
	$image     = $product->get_image( 'medium' );
	$title     = $product->get_name();
	$price     = $product->get_price_html();
	?>
	<article class="zymarg-card zymarg-result">
		<a class="zymarg-result__link" href="<?php echo esc_url( $permalink ); ?>">
			<?php if ( $image ) : ?>
				<span class="zymarg-result__media"><?php echo $image; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
			<?php endif; ?>
			<h2 class="zymarg-result__title"><?php echo esc_html( $title ); ?></h2>
		</a>
		<?php if ( $price ) : ?>
			<div class="price"><?php echo wp_kses_post( $price ); ?></div>
		<?php endif; ?>
	</article>
	<?php
}

/**
 * Render a full product grid.
 *
 * Uses the plugin's grid-wrapper template when available, otherwise renders
 * cards inside the theme's standard grid container.
 *
 * @param WC_Product[]|int[] $products Array of WC_Product objects or product IDs.
 * @param int                $columns  Number of grid columns.
 * @return void
 */
function zymarg_os_render_product_grid( $products, $columns = 4 ) {
	if ( empty( $products ) ) {
		return;
	}

	// Normalize to WC_Product objects.
	$wc_products = array();
	foreach ( $products as $product ) {
		if ( is_numeric( $product ) ) {
			$product = wc_get_product( $product );
		}
		if ( $product instanceof \WC_Product ) {
			$wc_products[] = $product;
		}
	}

	if ( empty( $wc_products ) ) {
		return;
	}

	if ( zymarg_os_wcpg_active() ) {
		$settings            = zymarg_os_wcpg_card_settings();
		$settings['columns'] = $columns;

		\Zymarg\WCPG\Template_Loader::get_template( 'grid/grid-wrapper.php', array(
			'settings'  => $settings,
			'widget_id' => 'theme',
			'products'  => $wc_products,
		) );
		return;
	}

	// Fallback: theme's basic grid.
	echo '<div class="zymarg-grid zymarg-grid--auto zymarg-results__grid">';
	foreach ( $wc_products as $product ) {
		zymarg_os_render_product_card( $product );
	}
	echo '</div>';
}
