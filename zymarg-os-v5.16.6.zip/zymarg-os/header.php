<?php
/**
 * The header.
 *
 * Deliberately minimal: ZYMARG OS does NOT render a visual header (logo, nav,
 * etc.) — that is handled by the ZYMARG plugin / page builder. This file only
 * outputs the document head, the opening <body>, and fires wp_body_open so the
 * background orbs and any plugin-injected header content can attach.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

	<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'zymarg-os' ); ?></a>

	<div id="page" class="zymarg-site">
