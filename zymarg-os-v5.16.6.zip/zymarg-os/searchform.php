<?php
/**
 * Custom search form.
 *
 * @package ZYMARG_OS
 */

defined( 'ABSPATH' ) || exit;

$zymarg_unique_id = wp_unique_id( 'search-form-' );
?>
<form role="search" method="get" class="zymarg-search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label for="<?php echo esc_attr( $zymarg_unique_id ); ?>" class="screen-reader-text">
		<?php esc_html_e( 'Search for:', 'zymarg-os' ); ?>
	</label>
	<input
		type="search"
		id="<?php echo esc_attr( $zymarg_unique_id ); ?>"
		class="zymarg-search-form__field"
		placeholder="<?php esc_attr_e( 'Search products…', 'zymarg-os' ); ?>"
		value="<?php echo get_search_query(); ?>"
		name="s"
	/>
	<button type="submit" class="zymarg-btn zymarg-search-form__submit">
		<?php esc_html_e( 'Search', 'zymarg-os' ); ?>
	</button>
</form>
