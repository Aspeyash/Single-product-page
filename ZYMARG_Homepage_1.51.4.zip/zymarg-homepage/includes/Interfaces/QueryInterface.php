<?php
/**
 * ZYMARG Homepage – Query Interface
 *
 * Contract for all data-retrieval classes. Every Query.php inside a Feature
 * folder and every shared query class in includes/Queries/ must implement
 * this interface so LayoutEngine can call them uniformly.
 *
 * @package ZYMARGHomepage\Interfaces
 * @since   1.1.0
 * @version 1.2.0
 */

namespace ZYMARGHomepage\Interfaces;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Interface QueryInterface
 *
 * Standardises how features retrieve their data from WordPress/WooCommerce.
 */
interface QueryInterface {

    /**
     * Execute the query and return a structured result array.
     *
     * Implementations must:
     *   – Never echo or output anything.
     *   – Check the cache before querying the database.
     *   – Store results in the cache after a cache miss.
     *   – Return an empty array (not null) when there are no results.
     *
     * @since 1.1.0
     * @param array $args Query arguments (limit, category, order, etc.).
     * @return array Result set; structure is query-class-specific.
     */
    public function get( array $args = [] ): array;
}
