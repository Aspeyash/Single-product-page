<?php
/**
 * ZYMARG Homepage – Feature Interface
 *
 * Contract that every homepage feature section must implement.
 * Features register themselves with FeatureRegistry, declare their
 * default state, and expose a render entry-point used by LayoutEngine.
 *
 * @package ZYMARGHomepage\Interfaces
 * @since   1.1.0
 * @version 1.2.0
 */

namespace ZYMARGHomepage\Interfaces;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Interface FeatureInterface
 *
 * All homepage feature classes must implement this interface.
 */
interface FeatureInterface {

    /**
     * Return the unique machine-readable slug for this feature.
     *
     * Must match the slug listed in CONTRIBUTING.md §4
     * (e.g. 'hero', 'categories', 'flash-deals').
     *
     * @since 1.1.0
     * @return string
     */
    public function get_slug(): string;

    /**
     * Return the human-readable label shown in the admin panel.
     *
     * @since 1.1.0
     * @return string
     */
    public function get_label(): string;

    /**
     * Return the default display order (1-based) for this feature.
     *
     * Used only when no saved order exists in zymarg_hp_section_order.
     *
     * @since 1.1.0
     * @return int
     */
    public function get_default_order(): int;

    /**
     * Return whether this feature is enabled by default on activation.
     *
     * @since 1.1.0
     * @return bool
     */
    public function is_enabled_by_default(): bool;

    /**
     * Render the feature section and return the HTML string.
     *
     * Called by LayoutEngine only when the feature is enabled.
     * Must return a string — never echo directly.
     *
     * @since 1.1.0
     * @param array $settings Per-section settings saved by the admin.
     * @return string HTML output.
     */
    public function render( array $settings ): string;
}
