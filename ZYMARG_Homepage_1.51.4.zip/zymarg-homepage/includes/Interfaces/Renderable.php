<?php
/**
 * ZYMARG Homepage – Renderable Interface
 *
 * Contract for all Template classes. Every Template.php inside a Feature
 * folder must implement this interface so LayoutEngine can call render()
 * without knowing the concrete class.
 *
 * Rule (CONTRIBUTING.md §7): template files must never call wp_enqueue_*
 * or contain query logic. They receive pre-fetched data and return HTML.
 *
 * @package ZYMARGHomepage\Interfaces
 * @since   1.1.0
 * @version 1.2.0
 */

namespace ZYMARGHomepage\Interfaces;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Interface Renderable
 *
 * Implemented by every Feature Template class.
 */
interface Renderable {

    /**
     * Render this template and return the resulting HTML string.
     *
     * Implementations must:
     *   – Never echo or output anything; always return the full HTML.
     *   – Escape all values: esc_html(), esc_attr(), esc_url(), wp_kses_post().
     *   – Use zhp- prefixed CSS classes only.
     *   – Never contain query logic or wp_enqueue_* calls.
     *
     * @since 1.1.0
     * @param array $data    Pre-fetched data from the corresponding Query class.
     * @param array $settings Per-section admin settings.
     * @return string HTML output.
     */
    public function render( array $data, array $settings ): string;
}
