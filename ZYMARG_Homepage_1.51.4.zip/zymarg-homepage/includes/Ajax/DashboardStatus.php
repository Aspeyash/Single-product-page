<?php
/**
 * ZYMARG Homepage – Dashboard Status AJAX Handler
 *
 * Returns a JSON snapshot of the plugin's live configuration health,
 * consumed by the Dashboard admin page to populate its status bar
 * without a full page reload.
 *
 * Response shape:
 * {
 *   master_enabled        : bool,
 *   sections_enabled      : int,
 *   sections_total        : int,
 *   front_page_configured : bool,   // WP front page set to a static page
 *   shortcode_on_front    : bool,   // [zymarg_homepage] in that page's content
 *   woocommerce_active    : bool,
 *   dokan_active          : bool,
 *   product_grid_active   : bool,   // ZYMARG WC Product Grid engine running
 *   template_pack_active  : bool,   // ZYMARG Template Pack card registered
 *   flash_deals_ready     : bool,   // engine exposes a flash_deals source
 * }
 *
 * Hooked to wp_ajax_zhp_dashboard_status via Hooks::register().
 * Requires manage_options capability — not exposed to non-logged-in users.
 *
 * @package ZYMARGHomepage\Ajax
 * @since   1.7.0
 * @version 1.31.1
 */

namespace ZYMARGHomepage\Ajax;

use ZYMARGHomepage\Admin\Settings;
use ZYMARGHomepage\Homepage\SectionManager;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class DashboardStatus
 *
 * Handles the wp_ajax_zhp_dashboard_status AJAX action.
 *
 * @since 1.7.0
 */
final class DashboardStatus {

    /**
     * Handle the AJAX request.
     *
     * Validates nonce and capability, then returns a JSON status payload.
     *
     * @since 1.7.0
     * @return void
     */
    public function handle(): void {

        check_ajax_referer( 'zhp_dashboard_status', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'zymarg-homepage' ) ], 403 );
        }

        // ── Settings ─────────────────────────────────────────────
        $settings = Settings::get_all();

        // ── Section counts ────────────────────────────────────────
        $section_manager  = new SectionManager();
        $all_sections     = $section_manager->get_all_sections();
        $sections_total   = count( $all_sections );
        $sections_enabled = count( array_filter(
            $all_sections,
            static fn( array $s ): bool => ! empty( $s['enabled'] )
        ) );

        // ── Front page configuration ──────────────────────────────
        $show_on_front         = get_option( 'show_on_front' );
        $page_on_front         = (int) get_option( 'page_on_front' );
        $front_page_configured = ( 'page' === $show_on_front && $page_on_front > 0 );

        // ── Shortcode presence ────────────────────────────────────
        $shortcode_on_front = false;
        if ( $front_page_configured ) {
            $front_page = get_post( $page_on_front );
            if ( $front_page instanceof \WP_Post ) {
                $shortcode_on_front = has_shortcode( $front_page->post_content, 'zymarg_homepage' );
            }
        }

        // ── Plugin dependencies ───────────────────────────────────
        $woocommerce_active = class_exists( 'WooCommerce' );
        $dokan_active       = class_exists( 'WeDevs_Dokan' ) || function_exists( 'dokan' );

        // The homepage no longer queries products itself, so the state of
        // the engine and its card pack is the most useful thing this page
        // can report.
        $bridge               = '\\ZYMARGHomepage\\Integration\\ProductGridBridge';
        $product_grid_active  = (bool) call_user_func( array( $bridge, 'is_engine_available' ) );
        $template_pack_active = (bool) call_user_func( array( $bridge, 'is_template_pack_available' ) );
        $flash_deals_ready    = (bool) call_user_func( array( $bridge, 'is_flash_deals_available' ) );

        wp_send_json_success( [
            'master_enabled'        => (bool) $settings['master_enabled'],
            'sections_enabled'      => $sections_enabled,
            'sections_total'        => $sections_total,
            'front_page_configured' => $front_page_configured,
            'shortcode_on_front'    => $shortcode_on_front,
            'woocommerce_active'    => $woocommerce_active,
            'dokan_active'          => $dokan_active,
            'product_grid_active'   => $product_grid_active,
            'template_pack_active'  => $template_pack_active,
            'flash_deals_ready'     => $flash_deals_ready,
        ] );
    }
}
