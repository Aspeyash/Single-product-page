<?php
/**
 * ZYMARG Homepage – Admin AJAX Page Router
 *
 * Serves the plugin's own admin screens over admin-ajax.php so the admin
 * area behaves like a single-page app: clicking Dashboard, Homepage,
 * Settings or Help in the submenu swaps the content without a full
 * WordPress page load.
 *
 * The page classes are reused untouched. Each one echoes its markup from
 * render(), so this router simply captures that output with an output
 * buffer and returns it as a JSON string. There is no duplicated markup
 * and no second rendering path to keep in sync — the AJAX response is
 * byte-for-byte what a normal page load would have produced.
 *
 * Security is deliberately identical to a normal admin page load:
 *   • a nonce, so a third-party site cannot make the browser fetch these
 *     screens,
 *   • a manage_options capability check, matching the capability passed to
 *     add_submenu_page() in Menu.php,
 *   • a slug allowlist, so the action can only ever render this plugin's
 *     four screens and can never be pointed at arbitrary callables.
 *
 * @package ZYMARGHomepage\Admin
 * @since   1.19.0
 * @version 1.19.0
 */

namespace ZYMARGHomepage\Admin;

use ZYMARGHomepage\Homepage\HomepageController;
use ZYMARGHomepage\Admin\Pages\Dashboard;
use ZYMARGHomepage\Admin\Pages\Homepage;
use ZYMARGHomepage\Admin\Pages\Settings;
use ZYMARGHomepage\Admin\Pages\Help;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class AjaxRouter
 *
 * Handles wp_ajax_zhp_admin_page — returns a rendered admin screen as HTML.
 */
final class AjaxRouter {

    /**
     * Nonce action for admin page requests.
     *
     * @since 1.19.0
     */
    public const NONCE_ACTION = 'zhp_admin_page';

    /**
     * Homepage controller — needed to build the section manager screen.
     *
     * @since 1.19.0
     * @var HomepageController
     */
    private HomepageController $controller;

    /**
     * Constructor.
     *
     * @since 1.19.0
     * @param HomepageController $controller Homepage engine controller.
     */
    public function __construct( HomepageController $controller ) {
        $this->controller = $controller;
    }

    /**
     * Return the plugin admin page slugs this router can serve.
     *
     * Assets.php uses this to hand the list to JavaScript, so the allowlist
     * lives in exactly one place.
     *
     * @since 1.19.0
     * @return array<string,string> Slug => submenu label.
     */
    public static function pages(): array {
        return [
            'zymarg-homepage'          => __( 'Dashboard', 'zymarg-homepage' ),
            'zymarg-homepage-sections' => __( 'Homepage', 'zymarg-homepage' ),
            'zymarg-homepage-settings' => __( 'Settings', 'zymarg-homepage' ),
            'zymarg-homepage-help'     => __( 'Help', 'zymarg-homepage' ),
        ];
    }

    /**
     * Handle the AJAX request.
     *
     * Hooked to wp_ajax_zhp_admin_page via Hooks::register().
     *
     * @since 1.19.0
     * @return void
     */
    public function handle(): void {
        check_ajax_referer( self::NONCE_ACTION, 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error(
                [ 'message' => __( 'Insufficient permissions.', 'zymarg-homepage' ) ],
                403
            );
        }

        $slug = isset( $_POST['slug'] )
            ? sanitize_key( wp_unslash( $_POST['slug'] ) )
            : '';

        $pages = self::pages();

        if ( ! isset( $pages[ $slug ] ) ) {
            wp_send_json_error(
                [ 'message' => __( 'Unknown admin page.', 'zymarg-homepage' ) ],
                400
            );
        }

        /*
         * On a normal page load these carry the current screen slug, and page
         * code is entitled to read them — Assets::current_plugin_page() does
         * exactly that. During an admin-ajax request they hold the AJAX action
         * instead, so they are pointed at the screen actually being rendered.
         */
        $_GET['page']     = $slug;
        $_REQUEST['page'] = $slug;

        /*
         * Point the WP screen API at the plugin page being rendered so that
         * any code that calls get_current_screen() (including admin notices
         * and Assets::current_plugin_page()) resolves to the right context.
         */
        set_current_screen( $slug );

        wp_send_json_success(
            [
                'slug'  => $slug,
                'title' => $pages[ $slug ],
                'html'  => $this->capture( $slug ),
            ]
        );
    }

    // ──────────────────────────────────────────────────────────────
    //  Private helpers
    // ──────────────────────────────────────────────────────────────

    /**
     * Render a screen into a string.
     *
     * @since 1.19.0
     * @param string $slug Allowlisted plugin page slug.
     * @return string Rendered HTML.
     */
    private function capture( string $slug ): string {
        $page = $this->page_for( $slug );

        ob_start();
        $page->render();

        return (string) ob_get_clean();
    }

    /**
     * Build the page object for a slug.
     *
     * Mirrors the instantiation in Menu::register(), so both entry points
     * construct these screens the same way.
     *
     * @since 1.19.0
     * @param string $slug Allowlisted plugin page slug.
     * @return Dashboard|Homepage|Settings|Help
     */
    private function page_for( string $slug ) {
        switch ( $slug ) {
            case 'zymarg-homepage-sections':
                return new Homepage( $this->controller->get_section_manager() );

            case 'zymarg-homepage-settings':
                return new Settings();

            case 'zymarg-homepage-help':
                return new Help();

            default:
                return new Dashboard();
        }
    }
}
