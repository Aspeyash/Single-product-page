<?php
/**
 * ZYMARG Homepage – Admin Bootstrap
 *
 * Instantiated by Plugin::setup() when is_admin() is true.
 * Wires together all admin subsystems: Menu, Assets, DragDrop, and the
 * three admin pages (Dashboard, Homepage, Settings).
 *
 * No add_action / add_filter calls live here — all hooks are registered
 * via Hooks::register() in Core/Hooks.php.
 *
 * @package ZYMARGHomepage\Admin
 * @since   1.3.0
 * @version 1.19.0
 */

namespace ZYMARGHomepage\Admin;

use ZYMARGHomepage\Homepage\HomepageController;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Admin
 *
 * Top-level admin coordinator. Exposes callback methods that Hooks.php
 * binds to WordPress admin hooks.
 */
final class Admin {

    /**
     * Homepage controller — used by Pages\Homepage to access SectionManager.
     *
     * @since 1.3.0
     * @var HomepageController
     */
    private HomepageController $controller;

    /**
     * Admin asset manager.
     *
     * @since 1.3.0
     * @var Assets
     */
    private Assets $assets;

    /**
     * Drag-and-drop handler.
     *
     * @since 1.3.0
     * @var DragDrop
     */
    private DragDrop $drag_drop;

    /**
     * Admin menu registrar.
     *
     * @since 1.3.0
     * @var Menu
     */
    private Menu $menu;

    /**
     * AJAX admin page router.
     *
     * @since 1.19.0
     * @var AjaxRouter
     */
    private AjaxRouter $ajax_router;

    /**
     * Constructor.
     *
     * @since 1.3.0
     * @param HomepageController $controller The homepage engine controller.
     */
    public function __construct( HomepageController $controller ) {
        $this->controller = $controller;
        $this->assets     = new Assets();
        $this->drag_drop  = new DragDrop( $controller->get_section_manager() );
        $this->menu        = new Menu( $controller );
        $this->ajax_router = new AjaxRouter( $controller );
    }

    /**
     * Return the Menu instance for hook binding.
     *
     * @since 1.3.0
     * @return Menu
     */
    public function get_menu(): Menu {
        return $this->menu;
    }

    /**
     * Return the Assets instance for hook binding.
     *
     * @since 1.3.0
     * @return Assets
     */
    public function get_assets(): Assets {
        return $this->assets;
    }

    /**
     * Return the DragDrop instance for hook binding.
     *
     * @since 1.3.0
     * @return DragDrop
     */
    public function get_drag_drop(): DragDrop {
        return $this->drag_drop;
    }

    /**
     * Return the AJAX page router for hook binding.
     *
     * @since 1.19.0
     * @return AjaxRouter
     */
    public function get_ajax_router(): AjaxRouter {
        return $this->ajax_router;
    }
}
