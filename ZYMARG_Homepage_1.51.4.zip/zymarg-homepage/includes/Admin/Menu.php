<?php
/**
 * ZYMARG Homepage – Admin Menu
 *
 * Registers the ZYMARG Homepage top-level admin menu and its three
 * sub-pages: Dashboard, Homepage (section manager), and Settings.
 *
 * Menu structure:
 *   ZYMARG Homepage
 *     ├── Dashboard
 *     ├── Homepage   ← section drag-and-drop manager
 *     ├── Settings
 *     └── Help       ← setup guide and developer reference
 *
 * @package ZYMARGHomepage\Admin
 * @since   1.3.0
 * @version 1.22.0
 */

namespace ZYMARGHomepage\Admin;

use ZYMARGHomepage\Homepage\HomepageController;
use ZYMARGHomepage\Admin\Pages\Dashboard;
use ZYMARGHomepage\Admin\Pages\Homepage;
use ZYMARGHomepage\Admin\Pages\Settings;
use ZYMARGHomepage\Admin\Pages\Help;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Menu
 *
 * Registers the WordPress admin menu for the ZYMARG Homepage plugin.
 * Called via add_action( 'admin_menu', … ) in Hooks.php.
 */
final class Menu {

    /**
     * Parent menu slug — shared across all sub-pages.
     *
     * @since 1.3.0
     */
    public const PARENT_SLUG = 'zymarg-homepage';

    /**
     * Homepage controller — passed to page classes.
     *
     * @since 1.3.0
     * @var HomepageController
     */
    private HomepageController $controller;

    /**
     * Constructor.
     *
     * @since 1.3.0
     * @param HomepageController $controller Homepage engine controller.
     */
    public function __construct( HomepageController $controller ) {
        $this->controller = $controller;
    }

    /**
     * Register the admin menu.
     *
     * Hooked to admin_menu via Hooks::register().
     *
     * @since 1.3.0
     * @return void
     */
    public function register(): void {
        $dashboard = new Dashboard();
        $homepage  = new Homepage( $this->controller->get_section_manager() );
        $settings  = new Settings();
        $help      = new Help();

        // Top-level menu item (maps to Dashboard sub-page).
        add_menu_page(
            __( 'ZYMARG Homepage', 'zymarg-homepage' ),
            __( 'Homepage', 'zymarg-homepage' ),
            'manage_options',
            self::PARENT_SLUG,
            [ $dashboard, 'render' ],
            $this->get_menu_icon(),
            58  // Position: between WooCommerce and appearance.
        );

        // Sub-page: Dashboard (same slug as parent — no duplicate in menu).
        add_submenu_page(
            self::PARENT_SLUG,
            __( 'Dashboard – ZYMARG Homepage', 'zymarg-homepage' ),
            __( 'Dashboard', 'zymarg-homepage' ),
            'manage_options',
            self::PARENT_SLUG,
            [ $dashboard, 'render' ]
        );

        // Sub-page: Homepage section manager.
        add_submenu_page(
            self::PARENT_SLUG,
            __( 'Homepage – ZYMARG Homepage', 'zymarg-homepage' ),
            __( 'Homepage', 'zymarg-homepage' ),
            'manage_options',
            'zymarg-homepage-sections',
            [ $homepage, 'render' ]
        );

        // Sub-page: Settings.
        add_submenu_page(
            self::PARENT_SLUG,
            __( 'Settings – ZYMARG Homepage', 'zymarg-homepage' ),
            __( 'Settings', 'zymarg-homepage' ),
            'manage_options',
            'zymarg-homepage-settings',
            [ $settings, 'render' ]
        );

        // Sub-page: Help & Documentation.
        add_submenu_page(
            self::PARENT_SLUG,
            __( 'Help – ZYMARG Homepage', 'zymarg-homepage' ),
            __( 'Help', 'zymarg-homepage' ),
            'manage_options',
            'zymarg-homepage-help',
            [ $help, 'render' ]
        );
    }

    // ──────────────────────────────────────────────────────────────
    //  Private helpers
    // ──────────────────────────────────────────────────────────────

    /**
     * Return an inline SVG data URI for the menu icon.
     *
     * Uses the ZYMARG primary brand colour (#9500A5).
     *
     * @since 1.3.0
     * @return string base64 SVG data URI.
     */

    /**
     * Sidebar parent-menu branding (Design Tokens v3 section 2.16).
     *
     * Replaces the old render_menu_css() admin_head inline <style> that
     * painted the label #9500A5 on the default dark bar. The new pattern
     * paints the whole item with the brand gradient and flips content
     * to surface white in every state. Because Homepage ships a custom
     * SVG icon (not a dashicon), the stylesheet also carries the
     * mask-image block that repaints the glyph in surface white -- see
     * assets/css/admin/zhp-menu.css.
     *
     * Runs on every admin page: the sidebar is everywhere.
     *
     * @since 1.51.4
     * @return void
     */
    public function enqueue_menu_branding(): void {
        // Register the shared tokens under their canonical handle if a
        // sibling ZYMARG plugin has not already. The plugin already ships
        // a tokens file at assets/css/frontend/zymarg-tokens.css, which
        // is intentionally shared between the front and the back end --
        // see the token file top comment.
        if ( ! wp_style_is( 'zymarg-tokens', 'registered' ) ) {
            wp_register_style(
                'zymarg-tokens',
                ZYMARG_HP_PLUGIN_URL . 'assets/css/frontend/zymarg-tokens.css',
                array(),
                ZYMARG_HP_VERSION
            );
        }

        wp_enqueue_style( 'zymarg-tokens' );

        wp_enqueue_style(
            'zhp-menu',
            ZYMARG_HP_PLUGIN_URL . 'assets/css/admin/zhp-menu.css',
            array( 'zymarg-tokens' ),
            ZYMARG_HP_VERSION
        );
    }

    private function get_menu_icon(): string {
        $svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="%23a0a5aa"><path d="M3 4a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V4zm0 6a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v6a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-6zm10 0a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1h-2a1 1 0 0 1-1-1v-2zm0 5a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v1a1 1 0 0 1-1 1h-2a1 1 0 0 1-1-1v-1z"/></svg>';

        return 'data:image/svg+xml;base64,' . base64_encode( $svg );
    }
}
