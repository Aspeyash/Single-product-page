<?php
/**
 * ZYMARG Homepage – Drag-and-Drop AJAX Handler
 *
 * Handles the AJAX request from the Homepage section manager when the
 * admin saves a new section order, toggle state, or per-section settings.
 *
 * The drag-and-drop UI itself is powered by jQuery UI Sortable (admin JS).
 * This class only handles the server-side persistence of the submitted data.
 *
 * @package ZYMARGHomepage\Admin
 * @since   1.3.0
 * @version 1.3.0
 */

namespace ZYMARGHomepage\Admin;

use ZYMARGHomepage\Homepage\SectionManager;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class DragDrop
 *
 * Receives AJAX save requests from the Homepage admin page and persists
 * the new section configuration via SectionManager::save().
 */
final class DragDrop {

    /**
     * Section manager — handles database reads and writes.
     *
     * @since 1.3.0
     * @var SectionManager
     */
    private SectionManager $section_manager;

    /**
     * Constructor.
     *
     * @since 1.3.0
     * @param SectionManager $section_manager Injected section manager.
     */
    public function __construct( SectionManager $section_manager ) {
        $this->section_manager = $section_manager;
    }

    /**
     * Handle the AJAX save request for section order and settings.
     *
     * Hooked to wp_ajax_zhp_save_sections via Hooks::register().
     *
     * Expected POST fields:
     *   nonce    – security nonce (zhp_save_sections)
     *   sections – JSON-encoded array of section rows
     *
     * @since 1.3.0
     * @return void
     */
    public function handle_save(): void {
        check_ajax_referer( 'zhp_save_sections', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error(
                [ 'message' => __( 'Insufficient permissions.', 'zymarg-homepage' ) ],
                403
            );
        }

        // phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce checked above.
        $raw_sections = isset( $_POST['sections'] ) ? wp_unslash( $_POST['sections'] ) : '';
        // phpcs:enable

        if ( ! is_string( $raw_sections ) || empty( $raw_sections ) ) {
            wp_send_json_error( [ 'message' => __( 'No section data received.', 'zymarg-homepage' ) ] );
        }

        $sections = json_decode( $raw_sections, true );

        if ( ! is_array( $sections ) ) {
            wp_send_json_error( [ 'message' => __( 'Invalid section data format.', 'zymarg-homepage' ) ] );
        }

        $saved = $this->section_manager->save( $sections );

        if ( $saved ) {
            wp_send_json_success( [ 'message' => __( 'Section order saved.', 'zymarg-homepage' ) ] );
        } else {
            // update_option returns false when the value hasn't changed — still OK.
            wp_send_json_success( [ 'message' => __( 'No changes to save.', 'zymarg-homepage' ) ] );
        }
    }

    /**
     * Handle the AJAX request to reset all sections to their default order.
     *
     * Hooked to wp_ajax_zhp_reset_sections via Hooks::register().
     *
     * @since 1.3.0
     * @return void
     */
    public function handle_reset(): void {
        check_ajax_referer( 'zhp_save_sections', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error(
                [ 'message' => __( 'Insufficient permissions.', 'zymarg-homepage' ) ],
                403
            );
        }

        // Wipe the option so SectionManager::get_all_sections() rebuilds defaults.
        delete_option( SectionManager::OPTION_KEY );
        add_option( SectionManager::OPTION_KEY, [] );

        wp_send_json_success( [ 'message' => __( 'Section order reset to defaults.', 'zymarg-homepage' ) ] );
    }
}
