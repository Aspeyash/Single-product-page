<?php
/**
 * ZYMARG Homepage – Global Settings Handler
 *
 * Handles saving and retrieving global plugin settings stored in the
 * `zymarg_hp_settings` WordPress option.
 *
 * Fields managed:
 *   master_enabled       – bool  – enable or disable all plugin output.
 *   products_per_section – int   – default product count per section.
 *   cache_duration       – int   – query result cache lifetime (minutes).
 *   support_email        – string – contact address shown on the Help page.
 *   use_product_grid_cards – bool – draw cards with the ZYMARG WC Product Grid
 *                                  engine when it is installed and booted.
 *                                  Ignored (and harmless) when it is not.
 *   section_title_size   – int   – section heading size in px. 0 = automatic.
 *   explore_link_size    – int   – "Explore More" size in px. 0 = automatic.
 *   section_gap          – int   – vertical space BETWEEN sections, 0-100%.
 *   header_gap           – int   – space between a section heading and its
 *                                  cards, 0-100%. 100 = the shipped 24px.
 *
 * This class handles the data layer. UI rendering lives in Pages/Settings.php.
 *
 * @package ZYMARGHomepage\Admin
 * @since   1.3.0
 * @version 1.43.0
 */

namespace ZYMARGHomepage\Admin;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Settings
 *
 * Read / write global plugin settings. Handles the AJAX save request
 * from the Settings admin page.
 */
final class Settings {

    /**
     * WordPress option key for global settings.
     *
     * @since 1.3.0
     */
    public const OPTION_KEY = 'zymarg_hp_settings';

    /**
     * Default values for every setting.
     *
     * @since 1.3.0
     * @var array<string, mixed>
     */
    private const DEFAULTS = [
        'master_enabled'       => true,
        'products_per_section' => 8,
        'cache_duration'       => 15,
        'support_email'        => '',
        // Default true so installing the Product Grid engine later switches
        // the site over automatically, with no settings visit needed.
        'use_product_grid_cards' => true,
        /*
         * Both default to 0, meaning "automatic" — no override is emitted and
         * the responsive clamp() in zymarg-tokens.css continues to scale the
         * text with the viewport.
         *
         * 0 rather than the current pixel value on purpose: a real number here
         * would freeze the size at whatever today's token happens to be, so
         * every existing site would silently lose its fluid type the first time
         * anything saved the settings form.
         */
        'section_title_size'   => 0,
        'explore_link_size'    => 0,
        /*
         * Which card design the Product Grid engine should draw. 'zymarg' is
         * the branded card from the ZYMARG Template Pack; 'default' hands the
         * choice back to the engine, which uses its own 'classic' card.
         */
        'card_template'        => 'zymarg',
        /*
         * Spacing defaults are NOT listed here. They live in Core\Spacing,
         * which is the single registry the settings screen, the admin JS, the
         * activation seed and the CSS emitter all read from.
         *
         * They cannot simply be inlined into this constant: a class constant
         * cannot call a method, so duplicating them here would recreate
         * exactly the drift this refactor removes. get_all() and get() below
         * merge the registry defaults in at runtime instead.
         */
    ];

    /**
     * Return all current settings, merged with defaults.
     *
     * @since 1.3.0
     * @return array<string, mixed>
     */
    public static function get_all(): array {
        $saved = get_option( self::OPTION_KEY, [] );

        if ( ! is_array( $saved ) ) {
            $saved = [];
        }

        // Registry defaults sit between the two so that a stored value still
        // wins, while a spacing control that has never been saved resolves to
        // its shipped default rather than to null.
        return array_merge( self::DEFAULTS, \ZYMARGHomepage\Core\Spacing::defaults(), $saved );
    }

    /**
     * Return a single setting value.
     *
     * @since 1.3.0
     * @param string $key     Setting key.
     * @param mixed  $default Override fallback (uses class DEFAULTS if null).
     * @return mixed
     */
    public static function get( string $key, mixed $default = null ): mixed {
        $all = self::get_all();

        if ( array_key_exists( $key, $all ) ) {
            return $all[ $key ];
        }

        // An explicit override wins; then this class's own defaults; then the
        // spacing registry. Written out rather than chained with ?? because
        // a legitimately stored 0 or false must not fall through to the next
        // branch, which is what a naive null-coalescing chain would do.
        if ( null !== $default ) {
            return $default;
        }

        if ( array_key_exists( $key, self::DEFAULTS ) ) {
            return self::DEFAULTS[ $key ];
        }

        return \ZYMARGHomepage\Core\Spacing::defaults()[ $key ] ?? null;
    }

    /**
     * Handle the AJAX request to save global settings.
     *
     * Hooked to wp_ajax_zhp_save_settings via Hooks::register().
     * Validates nonce and capabilities, sanitises input, persists.
     *
     * @since 1.3.0
     * @return void
     */
    public function handle_save(): void {
        check_ajax_referer( 'zhp_save_settings', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'zymarg-homepage' ) ], 403 );
        }

        // phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce checked above.
        $raw = isset( $_POST['settings'] ) && is_array( $_POST['settings'] )
            ? wp_unslash( $_POST['settings'] )
            : [];
        // phpcs:enable

        $clean = [
            'master_enabled'       => ! empty( $raw['master_enabled'] ),
            'products_per_section' => isset( $raw['products_per_section'] )
                ? max( 1, min( 50, absint( $raw['products_per_section'] ) ) )
                : self::DEFAULTS['products_per_section'],
            'cache_duration'       => isset( $raw['cache_duration'] )
                ? max( 0, min( 1440, absint( $raw['cache_duration'] ) ) )
                : self::DEFAULTS['cache_duration'],
            'support_email'        => isset( $raw['support_email'] )
                ? sanitize_email( $raw['support_email'] )
                : self::DEFAULTS['support_email'],
            'use_product_grid_cards' => ! empty( $raw['use_product_grid_cards'] ),
            /*
             * Clamped, not just cast. These values are interpolated into a CSS
             * declaration, so the bounds are what guarantee the output is always
             * a sane number — an unbounded absint() would happily accept 99999
             * and produce a heading taller than the screen with no way to see
             * the control that caused it.
             *
             * 0 is preserved as "automatic" and must stay outside the minimum,
             * hence the explicit zero check before clamping.
             */
            'section_title_size'   => self::clamp_px( $raw['section_title_size'] ?? 0, 14, 48 ),
            'explore_link_size'    => self::clamp_px( $raw['explore_link_size'] ?? 0, 10, 24 ),
            'card_template'        => self::clean_card_template( $raw['card_template'] ?? '' ),
        ];

        /*
         * Every spacing control is clamped by the registry rather than by a
         * hand-written line per key here. Each control's own default is used
         * when a key is missing from the payload, so a partial save cannot
         * silently flatten spacing the admin never touched.
         */
        $clean = array_merge( $clean, \ZYMARGHomepage\Core\Spacing::sanitize( $raw ) );

        $updated = update_option( self::OPTION_KEY, $clean );

        wp_send_json_success( [
            'message' => __( 'Settings saved.', 'zymarg-homepage' ),
            'updated' => $updated,
        ] );
    }

    /**
     * Normalise the chosen card template slug.
     *
     * Anything unrecognised falls back to the branded card rather than being
     * passed through, because the slug is handed to another plugin's template
     * registry and an unknown value there resolves to a different design.
     *
     * @since 1.31.0
     * @param mixed $value Raw submitted value.
     * @return string Either 'zymarg' or 'default'.
     */
    private static function clean_card_template( $value ): string {
        $value = sanitize_key( (string) $value );

        return in_array( $value, [ 'zymarg', 'default' ], true ) ? $value : 'zymarg';
    }

    /**
     * Normalise a pixel size setting.
     *
     * Returns 0 for "automatic", otherwise the value clamped into range.
     *
     * @since 1.21.0
     * @param mixed $value Raw submitted value.
     * @param int   $min   Smallest allowed pixel size.
     * @param int   $max   Largest allowed pixel size.
     * @return int Clamped size, or 0 for automatic.
     */
    private static function clamp_px( mixed $value, int $min, int $max ): int {
        $px = absint( $value );

        if ( 0 === $px ) {
            return 0;
        }

        return max( $min, min( $max, $px ) );
    }
}
