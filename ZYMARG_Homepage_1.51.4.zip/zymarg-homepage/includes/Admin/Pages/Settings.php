<?php
/**
 * ZYMARG Homepage – Global Settings Admin Page
 *
 * Renders the Settings page with:
 *   - Master switch (enable/disable all plugin output)
 *   - Default products per section
 *   - Cache duration in minutes
 *   - Text sizes for the section heading and the "Explore More" control
 *
 * Settings are saved via AJAX to keep the UX smooth and match the
 * pattern used by the drag-and-drop section manager.
 *
 * @package ZYMARGHomepage\Admin\Pages
 * @since   1.3.0
 * @version 1.42.0
 */

namespace ZYMARGHomepage\Admin\Pages;

use ZYMARGHomepage\Admin\Settings as SettingsHandler;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Settings
 *
 * Renders the global Settings admin page.
 */
final class Settings {

    /**
     * Render the Settings page.
     *
     * @since 1.3.0
     * @return void
     */
    public function render(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to access this page.', 'zymarg-homepage' ) );
        }

        $s = SettingsHandler::get_all();
        ?>
        <div class="wrap zhp-admin-wrap">

            <div class="zhp-admin-header">
                <div class="zhp-admin-header__inner">
                    <div class="zhp-admin-header__brand">
                        <span class="zhp-admin-header__logo"><svg class="zhp-spark" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="ZYMARG Discovery Spark" focusable="false"><g class="zhp-spark-group--accent"><path class="zhp-spark-item--purple" d="M10.4 5.4c0 1.32-0.24 2.4-1.44 2.4 1.2 0 1.44 1.08 1.44 2.4 0-1.32 0.24-2.4 1.44-2.4-1.2 0-1.44-1.08-1.44-2.4z"/><path class="zhp-spark-item--gold" d="M10.4 6.0c0 0.96-0.18 1.8-1.08 1.8 0.9 0 1.08 0.84 1.08 1.8 0-0.9 0.18-1.8 1.08-1.8-0.9 0-1.08-0.84-1.08-1.8z"/></g><g class="zhp-spark-group--companion"><path class="zhp-spark-item--purple" d="M9.5 10.92c0 2.25-0.45 4.12-2.4 4.12 1.95 0 2.4 1.87 2.4 4.12 0-2.25 0.45-4.12 2.4-4.12-1.95 0-2.4-1.87-2.4-4.12z"/><path class="zhp-spark-item--gold" d="M9.5 11.5c0 1.9-0.38 3.54-2.0 3.54 1.62 0 2.0 1.64 2.0 3.54 0-1.9 0.38-3.54 2.0-3.54-1.62 0-2.0-1.64-2.0-3.54z"/></g><g class="zhp-spark-group--hero"><path class="zhp-spark-item--purple" d="M15.2 5.6c0 3.45-0.69 6.3-4.08 6.3 3.39 0 4.08 2.85 4.08 6.3 0-3.45 0.69-6.3 4.08-6.3-3.39 0-4.08-2.85-4.08-6.3z"/><path class="zhp-spark-item--gold" d="M15.2 6.5c0 2.9-0.58 5.4-3.39 5.4 2.81 0 3.39 2.5 3.39 5.4 0-2.9 0.58-5.4 3.39-5.4-2.81 0-3.39-2.5-3.39-5.4z"/></g></svg></span>
                        <div>
                            <h1 class="zhp-admin-header__title">
                                <?php esc_html_e( 'Settings', 'zymarg-homepage' ); ?>
                            </h1>
                            <p class="zhp-admin-header__version">
                                <?php esc_html_e( 'Global plugin configuration', 'zymarg-homepage' ); ?>
                            </p>
                        </div>
                    </div>
                    <div class="zhp-admin-header__actions">
                        <span class="zhp-admin-header__badge">v<?php echo esc_html( ZYMARG_HP_VERSION ); ?></span>
                        <button type="button" id="zhp-save-settings-btn" class="zhp-admin-btn zhp-admin-btn--primary">
                            <?php esc_html_e( 'Save Settings', 'zymarg-homepage' ); ?>
                        </button>
                    </div>
                </div>
            </div>

            <div class="zhp-admin-content">

                <div class="zhp-notice zhp-notice--info" id="zhp-settings-notice" style="display:none;">
                    <span id="zhp-settings-notice-text"></span>
                </div>

                <div class="zhp-settings-form">

                    <!-- Master switch -->
                    <div class="zhp-settings-group">
                        <h2 class="zhp-settings-group__title">
                            <?php esc_html_e( 'Homepage Output', 'zymarg-homepage' ); ?>
                        </h2>

                        <div class="zhp-settings-row">
                            <div class="zhp-settings-row__info">
                                <label class="zhp-settings-row__label" for="zhp-master-enabled">
                                    <?php esc_html_e( 'Master Switch', 'zymarg-homepage' ); ?>
                                </label>
                                <p class="zhp-settings-row__desc">
                                    <?php esc_html_e( 'When disabled, the [zymarg_homepage] shortcode and zymarg_homepage_render() return empty output. All settings are preserved.', 'zymarg-homepage' ); ?>
                                </p>
                            </div>
                            <div class="zhp-settings-row__control">
                                <label class="zhp-toggle">
                                    <input type="checkbox"
                                           id="zhp-master-enabled"
                                           class="zhp-toggle__input"
                                           name="master_enabled"
                                           value="1"
                                        <?php checked( ! empty( $s['master_enabled'] ) ); ?>>
                                    <span class="zhp-toggle__track">
                                        <span class="zhp-toggle__thumb"></span>
                                    </span>
                                </label>
                                <span class="zhp-settings-row__toggle-label">
                                    <?php echo ! empty( $s['master_enabled'] )
                                        ? esc_html__( 'Enabled', 'zymarg-homepage' )
                                        : esc_html__( 'Disabled', 'zymarg-homepage' ); ?>
                                </span>
                            </div>
                        </div>
                    </div>

                    <!-- Text sizes -->
                    <div class="zhp-settings-group">
                        <h2 class="zhp-settings-group__title">
                            <?php esc_html_e( 'Text Sizes', 'zymarg-homepage' ); ?>
                        </h2>

                        <div class="zhp-settings-row">
                            <div class="zhp-settings-row__info">
                                <label class="zhp-settings-row__label" for="zhp-section-title-size">
                                    <?php esc_html_e( 'Section heading size', 'zymarg-homepage' ); ?>
                                </label>
                                <p class="zhp-settings-row__desc">
                                    <?php esc_html_e( 'Size in pixels of headings like "Trending Products". Set 0 for automatic, which scales the heading with the screen width. Range: 14–48.', 'zymarg-homepage' ); ?>
                                </p>
                            </div>
                            <div class="zhp-settings-row__control">
                                <input type="number"
                                       id="zhp-section-title-size"
                                       name="section_title_size"
                                       class="zhp-settings-number"
                                       value="<?php echo esc_attr( (string) absint( $s['section_title_size'] ?? 0 ) ); ?>"
                                       min="0"
                                       max="48"
                                       step="1">
                            </div>
                        </div>

                        <div class="zhp-settings-row">
                            <div class="zhp-settings-row__info">
                                <label class="zhp-settings-row__label" for="zhp-explore-link-size">
                                    <?php esc_html_e( '"Explore More" size', 'zymarg-homepage' ); ?>
                                </label>
                                <p class="zhp-settings-row__desc">
                                    <?php esc_html_e( 'Size in pixels of the "Explore More" button on the right of each section heading. Set 0 for automatic. Range: 10–24.', 'zymarg-homepage' ); ?>
                                </p>
                            </div>
                            <div class="zhp-settings-row__control">
                                <input type="number"
                                       id="zhp-explore-link-size"
                                       name="explore_link_size"
                                       class="zhp-settings-number"
                                       value="<?php echo esc_attr( (string) absint( $s['explore_link_size'] ?? 0 ) ); ?>"
                                       min="0"
                                       max="24"
                                       step="1">
                            </div>
                        </div>

                        <?php
                        /*
                         * Spacing rows are generated from the Core\Spacing
                         * registry. Adding a control used to mean writing this
                         * markup by hand and restating its bounds and default
                         * here, in the admin JS, in the sanitiser and in the
                         * CSS emitter - four copies free to disagree.
                         *
                         * data-zhp-spacing carries the setting key and
                         * data-zhp-default its shipped value, which is how the
                         * admin JS collects these generically. The default is
                         * read from the markup rather than assumed, because it
                         * is not the same for every control: the scale controls
                         * default to 100 while the gaps default to 0.
                         */
                        $zhp_spacing_labels = \ZYMARGHomepage\Core\Spacing::labels();

                        foreach ( \ZYMARGHomepage\Core\Spacing::CONTROLS as $zhp_control ) :
                            $zhp_key     = (string) $zhp_control['key'];
                            $zhp_id      = 'zhp-' . str_replace( '_', '-', $zhp_key );
                            $zhp_default = (int) $zhp_control['default'];
                            /*
                             * Bounds come from the registry rather than being
                             * restated here. They are no longer the same for
                             * every control: Master Gap and Card Gap run to
                             * 300, the column counts are small integers, and
                             * Side Gap is a pixel figure capped at 60.
                             */
                            list( $zhp_min, $zhp_max, $zhp_step ) = \ZYMARGHomepage\Core\Spacing::bounds( $zhp_control );
                            $zhp_value   = isset( $s[ $zhp_key ] ) && is_numeric( $s[ $zhp_key ] )
                                ? max( $zhp_min, min( $zhp_max, (int) $s[ $zhp_key ] ) )
                                : $zhp_default;
                            $zhp_label   = $zhp_spacing_labels[ $zhp_key ]['label'] ?? $zhp_key;
                            $zhp_desc    = $zhp_spacing_labels[ $zhp_key ]['desc'] ?? '';
                            ?>
                            <div class="zhp-settings-row">
                                <div class="zhp-settings-row__info">
                                    <label class="zhp-settings-row__label" for="<?php echo esc_attr( $zhp_id ); ?>">
                                        <?php echo esc_html( $zhp_label ); ?>
                                    </label>
                                    <p class="zhp-settings-row__desc">
                                        <?php echo esc_html( $zhp_desc ); ?>
                                    </p>
                                </div>
                                <div class="zhp-settings-row__control">
                                    <input type="number"
                                           id="<?php echo esc_attr( $zhp_id ); ?>"
                                           name="<?php echo esc_attr( $zhp_key ); ?>"
                                           class="zhp-settings-number"
                                           data-zhp-spacing="<?php echo esc_attr( $zhp_key ); ?>"
                                           data-zhp-default="<?php echo esc_attr( (string) $zhp_default ); ?>"
                                           value="<?php echo esc_attr( (string) $zhp_value ); ?>"
                                           min="<?php echo esc_attr( (string) $zhp_min ); ?>"
                                           max="<?php echo esc_attr( (string) $zhp_max ); ?>"
                                           step="<?php echo esc_attr( (string) $zhp_step ); ?>">
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- Product card source -->
                    <div class="zhp-settings-group">
                        <h2 class="zhp-settings-group__title">
                            <?php esc_html_e( 'Product Card Design', 'zymarg-homepage' ); ?>
                        </h2>

                        <?php
                        $engine_ready = \ZYMARGHomepage\Integration\ProductGridBridge::is_engine_available();
                        $use_engine   = ! array_key_exists( 'use_product_grid_cards', $s )
                            || ! empty( $s['use_product_grid_cards'] );
                        ?>

                        <div class="zhp-settings-row">
                            <div class="zhp-settings-row__info">
                                <label class="zhp-settings-row__label" for="zhp-use-product-grid-cards">
                                    <?php esc_html_e( 'Use ZYMARG Product Grid cards', 'zymarg-homepage' ); ?>
                                </label>
                                <p class="zhp-settings-row__desc">
                                    <?php esc_html_e( 'When on, product rows are drawn by the ZYMARG WC Product Grid plugin so the homepage matches the rest of your site. When off, the homepage uses its own card design.', 'zymarg-homepage' ); ?>
                                </p>
                                <p class="zhp-settings-row__desc">
                                    <strong><?php esc_html_e( 'Status:', 'zymarg-homepage' ); ?></strong>
                                    <?php
                                    if ( $engine_ready && $use_engine ) {
                                        esc_html_e( 'Product Grid detected and active — its card is being used.', 'zymarg-homepage' );
                                    } elseif ( $engine_ready ) {
                                        esc_html_e( 'Product Grid detected, but this switch is off — the homepage card is being used.', 'zymarg-homepage' );
                                    } else {
                                        esc_html_e( 'Product Grid not detected — the homepage card is being used. This switch takes effect automatically once that plugin is installed and running.', 'zymarg-homepage' );
                                    }
                                    ?>
                                </p>
                            </div>
                            <div class="zhp-settings-row__control">
                                <label class="zhp-toggle">
                                    <input type="checkbox"
                                           id="zhp-use-product-grid-cards"
                                           class="zhp-toggle__input"
                                           name="use_product_grid_cards"
                                           value="1"
                                        <?php checked( $use_engine ); ?>>
                                    <span class="zhp-toggle__track">
                                        <span class="zhp-toggle__thumb"></span>
                                    </span>
                                </label>
                                <span class="zhp-settings-row__toggle-label">
                                    <?php echo $use_engine
                                        ? esc_html__( 'Enabled', 'zymarg-homepage' )
                                        : esc_html__( 'Disabled', 'zymarg-homepage' ); ?>
                                </span>
                            </div>
                        </div>

                        <?php
                        $card_template = isset( $s['card_template'] )
                            ? sanitize_key( (string) $s['card_template'] )
                            : 'zymarg';
                        $pack_ready = \ZYMARGHomepage\Integration\ProductGridBridge::is_template_pack_available();
                        ?>

                        <div class="zhp-settings-row">
                            <div class="zhp-settings-row__info">
                                <label class="zhp-settings-row__label" for="zhp-card-template">
                                    <?php esc_html_e( 'Card design', 'zymarg-homepage' ); ?>
                                </label>
                                <p class="zhp-settings-row__desc">
                                    <?php esc_html_e( 'Which card the Product Grid engine draws. "ZYMARG branded" is the card from the ZYMARG Template Pack, with the discount badge, quick view, wishlist and seller row. "Engine default" uses the plain card built into the Product Grid plugin.', 'zymarg-homepage' ); ?>
                                </p>
                                <?php if ( ! $pack_ready ) : ?>
                                <p class="zhp-settings-row__desc">
                                    <strong><?php esc_html_e( 'Note:', 'zymarg-homepage' ); ?></strong>
                                    <?php esc_html_e( 'The ZYMARG Template Pack was not detected. Until it is active the engine falls back to its own card whatever is chosen here.', 'zymarg-homepage' ); ?>
                                </p>
                                <?php endif; ?>
                            </div>
                            <div class="zhp-settings-row__control">
                                <select id="zhp-card-template" name="card_template" class="zhp-design-source">
                                    <option value="zymarg"<?php selected( $card_template, 'zymarg' ); ?>>
                                        <?php esc_html_e( 'ZYMARG branded card', 'zymarg-homepage' ); ?>
                                    </option>
                                    <option value="default"<?php selected( $card_template, 'default' ); ?>>
                                        <?php esc_html_e( 'Engine default card', 'zymarg-homepage' ); ?>
                                    </option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <!-- Products per section -->
                    <div class="zhp-settings-group">
                        <h2 class="zhp-settings-group__title">
                            <?php esc_html_e( 'Product Sections', 'zymarg-homepage' ); ?>
                        </h2>

                        <div class="zhp-settings-row">
                            <div class="zhp-settings-row__info">
                                <label class="zhp-settings-row__label" for="zhp-products-per-section">
                                    <?php esc_html_e( 'Products Per Section', 'zymarg-homepage' ); ?>
                                </label>
                                <p class="zhp-settings-row__desc">
                                    <?php esc_html_e( 'Default number of products shown in each product section (Featured, Trending, etc.). Individual sections can override this in their own settings. Range: 1–50.', 'zymarg-homepage' ); ?>
                                </p>
                            </div>
                            <div class="zhp-settings-row__control">
                                <input type="number"
                                       id="zhp-products-per-section"
                                       name="products_per_section"
                                       class="zhp-settings-number"
                                       value="<?php echo esc_attr( (string) absint( $s['products_per_section'] ) ); ?>"
                                       min="1"
                                       max="50"
                                       step="1">
                            </div>
                        </div>
                    </div>

                    <!-- Cache duration -->
                    <div class="zhp-settings-group">
                        <h2 class="zhp-settings-group__title">
                            <?php esc_html_e( 'Performance', 'zymarg-homepage' ); ?>
                        </h2>

                        <div class="zhp-settings-row">
                            <div class="zhp-settings-row__info">
                                <label class="zhp-settings-row__label" for="zhp-cache-duration">
                                    <?php esc_html_e( 'Cache Duration (minutes)', 'zymarg-homepage' ); ?>
                                </label>
                                <p class="zhp-settings-row__desc">
                                    <?php esc_html_e( 'How long product and category query results are cached using WordPress transients. Set to 0 to disable caching. Range: 0–1440 minutes (24 hours).', 'zymarg-homepage' ); ?>
                                </p>
                            </div>
                            <div class="zhp-settings-row__control">
                                <input type="number"
                                       id="zhp-cache-duration"
                                       name="cache_duration"
                                       class="zhp-settings-number"
                                       value="<?php echo esc_attr( (string) absint( $s['cache_duration'] ) ); ?>"
                                       min="0"
                                       max="1440"
                                       step="1">
                            </div>
                        </div>

                        <div class="zhp-settings-row">
                            <div class="zhp-settings-row__info">
                                <label class="zhp-settings-row__label" for="zhp-support-email">
                                    <?php esc_html_e( 'Support Email', 'zymarg-homepage' ); ?>
                                </label>
                                <p class="zhp-settings-row__desc">
                                    <?php esc_html_e( 'Contact address shown at the bottom of the Help page. Leave blank to hide the support contact entirely.', 'zymarg-homepage' ); ?>
                                </p>
                            </div>
                            <div class="zhp-settings-row__control">
                                <input type="email"
                                       id="zhp-support-email"
                                       name="support_email"
                                       class="zhp-settings-text"
                                       value="<?php echo esc_attr( $s['support_email'] ?? '' ); ?>"
                                       placeholder="e.g. engineering@yourcompany.com">
                            </div>
                        </div>
                    </div>

                </div><!-- .zhp-settings-form -->

            </div><!-- .zhp-admin-content -->
        </div><!-- .wrap.zhp-admin-wrap -->
        <?php
    }
}
