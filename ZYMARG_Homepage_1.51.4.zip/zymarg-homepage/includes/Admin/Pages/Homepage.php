<?php
/**
 * ZYMARG Homepage – Homepage Section Manager Admin Page
 *
 * Renders the drag-and-drop section manager. This page gives the site owner
 * complete control over all homepage sections:
 *
 *   Level 1 – Toggle (show / hide each section)
 *   Level 2 – Order (drag rows to reorder)
 *   Level 3 – Per-section settings (expandable panel per section)
 *
 * Sections defined in CONTRIBUTING.md §4:
 *   hero, categories, featured-products, trending-products, best-sellers,
 *   flash-deals, new-arrivals, recommended,
 *   featured-sellers, promo-banner, collections, brands, newsletter, footer-cta
 *
 * Sections are loaded from SectionManager (which reads the saved option).
 * When no sections are saved yet, the full default list is shown so the
 * admin panel is immediately useful even before Phase 5 features exist.
 *
 * Changes in 1.19.1:
 *   • Each row gained a Move up / Move down button pair. jQuery UI Sortable
 *     is mouse-only and WordPress bundles no touch shim for it, so dragging
 *     has never worked on a phone or tablet. The buttons are the accessible
 *     and touch-capable path to the same result, and they also give keyboard
 *     users a way to reorder that dragging never provided.
 *
 * @package ZYMARGHomepage\Admin\Pages
 * @since   1.3.0
 * @version 1.46.1
 */

namespace ZYMARGHomepage\Admin\Pages;

use ZYMARGHomepage\Homepage\SectionManager;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Homepage
 *
 * Renders the Homepage section drag-and-drop manager.
 */
final class Homepage {

    /**
     * Section manager — reads and writes section config.
     *
     * @since 1.3.0
     * @var SectionManager
     */
    private SectionManager $section_manager;

    /**
     * Human-readable labels for every known section slug.
     *
     * Used when a feature class is not yet registered (Phases 3–4).
     *
     * @since 1.3.0
     * @var array<string, string>
     */
    private const SLUG_LABELS = [
        'hero'               => 'Hero Banner',
        'categories'         => 'Category Showcase',
        'featured-products'  => 'Featured Products',
        'trending-products'  => 'Trending Products',
        'best-sellers'       => 'Best Sellers',
        'flash-deals'        => 'Flash Deals',
        'new-arrivals'       => 'New Arrivals',
        'recommended'        => 'Recommended For You',
        'dynamic-picks'      => 'Just For You',
        'featured-sellers'   => 'Featured Sellers',
        'promo-banner'       => 'Promo Banner',
        'collections'        => 'Collections',
        'brands'             => 'Brands',
        'newsletter'         => 'Newsletter Sign-up',
        'footer-cta'         => 'Footer Call-to-Action',
    ];

    /**
     * Default section list used when the option is empty.
     *
     * Mirrors the full slug list from CONTRIBUTING.md §4.
     *
     * @since 1.3.0
     * @var string[]
     */
    private const DEFAULT_SLUGS = [
        'hero',
        'categories',
        'featured-products',
        'trending-products',
        'best-sellers',
        'flash-deals',
        'new-arrivals',
        'recommended',
        'dynamic-picks',
        'featured-sellers',
        'promo-banner',
        'collections',
        'brands',
        'newsletter',
        'footer-cta',
    ];

    /**
     * Constructor.
     *
     * @since 1.3.0
     * @param SectionManager $section_manager Injected section manager.
     */
    public function __construct( SectionManager $section_manager ) {
        $this->section_manager = $section_manager;
    }

    /**
     * Render the Homepage section manager page.
     *
     * @since 1.3.0
     * @return void
     */
    public function render(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to access this page.', 'zymarg-homepage' ) );
        }

        $sections = $this->get_sections_for_display();
        ?>
        <div class="wrap zhp-admin-wrap">

            <div class="zhp-admin-header">
                <div class="zhp-admin-header__inner">
                    <div class="zhp-admin-header__brand">
                        <span class="zhp-admin-header__logo"><svg class="zhp-spark" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="ZYMARG Discovery Spark" focusable="false"><g class="zhp-spark-group--accent"><path class="zhp-spark-item--purple" d="M10.4 5.4c0 1.32-0.24 2.4-1.44 2.4 1.2 0 1.44 1.08 1.44 2.4 0-1.32 0.24-2.4 1.44-2.4-1.2 0-1.44-1.08-1.44-2.4z"/><path class="zhp-spark-item--gold" d="M10.4 6.0c0 0.96-0.18 1.8-1.08 1.8 0.9 0 1.08 0.84 1.08 1.8 0-0.9 0.18-1.8 1.08-1.8-0.9 0-1.08-0.84-1.08-1.8z"/></g><g class="zhp-spark-group--companion"><path class="zhp-spark-item--purple" d="M9.5 10.92c0 2.25-0.45 4.12-2.4 4.12 1.95 0 2.4 1.87 2.4 4.12 0-2.25 0.45-4.12 2.4-4.12-1.95 0-2.4-1.87-2.4-4.12z"/><path class="zhp-spark-item--gold" d="M9.5 11.5c0 1.9-0.38 3.54-2.0 3.54 1.62 0 2.0 1.64 2.0 3.54 0-1.9 0.38-3.54 2.0-3.54-1.62 0-2.0-1.64-2.0-3.54z"/></g><g class="zhp-spark-group--hero"><path class="zhp-spark-item--purple" d="M15.2 5.6c0 3.45-0.69 6.3-4.08 6.3 3.39 0 4.08 2.85 4.08 6.3 0-3.45 0.69-6.3 4.08-6.3-3.39 0-4.08-2.85-4.08-6.3z"/><path class="zhp-spark-item--gold" d="M15.2 6.5c0 2.9-0.58 5.4-3.39 5.4 2.81 0 3.39 2.5 3.39 5.4 0-2.9 0.58-5.4 3.39-5.4-2.81 0-3.39-2.5-3.39-5.4z"/></g></svg></span>
                        <div>
                            <div class="zhp-admin-header__titlerow">
                                <h1 class="zhp-admin-header__title">
                                    <?php esc_html_e( 'Homepage Sections', 'zymarg-homepage' ); ?>
                                </h1>
                                <span class="zhp-admin-header__badge">v<?php echo esc_html( ZYMARG_HP_VERSION ); ?></span>
                            </div>
                            <p class="zhp-admin-header__version">
                                <?php esc_html_e( 'Drag or use ↑ ↓ to reorder · Toggle to show/hide · Click ▸ to configure', 'zymarg-homepage' ); ?>
                            </p>
                        </div>
                    </div>
                    <div class="zhp-admin-header__actions">
                        <button type="button" id="zhp-reset-sections" class="zhp-admin-btn zhp-admin-btn--ghost">
                            <?php esc_html_e( 'Reset to Defaults', 'zymarg-homepage' ); ?>
                        </button>
                        <button type="button" id="zhp-save-sections" class="zhp-admin-btn zhp-admin-btn--primary">
                            <?php esc_html_e( 'Save Changes', 'zymarg-homepage' ); ?>
                        </button>
                    </div>
                </div>
            </div>

            <div class="zhp-admin-content">

                <div class="zhp-notice zhp-notice--info" id="zhp-save-notice" style="display:none;">
                    <span id="zhp-save-notice-text"></span>
                </div>

                <div class="zhp-sections-panel">
                    <div class="zhp-sections-panel__header">
                        <span class="zhp-sections-panel__col zhp-sections-panel__col--drag"></span>
                        <span class="zhp-sections-panel__col zhp-sections-panel__col--toggle">
                            <?php esc_html_e( 'Visible', 'zymarg-homepage' ); ?>
                        </span>
                        <span class="zhp-sections-panel__col zhp-sections-panel__col--label">
                            <?php esc_html_e( 'Section', 'zymarg-homepage' ); ?>
                        </span>
                        <span class="zhp-sections-panel__col zhp-sections-panel__col--move">
                            <?php esc_html_e( 'Move', 'zymarg-homepage' ); ?>
                        </span>
                        <span class="zhp-sections-panel__col zhp-sections-panel__col--expand"></span>
                    </div>

                    <ul id="zhp-section-list" class="zhp-section-list">
                        <?php foreach ( $sections as $index => $section ) : ?>
                            <?php $this->render_section_row( $section, $index ); ?>
                        <?php endforeach; ?>
                    </ul>
                </div>

                <div class="zhp-admin-tip">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                        <circle cx="8" cy="8" r="7" stroke="currentColor" stroke-width="1.5"/>
                        <path d="M8 7v4M8 5v.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                    </svg>
                    <?php esc_html_e( 'Sections marked as not visible are hidden from the homepage but their settings are preserved. Toggle them back on at any time. Dragging needs a mouse — on a touch device, use the ↑ and ↓ buttons to reorder.', 'zymarg-homepage' ); ?>
                </div>

            </div>
        </div>
        <?php
    }

    // ──────────────────────────────────────────────────────────────
    //  Private helpers
    // ──────────────────────────────────────────────────────────────

    /**
     * Return the section list to display.
     *
     * Uses SectionManager for saved sections. If none are saved yet,
     * falls back to the full default slug list so the admin page is
     * immediately useful in Phase 3 before any features exist.
     *
     * @since 1.3.0
     * @return array<int, array{ slug: string, enabled: bool, order: int, settings: array }>
     */
    private function get_sections_for_display(): array {
        $saved = $this->section_manager->get_all_sections();

        if ( ! empty( $saved ) ) {
            return $saved;
        }

        // Build the default list from the canonical slug list.
        $defaults = [];
        foreach ( self::DEFAULT_SLUGS as $i => $slug ) {
            $defaults[] = [
                'slug'     => $slug,
                'enabled'  => true,
                'order'    => $i + 1,
                'settings' => [],
            ];
        }

        return $defaults;
    }

    /**
     * Render a single draggable section row.
     *
     * @since 1.3.0
     * @param array $section Section data row.
     * @param int   $index   Zero-based position index.
     * @return void
     */
    private function render_section_row( array $section, int $index ): void {
        $slug    = sanitize_key( $section['slug'] ?? '' );
        $enabled = ! empty( $section['enabled'] );
        $order   = absint( $section['order'] ?? ( $index + 1 ) );
        /*
         * Label resolution order (1.46.1): this hardcoded map first, so every
         * existing label is unchanged, then the feature's own get_label(), and
         * only then a slug prettified as a last resort. The registry step is
         * what stops a future section from showing up as a mangled slug purely
         * because nobody remembered to edit the const above.
         */
        $zhp_feature = \ZYMARGHomepage\Homepage\FeatureRegistry::get( $slug );
        $label       = self::SLUG_LABELS[ $slug ]
            ?? ( null !== $zhp_feature ? $zhp_feature->get_label() : ucwords( str_replace( '-', ' ', $slug ) ) );
        $label       = esc_html( $label );
        $row_id  = 'zhp-section-' . esc_attr( $slug );
        ?>
        <li class="zhp-section-row<?php echo $enabled ? '' : ' zhp-section-row--disabled'; ?>"
            id="<?php echo esc_attr( $row_id ); ?>"
            data-slug="<?php echo esc_attr( $slug ); ?>"
            data-order="<?php echo esc_attr( (string) $order ); ?>">

            <!-- Drag handle -->
            <span class="zhp-section-row__drag" title="<?php esc_attr_e( 'Drag to reorder', 'zymarg-homepage' ); ?>">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                    <circle cx="5.5" cy="4" r="1.25" fill="currentColor"/>
                    <circle cx="5.5" cy="8" r="1.25" fill="currentColor"/>
                    <circle cx="5.5" cy="12" r="1.25" fill="currentColor"/>
                    <circle cx="10.5" cy="4" r="1.25" fill="currentColor"/>
                    <circle cx="10.5" cy="8" r="1.25" fill="currentColor"/>
                    <circle cx="10.5" cy="12" r="1.25" fill="currentColor"/>
                </svg>
            </span>

            <!-- Toggle switch -->
            <span class="zhp-section-row__toggle">
                <label class="zhp-toggle" title="<?php echo $enabled ? esc_attr__( 'Visible — click to hide', 'zymarg-homepage' ) : esc_attr__( 'Hidden — click to show', 'zymarg-homepage' ); ?>">
                    <input type="checkbox"
                           class="zhp-toggle__input zhp-section-enabled"
                           name="zhp_enabled[<?php echo esc_attr( $slug ); ?>]"
                           value="1"
                        <?php checked( $enabled ); ?>>
                    <span class="zhp-toggle__track">
                        <span class="zhp-toggle__thumb"></span>
                    </span>
                </label>
            </span>

            <!-- Section label and slug badge -->
            <span class="zhp-section-row__label">
                <strong><?php echo esc_html( $label ); ?></strong>
                <code class="zhp-section-row__slug"><?php echo esc_html( $slug ); ?></code>
            </span>

            <!--
                Move up / Move down.

                The drag handle above is driven by jQuery UI Sortable, which
                binds mouse events only, so it is inert on touch devices.
                These buttons are the touch and keyboard path to the same
                reorder, and they are the only path a screen reader user has.
                Disabled state at the ends of the list is applied by
                zymarg-drag-drop.js, not here, because it has to be
                recalculated after every move and after every AJAX swap.
            -->
            <span class="zhp-section-row__move">
                <button type="button"
                        class="zhp-move-btn zhp-move-btn--up"
                        data-zhp-move="up"
                        aria-label="<?php echo esc_attr( sprintf( /* translators: %s section label */ __( 'Move %s up', 'zymarg-homepage' ), $label ) ); ?>"
                        title="<?php esc_attr_e( 'Move up', 'zymarg-homepage' ); ?>">
                    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" aria-hidden="true" focusable="false">
                        <path d="M4 10l4-4 4 4" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </button>
                <button type="button"
                        class="zhp-move-btn zhp-move-btn--down"
                        data-zhp-move="down"
                        aria-label="<?php echo esc_attr( sprintf( /* translators: %s section label */ __( 'Move %s down', 'zymarg-homepage' ), $label ) ); ?>"
                        title="<?php esc_attr_e( 'Move down', 'zymarg-homepage' ); ?>">
                    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" aria-hidden="true" focusable="false">
                        <path d="M4 6l4 4 4-4" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </button>
            </span>

            <!-- Expand button -->
            <button type="button"
                    class="zhp-section-row__expand zhp-expand-btn"
                    aria-expanded="false"
                    aria-controls="zhp-settings-<?php echo esc_attr( $slug ); ?>"
                    title="<?php esc_attr_e( 'Section settings', 'zymarg-homepage' ); ?>">
                <svg class="zhp-expand-btn__icon" width="16" height="16" viewBox="0 0 16 16" fill="none">
                    <path d="M4 6l4 4 4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </button>

            <!-- Per-section settings panel (initially hidden) -->
            <div class="zhp-section-settings"
                 id="zhp-settings-<?php echo esc_attr( $slug ); ?>"
                 hidden>
                <?php $this->render_section_settings( $slug, $section['settings'] ?? [] ); ?>
            </div>

        </li>
        <?php
    }

    /**
     * Render the expandable settings panel for a section.
     *
     * In Phase 3 most sections have no Feature class registered, so this
     * renders a generic placeholder. Phase 5 will hook into each Feature's
     * Settings.php to render real fields.
     *
     * @since 1.3.0
     * @param string $slug     Section slug.
     * @param array  $settings Current saved settings for this section.
     * @return void
     */
    private function render_section_settings( string $slug, array $settings ): void {
        ?>
        <div class="zhp-section-settings__inner">
            <?php
            // Check if a Feature class is registered for this slug.
            $feature = \ZYMARGHomepage\Homepage\FeatureRegistry::get( $slug );

            if ( null !== $feature && method_exists( $feature, 'render_settings_fields' ) ) {
                // Phase 5+: delegate to the feature's own settings renderer.
                $feature->render_settings_fields( $settings );
            } else {
                // Phase 3 placeholder — shows available settings once the
                // feature is built in Phase 5.
                ?>
                <p class="zhp-section-settings__placeholder">
                    <?php
                    echo esc_html(
                        sprintf(
                            /* translators: %s section label */
                            __( 'Settings for "%s" will appear here once the section is fully built.', 'zymarg-homepage' ),
                            self::SLUG_LABELS[ $slug ] ?? $slug
                        )
                    );
                    ?>
                </p>
                <?php
            }
            ?>
        </div>
        <?php
    }
}
