<?php
/**
 * ZYMARG Homepage – Dashboard Admin Page
 *
 * Renders the Dashboard overview page. Shows plugin version, quick-access
 * links to the Homepage and Settings pages, and a summary of active sections.
 *
 * @package ZYMARGHomepage\Admin\Pages
 * @since   1.3.0
 * @version 1.31.1
 */

namespace ZYMARGHomepage\Admin\Pages;

use ZYMARGHomepage\Admin\Menu;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Dashboard
 *
 * Renders the Dashboard admin page.
 */
final class Dashboard {

    /**
     * Render the Dashboard page.
     *
     * Called by WordPress when the admin user visits the top-level
     * "ZYMARG Homepage" menu item or the "Dashboard" sub-menu item.
     *
     * @since 1.3.0
     * @return void
     */
    public function render(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to access this page.', 'zymarg-homepage' ) );
        }
        ?>
        <div class="wrap zhp-admin-wrap">

            <div class="zhp-admin-header">
                <div class="zhp-admin-header__inner">
                    <div class="zhp-admin-header__brand">
                        <span class="zhp-admin-header__logo"><svg class="zhp-spark" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="ZYMARG Discovery Spark" focusable="false"><g class="zhp-spark-group--accent"><path class="zhp-spark-item--purple" d="M10.4 5.4c0 1.32-0.24 2.4-1.44 2.4 1.2 0 1.44 1.08 1.44 2.4 0-1.32 0.24-2.4 1.44-2.4-1.2 0-1.44-1.08-1.44-2.4z"/><path class="zhp-spark-item--gold" d="M10.4 6.0c0 0.96-0.18 1.8-1.08 1.8 0.9 0 1.08 0.84 1.08 1.8 0-0.9 0.18-1.8 1.08-1.8-0.9 0-1.08-0.84-1.08-1.8z"/></g><g class="zhp-spark-group--companion"><path class="zhp-spark-item--purple" d="M9.5 10.92c0 2.25-0.45 4.12-2.4 4.12 1.95 0 2.4 1.87 2.4 4.12 0-2.25 0.45-4.12 2.4-4.12-1.95 0-2.4-1.87-2.4-4.12z"/><path class="zhp-spark-item--gold" d="M9.5 11.5c0 1.9-0.38 3.54-2.0 3.54 1.62 0 2.0 1.64 2.0 3.54 0-1.9 0.38-3.54 2.0-3.54-1.62 0-2.0-1.64-2.0-3.54z"/></g><g class="zhp-spark-group--hero"><path class="zhp-spark-item--purple" d="M15.2 5.6c0 3.45-0.69 6.3-4.08 6.3 3.39 0 4.08 2.85 4.08 6.3 0-3.45 0.69-6.3 4.08-6.3-3.39 0-4.08-2.85-4.08-6.3z"/><path class="zhp-spark-item--gold" d="M15.2 6.5c0 2.9-0.58 5.4-3.39 5.4 2.81 0 3.39 2.5 3.39 5.4 0-2.9 0.58-5.4 3.39-5.4-2.81 0-3.39-2.5-3.39-5.4z"/></g></svg></span>
                        <div>
                            <div class="zhp-admin-header__titlerow">
                                <h1 class="zhp-admin-header__title">
                                    <?php esc_html_e( 'ZYMARG Homepage', 'zymarg-homepage' ); ?>
                                </h1>
                                <span class="zhp-admin-header__badge">v<?php echo esc_html( ZYMARG_HP_VERSION ); ?></span>
                            </div>
                            <p class="zhp-admin-header__version">
                                <?php esc_html_e( 'Overview, quick links and live status', 'zymarg-homepage' ); ?>
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="zhp-admin-content">

                <div class="zhp-admin-cards">

                    <!-- Quick links card -->
                    <div class="zhp-admin-card">
                        <div class="zhp-admin-card__icon zhp-admin-card__icon--purple">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect x="3" y="3" width="8" height="5" rx="1.5" fill="currentColor"/>
                                <rect x="13" y="3" width="8" height="5" rx="1.5" fill="currentColor" opacity=".5"/>
                                <rect x="3" y="10" width="8" height="11" rx="1.5" fill="currentColor" opacity=".5"/>
                                <rect x="13" y="10" width="8" height="11" rx="1.5" fill="currentColor"/>
                            </svg>
                        </div>
                        <h2 class="zhp-admin-card__title">
                            <?php esc_html_e( 'Homepage Sections', 'zymarg-homepage' ); ?>
                        </h2>
                        <p class="zhp-admin-card__desc">
                            <?php esc_html_e( 'Toggle, reorder, and configure each section of the homepage using the visual drag-and-drop manager.', 'zymarg-homepage' ); ?>
                        </p>
                        <a href="<?php echo esc_url( admin_url( 'admin.php?page=zymarg-homepage-sections' ) ); ?>"
                           class="zhp-admin-btn zhp-admin-btn--primary">
                            <?php esc_html_e( 'Manage Sections →', 'zymarg-homepage' ); ?>
                        </a>
                    </div>

                    <!-- Settings card -->
                    <div class="zhp-admin-card">
                        <div class="zhp-admin-card__icon zhp-admin-card__icon--accent">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z" fill="currentColor"/>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M9.27 2.76a2 2 0 0 1 5.46 0l.52 1.56a7.1 7.1 0 0 1 1.44.83l1.61-.42a2 2 0 0 1 2.36 1.57l.43 2.11a2 2 0 0 1-.96 2.14l-1.4.8c.02.25.02.5 0 .75l1.4.8a2 2 0 0 1 .96 2.14l-.43 2.11a2 2 0 0 1-2.36 1.57l-1.61-.42a7.1 7.1 0 0 1-1.44.83l-.52 1.56a2 2 0 0 1-5.46 0l-.52-1.56a7.1 7.1 0 0 1-1.44-.83l-1.61.42a2 2 0 0 1-2.36-1.57l-.43-2.11a2 2 0 0 1 .96-2.14l1.4-.8a7.1 7.1 0 0 1 0-.75l-1.4-.8A2 2 0 0 1 3.41 8.3l.43-2.11A2 2 0 0 1 6.2 4.62l1.61.42a7.1 7.1 0 0 1 1.44-.83l.52-1.56z" fill="currentColor" opacity=".3"/>
                            </svg>
                        </div>
                        <h2 class="zhp-admin-card__title">
                            <?php esc_html_e( 'Global Settings', 'zymarg-homepage' ); ?>
                        </h2>
                        <p class="zhp-admin-card__desc">
                            <?php esc_html_e( 'Control the master switch, default product counts, cache duration, and other global plugin options.', 'zymarg-homepage' ); ?>
                        </p>
                        <a href="<?php echo esc_url( admin_url( 'admin.php?page=zymarg-homepage-settings' ) ); ?>"
                           class="zhp-admin-btn zhp-admin-btn--secondary">
                            <?php esc_html_e( 'Open Settings →', 'zymarg-homepage' ); ?>
                        </a>
                    </div>

                </div>

                <!-- Static items — always known -->
                <div class="zhp-admin-status">
                    <div class="zhp-admin-status__item">
                        <span class="zhp-admin-status__label">
                            <?php esc_html_e( 'Version', 'zymarg-homepage' ); ?>
                        </span>
                        <span class="zhp-admin-status__value">
                            <?php echo esc_html( ZYMARG_HP_VERSION ); ?>
                        </span>
                    </div>
                    <div class="zhp-admin-status__item">
                        <span class="zhp-admin-status__label">
                            <?php esc_html_e( 'Shortcode', 'zymarg-homepage' ); ?>
                        </span>
                        <code class="zhp-admin-status__code">[zymarg_homepage]</code>
                    </div>
                    <div class="zhp-admin-status__item">
                        <span class="zhp-admin-status__label">
                            <?php esc_html_e( 'PHP Function', 'zymarg-homepage' ); ?>
                        </span>
                        <code class="zhp-admin-status__code">zymarg_homepage_render()</code>
                    </div>
                </div>

                <!-- Live status bar — populated via AJAX on page load -->
                <div class="zhp-admin-status zhp-admin-status--live" id="zhp-dashboard-status" aria-live="polite">
                    <div class="zhp-admin-status__item">
                        <span class="zhp-admin-status__label">
                            <?php esc_html_e( 'Master Switch', 'zymarg-homepage' ); ?>
                        </span>
                        <span class="zhp-admin-status__value zhp-status--loading" id="zhp-ds-master">—</span>
                    </div>
                    <div class="zhp-admin-status__item">
                        <span class="zhp-admin-status__label">
                            <?php esc_html_e( 'Sections Active', 'zymarg-homepage' ); ?>
                        </span>
                        <span class="zhp-admin-status__value zhp-status--loading" id="zhp-ds-sections">—</span>
                    </div>
                    <div class="zhp-admin-status__item">
                        <span class="zhp-admin-status__label">
                            <?php esc_html_e( 'Front Page', 'zymarg-homepage' ); ?>
                        </span>
                        <span class="zhp-admin-status__value zhp-status--loading" id="zhp-ds-frontpage">—</span>
                    </div>
                    <div class="zhp-admin-status__item">
                        <span class="zhp-admin-status__label">
                            <?php esc_html_e( 'Shortcode on Page', 'zymarg-homepage' ); ?>
                        </span>
                        <span class="zhp-admin-status__value zhp-status--loading" id="zhp-ds-shortcode">—</span>
                    </div>
                    <div class="zhp-admin-status__item">
                        <span class="zhp-admin-status__label">
                            <?php esc_html_e( 'WooCommerce', 'zymarg-homepage' ); ?>
                        </span>
                        <span class="zhp-admin-status__value zhp-status--loading" id="zhp-ds-woo">—</span>
                    </div>
                    <div class="zhp-admin-status__item">
                        <span class="zhp-admin-status__label">
                            <?php esc_html_e( 'Dokan', 'zymarg-homepage' ); ?>
                        </span>
                        <span class="zhp-admin-status__value zhp-status--loading" id="zhp-ds-dokan">—</span>
                    </div>
                    <div class="zhp-admin-status__item">
                        <span class="zhp-admin-status__label">
                            <?php esc_html_e( 'Product Grid Engine', 'zymarg-homepage' ); ?>
                        </span>
                        <span class="zhp-admin-status__value zhp-status--loading" id="zhp-ds-engine">—</span>
                    </div>
                    <div class="zhp-admin-status__item">
                        <span class="zhp-admin-status__label">
                            <?php esc_html_e( 'ZYMARG Template Pack', 'zymarg-homepage' ); ?>
                        </span>
                        <span class="zhp-admin-status__value zhp-status--loading" id="zhp-ds-pack">—</span>
                    </div>
                    <div class="zhp-admin-status__item">
                        <span class="zhp-admin-status__label">
                            <?php esc_html_e( 'Flash Deals Source', 'zymarg-homepage' ); ?>
                        </span>
                        <span class="zhp-admin-status__value zhp-status--loading" id="zhp-ds-flash">—</span>
                    </div>
                </div>

            </div><!-- .zhp-admin-content -->
        </div><!-- .wrap.zhp-admin-wrap -->
        <?php
    }
}
