<?php
/**
 * ZYMARG Homepage – Help Admin Page
 *
 * Renders the Help & Documentation page covering:
 *   1. Initial setup — the three steps required to display the homepage.
 *   2. Section reference — all 15 sections and their slugs.
 *   3. Shortcode and PHP function usage.
 *   4. Theme integration notes.
 *   5. Design token overrides.
 *   6. Developer hooks (filters and actions).
 *   7. AJAX and REST endpoint reference.
 *   8. Troubleshooting checklist.
 *
 * This page is intentionally static — no AJAX, no form. It is pure
 * documentation rendered server-side so it is always accurate and
 * never out of sync with the installed version.
 *
 * @package ZYMARGHomepage\Admin\Pages
 * @since   1.7.0
 * @version 1.42.0
 */

namespace ZYMARGHomepage\Admin\Pages;

use ZYMARGHomepage\Admin\Menu;
use ZYMARGHomepage\Admin\Settings;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Help
 *
 * Renders the Help & Documentation admin page.
 */
final class Help {

    /**
     * Render the Help page.
     *
     * Called by WordPress when the admin user visits ZYMARG Homepage → Help.
     *
     * @since 1.7.0
     * @return void
     */
    public function render(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to access this page.', 'zymarg-homepage' ) );
        }
        ?>
        <div class="wrap zhp-admin-wrap">

            <!-- ── Page header ──────────────────────────────────── -->
            <div class="zhp-admin-header">
                <div class="zhp-admin-header__inner">
                    <div class="zhp-admin-header__brand">
                        <span class="zhp-admin-header__logo"><svg class="zhp-spark" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="ZYMARG Discovery Spark" focusable="false"><g class="zhp-spark-group--accent"><path class="zhp-spark-item--purple" d="M10.4 5.4c0 1.32-0.24 2.4-1.44 2.4 1.2 0 1.44 1.08 1.44 2.4 0-1.32 0.24-2.4 1.44-2.4-1.2 0-1.44-1.08-1.44-2.4z"/><path class="zhp-spark-item--gold" d="M10.4 6.0c0 0.96-0.18 1.8-1.08 1.8 0.9 0 1.08 0.84 1.08 1.8 0-0.9 0.18-1.8 1.08-1.8-0.9 0-1.08-0.84-1.08-1.8z"/></g><g class="zhp-spark-group--companion"><path class="zhp-spark-item--purple" d="M9.5 10.92c0 2.25-0.45 4.12-2.4 4.12 1.95 0 2.4 1.87 2.4 4.12 0-2.25 0.45-4.12 2.4-4.12-1.95 0-2.4-1.87-2.4-4.12z"/><path class="zhp-spark-item--gold" d="M9.5 11.5c0 1.9-0.38 3.54-2.0 3.54 1.62 0 2.0 1.64 2.0 3.54 0-1.9 0.38-3.54 2.0-3.54-1.62 0-2.0-1.64-2.0-3.54z"/></g><g class="zhp-spark-group--hero"><path class="zhp-spark-item--purple" d="M15.2 5.6c0 3.45-0.69 6.3-4.08 6.3 3.39 0 4.08 2.85 4.08 6.3 0-3.45 0.69-6.3 4.08-6.3-3.39 0-4.08-2.85-4.08-6.3z"/><path class="zhp-spark-item--gold" d="M15.2 6.5c0 2.9-0.58 5.4-3.39 5.4 2.81 0 3.39 2.5 3.39 5.4 0-2.9 0.58-5.4 3.39-5.4-2.81 0-3.39-2.5-3.39-5.4z"/></g></svg></span>
                        <div>
                            <h1 class="zhp-admin-header__title">
                                <?php esc_html_e( 'Help & Documentation', 'zymarg-homepage' ); ?>
                            </h1>
                            <p class="zhp-admin-header__version">
                                <?php esc_html_e( 'Setup guides, shortcodes and troubleshooting', 'zymarg-homepage' ); ?>
                            </p>
                        </div>
                    </div>
                                    <div class="zhp-admin-header__actions">
                        <span class="zhp-admin-header__badge">v<?php echo esc_html( ZYMARG_HP_VERSION ); ?></span>
                    </div>
</div>
            </div>

            <div class="zhp-admin-content">

                <!-- ═══════════════════════════════════════════════
                     1. INITIAL SETUP
                ═══════════════════════════════════════════════ -->
                <div class="zhp-settings-group">

                    <h2 class="zhp-settings-group__title">
                        <?php esc_html_e( 'Initial Setup', 'zymarg-homepage' ); ?>
                    </h2>

                    <p class="zhp-help-intro">
                        <?php esc_html_e( 'From version 1.7.2 the plugin configures itself automatically on activation. No manual page creation or Settings → Reading changes are needed.', 'zymarg-homepage' ); ?>
                    </p>

                    <!-- Step 1 — Auto (done on activation) -->
                    <div class="zhp-settings-row">
                        <div class="zhp-settings-row__info">
                            <p class="zhp-settings-row__label">
                                <?php esc_html_e( 'Step 1 — Front page (automatic)', 'zymarg-homepage' ); ?>
                            </p>
                            <p class="zhp-settings-row__desc">
                                <?php esc_html_e( 'On activation the plugin checks for a front page in this order:', 'zymarg-homepage' ); ?>
                            </p>
                            <ul class="zhp-help-list">
                                <li class="zhp-settings-row__desc"><?php esc_html_e( 'If WordPress already has a static front page configured — the plugin takes over that page. Nothing is changed in Settings → Reading.', 'zymarg-homepage' ); ?></li>
                                <li class="zhp-settings-row__desc"><?php esc_html_e( 'If a published page with the slug "home" exists — it is set as the static front page automatically.', 'zymarg-homepage' ); ?></li>
                                <li class="zhp-settings-row__desc"><?php esc_html_e( 'If neither exists — a new "Home" page is created and set as the static front page.', 'zymarg-homepage' ); ?></li>
                            </ul>
                            <p class="zhp-settings-row__desc">
                                <?php esc_html_e( 'The plugin renders its output by overriding the front page content at runtime — it does not insert a shortcode or modify any page in the database.', 'zymarg-homepage' ); ?>
                            </p>
                        </div>
                    </div>

                    <!-- Step 2 — Enable sections (still manual) -->
                    <div class="zhp-settings-row">
                        <div class="zhp-settings-row__info">
                            <p class="zhp-settings-row__label">
                                <?php esc_html_e( 'Step 2 — Enable and order sections', 'zymarg-homepage' ); ?>
                            </p>
                            <p class="zhp-settings-row__desc">
                                <?php esc_html_e( 'All 15 sections are enabled by default. Go to ZYMARG Homepage → Homepage to toggle sections on or off and drag them into the order you want. Save. Reload your front page — the changes appear immediately.', 'zymarg-homepage' ); ?>
                            </p>
                            <a href="<?php echo esc_url( admin_url( 'admin.php?page=zymarg-homepage-sections' ) ); ?>"
                               class="zhp-admin-btn zhp-admin-btn--primary zhp-help-btn-inline">
                                <?php esc_html_e( 'Open Section Manager →', 'zymarg-homepage' ); ?>
                            </a>
                        </div>
                    </div>

                    <!-- Step 3 (optional) — Reduce theme interference -->
                    <div class="zhp-settings-row">
                        <div class="zhp-settings-row__info">
                            <p class="zhp-settings-row__label">
                                <?php esc_html_e( 'Step 3 (optional) — Reduce theme interference', 'zymarg-homepage' ); ?>
                            </p>
                            <p class="zhp-settings-row__desc">
                                <?php esc_html_e( 'The plugin renders its output between your theme\'s header and footer. If your theme adds a sidebar, page title, or breadcrumbs to the front page, assign a full-width or blank page template to the front page. This is done via the Page Attributes panel in the WordPress editor — the available templates depend on your theme.', 'zymarg-homepage' ); ?>
                            </p>
                        </div>
                    </div>

                    <!-- Manual shortcode fallback note -->
                    <div class="zhp-settings-row">
                        <div class="zhp-settings-row__info">
                            <p class="zhp-settings-row__label">
                                <?php esc_html_e( 'Using the shortcode on other pages', 'zymarg-homepage' ); ?>
                            </p>
                            <p class="zhp-settings-row__desc">
                                <?php esc_html_e( 'The automatic takeover only applies to the WordPress front page. To embed the homepage output anywhere else, place the shortcode in that page\'s content:', 'zymarg-homepage' ); ?>
                            </p>
                            <code class="zhp-admin-status__code zhp-help-code">[zymarg_homepage]</code>
                        </div>
                    </div>

                </div><!-- end Initial Setup -->

                <!-- ═══════════════════════════════════════════════
                     2. SECTION REFERENCE
                ═══════════════════════════════════════════════ -->
                <div class="zhp-settings-group">

                    <h2 class="zhp-settings-group__title">
                        <?php esc_html_e( 'Section Reference', 'zymarg-homepage' ); ?>
                    </h2>

                    <p class="zhp-settings-row__desc zhp-help-intro">
                        <?php esc_html_e( 'All 15 sections ship enabled by default and can be individually toggled and reordered from the Homepage manager. The slug is the internal identifier used in filters, REST calls, and AJAX requests.', 'zymarg-homepage' ); ?>
                    </p>

                    <table class="zhp-help-table widefat striped">
                        <thead>
                            <tr>
                                <th><?php esc_html_e( 'Section', 'zymarg-homepage' ); ?></th>
                                <th><?php esc_html_e( 'Slug', 'zymarg-homepage' ); ?></th>
                                <th><?php esc_html_e( 'Description', 'zymarg-homepage' ); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $sections = [
                                [ 'Hero',              'hero',                   __( 'Full-width banner with heading, subheading, and two CTA buttons. Background accepts an image URL.', 'zymarg-homepage' ) ],
                                [ 'Categories',        'categories',             __( 'Product category grid pulled from WooCommerce. Shows category image, name, and product count.', 'zymarg-homepage' ) ],
                                [ 'Best Sellers',      'best-sellers',           __( 'Top-selling products ordered by WooCommerce total_sales meta.', 'zymarg-homepage' ) ],
                                [ 'New Arrivals',      'new-arrivals',           __( 'Most recently published products. Cards carry a "NEW" badge.', 'zymarg-homepage' ) ],
                                [ 'Featured Products', 'featured-products',      __( 'Products marked as Featured in WooCommerce.', 'zymarg-homepage' ) ],
                                [ 'Flash Deals',       'flash-deals',            __( 'On-sale products. Cards show a live countdown timer to the sale end date.', 'zymarg-homepage' ) ],
                                [ 'Trending',          'trending-products',      __( 'High view-count products using WooCommerce analytics. Falls back to total_sales if analytics are unavailable.', 'zymarg-homepage' ) ],
                                [ 'Recommended',       'recommended',            __( 'Up-sell and cross-sell products from the visitor\'s most recent WooCommerce order. Shows empty state for guests.', 'zymarg-homepage' ) ],
                                [ 'Featured Sellers',  'featured-sellers',       __( 'Dokan seller cards with avatar, store name, rating, and product count.', 'zymarg-homepage' ) ],
                                [ 'Promo Banner',      'promo-banner',           __( 'Full-width image banner with optional overlay heading, subtext, and CTA button.', 'zymarg-homepage' ) ],
                                [ 'Collections',       'collections',            __( 'Curated category collections displayed as large image cards.', 'zymarg-homepage' ) ],
                                [ 'Brands',            'brands',                 __( 'Brand logo grid linking to brand archive pages.', 'zymarg-homepage' ) ],
                                [ 'Newsletter',        'newsletter',             __( 'AJAX email capture form. Fires the zhp_newsletter_subscribe action on successful submission.', 'zymarg-homepage' ) ],
                                [ 'Footer CTA',        'footer-cta',             __( 'Bottom-of-page call-to-action block with heading, body text, and two buttons.', 'zymarg-homepage' ) ],
                            ];
                            foreach ( $sections as $row ) :
                            ?>
                            <tr>
                                <td><strong><?php echo esc_html( $row[0] ); ?></strong></td>
                                <td><code><?php echo esc_html( $row[1] ); ?></code></td>
                                <td><?php echo esc_html( $row[2] ); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>

                </div><!-- end Section Reference -->

                <!-- ═══════════════════════════════════════════════
                     3. SHORTCODE & PHP FUNCTION
                ═══════════════════════════════════════════════ -->
                <div class="zhp-settings-group">

                    <h2 class="zhp-settings-group__title">
                        <?php esc_html_e( 'Shortcode & PHP Function', 'zymarg-homepage' ); ?>
                    </h2>

                    <div class="zhp-settings-row">
                        <div class="zhp-settings-row__info">
                            <p class="zhp-settings-row__label">
                                <?php esc_html_e( 'Shortcode', 'zymarg-homepage' ); ?>
                            </p>
                            <p class="zhp-settings-row__desc">
                                <?php esc_html_e( 'Place this in any WordPress page, post, or widget to render the full homepage output at that position.', 'zymarg-homepage' ); ?>
                            </p>
                            <code class="zhp-admin-status__code zhp-help-code">[zymarg_homepage]</code>
                        </div>
                    </div>

                    <div class="zhp-settings-row">
                        <div class="zhp-settings-row__info">
                            <p class="zhp-settings-row__label">
                                <?php esc_html_e( 'PHP Function', 'zymarg-homepage' ); ?>
                            </p>
                            <p class="zhp-settings-row__desc">
                                <?php esc_html_e( 'Use inside a theme template or custom code to render the output programmatically. Returns the full HTML string — it does not echo.', 'zymarg-homepage' ); ?>
                            </p>
                            <code class="zhp-admin-status__code zhp-help-code">&lt;?php echo zymarg_homepage_render(); ?&gt;</code>
                        </div>
                    </div>

                </div><!-- end Shortcode -->

                <!-- ═══════════════════════════════════════════════
                     4. DESIGN TOKEN OVERRIDES
                ═══════════════════════════════════════════════ -->
                <div class="zhp-settings-group">

                    <h2 class="zhp-settings-group__title">
                        <?php esc_html_e( 'Overriding Colors & Typography', 'zymarg-homepage' ); ?>
                    </h2>

                    <div class="zhp-settings-row">
                        <div class="zhp-settings-row__info">
                            <p class="zhp-settings-row__desc">
                                <?php esc_html_e( 'Every visual value in the plugin is defined as a CSS custom property (design token) on :root. To retheme without editing plugin files, override any token in your child theme\'s style.css or an additional CSS snippet. The most commonly changed tokens are shown below.', 'zymarg-homepage' ); ?>
                            </p>
                            <pre class="zhp-help-pre"><?php echo esc_html(
':root {
  /* Brand colours — source of truth: zymarg-tokens.css */
  --zhp-color-primary:   #9500A5;  /* mid purple  — section titles, borders   */
  --zhp-color-secondary: #BD00D1;  /* bright purple — gradient midpoint        */
  --zhp-color-accent:    #FEA9FF;  /* pink — gradient end, focus outlines      */
  --zhp-color-dark:      #36003D;  /* near-black purple — headings, dark text  */

  /* Status colours */
  --zhp-color-danger:    #E53E3E;  /* sale badge red   */
  --zhp-color-warning:   #ED8936;  /* hot badge orange */
  --zhp-color-star:      #F6AD55;  /* star rating amber */

  /* Typography — font-family comes from the theme; override if needed */
  --zhp-font-size-xl:   clamp(20px, 2.5vw, 24px);  /* section headings */
  --zhp-font-size-lg:   clamp(17px, 2vw,   20px);  /* sub-headings     */
  --zhp-font-size-sm:   14px;                       /* small text       */
}'
                            ); ?></pre>
                        </div>
                    </div>

                </div><!-- end Design Tokens -->

                <!-- ═══════════════════════════════════════════════
                     5. DEVELOPER HOOKS
                ═══════════════════════════════════════════════ -->
                <div class="zhp-settings-group">

                    <h2 class="zhp-settings-group__title">
                        <?php esc_html_e( 'Developer Hooks', 'zymarg-homepage' ); ?>
                    </h2>

                    <!-- Actions -->
                    <div class="zhp-settings-row">
                        <div class="zhp-settings-row__info">
                            <p class="zhp-settings-row__label">
                                <?php esc_html_e( 'Actions', 'zymarg-homepage' ); ?>
                            </p>
                        </div>
                    </div>

                    <table class="zhp-help-table widefat striped">
                        <thead>
                            <tr>
                                <th><?php esc_html_e( 'Hook', 'zymarg-homepage' ); ?></th>
                                <th><?php esc_html_e( 'Parameters', 'zymarg-homepage' ); ?></th>
                                <th><?php esc_html_e( 'When it fires', 'zymarg-homepage' ); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $actions = [
                                [ 'zhp_before_render',        '—',       __( 'Before the full homepage HTML is output.', 'zymarg-homepage' ) ],
                                [ 'zhp_after_render',         '—',       __( 'After the full homepage HTML is output.', 'zymarg-homepage' ) ],
                                [ 'zhp_newsletter_subscribe', '$email',  __( 'After a successful newsletter AJAX submission. Use to pass the email to your mailing list provider.', 'zymarg-homepage' ) ],
                            ];
                            foreach ( $actions as $row ) :
                            ?>
                            <tr>
                                <td><code><?php echo esc_html( $row[0] ); ?></code></td>
                                <td><code><?php echo esc_html( $row[1] ); ?></code></td>
                                <td><?php echo esc_html( $row[2] ); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>

                    <!-- Filters -->
                    <div class="zhp-settings-row" style="margin-top:1.5rem;">
                        <div class="zhp-settings-row__info">
                            <p class="zhp-settings-row__label">
                                <?php esc_html_e( 'Filters', 'zymarg-homepage' ); ?>
                            </p>
                        </div>
                    </div>

                    <table class="zhp-help-table widefat striped">
                        <thead>
                            <tr>
                                <th><?php esc_html_e( 'Filter', 'zymarg-homepage' ); ?></th>
                                <th><?php esc_html_e( 'What it controls', 'zymarg-homepage' ); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $filters = [
                                [ 'zhp_section_data_{$type}',  __( 'Raw data array before a specific section renders. Replace {$type} with the section slug, e.g. zhp_section_data_best-sellers.', 'zymarg-homepage' ) ],
                                [ 'zhp_product_query_args',    __( 'WP_Query arguments array before any product query runs. Use to add custom meta queries or tax queries.', 'zymarg-homepage' ) ],
                                [ 'zhp_cache_ttl',             __( 'Cache lifetime in seconds. Default: 3600 (1 hour). Return 0 to disable caching entirely.', 'zymarg-homepage' ) ],
                                [ 'zhp_enabled_sections',      __( 'Ordered array of enabled section slugs. Modify to add, remove, or reorder sections programmatically.', 'zymarg-homepage' ) ],
                            ];
                            foreach ( $filters as $row ) :
                            ?>
                            <tr>
                                <td><code><?php echo esc_html( $row[0] ); ?></code></td>
                                <td><?php echo esc_html( $row[1] ); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>

                </div><!-- end Developer Hooks -->

                <!-- ═══════════════════════════════════════════════
                     6. AJAX & REST REFERENCE
                ═══════════════════════════════════════════════ -->
                <div class="zhp-settings-group">

                    <h2 class="zhp-settings-group__title">
                        <?php esc_html_e( 'AJAX & REST Endpoints', 'zymarg-homepage' ); ?>
                    </h2>

                    <p class="zhp-settings-row__desc zhp-help-intro">
                        <?php esc_html_e( 'All AJAX handlers require a valid nonce passed as zhp_nonce in the POST body. Nonces are localised onto every page that renders plugin output via the zhpAjax JavaScript global.', 'zymarg-homepage' ); ?>
                    </p>

                    <table class="zhp-help-table widefat striped">
                        <thead>
                            <tr>
                                <th><?php esc_html_e( 'Type', 'zymarg-homepage' ); ?></th>
                                <th><?php esc_html_e( 'Action / Route', 'zymarg-homepage' ); ?></th>
                                <th><?php esc_html_e( 'Description', 'zymarg-homepage' ); ?></th>
                                <th><?php esc_html_e( 'Auth required', 'zymarg-homepage' ); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $endpoints = [
                                [ 'AJAX', 'zhp_dashboard_status',        __( 'Live status tiles on the plugin Dashboard.', 'zymarg-homepage' ),                 __( 'Yes - manage_options', 'zymarg-homepage' ) ],
                                [ 'AJAX', 'zhp_save_sections',           __( 'Saves section order, on/off state and per-section settings.', 'zymarg-homepage' ), __( 'Yes - manage_options', 'zymarg-homepage' ) ],
                                [ 'AJAX', 'zhp_reset_sections',          __( 'Restores the default section order and clears settings.', 'zymarg-homepage' ),    __( 'Yes - manage_options', 'zymarg-homepage' ) ],
                                [ 'AJAX', 'zhp_save_settings',           __( 'Saves the global Settings screen.', 'zymarg-homepage' ),                          __( 'Yes - manage_options', 'zymarg-homepage' ) ],
                                [ 'AJAX', 'zhp_admin_page',              __( 'Loads an admin screen for the no-reload admin router.', 'zymarg-homepage' ),      __( 'Yes - manage_options', 'zymarg-homepage' ) ],
                                [ 'REST', 'GET /zhp/v1/categories',      __( 'Product categories used by the Category Showcase section.', 'zymarg-homepage' ),  __( 'No - open to all visitors', 'zymarg-homepage' ) ],
                                [ 'REST', 'GET /zhp/v1/sellers',         __( 'Dokan vendors used by the Featured Sellers section.', 'zymarg-homepage' ),        __( 'No - open to all visitors', 'zymarg-homepage' ) ],
                                [ 'REST', 'POST /zhp/v1/newsletter/subscribe', __( 'Subscribes an email; fires the zhp_newsletter_subscribe action.', 'zymarg-homepage' ), __( 'No - open to all visitors', 'zymarg-homepage' ) ],
                            ];
                            foreach ( $endpoints as $row ) :
                            ?>
                            <tr>
                                <td><strong><?php echo esc_html( $row[0] ); ?></strong></td>
                                <td><code><?php echo esc_html( $row[1] ); ?></code></td>
                                <td><?php echo esc_html( $row[2] ); ?></td>
                                <td><?php echo esc_html( $row[3] ); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>

                    <!-- JS global reference -->
                    <div class="zhp-settings-row" style="margin-top:1.5rem;">
                        <div class="zhp-settings-row__info">
                            <p class="zhp-settings-row__label">
                                <?php esc_html_e( 'JavaScript global — zhpAjax', 'zymarg-homepage' ); ?>
                            </p>
                            <p class="zhp-settings-row__desc">
                                <?php esc_html_e( 'Available on every page where the plugin renders. Use it in custom JS to make authenticated AJAX calls.', 'zymarg-homepage' ); ?>
                            </p>
                            <pre class="zhp-help-pre"><?php echo esc_html(
'window.zhpAjax = {
  ajaxUrl: "/wp-admin/admin-ajax.php",
  restUrl:  "/wp-json/zhp/v1/",
  nonces: {
    newsletter: "…",
  },
  i18n: {
    exploreMore:  "Explore More",
    loading:      "Loading…",
    error:        "Something went wrong. Please try again.",
    carouselPrev: "Scroll left",
    carouselNext: "Scroll right",
  },
};'
                            ); ?></pre>
                        </div>
                    </div>

                </div><!-- end AJAX & REST -->

                <!-- 9. CUSTOM CODE BOXES -->
                <div class="zhp-settings-group">

                    <h2 class="zhp-settings-group__title">
                        <?php esc_html_e( 'Custom Code Boxes', 'zymarg-homepage' ); ?>
                    </h2>

                    <p class="zhp-settings-row__desc zhp-help-intro">
                        <?php esc_html_e( 'Every section panel in the Homepage manager offers boxes for your own code. They accept different things and are protected in different ways. Your code is stored exactly as you type it and is always visible again when you reopen the panel.', 'zymarg-homepage' ); ?>
                    </p>

                    <table class="zhp-help-table widefat striped">
                        <thead>
                            <tr>
                                <th><?php esc_html_e( 'Box', 'zymarg-homepage' ); ?></th>
                                <th><?php esc_html_e( 'Stored as', 'zymarg-homepage' ); ?></th>
                                <th><?php esc_html_e( 'What it accepts', 'zymarg-homepage' ); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $zhp_boxes = [
                                [
                                    __( 'Custom Header HTML', 'zymarg-homepage' ),
                                    'header_html',
                                    __( 'A fragment that replaces the heading row of one section only. Wrap it in an element with the class zhp-section-header to keep the standard spacing. A style block is allowed and is confined to this section.', 'zymarg-homepage' ),
                                ],
                                [
                                    __( 'My HTML Design', 'zymarg-homepage' ),
                                    'custom_html',
                                    __( 'A complete replacement for the whole section body. Only used when Design Source is set to "My own HTML design". Supports live data placeholders.', 'zymarg-homepage' ),
                                ],
                                [
                                    __( 'Extra CSS', 'zymarg-homepage' ),
                                    'custom_css',
                                    __( 'Plain CSS applied after the styles inside your HTML, so it wins any conflict. Only output when My HTML Design is in use, so it does nothing if you are only using the header box.', 'zymarg-homepage' ),
                                ],
                            ];
                            foreach ( $zhp_boxes as $zhp_row ) :
                            ?>
                            <tr>
                                <td><?php echo esc_html( $zhp_row[0] ); ?></td>
                                <td><code><?php echo esc_html( $zhp_row[1] ); ?></code></td>
                                <td><?php echo esc_html( $zhp_row[2] ); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>

                    <div class="zhp-settings-row">
                        <div class="zhp-settings-row__info">
                            <p class="zhp-settings-row__label">
                                <?php esc_html_e( 'Rules for the Custom Header HTML box', 'zymarg-homepage' ); ?>
                            </p>
                            <ul>
                                <li class="zhp-settings-row__desc"><?php esc_html_e( 'Paste a fragment, not a whole file. DOCTYPE, html, head, title and body tags are stripped automatically.', 'zymarg-homepage' ); ?></li>
                                <li class="zhp-settings-row__desc"><?php esc_html_e( 'Never style body, html or :root. Those rules are confined to the section, and page-level layout properties such as display, margin, position and min-height are dropped entirely.', 'zymarg-homepage' ); ?></li>
                                <li class="zhp-settings-row__desc"><?php esc_html_e( 'Script tags and inline event handlers such as onclick are removed. This box is for layout and text only.', 'zymarg-homepage' ); ?></li>
                                <li class="zhp-settings-row__desc"><?php esc_html_e( 'Give your CSS classes a unique prefix. Keyframe names are global, so a generic name can clash with your theme.', 'zymarg-homepage' ); ?></li>
                                <li class="zhp-settings-row__desc"><?php esc_html_e( 'Use absolute image URLs.', 'zymarg-homepage' ); ?></li>
                            </ul>
                            <p class="zhp-settings-row__desc">
                                <?php esc_html_e( 'A reviewer under the box reports anything that will be changed, before and after you save.', 'zymarg-homepage' ); ?>
                            </p>
                        </div>
                    </div>

                    <div class="zhp-settings-row">
                        <div class="zhp-settings-row__info">
                            <p class="zhp-settings-row__label">
                                <?php esc_html_e( 'Live data placeholders', 'zymarg-homepage' ); ?>
                            </p>
                            <p class="zhp-settings-row__desc">
                                <?php esc_html_e( 'The My HTML Design box replaces placeholders with real data. Single values look like {{heading}}. Repeating blocks wrap the markup that should repeat once per row. Each section panel lists the placeholders it supports. Any placeholder that has no data is removed rather than printed.', 'zymarg-homepage' ); ?>
                            </p>
                            <pre class="zhp-help-pre"><?php echo esc_html( "{{#categories}}\n  <a href=\"{{url}}\">{{name}} ({{count}})</a>\n{{/categories}}" ); ?></pre>
                        </div>
                    </div>

                    <div class="zhp-settings-row">
                        <div class="zhp-settings-row__info">
                            <p class="zhp-settings-row__label">
                                <?php esc_html_e( 'Hiding a section header', 'zymarg-homepage' ); ?>
                            </p>
                            <p class="zhp-settings-row__desc">
                                <?php esc_html_e( 'Each section panel has a Hide section header checkbox. It removes the heading row only and leaves the rest of the section intact, which is useful when your own design already contains a title.', 'zymarg-homepage' ); ?>
                            </p>
                        </div>
                    </div>

                    <div class="zhp-settings-row">
                        <div class="zhp-settings-row__info">
                            <p class="zhp-settings-row__label">
                                <?php esc_html_e( 'Where your code is stored', 'zymarg-homepage' ); ?>
                            </p>
                            <p class="zhp-settings-row__desc">
                                <?php esc_html_e( 'All three boxes are saved verbatim in the zymarg_hp_section_order option, together with section order and toggle states. Your code survives plugin updates, deactivation and reactivation. Deleting the plugin from the Plugins screen runs uninstall.php, which removes that option and everything in it, so copy your code out first.', 'zymarg-homepage' ); ?>
                            </p>
                        </div>
                    </div>

                </div><!-- end Custom Code Boxes -->

                <!-- ===============================================
                     SECTION FEATURES (1.29.0 - 1.35.0)
                     =============================================== -->
                <div class="zhp-settings-group">
                    <h2 class="zhp-settings-group__title">
                        <?php esc_html_e( 'Section Features', 'zymarg-homepage' ); ?>
                    </h2>
                    <p class="zhp-help-intro">
                        <?php esc_html_e( 'Everything below is set per section, from Homepage - Sections. Click the arrow beside a section to open its panel.', 'zymarg-homepage' ); ?>
                    </p>
                    <table class="zhp-help-table">
                        <thead>
                            <tr>
                                <th><?php esc_html_e( 'Setting', 'zymarg-homepage' ); ?></th>
                                <th><?php esc_html_e( 'Where it appears', 'zymarg-homepage' ); ?></th>
                                <th><?php esc_html_e( 'What it does', 'zymarg-homepage' ); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            /*
                             * The spacing rows are generated from the
                             * Core\Spacing registry rather than written out
                             * here, so this table cannot fall behind the
                             * controls it documents - which is exactly what
                             * happened while the sliders were maintained by
                             * hand across several files.
                             */
                            $zhp_spacing_labels = \ZYMARGHomepage\Core\Spacing::labels();

                            $features = [
                                ...array_map(
                                    static function ( array $control ) use ( $zhp_spacing_labels ) {
                                        $key = (string) $control['key'];

                                        return [
                                            $zhp_spacing_labels[ $key ]['label'] ?? $key,
                                            __( 'Global - Settings screen', 'zymarg-homepage' ),
                                            $zhp_spacing_labels[ $key ]['desc'] ?? '',
                                        ];
                                    },
                                    \ZYMARGHomepage\Core\Spacing::CONTROLS
                                ),
                                [ __( 'Hide Section Header', 'zymarg-homepage' ), __( 'Every section', 'zymarg-homepage' ), __( 'Removes the heading row entirely, including the Explore More link. Use it when your custom HTML already draws its own heading.', 'zymarg-homepage' ) ],
                                [ __( 'Custom Header HTML', 'zymarg-homepage' ), __( 'Every section', 'zymarg-homepage' ), __( 'Replaces just the heading row. Paste a fragment, not a full page - no doctype, html, head or body tags. Anything you paste is checked as you type and unsafe wrappers are stripped on save.', 'zymarg-homepage' ) ],
                                [ __( 'Explore More link', 'zymarg-homepage' ), __( 'The 10 row sections', 'zymarg-homepage' ), __( 'The link at the right of the heading. Set your own URL and label, hide it, or replace it with your own HTML. Left empty, it points at the WooCommerce shop page.', 'zymarg-homepage' ) ],
                                [ __( 'Horizontal swipeable carousel', 'zymarg-homepage' ), __( 'The 10 row sections', 'zymarg-homepage' ), __( 'Turns the grid into a one-row swipeable strip with arrow buttons. Off by default - switch it on only where you want it.', 'zymarg-homepage' ) ],
                                [ __( 'Rotate the carousel automatically', 'zymarg-homepage' ), __( 'The 10 row sections', 'zymarg-homepage' ), __( 'Moves the row on its own. Only has an effect when the carousel above is on. Off by default, and never runs for visitors whose device asks for reduced motion.', 'zymarg-homepage' ) ],
                                [ __( 'Rotation Style', 'zymarg-homepage' ), __( 'The 10 row sections, plus Hero, Promo Banner and Footer CTA', 'zymarg-homepage' ), __( 'Step is the default: move one screen, wait, move again. Continuous drifts steadily from right to left and never pauses, reading like a live ticker. Continuous ignores the seconds setting and uses the pixels-per-second speed instead.', 'zymarg-homepage' ) ],
                                [ __( 'Seconds Between Slides', 'zymarg-homepage' ), __( 'The 10 row sections', 'zymarg-homepage' ), __( 'How long the row rests before moving again, in the Step style only. 2 to 30 seconds, default 6.', 'zymarg-homepage' ) ],
                                [ __( 'Continuous Speed', 'zymarg-homepage' ), __( 'Every section that can rotate', 'zymarg-homepage' ), __( 'Travel speed for the Continuous style, in pixels per second. 10 to 200, default 40. Around 40 reads as a gentle drift; higher moves faster.', 'zymarg-homepage' ) ],
                                [ __( 'Banners repeater', 'zymarg-homepage' ), __( 'Hero, Promo Banner, Newsletter, Footer CTA', 'zymarg-homepage' ), __( 'Add more than one banner to a single-block section and it becomes a slider. With one banner the output is unchanged.', 'zymarg-homepage' ) ],
                                [ __( 'Rotate banners automatically', 'zymarg-homepage' ), __( 'Hero, Promo Banner, Footer CTA', 'zymarg-homepage' ), __( 'Advances the slider on its own, in either rotation style. Newsletter is swipe-only on purpose, so a form cannot slide away from someone part-way through typing.', 'zymarg-homepage' ) ],
                                [ __( 'Seconds Between Banners', 'zymarg-homepage' ), __( 'Hero, Promo Banner, Footer CTA', 'zymarg-homepage' ), __( 'How long each banner rests before the next one. 2 to 30 seconds, default 6.', 'zymarg-homepage' ) ],
                                [ __( 'Glide Speed', 'zymarg-homepage' ), __( 'Every section that can rotate', 'zymarg-homepage' ), __( 'How long one slide movement takes, in milliseconds. 100 to 3000, default 400. This is the travel time, not the wait in between, and it applies to the arrow buttons as well. The Continuous style does not use it.', 'zymarg-homepage' ) ],
                                [ __( 'Brands list', 'zymarg-homepage' ), __( 'Brands', 'zymarg-homepage' ), __( 'Type brand logos and links by hand. Whatever you add here replaces the automatic list, so no brand taxonomy is needed on the store.', 'zymarg-homepage' ) ],
                                [ __( 'Show seller name', 'zymarg-homepage' ), __( 'The 6 product sections', 'zymarg-homepage' ), __( 'Shows the Dokan vendor under each card. Needs the ZYMARG Template Pack card design, since the classic card has no vendor row.', 'zymarg-homepage' ) ],
                            ];
                            foreach ( $features as $row ) :
                            ?>
                            <tr>
                                <td><strong><?php echo esc_html( $row[0] ); ?></strong></td>
                                <td><?php echo esc_html( $row[1] ); ?></td>
                                <td><?php echo esc_html( $row[2] ); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div><!-- end Section Features -->

                <!-- ===============================================
                     DASHBOARD STATUS & CARD DESIGN
                     =============================================== -->
                <div class="zhp-settings-group">
                    <h2 class="zhp-settings-group__title">
                        <?php esc_html_e( 'Dashboard Status Rows', 'zymarg-homepage' ); ?>
                    </h2>
                    <p class="zhp-help-intro">
                        <?php esc_html_e( 'The Dashboard checks these live every time you open it. This is what each row means and what to do when it is not green.', 'zymarg-homepage' ); ?>
                    </p>
                    <table class="zhp-help-table">
                        <thead>
                            <tr>
                                <th><?php esc_html_e( 'Row', 'zymarg-homepage' ); ?></th>
                                <th><?php esc_html_e( 'Meaning', 'zymarg-homepage' ); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $rows = [
                                [ __( 'Master Switch', 'zymarg-homepage' ), __( 'Off means the plugin renders nothing at all, whatever your section settings say. Set it on the Settings screen.', 'zymarg-homepage' ) ],
                                [ __( 'Sections Active', 'zymarg-homepage' ), __( 'How many sections are switched on out of the total available. Retired sections are not counted.', 'zymarg-homepage' ) ],
                                [ __( 'Front Page', 'zymarg-homepage' ), __( 'Whether WordPress is set to show a static page as the front page, under Settings - Reading.', 'zymarg-homepage' ) ],
                                [ __( 'Shortcode on Page', 'zymarg-homepage' ), __( 'Whether the front page contains the homepage shortcode. It can read Missing while the homepage still renders correctly, if your theme or page builder calls the plugin another way. Only worth chasing if the sections are actually absent.', 'zymarg-homepage' ) ],
                                [ __( 'WooCommerce', 'zymarg-homepage' ), __( 'Required. Without it no product, category or seller section can render.', 'zymarg-homepage' ) ],
                                [ __( 'Dokan', 'zymarg-homepage' ), __( 'Needed only by Featured Sellers and by the vendor name on product cards.', 'zymarg-homepage' ) ],
                                [ __( 'Product Grid Engine', 'zymarg-homepage' ), __( 'The ZYMARG WC Product Grid plugin. It owns all product querying and card rendering. Inactive means every product section renders nothing on the front end, and admins see a notice in its place.', 'zymarg-homepage' ) ],
                                [ __( 'Template Pack', 'zymarg-homepage' ), __( 'The ZYMARG Template Pack, which supplies the branded card design. Without it, cards fall back to the engine classic card.', 'zymarg-homepage' ) ],
                                [ __( 'Flash Deals Source', 'zymarg-homepage' ), __( 'Whether the engine provides a flash deals product source. Not built yet means the Flash Deals section stays empty for visitors until that source ships in the engine.', 'zymarg-homepage' ) ],
                            ];
                            foreach ( $rows as $row ) :
                            ?>
                            <tr>
                                <td><strong><?php echo esc_html( $row[0] ); ?></strong></td>
                                <td><?php echo esc_html( $row[1] ); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>

                    <div class="zhp-settings-row" style="margin-top:1.5rem;">
                        <div class="zhp-settings-row__info">
                            <p class="zhp-settings-row__label">
                                <?php esc_html_e( 'Product Card Design', 'zymarg-homepage' ); ?>
                            </p>
                            <p class="zhp-settings-row__desc">
                                <?php esc_html_e( 'On the Settings screen you choose which card the product sections draw. ZYMARG branded is the Template Pack card, with the discount badge, quick view, wishlist, rating and vendor row. Engine default is the classic card that ships with the Product Grid engine. If the Template Pack is not installed the branded option quietly falls back to classic, and the Settings screen tells you so.', 'zymarg-homepage' ); ?>
                            </p>
                        </div>
                    </div>
                </div><!-- end Dashboard Status -->

                <!-- ═══════════════════════════════════════════════
                     7. ASSET DEBUG MODE
                ═══════════════════════════════════════════════ -->
                <div class="zhp-settings-group">

                    <h2 class="zhp-settings-group__title">
                        <?php esc_html_e( 'Asset Debug Mode', 'zymarg-homepage' ); ?>
                    </h2>

                    <div class="zhp-settings-row">
                        <div class="zhp-settings-row__info">
                            <p class="zhp-settings-row__desc">
                                <?php esc_html_e( 'By default the plugin loads minified CSS and JS files (.min.css / .min.js) for performance. To load the full unminified originals for development or debugging, add the following line to your wp-config.php before the "That\'s all, stop editing!" comment.', 'zymarg-homepage' ); ?>
                            </p>
                            <pre class="zhp-help-pre"><?php echo esc_html( "define( 'SCRIPT_DEBUG', true );" ); ?></pre>
                            <p class="zhp-settings-row__desc">
                                <?php esc_html_e( 'Remove or set to false when done — SCRIPT_DEBUG noticeably increases page weight.', 'zymarg-homepage' ); ?>
                            </p>
                        </div>
                    </div>

                </div><!-- end Asset Debug Mode -->

                <!-- ═══════════════════════════════════════════════
                     8. TROUBLESHOOTING
                ═══════════════════════════════════════════════ -->
                <div class="zhp-settings-group">

                    <h2 class="zhp-settings-group__title">
                        <?php esc_html_e( 'Troubleshooting', 'zymarg-homepage' ); ?>
                    </h2>

                    <?php
                    $issues = [
                        [
                            __( 'Nothing appears on the front page', 'zymarg-homepage' ),
                            [
                                __( 'The page containing [zymarg_homepage] is not set as the static front page. Go to Settings → Reading and set it.', 'zymarg-homepage' ),
                                __( 'The shortcode [zymarg_homepage] is missing from the page content. Open the page in the editor and confirm it is there.', 'zymarg-homepage' ),
                                __( 'The master switch is OFF. Go to ZYMARG Homepage → Settings and enable it.', 'zymarg-homepage' ),
                                __( 'No sections are enabled. Go to ZYMARG Homepage → Homepage and enable at least one section.', 'zymarg-homepage' ),
                            ],
                        ],
                        [
                            __( 'Sections show but no products appear', 'zymarg-homepage' ),
                            [
                                __( 'WooCommerce is not active or no products are published. Confirm WooCommerce is installed and you have at least one published product.', 'zymarg-homepage' ),
                                __( 'The cache is serving stale empty results. Go to ZYMARG Homepage → Settings and set Cache Duration to 0 temporarily, reload the page, then restore your preferred cache duration.', 'zymarg-homepage' ),
                                __( 'The section type has no matching products. Flash Deals needs products on sale, and Recommended needs enough order history. Test with Best Sellers or New Arrivals first, since those work on any store with products.', 'zymarg-homepage' ),
                            ],
                        ],
                        [
                            __( 'Featured Sellers section is empty', 'zymarg-homepage' ),
                            [
                                __( 'The Dokan multivendor plugin is not active or no sellers have been approved. Confirm Dokan is active and at least one vendor account exists with published products.', 'zymarg-homepage' ),
                            ],
                        ],
                        [
                            __( 'Carousel arrows or auto-rotate do not work', 'zymarg-homepage' ),
                            [
                                __( 'A JavaScript error is occurring before the plugin scripts run. Open your browser\'s developer console (F12) and look for errors on the Network or Console tab.', 'zymarg-homepage' ),
                                __( 'A caching or minification plugin is combining or deferring scripts in a way that breaks carousel.js. Temporarily disable third-party caching plugins and test again.', 'zymarg-homepage' ),
                                __( 'Auto-rotate never runs for visitors whose device asks for reduced motion. That is intentional, and so is each style stopping differently: Step stops for good the moment a visitor swipes, scrolls or tabs in, while Continuous only pauses on hover or focus and then resumes.', 'zymarg-homepage' ),
                                __( 'Rotation needs two or more items. A banner section with a single banner, or a row whose section has only one card, has nothing to rotate.', 'zymarg-homepage' ),
                            ],
                        ],
                        [
                            __( 'Newsletter signup returns an error', 'zymarg-homepage' ),
                            [
                                __( 'The zhp_newsletter_subscribe action has no listener hooked to it. You need to add_action( \'zhp_newsletter_subscribe\', ... ) in your theme functions.php or a custom plugin to pass the email to your mailing list provider.', 'zymarg-homepage' ),
                            ],
                        ],
                        [
                            __( 'CSS styles look broken or missing', 'zymarg-homepage' ),
                            [
                                __( 'Another plugin or your theme is outputting an error that prevents the plugin stylesheets from loading. Check for PHP notices or fatal errors in WP_DEBUG mode.', 'zymarg-homepage' ),
                                __( 'A minification/concatenation plugin has removed the plugin CSS. Exclude zymarg-tokens.min.css and any zhp-*.min.css from that plugin\'s scope.', 'zymarg-homepage' ),
                            ],
                        ],
                    ];

                    foreach ( $issues as $issue ) :
                    ?>
                    <div class="zhp-settings-row">
                        <div class="zhp-settings-row__info">
                            <p class="zhp-settings-row__label">
                                <?php echo esc_html( $issue[0] ); ?>
                            </p>
                            <ul class="zhp-help-list">
                                <?php foreach ( $issue[1] as $fix ) : ?>
                                <li class="zhp-settings-row__desc"><?php echo esc_html( $fix ); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
                    <?php endforeach; ?>

                </div><!-- end Troubleshooting -->

                <!-- ── Footer ──────────────────────────────────── -->
                <div class="zhp-admin-status" style="margin-top:2rem;">
                    <div class="zhp-admin-status__item">
                        <span class="zhp-admin-status__label">
                            <?php esc_html_e( 'Version', 'zymarg-homepage' ); ?>
                        </span>
                        <span class="zhp-admin-status__value">
                            <?php echo esc_html( ZYMARG_HP_VERSION ); ?>
                        </span>
                    </div>
                    <?php
                    $support_email = Settings::get( 'support_email' );
                    if ( $support_email ) :
                    ?>
                    <div class="zhp-admin-status__item">
                        <span class="zhp-admin-status__label">
                            <?php esc_html_e( 'Support', 'zymarg-homepage' ); ?>
                        </span>
                        <span class="zhp-admin-status__value">
                            <a href="mailto:<?php echo esc_attr( $support_email ); ?>">
                                <?php echo esc_html( $support_email ); ?>
                            </a>
                        </span>
                    </div>
                    <?php endif; ?>
                </div>

            </div><!-- .zhp-admin-content -->
        </div><!-- .wrap.zhp-admin-wrap -->

        <?php
    }
}
