<?php
/**
 * ZYMARG Homepage – Admin Asset Manager
 *
 * Enqueues CSS and JS for the ZYMARG Homepage admin pages only.
 * Admin assets are never loaded on the frontend, and frontend assets
 * are never loaded in the admin — each side has its own manager.
 *
 * Hooked to admin_enqueue_scripts via Hooks::register(). The hook
 * receives the current admin page slug so we can load selectively.
 *
 * Phase 7 adds:
 *   • Asset URLs resolved via Core\AssetPath, which prefers the built
 *     .min file when it exists and falls back to the source otherwise.
 *
 * @package ZYMARGHomepage\Admin
 * @since   1.3.0
 * @version 1.29.0
 */

namespace ZYMARGHomepage\Admin;

use ZYMARGHomepage\Core\AssetPath;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Assets
 *
 * Registers and conditionally enqueues admin-side CSS and JS.
 */
final class Assets {

    /**
     * Admin page slugs on which plugin assets should be enqueued.
     *
     * @since 1.3.0
     * @var string[]
     */
    private const PLUGIN_PAGE_SLUGS = [
        'zymarg-homepage',
        'zymarg-homepage-sections',
        'zymarg-homepage-settings',
        'zymarg-homepage-help',
    ];


    /**
     * Enqueue admin CSS and JS.
     *
     * Hooked to admin_enqueue_scripts via Hooks::register().
     * Only loads on ZYMARG Homepage admin pages.
     *
     * @since 1.3.0
     * @param string $hook_suffix Current admin page hook suffix.
     * @return void
     */
    public function enqueue( string $hook_suffix ): void {
        $page = $this->current_plugin_page();

        if ( '' === $page ) {
            return;
        }

        $this->enqueue_admin_css();
        $this->enqueue_admin_js( $page );
    }

    /**
     * Resolve the current ZYMARG Homepage admin page slug.
     *
     * Matching on the hook suffix is unreliable: WordPress builds submenu
     * hooks from sanitize_title( parent MENU TITLE ), not the parent slug.
     * The parent title here is 'Homepage', so submenu hooks are actually
     * 'homepage_page_zymarg-homepage-settings' and not
     * 'zymarg-homepage_page_zymarg-homepage-settings'. Matching the page
     * slug is stable and survives any future menu-title change.
     *
     * @since 1.9.3
     * @return string Page slug, or an empty string when not a plugin page.
     */
    private function current_plugin_page(): string {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only page check.
        $page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';

        return in_array( $page, self::PLUGIN_PAGE_SLUGS, true ) ? $page : '';
    }

    // ──────────────────────────────────────────────────────────────
    //  Private helpers
    // ──────────────────────────────────────────────────────────────

    /**
     * Enqueue the main admin stylesheet.
     *
     * @since 1.3.0
     * @return void
     */
    private function enqueue_admin_css(): void {
        wp_enqueue_style(
            'zymarg-hp-admin',
            AssetPath::url( 'assets/css/admin/zymarg-admin', 'css' ),
            [],
            ZYMARG_HP_VERSION,
            'all'
        );
    }

    /**
     * Enqueue admin JavaScript.
     *
     * On the Homepage section manager page, also enqueues the drag-and-drop
     * script and jQuery UI Sortable (WordPress-bundled).
     *
     * @since 1.3.0
     * @param string $page Current ZYMARG Homepage admin page slug.
     * @return void
     */
    private function enqueue_admin_js( string $page ): void {
        // Base admin script (shared across all admin pages).
        wp_enqueue_script(
            'zymarg-hp-admin',
            AssetPath::url( 'assets/js/admin/zymarg-admin', 'js' ),
            [ 'jquery' ],
            ZYMARG_HP_VERSION,
            true
        );

        // zhpAdmin global — available on every plugin admin page.
        wp_localize_script(
            'zymarg-hp-admin',
            'zhpAdmin',
            [
                'ajaxUrl'        => admin_url( 'admin-ajax.php' ),
                'nonce'          => wp_create_nonce( 'zhp_save_settings' ),
                'nonceDashboard' => wp_create_nonce( 'zhp_dashboard_status' ),
                'i18n'           => [
                    'save'           => __( 'Save Settings',             'zymarg-homepage' ),
                    'saving'         => __( 'Saving…',                   'zymarg-homepage' ),
                    'saved'          => __( 'Settings saved.',           'zymarg-homepage' ),
                    'error'          => __( 'Save failed. Please try again.', 'zymarg-homepage' ),
                    'enabled'        => __( 'Enabled',                   'zymarg-homepage' ),
                    'disabled'       => __( 'Disabled',                  'zymarg-homepage' ),
                    'on'             => __( 'On',                        'zymarg-homepage' ),
                    'off'            => __( 'Off',                       'zymarg-homepage' ),
                    'active'         => __( 'Active',                    'zymarg-homepage' ),
                    'inactive'       => __( 'Inactive',                  'zymarg-homepage' ),
                    'configured'     => __( 'Configured',                'zymarg-homepage' ),
                    'notConfigured'  => __( 'Not configured',            'zymarg-homepage' ),
                    'found'          => __( 'Found',                     'zymarg-homepage' ),
                    'missing'        => __( 'Missing',                   'zymarg-homepage' ),
                    'hdrDoc' => __( 'This looks like a complete HTML file. The DOCTYPE, html, head and body tags are removed automatically.', 'zymarg-homepage' ),
                    'hdrRoot' => __( 'Your CSS targets body, html or :root. Those rules are confined to this section.', 'zymarg-homepage' ),
                    'hdrLayout' => __( 'Page-level layout properties such as display, margin and min-height are dropped.', 'zymarg-homepage' ),
                    'hdrScript' => __( 'Script tags and inline event handlers are removed.', 'zymarg-homepage' ),
                    'hdrWrap' => __( 'No zhp-section-header element found. Wrap your heading in one to keep standard spacing.', 'zymarg-homepage' ),
                    'hdrOk' => __( 'Looks good. Nothing in this code needs changing.', 'zymarg-homepage' ),
                ],
            ]
        );

        /*
         * AJAX page router — loaded on every plugin admin screen.
         *
         * Registered before the drag-and-drop script so the router's
         * `zhp:admin:loaded` handlers are attached first.
         */
        wp_enqueue_script(
            'zymarg-hp-admin-router',
            AssetPath::url( 'assets/js/admin/zymarg-admin-router', 'js' ),
            [ 'jquery' ],
            ZYMARG_HP_VERSION,
            true
        );

        wp_localize_script(
            'zymarg-hp-admin-router',
            'zhpRouter',
            [
                'ajaxUrl' => admin_url( 'admin-ajax.php' ),
                'nonce'   => wp_create_nonce( AjaxRouter::NONCE_ACTION ),
                // The allowlist the router may navigate to, taken from the PHP
                // side so the two can never drift apart.
                'slugs'   => array_keys( AjaxRouter::pages() ),
                'brand'   => __( 'ZYMARG Homepage', 'zymarg-homepage' ),
                'i18n'    => [
                    'loading' => __( 'Loading…', 'zymarg-homepage' ),
                    'error'   => __( 'Could not load that screen.', 'zymarg-homepage' ),
                ],
            ]
        );

        /*
         * Drag-and-drop now loads on every plugin admin screen, not just the
         * section manager.
         *
         * With AJAX navigation the browser can arrive at the section manager
         * without a page load, and admin_enqueue_scripts does not run again at
         * that point. Enqueuing it only on the sections page would mean the
         * sortable list silently stopped working whenever the user reached it
         * by clicking the submenu rather than loading the URL directly. The
         * script exits early on screens with no section list.
         *
         * $page is still received for clarity but no longer gates anything.
         */
        wp_enqueue_script( 'jquery-ui-sortable' );

        wp_enqueue_script(
            'zymarg-hp-drag-drop',
            AssetPath::url( 'assets/js/admin/zymarg-drag-drop', 'js' ),
            [ 'jquery', 'jquery-ui-sortable' ],
            ZYMARG_HP_VERSION,
            true
        );

        wp_localize_script(
            'zymarg-hp-drag-drop',
            'zhpDragDrop',
            [
                'ajaxUrl' => admin_url( 'admin-ajax.php' ),
                'nonce'   => wp_create_nonce( 'zhp_save_sections' ),
                'i18n'    => [
                    'save'      => __( 'Save Changes',              'zymarg-homepage' ),
                    'saving'    => __( 'Saving…',                   'zymarg-homepage' ),
                    'saved'     => __( 'Changes saved.',            'zymarg-homepage' ),
                    'error'     => __( 'Save failed. Please try again.', 'zymarg-homepage' ),
                    'confirm'   => __( 'Reset section order to defaults? This cannot be undone.', 'zymarg-homepage' ),
                    'cancel'    => __( 'Cancel',                    'zymarg-homepage' ),
                    'confirmOk' => __( 'Yes, reset',                'zymarg-homepage' ),
                ],
            ]
        );
    }
}
