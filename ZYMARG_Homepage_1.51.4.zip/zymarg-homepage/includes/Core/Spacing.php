<?php
/**
 * Spacing control registry.
 *
 * Single source of truth for every spacing setting on the homepage.
 *
 * Before this class each control was added by hand in five places: a default
 * in Admin\Settings, a clamp in its sanitiser, a block of markup in the
 * settings page, a key in the admin JS, and an emitter in Core\Assets. The
 * 0-100 range was restated in four of them and nothing kept the copies
 * honest - which is how the activation seed ended up missing three keys it
 * was commented as being kept in sync with.
 *
 * A control is now one entry in self::CONTROLS. Everything else reads it.
 *
 * @package ZYMARGHomepage
 * @since   1.45.0
 * @version 1.45.0
 */

namespace ZYMARGHomepage\Core;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registry of spacing controls and the CSS they emit.
 */
final class Spacing {

	/**
	 * Emits a unitless multiplier, e.g. 50 -> 0.5.
	 *
	 * Used for controls that scale a length the design already has. The
	 * stylesheet owns the length; the setting only says how much of it to use.
	 *
	 * @since 1.45.0
	 * @var   string
	 */
	public const MODE_SCALE = 'scale';

	/**
	 * Emits a length, e.g. 50 -> calc( var( --zhp-gap-max ) * 0.5 ).
	 *
	 * Used for gaps, which have no existing length to scale: at the shipped
	 * defaults they are simply absent. --zhp-gap-max is the shared reference
	 * so that 100 means the same amount of air wherever it is used.
	 *
	 * @since 1.45.0
	 * @var   string
	 */
	public const MODE_GAP = 'gap';

	/**
	 * Emits a pixel length, e.g. 4 -> 4px.
	 *
	 * Used where the design needs an exact figure rather than a proportion of
	 * something else. The Connection Engine's side gap field works this way,
	 * and matching it is the only way the two plugins can be lined up by
	 * typing the same number into both.
	 *
	 * @since 1.50.0
	 * @var   string
	 */
	public const MODE_PX = 'px';

	/**
	 * Emits a bare integer, e.g. 2.
	 *
	 * Used for counts consumed by repeat() in a grid template, where a unit
	 * would make the declaration invalid.
	 *
	 * @since 1.50.0
	 * @var   string
	 */
	public const MODE_COUNT = 'count';

	/**
	 * Emits a viewport-width length, e.g. 92 -> 92vw.
	 *
	 * Used for the content width, which has to keep adjusting itself to the
	 * screen rather than stopping at a figure typed in pixels. A vw value is
	 * what lets a 2560px or 4K display fill out instead of leaving every
	 * section in a narrow centred column while the hero band stretches past
	 * it on both sides.
	 *
	 * @since 1.51.0
	 * @var   string
	 */
	public const MODE_VW = 'vw';

	/**
	 * Every spacing control, in the order they appear on the settings screen.
	 *
	 * Deliberately holds no translated strings. This constant is read on the
	 * front end to build the inline style, and pulling label text in here
	 * would load the translation files on every page view to render nothing.
	 * Labels live in self::labels(), which only the admin screens call.
	 *
	 * 'default' is always the value that reproduces the layout as shipped, and
	 * is the one value that emits no CSS at all. Note that this is 100 for the
	 * scale controls and 0 for the gaps: a scale of 100 means "all of the
	 * length the stylesheet already has", while a gap of 0 means "the gap that
	 * does not exist yet". Both leave an untouched install byte-for-byte as
	 * the stylesheet was authored.
	 *
	 * @since 1.45.0
	 * @var   array<int, array<string, mixed>>
	 */
	public const CONTROLS = [
		// ── Master ────────────────────────────────────
		/*
		 * Multiplies --zhp-gap-max and the three vertical scales, so it moves
		 * every vertical gap at once while each control below still applies
		 * its own factor on top. Ranges past 100 because the useful direction
		 * for a master control is usually loosening, not tightening.
		 */
		[
			'key'     => 'master_gap',
			'var'     => '--zhp-gap-master',
			'mode'    => self::MODE_SCALE,
			'default' => 100,
			'min'     => 0,
			'max'     => 300,
			'step'    => 5,
		],
		[
			'key'     => 'card_gap',
			'var'     => '--zhp-card-gap-scale',
			'mode'    => self::MODE_SCALE,
			'default' => 100,
			'min'     => 0,
			'max'     => 300,
			'step'    => 5,
		],

		// ── Columns ──────────────────────────────────
		[
			'key'     => 'cards_per_row_desktop',
			'var'     => '--zhp-cols-d',
			'mode'    => self::MODE_COUNT,
			'default' => 4,
			'min'     => 1,
			'max'     => 8,
			'step'    => 1,
		],
		[
			'key'     => 'cards_per_row_tablet',
			'var'     => '--zhp-cols-t',
			'mode'    => self::MODE_COUNT,
			'default' => 3,
			'min'     => 1,
			'max'     => 8,
			'step'    => 1,
		],
		[
			'key'     => 'cards_per_row_mobile',
			'var'     => '--zhp-cols-m',
			'mode'    => self::MODE_COUNT,
			'default' => 2,
			'min'     => 1,
			'max'     => 4,
			'step'    => 1,
		],
		[
			'key'     => 'side_gap_mobile',
			'var'     => '--zhp-side-gap-m',
			'mode'    => self::MODE_PX,
			'default' => 4,
			'min'     => 0,
			'max'     => 60,
			'step'    => 1,
		],
		// ── Hero ──────────────────────────────────────────────────────
		[
			'key'     => 'hero_height',
			'var'     => '--zhp-hero-scale',
			'mode'    => self::MODE_SCALE,
			'default' => 100,
			'group'   => 'hero',
		],
		[
			'key'     => 'hero_padding',
			'var'     => '--zhp-hero-pad-scale',
			'mode'    => self::MODE_SCALE,
			'default' => 100,
			'group'   => 'hero',
		],
		[
			'key'     => 'hero_below_gap',
			'var'     => '--zhp-gap-hero',
			'mode'    => self::MODE_GAP,
			'default' => 0,
			'group'   => 'hero',
		],
		[
			'key'     => 'hero_above_gap',
			'var'     => '--zhp-gap-hero-top',
			'mode'    => self::MODE_GAP,
			'default' => 0,
			'group'   => 'hero',
		],
		[
			'key'     => 'hero_side_gap',
			'var'     => '--zhp-gap-hero-side',
			'mode'    => self::MODE_GAP,
			'default' => 0,
			'group'   => 'hero',
		],
		[
			'key'     => 'hero_padding_x',
			'var'     => '--zhp-hero-pad-x-scale',
			'mode'    => self::MODE_SCALE,
			'default' => 100,
			'group'   => 'hero',
		],
		/*
		 * Measure of the hero copy, in pixels. Widening Content Width alone
		 * leaves the heading and sub-heading in a 600px column inside a very
		 * wide banner, which is the other half of why the hero looked empty
		 * on a 4K screen. 600 reproduces the shipped design, emitting nothing.
		 */
		[
			'key'     => 'hero_text_width',
			'var'     => '--zhp-hero-copy-max',
			'mode'    => self::MODE_PX,
			'default' => 600,
			'min'     => 320,
			'max'     => 1400,
			'step'    => 20,
			'group'   => 'hero',
		],

		// ── Product sections ──────────────────────────────────────────
		[
			'key'     => 'section_gap',
			'var'     => '--zhp-section-scale',
			'mode'    => self::MODE_SCALE,
			'default' => 100,
			'group'   => 'sections',
		],
		[
			'key'     => 'header_gap',
			'var'     => '--zhp-header-scale',
			'mode'    => self::MODE_SCALE,
			'default' => 100,
			'group'   => 'sections',
		],
		[
			'key'     => 'section_below_gap',
			'var'     => '--zhp-gap-section',
			'mode'    => self::MODE_GAP,
			'default' => 0,
			'group'   => 'sections',
		],
		[
			'key'     => 'section_side_padding',
			'var'     => '--zhp-container-pad-scale',
			'mode'    => self::MODE_SCALE,
			'default' => 100,
			'group'   => 'sections',
		],
		/*
		 * Width of the content column, as a percentage of the viewport.
		 *
		 * 0 is the default and the one value that emits nothing, so the
		 * shipped 1280px cap stays exactly as authored. Any other value is
		 * emitted as a vw length and therefore keeps adjusting on every
		 * screen size instead of stopping at a fixed pixel figure. The
		 * stylesheet only consumes it above 768px, so phones and tablets
		 * keep the 4px side gap that lines up with the Connection Engine.
		 */
		[
			'key'     => 'content_width',
			'var'     => '--zhp-content-width',
			'mode'    => self::MODE_VW,
			'default' => 0,
			'min'     => 0,
			'max'     => 100,
			'step'    => 1,
			'group'   => 'sections',
		],

		// ── Full-bleed bands ──────────────────────────────────────────
		[
			'key'     => 'band_gap',
			'var'     => '--zhp-band-scale',
			'mode'    => self::MODE_SCALE,
			'default' => 100,
			'group'   => 'bands',
		],
		[
			'key'     => 'promo_banner_below_gap',
			'var'     => '--zhp-gap-promo-banner',
			'mode'    => self::MODE_GAP,
			'default' => 0,
			'group'   => 'bands',
		],
		[
			'key'     => 'newsletter_below_gap',
			'var'     => '--zhp-gap-newsletter',
			'mode'    => self::MODE_GAP,
			'default' => 0,
			'group'   => 'bands',
		],
		[
			'key'     => 'footer_cta_below_gap',
			'var'     => '--zhp-gap-footer-cta',
			'mode'    => self::MODE_GAP,
			'default' => 0,
			'group'   => 'bands',
		],
	];

	/**
	 * Return the raw control definitions.
	 *
	 * @since  1.45.0
	 * @return array<int, array<string, mixed>>
	 */
	public static function controls(): array {
		return self::CONTROLS;
	}

	/**
	 * Return [ min, max, step ] for a control.
	 *
	 * Defaults reproduce the original 0-100 by 5 range, so the controls that
	 * predate per-control bounds need no entries of their own. The sanitiser,
	 * the CSS emitter and the settings markup all read this, which is what
	 * stops a range being restated in three places and drifting apart.
	 *
	 * @since  1.50.0
	 * @param  array<string, mixed> $control One entry from self::CONTROLS.
	 * @return array{0:int,1:int,2:int}
	 */
	public static function bounds( array $control ): array {
		return [
			isset( $control['min'] ) ? (int) $control['min'] : 0,
			isset( $control['max'] ) ? (int) $control['max'] : 100,
			isset( $control['step'] ) ? (int) $control['step'] : 5,
		];
	}

	/**
	 * Return every control's default, keyed by setting name.
	 *
	 * Consumed by Admin\Settings and by the activation seed in Core\Plugin so
	 * that neither has to restate these numbers.
	 *
	 * @since  1.45.0
	 * @return array<string, int>
	 */
	public static function defaults(): array {
		$defaults = [];

		foreach ( self::CONTROLS as $control ) {
			$defaults[ $control['key'] ] = (int) $control['default'];
		}

		return $defaults;
	}

	/**
	 * Clamp a raw submitted value to the usable range.
	 *
	 * Clamped rather than merely cast: these numbers are interpolated into a
	 * CSS declaration, so the bounds are what guarantee the output is always
	 * sane. 0 is a legitimate value for every control here - it means no gap,
	 * or no scaling at all - so unlike the font-size settings there is no
	 * "automatic" sentinel to preserve and the whole 0-100 range is valid.
	 *
	 * A key absent from the input falls back to that control's default rather
	 * than to zero, so a partial save cannot silently flatten spacing that
	 * nobody touched.
	 *
	 * @since  1.45.0
	 * @param  array<string, mixed> $raw Raw input, typically the AJAX payload.
	 * @return array<string, int>
	 */
	public static function sanitize( array $raw ): array {
		$clean = [];

		foreach ( self::CONTROLS as $control ) {
			$key     = $control['key'];
			$default = (int) $control['default'];

			if ( ! isset( $raw[ $key ] ) || ! is_numeric( $raw[ $key ] ) ) {
				$clean[ $key ] = $default;
				continue;
			}

			list( $min, $max ) = self::bounds( $control );

			$clean[ $key ] = max( $min, min( $max, (int) $raw[ $key ] ) );
		}

		return $clean;
	}

	/**
	 * Build the CSS custom property declarations for the current settings.
	 *
	 * A control at its default emits nothing at all. That is what keeps an
	 * untouched install rendering from the stylesheet exactly as authored,
	 * with no inline override to reason about, and it means this method
	 * usually returns an empty string.
	 *
	 * @since  1.45.0
	 * @param  array<string, mixed> $settings Stored plugin settings.
	 * @return string Declarations such as "--zhp-section-scale:0.5;", or ''.
	 */
	public static function declarations( array $settings ): string {
		$declarations = '';

		foreach ( self::CONTROLS as $control ) {
			$key = $control['key'];

			if ( ! isset( $settings[ $key ] ) || ! is_numeric( $settings[ $key ] ) ) {
				continue;
			}

			list( $min, $max ) = self::bounds( $control );

			$value = max( $min, min( $max, (int) $settings[ $key ] ) );

			if ( (int) $control['default'] === $value ) {
				continue;
			}

			if ( self::MODE_VW === $control['mode'] ) {
				$declarations .= $control['var'] . ':' . $value . 'vw;';
				continue;
			}

			if ( self::MODE_PX === $control['mode'] ) {
				$declarations .= $control['var'] . ':' . $value . 'px;';
				continue;
			}

			if ( self::MODE_COUNT === $control['mode'] ) {
				$declarations .= $control['var'] . ':' . $value . ';';
				continue;
			}

			// Trailing zeroes would be harmless but noisy in the page source.
			$ratio = rtrim( rtrim( number_format( $value / 100, 2, '.', '' ), '0' ), '.' );

			if ( '' === $ratio ) {
				$ratio = '0';
			}

			if ( self::MODE_GAP === $control['mode'] ) {
				$declarations .= $control['var'] . ':calc(var(--zhp-gap-max) * ' . $ratio . ');';
				continue;
			}

			$declarations .= $control['var'] . ':' . $ratio . ';';
		}

		return $declarations;
	}

	/**
	 * Return translated labels and descriptions, keyed by setting name.
	 *
	 * Separate from self::CONTROLS on purpose. A class constant cannot call
	 * __(), and more importantly the front end reads CONTROLS on every page
	 * view - keeping the strings out of it means no translation files are
	 * loaded to render an inline style that contains no text.
	 *
	 * @since  1.45.0
	 * @return array<string, array<string, string>>
	 */
	public static function labels(): array {
		return [
			'content_width' => [
				'label' => __( 'Content Width', 'zymarg-homepage' ),
				'desc'  => __( 'How much of the screen width the page content uses, as a percentage of the viewport, on screens above 768px. 0 is the design as shipped, which caps content at a fixed 1280px - on a 2560px or 4K monitor that leaves roughly half the screen empty while the hero banner behind it still stretches edge to edge. Any other value is a percentage that keeps adjusting itself to whatever screen the page is opened on, so 92 fills 92 percent of a 1440px laptop and of an 8K display alike. 100 runs content to the very edges, inset only by Side Padding. Phones are unaffected, so the Side Gap (Mobile) alignment with the Connection Engine is preserved. Tablets and laptops follow this control too, which keeps the homepage consistent with the matching Content Width controls in the Connection Engine and Store Page plugins - set all three to the same value for a consistent site. For grid sections this makes each card wider rather than adding cards, so raise Cards Per Row (Desktop) to 5 or 6 to match; the category carousel uses fixed-width cards and simply reveals more of them.', 'zymarg-homepage' ),
			],
			'hero_text_width' => [
				'label' => __( 'Hero Text Width', 'zymarg-homepage' ),
				'desc'  => __( 'Widest the hero heading and sub-heading are allowed to run, in pixels. The number you type is the measure. 600 is the design as shipped. This is the companion to Content Width: widening the content alone leaves the hero copy in a narrow column inside a very wide banner, which is what makes a full-bleed hero look empty on a large screen. Raising it much past roughly 900 makes the headline harder to read, because the line becomes longer than the eye comfortably scans.', 'zymarg-homepage' ),
			],
			'master_gap' => [
				'label' => __( 'Master Gap', 'zymarg-homepage' ),
				'desc'  => __( 'Scales every vertical gap on the homepage at once - section spacing, heading spacing, band padding and all the Gap Below controls. 100 is the design as shipped, 200 doubles the breathing room, 50 halves it, 0 closes it up completely. Each individual control below still applies on top of this, so use this to set the overall rhythm and the others to fine-tune one spot. This does not affect horizontal spacing; Side Gap and Side Padding handle that.', 'zymarg-homepage' ),
			],
			'card_gap' => [
				'label' => __( 'Card Gap', 'zymarg-homepage' ),
				'desc'  => __( 'Space between cards, both across a row and between rows, as a percentage of the built-in spacing - 12px on phones, tightening to 10px on small phones, and up to 32px on wide grids. 100 is the design as shipped. Lowering this fits more card into the same width without changing how many cards there are; raising it separates them.', 'zymarg-homepage' ),
			],
			'cards_per_row_desktop' => [
				'label' => __( 'Cards Per Row (Desktop)', 'zymarg-homepage' ),
				'desc'  => __( 'How many cards sit side by side on screens above 1024px. 4 is the design as shipped. This now decides the column count outright, replacing a figure that used to be fixed in the code and could not be reached from this screen.', 'zymarg-homepage' ),
			],
			'cards_per_row_tablet' => [
				'label' => __( 'Cards Per Row (Tablet)', 'zymarg-homepage' ),
				'desc'  => __( 'How many cards sit side by side between 900px and 1024px. 3 is the design as shipped.', 'zymarg-homepage' ),
			],
			'cards_per_row_mobile' => [
				'label' => __( 'Cards Per Row (Mobile)', 'zymarg-homepage' ),
				'desc'  => __( 'How many cards sit side by side on screens up to 900px. 2 is the design as shipped, and matches the Connection Engine browse page. Applies to sections drawn by the Product Grid engine as well as to the ones this plugin draws itself, so the whole homepage stays consistent.', 'zymarg-homepage' ),
			],
			'side_gap_mobile' => [
				'label' => __( 'Side Gap (Mobile)', 'zymarg-homepage' ),
				'desc'  => __( 'Space between the page content and each screen edge on phones, in pixels. The number you type is the gap. 4 is the default and matches the Connection Engine, so a homepage section and a browse page line up on the same phone - set both plugins to the same figure to keep them aligned. Side Padding still scales this, and tablet and desktop spacing is unaffected.', 'zymarg-homepage' ),
			],
			'hero_height' => [
				'label' => __( 'Hero Height', 'zymarg-homepage' ),
				'desc'  => __( 'How tall the hero banner is, as a percentage of its built-in height. 100 is the design as shipped, 50 halves it, 0 shrinks the hero to fit its own text. This is the setting to use if the banner feels too tall - the hero is sized by a minimum height, so this is what actually moves it.', 'zymarg-homepage' ),
			],
			'hero_padding' => [
				'label' => __( 'Hero Padding', 'zymarg-homepage' ),
				'desc'  => __( 'Breathing room above and below the hero text, as a percentage of the built-in 64 pixels. Note that this has no visible effect until Hero Height is low enough that the text, rather than the minimum height, is what decides how tall the hero is.', 'zymarg-homepage' ),
			],
			'hero_below_gap' => [
				'label' => __( 'Gap Below Hero', 'zymarg-homepage' ),
				'desc'  => __( 'Separation between the hero and whatever follows it. 0 is the design as shipped, where they meet directly; 100 leaves a full band of space. This is space between the two blocks, not padding inside either of them.', 'zymarg-homepage' ),
			],
			'hero_above_gap' => [
				'label' => __( 'Gap Above Hero', 'zymarg-homepage' ),
				'desc'  => __( 'Space between the top of the page and the hero banner. 0 is the design as shipped, where the hero sits flush against whatever the theme puts above it - usually the header. Raise this to let the page background show through as a strip above the banner. This is space outside the hero, so it does not make the banner itself any taller.', 'zymarg-homepage' ),
			],
			'hero_side_gap' => [
				'label' => __( 'Gap Beside Hero', 'zymarg-homepage' ),
				'desc'  => __( 'Inset from the left and right screen edges. 0 is the design as shipped, where the hero is full-bleed and touches both edges. Raising this pulls the banner in from the sides so the page background frames it, which is how to get an inset or card-style hero. The hero text stays centred as the banner narrows.', 'zymarg-homepage' ),
			],
			'hero_padding_x' => [
				'label' => __( 'Hero Padding (Sides)', 'zymarg-homepage' ),
				'desc'  => __( 'Space between the hero text and the left and right edges of the banner, as a percentage of the site container padding. 100 is the design as shipped, where the hero text lines up with every other section. Unlike Gap Beside Hero this moves the text inside the banner rather than the banner itself, and unlike Hero Padding it works at any Hero Height. Lowering it below 100 will break alignment with the sections underneath.', 'zymarg-homepage' ),
			],
			'section_gap' => [
				'label' => __( 'Section Gap', 'zymarg-homepage' ),
				'desc'  => __( 'Vertical space inside each section, as a percentage of the built-in spacing. 100 is the design as shipped, 50 halves it, 0 removes it. Below roughly 20 the gap becomes smaller than the space between two rows of cards, so neighbouring sections start to read as one continuous grid.', 'zymarg-homepage' ),
			],
			'header_gap' => [
				'label' => __( 'Header Gap', 'zymarg-homepage' ),
				'desc'  => __( 'Space between a section heading and the product cards below it, as a percentage of the built-in 24 pixels. 100 is the design as shipped, 0 sits the cards directly under the heading. Separate from Section Gap, which controls whole sections.', 'zymarg-homepage' ),
			],
			'section_below_gap' => [
				'label' => __( 'Gap Between Sections', 'zymarg-homepage' ),
				'desc'  => __( 'Extra separation between one product section and the next, on top of their own spacing. 0 is the design as shipped. Use this when sections need to read as distinct blocks rather than one long grid.', 'zymarg-homepage' ),
			],
			'section_side_padding' => [
				'label' => __( 'Side Padding', 'zymarg-homepage' ),
				'desc'  => __( 'Space between page content and the left and right screen edges, as a percentage of the built-in padding - 16px on phones, 24px on tablets, 32px on desktop. 100 is the design as shipped; 0 runs content right to the edges. This is the one horizontal control that applies to everything at once: every section, and the content inside the full-bleed bands. The hero has its own Hero Padding (Sides), so lowering this alone will pull the sections out of alignment with the hero.', 'zymarg-homepage' ),
			],
			'band_gap' => [
				'label' => __( 'Band Padding', 'zymarg-homepage' ),
				'desc'  => __( 'Vertical padding INSIDE the three full-bleed bands - Newsletter, Footer CTA and Promo Banner - as a percentage of the built-in spacing. 100 is the design as shipped. Raising this makes the coloured bands taller; it does not push them apart. To separate them, use the Gap Below controls instead.', 'zymarg-homepage' ),
			],
			'promo_banner_below_gap' => [
				'label' => __( 'Gap Below Promo Banner', 'zymarg-homepage' ),
				'desc'  => __( 'Separation between the Promo Banner and whatever follows it. 0 is the design as shipped, where they meet directly.', 'zymarg-homepage' ),
			],
			'newsletter_below_gap' => [
				'label' => __( 'Gap Below Newsletter', 'zymarg-homepage' ),
				'desc'  => __( 'Separation between the Newsletter band and whatever follows it. 0 is the design as shipped, which is why the Newsletter and the Footer CTA meet at a hard seam with no space between the two colours. Raise this to part them.', 'zymarg-homepage' ),
			],
			'footer_cta_below_gap' => [
				'label' => __( 'Gap Below Footer CTA', 'zymarg-homepage' ),
				'desc'  => __( 'Separation between the Footer CTA band and the bottom of the homepage. 0 is the design as shipped; raise it to leave space beneath the band.', 'zymarg-homepage' ),
			],
		];
	}
}
