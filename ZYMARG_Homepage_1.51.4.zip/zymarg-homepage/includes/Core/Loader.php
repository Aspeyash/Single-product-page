<?php
/**
 * ZYMARG Homepage – PSR-4 Class Autoloader
 *
 * Maps the ZYMARGHomepage namespace to includes/ so every class in this
 * plugin is loaded on demand without manual require_once calls.
 *
 * Mapping example:
 *   ZYMARGHomepage\Features\Hero\Feature
 *   → {PLUGIN_DIR}/includes/Features/Hero/Feature.php
 *
 * @package ZYMARGHomepage\Core
 * @since   1.0.1
 * @version 1.1.0
 */

namespace ZYMARGHomepage\Core;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Loader
 *
 * Registers a PSR-4 compatible autoloader for the ZYMARGHomepage namespace.
 * Must be the first class file required; all other classes rely on it.
 */
final class Loader {

    /**
     * Root namespace prefix this autoloader handles.
     */
    private const NAMESPACE_PREFIX = 'ZYMARGHomepage\\';

    /**
     * Base directory that the namespace prefix maps to.
     * Resolved from ZYMARG_HP_PLUGIN_DIR (set in zymarg-homepage.php).
     */
    private const BASE_DIR_SUFFIX = 'includes/';

    /**
     * Register the autoloader with PHP's SPL autoloader stack.
     *
     * Called once from zymarg-homepage.php immediately after this file
     * is required. Prepended to the stack so it runs before any other
     * autoloader and avoids interfering with theme or other plugin loaders.
     *
     * @since 1.0.1
     * @return void
     */
    public static function register(): void {
        spl_autoload_register( [ static::class, 'autoload' ], true, true );
    }

    /**
     * Resolve and load a class file.
     *
     * @since 1.0.1
     * @param string $class Fully qualified class name.
     * @return void
     */
    public static function autoload( string $class ): void {
        // Bail early if the class does not belong to this plugin.
        if ( 0 !== strpos( $class, self::NAMESPACE_PREFIX ) ) {
            return;
        }

        // Strip the root namespace prefix to get the relative class path.
        $relative_class = substr( $class, strlen( self::NAMESPACE_PREFIX ) );

        // Build the absolute file path.
        $file = ZYMARG_HP_PLUGIN_DIR
            . self::BASE_DIR_SUFFIX
            . str_replace( '\\', DIRECTORY_SEPARATOR, $relative_class )
            . '.php';

        if ( is_readable( $file ) ) {
            require_once $file;
        }
    }
}
