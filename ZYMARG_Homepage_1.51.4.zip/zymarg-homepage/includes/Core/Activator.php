<?php
/**
 * ZYMARG Homepage – Activator
 *
 * Runs once when the plugin is activated via register_activation_hook().
 * Responsible for automatically configuring WordPress so the plugin
 * homepage renders on the site front page with zero manual setup.
 *
 * Resolution priority:
 *   1. WordPress already has a static front page configured
 *      → store its ID, leave WordPress settings untouched.
 *   2. A published page with the slug 'home' exists
 *      → set it as the static front page.
 *   3. Neither exists
 *      → create a new published 'Home' page and set it as the front page.
 *
 * In all three cases the page ID is stored in the `zymarg_hp_front_page_id`
 * option so HomepageController can reference it. A `zymarg_hp_page_created`
 * flag records whether we created the page (for potential cleanup).
 *
 * This class intentionally does NOT modify the active theme, add page
 * content, or inject shortcodes. The front page takeover is handled at
 * runtime via the `the_content` filter in HomepageController.
 *
 * @package ZYMARGHomepage\Core
 * @since   1.7.3
 * @version 1.7.3
 */

namespace ZYMARGHomepage\Core;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Activator
 *
 * Handles the one-time front page auto-setup on plugin activation.
 *
 * @since 1.7.3
 */
final class Activator {

    /**
     * Run the activation setup.
     *
     * Called from Plugin::activate(). Finds or creates the front page
     * and ensures WordPress is configured to serve it as a static front page.
     *
     * Safe to call multiple times — uses conditional checks so repeated
     * activation (e.g. deactivate → re-activate) does not create duplicate
     * pages or overwrite a manually configured front page.
     *
     * @since 1.7.3
     * @return void
     */
    public static function run(): void {

        $page_id = self::resolve_front_page();

        if ( $page_id < 1 ) {
            // Could not resolve or create a page — leave WordPress settings alone.
            return;
        }

        // Store the page ID so other subsystems can reference it.
        update_option( 'zymarg_hp_front_page_id', $page_id );

        // Point WordPress at this page as the static front page.
        // Only update if the settings are not already correct to avoid
        // triggering unnecessary cache flushes.
        if (
            'page' !== get_option( 'show_on_front' ) ||
            (int) get_option( 'page_on_front' ) !== $page_id
        ) {
            update_option( 'show_on_front', 'page' );
            update_option( 'page_on_front', $page_id );
        }
    }

    // ──────────────────────────────────────────────────────────────
    //  Private helpers
    // ──────────────────────────────────────────────────────────────

    /**
     * Resolve the front page ID using the three-step priority chain.
     *
     * @since 1.7.3
     * @return int Page ID, or 0 on failure.
     */
    private static function resolve_front_page(): int {

        // ── Priority 1: static front page already configured ──────
        if ( 'page' === get_option( 'show_on_front' ) ) {
            $existing_id = (int) get_option( 'page_on_front' );
            if (
                $existing_id > 0 &&
                get_post( $existing_id ) instanceof \WP_Post
            ) {
                // WordPress already points at a real page — leave everything
                // as-is, just record the ID. Do not set zymarg_hp_page_created
                // so deactivation knows not to delete this page.
                update_option( 'zymarg_hp_page_created', false );
                return $existing_id;
            }
        }

        // ── Priority 2: published page with slug 'home' exists ────
        $home_page = get_page_by_path( 'home', OBJECT, 'page' );
        if (
            $home_page instanceof \WP_Post &&
            'publish' === $home_page->post_status
        ) {
            update_option( 'zymarg_hp_page_created', false );
            return $home_page->ID;
        }

        // ── Priority 3: create a new 'Home' page ──────────────────
        $page_id = wp_insert_post(
            [
                'post_title'   => _x( 'Home', 'auto-created front page title', 'zymarg-homepage' ),
                'post_name'    => 'home',
                'post_status'  => 'publish',
                'post_type'    => 'page',
                'post_content' => '', // Content is provided by the plugin at runtime.
                'post_author'  => get_current_user_id() ?: 1,
            ],
            true // Return WP_Error on failure.
        );

        if ( is_wp_error( $page_id ) || $page_id < 1 ) {
            return 0;
        }

        // Flag that WE created this page so we could clean it up later.
        update_option( 'zymarg_hp_page_created', true );
        return $page_id;
    }
}
