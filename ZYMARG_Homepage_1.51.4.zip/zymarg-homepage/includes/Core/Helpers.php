<?php
/**
 * ZYMARG Homepage – Shared Helpers
 *
 * Stateless utility functions used across multiple features and components.
 * All helpers are static methods on the Helpers class — no global functions,
 * no procedural prefixes.
 *
 * Only add a helper here when the same logic is genuinely needed in two or
 * more different places. Single-use helpers belong in their own Feature class.
 *
 * @package ZYMARGHomepage\Core
 * @since   1.0.1
 * @version 1.9.5
 */

namespace ZYMARGHomepage\Core;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Helpers
 *
 * Pure utility methods. No constructor, no state.
 */
final class Helpers {

    // ──────────────────────────────────────────────────────────────
    //  Settings
    // ──────────────────────────────────────────────────────────────

    /**
     * Check whether the plugin's master switch is enabled.
     *
     * When disabled, HomepageController outputs nothing and all assets
     * are suppressed. Set via the admin Settings page.
     *
     * @since 1.0.1
     * @return bool
     */
    public static function is_plugin_enabled(): bool {
        $settings = get_option( 'zymarg_hp_settings', [] );
        return ! isset( $settings['master_enabled'] ) || (bool) $settings['master_enabled'];
    }

    /**
     * Retrieve a single global setting value.
     *
     * @since 1.0.1
     * @param string $key     Setting key inside the zymarg_hp_settings array.
     * @param mixed  $default Default value when the key is absent.
     * @return mixed
     */
    public static function get_setting( string $key, mixed $default = null ): mixed {
        $settings = get_option( 'zymarg_hp_settings', [] );
        return $settings[ $key ] ?? $default;
    }

    // ──────────────────────────────────────────────────────────────
    //  Image helpers
    // ──────────────────────────────────────────────────────────────

    /**
     * Return a safe placeholder image URL when no real image exists.
     *
     * Uses an SVG data URI so there is no external HTTP request and no
     * layout shift. The placeholder respects the ZYMARG colour palette.
     *
     * @since 1.0.1
     * @return string Data URI string.
     */
    public static function placeholder_image_url(): string {
        // Soft purple rectangle — matches --zhp-color-container (#EAEDFF).
        return 'data:image/svg+xml;charset=utf-8,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%220 0 400 300%22%3E%3Crect width%3D%22400%22 height%3D%22300%22 fill%3D%22%23EAEDFF%22%2F%3E%3C%2Fsvg%3E';
    }

    /**
     * Build a product thumbnail URL, falling back gracefully.
     *
     * @since 1.0.1
     * @param int    $product_id WooCommerce product ID.
     * @param string $size       Image size slug (default: 'woocommerce_thumbnail').
     * @return string Absolute image URL.
     */
    public static function product_image_url( int $product_id, string $size = 'woocommerce_thumbnail' ): string {
        $thumbnail_id = (int) get_post_thumbnail_id( $product_id );

        if ( $thumbnail_id > 0 ) {
            $src = wp_get_attachment_image_url( $thumbnail_id, $size );
            if ( $src ) {
                return $src;
            }
        }

        // WooCommerce may not be active — never call its functions unguarded.
        if ( function_exists( 'wc_placeholder_img_src' ) ) {
            return (string) wc_placeholder_img_src( $size );
        }

        return self::placeholder_image_url();
    }

    // ──────────────────────────────────────────────────────────────
    //  Formatting helpers
    // ──────────────────────────────────────────────────────────────

    /**
     * Truncate a string to a maximum number of words.
     *
     * @since 1.0.1
     * @param string $text      Input string.
     * @param int    $max_words Maximum number of words to keep.
     * @param string $ellipsis  Appended when text is truncated. Default '…'.
     * @return string
     */
    public static function truncate_words( string $text, int $max_words, string $ellipsis = '…' ): string {
        $text  = wp_strip_all_tags( $text );
        $words = preg_split( '/\s+/u', trim( $text ), -1, PREG_SPLIT_NO_EMPTY );

        if ( count( $words ) <= $max_words ) {
            return $text;
        }

        return implode( ' ', array_slice( $words, 0, $max_words ) ) . $ellipsis;
    }

    /**
     * Format a WooCommerce price for display.
     *
     * Delegates to wc_price() when WooCommerce is active; falls back to a
     * simple currency-prefixed string otherwise.
     *
     * @since 1.0.1
     * @param float|string $price Raw price value.
     * @return string HTML price string (already escaped by WooCommerce).
     */
    public static function format_price( float|string $price ): string {
        if ( function_exists( 'wc_price' ) ) {
            return wc_price( $price );
        }

        // WooCommerce inactive — get_woocommerce_currency_symbol() would fatal.
        $symbol = function_exists( 'get_woocommerce_currency_symbol' )
            ? get_woocommerce_currency_symbol()
            : '';

        return esc_html( $symbol . number_format( (float) $price, 2 ) );
    }

    // ──────────────────────────────────────────────────────────────
    //  Template helpers
    // ──────────────────────────────────────────────────────────────

    /**
     * Render an attribute string from an associative array.
     *
     * Keys and values are escaped with esc_attr(). Null values are
     * skipped; boolean true emits the attribute name only (for e.g. `disabled`).
     *
     * @since 1.0.1
     * @param array<string, scalar|null> $attrs Attribute name → value map.
     * @return string Ready-to-print attribute string (leading space included).
     */
    public static function build_attrs( array $attrs ): string {
        $parts = [];

        foreach ( $attrs as $name => $value ) {
            if ( null === $value ) {
                continue;
            }

            $name = esc_attr( $name );

            if ( true === $value ) {
                $parts[] = $name;
            } else {
                $parts[] = $name . '="' . esc_attr( (string) $value ) . '"';
            }
        }

        return $parts ? ' ' . implode( ' ', $parts ) : '';
    }

    /**
     * Return the CSS class string for a section wrapper.
     *
     * Ensures the 'zhp-' prefix is present on every class and deduplicates.
     *
     * @since 1.0.1
     * @param string   $base         Base section class (e.g. 'hero', 'categories').
     * @param string[] $extra_classes Additional modifier classes.
     * @return string Space-separated class string.
     */
    public static function section_class( string $base, array $extra_classes = [] ): string {
        $classes   = array_merge( [ 'zhp-section', "zhp-section--{$base}" ], $extra_classes );
        $sanitised = array_map( 'sanitize_html_class', array_unique( $classes ) );
        return implode( ' ', array_filter( $sanitised ) );
    }
}
