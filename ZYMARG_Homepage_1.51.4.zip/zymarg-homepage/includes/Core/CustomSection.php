<?php
/**
 * ZYMARG Homepage – Custom Section Renderer
 *
 * Lets an administrator replace a single section's markup with their own
 * hand-written design, pasted into the section's admin panel.
 *
 * The pasted code is expected to be a COMPLETE standalone HTML document — the
 * kind of file a developer hands over, which opens and works on its own in a
 * browser. That is deliberately the easiest thing for a human to produce and
 * to preview, but a whole document cannot be dropped into the middle of a
 * WordPress page as-is. Three things in a standalone file are actively
 * destructive when they land inside an existing page:
 *
 *   1. The document scaffolding (<!DOCTYPE>, <html>, <head>, <body>) is
 *      meaningless inside a page. Browsers discard the tags but hoist whatever
 *      was inside <head> into unpredictable places.
 *   2. A universal reset such as `* { margin: 0 }` does not stop at the
 *      author's design — it strips the theme's header, menu and footer too.
 *   3. `html, body { overflow: hidden; height: 100dvh; display: flex }` breaks
 *      the entire site: the page can no longer scroll, so everything below the
 *      fold becomes unreachable.
 *
 * So this class does not merely sanitise; it TRANSLATES. It unwraps the
 * document, lifts the CSS out, rewrites every selector so it cannot escape the
 * section, and neutralises the handful of declarations that would otherwise
 * escape via `html`/`body`. The author's file stays as they wrote it; the
 * adaptation happens at render time.
 *
 * Scripts are deliberately allowed. Real designs are interactive — the tabs,
 * sliders and counters in a handed-over file depend on them — and only users
 * who can already install plugins may save here, so forbidding <script> would
 * prevent nothing while breaking the actual use case. Filter
 * `zhp_custom_section_allow_scripts` to false to strip them anyway.
 *
 * @package ZYMARGHomepage\Core
 * @since   1.18.0
 * @version 1.40.0
 */

namespace ZYMARGHomepage\Core;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class CustomSection
 *
 * Adapts a standalone HTML document into a single homepage section.
 */
final class CustomSection {

    /**
     * Settings keys that hold raw author code and must never be run through
     * sanitize_text_field() on save. SectionManager consults this list.
     *
     * `header_html` was missing from this list until 1.25.0. Several sections
     * had offered a "Custom Header HTML" box since 1.7.0, but because the key
     * was not listed here every value pasted into it went through
     * sanitize_text_field() in SectionManager::sanitise_settings(), which
     * strips every tag. The markup was destroyed on save and the box appeared
     * to do nothing. The templates that read it were correct all along; only
     * this list was wrong.
     *
     * @since 1.18.0
     * @var string[]
     */
    public const RAW_KEYS = [ 'custom_html', 'custom_css', 'header_html', 'explore_html' ];

    /**
     * Declarations that are dropped when they appear on html/body/:root.
     *
     * These are the properties that reach outside the section and break the
     * surrounding page. Everything else on those selectors (background,
     * colour, font) is harmless once retargeted at the section wrapper.
     *
     * @since 1.18.0
     * @var string[]
     */
    private const UNSAFE_ROOT_PROPS = [
        'overflow', 'overflow-x', 'overflow-y',
        'height', 'min-height', 'max-height',
        'width', 'min-width', 'max-width',
        'position', 'display', 'margin', 'padding',
        'justify-content', 'align-items', 'inset',
        'top', 'right', 'bottom', 'left',
    ];

    /**
     * Whether this section should render the author's design instead of the
     * plugin's own template.
     *
     * An empty code box counts as inactive, so switching the dropdown to
     * "custom" before pasting anything cannot blank out the section.
     *
     * @since 1.18.0
     * @param array $settings Saved section settings.
     * @return bool
     */
    public static function is_active( array $settings ): bool {
        $source = $settings['design_source'] ?? 'plugin';

        if ( 'custom' !== $source ) {
            return false;
        }

        return '' !== trim( (string) ( $settings['custom_html'] ?? '' ) );
    }

    /**
     * Render the author's design for one section.
     *
     * @since 1.18.0
     * @param string $slug     Section slug, used to build the scope class.
     * @param array  $settings Saved section settings.
     * @param array  $vars     Scalar placeholders, e.g. [ 'heading' => '…' ].
     * @param array  $loops    Repeating placeholders, e.g. [ 'categories' => [ … ] ].
     * @return string Section HTML, or '' when there is nothing to render.
     */
    public static function render( string $slug, array $settings, array $vars = [], array $loops = [] ): string {
        $code = (string) ( $settings['custom_html'] ?? '' );

        if ( '' === trim( $code ) ) {
            return '';
        }

        $scope = 'zhp-custom--' . sanitize_html_class( $slug );

        // Pull the CSS out of the document before touching the markup, so that
        // stylesheet contents are never mistaken for placeholders or tags.
        $css  = self::extract_css( $code );
        $html = self::extract_markup( $code );

        // The separate "Custom CSS" box is appended last so it can override the
        // styles that came inline with the document.
        $extra = trim( (string) ( $settings['custom_css'] ?? '' ) );
        if ( '' !== $extra ) {
            $css .= "\n" . $extra;
        }

        if ( ! apply_filters( 'zhp_custom_section_allow_scripts', true, $slug ) ) {
            $html = self::strip_scripts( $html );
        }

        $html = self::fill_loops( $html, $loops );
        $html = self::fill_vars( $html, $vars );
        $html = self::strip_unused_placeholders( $html );

        $css = self::scope_css( $css, $scope );

        $out = '<section class="zhp-custom ' . esc_attr( $scope ) . '" data-zhp-custom="' . esc_attr( $slug ) . '">';

        if ( '' !== trim( $css ) ) {
            // Printed inline rather than enqueued because the CSS is per
            // section, changes whenever the author edits the box, and has no
            // stable file on disk to enqueue.
            $out .= '<style>' . $css . '</style>';
        }

        $out .= $html . '</section>';

        /**
         * Filter the finished custom section markup.
         *
         * @since 1.18.0
         * @param string $out   Rendered section HTML.
         * @param string $slug  Section slug.
         * @param array  $vars  Scalar placeholders that were available.
         */
        return (string) apply_filters( 'zhp_custom_section_html', $out, $slug, $vars );
    }

    /* ---------------------------------------------------------------------
     * Document unwrapping
     * ------------------------------------------------------------------ */

    /**
     * Collect every stylesheet found in the document, in source order.
     *
     * @since 1.18.0
     * @param string $code Raw pasted document.
     * @return string Concatenated CSS.
     */
    private static function extract_css( string $code ): string {
        if ( ! preg_match_all( '#<style\b[^>]*>(.*?)</style>#is', $code, $matches ) ) {
            return '';
        }

        return implode( "\n", $matches[1] );
    }

    /**
     * Reduce a standalone document to the markup that belongs inside a page.
     *
     * Keeps <link rel="stylesheet"> tags from the head — browsers accept those
     * in the body, and dropping them would silently break a design that loads
     * its font or icon set that way.
     *
     * @since 1.18.0
     * @param string $code Raw pasted document.
     * @return string Markup safe to place inside a page.
     */
    private static function extract_markup( string $code ): string {
        $links = '';

        if ( preg_match( '#<head\b[^>]*>(.*?)</head>#is', $code, $head )
            && preg_match_all( '#<link\b[^>]*>#i', $head[1], $found )
        ) {
            foreach ( $found[0] as $tag ) {
                if ( false !== stripos( $tag, 'stylesheet' ) || false !== stripos( $tag, 'preconnect' ) ) {
                    $links .= $tag;
                }
            }
        }

        // Prefer the body contents when the document has one.
        if ( preg_match( '#<body\b[^>]*>(.*)</body>#is', $code, $body ) ) {
            $code = $body[1];
        }

        // Elements whose content must go, not just their tags.
        $code = preg_replace( '#<style\b[^>]*>.*?</style>#is', '', $code );
        $code = preg_replace( '#<title\b[^>]*>.*?</title>#is', '', (string) $code );
        $code = preg_replace( '#<!DOCTYPE[^>]*>#i', '', (string) $code );
        $code = preg_replace( '#<!--\[if.*?<!\[endif\]-->#is', '', (string) $code );

        // Remaining document-level tags carry no meaning inside a page.
        $code = preg_replace(
            '#</?(?:html|head|body|meta|base|title)\b[^>]*>#i',
            '',
            (string) $code
        );

        return $links . trim( (string) $code );
    }

    /**
     * Remove script elements and inline event handlers.
     *
     * Only used when zhp_custom_section_allow_scripts is filtered to false.
     *
     * @since 1.18.0
     * @param string $html Markup.
     * @return string
     */
    private static function strip_scripts( string $html ): string {
        $html = preg_replace( '#<script\b[^>]*>.*?</script>#is', '', $html );
        $html = preg_replace( '#<script\b[^>]*/?>#i', '', (string) $html );
        $html = preg_replace( '#\son[a-z]+\s*=\s*"[^"]*"#i', '', (string) $html );
        $html = preg_replace( "#\\son[a-z]+\\s*=\\s*'[^']*'#i", '', (string) $html );

        return (string) $html;
    }

    /* ---------------------------------------------------------------------
     * Placeholders
     * ------------------------------------------------------------------ */

    /**
     * Expand repeating blocks: {{#categories}} … {{/categories}}.
     *
     * The block body is repeated once per row, with that row's keys filled in.
     *
     * @since 1.18.0
     * @param string $html  Markup.
     * @param array  $loops Map of loop name => list of associative rows.
     * @return string
     */
    private static function fill_loops( string $html, array $loops ): string {
        foreach ( $loops as $name => $rows ) {
            $pattern = '#\{\{\#' . preg_quote( (string) $name, '#' ) . '\}\}(.*?)\{\{/' . preg_quote( (string) $name, '#' ) . '\}\}#is';

            $html = (string) preg_replace_callback(
                $pattern,
                static function ( array $m ) use ( $rows ): string {
                    if ( ! is_array( $rows ) || empty( $rows ) ) {
                        return '';
                    }

                    $out = '';
                    foreach ( $rows as $row ) {
                        if ( ! is_array( $row ) ) {
                            continue;
                        }
                        $out .= self::fill_vars( $m[1], $row );
                    }

                    return $out;
                },
                $html
            );
        }

        return $html;
    }

    /**
     * Replace {{key}} placeholders with escaped values.
     *
     * Escaping is chosen by key name: anything that looks like a link or an
     * image path goes through esc_url(), everything else through esc_attr().
     * esc_attr() is used rather than esc_html() because a placeholder is just
     * as likely to sit inside an attribute as in text, and it renders
     * correctly in both positions.
     *
     * @since 1.18.0
     * @param string $html Markup.
     * @param array  $vars Map of placeholder name => value.
     * @return string
     */
    private static function fill_vars( string $html, array $vars ): string {
        foreach ( $vars as $key => $value ) {
            if ( is_array( $value ) || is_object( $value ) ) {
                continue;
            }

            $key = (string) $key;

            if ( 'url' === $key || preg_match( '#(?:^|_)(?:url|link|permalink|src)$#', $key ) ) {
                $safe = esc_url( (string) $value );
            } else {
                $safe = esc_attr( (string) $value );
            }

            $html = str_replace( '{{' . $key . '}}', $safe, $html );
        }

        return $html;
    }

    /**
     * Remove placeholders that had no matching value.
     *
     * Without this a typo such as {{headding}} would be printed literally on
     * the front end. Loop tags are cleared too, in case a loop name was
     * misspelled and never expanded.
     *
     * @since 1.18.0
     * @param string $html Markup.
     * @return string
     */
    private static function strip_unused_placeholders( string $html ): string {
        /*
         * The `#` inside the character class MUST stay escaped. `#` is also the
         * pattern delimiter here, and PHP ends the pattern at the first
         * unescaped one even inside a [class] — so the unescaped form silently
         * became an "Unknown modifier '/'" warning, preg_replace() returned
         * null, and casting null to string blanked the entire section.
         */
        $stripped = preg_replace( '#\{\{[\#/]?[a-z0-9_\-]*\}\}#i', '', $html );

        /*
         * Never let a regex failure destroy the author's design. If the pattern
         * ever fails again, returning the unstripped markup shows the design
         * with a stray {{placeholder}} visible, which is a far better outcome
         * than an empty section that gives no clue what went wrong.
         */
        return null === $stripped ? $html : (string) $stripped;
    }

    /* ---------------------------------------------------------------------
     * CSS scoping
     * ------------------------------------------------------------------ */

    /**
     * Rewrite a stylesheet so that nothing in it can affect the rest of the
     * page.
     *
     * @since 1.18.0
     * @param string $css   Author CSS.
     * @param string $scope Wrapper class name, without the leading dot.
     * @return string
     */
    private static function scope_css( string $css, string $scope ): string {
        if ( '' === trim( $css ) ) {
            return '';
        }

        $css = (string) preg_replace( '#/\*.*?\*/#s', '', $css );

        return self::scope_block( $css, $scope );
    }

    /**
     * Walk a stylesheet body, prefixing selectors and recursing into
     * conditional at-rules.
     *
     * Written as a brace-counting walk rather than a regex because nested
     * at-rules (a @media containing rules containing braces) cannot be matched
     * reliably with a regular expression.
     *
     * @since 1.18.0
     * @param string $css   Stylesheet body.
     * @param string $scope Wrapper class name.
     * @return string
     */
    private static function scope_block( string $css, string $scope ): string {
        $out    = '';
        $buffer = '';
        $len    = strlen( $css );
        $i      = 0;

        while ( $i < $len ) {
            if ( '{' !== $css[ $i ] ) {
                $buffer .= $css[ $i ];
                $i++;
                continue;
            }

            // Capture this block's body by counting braces.
            $depth = 1;
            $body  = '';
            $j     = $i + 1;

            while ( $j < $len ) {
                if ( '{' === $css[ $j ] ) {
                    $depth++;
                } elseif ( '}' === $css[ $j ] ) {
                    $depth--;
                    if ( 0 === $depth ) {
                        break;
                    }
                }
                $body .= $css[ $j ];
                $j++;
            }

            $selector = trim( $buffer );

            if ( '' !== $selector && '@' === $selector[0] ) {
                $lower = strtolower( $selector );

                if ( 0 === strpos( $lower, '@media' )
                    || 0 === strpos( $lower, '@supports' )
                    || 0 === strpos( $lower, '@container' )
                    || 0 === strpos( $lower, '@layer' )
                ) {
                    // Conditional wrapper: keep the condition, scope the inside.
                    $out .= $selector . '{' . self::scope_block( $body, $scope ) . '}';
                } else {
                    // @keyframes, @font-face, @property: the body is not a list
                    // of selectors, and prefixing it would break the rule.
                    $out .= $selector . '{' . $body . '}';
                }
            } elseif ( '' !== $selector ) {
                $out .= self::scope_selector( $selector, $scope )
                    . '{' . self::filter_declarations( $selector, $body ) . '}';
            }

            $buffer = '';
            $i      = $j + 1;
        }

        // Anything left over is a statement without a block, such as @import.
        return $out . trim( $buffer );
    }

    /**
     * Prefix a comma-separated selector list with the section wrapper.
     *
     * Document-level selectors are retargeted at the wrapper itself, which is
     * what the author actually meant: inside their standalone file, `body` WAS
     * the outermost box of the design.
     *
     * @since 1.18.0
     * @param string $selector Selector list.
     * @param string $scope    Wrapper class name.
     * @return string
     */
    private static function scope_selector( string $selector, string $scope ): string {
        $root  = '.' . $scope;
        $parts = explode( ',', $selector );
        $done  = [];

        foreach ( $parts as $part ) {
            $sel = trim( preg_replace( '#\s+#', ' ', $part ) ?? '' );

            if ( '' === $sel ) {
                continue;
            }

            $lower = strtolower( $sel );

            if ( in_array( $lower, [ 'html', 'body', ':root', 'html body' ], true ) ) {
                // Variables and page-level paint belong on the wrapper.
                $done[] = $root;
                continue;
            }

            if ( '*' === $sel ) {
                // A universal reset is honoured, but only within the section.
                $done[] = $root;
                $done[] = $root . ' *';
                continue;
            }

            if ( preg_match( '#^(?:html|body)\b(.*)$#i', $sel, $m ) ) {
                $done[] = $root . $m[1];
                continue;
            }

            $done[] = $root . ' ' . $sel;
        }

        return implode( ',', $done );
    }

    /**
     * Drop declarations that would escape the section via html/body/:root.
     *
     * `body { overflow: hidden; height: 100dvh }` is the single most damaging
     * thing in a standalone file — retargeted at the wrapper it would freeze
     * the section at viewport height and clip its content — so those
     * properties are removed while colours and fonts are kept.
     *
     * @since 1.18.0
     * @param string $selector Original selector list.
     * @param string $body     Declaration block.
     * @return string
     */
    private static function filter_declarations( string $selector, string $body ): string {
        if ( ! preg_match( '#(^|,)\s*(html|body|:root)\b#i', $selector ) ) {
            return $body;
        }

        $kept = [];

        foreach ( explode( ';', $body ) as $declaration ) {
            if ( '' === trim( $declaration ) ) {
                continue;
            }

            $property = strtolower( trim( strtok( $declaration, ':' ) ?: '' ) );

            // Custom properties are always safe: they do nothing until used.
            if ( 0 === strpos( $property, '--' ) ) {
                $kept[] = $declaration;
                continue;
            }

            if ( in_array( $property, self::UNSAFE_ROOT_PROPS, true ) ) {
                continue;
            }

            $kept[] = $declaration;
        }

        return implode( ';', $kept ) . ';';
    }

    /* ---------------------------------------------------------------------
     * Admin panel
     * ------------------------------------------------------------------ */

    /**
     * Output the shared "Design Source" fields for a section's admin panel.
     *
     * Shared rather than duplicated per section so the three panels cannot
     * drift apart, and so the placeholder hint always matches what render()
     * actually supplies.
     *
     * @since 1.18.0
     * @param array  $settings Saved section settings.
     * @param string $slug     Section slug.
     * @return void
     */
    public static function render_admin_fields( array $settings, string $slug ): void {
        $source = ( 'custom' === ( $settings['design_source'] ?? 'plugin' ) ) ? 'custom' : 'plugin';
        $html   = (string) ( $settings['custom_html'] ?? '' );
        $css    = (string) ( $settings['custom_css'] ?? '' );
        $hint   = self::placeholder_hint( $slug );

        // The header-only box is offered first because it is the smaller,
        // safer edit: most admins want to restyle a title, not replace a
        // whole section. Emitted here rather than in each section's own
        // Settings class so every panel gets it automatically.
        self::render_header_field( $settings, $slug );
        self::render_explore_field( $settings, $slug );
        ?>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'Design Source', 'zymarg-homepage' ); ?></label>
            <select name="settings[design_source]" class="zhp-design-source">
                <option value="plugin"<?php selected( 'plugin', $source ); ?>>
                    <?php esc_html_e( 'Plugin default design', 'zymarg-homepage' ); ?>
                </option>
                <option value="custom"<?php selected( 'custom', $source ); ?>>
                    <?php esc_html_e( 'My own HTML design', 'zymarg-homepage' ); ?>
                </option>
            </select>
        </div>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'My HTML Design', 'zymarg-homepage' ); ?></label>
            <textarea name="settings[custom_html]" rows="12" spellcheck="false"
                      class="zhp-code-box"
                      placeholder="<?php esc_attr_e( 'Paste your complete HTML file here…', 'zymarg-homepage' ); ?>"><?php echo esc_textarea( $html ); ?></textarea>
            <p class="description">
                <?php esc_html_e( 'Paste a complete HTML file, exactly as your developer wrote it. The document wrapper is removed and your CSS is confined to this section automatically, so it cannot affect your header, footer or the rest of the page.', 'zymarg-homepage' ); ?>
                <br>
                <strong><?php esc_html_e( 'Live data placeholders:', 'zymarg-homepage' ); ?></strong>
                <code><?php echo esc_html( $hint ); ?></code>
                <br>
                <?php esc_html_e( 'Leave this empty, or set Design Source back to the plugin default, to restore the built-in design. Your code stays saved either way.', 'zymarg-homepage' ); ?>
            </p>
        </div>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'Extra CSS (optional)', 'zymarg-homepage' ); ?></label>
            <textarea name="settings[custom_css]" rows="6" spellcheck="false"
                      class="zhp-code-box"><?php echo esc_textarea( $css ); ?></textarea>
            <p class="description">
                <?php esc_html_e( 'Applied after the CSS inside your HTML file, so it wins any conflict. Also confined to this section.', 'zymarg-homepage' ); ?>
            </p>
        </div>
        <?php
    }

    /**
     * Output the shared "Custom Header HTML" field for a section's panel.
     *
     * This replaces only the heading row of a section, leaving the rest of the
     * plugin design intact. It is the lighter-touch sibling of the full
     * "My own HTML design" box below it: use this to restyle a title, use that
     * to replace the whole section.
     *
     * Four sections carried their own hand-written copy of this markup before
     * 1.25.0. They are now all routed through here so the label, description
     * and field name cannot drift apart. The `name` attribute is unchanged
     * (`settings[header_html]`), so anything already saved is picked up as-is.
     *
     * @since 1.25.0
     * @param array  $settings Saved section settings.
     * @param string $slug     Section slug, used to build a unique field id.
     * @return void
     */
    public static function render_header_field( array $settings, string $slug ): void {
        $field_id = 'zhp-header-html-' . sanitize_html_class( $slug );
        $header   = (string) ( $settings['header_html'] ?? '' );
        ?>
        <div class="zhp-settings-row">
            <label>
                <input type="checkbox" name="settings[hide_header]" value="1"<?php checked( self::header_hidden( $settings ) ); ?>>
                <?php esc_html_e( 'Hide section header', 'zymarg-homepage' ); ?>
            </label>
            <p class="description" style="margin:4px 0 0;font-size:12px;color:#888;">
                <?php esc_html_e( 'Removes the heading row of this section only. The rest of the section still renders.', 'zymarg-homepage' ); ?>
            </p>
        </div>
        <div class="zhp-settings-row zhp-code-box">
            <label for="<?php echo esc_attr( $field_id ); ?>">
                <?php esc_html_e( 'Custom Header HTML (optional)', 'zymarg-homepage' ); ?>
            </label>
            <p class="description" style="margin:4px 0 6px;font-size:12px;color:#888;">
                <?php esc_html_e( 'Replaces the heading row of this section only. The rest of the section keeps the plugin design. Leave empty to use the default heading.', 'zymarg-homepage' ); ?>
            </p>
            <textarea id="<?php echo esc_attr( $field_id ); ?>"
                      name="settings[header_html]"
                      rows="4"
                      spellcheck="false"
                      class="zhp-code-textarea"
                      style="width:100%;font-family:monospace;font-size:12px;"><?php echo esc_textarea( $header ); ?></textarea>
            <?php self::render_header_review( $header ); ?>
        </div>
        <?php
    }

    /**
     * Build the heading row for a section.
     *
     * Returns the administrator's own header markup when they supplied one,
     * and the plugin's standard heading row otherwise. Centralised so that the
     * escaping decision is made in exactly one place: the default heading is
     * escaped, the custom markup is deliberately not, because it is
     * admin-authored code stored verbatim under RAW_KEYS.
     *
     * @since 1.25.0
     * @param array  $settings   Saved section settings.
     * @param string $heading    Resolved default heading text.
     * @param string $heading_id Element id the section's aria-labelledby points at.
     * @param string $extra_html Optional extra markup inside the header row,
     *                           such as the flash-deals countdown. Ignored when
     *                           custom header HTML is in use, since the author's
     *                           markup owns the whole row at that point.
     * @return string Header row HTML.
     */
    public static function render_section_header( array $settings, string $heading, string $heading_id = '', string $extra_html = '', string $slug = '' ): string {
        if ( self::header_hidden( $settings ) ) {
            return '';
        }

        $custom = trim( (string) ( $settings['header_html'] ?? '' ) );

        if ( '' !== $custom ) {
            $prepared = self::prepare_header( $custom, $slug );
            $explore  = self::explore_more( $settings, $slug );

            /*
             * A custom heading used to return here directly, which silently
             * dropped the Explore More link - the admin replaced the heading,
             * they did not ask for the link to disappear. It is appended
             * alongside instead, inside the same flex row the default header
             * uses, so it still sits hard right. "Hide the Explore More link"
             * remains the deliberate way to remove it.
             */
            if ( '' === $explore ) {
                return $prepared;
            }

            return '<div class="zhp-section-header zhp-section-header--custom">'
                . $prepared
                . $explore
                . '</div>';
        }

        $id_attr = '' !== $heading_id ? ' id="' . esc_attr( $heading_id ) . '"' : '';

        return '<div class="zhp-section-header">'
            . '<h2 class="zhp-section-title"' . $id_attr . '>' . esc_html( $heading ) . '</h2>'
            . $extra_html
            . self::explore_more( $settings, $slug )
            . '</div>';
    }

    /**
     * Make admin-supplied header markup safe to place inside a page.
     *
     * Before 1.29.0 the "Custom Header HTML" box was echoed verbatim, so a
     * pasted preview file - complete with a body { display:flex } rule - could
     * take down the layout of the entire homepage. This routes that markup
     * through the same pipeline the full custom-design box has always used:
     * the document wrapper is dropped, scripts are removed, and the CSS is
     * confined to this section so it cannot escape.
     *
     * @since 1.29.0
     * @param string $html Raw header markup as the administrator typed it.
     * @param string $slug Section slug, used to build the scope class.
     * @return string Safe markup, ready to echo.
     */
    /**
     * Whether the administrator has hidden this section's heading row.
     *
     * Hides the header only. The rest of the section keeps rendering, which is
     * what you want when a custom design already contains its own title.
     *
     * @since 1.29.0
     * @param array $settings Saved section settings.
     * @return bool
     */
    public static function render_explore_field( array $settings, string $slug ): void {
        $field_id = 'zhp-explore-html-' . sanitize_html_class( $slug );
        $html     = (string) ( $settings['explore_html'] ?? '' );
        ?>
        <div class="zhp-settings-row">
            <label>
                <input type="checkbox" name="settings[hide_explore]" value="1"<?php checked( ! empty( $settings['hide_explore'] ) ); ?>>
                <?php esc_html_e( 'Hide the Explore More link', 'zymarg-homepage' ); ?>
            </label>
            <p class="description" style="margin:4px 0 0;font-size:12px;color:#888;">
                <?php esc_html_e( 'Removes the link on the right of this heading only.', 'zymarg-homepage' ); ?>
            </p>
        </div>
        <?php
        /*
         * Destination when no explicit URL is set (v1.47.0).
         *
         * Defaults to 'shop', which is exactly what every existing section
         * already does, so upgrading changes nothing until an admin opts a
         * section. 'browse' is the default and is only offered when the
         * Connection Engine is new enough to serve a feed page -- offering a
         * destination that does not exist yet would just break a live section.
         */
        $dest         = ( 'shop' === (string) ( $settings['explore_dest'] ?? '' ) ) ? 'shop' : 'browse';
        $browse_ready = function_exists( 'zymarg_ce_browse_url' );
        ?>
        <?php if ( $browse_ready ) : ?>
            <div class="zhp-settings-row">
                <label><?php esc_html_e( 'Explore More Destination', 'zymarg-homepage' ); ?></label>
                <select name="settings[explore_dest]">
                    <option value="browse"<?php selected( $dest, 'browse' ); ?>>
                        <?php esc_html_e( 'Browse page, showing this section&rsquo;s products (default)', 'zymarg-homepage' ); ?>
                    </option>
                    <option value="shop"<?php selected( $dest, 'shop' ); ?>>
                        <?php esc_html_e( 'Shop page', 'zymarg-homepage' ); ?>
                    </option>
                </select>
                <p class="description" style="margin:4px 0 0;font-size:12px;color:#888;">
                    <?php esc_html_e( 'The Browse page option opens the Connection Engine browse page filtered to the same products this section shows. Used only when the URL below is empty. Sections with no matching product feed fall back to the Shop page.', 'zymarg-homepage' ); ?>
                </p>
            </div>
        <?php else : ?>
            <input type="hidden" name="settings[explore_dest]" value="<?php echo esc_attr( $dest ); ?>">
        <?php endif; ?>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'Explore More Link URL', 'zymarg-homepage' ); ?></label>
            <input type="url" name="settings[explore_url]" value="<?php echo esc_attr( $settings['explore_url'] ?? '' ); ?>">
            <p class="description" style="margin:4px 0 0;font-size:12px;color:#888;">
                <?php esc_html_e( 'Overrides the destination above. Leave empty to use it.', 'zymarg-homepage' ); ?>
            </p>
        </div>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'Explore More Label', 'zymarg-homepage' ); ?></label>
            <input type="text" name="settings[explore_label]" value="<?php echo esc_attr( $settings['explore_label'] ?? '' ); ?>"
                   placeholder="<?php esc_attr_e( 'Explore More', 'zymarg-homepage' ); ?>">
        </div>
        <div class="zhp-settings-row zhp-code-box">
            <label for="<?php echo esc_attr( $field_id ); ?>">
                <?php esc_html_e( 'Custom Explore More HTML (optional)', 'zymarg-homepage' ); ?>
            </label>
            <p class="description" style="margin:4px 0 6px;font-size:12px;color:#888;">
                <?php esc_html_e( 'Replaces the Explore More link only. Your CSS is confined to this control automatically. Leave empty to use the default link.', 'zymarg-homepage' ); ?>
            </p>
            <textarea id="<?php echo esc_attr( $field_id ); ?>"
                      name="settings[explore_html]"
                      rows="4"
                      spellcheck="false"
                      class="zhp-code-textarea"
                      style="width:100%;font-family:monospace;font-size:12px;"><?php echo esc_textarea( $html ); ?></textarea>
            <?php self::render_header_review( $html ); ?>
        </div>
        <?php
    }

    public static function explore_more( array $settings, string $slug = '' ): string {
        if ( ! empty( $settings['hide_explore'] ) ) {
            return '';
        }

        $custom = trim( (string) ( $settings['explore_html'] ?? '' ) );

        /*
         * Resolve the destination before the custom branch, because the custom
         * branch needs it too now. It used to be resolved only for the default
         * markup below, which is why Explore More URL was silently ignored the
         * moment anything was typed into the Explore More HTML box.
         */
        $url = trim( (string) ( $settings['explore_url'] ?? '' ) );

        /*
         * Browse-page destination (v1.47.0).
         *
         * Sends the shopper to a page that shows the same kind of products the
         * section was showing, instead of an unfiltered Shop page with no
         * relationship to what they clicked.
         *
         * This is the DEFAULT as of v1.47.1. It was opt-in in 1.47.0, which
         * meant the feature shipped switched off and every section still went
         * to the Shop page until an admin changed seven separate dropdowns.
         * The opt-in added nothing: the guards below already fall back safely,
         * so the only thing it protected against was the feature working.
         *
         * Guards, all of which fall through to the shop page below: an explicit
         * Explore More URL still wins, an admin can still pick 'shop' per
         * section, and the bridge returns '' unless the Connection Engine is
         * active, new enough, has its browse page switched on, and can actually
         * serve this section's feed.
         */
        if (
            '' === $url
            && 'shop' !== (string) ( $settings['explore_dest'] ?? '' )
            && '' !== $slug
            && class_exists( '\\ZYMARGHomepage\\Integration\\ProductGridBridge' )
        ) {
            $url = \ZYMARGHomepage\Integration\ProductGridBridge::browse_url_for_slug( $slug );
        }

        if ( '' === $url && function_exists( 'wc_get_page_permalink' ) ) {
            $url = (string) wc_get_page_permalink( 'shop' );
        }

        /*
         * Custom markup path.
         *
         * Two things here are easy to get wrong and both were:
         *
         * 1. prepare_header() is the HEADING builder, so its wrapper carries
         *    .zhp-custom-header. In a --custom heading row BOTH children then
         *    matched the greedy `flex: 1 1 auto` rule meant for the heading,
         *    each took half the row, and the link landed in the middle of the
         *    header while the rule that pins it right matched nothing. The
         *    extra class gives the stylesheet something to tell them apart.
         *
         * 2. This path never emitted an <a>, so a custom Explore More was
         *    unclickable text unless the admin happened to include their own
         *    link. It is auto-linked below, but only when the supplied markup
         *    has no anchor of its own, so hand-written links still win and we
         *    can never nest one anchor inside another.
         */
        if ( '' !== $custom ) {
            return self::prepare_header( $custom, $slug . '-explore', 'zhp-explore-more--custom', $url );
        }

        if ( '' === $url ) {
            return '';
        }

        $label = trim( (string) ( $settings['explore_label'] ?? '' ) );

        if ( '' === $label ) {
            $label = __( 'Explore More', 'zymarg-homepage' );
        }

        return '<a class="zhp-explore-more" href="' . esc_url( $url ) . '">'
            . esc_html( $label )
            . '<span class="zhp-explore-more__arrow" aria-hidden="true">&rarr;</span>'
            . '</a>';
    }

    /**
     * Scoped <style> for the "Extra CSS" box on a section using the plugin design.
     *
     * The Extra CSS box used to be dead unless the admin had also pasted a
     * complete document into the "My HTML Design" box, because the only code
     * that read it lived inside render(), which bails when custom_html is
     * empty. So an admin who just wanted to nudge a colour on an otherwise
     * stock section typed CSS into a box that silently threw it away.
     *
     * This returns that CSS on its own, scoped to the section exactly as the
     * custom-design path scopes it. Returns nothing when the custom design IS
     * active, because render() already appends the same CSS there and emitting
     * it twice would double every rule.
     *
     * @since 1.35.0
     * @param array  $settings Saved section settings.
     * @param string $slug     Section slug.
     * @return string A <style> block, or '' when there is nothing to add.
     */
    /**
     * Motion attributes for a row-section carousel.
     *
     * Auto-rotation was originally banner-only. The frontend script already
     * reads these attributes from any track, so the sections only needed to
     * emit them. They are placed on the <section> rather than the track
     * because product rows are drawn by the engine, whose markup this plugin
     * cannot add attributes to; the script inherits them from the ancestor.
     *
     * @since 1.39.0
     * @param array $settings Saved section settings.
     * @return string Attribute string, empty when the carousel is off.
     */
    public static function carousel_motion_attrs( array $settings ): string {
        if ( empty( $settings['carousel'] ) ) {
            return '';
        }

        $glide = (int) ( $settings['glide_speed'] ?? 0 );
        $glide = ( $glide >= 100 && $glide <= 3000 ) ? $glide : 400;

        $out = ' data-zhp-carousel-motion data-zhp-glide="' . esc_attr( (string) $glide ) . '"';

        if ( ! empty( $settings['autoplay'] ) ) {
            if ( 'marquee' === ( $settings['autoplay_mode'] ?? 'step' ) ) {
                $speed = (int) ( $settings['marquee_speed'] ?? 0 );
                $speed = ( $speed >= 10 && $speed <= 200 ) ? $speed : 40;

                $out .= ' data-zhp-marquee="' . esc_attr( (string) $speed ) . '"';
            } else {
                $delay = (int) ( $settings['autoplay_delay'] ?? 0 );
                $delay = ( $delay >= 2 && $delay <= 30 ) ? $delay : 6;

                $out .= ' data-zhp-autoplay="' . esc_attr( (string) $delay ) . '"';
            }
        }

        return $out;
    }

    /**
     * Auto-rotate and glide controls for a row section.
     *
     * @since 1.39.0
     * @param array $settings Saved section settings.
     * @return void
     */
    public static function render_carousel_motion_fields( array $settings ): void {
        $delay = (int) ( $settings['autoplay_delay'] ?? 0 );
        $delay = ( $delay >= 2 && $delay <= 30 ) ? $delay : 6;
        $glide = (int) ( $settings['glide_speed'] ?? 0 );
        $glide = ( $glide >= 100 && $glide <= 3000 ) ? $glide : 400;
        $mode  = 'marquee' === ( $settings['autoplay_mode'] ?? 'step' ) ? 'marquee' : 'step';
        $speed = (int) ( $settings['marquee_speed'] ?? 0 );
        $speed = ( $speed >= 10 && $speed <= 200 ) ? $speed : 40;
        ?>
        <div class="zhp-settings-row">
            <label>
                <input type="checkbox" name="settings[autoplay]" value="1"<?php checked( ! empty( $settings['autoplay'] ) ); ?>>
                <?php esc_html_e( 'Rotate the carousel automatically', 'zymarg-homepage' ); ?>
            </label>
            <p class="zhp-settings-row__desc">
                <?php esc_html_e( 'Only applies when the carousel above is on. Rotation stops for good as soon as the shopper swipes, scrolls or uses the arrows, and never starts for visitors who prefer reduced motion.', 'zymarg-homepage' ); ?>
            </p>
        </div>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'Rotation Style', 'zymarg-homepage' ); ?></label>
            <select name="settings[autoplay_mode]" class="zhp-settings-select">
                <option value="step"<?php selected( $mode, 'step' ); ?>>
                    <?php esc_html_e( 'Step - slide, pause, slide', 'zymarg-homepage' ); ?>
                </option>
                <option value="marquee"<?php selected( $mode, 'marquee' ); ?>>
                    <?php esc_html_e( 'Continuous - never stops moving', 'zymarg-homepage' ); ?>
                </option>
            </select>
            <p class="zhp-settings-row__desc">
                <?php esc_html_e( 'Step advances one screen at a time and waits in between. Continuous drifts the row steadily from right to left with no pauses, and loops seamlessly. Continuous ignores the seconds setting below and uses the speed instead.', 'zymarg-homepage' ); ?>
            </p>
        </div>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'Seconds Between Slides', 'zymarg-homepage' ); ?></label>
            <input type="number" min="2" max="30" step="1" class="zhp-settings-number"
                   name="settings[autoplay_delay]" value="<?php echo esc_attr( (string) $delay ); ?>">
        </div>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'Continuous Speed (pixels per second)', 'zymarg-homepage' ); ?></label>
            <input type="number" min="10" max="200" step="5" class="zhp-settings-number"
                   name="settings[marquee_speed]" value="<?php echo esc_attr( (string) $speed ); ?>">
            <p class="zhp-settings-row__desc">
                <?php esc_html_e( 'Only used by the Continuous style. Around 40 reads as a gentle drift; higher values move faster.', 'zymarg-homepage' ); ?>
            </p>
        </div>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'Glide Speed (milliseconds)', 'zymarg-homepage' ); ?></label>
            <input type="number" min="100" max="3000" step="50" class="zhp-settings-number"
                   name="settings[glide_speed]" value="<?php echo esc_attr( (string) $glide ); ?>">
            <p class="zhp-settings-row__desc">
                <?php esc_html_e( 'How long one slide takes to travel. Also applies to the arrows.', 'zymarg-homepage' ); ?>
            </p>
        </div>
        <?php
    }

    public static function standalone_css( array $settings, string $slug ): string {
        if ( self::is_active( $settings ) ) {
            return '';
        }

        $extra = trim( (string) ( $settings['custom_css'] ?? '' ) );

        if ( '' === $extra ) {
            return '';
        }

        $scope  = 'zhp-custom--' . sanitize_html_class( $slug );
        $scoped = self::scope_css( $extra, $scope );

        if ( '' === trim( $scoped ) ) {
            return '';
        }

        return '<style>' . $scoped . '</style>';
    }

    public static function header_hidden( array $settings ): bool {
        return ! empty( $settings['hide_header'] );
    }

    public static function prepare_header( string $html, string $slug = '', string $extra_class = '', string $link_url = '' ): string {
        if ( '' === trim( $html ) ) {
            return '';
        }

        $safe_slug = sanitize_html_class( $slug );
        $scope     = '' !== $safe_slug ? 'zhp-header--' . $safe_slug : 'zhp-custom-header';
        $classes   = 'zhp-custom-header' . ( 'zhp-custom-header' !== $scope ? ' ' . $scope : '' );

        if ( '' !== $extra_class ) {
            $classes .= ' ' . $extra_class;
        }

        $css    = self::extract_css( $html );
        $markup = self::extract_markup( $html );
        $markup = self::strip_scripts( $markup );
        $css    = self::scope_css( $css, $scope );

        /*
         * Optional auto-link, used by explore_more().
         *
         * Applied after strip_scripts() so the anchor can only ever wrap markup
         * that already survived sanitising, and skipped entirely when the admin
         * supplied their own anchor, which would otherwise nest.
         */
        if ( '' !== $link_url && ! preg_match( '/<a[\s>]/i', $markup ) ) {
            $markup = '<a class="zhp-explore-more__link" href="' . esc_url( $link_url ) . '">'
                . $markup
                . '</a>';
        }

        $out = '<div class="' . esc_attr( $classes ) . '" data-zhp-custom-header="' . esc_attr( $slug ) . '">';

        if ( '' !== trim( $css ) ) {
            $out .= '<style>' . $css . '</style>';
        }

        return $out . $markup . '</div>';
    }

    /**
     * Describe what prepare_header() will change about a piece of markup.
     *
     * Powers the reviewer shown beneath the "Custom Header HTML" box, so an
     * administrator can see why their code behaves differently on the page
     * than it did in the file they copied it from.
     *
     * @since 1.29.0
     * @param string $html Raw header markup.
     * @return array List of notes. An empty list means nothing will change.
     */
    public static function analyse_header( string $html ): array {
        $notes = [];

        if ( '' === trim( $html ) ) {
            return $notes;
        }

        if ( preg_match( '#<!DOCTYPE|<html\b|<head\b|<body\b#i', $html ) ) {
            $notes[] = __( 'This looks like a complete HTML file. The DOCTYPE, html, head and body tags are removed automatically, and only the markup inside body is used. Paste just the fragment next time.', 'zymarg-homepage' );
        }

        $css = self::extract_css( $html );

        if ( '' !== trim( $css ) && preg_match( '#(?:^|[\s,\}])(?:body|html|:root)\b#i', $css ) ) {
            $notes[] = __( 'Your CSS targets body, html or :root. Those rules are confined to this section, so they can no longer affect the rest of the page.', 'zymarg-homepage' );

            foreach ( self::UNSAFE_ROOT_PROPS as $prop ) {
                if ( preg_match( '#(?:^|[;\{\s])' . preg_quote( $prop, '#' ) . '\s*:#i', $css ) ) {
                    $notes[] = sprintf(
                        /* translators: %s: CSS property name, for example display. */
                        __( 'Layout properties such as "%s" are dropped from page-level rules, because those are the ones that break a homepage. Apply them to your own class instead.', 'zymarg-homepage' ),
                        $prop
                    );
                    break;
                }
            }
        }

        if ( preg_match( '#<script\b#i', $html ) || preg_match( '#\son[a-z]+\s*=#i', $html ) ) {
            $notes[] = __( 'Script tags and inline event handlers are removed. This box is for layout and text only.', 'zymarg-homepage' );
        }

        if ( false === stripos( $html, 'zhp-section-header' ) ) {
            $notes[] = __( 'No element using the class "zhp-section-header" was found. Wrap your heading in one so this section keeps the same spacing and alignment as the others.', 'zymarg-homepage' );
        }

        return $notes;
    }

    /**
     * Output the live reviewer beneath the header box.
     *
     * @since 1.29.0
     * @param string $header Saved header markup.
     * @return void
     */
    public static function render_header_review( string $header ): void {
        $notes    = self::analyse_header( $header );
        $has_code = '' !== trim( $header );
        ?>
        <div class="zhp-header-check" data-zhp-header-check>
            <p class="zhp-header-check__rules">
                <strong><?php esc_html_e( 'What belongs in this box:', 'zymarg-homepage' ); ?></strong>
                <?php esc_html_e( 'a fragment only, with no DOCTYPE, html, head or body tags. Style your own classes and never body, html or :root. A style block is fine here, because it is confined to this section automatically.', 'zymarg-homepage' ); ?>
            </p>
            <ul class="zhp-header-check__list" data-zhp-header-notes<?php echo empty( $notes ) ? ' hidden' : ''; ?>>
                <?php foreach ( $notes as $note ) : ?>
                    <li><?php echo esc_html( $note ); ?></li>
                <?php endforeach; ?>
            </ul>
            <p class="zhp-header-check__ok" data-zhp-header-ok<?php echo ( $has_code && empty( $notes ) ) ? '' : ' hidden'; ?>>
                <?php esc_html_e( 'Looks good. Nothing in this code needs changing.', 'zymarg-homepage' ); ?>
            </p>
        </div>
        <?php
    }

    /**
     * The placeholder list shown to the author for a given section.
     *
     * @since 1.18.0
     * @param string $slug Section slug.
     * @return string
     */
    private static function placeholder_hint( string $slug ): string {
        switch ( $slug ) {
            case 'hero':
                return '{{heading}} {{subheading}} {{cta_label}} {{cta_url}} {{bg_image}}';

            case 'categories':
                return '{{heading}} — repeat per category: {{#categories}} {{name}} {{url}} {{image_url}} {{image_alt}} {{count}} {{slug}} {{/categories}}';

            case 'promo-banner':
                return '{{title}} {{image_url}} {{alt_text}} {{link_url}} {{link_label}}';

            case 'featured-sellers':
                return '{{heading}} — repeat per seller: {{#sellers}} {{name}} {{url}} {{avatar_url}} {{banner_url}} {{location}} {{rating}} {{rating_count}} {{product_count}} {{/sellers}}';

            case 'collections':
                return '{{heading}} — repeat per collection: {{#collections}} {{title}} {{subtitle}} {{image_url}} {{image_alt}} {{link_url}} {{link_label}} {{/collections}}';

            case 'brands':
                return '{{heading}} — repeat per brand: {{#brands}} {{name}} {{url}} {{image_url}} {{image_alt}} {{count}} {{/brands}}';

            case 'newsletter':
                return '{{heading}} {{subheading}} {{btn_label}} {{success_message}} — keep an input with data-zhp-newsletter-email and a button with data-zhp-newsletter-submit for signup to work';

            case 'footer-cta':
                return '{{heading}} {{subheading}} {{btn_label}} {{btn_url}}';
        }

        return '';
    }
}
