<?php
/**
 * ZYMARG Homepage – Asset path resolver
 *
 * Single source of truth for turning a logical asset name into a real URL.
 *
 * WHY THIS EXISTS
 * ---------------
 * Twelve classes each carried their own copy of this idiom:
 *
 *     $this->min = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';
 *
 * and then appended `$this->min` straight onto a path. That produced two
 * distinct classes of bug:
 *
 *   1. A 404 whenever the minified twin did not exist on disk. Production
 *      always asks for `.min`, so a new asset shipped without a hand-written
 *      minified copy simply failed to load, silently.
 *   2. Worse, in nine `Features/*\/Assets.php` classes the existence check was
 *      performed against the MINIFIED path and, when it failed, the enqueue was
 *      skipped entirely rather than falling back to the source file. A missing
 *      `.min` twin therefore meant the section rendered with no CSS at all.
 *
 * This resolver always degrades gracefully: it prefers the minified build when
 * one genuinely exists, falls back to the unminified source when it does not,
 * and returns an empty string only when neither file is present — so a caller
 * can never enqueue a URL that 404s.
 *
 * Results are memoised per request because these paths are resolved dozens of
 * times per page load and `file_exists()` hits the filesystem.
 *
 * @package ZYMARGHomepage\Core
 * @since   1.12.0
 */

namespace ZYMARGHomepage\Core;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Resolves plugin asset paths and URLs, preferring built files when available.
 *
 * @since 1.12.0
 */
final class AssetPath {

    /**
     * Memoised results, keyed "relative/path.ext".
     *
     * Values are the resolved relative path including the correct suffix, or
     * an empty string when no file exists at all.
     *
     * @since 1.12.0
     * @var array<string, string>
     */
    private static array $cache = [];

    /**
     * Whether WordPress is asking for unminified assets.
     *
     * @since 1.12.0
     * @return bool True when SCRIPT_DEBUG is enabled.
     */
    public static function is_debug(): bool {
        return defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG;
    }

    /**
     * Resolve the relative path of the best available variant of an asset.
     *
     * Preference order:
     *   - SCRIPT_DEBUG on  : source, then minified as a fallback.
     *   - SCRIPT_DEBUG off : minified, then source as a fallback.
     *
     * @since 1.12.0
     * @param string $relative_path Path under the plugin root, no extension.
     *                              e.g. 'assets/css/frontend/brands'.
     * @param string $extension     Extension without the dot, e.g. 'css'.
     * @return string Relative path with extension, or '' when nothing exists.
     */
    public static function relative( string $relative_path, string $extension ): string {
        $key = $relative_path . '.' . $extension;

        if ( isset( self::$cache[ $key ] ) ) {
            return self::$cache[ $key ];
        }

        $source   = $relative_path . '.' . $extension;
        $minified = $relative_path . '.min.' . $extension;

        $order = self::is_debug()
            ? [ $source, $minified ]
            : [ $minified, $source ];

        $resolved = '';
        foreach ( $order as $candidate ) {
            if ( file_exists( ZYMARG_HP_PLUGIN_DIR . $candidate ) ) {
                $resolved = $candidate;
                break;
            }
        }

        self::$cache[ $key ] = $resolved;

        return $resolved;
    }

    /**
     * Absolute filesystem path of the best available variant.
     *
     * Returns '' when the asset does not exist in any variant, which makes
     * `file_exists( AssetPath::path( ... ) )` safe as a guard.
     *
     * @since 1.12.0
     * @param string $relative_path Path under the plugin root, no extension.
     * @param string $extension     Extension without the dot.
     * @return string Absolute path, or '' when nothing exists.
     */
    public static function path( string $relative_path, string $extension ): string {
        $resolved = self::relative( $relative_path, $extension );

        return '' === $resolved ? '' : ZYMARG_HP_PLUGIN_DIR . $resolved;
    }

    /**
     * Public URL of the best available variant.
     *
     * @since 1.12.0
     * @param string $relative_path Path under the plugin root, no extension.
     * @param string $extension     Extension without the dot.
     * @return string Absolute URL, or '' when nothing exists.
     */
    public static function url( string $relative_path, string $extension ): string {
        $resolved = self::relative( $relative_path, $extension );

        return '' === $resolved ? '' : ZYMARG_HP_PLUGIN_URL . $resolved;
    }

    /**
     * Whether any variant of the asset exists on disk.
     *
     * @since 1.12.0
     * @param string $relative_path Path under the plugin root, no extension.
     * @param string $extension     Extension without the dot.
     * @return bool
     */
    public static function exists( string $relative_path, string $extension ): bool {
        return '' !== self::relative( $relative_path, $extension );
    }

    /**
     * Clear the memoisation cache.
     *
     * Only useful in tests, or after writing asset files at runtime.
     *
     * @since 1.12.0
     * @return void
     */
    public static function flush_cache(): void {
        self::$cache = [];
    }
}
