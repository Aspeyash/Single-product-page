<?php
/**
 * ZYMARG Homepage - Shared multibanner slide helper.
 *
 * Hero, Promo Banner, Footer CTA and Newsletter each used to store exactly one
 * banner as flat top-level settings keys. This turns those four panels into
 * repeaters without touching what a single banner looks like.
 *
 * TWO RULES THIS FILE EXISTS TO GUARANTEE
 * ---------------------------------------
 * 1. A section with one slide renders byte-identically to how it rendered
 *    before multibanner existed. wrap() returns the markup untouched when
 *    there is nothing to scroll, so no carousel container, no extra div and no
 *    new CSS ever reaches an unchanged section.
 * 2. Nobody loses the banner they already had. get() falls back to the legacy
 *    flat keys when the repeater is empty, so an existing site keeps rendering
 *    on upgrade and the old values are read, never overwritten.
 *
 * @package ZYMARGHomepage\Core
 * @since   1.34.0
 * @version 1.40.0
 */

namespace ZYMARGHomepage\Core;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Slides {

    /**
     * Field lists per section slug, in admin display order.
     *
     * @since 1.34.0
     * @var array<string, string[]>
     */
    public const FIELDS = [
        'hero'         => [ 'heading', 'subheading', 'cta_label', 'cta_url', 'bg_image' ],
        'promo-banner' => [ 'title', 'image_url', 'alt_text', 'link_url', 'link_label' ],
        'footer-cta'   => [ 'heading', 'subheading', 'btn_label', 'btn_url' ],
        'newsletter'   => [ 'heading', 'subheading', 'btn_label', 'success_message' ],
    ];

    /**
     * Sections where auto-rotate is offered.
     *
     * Newsletter is deliberately absent. It contains an email field, and
     * sliding a form out from under someone who is typing loses their input.
     *
     * @since 1.34.0
     * @var string[]
     */
    public const AUTOPLAY_SLUGS = [ 'hero', 'promo-banner', 'footer-cta' ];

    /**
     * Resolve a section's slides, newest admin data first, legacy keys second.
     *
     * @since 1.34.0
     * @param array  $settings Saved section settings.
     * @param string $slug     Section slug.
     * @return array<int, array<string, string>>
     */
    /**
     * Human labels and input types for each repeater field.
     *
     * @since 1.34.0
     * @var array<string, array{0:string,1:string}>
     */
    public const FIELD_META = [
        'heading'         => [ 'Heading', 'text' ],
        'subheading'      => [ 'Sub-heading', 'text' ],
        'title'           => [ 'Banner Title', 'text' ],
        'cta_label'       => [ 'Button Label', 'text' ],
        'cta_url'         => [ 'Button URL', 'url' ],
        'btn_label'       => [ 'Button Label', 'text' ],
        'btn_url'         => [ 'Button URL', 'url' ],
        'link_label'      => [ 'Link Label', 'text' ],
        'link_url'        => [ 'Link URL', 'url' ],
        'bg_image'        => [ 'Background Image URL', 'url' ],
        'image_url'       => [ 'Image URL', 'url' ],
        'alt_text'        => [ 'Image Alt Text', 'text' ],
        'success_message' => [ 'Success Message', 'text' ],
    ];

    /**
     * Render the repeater panel plus its rotation controls.
     *
     * @since 1.34.0
     * @param array  $settings Saved section settings.
     * @param string $slug     Section slug.
     * @return void
     */
    public static function render_repeater( array $settings, string $slug ): void {
        $fields = self::FIELDS[ $slug ] ?? [];

        if ( empty( $fields ) ) {
            return;
        }

        $rows = self::get( $settings, $slug );
        ?>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'Banners', 'zymarg-homepage' ); ?></label>
            <p class="zhp-repeater__hint">
                <?php esc_html_e( 'One row is one banner. Add a second row to turn this section into a swipeable multibanner. With a single row the section looks and behaves exactly as it does now.', 'zymarg-homepage' ); ?>
            </p>
            <div class="zhp-repeater" data-zhp-repeater="<?php echo esc_attr( $slug ); ?>">
                <div class="zhp-repeater__rows">
                    <?php foreach ( $rows as $index => $row ) : ?>
                        <?php self::render_row( (int) $index, $row, $fields, $slug ); ?>
                    <?php endforeach; ?>
                </div>
                <script type="text/html" class="zhp-repeater__template">
                    <?php self::render_row( null, [], $fields, $slug ); ?>
                </script>
                <button type="button" class="zhp-admin-btn zhp-admin-btn--ghost zhp-repeater__add">
                    <?php esc_html_e( '+ Add Banner', 'zymarg-homepage' ); ?>
                </button>
            </div>
        </div>
        <?php
        $glide = (int) ( $settings['glide_speed'] ?? 0 );
        $glide = ( $glide >= 100 && $glide <= 3000 ) ? $glide : 400;
        ?>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'Glide Speed (milliseconds)', 'zymarg-homepage' ); ?></label>
            <input type="number" min="100" max="3000" step="50" class="zhp-settings-number"
                   name="settings[glide_speed]" value="<?php echo esc_attr( (string) $glide ); ?>">
            <p class="description" style="margin:4px 0 0;font-size:12px;color:#888;">
                <?php esc_html_e( 'How long one banner takes to slide across. Lower is snappier, higher is more relaxed. 400 is the default; 1000 is one full second. This is separate from the wait between banners above. Visitors who have asked for reduced motion always jump instantly instead.', 'zymarg-homepage' ); ?>
            </p>
        </div>
        <?php
        if ( in_array( $slug, self::AUTOPLAY_SLUGS, true ) ) :
            $delay = (int) ( $settings['autoplay_delay'] ?? 0 );
            $delay = ( $delay >= 2 && $delay <= 30 ) ? $delay : 6;
            $mode  = 'marquee' === ( $settings['autoplay_mode'] ?? 'step' ) ? 'marquee' : 'step';
            $speed = (int) ( $settings['marquee_speed'] ?? 0 );
            $speed = ( $speed >= 10 && $speed <= 200 ) ? $speed : 40;
            ?>
            <div class="zhp-settings-row">
                <label>
                    <input type="checkbox" name="settings[autoplay]" value="1"<?php checked( ! empty( $settings['autoplay'] ) ); ?>>
                    <?php esc_html_e( 'Rotate banners automatically', 'zymarg-homepage' ); ?>
                </label>
                <p class="description" style="margin:4px 0 0;font-size:12px;color:#888;">
                    <?php esc_html_e( 'Rotation pauses while the visitor hovers, swipes or tabs into the banner, and stays off for anyone who has asked for reduced motion. Only applies with two or more banners.', 'zymarg-homepage' ); ?>
                </p>
            </div>
            <div class="zhp-settings-row">
                <label><?php esc_html_e( 'Rotation Style', 'zymarg-homepage' ); ?></label>
                <select name="settings[autoplay_mode]" class="zhp-settings-select">
                    <option value="step"<?php selected( $mode, 'step' ); ?>>
                        <?php esc_html_e( 'Step - slide, pause, slide', 'zymarg-homepage' ); ?>
                    </option>
                    <option value="marquee"<?php selected( $mode, 'marquee' ); ?>>
                        <?php esc_html_e( 'Continuous - never stops moving', 'zymarg-homepage' ); ?>
                    </option>
                </select>
                <p class="description" style="margin:4px 0 0;font-size:12px;color:#888;">
                    <?php esc_html_e( 'Step is the existing behaviour: slide, wait, slide again. Continuous drifts steadily from right to left without pausing and uses the speed below instead of the seconds setting.', 'zymarg-homepage' ); ?>
                </p>
            </div>
            <div class="zhp-settings-row">
                <label><?php esc_html_e( 'Continuous Speed (pixels per second)', 'zymarg-homepage' ); ?></label>
                <input type="number" min="10" max="200" step="5" class="zhp-settings-number"
                       name="settings[marquee_speed]" value="<?php echo esc_attr( (string) $speed ); ?>">
            </div>
            <div class="zhp-settings-row">
                <label><?php esc_html_e( 'Seconds Between Banners', 'zymarg-homepage' ); ?></label>
                <input type="number" min="2" max="30" class="zhp-settings-number"
                       name="settings[autoplay_delay]" value="<?php echo esc_attr( (string) $delay ); ?>">
            </div>
        <?php else : ?>
            <div class="zhp-settings-row">
                <p class="description" style="margin:0;font-size:12px;color:#888;">
                    <?php esc_html_e( 'This section rotates on swipe only. Auto-rotation is not offered here because it would slide the sign-up field away from anyone part-way through typing their email.', 'zymarg-homepage' ); ?>
                </p>
            </div>
        <?php endif;
    }

    /**
     * Render one repeater row.
     *
     * @since 1.34.0
     * @param int|null $index  Row index, or null for the clone template.
     * @param array    $row    Saved values.
     * @param string[] $fields Field keys for this section.
     * @param string   $slug   Section slug.
     * @return void
     */
    private static function render_row( ?int $index, array $row, array $fields, string $slug ): void {
        $i = null === $index ? '__INDEX__' : (string) $index;
        ?>
        <div class="zhp-repeater__row" data-index="<?php echo esc_attr( $i ); ?>">
            <div class="zhp-repeater__grid">
                <?php foreach ( $fields as $field ) :
                    $meta = self::FIELD_META[ $field ] ?? [ $field, 'text' ];
                    ?>
                    <label>
                        <span><?php echo esc_html( __( $meta[0], 'zymarg-homepage' ) ); ?></span>
                        <input type="<?php echo esc_attr( $meta[1] ); ?>"
                               name="settings[items][<?php echo esc_attr( $i ); ?>][<?php echo esc_attr( $field ); ?>]"
                               value="<?php echo esc_attr( $row[ $field ] ?? '' ); ?>">
                    </label>
                <?php endforeach; ?>
            </div>
            <button type="button" class="zhp-repeater__remove"
                    aria-label="<?php esc_attr_e( 'Remove this banner', 'zymarg-homepage' ); ?>"
                    title="<?php esc_attr_e( 'Remove', 'zymarg-homepage' ); ?>">&times;</button>
        </div>
        <?php
    }

    public static function get( array $settings, string $slug ): array {
        $fields = self::FIELDS[ $slug ] ?? [];

        if ( empty( $fields ) ) {
            return [];
        }

        $rows  = is_array( $settings['items'] ?? null ) ? $settings['items'] : [];
        $clean = [];

        foreach ( $rows as $row ) {
            if ( ! is_array( $row ) ) {
                continue;
            }

            $slide = [];
            $used  = false;

            foreach ( $fields as $field ) {
                $value           = trim( (string) ( $row[ $field ] ?? '' ) );
                $slide[ $field ] = $value;
                $used            = $used || '' !== $value;
            }

            // Skip rows the admin added and never filled in.
            if ( $used ) {
                $clean[] = $slide;
            }
        }

        if ( ! empty( $clean ) ) {
            return $clean;
        }

        // No repeater rows yet: fall back to the flat keys this section has
        // always used, so an upgraded site renders exactly as it did before.
        $legacy = [];
        $used   = false;

        foreach ( $fields as $field ) {
            $value            = trim( (string) ( $settings[ $field ] ?? '' ) );
            $legacy[ $field ] = $value;
            $used             = $used || '' !== $value;
        }

        // Always one slide here, filled or not: an empty section is the
        // template's decision to make, not this helper's.
        unset( $used );

        return [ $legacy ];
    }

    /**
     * Whether this section should behave as a rotating multibanner.
     *
     * @since 1.34.0
     * @param array $slides Resolved slides.
     * @return bool
     */
    public static function is_multi( array $slides ): bool {
        return count( $slides ) > 1;
    }

    /**
     * Wrap rendered slides in the shared carousel track.
     *
     * Returns the markup completely untouched for a single slide. That is the
     * whole point: an admin who never opens the repeater must not inherit a
     * carousel wrapper, a scroll container or any behaviour change.
     *
     * @since 1.34.0
     * @param string $html     Concatenated slide markup.
     * @param array  $settings Saved section settings.
     * @param string $slug     Section slug.
     * @param int    $count    Number of slides rendered.
     * @return string
     */
    public static function wrap( string $html, array $settings, string $slug, int $count ): string {
        if ( $count < 2 ) {
            return $html;
        }

        $autoplay = in_array( $slug, self::AUTOPLAY_SLUGS, true ) && ! empty( $settings['autoplay'] );
        $delay    = (int) ( $settings['autoplay_delay'] ?? 0 );

        if ( $delay < 2 || $delay > 30 ) {
            $delay = 6;
        }

        $attrs = ' data-zhp-carousel data-zhp-slides="' . esc_attr( (string) $count ) . '"';

        $glide = (int) ( $settings['glide_speed'] ?? 0 );

        if ( $glide >= 100 && $glide <= 3000 ) {
            $attrs .= ' data-zhp-glide="' . esc_attr( (string) $glide ) . '"';
        }

        if ( $autoplay ) {
            /*
             * Step remains the default and is untouched. Continuous is an
             * additional choice, so only one of the two attributes is ever
             * emitted and existing sections keep behaving exactly as before.
             */
            if ( 'marquee' === ( $settings['autoplay_mode'] ?? 'step' ) ) {
                $speed = (int) ( $settings['marquee_speed'] ?? 0 );
                $speed = ( $speed >= 10 && $speed <= 200 ) ? $speed : 40;

                $attrs .= ' data-zhp-marquee="' . esc_attr( (string) $speed ) . '"';
            } else {
                $attrs .= ' data-zhp-autoplay="' . esc_attr( (string) $delay ) . '"';
            }
        }

        return '<div class="zhp-slides zhp-carousel-track zhp-slides--' . esc_attr( sanitize_html_class( $slug ) ) . '"'
            . $attrs . '>' . $html . '</div>';
    }
}
