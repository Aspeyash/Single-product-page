<?php
/**
 * ZYMARG Homepage – Debug Logger
 *
 * Thin wrapper around WordPress debug logging. All diagnostic output in
 * this plugin must go through Logger — never call error_log() directly.
 *
 * Logs are written only when WP_DEBUG and WP_DEBUG_LOG are both true,
 * so production environments are never affected.
 *
 * Prefixes every entry with [ZYMARG-HP] and the current version for easy
 * grepping in wp-content/debug.log.
 *
 * @package ZYMARGHomepage\Core
 * @since   1.0.1
 * @version 1.1.0
 */

namespace ZYMARGHomepage\Core;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Logger
 *
 * Static-only utility. Call Logger::init() once on plugin boot, then use
 * Logger::debug(), Logger::info(), Logger::warning(), Logger::error()
 * anywhere in the codebase.
 */
final class Logger {

    /**
     * Log prefix applied to every entry.
     *
     * @since 1.0.1
     * @var string
     */
    private static string $prefix = '[ZYMARG-HP]';

    /**
     * Whether debug logging is active in this environment.
     *
     * @since 1.0.1
     * @var bool
     */
    private static bool $active = false;

    /**
     * Initialise the logger.
     *
     * Called once from Plugin::setup(). Determines whether logging is
     * active based on WordPress debug constants.
     *
     * @since 1.0.1
     * @return void
     */
    public static function init(): void {
        static::$active = ( defined( 'WP_DEBUG' ) && WP_DEBUG )
                       && ( defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG );

        static::$prefix = sprintf( '[ZYMARG-HP v%s]', ZYMARG_HP_VERSION );
    }

    /**
     * Log a DEBUG-level message.
     *
     * Use for verbose trace output during development.
     *
     * @since 1.0.1
     * @param string $message Human-readable message.
     * @param mixed  $context Optional data to append (array, object, scalar).
     * @return void
     */
    public static function debug( string $message, mixed $context = null ): void {
        static::write( 'DEBUG', $message, $context );
    }

    /**
     * Log an INFO-level message.
     *
     * Use for noteworthy state transitions (plugin activated, cache flushed).
     *
     * @since 1.0.1
     * @param string $message Human-readable message.
     * @param mixed  $context Optional data to append.
     * @return void
     */
    public static function info( string $message, mixed $context = null ): void {
        static::write( 'INFO', $message, $context );
    }

    /**
     * Log a WARNING-level message.
     *
     * Use for recoverable unexpected states (missing option, deprecated call).
     *
     * @since 1.0.1
     * @param string $message Human-readable message.
     * @param mixed  $context Optional data to append.
     * @return void
     */
    public static function warning( string $message, mixed $context = null ): void {
        static::write( 'WARNING', $message, $context );
    }

    /**
     * Log an ERROR-level message.
     *
     * Use for failures that degrade plugin functionality.
     * Even in production (WP_DEBUG off) these are still surfaced so that
     * developers can trace issues in staging logs.
     *
     * @since 1.0.1
     * @param string $message Human-readable message.
     * @param mixed  $context Optional data to append.
     * @return void
     */
    public static function error( string $message, mixed $context = null ): void {
        // Errors write even when WP_DEBUG_LOG is off, so they are never silent.
        $entry = static::format( 'ERROR', $message, $context );
        // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
        error_log( $entry );
    }

    // ──────────────────────────────────────────────────────────────
    //  Private helpers
    // ──────────────────────────────────────────────────────────────

    /**
     * Build and emit a log entry (DEBUG / INFO / WARNING levels only).
     *
     * @since 1.0.1
     * @param string $level   Log level label.
     * @param string $message Log message.
     * @param mixed  $context Optional context data.
     * @return void
     */
    private static function write( string $level, string $message, mixed $context ): void {
        if ( ! static::$active ) {
            return;
        }

        $entry = static::format( $level, $message, $context );
        // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
        error_log( $entry );
    }

    /**
     * Format a log entry string.
     *
     * @since 1.0.1
     * @param string $level   Log level.
     * @param string $message Log message.
     * @param mixed  $context Optional context.
     * @return string
     */
    private static function format( string $level, string $message, mixed $context ): string {
        $entry = sprintf( '%s [%s] %s', static::$prefix, $level, $message );

        if ( null !== $context ) {
            $entry .= ' | ' . ( is_string( $context ) ? $context : wp_json_encode( $context ) );
        }

        return $entry;
    }
}
