<?php
/**
 * ZYMARG Homepage – Query Cache
 *
 * Thin wrapper around WordPress transients. All query-result caching in
 * this plugin must go through this class — never call get_transient()
 * or set_transient() directly in feature or query files.
 *
 * Cache duration is controlled globally via the Settings admin page
 * (option: zymarg_hp_settings → cache_duration, default 15 minutes).
 * Individual call-sites may request a shorter TTL but never a longer one.
 *
 * All cache keys are prefixed with 'zhp_' to avoid collisions with
 * other plugins and to make bulk invalidation straightforward.
 *
 * @package ZYMARGHomepage\Core
 * @since   1.0.1
 * @version 1.1.0
 */

namespace ZYMARGHomepage\Core;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Cache
 *
 * Static-only utility for transient-backed query caching.
 */
final class Cache {

    /**
     * Prefix applied to every transient key written by this plugin.
     *
     * @since 1.0.1
     * @var string
     */
    private const KEY_PREFIX = 'zhp_';

    /**
     * Maximum transient key length WordPress supports.
     * Keys longer than this are hashed to stay within the limit.
     *
     * @since 1.0.1
     * @var int
     */
    private const MAX_KEY_LENGTH = 172;

    /**
     * Retrieve a cached value.
     *
     * Returns null (not false) when the key does not exist so call-sites
     * can safely use null-coalescing: $data = Cache::get('key') ?? expensive_query().
     *
     * @since 1.0.1
     * @param string $key Cache key (without the 'zhp_' prefix).
     * @return mixed|null Cached value, or null if not found / expired.
     */
    public static function get( string $key ): mixed {
        $value = get_transient( static::build_key( $key ) );
        return ( false === $value ) ? null : $value;
    }

    /**
     * Store a value in cache.
     *
     * @since 1.0.1
     * @param string $key        Cache key (without the 'zhp_' prefix).
     * @param mixed  $value      Value to cache. Must be serialisable.
     * @param int    $ttl_seconds Time-to-live in seconds. Defaults to global setting.
     *                            Pass 0 to cache indefinitely.
     * @return bool True on success.
     */
    public static function set( string $key, mixed $value, int $ttl_seconds = -1 ): bool {
        if ( $ttl_seconds < 0 ) {
            $ttl_seconds = static::default_ttl();
        }

        return set_transient( static::build_key( $key ), $value, $ttl_seconds );
    }

    /**
     * Delete a single cached value.
     *
     * @since 1.0.1
     * @param string $key Cache key (without the 'zhp_' prefix).
     * @return bool True if the transient was deleted.
     */
    public static function delete( string $key ): bool {
        return delete_transient( static::build_key( $key ) );
    }

    /**
     * Flush all plugin transients whose keys start with 'zhp_'.
     *
     * Used by the Settings page "Clear Cache" button and on plugin upgrade.
     * Works on both single-site and multisite installations.
     *
     * @since 1.0.1
     * @global \wpdb $wpdb WordPress database object.
     * @return int Number of transients deleted.
     */
    public static function flush_all(): int {
        global $wpdb;

        $deleted = 0;

        // Delete from the options table (standard transients).
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $rows = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT option_name FROM {$wpdb->options}
                 WHERE option_name LIKE %s
                    OR option_name LIKE %s",
                '_transient_' . self::KEY_PREFIX . '%',
                '_transient_timeout_' . self::KEY_PREFIX . '%'
            )
        );

        foreach ( $rows as $option_name ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery
            $wpdb->delete( $wpdb->options, [ 'option_name' => $option_name ] );
            $deleted++;
        }

        Logger::info( 'Cache flushed.', [ 'deleted' => $deleted ] );

        return $deleted;
    }

    // ──────────────────────────────────────────────────────────────
    //  Private helpers
    // ──────────────────────────────────────────────────────────────

    /**
     * Build the full transient key, hashing if necessary.
     *
     * @since 1.0.1
     * @param string $key Raw key.
     * @return string Prefixed and possibly hashed key.
     */
    private static function build_key( string $key ): string {
        $full = self::KEY_PREFIX . $key;

        if ( strlen( $full ) > self::MAX_KEY_LENGTH ) {
            $full = self::KEY_PREFIX . md5( $key );
        }

        return $full;
    }

    /**
     * Retrieve the configured default TTL in seconds.
     *
     * Falls back to 15 minutes if the option has not been set yet
     * (e.g. during the activation sequence).
     *
     * @since 1.0.1
     * @return int TTL in seconds.
     */
    private static function default_ttl(): int {
        $settings = get_option( 'zymarg_hp_settings', [] );
        $minutes  = isset( $settings['cache_duration'] )
            ? (int) $settings['cache_duration']
            : 15;

        return max( 1, $minutes ) * MINUTE_IN_SECONDS;
    }
}
