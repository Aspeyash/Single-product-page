<?php
/**
 * ZYMARG Homepage – Global Asset Manager
 *
 * Enqueues CSS and JS that must be available on every page where the
 * plugin outputs content. Feature-specific assets are NOT loaded here —
 * each Feature's own Assets.php handles those conditionally.
 *
 * Rules (from CONTRIBUTING.md §7 & §8):
 *   • wp_enqueue_* calls from template files are forbidden.
 *   • Feature assets load only when that feature is enabled.
 *   • Global assets (design tokens, base utilities) are loaded here.
 *   • No inline <style> or <script> blocks.
 *
 * zhpAjax:
 *   • A data-only global carrying the AJAX and REST URLs, the newsletter
 *     nonce and the shared i18n strings.
 *
 * Phase 7 adds:
 *   • Asset URLs resolved through Core\AssetPath, which prefers the built
 *     .min file when present and falls back to the source when it is not.
 *
 * @package ZYMARGHomepage\Core
 * @since   1.0.1
 * @version 1.44.2
 */

namespace ZYMARGHomepage\Core;

use ZYMARGHomepage\Homepage\FeatureRegistry;
use ZYMARGHomepage\Homepage\HomepageController;
use ZYMARGHomepage\Integration\ProductGridBridge;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Assets
 *
 * Manages plugin-wide CSS and JS. Instantiated by Plugin::setup() and
 * bound to WordPress action hooks via Hooks::register().
 */
final class Assets {

    /**
     * Homepage controller, used to resolve which sections are active.
     *
     * @since 1.10.0
     * @var HomepageController|null
     */
    private ?HomepageController $controller;

    /**
     * Constructor.
     *
     * @since 1.7.0
     * @param HomepageController|null $controller Homepage engine, for feature asset resolution.
     */
    public function __construct( ?HomepageController $controller = null ) {
        $this->controller = $controller;
    }

    /**
     * Enqueue global frontend styles and scripts.
     *
     * Hooked to wp_enqueue_scripts by Hooks::register().
     *
     * @since 1.0.1
     * @return void
     */
    public function enqueue_frontend(): void {
        // Plugin assets are only useful where the plugin actually renders.
        // Previously these loaded on every page of the site.
        if ( ! $this->is_homepage_request() ) {
            return;
        }

        $this->enqueue_tokens();
        $this->enqueue_frontend_scripts();
        $this->enqueue_feature_styles();
        $this->enqueue_carousel_assets();
        $this->enqueue_card_template_styles();
    }

    /**
     * Load the Product Grid card template's own stylesheet in the <head>.
     *
     * The engine enqueues a card template's style.css from inside its render
     * routine. On the homepage that render happens during the_content(), which
     * runs after wp_head() has already been sent, so WordPress prints the
     * <link> in the footer instead. The branded card therefore paints before
     * its stylesheet arrives: the 1:1 box on .zymarg-zc__image-wrap is not yet
     * in force, every product image renders at its natural size, and the whole
     * grid snaps down when the CSS finally lands. That is the layout shift on
     * first load, and it is why the engine's default card is unaffected — its
     * rules live in zymarg-wcpg-frontend, which does reach the <head>.
     *
     * The engine already solves this for its own shortcodes in
     * Shortcode_Asset_Preloader, but that class is deliberately scoped to the
     * wishlist, recently-viewed and My Account pages and does nothing here.
     * So we do the same thing for the homepage: resolve the card's stylesheet
     * through the engine's Template_Manager and enqueue it during
     * wp_enqueue_scripts, well before first paint.
     *
     * Registering under the engine's own handle makes this idempotent. When
     * the engine later reaches its render-time enqueue it finds the handle
     * already registered and enqueued, so nothing is duplicated and the URL
     * and version stay exactly what the engine would have produced.
     *
     * @since 1.44.2
     * @return void
     */
    private function enqueue_card_template_styles(): void {
        if ( ! class_exists( ProductGridBridge::class ) || ! ProductGridBridge::is_active() ) {
            return;
        }

        $slug = ProductGridBridge::card_template();

        // An empty slug means the admin chose the engine's default card,
        // whose styles already ship inside the engine's frontend stylesheet.
        if ( '' === $slug ) {
            return;
        }

        if ( ! class_exists( '\\Zymarg\\WCPG\\Templates\\Template_Manager' ) ) {
            return;
        }

        $handle = 'zymarg-wcpg-card-' . $slug;

        if ( wp_style_is( $handle, 'enqueued' ) ) {
            return;
        }

        if ( wp_style_is( $handle, 'registered' ) ) {
            wp_enqueue_style( $handle );
            return;
        }

        $assets = \Zymarg\WCPG\Templates\Template_Manager::get_card_assets( $slug );

        if ( empty( $assets['css']['url'] ) ) {
            return;
        }

        // Depend on the engine stylesheet only if it exists, so a change in
        // the engine's registration order can never drop our <link>.
        $deps = wp_style_is( 'zymarg-wcpg-frontend', 'registered' )
            ? [ 'zymarg-wcpg-frontend' ]
            : [];

        wp_register_style(
            $handle,
            $assets['css']['url'],
            $deps,
            $assets['css']['version'] ?? ZYMARG_HP_VERSION,
            'all'
        );

        wp_enqueue_style( $handle );
    }

    /**
     * Determine whether the current request renders the plugin homepage.
     *
     * True on the site front page, or on any singular post/page whose
     * content contains the [zymarg_homepage] shortcode.
     *
     * @since 1.10.0
     * @return bool
     */
    private function is_homepage_request(): bool {
        if ( is_admin() ) {
            return false;
        }

        if ( is_front_page() ) {
            return true;
        }

        if ( is_singular() ) {
            $post = get_post();
            if ( $post instanceof \WP_Post && has_shortcode( (string) $post->post_content, 'zymarg_homepage' ) ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Enqueue the stylesheet belonging to each ACTIVE feature section.
     *
     * Every Features/*\/Assets.php class already had a working enqueue()
     * method, but nothing in the plugin ever instantiated or called them —
     * Hooks::register() only bound this global Assets class. The result was
     * that only zymarg-tokens.css ever loaded, so all nine section
     * stylesheets were dead code and the homepage rendered essentially
     * unstyled beyond the base tokens and utilities.
     *
     * The Assets class for a feature is resolved from that feature's own
     * namespace, so no change to FeatureInterface or the Feature classes is
     * required. The seven ProductSections sub-features all share a single
     * namespace and therefore a single stylesheet, which is de-duplicated
     * here and again by WordPress via the shared handle.
     *
     * @since 1.10.0
     * @return void
     */
    private function enqueue_feature_styles(): void {
        if ( ! $this->controller instanceof HomepageController || ! $this->controller->is_active() ) {
            return;
        }

        $done = [];

        foreach ( $this->controller->get_section_manager()->get_active_sections() as $section ) {
            $feature = FeatureRegistry::get( $section['slug'] ?? '' );

            if ( null === $feature ) {
                continue;
            }

            $namespace   = ( new \ReflectionClass( $feature ) )->getNamespaceName();
            $assets_class = $namespace . '\\Assets';

            if ( isset( $done[ $assets_class ] ) || ! class_exists( $assets_class ) ) {
                continue;
            }

            $done[ $assets_class ] = true;

            $instance = new $assets_class();

            if ( method_exists( $instance, 'enqueue' ) ) {
                $instance->enqueue();
            }
        }
    }

    /**
     * Enqueue the carousel stylesheet and script.
     *
     * Only loaded when at least one active section actually has its
     * carousel setting enabled, so sites that keep the default wrapping
     * grids pay nothing for this feature.
     *
     * @since 1.11.0
     * @return void
     */
    private function enqueue_carousel_assets(): void {
        if ( ! $this->controller instanceof HomepageController || ! $this->controller->is_active() ) {
            return;
        }

        $wanted = false;

        foreach ( $this->controller->get_section_manager()->get_active_sections() as $section ) {
            if ( ! empty( $section['settings']['carousel'] ) ) {
                $wanted = true;
                break;
            }
        }

        if ( ! $wanted ) {
            return;
        }

        wp_enqueue_style(
            'zhp-carousel',
            AssetPath::url( 'assets/css/frontend/carousel', 'css' ),
            [ 'zhp-tokens' ],
            ZYMARG_HP_VERSION,
            'all'
        );

        wp_enqueue_script(
            'zhp-carousel',
            AssetPath::url( 'assets/js/frontend/carousel', 'js' ),
            [ 'zhp-runtime' ],
            ZYMARG_HP_VERSION,
            true
        );
    }


    // ──────────────────────────────────────────────────────────────
    //  Private helpers
    // ���─────────────────────────────────────────────────────────────

    /**
     * Enqueue the design-token stylesheet.
     *
     * zymarg-tokens.css defines every CSS custom property and the handful
     * of base utility classes (.zhp-container, .zhp-btn-primary, etc.).
     * All other plugin stylesheets load after this one and inherit the tokens.
     *
     * @since 1.0.1
     * @return void
     */
    private function enqueue_tokens(): void {
        wp_enqueue_style(
            'zhp-tokens',
            AssetPath::url( 'assets/css/frontend/zymarg-tokens', 'css' ),
            [],
            ZYMARG_HP_VERSION,
            'all'
        );

        $this->add_typography_overrides();
    }

    /**
     * Emit the admin's text-size choices as CSS custom properties.
     *
     * Attached to the token stylesheet rather than written into a template, so
     * the values arrive in the <head> with the rest of the CSS and never cause
     * a flash of differently-sized text.
     *
     * Nothing is emitted when both settings are 0 ("automatic"). That is what
     * keeps the responsive clamp() in zymarg-tokens.css in charge by default:
     * an override, even one equal to today's value, would freeze the size and
     * stop it scaling with the viewport.
     *
     * Read with get_option() rather than through Admin\Settings because Core
     * must not depend on the admin layer — the admin classes are not loaded on
     * a front-end request. Core\Cache and Core\Helpers read the same option the
     * same way.
     *
     * @since 1.21.0
     * @return void
     */
    private function add_typography_overrides(): void {
        $settings = get_option( 'zymarg_hp_settings', [] );

        if ( ! is_array( $settings ) ) {
            return;
        }

        $title_px   = absint( $settings['section_title_size'] ?? 0 );
        $explore_px = absint( $settings['explore_link_size'] ?? 0 );

        $declarations = '';

        // Bounds are enforced here as well as in the save handler. This value
        // goes straight into a stylesheet, and an option can be written by
        // WP-CLI, a migration, or another plugin without passing through the
        // settings form at all.
        if ( $title_px >= 14 && $title_px <= 48 ) {
            $declarations .= '--zhp-section-title-size:' . $title_px . 'px;';
        }

        if ( $explore_px >= 10 && $explore_px <= 24 ) {
            $declarations .= '--zhp-explore-more-size:' . $explore_px . 'px;';
        }

        // Every spacing control now comes from the Core\Spacing registry: the
        // three scale controls that used to be written out longhand here, plus
        // the gap controls added in 1.45.0. Bounds, defaults, and the rule that
        // a default value emits nothing all live in that one class instead of
        // being restated per control across four files.
        $declarations .= Spacing::declarations( $settings );

        if ( '' === $declarations ) {
            return;
        }

        wp_add_inline_style( 'zhp-tokens', ':root{' . $declarations . '}' );
    }

    /**
     * Enqueue frontend JavaScript and localise the shared zhpAjax global.
     *
     * URLs come from Core\AssetPath: the built .min.js in production, the
     * unminified original under SCRIPT_DEBUG for readable stack traces.
     *
     * @since 1.6.0
     * @return void
     */
    private function enqueue_frontend_scripts(): void {
        // load-more.js and filters.js were removed in 1.30.0 along with the
        // AJAX handlers behind them. zhpAjax survives because it carries
        // the newsletter nonce and the carousel labels, so it is now
        // localised onto a data-only handle that always loads.
        wp_register_script( 'zhp-runtime', false, [], ZYMARG_HP_VERSION, true );
        wp_enqueue_script( 'zhp-runtime' );

        // Localise zhpAjax onto the data-only runtime handle.
        // This object is shared by all frontend scripts in the global scope.
        wp_localize_script(
            'zhp-runtime',
            'zhpAjax',
            [
                'ajaxUrl' => esc_url( admin_url( 'admin-ajax.php' ) ),
                'restUrl' => esc_url( rest_url( 'zhp/v1/' ) ),
                'nonces'  => [
                    'newsletter' => wp_create_nonce( 'zhp_newsletter' ),
                ],
                'i18n' => [
                    // 'exploreMore' is the label shown on the control in each
                    // section header since 1.21.0.
                    'exploreMore' => __( 'Explore More', 'zymarg-homepage' ),
                    'loading'  => __( 'Loading…',  'zymarg-homepage' ),
                    'noMore'   => __( 'No more products.', 'zymarg-homepage' ),
                    'error'    => __( 'Something went wrong. Please try again.', 'zymarg-homepage' ),
                    'carouselPrev' => __( 'Scroll left', 'zymarg-homepage' ),
                    'carouselNext' => __( 'Scroll right', 'zymarg-homepage' ),
                ],
            ]
        );
    }
}
