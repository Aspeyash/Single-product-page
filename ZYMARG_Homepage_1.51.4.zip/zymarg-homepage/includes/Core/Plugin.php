<?php
/**
 * ZYMARG Homepage – Main Plugin Class
 *
 * Singleton entry-point for all plugin subsystems. Instantiated once via
 * Plugin::get_instance() on the plugins_loaded hook in zymarg-homepage.php.
 *
 * Phase 1 wired up:  Hooks, Assets, Logger.
 * Phase 2 adds:      HomepageController (FeatureRegistry, SectionManager,
 *                    LayoutEngine, Renderer) + shortcode + public function.
 * Phase 3 adds:      Admin panel (Admin, Menu, DragDrop, Pages).
 *
 * @package ZYMARGHomepage\Core
 * @since   1.0.1
 * @version 1.22.0
 */

namespace ZYMARGHomepage\Core;

use ZYMARGHomepage\Homepage\HomepageController;
use ZYMARGHomepage\Admin\Admin;
use ZYMARGHomepage\Core\Activator;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Plugin
 *
 * Boots and wires all plugin subsystems. Use get_instance() — never new Plugin().
 */
final class Plugin {

    /**
     * Singleton instance.
     *
     * @since 1.0.1
     * @var static|null
     */
    private static ?Plugin $instance = null;

    /**
     * Core subsystems — populated in setup().
     *
     * @since 1.0.1
     */
    private Hooks  $hooks;
    private Assets $assets;

    /**
     * Homepage engine — added in Phase 2.
     *
     * @since 1.1.0
     * @var HomepageController
     */
    private HomepageController $controller;

    /**
     * Admin subsystem — added in Phase 3.
     *
     * @since 1.3.0
     * @var Admin|null
     */
    private ?Admin $admin = null;

    /**
     * Private constructor — use get_instance().
     *
     * @since 1.0.1
     */
    private function __construct() {}

    /**
     * Return (and on first call, create) the singleton instance.
     *
     * Called by add_action( 'plugins_loaded', … ) in zymarg-homepage.php.
     *
     * @since 1.0.1
     * @return static
     */
    public static function get_instance(): static {
        if ( null === static::$instance ) {
            static::$instance = new static();
            static::$instance->setup();
        }
        return static::$instance;
    }

    // ──────────────────────────────────────────────────────────────
    //  Setup
    // ──────────────────────────────────────────────────────────────

    /**
     * Initialise all subsystems.
     *
     * Order matters:
     *   1. Logger         — available immediately so other systems can log.
     *   2. i18n           — strings ready before anything outputs text.
     *   3. HomepageController — boots FeatureRegistry and rendering engine.
     *   4. Admin          — only instantiated when is_admin().
     *   5. Hooks          — registers all add_action / add_filter / add_shortcode.
     *   6. Assets         — enqueue callbacks registered via Hooks.
     *
     * @since 1.0.1
     * @return void
     */
    private function setup(): void {
        Logger::init();
        $this->load_textdomain();

        // Phase 2: boot the homepage engine first so Hooks can bind its methods.
        $this->controller = new HomepageController();

        // Phase 3: boot admin subsystem (admin context only).
        if ( is_admin() ) {
            $this->admin = new Admin( $this->controller );
        }

        $this->hooks = new Hooks();

        // Assets needs the controller so it can enqueue the stylesheet for
        // each ACTIVE section. Without this the per-feature CSS never loads
        // and the homepage renders unstyled (all sections stacked vertically).
        $this->assets = new Assets( $this->controller );

        // Pass controller and admin into Hooks so it can register all callbacks.
        $this->hooks->register( $this->assets, $this->controller, $this->admin );

        Logger::debug( 'Plugin booted — v' . ZYMARG_HP_VERSION );
    }

    /**
     * Load the plugin text domain for i18n.
     *
     * @since 1.0.1
     * @return void
     */
    private function load_textdomain(): void {
        load_plugin_textdomain(
            ZYMARG_HP_TEXT_DOMAIN,
            false,
            dirname( plugin_basename( ZYMARG_HP_PLUGIN_FILE ) ) . '/languages'
        );
    }

    // ──────────────────────────────────────────────────────────────
    //  Activation / Deactivation
    // ──────────────────────────────────────────────────────────────

    /**
     * Run on plugin activation.
     *
     * Triggered by register_activation_hook() in zymarg-homepage.php.
     * Sets up default options and flushes rewrite rules.
     *
     * @since 1.0.1
     * @return void
     */
    public static function activate(): void {
        if ( ! current_user_can( 'activate_plugins' ) ) {
            return;
        }

        // Seed the section order option on first activation.
        if ( false === get_option( 'zymarg_hp_section_order' ) ) {
            add_option( 'zymarg_hp_section_order', [] );
        }

        // Seed the global settings option on first activation.
        //
        // This list has to match Admin\Settings::DEFAULTS, and until 1.45.0 it
        // quietly did not: section_gap, header_gap and band_gap were added to
        // the settings class but never here, so a fresh install had no stored
        // row for them. It was survivable rather than harmless - reads go
        // through array_merge() with the defaults, so the values were correct -
        // but anything inspecting the option directly saw keys that did not
        // exist yet.
        //
        // The spacing half is now merged in from the same registry the
        // settings class reads, so the two can no longer drift apart.
        if ( false === get_option( 'zymarg_hp_settings' ) ) {
            add_option( 'zymarg_hp_settings', array_merge( [
                'master_enabled'       => true,
                'products_per_section' => 8,
                'cache_duration'       => 15,
                'support_email'        => '',
                'use_product_grid_cards' => true,
                'section_title_size'   => 0,
                'explore_link_size'    => 0,
                'card_template'        => 'zymarg',
            ], Spacing::defaults() ) );
        }

        // Auto-setup: find or create the homepage and configure WordPress
        // to serve it as the static front page — no manual steps required.
        Activator::run();

        flush_rewrite_rules();
    }

    /**
     * Run on plugin deactivation.
     *
     * Triggered by register_deactivation_hook() in zymarg-homepage.php.
     * Options and saved data are preserved — use uninstall.php for cleanup.
     *
     * @since 1.0.1
     * @return void
     */
    public static function deactivate(): void {
        if ( ! current_user_can( 'activate_plugins' ) ) {
            return;
        }

        flush_rewrite_rules();
    }
}
