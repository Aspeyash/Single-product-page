<?php
/**
 * ZYMARG Homepage – Core Constants
 *
 * Plugin-level constants (version, text domain, brand primary colour).
 *
 * Design tokens (colours, spacing, typography, radius, shadows, animation)
 * live in ONE place: assets/css/frontend/zymarg-tokens.css.
 * PHP files that need a token value — e.g. to generate an inline SVG or
 * output a style attribute — should read ZHP_COLOR_PRIMARY from here.
 * Do not duplicate individual token values anywhere else in PHP.
 *
 * Previously this file held the full token set as PHP constants. All those
 * constants were audited in v1.24.0 and found to have zero callers; they
 * have been removed. The canonical token list is zymarg-tokens.css.
 *
 * Plugin path constants (ZYMARG_HP_PLUGIN_FILE / _DIR / _URL) are defined
 * in zymarg-homepage.php before this file is loaded.
 *
 * @package ZYMARGHomepage
 * @since   1.0.1
 * @version 1.31.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// ═══════════════════════════════════════════════════════════════
//  PLUGIN VERSIONING
//  ─────────────────────────────────────────────────────────────
//  !! READ BEFORE EDITING !!
//
//  Every time ANY file inside this plugin is changed — no matter
//  how small — the version MUST be bumped in ALL of the following
//  places before the zip is packaged:
//
//    1. The "Version:" header in zymarg-homepage.php
//    2. ZYMARG_HP_VERSION constant below
//    3. A @version comment at the top of every changed PHP file
//    4. A @version comment at the top of every changed JS/CSS file
//    5. Any @since tag introduced in that session
//    6. The zip filename  →  "ZYMARG Homepage {version}.zip"
//
//  Follow semver: MAJOR.MINOR.PATCH
//    PATCH  – bug fixes, copy tweaks, CSS micro-adjustments
//    MINOR  – new feature, new section, new setting
//    MAJOR  – architectural overhaul, breaking change
//
//  Never ship two different zips with the same version number.
// ═══════════════════════════════════════════════════════════════

define( 'ZYMARG_HP_VERSION',     '1.51.4' );
define( 'ZYMARG_HP_TEXT_DOMAIN', 'zymarg-homepage' );

// ── Brand primary (PHP callers only) ───────────────────────────
// This is the ONE colour value kept in PHP. It is used by:
//   Admin\Menu::render_menu_css()  — colours the sidebar menu label.
//   Admin\Menu::get_menu_icon()    — tints the SVG icon (via data URI).
// All other design tokens live in assets/css/frontend/zymarg-tokens.css.
// Do not add more colour constants here; use a CSS custom property instead.
define( 'ZHP_COLOR_PRIMARY', '#9500A5' );
