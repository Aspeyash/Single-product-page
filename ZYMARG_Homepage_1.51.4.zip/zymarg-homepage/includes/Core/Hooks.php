<?php
/**
 * ZYMARG Homepage – Hook Registry
 *
 * SINGLE LOCATION for every add_action() and add_filter() call in this
 * plugin. No other file may call add_action() or add_filter() directly.
 *
 * All hook registrations are split by subsystem:
 *   register()       — always runs (both frontend and admin)
 *
 * Phase 1 registered:
 *   • Global CSS/JS enqueueing (frontend)
 *
 * Phase 2 adds:
 *   • [zymarg_homepage] shortcode
 *
 * Phase 3 adds:
 *   • admin_menu
 *   • admin_enqueue_scripts
 *   • AJAX handlers (save sections, reset sections, save settings)
 *
 * Phase 6 adds:
 *   • rest_api_init → zhp/v1/* endpoints
 *
 * Phase 7.2 adds:
 *   • the_content filter → HomepageController::maybe_override_content()
 *     so the front page is taken over automatically without a shortcode.
 *
 * @package ZYMARGHomepage\Core
 * @since   1.0.1
 * @version 1.31.0
 */

namespace ZYMARGHomepage\Core;

use ZYMARGHomepage\Ajax\DashboardStatus;
use ZYMARGHomepage\Homepage\HomepageController;
use ZYMARGHomepage\Admin\Admin;
use ZYMARGHomepage\REST\Routes;
use ZYMARGHomepage\Integration\ProductGridBridge;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Hooks
 *
 * Centralised hook registry. Instantiated by Plugin::setup() and passed
 * any subsystem instances it needs to bind callbacks to.
 */
final class Hooks {

    /**
     * Register all hooks with WordPress.
     *
     * Accepts subsystem instances so we can bind their callbacks without
     * tight coupling in constructors.
     *
     * @since 1.0.1
     * @param Assets             $assets     Global asset manager.
     * @param HomepageController $controller Homepage engine.
     * @param Admin|null         $admin      Admin subsystem (null on frontend).
     * @return void
     */
    public function register(
        Assets $assets,
        HomepageController $controller,
        ?Admin $admin = null
    ): void {
        // ── Frontend hooks ───────────────────────────────────────
        add_action( 'wp_enqueue_scripts', [ $assets, 'enqueue_frontend' ] );

        // ── Shortcode ────────────────────────────────────────────
        // [zymarg_homepage] — renders the full homepage HTML inline.
        add_shortcode( 'zymarg_homepage', [ $controller, 'render' ] );

        // ── Automatic front page takeover ─────────────────────────
        // Replaces the front page post content with plugin output at runtime.
        // No shortcode or manual page edit required after activation.
        // Safe when shortcode is present — maybe_override_content() detects it.
        add_filter( 'the_content', [ $controller, 'maybe_override_content' ] );

        // -- Banner post type (removed in 1.28.0) -----------------
        // The zhp_banner CPT and its Banners menu were a second place to
        // do a job this plugin already does on Homepage > Sections. Hero
        // and Promo Banner simply duplicated panels that already existed
        // there, and because BannerQuery preferred the CPT over settings,
        // an empty banner post silently overrode a working panel.
        //
        // Collections was the only section that genuinely needed a card
        // list, and it now stores its cards in its own section settings,
        // so nothing needs the post type any more. BannerQuery keeps its
        // post_type_exists() guard, which is simply false from now on, so
        // Hero and Promo Banner resolve from their settings panels.

        // ── Product Grid plugin bridge ───────────────────────────
        // Lets the ZYMARG WC Product Grid engine draw homepage cards so the
        // whole site shares one card design. The bridge decides for itself
        // whether to act: it returns null — leaving the homepage to render its
        // own cards — whenever the engine is absent, not booted, switched off
        // by the admin, or unable to produce output. Registering it here is
        // therefore always safe, on any site.
        $product_grid_bridge = new ProductGridBridge();
        add_filter( 'zhp_product_grid_html_pre', [ $product_grid_bridge, 'maybe_render' ], 10, 4 );

        // The engine hands over its chosen products here, which is how the
        // Flash Deals countdown learns the real sale end date.
        add_filter( 'zymarg_products', [ ProductGridBridge::class, 'capture_sale_end' ], 10, 1 );

        // Load More, Search and product Filters were removed in 1.30.0.
        // Those behaviours belong to the ZYMARG WC Product Grid engine,
        // which owns product rendering and its own pagination.
        $dashboard_status = new DashboardStatus();
        add_action( 'wp_ajax_zhp_dashboard_status', [ $dashboard_status, 'handle' ] );

        // REST API — registered on rest_api_init.
        $routes = new Routes();
        add_action( 'rest_api_init', [ $routes, 'register' ] );

        // ── Admin hooks ──────────────────────────────────────────
        if ( null !== $admin ) {
            // Admin menu registration.
            add_action( 'admin_menu', [ $admin->get_menu(), 'register' ] );

            // Sidebar parent-menu branding (Design Tokens v3 section 2.16).
            // Runs on admin_enqueue_scripts on every admin page so the
            // top-level item reads as ours everywhere, not only on the
            // plugin's own screens.
            add_action( 'admin_enqueue_scripts', [ $admin->get_menu(), 'enqueue_menu_branding' ] );

            // Admin asset enqueueing.
            add_action( 'admin_enqueue_scripts', [ $admin->get_assets(), 'enqueue' ] );

            // Contextual help panel on the Banners screens. The handler checks
            // the current screen itself and prints nothing anywhere else, so
            // registering it unconditionally here is safe.

            // AJAX: save section order and settings.
            add_action( 'wp_ajax_zhp_save_sections', [ $admin->get_drag_drop(), 'handle_save' ] );

            // AJAX: reset section order to defaults.
            add_action( 'wp_ajax_zhp_reset_sections', [ $admin->get_drag_drop(), 'handle_reset' ] );

            // AJAX: save global settings.
            $settings_handler = new \ZYMARGHomepage\Admin\Settings();
            add_action( 'wp_ajax_zhp_save_settings', [ $settings_handler, 'handle_save' ] );

            // AJAX: serve a plugin admin screen for in-place navigation.
            add_action( 'wp_ajax_zhp_admin_page', [ $admin->get_ajax_router(), 'handle' ] );
        }
    }
}
