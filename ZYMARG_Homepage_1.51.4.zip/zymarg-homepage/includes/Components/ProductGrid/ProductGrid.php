<?php
/**
 * ZYMARG Homepage - Product Grid Component (delegating shell)
 *
 * As of 1.30.0 this plugin no longer draws product cards. That job belongs to
 * the ZYMARG WC Product Grid engine, which already rendered every card on the
 * live site through the bridge below. This component is deliberately kept --
 * rather than deleted -- because it is the single place the homepage fires
 * zhp_product_grid_html_pre, and that filter is how the engine is invoked.
 * Removing the class would disconnect the engine entirely.
 *
 * WHAT CHANGED
 * ------------
 * Before: fire the filter, and if nothing claimed it, build the whole grid
 * from its own card component.
 * Now:    fire the filter, and if nothing claims it, render nothing for
 *         visitors and an explanatory notice for administrators.
 *
 * The homepage still decides WHICH products appear and in what order. Only the
 * card and grid markup moved to the engine.
 *
 * @package ZYMARGHomepage\Components\ProductGrid
 * @since   1.8.0
 * @version 1.31.0
 */

namespace ZYMARGHomepage\Components\ProductGrid;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class ProductGrid
 *
 * @since 1.8.0
 */
class ProductGrid {

    /**
     * Hand a product grid to the rendering engine.
     *
     * The signature is unchanged from 1.8.0 so every existing caller keeps
     * working without modification.
     *
     * @since 1.8.0
     * @param array $products     Normalised product rows chosen by the homepage.
     * @param array $card_options Options forwarded to the engine.
     * @return string Engine markup, an admin notice, or an empty string.
     */
    public function render( array $products, array $card_options = [] ): string {
        $source = isset( $card_options['source'] ) ? sanitize_key( (string) $card_options['source'] ) : '';

        // With a source key the engine runs its own query, so an empty
        // $products array is expected and must not short-circuit.
        if ( '' === $source && empty( $products ) ) {
            return '';
        }

        $is_carousel = ! empty( $card_options['carousel'] );

        // Grid-level keys must not leak into the engine's card config.
        unset( $card_options['carousel'], $card_options['grid_class'] );

        /**
         * Short-circuit the entire grid.
         *
         * ProductGridBridge is attached here at priority 10. Any string return
         * is used verbatim.
         *
         * @since 1.13.0
         * @param string|null $html         Replacement HTML, or null.
         * @param array       $products     Normalised product rows.
         * @param array       $card_options Card options.
         * @param bool        $is_carousel  Whether this grid is a carousel track.
         */
        $pre = apply_filters( 'zhp_product_grid_html_pre', null, $products, $card_options, $is_carousel );

        if ( is_string( $pre ) && '' !== trim( $pre ) ) {
            /** This filter is documented above. */
            return (string) apply_filters( 'zhp_product_grid_html', $pre, $products, $card_options, $is_carousel );
        }

        $bridge = '\\ZYMARGHomepage\\Integration\\ProductGridBridge';

        // Distinguish 'engine absent' from 'engine present but this source
        // is not registered yet', so the admin notice names the real cause.
        if ( '' !== $source
            && class_exists( $bridge )
            && call_user_func( array( $bridge, 'is_engine_available' ) )
            && ! call_user_func( array( $bridge, 'is_source_available' ), $source )
        ) {
            return self::source_missing_notice( $source );
        }

        return self::engine_missing_notice();
    }

    /**
     * Explain the empty row to administrators, and only to administrators.
     *
     * Visitors get an empty string, so a missing engine degrades to a section
     * that simply is not there rather than a broken-looking one.
     *
     * @since 1.30.0
     * @return string
     */
    private static function engine_missing_notice(): string {
        if ( ! function_exists( 'current_user_can' ) || ! current_user_can( 'manage_options' ) ) {
            return '';
        }

        return sprintf(
            '<div class="zhp-engine-notice" role="status"><strong>%1$s</strong><span>%2$s</span></div>',
            esc_html__( 'Product engine not connected', 'zymarg-homepage' ),
            esc_html__( 'This row has products to show, but the ZYMARG WC Product Grid plugin is not installed, not activated, or has not finished booting. Only administrators can see this message.', 'zymarg-homepage' )
        );
    }
    /**
     * Explain a source the engine does not know about, to administrators only.
     *
     * Reached when the engine is booted but the requested source key is not in
     * its registry -- currently only flash_deals, which is pending in the
     * Product Grid plugin. Showing nothing to visitors is deliberate: the
     * engine would otherwise silently fall back to its 'all' source and fill
     * the row with unrelated products.
     *
     * @since 1.31.0
     * @param string $source The unavailable source key.
     * @return string
     */
    private static function source_missing_notice( string $source ): string {
        if ( ! function_exists( 'current_user_can' ) || ! current_user_can( 'manage_options' ) ) {
            return '';
        }

        return sprintf(
            '<div class="zhp-engine-notice" role="status"><strong>%1$s</strong><span>%2$s</span></div>',
            esc_html__( 'Product source not available yet', 'zymarg-homepage' ),
            sprintf(
                /* translators: %s: engine source key, e.g. flash_deals. */
                esc_html__( 'The ZYMARG WC Product Grid plugin does not provide the "%s" source yet, so this row is hidden from visitors rather than filled with unrelated products. It will start working automatically once that source is added. Only administrators can see this message.', 'zymarg-homepage' ),
                esc_html( $source )
            )
        );
    }
}
