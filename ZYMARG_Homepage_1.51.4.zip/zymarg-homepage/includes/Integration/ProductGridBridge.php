<?php
/**
 * ZYMARG Homepage – Product Grid Bridge
 *
 * Hands product-card rendering to the ZYMARG WC Product Grid plugin when that
 * plugin is present, booted and enabled, so the whole site shows one card
 * design. When it is missing, not booted, disabled by the admin, or fails for
 * any reason, this bridge stands aside and the homepage renders its own cards.
 *
 * WHY "BOOTED" AND NOT MERELY "ACTIVE"
 * ------------------------------------
 * Checking whether the plugin is active is not enough. The engine gates its
 * own start-up on a compatibility check, and when that check fails it returns
 * early before initialising its API bootstrap. In that state the classes are
 * all loaded and every naive detection test passes, but Public_API::render()
 * returns an empty string. Rows would silently render blank.
 *
 * So detection asks the engine itself whether it finished booting, via
 * Api_Bootstrap::is_initialized(). That is the same flag the engine's own
 * render path consults.
 *
 * FAILURE POLICY
 * --------------
 * Every failure mode returns null, which tells the calling component to render
 * normally. There is no path through this class that can produce a broken or
 * empty product row:
 *
 *   – engine absent, or missing the expected classes/methods  -> null
 *   – engine present but not booted                           -> null
 *   – admin toggle off                                        -> null
 *   – no resolvable WooCommerce products                      -> null
 *   – engine returns '' or its hide-widget sentinel           -> null
 *   – engine throws anything at all                           -> null
 *
 * @package ZYMARGHomepage\Integration
 * @since   1.14.0
 * @version 1.46.2
 */

namespace ZYMARGHomepage\Integration;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class ProductGridBridge
 *
 * @since 1.14.0
 */
final class ProductGridBridge {

    /**
     * Settings key holding the admin toggle.
     *
     * @since 1.14.0
     */
    public const SETTING_KEY = 'use_product_grid_cards';

    /**
     * The engine's single documented-stable entry point.
     *
     * @since 1.14.0
     */
    private const ENGINE_API = '\\Zymarg\\WCPG\\Api\\Public_API';

    /**
     * The engine's boot-state holder.
     *
     * @since 1.14.0
     */
    private const ENGINE_BOOTSTRAP = '\\Zymarg\\WCPG\\Bootstrap\\Api_Bootstrap';

    /**
     * Sentinel the engine returns when a context-aware source decides the
     * whole widget should be hidden. Treated as "no output".
     *
     * @since 1.14.0
     */
    private const HIDE_WIDGET = '__ZYMARG_HIDE_WIDGET__';

    /**
     * Homepage section slug -> engine source key.
     *
     * The engine's registry uses underscores (best_selling, current_vendor),
     * while homepage slugs use hyphens. Anything absent from this map has no
     * engine equivalent and must not be delegated.
     *
     * @since 1.31.0
     */
    private const SOURCE_MAP = [
        'featured-products' => 'featured',
        'trending-products' => 'trending',
        'best-sellers'      => 'best_selling',
        'flash-deals'       => 'flash_deals',
        /*
         * 'all' rather than 'recent' (1.46.2).
         *
         * Despite the name, the engine's 'recent' source is its *recently
         * viewed* source: Source_Recent opens by calling
         * Recently_Viewed::get_ids() and contains no date-ordered query at
         * all. This row was therefore showing each visitor their own browsing
         * history, and showing a first-time visitor nothing.
         *
         * Source_All ordered by date DESC is what "new arrivals" actually
         * means, and it always returns products.
         */
        'new-arrivals'      => 'all',
        'recommended'       => 'recommended',
        'dynamic-picks'     => 'dynamic',
    ];

    /**
     * Source keys shipped by the engine itself as of Product Grid 2.1.0.
     *
     * @since 1.31.0
     */
    private const ENGINE_SOURCES = [
        'all', 'dynamic', 'featured', 'best_selling', 'similar', 'recent',
        'wishlist', 'trending', 'vendor', 'current_vendor', 'algolia',
        'category', 'recommended',
    ];

    /**
     * Source keys that arrive from outside the engine's built-in registry,
     * mapped to the class whose presence proves the source is installed.
     *
     * flash_deals is pending in the Product Grid plugin. Until that class
     * exists the row is suppressed, because an unknown key makes the engine
     * fall back to its 'all' source silently -- which would fill a Flash
     * Deals row with unrelated products and look like a bug on the storefront.
     *
     * @since 1.31.0
     */
    private const EXTERNAL_SOURCE_CLASSES = [
        'flash_deals' => '\\Zymarg\\WCPG\\Query\\Source_Flash_Deals',
    ];

    /**
     * Translate a homepage section slug into an engine source key.
     *
     * @since 1.31.0
     * @param string $slug Homepage section slug.
     * @return string Engine source key, or '' when the slug has no equivalent.
     */
    public static function source_for_slug( string $slug ): string {
        return self::SOURCE_MAP[ $slug ] ?? '';
    }

    /**
     * Whether the engine can actually serve this source key.
     *
     * @since 1.31.0
     * @param string $source Engine source key.
     * @return bool
     */
    public static function is_source_available( string $source ): bool {
        /*
         * Ask the engine directly when it can answer (Product Grid 2.12.0+).
         *
         * The two constants below are a copy of a list that lives in another
         * plugin, and a copy goes stale in both directions: it reports a
         * source that was removed, and it hides a source that was added. Both
         * failures are silent. has_source() also checks that the class behind
         * the key is actually loadable, which is the case EXTERNAL_SOURCE_CLASSES
         * was hand-written to cover for exactly one key.
         *
         * The constants stay as the fallback for older engine versions.
         */
        if (
            class_exists( self::ENGINE_API )
            && method_exists( self::ENGINE_API, 'has_source' )
        ) {
            $api = self::ENGINE_API;

            return (bool) $api::has_source( $source );
        }

        if ( in_array( $source, self::ENGINE_SOURCES, true ) ) {
            return true;
        }

        $class = self::EXTERNAL_SOURCE_CLASSES[ $source ] ?? '';

        return '' !== $class && class_exists( $class );
    }

    /**
     * The Browse page URL for a homepage section, scoped to that section's feed.
     *
     * This is what makes "Explore More" land on a page showing the same kind of
     * products the section was showing, instead of dumping the shopper into an
     * unfiltered shop page that has nothing to do with what they just clicked.
     *
     * Returns '' whenever that promise cannot be kept -- Connection Engine not
     * active, too old to understand feeds, or the section has no engine source.
     * The caller then falls back to the shop page, which is the pre-1.47.0
     * behaviour. Never returns a Browse URL that would show the wrong products.
     *
     * @since 1.47.0
     * @param string $slug Homepage section slug, e.g. 'trending-products'.
     * @return string Absolute URL, or '' when unavailable.
     */
    public static function browse_url_for_slug( string $slug ): string {
        /*
         * Explore page first (1.48.0).
         *
         * Connection Engine 1.11.0 added a real Explore page for exactly this
         * purpose. It is preferred over the virtual Browse page because a real
         * page is not vulnerable to being claimed by another plugin's
         * template_include hook, which is what was happening on /category/.
         *
         * Both are read through function_exists so this plugin keeps working
         * against an older engine: with 1.10.x the Browse page is used exactly
         * as before, and with no engine at all the caller falls back to Shop.
         */
        $has_explore = function_exists( 'zymarg_ce_explore_url' );
        $has_browse  = function_exists( 'zymarg_ce_browse_url' );

        if ( ! $has_explore && ! $has_browse ) {
            return '';
        }

        $source = self::source_for_slug( $slug );

        if ( '' === $source ) {
            return '';
        }

        /*
         * 'all' is the whole catalogue, so scoping the destination to it would
         * add a parameter and a feed chip that mean nothing. Send those
         * sections to the unscoped page instead.
         */
        if ( 'all' === $source ) {
            $url = $has_explore ? (string) zymarg_ce_explore_url() : '';

            return ( '' !== $url || ! $has_browse ) ? $url : (string) zymarg_ce_browse_url();
        }

        if ( ! self::is_source_available( $source ) ) {
            return '';
        }

        $url = $has_explore ? (string) zymarg_ce_explore_url( $source ) : '';

        // An empty Explore URL means the page was trashed or never created, so
        // fall through to the Browse page rather than returning nothing.
        return ( '' !== $url || ! $has_browse ) ? $url : (string) zymarg_ce_browse_url( $source );
    }

    /**
     * The card template slug to ask the engine for.
     *
     * 'zymarg' is the branded card from the ZYMARG Template Pack. An admin who
     * picks 'Engine default' gets '' here, which leaves the engine on its own
     * 'classic' card.
     *
     * @since 1.31.0
     * @return string
     */
    /**
     * Soonest upcoming sale end seen in the last engine render, as a Unix
     * timestamp. 0 when nothing on screen is on a scheduled sale.
     *
     * @since 1.31.0
     * @var int
     */
    private static $sale_end = 0;

    /**
     * Record the soonest sale end among the products the engine just resolved.
     *
     * Hooked to the engine's zymarg_products filter, which hands over the
     * chosen products after the query and before rendering. This is how the
     * homepage learns what is in a row now that it no longer runs the query
     * itself. The value is read, and reset, by the section template.
     *
     * @since 1.31.0
     * @param mixed $products Products chosen by the engine.
     * @return mixed The products, unmodified.
     */
    public static function capture_sale_end( $products ) {
        if ( ! is_array( $products ) ) {
            return $products;
        }

        $soonest = 0;
        $now     = time();

        foreach ( $products as $product ) {
            if ( ! is_object( $product ) || ! method_exists( $product, 'get_date_on_sale_to' ) ) {
                continue;
            }

            $date = $product->get_date_on_sale_to();

            if ( ! $date || ! method_exists( $date, 'getTimestamp' ) ) {
                continue;
            }

            $timestamp = (int) $date->getTimestamp();

            if ( $timestamp > $now && ( 0 === $soonest || $timestamp < $soonest ) ) {
                $soonest = $timestamp;
            }
        }

        self::$sale_end = $soonest;

        return $products;
    }

    /**
     * Read and clear the captured sale end.
     *
     * Cleared on read so one row's deadline can never leak into the next.
     *
     * @since 1.31.0
     * @return int Unix timestamp, or 0 when there is no scheduled end.
     */
    public static function take_sale_end(): int {
        $value          = self::$sale_end;
        self::$sale_end = 0;

        return (int) $value;
    }

    /**
     * Is the ZYMARG Template Pack active?
     *
     * Checking for Template_Manager is NOT a valid test: that class ships
     * with the Product Grid engine, so it exists whenever the engine is
     * active, with or without the pack. The pack is what registers the
     * 'zymarg' card slug, so asking the registry is the only honest test.
     *
     * @since 1.31.1
     * @return bool
     */
    public static function is_template_pack_available(): bool {
        $manager = '\\Zymarg\\WCPG\\Templates\\Template_Manager';

        if ( ! class_exists( $manager ) || ! method_exists( $manager, 'is_registered_card' ) ) {
            return false;
        }

        return (bool) call_user_func( array( $manager, 'is_registered_card' ), 'zymarg' );
    }

    /**
     * Is the Flash Deals source available in the engine yet?
     *
     * @since 1.31.1
     * @return bool
     */
    public static function is_flash_deals_available(): bool {
        return self::is_source_available( 'flash_deals' );
    }

    public static function card_template(): string {
        $settings = get_option( 'zymarg_hp_settings', [] );
        $template = is_array( $settings ) && isset( $settings['card_template'] )
            ? sanitize_key( (string) $settings['card_template'] )
            : 'zymarg';

        if ( 'default' === $template || '' === $template ) {
            return '';
        }

        return preg_match( '/^[a-z0-9_-]+$/', $template ) ? $template : 'zymarg';
    }

    /**
     * Column counts for the engine, read from the spacing controls.
     *
     * The engine natively supports responsive columns: it reads
     * $config['responsive']['<tablet|mobile>']['layout']['columns'] and emits
     * data-columns-tablet / data-columns-mobile on the grid, which its own
     * stylesheet honours at 1024px and 767px. Until 1.50.3 this bridge sent a
     * hardcoded 4 and the homepage clawed the real counts back with
     * !important CSS aimed at the engine's own class names. Telling the engine
     * the right number up front is sturdier: it survives the engine renaming
     * .zymarg-wcpg__grid or its --cols-N modifiers.
     *
     * The CSS override is deliberately left in place. It is the fallback for
     * the two desktop values the engine cannot express (see the clamp below)
     * and the safety net if this config ever stops reaching the engine.
     *
     * get_option() rather than the Settings class, matching card_template()
     * above: this runs on the front end, where the admin class is not
     * guaranteed to be loaded.
     *
     * @since 1.50.3
     * @return array{desktop:int,tablet:int,mobile:int}
     */
    private static function column_counts(): array {
        $settings = get_option( 'zymarg_hp_settings', [] );
        $settings = is_array( $settings ) ? $settings : [];

        $defaults = \ZYMARGHomepage\Core\Spacing::defaults();

        $read = static function ( string $key, int $fallback ) use ( $settings, $defaults ): int {
            if ( isset( $settings[ $key ] ) && '' !== $settings[ $key ] ) {
                return (int) $settings[ $key ];
            }

            if ( isset( $defaults[ $key ] ) && '' !== $defaults[ $key ] ) {
                return (int) $defaults[ $key ];
            }

            return $fallback;
        };

        /*
         * The engine clamps columns to 1-6 (Render_Engine). The desktop
         * control allows up to 8, so 7 and 8 are clamped here rather than
         * silently mangled there, and the CSS override remains what actually
         * produces those two layouts.
         */
        $clamp = static function ( int $count ): int {
            return max( 1, min( 6, $count ) );
        };

        return [
            'desktop' => $clamp( $read( 'cards_per_row_desktop', 4 ) ),
            'tablet'  => $clamp( $read( 'cards_per_row_tablet', 3 ) ),
            'mobile'  => $clamp( $read( 'cards_per_row_mobile', 2 ) ),
        ];
    }

    /**
     * Whether the engine is installed AND finished booting.
     *
     * Deliberately does not use is_plugin_active(): that reports intent, not
     * readiness, and is only loaded in admin context anyway.
     *
     * @since 1.14.0
     * @return bool
     */
    public static function is_engine_available(): bool {
        if ( ! class_exists( self::ENGINE_API ) || ! method_exists( self::ENGINE_API, 'render' ) ) {
            return false;
        }

        if ( ! class_exists( self::ENGINE_BOOTSTRAP )
            || ! method_exists( self::ENGINE_BOOTSTRAP, 'is_initialized' )
        ) {
            return false;
        }

        // The engine's own answer to "did I boot?".
        return (bool) call_user_func( [ self::ENGINE_BOOTSTRAP, 'is_initialized' ] );
    }

    /**
     * Whether the admin has switched engine cards on.
     *
     * Defaults to true so that installing the engine later starts using its
     * card automatically, with no settings visit required.
     *
     * @since 1.14.0
     * @return bool
     */
    public static function is_enabled(): bool {
        $settings = get_option( 'zymarg_hp_settings', [] );

        if ( ! is_array( $settings ) || ! array_key_exists( self::SETTING_KEY, $settings ) ) {
            return true;
        }

        return ! empty( $settings[ self::SETTING_KEY ] );
    }

    /**
     * Whether this bridge should attempt to render.
     *
     * @since 1.14.0
     * @return bool
     */
    public static function is_active(): bool {
        $active = self::is_enabled() && self::is_engine_available();

        /**
         * Filter whether the Product Grid engine renders homepage cards.
         *
         * @since 1.14.0
         * @param bool $active Whether the bridge is active.
         */
        return (bool) apply_filters( 'zhp_use_product_grid_cards', $active );
    }

    /**
     * Short-circuit the homepage grid with engine-rendered markup.
     *
     * Hooked to zhp_product_grid_html_pre from Core\Hooks.
     *
     * @since 1.14.0
     * @param string|null $pre          Existing replacement HTML, or null.
     * @param array       $products     Pre-fetched rows, empty when a source key is used.
     * @param array       $card_options Card options from the calling section.
     * @param bool        $is_carousel  Whether this grid is a carousel track.
     * @return string|null Engine HTML, or null to let the homepage render.
     */
    public function maybe_render( $pre, array $products, array $card_options = [], bool $is_carousel = false ) {
        // Another integration already claimed this grid; do not fight it.
        if ( is_string( $pre ) ) {
            return $pre;
        }

        $source = isset( $card_options['source'] )
            ? sanitize_key( (string) $card_options['source'] )
            : '';

        if ( ! self::is_active() ) {
            return null;
        }

        // Without a source the caller must supply its own products.
        if ( '' === $source && empty( $products ) ) {
            return null;
        }

        // Never hand the engine a key it does not know: it would quietly
        // serve its 'all' source instead of failing.
        if ( '' !== $source && ! self::is_source_available( $source ) ) {
            return null;
        }

        $wc_products = '' === $source ? self::resolve_products( $products ) : [];

        if ( '' === $source && empty( $wc_products ) ) {
            return null;
        }

        if ( '' !== $source ) {
            $limit = absint( $card_options['limit'] ?? 0 );
            $limit = $limit > 0 ? $limit : 8;
        } else {
            $limit = count( $wc_products );
        }

        $args = [ 'config' => self::build_config( $card_options, $limit, $source ) ];

        // Passing 'products' makes the engine skip its Query Engine entirely,
        // so it is sent only on the legacy pre-fetched path.
        if ( '' === $source ) {
            $args['products'] = $wc_products;
        }

        try {
            $html = call_user_func( [ self::ENGINE_API, 'render' ], $args );
        } catch ( \Throwable $e ) {
            // The engine documents that it never throws, but a bridge must not
            // depend on another plugin honouring its own contract.
            if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
                error_log( sprintf( '[ZYMARG Homepage] Product Grid bridge failed: %s', $e->getMessage() ) );
            }

            return null;
        }

        if ( ! is_string( $html ) ) {
            return null;
        }

        $html = trim( $html );

        // Empty output or the hide sentinel both mean "the engine rendered
        // nothing" — fall back rather than leaving a hole in the page.
        if ( '' === $html || self::HIDE_WIDGET === $html ) {
            return null;
        }

        /*
         * A query that legitimately matched nothing - 1.51.0
         *
         * The engine does not return an empty string when its query finds no
         * products. It renders its own empty-state partial instead, so the row
         * arrived here as a complete grid wrapper containing "No products
         * found." That is not empty, so neither the '' test nor the
         * HIDE_WIDGET test above caught it, and the
         * "if ( '' === $grid_html ) return ''" guard in Template::render()
         * never fired. The result was a Featured Products heading sitting
         * above an engine message on the live homepage.
         *
         * HIDE_WIDGET is not the same condition: that sentinel means a SOURCE
         * decided the widget should not appear at all, not that a source ran
         * and matched zero products.
         *
         * Returning null reports "the engine rendered nothing" to the calling
         * component, which drops the whole section - heading, Explore More
         * link and all - exactly as if the section were switched off. Matched
         * on the engine's wrapper class, not the message text, because that
         * copy is translatable and overridable via its empty_message setting.
         */
        if ( false !== strpos( $html, 'zymarg-wcpg__empty' ) ) {
            return null;
        }

        return self::wrap_output( $html, $is_carousel );
    }

    /**
     * Turn normalised rows into WC_Product objects.
     *
     * Passing real products makes the engine skip its own Query Engine, so the
     * homepage keeps full control of what appears and in which order — the
     * engine only decides how each card looks.
     *
     * @since 1.14.0
     * @param array $products Normalised rows.
     * @return array List of WC_Product objects.
     */
    private static function resolve_products( array $products ): array {
        if ( ! function_exists( 'wc_get_product' ) ) {
            return [];
        }

        $resolved = [];

        foreach ( $products as $row ) {
            $id = 0;

            if ( is_array( $row ) && isset( $row['id'] ) ) {
                $id = absint( $row['id'] );
            }

            if ( $id < 1 ) {
                continue;
            }

            $product = wc_get_product( $id );

            // Skip anything unresolvable, so a single deleted product cannot
            // take down an entire row.
            if ( $product instanceof \WC_Product ) {
                $resolved[] = $product;
            }
        }

        return $resolved;
    }

    /**
     * Translate homepage card options into the engine's config shape.
     *
     * @since 1.14.0
     * @param array $card_options Homepage card options.
     * @param int   $count        Number of products being rendered.
     * @return array Engine config array.
     */
    private static function build_config( array $card_options, int $count, string $source = '' ): array {
        $show_badge  = ! isset( $card_options['show_badge'] ) || ! empty( $card_options['show_badge'] );
        $show_rating = ! isset( $card_options['show_rating'] ) || ! empty( $card_options['show_rating'] );
        $show_cta    = ! isset( $card_options['show_cta'] ) || ! empty( $card_options['show_cta'] );

        $show_vendor = ! empty( $card_options['show_vendor'] );

        $query = [ 'limit' => max( 1, $count ) ];

        // With a source the engine runs the query itself; without one the
        // homepage has already chosen the products and 'limit' only guards
        // the engine's normaliser.
        if ( '' !== $source ) {
            $query['source'] = $source;
        }

        /*
         * Ordering for the generic 'all' source (1.46.2).
         *
         * Source_All already defaults to date DESC, so New Arrivals would work
         * without this. It is stated explicitly anyway: the row's whole meaning
         * rests on that ordering, and leaving it implicit would make a future
         * change to the engine's default silently repurpose the section. The
         * values stay overridable so a later section can reuse 'all' with a
         * different order.
         */
        if ( 'all' === $source ) {
            $orderby = isset( $card_options['orderby'] )
                ? sanitize_key( (string) $card_options['orderby'] )
                : 'date';

            $order = isset( $card_options['order'] ) && 'ASC' === strtoupper( (string) $card_options['order'] )
                ? 'ASC'
                : 'DESC';

            $query['orderby'] = '' !== $orderby ? $orderby : 'date';
            $query['order']   = $order;
        }

        /*
         * Dynamic source tuning (1.46.0).
         *
         * Source_Dynamic reads its weights and pool TTL straight off the
         * settings array it is handed, and Query_Adapter passes any query key
         * it has no mapping for through unchanged. So these keys only have to
         * be placed in 'query' to arrive intact -- no engine change needed.
         *
         * Weights are forwarded only when the admin actually set them. Sending
         * zeros for untouched fields would be read as real weights and would
         * flatten the scoring, whereas absent keys let the engine apply its own
         * 60/30/10 split.
         */
        if ( 'dynamic' === $source ) {
            foreach ( [ 'dynamic_w_recency', 'dynamic_w_rating', 'dynamic_w_sales' ] as $weight_key ) {
                if ( isset( $card_options[ $weight_key ] ) && '' !== $card_options[ $weight_key ] ) {
                    $query[ $weight_key ] = max( 0, (int) $card_options[ $weight_key ] );
                }
            }

            $refresh = isset( $card_options['dynamic_refresh'] )
                ? sanitize_key( (string) $card_options['dynamic_refresh'] )
                : '';

            if ( in_array( $refresh, [ 'page', 'hour', 'day' ], true ) ) {
                $query['dynamic_refresh'] = $refresh;
            }
        }

        $columns = self::column_counts();

        $config = [
            'query'      => $query,
            'layout'     => [
                'type'    => 'grid',
                'columns' => $columns['desktop'],
            ],
            // Read by the engine at 1024px and 767px. See column_counts().
            'responsive' => [
                'tablet' => [
                    'layout' => [ 'columns' => $columns['tablet'] ],
                ],
                'mobile' => [
                    'layout' => [ 'columns' => $columns['mobile'] ],
                ],
            ],
            'card'       => [
                'show_image'          => true,
                'show_title'          => true,
                'show_price'          => true,
                'show_rating'         => $show_rating,
                'show_atc'            => $show_cta,
                'show_discount_badge' => $show_badge,
                'show_vendor'         => $show_vendor,
            ],
            // The homepage draws its own section headings and handles its own
            // pagination, so both stay off here.
            'heading'    => [
                'show' => false,
            ],
            'pagination' => [
                'mode' => 'none',
            ],
        ];

        $template = self::card_template();

        if ( '' !== $template ) {
            $config['card']['template'] = $template;
        }

        /**
         * Filter the config sent to the Product Grid engine.
         *
         * Use this to pick a card template, change columns, or toggle card
         * elements without editing this plugin.
         *
         * @since 1.14.0
         * @param array $config       Engine config.
         * @param array $card_options Original homepage card options.
         * @param int   $count        Number of products.
         */
        return (array) apply_filters( 'zhp_product_grid_engine_config', $config, $card_options, $count );
    }

    /**
     * Wrap engine output in a host element owned by this plugin.
     *
     * Engine markup is always wrapped, for two separate reasons.
     *
     * 1. Carousels. The homepage carousel needs the element that directly
     *    contains the cards to be the scroll track. The engine emits its own
     *    grid wrapper, so that element is not ours to mark up. carousel.js
     *    promotes the host's first child to a track at run time, which keeps
     *    every existing carousel style and behaviour.
     *
     * 2. AJAX. Load More and the filters have to locate the grid in the DOM.
     *    They used to look for `.zhp-product-grid`, which does not exist when
     *    the engine renders, so Load More was never injected and filtering
     *    silently did nothing. `data-zhp-grid` gives both scripts one stable
     *    hook whoever draws the cards, and it stays on this plugin's own
     *    element rather than depending on the engine's class names.
     *
     * @since 1.14.0
     * @param string $html        Engine markup.
     * @param bool   $is_carousel Whether this grid is a carousel track.
     * @return string
     */
    private static function wrap_output( string $html, bool $is_carousel ): string {
        $classes = [ 'zhp-grid-host' ];
        $attrs   = ' data-zhp-grid data-zhp-grid-engine';

        if ( $is_carousel ) {
            $classes[] = 'zhp-carousel-host';
            $attrs    .= ' data-zhp-carousel-host';
        }

        return sprintf(
            '<div class="%1$s"%2$s>%3$s</div>',
            esc_attr( implode( ' ', $classes ) ),
            $attrs,
            $html
        );
    }
}
