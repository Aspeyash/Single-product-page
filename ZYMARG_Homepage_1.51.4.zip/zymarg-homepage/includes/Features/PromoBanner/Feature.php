<?php
/**
 * ZYMARG Homepage – Promo Banner Feature
 *
 * @package ZYMARGHomepage\Features\PromoBanner
 * @since   1.5.0
 * @version 1.5.0
 */

namespace ZYMARGHomepage\Features\PromoBanner;

use ZYMARGHomepage\Interfaces\FeatureInterface;
use ZYMARGHomepage\Queries\BannerQuery;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Feature implements FeatureInterface {
    public function get_slug(): string          { return 'promo-banner'; }
    public function get_label(): string         { return __( 'Promo Banner', 'zymarg-homepage' ); }
    public function get_default_order(): int    { return 11; }
    public function is_enabled_by_default(): bool { return true; }

    public function render( array $settings ): string {
        $query = new BannerQuery();
        $data  = $query->get( [ 'type' => 'promo', 'limit' => 1 ] );
        return ( new Template() )->render( $data, $settings );
    }
    /**
     * Render admin settings fields for this section.
     *
     * @since 1.5.0
     * @param array $settings Current saved settings.
     * @return void
     */
    public function render_settings_fields( array $settings ): void {
        ( new Settings() )->render_settings_fields( $settings );
    }

}
