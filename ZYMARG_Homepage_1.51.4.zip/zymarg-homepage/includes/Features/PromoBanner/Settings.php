<?php
/**
 * ZYMARG Homepage – Promo Banner Settings
 *
 * @package ZYMARGHomepage\Features\PromoBanner
 * @since   1.5.0
 * @version 1.34.0
 */

namespace ZYMARGHomepage\Features\PromoBanner;

use ZYMARGHomepage\Core\CustomSection;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Settings {
    public function render_settings_fields( array $settings ): void {
        ?>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'Banner Title', 'zymarg-homepage' ); ?></label>
            <input type="text" name="settings[title]" value="<?php echo esc_attr( $settings['title'] ?? '' ); ?>">
        </div>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'Image URL', 'zymarg-homepage' ); ?></label>
            <input type="url" name="settings[image_url]" value="<?php echo esc_attr( $settings['image_url'] ?? '' ); ?>">
        </div>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'Link URL', 'zymarg-homepage' ); ?></label>
            <input type="url" name="settings[link_url]" value="<?php echo esc_attr( $settings['link_url'] ?? '' ); ?>">
        </div>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'Link Label', 'zymarg-homepage' ); ?></label>
            <input type="text" name="settings[link_label]" value="<?php echo esc_attr( $settings['link_label'] ?? '' ); ?>">
        </div>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'Image Alt Text', 'zymarg-homepage' ); ?></label>
            <input type="text" name="settings[alt_text]" value="<?php echo esc_attr( $settings['alt_text'] ?? '' ); ?>">
        </div>
        <?php
        \ZYMARGHomepage\Core\Slides::render_repeater( $settings, 'promo-banner' );
        CustomSection::render_admin_fields( $settings, 'promo-banner' );
    }
}
