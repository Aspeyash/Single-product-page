<?php
/**
 * ZYMARG Homepage – Promo Banner Template
 *
 * @package ZYMARGHomepage\Features\PromoBanner
 * @since   1.5.0
 * @version 1.34.0
 */

namespace ZYMARGHomepage\Features\PromoBanner;

use ZYMARGHomepage\Interfaces\Renderable;
use ZYMARGHomepage\Core\CustomSection;
use ZYMARGHomepage\Core\Helpers;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Template implements Renderable {
    public function render( array $data, array $settings ): string {
        /*
         * Multibanner. Each banner is rendered through the single-banner path
         * below and the results are wrapped in the shared carousel, so the
         * existing markup stays the single source of truth for what a banner
         * looks like. Clearing 'items' on the copy stops this branch from
         * re-entering itself. With fewer than two banners nothing happens here
         * at all and the section renders exactly as it always has.
         */
        $zhp_slides = \ZYMARGHomepage\Core\Slides::get( $settings, 'promo-banner' );

        if ( count( $zhp_slides ) > 1 ) {
            $zhp_html = '';

            foreach ( $zhp_slides as $zhp_slide ) {
                $zhp_one          = array_merge( $settings, $zhp_slide );
                $zhp_one['items'] = [];
                $zhp_html        .= $this->render( $data, $zhp_one );
            }

            return \ZYMARGHomepage\Core\Slides::wrap( $zhp_html, $settings, 'promo-banner', count( $zhp_slides ) );
        }

        $banner     = $data[0] ?? [];
        $image_url  = ! empty( $settings['image_url']  ) ? $settings['image_url']  : ( $banner['image_url']  ?? '' );
        $link_url   = ! empty( $settings['link_url']   ) ? $settings['link_url']   : ( $banner['link_url']   ?? '' );
        $alt_text   = ! empty( $settings['alt_text']   ) ? $settings['alt_text']   : ( $banner['image_alt']  ?? '' );
        $title      = ! empty( $settings['title']      ) ? $settings['title']      : ( $banner['title']      ?? '' );
        $link_label = ! empty( $settings['link_label'] ) ? $settings['link_label'] : ( $banner['link_label'] ?? __( 'Shop Now', 'zymarg-homepage' ) );

        /*
         * Checked before the "needs an image or a title" guard below, because a
         * custom design may legitimately need neither — it might carry its own
         * artwork and copy and use no placeholders at all.
         */
        if ( CustomSection::is_active( $settings ) ) {
            return CustomSection::render(
                'promo-banner',
                $settings,
                [
                    'title'      => $title,
                    'image_url'  => $image_url,
                    'alt_text'   => $alt_text,
                    'link_url'   => $link_url,
                    'link_label' => $link_label,
                ]
            );
        }

        /*
         * Header-only override, resolved before the guard below. Custom header
         * markup counts as content: an admin who supplies only header HTML,
         * with no image and no title, should still get a banner rather than a
         * silently missing section.
         */
        $custom_header = trim( (string) ( $settings['header_html'] ?? '' ) );

        if ( empty( $image_url ) && empty( $title ) && '' === $custom_header ) { return ''; }

        $heading_id  = $title ? wp_unique_id( 'zhp-heading-' ) : '';
        $section_a11y = $heading_id
            ? 'aria-labelledby="' . esc_attr( $heading_id ) . '"'
            : ( $alt_text ? 'aria-label="' . esc_attr( $alt_text ) . '"' : '' );

        ob_start();
        ?>
        <section class="zhp-section zhp-promo-banner" <?php echo $section_a11y; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above ?>>
            <div class="zhp-container">
                <?php if ( $link_url ) : ?>
                <a href="<?php echo esc_url( $link_url ); ?>" class="zhp-promo-banner__link" aria-label="<?php echo esc_attr( $alt_text ?: $title ); ?>">
                <?php endif; ?>
                    <div class="zhp-promo-banner__inner">
                        <?php if ( $image_url ) : ?>
                        <img src="<?php echo esc_url( $image_url ); ?>"
                             alt="<?php echo esc_attr( $alt_text ); ?>"
                             class="zhp-promo-banner__img"
                             width="1200" height="300" loading="lazy">
                        <?php endif; ?>
                        <?php
                        /*
                         * The overlay is kept inline rather than routed through
                         * CustomSection::render_section_header(), because the
                         * banner title lives in .zhp-promo-banner__overlay and
                         * not the shared .zhp-section-header row. The shop
                         * button below is left in place either way.
                         */
                        ?>
                        <?php if ( $title || '' !== $custom_header ) : ?>
                        <div class="zhp-promo-banner__overlay">
                            <?php if ( \ZYMARGHomepage\Core\CustomSection::header_hidden( $settings ) ) :
                        // Header hidden by the section setting.
                    elseif ( '' !== $custom_header ) : ?>
                            <?php echo \ZYMARGHomepage\Core\CustomSection::prepare_header( $custom_header, 'promo-banner' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- admin-authored markup stored verbatim under CustomSection::RAW_KEYS. ?>
                            <?php else : ?>
                            <h2 class="zhp-promo-banner__title"<?php if ( $heading_id ) { echo ' id="' . esc_attr( $heading_id ) . '"'; } ?>><?php echo esc_html( $title ); ?></h2>
                            <?php endif; ?>
                            <?php if ( $link_url && $link_label ) : ?>
                            <span class="zhp-btn-primary"><?php echo esc_html( $link_label ); ?></span>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                <?php if ( $link_url ) : ?>
                </a>
                <?php endif; ?>
            </div>
        </section>
        <?php
        return ob_get_clean();
    }
}
