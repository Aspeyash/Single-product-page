<?php
/**
 * ZYMARG Homepage – Promo Banner Assets
 *
 * @package ZYMARGHomepage\Features\PromoBanner
 * @since   1.5.0
 * @version 1.13.0
 */

namespace ZYMARGHomepage\Features\PromoBanner;

use ZYMARGHomepage\Core\AssetPath;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Assets {

    public function enqueue(): void {
        if ( AssetPath::exists( 'assets/css/frontend/promo-banner', 'css' ) ) {
            wp_enqueue_style( 'zhp-promo-banner', AssetPath::url( 'assets/css/frontend/promo-banner', 'css' ),
                [ 'zhp-tokens' ], ZYMARG_HP_VERSION );
        }
    }
}
