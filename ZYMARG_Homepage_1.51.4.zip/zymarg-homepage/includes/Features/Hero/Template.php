<?php
/**
 * ZYMARG Homepage – Hero Template
 *
 * Renders the full-width hero banner using design tokens only.
 *
 * @package ZYMARGHomepage\Features\Hero
 * @since   1.5.0
 * @version 1.34.0
 */

namespace ZYMARGHomepage\Features\Hero;

use ZYMARGHomepage\Core\CustomSection;

use ZYMARGHomepage\Core\Helpers;
use ZYMARGHomepage\Interfaces\Renderable;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Template
 *
 * Returns the Hero section HTML. No echo, no query logic, no wp_enqueue_*.
 */
class Template implements Renderable {

    /**
     * @since 1.5.0
     * @param array $data     Pre-fetched banner data from Query.
     * @param array $settings Per-section admin settings.
     * @return string
     */
    public function render( array $data, array $settings ): string {
        /*
         * Multibanner. Each banner is rendered through the single-banner path
         * below and the results are wrapped in the shared carousel, so the
         * existing markup stays the single source of truth for what a banner
         * looks like. Clearing 'items' on the copy stops this branch from
         * re-entering itself. With fewer than two banners nothing happens here
         * at all and the section renders exactly as it always has.
         */
        $zhp_slides = \ZYMARGHomepage\Core\Slides::get( $settings, 'hero' );

        if ( count( $zhp_slides ) > 1 ) {
            $zhp_html = '';

            foreach ( $zhp_slides as $zhp_slide ) {
                $zhp_one          = array_merge( $settings, $zhp_slide );
                $zhp_one['items'] = [];
                $zhp_html        .= $this->render( $data, $zhp_one );
            }

            return \ZYMARGHomepage\Core\Slides::wrap( $zhp_html, $settings, 'hero', count( $zhp_slides ) );
        }

        // Prefer settings override, then queried data, then defaults.
        $banner = $data[0] ?? [];

        $heading    = ! empty( $settings['heading'] )
            ? $settings['heading']
            : ( $banner['title'] ?? __( 'Discover Everything You Need', 'zymarg-homepage' ) );
        $subheading = ! empty( $settings['subheading'] )
            ? $settings['subheading']
            : ( $banner['subtitle'] ?? __( 'Shop thousands of products from trusted sellers across Bangladesh.', 'zymarg-homepage' ) );
        $cta_label  = ! empty( $settings['cta_label'] )
            ? $settings['cta_label']
            : ( $banner['link_label'] ?? __( 'Shop Now', 'zymarg-homepage' ) );
        $cta_url    = ! empty( $settings['cta_url'] )
            ? $settings['cta_url']
            : ( $banner['link_url'] ?? get_permalink( wc_get_page_id( 'shop' ) ) );
        $bg_image   = ! empty( $settings['bg_image'] )
            ? $settings['bg_image']
            : ( $banner['image_url'] ?? '' );

        /*
         * The administrator can replace this section's markup entirely with
         * their own design. Checked here, after the content values are resolved
         * but before any of the built-in markup work, so the author's design
         * still receives the live heading, link and image, and so the
         * attachment-ID lookup below is not paid for markup that is never used.
         */
        if ( CustomSection::is_active( $settings ) ) {
            return CustomSection::render(
                'hero',
                $settings,
                [
                    'heading'    => $heading,
                    'subheading' => $subheading,
                    'cta_label'  => $cta_label,
                    'cta_url'    => $cta_url,
                    'bg_image'   => $bg_image,
                ]
            );
        }

        /*
         * The hero image is almost always the homepage's Largest Contentful
         * Paint element. It used to be emitted as an inline
         * `background-image`, which has three costs the browser cannot work
         * around: the preload scanner cannot discover it while the CSS is
         * still loading, it cannot carry `fetchpriority`, and it cannot have a
         * `srcset` — so phones downloaded the full desktop file.
         *
         * Rendering a real <img> fixes all three. `srcset` needs an attachment
         * ID, and the admin panel only stores a URL string, so resolve one when
         * the image is in this site's media library.
         */
        $bg_image_id = 0;
        if ( $bg_image ) {
            // Prefer the ID the query already looked up; only fall back to a
            // URL lookup when the image came from the settings panel.
            $bg_image_id = ( empty( $settings['bg_image'] ) && ! empty( $banner['image_id'] ) )
                ? (int) $banner['image_id']
                : self::resolve_attachment_id( $bg_image );
        }

        $heading_id = wp_unique_id( 'zhp-heading-' );

        ob_start();
        ?>
        <section class="zhp-hero<?php echo $bg_image ? ' zhp-hero--has-image' : ''; ?>"
                 aria-labelledby="<?php echo esc_attr( $heading_id ); ?>">
            <?php if ( $bg_image ) : ?>
            <?php echo self::render_bg_image( $bg_image, $bg_image_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside helper ?>
            <?php endif; ?>
            <div class="zhp-hero__overlay" aria-hidden="true"></div>
            <div class="zhp-container zhp-hero__inner">
                <div class="zhp-hero__content">
                    <?php
                    /*
                     * Header-only override. The hero keeps its own markup here
                     * rather than calling CustomSection::render_section_header()
                     * because the hero heading is an <h1> inside .zhp-hero__content,
                     * not the shared .zhp-section-header row — emitting the shared
                     * row would land outside the hero's CSS. The call-to-action
                     * below stays put either way, so replacing the heading never
                     * costs the admin their button.
                     */
                    $custom_header = trim( (string) ( $settings['header_html'] ?? '' ) );
                    if ( \ZYMARGHomepage\Core\CustomSection::header_hidden( $settings ) ) :
                        // Header hidden by the section setting.
                    elseif ( '' !== $custom_header ) :
                        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- admin-authored markup stored verbatim under CustomSection::RAW_KEYS.
                        echo \ZYMARGHomepage\Core\CustomSection::prepare_header( $custom_header, 'hero' );
                    else :
                    ?>
                    <h1 class="zhp-hero__heading" id="<?php echo esc_attr( $heading_id ); ?>"><?php echo esc_html( $heading ); ?></h1>
                    <p class="zhp-hero__sub"><?php echo esc_html( $subheading ); ?></p>
                    <?php endif; ?>
                    <?php if ( $cta_url && $cta_label ) : ?>
                    <a href="<?php echo esc_url( $cta_url ); ?>" class="zhp-btn-primary zhp-hero__cta">
                        <?php echo esc_html( $cta_label ); ?>
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </section>
        <?php
        return ob_get_clean();
    }

    /**
     * Build the hero background <img> tag.
     *
     * The image is decorative — the heading carries the meaning — so it takes
     * an empty alt and aria-hidden rather than a repeated description.
     *
     * `loading="eager"` is explicit because wp_get_attachment_image() applies
     * `loading="lazy"` by default, and lazy-loading the LCP element delays it.
     *
     * @since 1.17.0
     * @param string $url           Image URL (already trusted from settings/query).
     * @param int    $attachment_id Attachment ID, or 0 when unresolved.
     * @return string Image HTML.
     */
    private static function render_bg_image( string $url, int $attachment_id ): string {
        if ( $attachment_id > 0 ) {
            $html = wp_get_attachment_image(
                $attachment_id,
                'full',
                false,
                [
                    'class'         => 'zhp-hero__bg',
                    'alt'           => '',
                    'aria-hidden'   => 'true',
                    'loading'       => 'eager',
                    'decoding'      => 'async',
                    'fetchpriority' => 'high',
                ]
            );

            // Returns '' if the attachment vanished; fall through to the URL.
            if ( '' !== $html ) {
                return $html;
            }
        }

        // No attachment ID: an external or CDN-hosted URL. Still eager and high
        // priority, but WordPress cannot generate a srcset for it.
        return sprintf(
            '<img src="%s" class="zhp-hero__bg" alt="" aria-hidden="true" loading="eager" decoding="async" fetchpriority="high">',
            esc_url( $url )
        );
    }

    /**
     * Resolve a local media-library URL to its attachment ID.
     *
     * attachment_url_to_postid() runs a database query, and the hero renders on
     * every homepage view, so the result is cached — including the 0 result for
     * external URLs, so a miss is not re-queried on every page load.
     *
     * @since 1.17.0
     * @param string $url Image URL.
     * @return int Attachment ID, or 0 when the URL is not in this media library.
     */
    private static function resolve_attachment_id( string $url ): int {
        $key    = 'zhp_hero_img_' . md5( $url );
        $cached = get_transient( $key );

        if ( false !== $cached ) {
            return (int) $cached;
        }

        $id = (int) attachment_url_to_postid( $url );

        set_transient( $key, $id, DAY_IN_SECONDS );

        return $id;
    }
}
