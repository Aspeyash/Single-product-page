<?php
/**
 * ZYMARG Homepage – Hero Assets
 *
 * Enqueues the Hero section stylesheet only when this feature is enabled.
 * Called by Hooks.php conditionally on the frontend.
 *
 * @package ZYMARGHomepage\Features\Hero
 * @since   1.5.0
 * @version 1.13.0
 */

namespace ZYMARGHomepage\Features\Hero;

use ZYMARGHomepage\Core\AssetPath;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Assets
 *
 * Conditionally enqueues Hero-specific CSS/JS.
 */
class Assets {

    /**
     * Enqueue frontend assets for the Hero section.
     *
     * @since 1.5.0
     * @return void
     */
    public function enqueue(): void {
        if ( AssetPath::exists( 'assets/css/frontend/hero', 'css' ) ) {
            wp_enqueue_style(
                'zhp-hero',
                AssetPath::url( 'assets/css/frontend/hero', 'css' ),
                [ 'zhp-tokens' ],
                ZYMARG_HP_VERSION
            );
        }
    }
}
