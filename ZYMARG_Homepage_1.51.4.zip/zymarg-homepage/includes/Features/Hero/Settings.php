<?php
/**
 * ZYMARG Homepage – Hero Settings Fields
 *
 * Renders the per-section settings panel for the Hero section inside the
 * admin Homepage drag-and-drop page.
 *
 * @package ZYMARGHomepage\Features\Hero
 * @since   1.5.0
 * @version 1.34.0
 */

namespace ZYMARGHomepage\Features\Hero;

use ZYMARGHomepage\Core\CustomSection;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Settings
 *
 * Renders admin settings fields for the Hero section.
 */
class Settings {

    /**
     * Output the HTML for this section's admin settings panel.
     *
     * @since 1.5.0
     * @param array $settings Current saved settings.
     * @return void
     */
    public function render_settings_fields( array $settings ): void {
        $heading    = $settings['heading']    ?? '';
        $subheading = $settings['subheading'] ?? '';
        $cta_label  = $settings['cta_label']  ?? '';
        $cta_url    = $settings['cta_url']    ?? '';
        $bg_image   = $settings['bg_image']   ?? '';
        ?>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'Heading', 'zymarg-homepage' ); ?></label>
            <input type="text" name="settings[heading]" value="<?php echo esc_attr( $heading ); ?>"
                   placeholder="<?php esc_attr_e( 'Discover Everything You Need', 'zymarg-homepage' ); ?>">
        </div>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'Sub-heading', 'zymarg-homepage' ); ?></label>
            <input type="text" name="settings[subheading]" value="<?php echo esc_attr( $subheading ); ?>">
        </div>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'CTA Label', 'zymarg-homepage' ); ?></label>
            <input type="text" name="settings[cta_label]" value="<?php echo esc_attr( $cta_label ); ?>"
                   placeholder="<?php esc_attr_e( 'Shop Now', 'zymarg-homepage' ); ?>">
        </div>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'CTA URL', 'zymarg-homepage' ); ?></label>
            <input type="url" name="settings[cta_url]" value="<?php echo esc_attr( $cta_url ); ?>">
        </div>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'Background Image URL', 'zymarg-homepage' ); ?></label>
            <input type="url" name="settings[bg_image]" value="<?php echo esc_attr( $bg_image ); ?>">
        </div>
        <?php
        \ZYMARGHomepage\Core\Slides::render_repeater( $settings, 'hero' );
        CustomSection::render_admin_fields( $settings, 'hero' );
    }
}
