<?php
/**
 * ZYMARG Homepage – Hero Feature
 *
 * Registers the Hero section with FeatureRegistry.
 * Coordinates Query → Template rendering.
 *
 * @package ZYMARGHomepage\Features\Hero
 * @since   1.5.0
 * @version 1.5.0
 */

namespace ZYMARGHomepage\Features\Hero;

use ZYMARGHomepage\Interfaces\FeatureInterface;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Feature
 *
 * Hero section — the full-width banner at the top of the homepage.
 */
class Feature implements FeatureInterface {

    /** @since 1.5.0 */
    public function get_slug(): string {
        return 'hero';
    }

    /** @since 1.5.0 */
    public function get_label(): string {
        return __( 'Hero Banner', 'zymarg-homepage' );
    }

    /** @since 1.5.0 */
    public function get_default_order(): int {
        return 1;
    }

    /** @since 1.5.0 */
    public function is_enabled_by_default(): bool {
        return true;
    }

    /**
     * Render the Hero section.
     *
     * @since 1.5.0
     * @param array $settings Per-section admin settings.
     * @return string
     */
    public function render( array $settings ): string {
        $query    = new Query();
        $data     = $query->get( [ 'type' => 'hero', 'limit' => 1 ] );
        $template = new Template();

        return $template->render( $data, $settings );
    }
    /**
     * Render admin settings fields for this section.
     *
     * @since 1.5.0
     * @param array $settings Current saved settings.
     * @return void
     */
    public function render_settings_fields( array $settings ): void {
        ( new Settings() )->render_settings_fields( $settings );
    }

}
