<?php
/**
 * ZYMARG Homepage – Hero Query
 *
 * Delegates to the shared BannerQuery for hero-type banners.
 *
 * @package ZYMARGHomepage\Features\Hero
 * @since   1.5.0
 * @version 1.5.0
 */

namespace ZYMARGHomepage\Features\Hero;

use ZYMARGHomepage\Interfaces\QueryInterface;
use ZYMARGHomepage\Queries\BannerQuery;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Query
 *
 * Fetches hero banner data via the shared BannerQuery.
 */
class Query implements QueryInterface {

    /**
     * @since 1.5.0
     * @param array $args Accepts 'type' and 'limit'.
     * @return array
     */
    public function get( array $args = [] ): array {
        $args = array_merge( [ 'type' => 'hero', 'limit' => 1 ], $args );
        $shared = new BannerQuery();
        return $shared->get( $args );
    }
}
