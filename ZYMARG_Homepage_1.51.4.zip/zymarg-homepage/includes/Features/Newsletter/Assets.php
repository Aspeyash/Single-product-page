<?php
/**
 * ZYMARG Homepage – Newsletter Assets
 *
 * @package ZYMARGHomepage\Features\Newsletter
 * @since   1.5.0
 * @version 1.13.0
 */

namespace ZYMARGHomepage\Features\Newsletter;

use ZYMARGHomepage\Core\AssetPath;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Assets {

    public function enqueue(): void {
        if ( AssetPath::exists( 'assets/css/frontend/newsletter', 'css' ) ) {
            wp_enqueue_style( 'zhp-newsletter', AssetPath::url( 'assets/css/frontend/newsletter', 'css' ),
                [ 'zhp-tokens' ], ZYMARG_HP_VERSION );
        }
        if ( AssetPath::exists( 'assets/js/frontend/newsletter', 'js' ) ) {
            wp_enqueue_script( 'zhp-newsletter', AssetPath::url( 'assets/js/frontend/newsletter', 'js' ),
                [], ZYMARG_HP_VERSION, true );
        }
    }
}
