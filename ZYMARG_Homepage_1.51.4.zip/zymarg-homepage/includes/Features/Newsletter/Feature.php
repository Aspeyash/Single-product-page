<?php
/**
 * ZYMARG Homepage – Newsletter Feature
 *
 * @package ZYMARGHomepage\Features\Newsletter
 * @since   1.5.0
 * @version 1.5.0
 */

namespace ZYMARGHomepage\Features\Newsletter;

use ZYMARGHomepage\Interfaces\FeatureInterface;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Feature implements FeatureInterface {
    public function get_slug(): string          { return 'newsletter'; }
    public function get_label(): string         { return __( 'Newsletter Signup', 'zymarg-homepage' ); }
    public function get_default_order(): int    { return 14; }
    public function is_enabled_by_default(): bool { return true; }

    public function render( array $settings ): string {
        return ( new Template() )->render( [], $settings );
    }
    /**
     * Render admin settings fields for this section.
     *
     * @since 1.5.0
     * @param array $settings Current saved settings.
     * @return void
     */
    public function render_settings_fields( array $settings ): void {
        ( new Settings() )->render_settings_fields( $settings );
    }

}
