<?php
/**
 * ZYMARG Homepage – Newsletter Template
 *
 * Renders the email sign-up strip. Submission is handled by the site's
 * newsletter plugin (Mailchimp for WooCommerce, MC4WP, etc.) — this
 * template outputs a standard HTML form that those plugins can target.
 *
 * @package ZYMARGHomepage\Features\Newsletter
 * @since   1.5.0
 * @version 1.34.0
 */

namespace ZYMARGHomepage\Features\Newsletter;

use ZYMARGHomepage\Core\CustomSection;
use ZYMARGHomepage\Interfaces\Renderable;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Template implements Renderable {
    public function render( array $data, array $settings ): string {
        /*
         * Multibanner. Each banner is rendered through the single-banner path
         * below and the results are wrapped in the shared carousel, so the
         * existing markup stays the single source of truth for what a banner
         * looks like. Clearing 'items' on the copy stops this branch from
         * re-entering itself. With fewer than two banners nothing happens here
         * at all and the section renders exactly as it always has.
         */
        $zhp_slides = \ZYMARGHomepage\Core\Slides::get( $settings, 'newsletter' );

        if ( count( $zhp_slides ) > 1 ) {
            $zhp_html = '';

            foreach ( $zhp_slides as $zhp_slide ) {
                $zhp_one          = array_merge( $settings, $zhp_slide );
                $zhp_one['items'] = [];
                $zhp_html        .= $this->render( $data, $zhp_one );
            }

            return \ZYMARGHomepage\Core\Slides::wrap( $zhp_html, $settings, 'newsletter', count( $zhp_slides ) );
        }

        $heading         = ! empty( $settings['heading'] )
            ? $settings['heading']
            : __( 'Stay in the Loop', 'zymarg-homepage' );
        $subheading      = ! empty( $settings['subheading'] )
            ? $settings['subheading']
            : __( 'Get the latest deals, new arrivals, and exclusive offers delivered to your inbox.', 'zymarg-homepage' );
        $btn_label       = ! empty( $settings['btn_label'] )
            ? $settings['btn_label']
            : __( 'Subscribe', 'zymarg-homepage' );
        $success_message = ! empty( $settings['success_message'] )
            ? $settings['success_message']
            : __( 'Thank you for subscribing!', 'zymarg-homepage' );

        $nonce      = wp_create_nonce( 'zhp_newsletter' );
        $heading_id = wp_unique_id( 'zhp-heading-' );
        $input_id   = wp_unique_id( 'zhp-email-' );

        /*
         * Full custom design. Checked after the copy is resolved so the
         * author's markup receives the live heading and labels. Note that a
         * custom design owns the whole strip, including the form: the sign-up
         * script binds to [data-zhp-newsletter-email] and
         * [data-zhp-newsletter-submit], so a custom design must keep those two
         * attributes for subscriptions to work. The placeholder hint shown in
         * the admin panel says so.
         */
        if ( CustomSection::is_active( $settings ) ) {
            return CustomSection::render(
                'newsletter',
                $settings,
                [
                    'heading'         => $heading,
                    'subheading'      => $subheading,
                    'btn_label'       => $btn_label,
                    'success_message' => $success_message,
                ]
            );
        }

        ob_start();
        ?>
        <section class="zhp-section zhp-newsletter" aria-labelledby="<?php echo esc_attr( $heading_id ); ?>">
            <div class="zhp-container">
                <div class="zhp-newsletter__inner">
                    <div class="zhp-newsletter__copy">
                        <?php
                        /*
                         * Header-only override. Kept inline rather than routed
                         * through CustomSection::render_section_header() because
                         * this section's heading lives in .zhp-newsletter__copy,
                         * not the shared .zhp-section-header row. The form beside
                         * it is untouched, so an admin can restyle the wording
                         * without touching the sign-up markup.
                         */
                        $custom_header = trim( (string) ( $settings['header_html'] ?? '' ) );
                        if ( \ZYMARGHomepage\Core\CustomSection::header_hidden( $settings ) ) :
                        // Header hidden by the section setting.
                    elseif ( '' !== $custom_header ) :
                            // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- admin-authored markup stored verbatim under CustomSection::RAW_KEYS.
                            echo \ZYMARGHomepage\Core\CustomSection::prepare_header( $custom_header, 'newsletter' );
                        else :
                        ?>
                        <h2 class="zhp-newsletter__heading" id="<?php echo esc_attr( $heading_id ); ?>"><?php echo esc_html( $heading ); ?></h2>
                        <p class="zhp-newsletter__sub"><?php echo esc_html( $subheading ); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="zhp-newsletter__form-wrap"
                         data-zhp-success="<?php echo esc_attr( $success_message ); ?>">
                        <div class="zhp-newsletter__form" role="form" aria-label="<?php esc_attr_e( 'Newsletter signup', 'zymarg-homepage' ); ?>">
                            <label for="<?php echo esc_attr( $input_id ); ?>" class="screen-reader-text">
                                <?php esc_html_e( 'Email address', 'zymarg-homepage' ); ?>
                            </label>
                            <input type="email" id="<?php echo esc_attr( $input_id ); ?>" class="zhp-input zhp-newsletter__input"
                                   placeholder="<?php esc_attr_e( 'Your email address', 'zymarg-homepage' ); ?>"
                                   autocomplete="email"
                                   data-zhp-newsletter-email
                                   required>
                            <input type="hidden" name="zhp_nonce" value="<?php echo esc_attr( $nonce ); ?>">
                            <button type="button"
                                    class="zhp-btn-primary zhp-newsletter__btn"
                                    data-zhp-newsletter-submit
                                    aria-label="<?php echo esc_attr( $btn_label ); ?>">
                                <?php echo esc_html( $btn_label ); ?>
                            </button>
                        </div>
                        <div class="zhp-newsletter__success" hidden aria-live="polite"></div>
                    </div>
                </div>
            </div>
        </section>
        <?php
        return ob_get_clean();
    }
}
