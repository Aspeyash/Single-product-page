<?php
/**
 * ZYMARG Homepage – Categories Settings Fields
 *
 * @package ZYMARGHomepage\Features\Categories
 * @since   1.5.0
 * @version 1.39.0
 */

namespace ZYMARGHomepage\Features\Categories;

use ZYMARGHomepage\Core\CustomSection;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Settings {
    public function render_settings_fields( array $settings ): void {
        $heading = $settings['heading'] ?? '';
        $limit   = (int) ( $settings['limit'] ?? 8 );
        ?>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'Section Heading', 'zymarg-homepage' ); ?></label>
            <input type="text" name="settings[heading]" value="<?php echo esc_attr( $heading ); ?>"
                   placeholder="<?php esc_attr_e( 'Shop by Category', 'zymarg-homepage' ); ?>">
        </div>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'Number of Categories', 'zymarg-homepage' ); ?></label>
            <input type="number" name="settings[limit]" value="<?php echo esc_attr( $limit ); ?>" min="2" max="20">
            <p class="zhp-settings-row__desc">
                <?php esc_html_e( 'You choose how many, not which ones. The categories with the most products come first, so the busiest parts of your shop lead the row, and this number decides how far down that list to go. Categories holding no products are never shown at all. It is a ceiling rather than a target: if fewer categories qualify, only those appear, and nothing is padded out to reach the number. The limit is 20 because a longer row is more scrolling than most shoppers will do.', 'zymarg-homepage' ); ?>
            </p>
        </div>
        <div class="zhp-settings-row">
            <label>
                <input type="checkbox" name="settings[carousel]" value="1"<?php checked( ! empty( $settings['carousel'] ) ); ?>>
                <?php esc_html_e( 'Horizontal swipeable carousel', 'zymarg-homepage' ); ?>
            </label>
            <p class="zhp-settings-row__desc">
                <?php esc_html_e( 'On, the categories sit in one row that shoppers swipe or scroll sideways, with arrows at each end. Off, they wrap onto as many lines as needed, like a grid, and every category is visible without scrolling. The rotation settings below only do anything while this is on.', 'zymarg-homepage' ); ?>
            </p>
        </div>
        <?php \ZYMARGHomepage\Core\CustomSection::render_carousel_motion_fields( $settings ); ?>
        <?php
        // Emits the Custom Header HTML box followed by the full custom-design
        // fields. The header box used to be hand-written here; it now lives in
        // CustomSection so all sections share one implementation.
        CustomSection::render_admin_fields( $settings, 'categories' );
    }
}
