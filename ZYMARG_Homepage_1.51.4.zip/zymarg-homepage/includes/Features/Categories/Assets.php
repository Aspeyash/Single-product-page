<?php
/**
 * ZYMARG Homepage – Categories Assets
 *
 * @package ZYMARGHomepage\Features\Categories
 * @since   1.5.0
 * @version 1.13.0
 */

namespace ZYMARGHomepage\Features\Categories;

use ZYMARGHomepage\Core\AssetPath;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Assets {

    public function enqueue(): void {
        if ( AssetPath::exists( 'assets/css/frontend/categories', 'css' ) ) {
            wp_enqueue_style( 'zhp-categories', AssetPath::url( 'assets/css/frontend/categories', 'css' ),
                [ 'zhp-tokens' ], ZYMARG_HP_VERSION );
        }
    }
}
