<?php
/**
 * ZYMARG Homepage – Categories Template
 *
 * @package ZYMARGHomepage\Features\Categories
 * @since   1.5.0
 * @version 1.39.0
 */

namespace ZYMARGHomepage\Features\Categories;

use ZYMARGHomepage\Core\CustomSection;
use ZYMARGHomepage\Interfaces\Renderable;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Template implements Renderable {
    public function render( array $data, array $settings ): string {
        if ( empty( $data ) ) { return ''; }

        $heading = ! empty( $settings['heading'] )
            ? $settings['heading']
            : __( 'Shop by Category', 'zymarg-homepage' );

        /*
         * A custom design replaces the markup, not the data: the category rows
         * are handed over as a repeating placeholder block so the author's cards
         * still show live categories, images and product counts.
         */
        if ( CustomSection::is_active( $settings ) ) {
            return CustomSection::render(
                'categories',
                $settings,
                [ 'heading' => $heading ],
                [ 'categories' => $data ]
            );
        }

        $heading_id  = wp_unique_id( 'zhp-heading-' );
        $is_carousel = ! empty( $settings['carousel'] );
        ob_start();
        ?>
        <section class="zhp-section zhp-categories" aria-labelledby="<?php echo esc_attr( $heading_id ); ?>"<?php echo CustomSection::carousel_motion_attrs( $settings ); ?>>
            <div class="zhp-container">
                <?php
                // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the default heading is escaped inside the helper; custom header markup is admin-authored and stored verbatim under CustomSection::RAW_KEYS.
                echo CustomSection::render_section_header( $settings, $heading, $heading_id, '', 'categories' );
                ?>
                <div class="zhp-categories__grid<?php echo $is_carousel ? ' zhp-carousel-track' : ''; ?>"
                     role="list"<?php echo $is_carousel ? ' data-zhp-carousel' : ''; ?>>
                    <?php foreach ( $data as $cat ) : ?>
                    <a href="<?php echo esc_url( $cat['url'] ); ?>"
                       class="zhp-category-card"
                       role="listitem"
                       aria-label="<?php echo esc_attr( $cat['name'] ); ?>">
                        <div class="zhp-category-card__img-wrap">
                            <img src="<?php echo esc_url( $cat['image_url'] ); ?>"
                                 alt="<?php echo esc_attr( $cat['image_alt'] ?? $cat['name'] ); ?>"
                                 width="200" height="200" loading="lazy">
                        </div>
                        <div class="zhp-category-card__body">
                            <span class="zhp-category-card__name"><?php echo esc_html( $cat['name'] ); ?></span>
                            <span class="zhp-category-card__count">
                                <?php printf( esc_html( _n( '%s item', '%s items', $cat['count'], 'zymarg-homepage' ) ), number_format_i18n( $cat['count'] ) ); ?>
                            </span>
                        </div>
                    </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
        <?php
        return ob_get_clean();
    }
}
