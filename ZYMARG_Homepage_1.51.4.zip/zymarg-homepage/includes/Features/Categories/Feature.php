<?php
/**
 * ZYMARG Homepage – Categories Feature
 *
 * @package ZYMARGHomepage\Features\Categories
 * @since   1.5.0
 * @version 1.5.0
 */

namespace ZYMARGHomepage\Features\Categories;

use ZYMARGHomepage\Interfaces\FeatureInterface;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Feature implements FeatureInterface {
    public function get_slug(): string       { return 'categories'; }
    public function get_label(): string      { return __( 'Shop by Category', 'zymarg-homepage' ); }
    public function get_default_order(): int { return 2; }
    public function is_enabled_by_default(): bool { return true; }

    public function render( array $settings ): string {
        $limit  = (int) ( $settings['limit'] ?? 8 );
        $query  = new Query();
        $data   = $query->get( [ 'limit' => $limit, 'parent' => 0, 'hide_empty' => true ] );
        return ( new Template() )->render( $data, $settings );
    }
    /**
     * Render admin settings fields for this section.
     *
     * @since 1.5.0
     * @param array $settings Current saved settings.
     * @return void
     */
    public function render_settings_fields( array $settings ): void {
        ( new Settings() )->render_settings_fields( $settings );
    }

}
