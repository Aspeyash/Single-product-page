<?php
/**
 * ZYMARG Homepage – Categories Query
 *
 * @package ZYMARGHomepage\Features\Categories
 * @since   1.5.0
 * @version 1.5.0
 */

namespace ZYMARGHomepage\Features\Categories;

use ZYMARGHomepage\Interfaces\QueryInterface;
use ZYMARGHomepage\Queries\CategoryQuery as SharedCategoryQuery;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Query implements QueryInterface {
    public function get( array $args = [] ): array {
        return ( new SharedCategoryQuery() )->get( $args );
    }
}
