<?php
/**
 * ZYMARG Homepage – Brands Feature
 *
 * Logo strip of featured brands / partners.
 *
 * @package ZYMARGHomepage\Features\Brands
 * @since   1.5.0
 * @version 1.5.0
 */

namespace ZYMARGHomepage\Features\Brands;

use ZYMARGHomepage\Interfaces\FeatureInterface;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Feature implements FeatureInterface {
    public function get_slug(): string          { return 'brands'; }
    public function get_label(): string         { return __( 'Brands', 'zymarg-homepage' ); }
    public function get_default_order(): int    { return 13; }
    public function is_enabled_by_default(): bool { return false; }

    public function render( array $settings ): string {
        $query = new Query();
        $data  = $query->get( $settings );
        return ( new Template() )->render( $data, $settings );
    }
    /**
     * Render admin settings fields for this section.
     *
     * @since 1.5.0
     * @param array $settings Current saved settings.
     * @return void
     */
    public function render_settings_fields( array $settings ): void {
        ( new Settings() )->render_settings_fields( $settings );
    }

}
