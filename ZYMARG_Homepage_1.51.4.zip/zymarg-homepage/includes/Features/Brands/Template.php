<?php
/**
 * ZYMARG Homepage – Brands Template
 *
 * @package ZYMARGHomepage\Features\Brands
 * @since   1.5.0
 * @version 1.39.0
 */

namespace ZYMARGHomepage\Features\Brands;

use ZYMARGHomepage\Core\CustomSection;
use ZYMARGHomepage\Interfaces\Renderable;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Template implements Renderable {
    public function render( array $data, array $settings ): string {
        $heading = ! empty( $settings['heading'] )
            ? $settings['heading']
            : __( 'Top Brands', 'zymarg-homepage' );

        /*
         * A custom design replaces the markup, not the data: the brand rows are
         * handed over as a repeating placeholder block so the author's logo
         * strip still shows live brands.
         *
         * Checked before the empty-data guard below because a custom design may
         * be entirely static. An author who hand-wrote their brand strip should
         * not lose it because no brand taxonomy is registered yet. The built-in
         * markup still bails, since it has nothing to draw without brands.
         */
        if ( CustomSection::is_active( $settings ) ) {
            return CustomSection::render(
                'brands',
                $settings,
                [ 'heading' => $heading ],
                [ 'brands' => $data ]
            );
        }

        if ( empty( $data ) ) { return ''; }

        $heading_id  = wp_unique_id( 'zhp-heading-' );
        $is_carousel = ! empty( $settings['carousel'] );
        ob_start();
        ?>
        <section class="zhp-section zhp-brands" aria-labelledby="<?php echo esc_attr( $heading_id ); ?>"<?php echo CustomSection::carousel_motion_attrs( $settings ); ?>>
            <div class="zhp-container">
                <?php
                // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the default heading is escaped inside the helper; custom header markup is admin-authored and stored verbatim under CustomSection::RAW_KEYS.
                echo CustomSection::render_section_header( $settings, $heading, $heading_id, '', 'brands' );
                ?>
                <div class="zhp-brands__strip<?php echo $is_carousel ? ' zhp-carousel-track' : ''; ?>"
                     role="list"<?php echo $is_carousel ? ' data-zhp-carousel' : ''; ?>>
                    <?php foreach ( $data as $brand ) : ?>
                    <a href="<?php echo esc_url( is_string( $brand['url'] ) ? $brand['url'] : '' ); ?>"
                       class="zhp-brand-logo"
                       role="listitem"
                       aria-label="<?php echo esc_attr( $brand['name'] ); ?>">
                        <?php if ( ! empty( $brand['image_url'] ) ) : ?>
                        <img src="<?php echo esc_url( $brand['image_url'] ); ?>"
                             alt="<?php echo esc_attr( $brand['image_alt'] ); ?>"
                             width="120" height="60" loading="lazy">
                        <?php else : ?>
                        <span class="zhp-brand-logo__text"><?php echo esc_html( $brand['name'] ); ?></span>
                        <?php endif; ?>
                    </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
        <?php
        return ob_get_clean();
    }
}
