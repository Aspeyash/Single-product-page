<?php
/**
 * ZYMARG Homepage – Brands Settings
 *
 * @package ZYMARGHomepage\Features\Brands
 * @since   1.5.0
 * @version 1.39.0
 */

namespace ZYMARGHomepage\Features\Brands;

use ZYMARGHomepage\Core\CustomSection;
use ZYMARGHomepage\Features\Brands\Query;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Settings {
    public function render_settings_fields( array $settings ): void {
        ?>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'Section Heading', 'zymarg-homepage' ); ?></label>
            <input type="text" name="settings[heading]" value="<?php echo esc_attr( $settings['heading'] ?? '' ); ?>"
                   placeholder="<?php esc_attr_e( 'Top Brands', 'zymarg-homepage' ); ?>">
        </div>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'Brands to Show', 'zymarg-homepage' ); ?></label>
            <input type="number" name="settings[limit]" value="<?php echo esc_attr( (int) ( $settings['limit'] ?? 12 ) ); ?>" min="2" max="24">
        </div>
        <div class="zhp-settings-row">
            <label>
                <input type="checkbox" name="settings[carousel]" value="1"<?php checked( ! empty( $settings['carousel'] ) ); ?>>
                <?php esc_html_e( 'Horizontal swipeable carousel', 'zymarg-homepage' ); ?>
            </label>
        </div>
        <?php \ZYMARGHomepage\Core\CustomSection::render_carousel_motion_fields( $settings ); ?>
        <?php $rows = Query::items( $settings ); ?>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'Brands', 'zymarg-homepage' ); ?></label>
            <p class="zhp-repeater__hint">
                <?php esc_html_e( 'Add each brand logo here. Anything listed below replaces the automatic brand list, so you do not need a brand taxonomy on the store. Leave this empty to fall back to the pa_brand or zhp_brand taxonomy if one is registered.', 'zymarg-homepage' ); ?>
            </p>
            <div class="zhp-repeater" data-zhp-repeater="brands">
                <div class="zhp-repeater__rows">
                    <?php foreach ( $rows as $i => $row ) { self::render_row( (int) $i, $row ); } ?>
                </div>
                <script type="text/html" class="zhp-repeater__template">
                    <?php self::render_row( null, [] ); ?>
                </script>
                <button type="button" class="zhp-admin-btn zhp-admin-btn--ghost zhp-repeater__add">
                    <?php esc_html_e( '+ Add Brand', 'zymarg-homepage' ); ?>
                </button>
            </div>
        </div>
        <?php
        // Custom Header HTML box + full custom-design fields, shared with
        // every other section so the three panels cannot drift apart.
        CustomSection::render_admin_fields( $settings, 'brands' );
    }

    /**
     * One repeater row. $index null renders the clone template.
     *
     * @since 1.35.0
     * @param int|null $index Row index, or null for the JS clone template.
     * @param array    $row   Saved row values.
     * @return void
     */
    private static function render_row( ?int $index, array $row ): void {
        $i = null === $index ? '__INDEX__' : (string) $index;
        ?>
        <div class="zhp-repeater__row" data-index="<?php echo esc_attr( $i ); ?>">
            <div class="zhp-repeater__grid">
                <input type="text" name="settings[items][<?php echo esc_attr( $i ); ?>][name]"
                       value="<?php echo esc_attr( (string) ( $row['name'] ?? '' ) ); ?>"
                       placeholder="<?php esc_attr_e( 'Brand name', 'zymarg-homepage' ); ?>">
                <input type="url" name="settings[items][<?php echo esc_attr( $i ); ?>][image_url]"
                       value="<?php echo esc_attr( (string) ( $row['image_url'] ?? '' ) ); ?>"
                       placeholder="<?php esc_attr_e( 'Logo image URL', 'zymarg-homepage' ); ?>">
                <input type="text" name="settings[items][<?php echo esc_attr( $i ); ?>][image_alt]"
                       value="<?php echo esc_attr( (string) ( $row['image_alt'] ?? '' ) ); ?>"
                       placeholder="<?php esc_attr_e( 'Logo alt text', 'zymarg-homepage' ); ?>">
                <input type="url" name="settings[items][<?php echo esc_attr( $i ); ?>][link_url]"
                       value="<?php echo esc_attr( (string) ( $row['url'] ?? $row['link_url'] ?? '' ) ); ?>"
                       placeholder="<?php esc_attr_e( 'Link URL', 'zymarg-homepage' ); ?>">
            </div>
            <button type="button" class="zhp-repeater__remove"
                    aria-label="<?php esc_attr_e( 'Remove brand', 'zymarg-homepage' ); ?>">&times;</button>
        </div>
        <?php
    }
}
