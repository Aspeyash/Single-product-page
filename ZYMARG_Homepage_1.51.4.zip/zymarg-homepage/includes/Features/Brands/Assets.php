<?php
/**
 * ZYMARG Homepage – Brands Assets
 *
 * @package ZYMARGHomepage\Features\Brands
 * @since   1.5.0
 * @version 1.13.0
 */

namespace ZYMARGHomepage\Features\Brands;

use ZYMARGHomepage\Core\AssetPath;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Assets {

    public function enqueue(): void {
        if ( AssetPath::exists( 'assets/css/frontend/brands', 'css' ) ) {
            wp_enqueue_style( 'zhp-brands', AssetPath::url( 'assets/css/frontend/brands', 'css' ),
                [ 'zhp-tokens' ], ZYMARG_HP_VERSION );
        }
    }
}
