<?php
/**
 * ZYMARG Homepage – Brands Query
 *
 * Retrieves brands from the `pa_brand` product attribute taxonomy
 * (WooCommerce) or the `zhp_brand` custom taxonomy if present.
 * Falls back gracefully to an empty array with a debug log.
 *
 * @package ZYMARGHomepage\Features\Brands
 * @since   1.5.0
 * @version 1.35.0
 */

namespace ZYMARGHomepage\Features\Brands;

use ZYMARGHomepage\Core\Logger;
use ZYMARGHomepage\Interfaces\QueryInterface;
use ZYMARGHomepage\Queries\CacheManager;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Query implements QueryInterface {

    private const CACHE_GROUP = 'brands';

    /**
     * Brand rows typed by hand into the Brands settings panel.
     *
     * Rows with neither a name nor an image are dropped, so a half-filled
     * repeater row never renders as an empty logo slot.
     *
     * @since 1.35.0
     * @param array $args Section settings.
     * @return array List of brand arrays shaped like the taxonomy results.
     */
    public static function items( array $args ): array {
        $rows = $args['items'] ?? [];

        if ( ! is_array( $rows ) ) {
            return [];
        }

        $out = [];

        foreach ( $rows as $row ) {
            if ( ! is_array( $row ) ) {
                continue;
            }

            $name  = trim( (string) ( $row['name'] ?? '' ) );
            $image = trim( (string) ( $row['image_url'] ?? '' ) );

            if ( '' === $name && '' === $image ) {
                continue;
            }

            $out[] = [
                'name'      => $name,
                'url'       => trim( (string) ( $row['link_url'] ?? '' ) ),
                'image_url' => $image,
                'image_alt' => trim( (string) ( $row['image_alt'] ?? '' ) ) ?: $name,
                'count'     => 0,
            ];
        }

        return $out;
    }

    public function get( array $args = [] ): array {
        $limit = max( 1, (int) ( $args['limit'] ?? 12 ) );

        // Hand-entered brands win over the taxonomy. Most stores never
        // register pa_brand or zhp_brand at all, which left this section
        // permanently blank with no way to populate it from the admin. Rows
        // typed into the Brands panel are authoritative and are not cached,
        // since they are already a cheap array read from the section options.
        $manual = self::items( $args );

        if ( ! empty( $manual ) ) {
            return array_slice( $manual, 0, $limit );
        }

        $cached = CacheManager::get( self::CACHE_GROUP, [ 'limit' => $limit ] );
        if ( false !== $cached ) { return $cached; }

        // Try pa_brand first (YITH Brands / custom attribute), then zhp_brand CPT tax.
        $taxonomy = taxonomy_exists( 'pa_brand' ) ? 'pa_brand'
                  : ( taxonomy_exists( 'zhp_brand' ) ? 'zhp_brand' : '' );

        if ( ! $taxonomy ) {
            Logger::debug( 'Brands Query: no brand taxonomy found — returning empty.' );
            CacheManager::set( self::CACHE_GROUP, [ 'limit' => $limit ], [] );
            return [];
        }

        $terms = get_terms( [
            'taxonomy'   => $taxonomy,
            'number'     => $limit,
            'hide_empty' => true,
            'orderby'    => 'count',
            'order'      => 'DESC',
        ] );

        if ( is_wp_error( $terms ) || empty( $terms ) ) {
            CacheManager::set( self::CACHE_GROUP, [ 'limit' => $limit ], [] );
            return [];
        }

        $results = [];
        foreach ( $terms as $term ) {
            $thumb_id  = (int) get_term_meta( $term->term_id, 'thumbnail_id', true );
            $image_url = $thumb_id
                ? wp_get_attachment_image_url( $thumb_id, 'thumbnail' )
                : '';

            $results[] = [
                'id'        => $term->term_id,
                'name'      => esc_html( $term->name ),
                'url'       => get_term_link( $term ),
                'image_url' => $image_url ?: '',
                'image_alt' => esc_attr( $term->name ),
                'count'     => (int) $term->count,
            ];
        }

        CacheManager::set( self::CACHE_GROUP, [ 'limit' => $limit ], $results );
        return $results;
    }
}
