<?php
/**
 * ZYMARG Homepage – Featured Sellers Assets
 *
 * @package ZYMARGHomepage\Features\FeaturedSellers
 * @since   1.5.0
 * @version 1.13.0
 */

namespace ZYMARGHomepage\Features\FeaturedSellers;

use ZYMARGHomepage\Core\AssetPath;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Assets {

    public function enqueue(): void {
        if ( AssetPath::exists( 'assets/css/frontend/sellers', 'css' ) ) {
            wp_enqueue_style( 'zhp-sellers', AssetPath::url( 'assets/css/frontend/sellers', 'css' ),
                [ 'zhp-tokens' ], ZYMARG_HP_VERSION );
        }
    }
}
