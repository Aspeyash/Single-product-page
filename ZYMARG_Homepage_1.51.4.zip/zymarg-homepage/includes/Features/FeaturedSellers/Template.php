<?php
/**
 * ZYMARG Homepage – Featured Sellers Template
 *
 * @package ZYMARGHomepage\Features\FeaturedSellers
 * @since   1.5.0
 * @version 1.39.0
 */

namespace ZYMARGHomepage\Features\FeaturedSellers;

use ZYMARGHomepage\Core\CustomSection;
use ZYMARGHomepage\Interfaces\Renderable;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Template implements Renderable {
    public function render( array $data, array $settings ): string {
        $heading = ! empty( $settings['heading'] )
            ? $settings['heading']
            : __( 'Meet Our Top Sellers', 'zymarg-homepage' );

        /*
         * A custom design replaces the markup, not the data: the seller rows
         * are handed over as a repeating placeholder block so the author's
         * cards still show live sellers, ratings and product counts.
         *
         * Checked before the empty-data guard below because a custom design may
         * be entirely static. An author who wrote their own seller strip should
         * not have it vanish because Dokan returned no vendors. The built-in
         * markup still bails, since it has nothing to draw without sellers.
         */
        if ( CustomSection::is_active( $settings ) ) {
            return CustomSection::render(
                'featured-sellers',
                $settings,
                [ 'heading' => $heading ],
                [ 'sellers' => $data ]
            );
        }

        if ( empty( $data ) ) { return ''; }

        $heading_id  = wp_unique_id( 'zhp-heading-' );
        $is_carousel = ! empty( $settings['carousel'] );
        ob_start();
        ?>
        <section class="zhp-section zhp-sellers" aria-labelledby="<?php echo esc_attr( $heading_id ); ?>"<?php echo CustomSection::carousel_motion_attrs( $settings ); ?>>
            <div class="zhp-container">
                <?php
                // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the default heading is escaped inside the helper; custom header markup is admin-authored and stored verbatim under CustomSection::RAW_KEYS.
                echo CustomSection::render_section_header( $settings, $heading, $heading_id, '', 'featured-sellers' );
                ?>
                <div class="zhp-sellers__grid<?php echo $is_carousel ? ' zhp-carousel-track' : ''; ?>"
                     role="list"<?php echo $is_carousel ? ' data-zhp-carousel' : ''; ?>>
                    <?php foreach ( $data as $seller ) : ?>
                    <a href="<?php echo esc_url( $seller['url'] ); ?>"
                       class="zhp-card zhp-seller-card"
                       role="listitem"
                       aria-label="<?php echo esc_attr( $seller['name'] ); ?>">
                        <?php if ( ! empty( $seller['banner_url'] ) ) : ?>
                        <div class="zhp-seller-card__banner">
                            <img src="<?php echo esc_url( $seller['banner_url'] ); ?>"
                                 alt="" width="400" height="120" loading="lazy" aria-hidden="true">
                        </div>
                        <?php endif; ?>
                        <div class="zhp-seller-card__body">
                            <img src="<?php echo esc_url( $seller['avatar_url'] ); ?>"
                                 alt="<?php echo esc_attr( $seller['name'] ); ?>"
                                 class="zhp-seller-card__avatar"
                                 width="64" height="64" loading="lazy">
                            <span class="zhp-seller-card__name"><?php echo esc_html( $seller['name'] ); ?></span>
                            <?php if ( ! empty( $seller['location'] ) ) : ?>
                            <span class="zhp-seller-card__location"><?php echo esc_html( $seller['location'] ); ?></span>
                            <?php endif; ?>
                            <?php if ( (float) ( $seller['rating'] ?? 0 ) > 0 ) : ?>
                            <div class="zhp-seller-card__rating" aria-label="<?php echo esc_attr( sprintf( /* translators: %s: star rating, e.g. 4.5 */ __( '%s stars', 'zymarg-homepage' ), number_format_i18n( (float) $seller['rating'], 1 ) ) ); ?>">
                                <span class="zhp-stars" style="--zhp-rating: <?php echo esc_attr( $seller['rating'] ); ?>"></span>
                                <span>(<?php echo (int) $seller['rating_count']; ?>)</span>
                            </div>
                            <?php endif; ?>
                            <span class="zhp-seller-card__products">
                                <?php printf(
                                    esc_html( _n( '%s product', '%s products', $seller['product_count'], 'zymarg-homepage' ) ),
                                    number_format_i18n( $seller['product_count'] )
                                ); ?>
                            </span>
                        </div>
                    </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
        <?php
        return ob_get_clean();
    }
}
