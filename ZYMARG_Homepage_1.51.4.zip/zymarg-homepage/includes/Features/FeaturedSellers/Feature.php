<?php
/**
 * ZYMARG Homepage – Featured Sellers Feature
 *
 * @package ZYMARGHomepage\Features\FeaturedSellers
 * @since   1.5.0
 * @version 1.5.0
 */

namespace ZYMARGHomepage\Features\FeaturedSellers;

use ZYMARGHomepage\Interfaces\FeatureInterface;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Feature implements FeatureInterface {
    public function get_slug(): string          { return 'featured-sellers'; }
    public function get_label(): string         { return __( 'Featured Sellers', 'zymarg-homepage' ); }
    public function get_default_order(): int    { return 10; }
    public function is_enabled_by_default(): bool { return true; }

    public function render( array $settings ): string {
        $limit = (int) ( $settings['limit'] ?? 6 );
        $query = new Query();
        $data  = $query->get( [ 'limit' => $limit ] );
        return ( new Template() )->render( $data, $settings );
    }
    /**
     * Render admin settings fields for this section.
     *
     * @since 1.5.0
     * @param array $settings Current saved settings.
     * @return void
     */
    public function render_settings_fields( array $settings ): void {
        ( new Settings() )->render_settings_fields( $settings );
    }

}
