<?php
/**
 * ZYMARG Homepage – Featured Sellers Settings
 *
 * @package ZYMARGHomepage\Features\FeaturedSellers
 * @since   1.5.0
 * @version 1.39.0
 */

namespace ZYMARGHomepage\Features\FeaturedSellers;

use ZYMARGHomepage\Core\CustomSection;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Settings {
    public function render_settings_fields( array $settings ): void {
        $heading = $settings['heading'] ?? '';
        $limit   = (int) ( $settings['limit'] ?? 6 );
        ?>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'Section Heading', 'zymarg-homepage' ); ?></label>
            <input type="text" name="settings[heading]" value="<?php echo esc_attr( $heading ); ?>"
                   placeholder="<?php esc_attr_e( 'Meet Our Top Sellers', 'zymarg-homepage' ); ?>">
        </div>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'Sellers to Show', 'zymarg-homepage' ); ?></label>
            <input type="number" name="settings[limit]" value="<?php echo esc_attr( $limit ); ?>" min="2" max="12">
        </div>
        <div class="zhp-settings-row">
            <label>
                <input type="checkbox" name="settings[carousel]" value="1"<?php checked( ! empty( $settings['carousel'] ) ); ?>>
                <?php esc_html_e( 'Horizontal swipeable carousel', 'zymarg-homepage' ); ?>
            </label>
        </div>
        <?php \ZYMARGHomepage\Core\CustomSection::render_carousel_motion_fields( $settings ); ?>
        <?php
        // Custom Header HTML box + full custom-design fields, shared with
        // every other section so the three panels cannot drift apart.
        CustomSection::render_admin_fields( $settings, 'featured-sellers' );
    }
}
