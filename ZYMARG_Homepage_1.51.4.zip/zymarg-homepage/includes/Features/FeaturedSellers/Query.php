<?php
/**
 * ZYMARG Homepage – Featured Sellers Query
 *
 * @package ZYMARGHomepage\Features\FeaturedSellers
 * @since   1.5.0
 * @version 1.5.0
 */

namespace ZYMARGHomepage\Features\FeaturedSellers;

use ZYMARGHomepage\Interfaces\QueryInterface;
use ZYMARGHomepage\Queries\SellerQuery as SharedSellerQuery;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Query implements QueryInterface {
    public function get( array $args = [] ): array {
        return ( new SharedSellerQuery() )->get( $args );
    }
}
