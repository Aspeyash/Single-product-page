<?php
/**
 * ZYMARG Homepage – Product Sections Template
 *
 * Shared template for all product section sub-types.
 * Renders a section heading and a responsive product grid.
 *
 * Cards and the grid are drawn by the ZYMARG WC Product Grid engine, which
 * also runs the query. This class owns only the section shell: heading,
 * optional countdown, and the container.
 *
 * @package ZYMARGHomepage\Features\ProductSections
 * @since   1.5.0
 * @version 1.46.0
 */

namespace ZYMARGHomepage\Features\ProductSections;

use ZYMARGHomepage\Components\ProductGrid\ProductGrid;
use ZYMARGHomepage\Interfaces\Renderable;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Template implements Renderable {

    public function render( array $data, array $settings ): string {
        $type      = $settings['_type']  ?? '';
        $label     = $settings['_label'] ?? '';
        $heading   = ! empty( $settings['heading'] ) ? $settings['heading'] : $label;
        $countdown   = ! empty( $settings['countdown'] ) && $type === 'flash-deals';
        $is_carousel = ! empty( $settings['carousel'] );
        $slug_css  = sanitize_html_class( $type );

        $limit  = absint( $settings['_limit'] ?? 0 );
        $limit  = $limit > 0 ? $limit : 8;
        $source = \ZYMARGHomepage\Integration\ProductGridBridge::source_for_slug( $type );

        // A section with no engine source has nothing to render.
        if ( '' === $source ) {
            return '';
        }

        $grid_options = [
            'carousel'    => $is_carousel,
            'source'      => $source,
            'limit'       => $limit,
            'show_vendor' => ! empty( $settings['show_vendor'] ),
        ];

        /*
         * Dynamic scoring controls (1.46.0). Forwarded only for the section
         * that uses the engine's 'dynamic' source, so no other row carries
         * settings the engine would ignore. The bridge validates these before
         * they reach the engine; passing them through untouched here keeps the
         * translation in one place.
         */
        if ( 'dynamic' === $source ) {
            foreach ( [ 'dynamic_w_recency', 'dynamic_w_rating', 'dynamic_w_sales', 'dynamic_refresh' ] as $dyn_key ) {
                if ( isset( $settings[ $dyn_key ] ) && '' !== $settings[ $dyn_key ] ) {
                    $grid_options[ $dyn_key ] = $settings[ $dyn_key ];
                }
            }
        }

        $grid      = new ProductGrid();
        $grid_html = $grid->render( $data, $grid_options );

        if ( '' === $grid_html ) { return ''; }

        // Captured while the engine rendered, so the timer counts to a real
        // sale end instead of an arbitrary midnight.
        $deadline = \ZYMARGHomepage\Integration\ProductGridBridge::take_sale_end();

        $heading_id = wp_unique_id( 'zhp-heading-' );
        ob_start();
        ?>
        <section class="zhp-section zhp-products zhp-products--<?php echo esc_attr( $slug_css ); ?>"
                 aria-labelledby="<?php echo esc_attr( $heading_id ); ?>"
                 data-zhp-section="<?php echo esc_attr( $type ); ?>"
                 data-zhp-limit="<?php echo esc_attr( $limit ); ?>"<?php echo \ZYMARGHomepage\Core\CustomSection::carousel_motion_attrs( $settings ); ?>>
            <div class="zhp-container">
                <?php
                $custom_header = trim( $settings['header_html'] ?? '' );
                if ( \ZYMARGHomepage\Core\CustomSection::header_hidden( $settings ) ) :
                        // Header hidden by the section setting.
                    elseif ( '' !== $custom_header ) :
                    /*
                     * Admin-supplied header HTML. Stored verbatim (RAW_KEYS) and
                     * output as-is — same trust level as custom_html on the
                     * custom-section body. The section still carries aria-labelledby
                     * pointing at $heading_id; if the custom HTML includes an <h2>
                     * with that id the association works automatically. When it does
                     * not, the section falls back to its aria-label attribute (set
                     * below) so it still has an accessible name.
                     *
                     * phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                     */
                    /*
                     * The six product sections do not go through
                     * CustomSection::render_section_header(), so the Explore
                     * More fix made there in 1.36.0 never reached them - a
                     * custom heading on Trending Products still swallowed the
                     * link. The link is appended here for the same reason: the
                     * admin replaced the heading, not the link. "Hide the
                     * Explore More link" is still the way to remove it.
                     */
                    $zhp_head    = \ZYMARGHomepage\Core\CustomSection::prepare_header( $custom_header, $type );
                    $zhp_explore = \ZYMARGHomepage\Core\CustomSection::explore_more( $settings, $type );

                    if ( '' === $zhp_explore ) {
                        echo $zhp_head; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                    } else {
                        echo '<div class="zhp-section-header zhp-section-header--custom">'
                            . $zhp_head
                            . $zhp_explore
                            . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                    }
                else :
                ?>
                <div class="zhp-section-header">
                    <h2 class="zhp-section-title" id="<?php echo esc_attr( $heading_id ); ?>"><?php echo esc_html( $heading ); ?></h2>
                    <?php if ( $countdown ) : ?>
                    <div class="zhp-countdown" data-zhp-countdown<?php echo $deadline > 0 ? ' data-zhp-deadline="' . esc_attr( (string) $deadline ) . '"' : ''; ?> aria-label="<?php esc_attr_e( 'Sale ends in', 'zymarg-homepage' ); ?>">
                        <span class="zhp-countdown__label"><?php esc_html_e( 'Ends in', 'zymarg-homepage' ); ?></span>
                        <span class="zhp-countdown__timer" data-zhp-timer></span>
                    </div>
                    <?php endif; ?>
                    <?php echo \ZYMARGHomepage\Core\CustomSection::explore_more( $settings, $type ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                </div>
                <?php endif; ?>
                <?php echo $grid_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- markup comes from the Product Grid engine, which escapes its own values. ?>
            </div>
        </section>
        <?php
        return ob_get_clean();
    }
}
