<?php
/**
 * ZYMARG Homepage – Product Sections Feature
 *
 * Handles all 7 product section sub-types as independent draggable
 * and togglable rows in the admin. Each sub-type has its own slug,
 * label, and default order but shares this Feature class.
 *
 * Use Feature::for_type( $type ) to get the Feature instance for a
 * specific type slug.
 *
 * @package ZYMARGHomepage\Features\ProductSections
 * @since   1.5.0
 * @version 1.46.0
 */

namespace ZYMARGHomepage\Features\ProductSections;

use ZYMARGHomepage\Interfaces\FeatureInterface;

if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Class Feature
 *
 * Concrete implementation for a single product section sub-type.
 * Instantiated once per sub-type by HomepageController::boot_features().
 */
class Feature implements FeatureInterface {

    /**
     * Sub-type configuration map.
     * slug => [ label, default_order, enabled_by_default ]
     *
     * @since 1.5.0
     */
    private const TYPES = [
        'featured-products'  => [ 'Featured Products',  3, true  ],
        'trending-products'  => [ 'Trending Products',  4, true  ],
        'best-sellers'       => [ 'Best Sellers',        5, true  ],
        'flash-deals'        => [ 'Flash Deals',         6, true  ],
        'new-arrivals'       => [ 'New Arrivals',        7, true  ],
        'recommended'        => [ 'Recommended',         8, false ],
        'dynamic-picks'      => [ 'Just For You',         9, false ],
    ];

    /** @since 1.5.0 */
    private string $slug;
    private string $label;
    private int    $default_order;
    private bool   $enabled_default;

    /**
     * @since 1.5.0
     * @param string $slug One of the keys in self::TYPES.
     */
    public function __construct( string $slug ) {
        $config                = self::TYPES[ $slug ] ?? [ ucwords( $slug ), 10, false ];
        $this->slug            = $slug;
        $this->label           = __( $config[0], 'zymarg-homepage' );
        $this->default_order   = $config[1];
        $this->enabled_default = $config[2];
    }

    /**
     * Return Feature instances for all product section sub-types.
     *
     * @since 1.5.0
     * @return self[]
     */
    public static function all_instances(): array {
        return array_map( fn( string $slug ) => new self( $slug ), array_keys( self::TYPES ) );
    }

    public function get_slug(): string          { return $this->slug; }
    public function get_label(): string         { return $this->label; }
    public function get_default_order(): int    { return $this->default_order; }
    public function is_enabled_by_default(): bool { return $this->enabled_default; }

    /**
     * Render the product section.
     *
     * @since 1.5.0
     */
    public function render( array $settings ): string {
        $settings_obj = new Settings();
        $limit        = $settings_obj->get_limit( $settings );

        // As of 1.31.0 the homepage no longer queries products. The Product
        // Grid engine owns every source, so the template passes a source key
        // and the engine returns finished cards.
        return ( new \ZYMARGHomepage\Features\ProductSections\Template() )->render(
            [],
            array_merge(
                $settings,
                [
                    '_type'  => $this->slug,
                    '_label' => $this->label,
                    '_limit' => $limit,
                ]
            )
        );
    }
    /**
     * Render admin settings fields for this section.
     *
     * @since 1.5.0
     * @param array $settings Current saved settings.
     * @return void
     */
    public function render_settings_fields( array $settings ): void {
        ( new Settings() )->render_settings_fields( $settings, $this->slug );
    }

}
