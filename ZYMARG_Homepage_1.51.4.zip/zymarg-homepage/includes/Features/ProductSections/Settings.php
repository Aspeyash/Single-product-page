<?php
/**
 * ZYMARG Homepage – Product Sections Settings
 *
 * @package ZYMARGHomepage\Features\ProductSections
 * @since   1.5.0
 * @version 1.46.0
 */

namespace ZYMARGHomepage\Features\ProductSections;

use ZYMARGHomepage\Core\Helpers;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Settings {

    /**
     * Resolve the products-per-section limit, honouring per-section override
     * then falling back to the global setting.
     *
     * @since 1.5.0
     */
    public function get_limit( array $settings ): int {
        if ( ! empty( $settings['limit'] ) ) {
            return max( 1, (int) $settings['limit'] );
        }
        return (int) Helpers::get_setting( 'products_per_section', 8 );
    }

    /**
     * Render admin settings fields for any product section sub-type.
     *
     * @since 1.5.0
     */
    public function render_settings_fields( array $settings, string $slug = '' ): void {
        $heading   = $settings['heading']   ?? '';
        $limit     = (int) ( $settings['limit'] ?? 0 );
        $countdown = ! empty( $settings['countdown'] );

        // Product sections share one settings renderer, so this single call
        // gives all seven of them the Custom Header HTML box. Added 1.29.0.
        $zhp_slug = '' !== $slug ? $slug : 'product-section';

        \ZYMARGHomepage\Core\CustomSection::render_header_field( $settings, $zhp_slug );

        /*
         * Product sections are the only ones that do not call
         * render_admin_fields(), because the engine draws their cards and they
         * have no custom-body boxes. That also silently withheld the Explore
         * More controls, even though the link itself renders on these rows -
         * so six sections showed a link with no way to configure it.
         */
        \ZYMARGHomepage\Core\CustomSection::render_explore_field( $settings, $zhp_slug );
        ?>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'Section Heading', 'zymarg-homepage' ); ?></label>
            <input type="text" name="settings[heading]" value="<?php echo esc_attr( $heading ); ?>">
        </div>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'Products to Show (0 = global default)', 'zymarg-homepage' ); ?></label>
            <input type="number" name="settings[limit]" value="<?php echo esc_attr( $limit ); ?>" min="0" max="24">
        </div>
        <?php if ( 'dynamic-picks' === $slug ) : ?>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'Scoring Weights (leave blank for 60 / 30 / 10)', 'zymarg-homepage' ); ?></label>
            <p class="zhp-settings-row__desc">
                <?php esc_html_e( 'Every published product is scored on three signals and the highest scoring ones are shown. The numbers are relative, not percentages: 60/30/10 and 6/3/1 behave identically. Set one to 0 to ignore that signal entirely.', 'zymarg-homepage' ); ?>
            </p>
        </div>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'Newness weight', 'zymarg-homepage' ); ?></label>
            <input type="number" name="settings[dynamic_w_recency]" value="<?php echo esc_attr( $settings['dynamic_w_recency'] ?? '' ); ?>" min="0" max="100" placeholder="60">
        </div>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'Rating weight', 'zymarg-homepage' ); ?></label>
            <input type="number" name="settings[dynamic_w_rating]" value="<?php echo esc_attr( $settings['dynamic_w_rating'] ?? '' ); ?>" min="0" max="100" placeholder="30">
        </div>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'Sales weight', 'zymarg-homepage' ); ?></label>
            <input type="number" name="settings[dynamic_w_sales]" value="<?php echo esc_attr( $settings['dynamic_w_sales'] ?? '' ); ?>" min="0" max="100" placeholder="10">
        </div>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'Reshuffle how often', 'zymarg-homepage' ); ?></label>
            <?php $zhp_refresh = $settings['dynamic_refresh'] ?? 'hour'; ?>
            <select name="settings[dynamic_refresh]">
                <option value="page"<?php selected( $zhp_refresh, 'page' ); ?>><?php esc_html_e( 'Every minute (busiest)', 'zymarg-homepage' ); ?></option>
                <option value="hour"<?php selected( $zhp_refresh, 'hour' ); ?>><?php esc_html_e( 'Hourly (recommended)', 'zymarg-homepage' ); ?></option>
                <option value="day"<?php selected( $zhp_refresh, 'day' ); ?>><?php esc_html_e( 'Daily (lightest)', 'zymarg-homepage' ); ?></option>
            </select>
            <p class="zhp-settings-row__desc">
                <?php esc_html_e( 'How long the candidate pool is cached. The visible order still shifts slightly on every page load regardless of this setting, so the row never looks frozen. Shorter intervals mean more database work.', 'zymarg-homepage' ); ?>
            </p>
        </div>
        <?php endif; ?>
        <?php if ( 'flash-deals' === $slug ) : ?>
        <div class="zhp-settings-row">
            <label>
                <input type="checkbox" name="settings[countdown]" value="1"<?php checked( $countdown ); ?>>
                <?php esc_html_e( 'Show countdown timer', 'zymarg-homepage' ); ?>
            </label>
            <p class="zhp-settings-row__desc">
                <?php esc_html_e( 'Counts down to the end of each sale. Needs a sale end date set on the product.', 'zymarg-homepage' ); ?>
            </p>
        </div>
        <?php endif; ?>
        <div class="zhp-settings-row">
            <label>
                <input type="checkbox" name="settings[carousel]" value="1"<?php checked( ! empty( $settings['carousel'] ) ); ?>>
                <?php esc_html_e( 'Horizontal swipeable carousel', 'zymarg-homepage' ); ?>
            </label>
        </div>
        <?php \ZYMARGHomepage\Core\CustomSection::render_carousel_motion_fields( $settings ); ?>
        <div class="zhp-settings-row">
            <label>
                <input type="checkbox" name="settings[show_vendor]" value="1"<?php checked( ! empty( $settings['show_vendor'] ) ); ?>>
                <?php esc_html_e( 'Show seller name on each card', 'zymarg-homepage' ); ?>
            </label>
            <p class="zhp-settings-row__desc">
                <?php esc_html_e( 'Adds the Dokan store name and avatar under the price. Requires the ZYMARG Template Pack card and an active Dokan install.', 'zymarg-homepage' ); ?>
            </p>
        </div>
        <?php
    }
}
