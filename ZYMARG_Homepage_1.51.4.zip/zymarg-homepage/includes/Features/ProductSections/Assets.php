<?php
/**
 * ZYMARG Homepage – Product Sections Assets
 *
 * @package ZYMARGHomepage\Features\ProductSections
 * @since   1.5.0
 * @version 1.13.0
 */

namespace ZYMARGHomepage\Features\ProductSections;

use ZYMARGHomepage\Core\AssetPath;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Assets {

    public function enqueue(): void {
        if ( AssetPath::exists( 'assets/css/frontend/products', 'css' ) ) {
            wp_enqueue_style( 'zhp-products', AssetPath::url( 'assets/css/frontend/products', 'css' ),
                [ 'zhp-tokens' ], ZYMARG_HP_VERSION );
        }
        if ( AssetPath::exists( 'assets/js/frontend/countdown', 'js' ) ) {
            wp_enqueue_script( 'zhp-countdown', AssetPath::url( 'assets/js/frontend/countdown', 'js' ),
                [], ZYMARG_HP_VERSION, true );
        }
    }
}
