<?php
/**
 * ZYMARG Homepage – Collections Assets
 *
 * @package ZYMARGHomepage\Features\Collections
 * @since   1.5.0
 * @version 1.13.0
 */

namespace ZYMARGHomepage\Features\Collections;

use ZYMARGHomepage\Core\AssetPath;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Assets {

    public function enqueue(): void {
        if ( AssetPath::exists( 'assets/css/frontend/collections', 'css' ) ) {
            wp_enqueue_style( 'zhp-collections', AssetPath::url( 'assets/css/frontend/collections', 'css' ),
                [ 'zhp-tokens' ], ZYMARG_HP_VERSION );
        }
    }
}
