<?php
/**
 * ZYMARG Homepage - Collections Settings
 *
 * Collection cards are managed here, in the Collections panel on
 * Homepage > Sections, rather than in a separate admin menu.
 *
 * WHY THE CARDS LIVE HERE
 * -----------------------
 * This panel used to offer only a heading, a limit and a carousel toggle. The
 * cards themselves had no input anywhere in the settings UI, so the section
 * could never render: there was literally nowhere to type a collection. The
 * cards were expected to come from a `zhp_banner` custom post type behind its
 * own admin menu, which duplicated the Hero and Promo Banner panels that
 * already existed on this screen and split one job across two places.
 *
 * The repeater below closes that gap in place. Every other section is
 * configured on this screen, and Collections now is too.
 *
 * @package ZYMARGHomepage\Features\Collections
 * @since   1.5.0
 * @version 1.39.0
 */

namespace ZYMARGHomepage\Features\Collections;

use ZYMARGHomepage\Core\CustomSection;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Settings {

    /**
     * Render the Collections settings panel.
     *
     * @since 1.5.0
     * @param array $settings Current saved settings.
     * @return void
     */
    public function render_settings_fields( array $settings ): void {
        $items = self::items( $settings );
        ?>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'Section Heading', 'zymarg-homepage' ); ?></label>
            <input type="text" name="settings[heading]" value="<?php echo esc_attr( $settings['heading'] ?? '' ); ?>"
                   placeholder="<?php esc_attr_e( 'Curated Collections', 'zymarg-homepage' ); ?>">
        </div>
        <div class="zhp-settings-row">
            <label>
                <input type="checkbox" name="settings[carousel]" value="1"<?php checked( ! empty( $settings['carousel'] ) ); ?>>
                <?php esc_html_e( 'Horizontal swipeable carousel', 'zymarg-homepage' ); ?>
            </label>
        </div>
        <?php \ZYMARGHomepage\Core\CustomSection::render_carousel_motion_fields( $settings ); ?>

        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'Collection Cards', 'zymarg-homepage' ); ?></label>
            <p class="zhp-repeater__hint">
                <?php esc_html_e( 'Each card is one collection tile. A card needs at least a title or an image to appear; blank cards are ignored.', 'zymarg-homepage' ); ?>
            </p>

            <div class="zhp-repeater" data-zhp-repeater="collections">
                <div class="zhp-repeater__rows">
                    <?php foreach ( $items as $index => $item ) : ?>
                        <?php self::render_row( (int) $index, $item ); ?>
                    <?php endforeach; ?>
                </div>

                <?php
                /*
                 * Blank row markup for the Add button to clone. It is wrapped in
                 * a <script type="text/html"> block so the browser never treats
                 * it as live form fields - otherwise the __INDEX__ placeholder
                 * row would be collected and written as a blank card on every
                 * save. The save routine skips this container too, belt and
                 * braces.
                 */
                ?>
                <script type="text/html" class="zhp-repeater__template">
                    <?php self::render_row( null, [] ); ?>
                </script>

                <button type="button" class="zhp-admin-btn zhp-admin-btn--ghost zhp-repeater__add">
                    <?php esc_html_e( '+ Add Collection', 'zymarg-homepage' ); ?>
                </button>
            </div>
        </div>
        <?php
        // Custom Header HTML box + full custom-design fields, shared with
        // every other section so the panels cannot drift apart.
        CustomSection::render_admin_fields( $settings, 'collections' );
    }

    /**
     * Render one repeater row.
     *
     * @since 1.28.0
     * @param int|null $index Row index, or null to emit the clone template.
     * @param array    $item  Card values.
     * @return void
     */
    private static function render_row( ?int $index, array $item ): void {
        // The clone template uses a literal placeholder that the Add button
        // swaps for the next free index.
        $i = null === $index ? '__INDEX__' : (string) $index;
        ?>
        <div class="zhp-repeater__row" data-index="<?php echo esc_attr( $i ); ?>">
            <div class="zhp-repeater__grid">
                <label>
                    <span><?php esc_html_e( 'Title', 'zymarg-homepage' ); ?></span>
                    <input type="text"
                           name="settings[items][<?php echo esc_attr( $i ); ?>][title]"
                           value="<?php echo esc_attr( $item['title'] ?? '' ); ?>"
                           placeholder="<?php esc_attr_e( 'Summer Deals', 'zymarg-homepage' ); ?>">
                </label>
                <label>
                    <span><?php esc_html_e( 'Image URL', 'zymarg-homepage' ); ?></span>
                    <input type="url"
                           name="settings[items][<?php echo esc_attr( $i ); ?>][image_url]"
                           value="<?php echo esc_attr( $item['image_url'] ?? '' ); ?>">
                </label>
                <label>
                    <span><?php esc_html_e( 'Image Alt Text', 'zymarg-homepage' ); ?></span>
                    <input type="text"
                           name="settings[items][<?php echo esc_attr( $i ); ?>][image_alt]"
                           value="<?php echo esc_attr( $item['image_alt'] ?? '' ); ?>">
                </label>
                <label>
                    <span><?php esc_html_e( 'Link URL', 'zymarg-homepage' ); ?></span>
                    <input type="url"
                           name="settings[items][<?php echo esc_attr( $i ); ?>][link_url]"
                           value="<?php echo esc_attr( $item['link_url'] ?? '' ); ?>">
                </label>
                <label>
                    <span><?php esc_html_e( 'Link Label', 'zymarg-homepage' ); ?></span>
                    <input type="text"
                           name="settings[items][<?php echo esc_attr( $i ); ?>][link_label]"
                           value="<?php echo esc_attr( $item['link_label'] ?? '' ); ?>"
                           placeholder="<?php esc_attr_e( 'Shop now', 'zymarg-homepage' ); ?>">
                </label>
            </div>
            <button type="button" class="zhp-repeater__remove"
                    aria-label="<?php esc_attr_e( 'Remove this collection', 'zymarg-homepage' ); ?>"
                    title="<?php esc_attr_e( 'Remove', 'zymarg-homepage' ); ?>">&times;</button>
        </div>
        <?php
    }

    /**
     * Normalise saved cards into a clean, densely indexed list.
     *
     * Cards with neither a title nor an image are dropped: they would render as
     * an empty tile with a broken image on the front end. This mirrors the
     * guard the settings-based banner fallback already applied.
     *
     * Shared with Feature::render() so the admin panel and the front end can
     * never disagree about what counts as a usable card.
     *
     * @since 1.28.0
     * @param array $settings Section settings.
     * @return array<int, array<string, string>> Clean card list.
     */
    public static function items( array $settings ): array {
        $raw = $settings['items'] ?? [];

        if ( ! is_array( $raw ) ) {
            return [];
        }

        $clean = [];

        foreach ( $raw as $item ) {
            if ( ! is_array( $item ) ) {
                continue;
            }

            $title = trim( (string) ( $item['title'] ?? '' ) );
            $image = trim( (string) ( $item['image_url'] ?? '' ) );

            // Skip blank rows - an admin who adds a card and never fills it in
            // should not get an empty tile on the homepage.
            if ( '' === $title && '' === $image ) {
                continue;
            }

            $alt = trim( (string) ( $item['image_alt'] ?? '' ) );

            $clean[] = [
                'title'      => $title,
                'image_url'  => $image,
                'image_alt'  => '' !== $alt ? $alt : $title,
                'link_url'   => trim( (string) ( $item['link_url'] ?? '' ) ),
                'link_label' => trim( (string) ( $item['link_label'] ?? '' ) ),
            ];
        }

        return $clean;
    }
}
