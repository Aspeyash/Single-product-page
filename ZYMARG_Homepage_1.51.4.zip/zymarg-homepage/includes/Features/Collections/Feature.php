<?php
/**
 * ZYMARG Homepage – Collections Feature
 *
 * Curated visual collection banners — e.g. "Summer Deals", "Back to School".
 *
 * Cards are read straight from this section's own settings, entered in the
 * Collections panel on Homepage > Sections. They previously came from the
 * `zhp_banner` custom post type behind a separate admin menu, which duplicated
 * the Hero and Promo Banner panels and split one job across two screens.
 *
 * @package ZYMARGHomepage\Features\Collections
 * @since   1.5.0
 * @version 1.28.0
 */

namespace ZYMARGHomepage\Features\Collections;

use ZYMARGHomepage\Interfaces\FeatureInterface;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Feature implements FeatureInterface {
    public function get_slug(): string          { return 'collections'; }
    public function get_label(): string         { return __( 'Collections', 'zymarg-homepage' ); }
    public function get_default_order(): int    { return 12; }
    public function is_enabled_by_default(): bool { return false; }

    public function render( array $settings ): string {
        /*
         * Settings::items() drops blank rows and falls back to the title for a
         * missing alt text. It is shared with the admin panel so the editor and
         * the front end can never disagree about what counts as a usable card.
         */
        $data = Settings::items( $settings );

        return ( new Template() )->render( $data, $settings );
    }
    /**
     * Render admin settings fields for this section.
     *
     * @since 1.5.0
     * @param array $settings Current saved settings.
     * @return void
     */
    public function render_settings_fields( array $settings ): void {
        ( new Settings() )->render_settings_fields( $settings );
    }

}
