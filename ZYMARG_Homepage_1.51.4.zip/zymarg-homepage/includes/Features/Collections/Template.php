<?php
/**
 * ZYMARG Homepage – Collections Template
 *
 * @package ZYMARGHomepage\Features\Collections
 * @since   1.5.0
 * @version 1.39.0
 */

namespace ZYMARGHomepage\Features\Collections;

use ZYMARGHomepage\Core\CustomSection;
use ZYMARGHomepage\Interfaces\Renderable;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Template implements Renderable {
    public function render( array $data, array $settings ): string {
        $heading = ! empty( $settings['heading'] )
            ? $settings['heading']
            : __( 'Curated Collections', 'zymarg-homepage' );

        /*
         * A custom design replaces the markup, not the data: the collection
         * rows are handed over as a repeating placeholder block so the author's
         * cards still show live collections and images.
         *
         * Checked before the empty-data guard below because a custom design may
         * be entirely static. This matters most here: the banner query does not
         * currently return anything for this section, so without this ordering
         * a hand-written collections design could never appear at all.
         */
        if ( CustomSection::is_active( $settings ) ) {
            return CustomSection::render(
                'collections',
                $settings,
                [ 'heading' => $heading ],
                [ 'collections' => $data ]
            );
        }

        if ( empty( $data ) ) { return ''; }

        $heading_id  = wp_unique_id( 'zhp-heading-' );
        $is_carousel = ! empty( $settings['carousel'] );
        ob_start();
        ?>
        <section class="zhp-section zhp-collections" aria-labelledby="<?php echo esc_attr( $heading_id ); ?>"<?php echo CustomSection::carousel_motion_attrs( $settings ); ?>>
            <div class="zhp-container">
                <?php
                // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the default heading is escaped inside the helper; custom header markup is admin-authored and stored verbatim under CustomSection::RAW_KEYS.
                echo CustomSection::render_section_header( $settings, $heading, $heading_id, '', 'collections' );
                ?>
                <div class="zhp-collections__grid<?php echo $is_carousel ? ' zhp-carousel-track' : ''; ?>"
                     role="list"<?php echo $is_carousel ? ' data-zhp-carousel' : ''; ?>>
                    <?php foreach ( $data as $item ) : ?>
                    <a href="<?php echo esc_url( $item['link_url'] ); ?>"
                       class="zhp-collection-card"
                       role="listitem"
                       aria-label="<?php echo esc_attr( $item['title'] ); ?>">
                        <div class="zhp-collection-card__img-wrap">
                            <img src="<?php echo esc_url( $item['image_url'] ); ?>"
                                 alt="<?php echo esc_attr( $item['image_alt'] ?? $item['title'] ); ?>"
                                 width="600" height="400" loading="lazy">
                        </div>
                        <div class="zhp-collection-card__overlay">
                            <span class="zhp-collection-card__title"><?php echo esc_html( $item['title'] ); ?></span>
                            <?php if ( ! empty( $item['link_label'] ) ) : ?>
                            <span class="zhp-btn-secondary"><?php echo esc_html( $item['link_label'] ); ?></span>
                            <?php endif; ?>
                        </div>
                    </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
        <?php
        return ob_get_clean();
    }
}
