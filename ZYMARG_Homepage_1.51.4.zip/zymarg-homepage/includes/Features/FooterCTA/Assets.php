<?php
/**
 * ZYMARG Homepage – Footer CTA Assets
 *
 * @package ZYMARGHomepage\Features\FooterCTA
 * @since   1.5.0
 * @version 1.13.0
 */

namespace ZYMARGHomepage\Features\FooterCTA;

use ZYMARGHomepage\Core\AssetPath;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Assets {

    public function enqueue(): void {
        if ( AssetPath::exists( 'assets/css/frontend/footer-cta', 'css' ) ) {
            wp_enqueue_style( 'zhp-footer-cta', AssetPath::url( 'assets/css/frontend/footer-cta', 'css' ),
                [ 'zhp-tokens' ], ZYMARG_HP_VERSION );
        }
    }
}
