<?php
/**
 * ZYMARG Homepage – Footer CTA Settings
 *
 * @package ZYMARGHomepage\Features\FooterCTA
 * @since   1.5.0
 * @version 1.34.0
 */

namespace ZYMARGHomepage\Features\FooterCTA;

use ZYMARGHomepage\Core\CustomSection;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Settings {
    public function render_settings_fields( array $settings ): void {
        ?>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'Heading', 'zymarg-homepage' ); ?></label>
            <input type="text" name="settings[heading]" value="<?php echo esc_attr( $settings['heading'] ?? '' ); ?>"
                   placeholder="<?php esc_attr_e( 'Start Selling on ZYMARG Today', 'zymarg-homepage' ); ?>">
        </div>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'Sub-heading', 'zymarg-homepage' ); ?></label>
            <input type="text" name="settings[subheading]" value="<?php echo esc_attr( $settings['subheading'] ?? '' ); ?>">
        </div>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'Button Label', 'zymarg-homepage' ); ?></label>
            <input type="text" name="settings[btn_label]" value="<?php echo esc_attr( $settings['btn_label'] ?? '' ); ?>"
                   placeholder="<?php esc_attr_e( 'Become a Seller', 'zymarg-homepage' ); ?>">
        </div>
        <div class="zhp-settings-row">
            <label><?php esc_html_e( 'Button URL', 'zymarg-homepage' ); ?></label>
            <input type="url" name="settings[btn_url]" value="<?php echo esc_attr( $settings['btn_url'] ?? '' ); ?>">
        </div>
        <?php
        // Custom Header HTML box + full custom-design fields, shared with
        // every other section so the three panels cannot drift apart.
        \ZYMARGHomepage\Core\Slides::render_repeater( $settings, 'footer-cta' );
        CustomSection::render_admin_fields( $settings, 'footer-cta' );
    }
}
