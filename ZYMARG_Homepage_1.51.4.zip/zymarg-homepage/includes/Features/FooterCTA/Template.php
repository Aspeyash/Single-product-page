<?php
/**
 * ZYMARG Homepage – Footer CTA Template
 *
 * @package ZYMARGHomepage\Features\FooterCTA
 * @since   1.5.0
 * @version 1.34.0
 */

namespace ZYMARGHomepage\Features\FooterCTA;

use ZYMARGHomepage\Core\CustomSection;
use ZYMARGHomepage\Interfaces\Renderable;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Template implements Renderable {
    public function render( array $data, array $settings ): string {
        /*
         * Multibanner. Each banner is rendered through the single-banner path
         * below and the results are wrapped in the shared carousel, so the
         * existing markup stays the single source of truth for what a banner
         * looks like. Clearing 'items' on the copy stops this branch from
         * re-entering itself. With fewer than two banners nothing happens here
         * at all and the section renders exactly as it always has.
         */
        $zhp_slides = \ZYMARGHomepage\Core\Slides::get( $settings, 'footer-cta' );

        if ( count( $zhp_slides ) > 1 ) {
            $zhp_html = '';

            foreach ( $zhp_slides as $zhp_slide ) {
                $zhp_one          = array_merge( $settings, $zhp_slide );
                $zhp_one['items'] = [];
                $zhp_html        .= $this->render( $data, $zhp_one );
            }

            return \ZYMARGHomepage\Core\Slides::wrap( $zhp_html, $settings, 'footer-cta', count( $zhp_slides ) );
        }

        $heading     = ! empty( $settings['heading'] )
            ? $settings['heading']
            : __( 'Start Selling on ZYMARG Today', 'zymarg-homepage' );
        $subheading  = ! empty( $settings['subheading'] )
            ? $settings['subheading']
            : __( 'Join thousands of sellers. Reach millions of buyers across Bangladesh.', 'zymarg-homepage' );
        $btn_label   = ! empty( $settings['btn_label'] )
            ? $settings['btn_label']
            : __( 'Become a Seller', 'zymarg-homepage' );
        $btn_url     = ! empty( $settings['btn_url'] )
            ? $settings['btn_url']
            : home_url( '/vendor-registration' );

        $heading_id = wp_unique_id( 'zhp-heading-' );

        /*
         * Full custom design. Checked after the copy and link are resolved so
         * the author's markup receives the live heading, label and URL.
         */
        if ( CustomSection::is_active( $settings ) ) {
            return CustomSection::render(
                'footer-cta',
                $settings,
                [
                    'heading'    => $heading,
                    'subheading' => $subheading,
                    'btn_label'  => $btn_label,
                    'btn_url'    => $btn_url,
                ]
            );
        }

        ob_start();
        ?>
        <section class="zhp-section zhp-footer-cta" aria-labelledby="<?php echo esc_attr( $heading_id ); ?>">
            <div class="zhp-container">
                <div class="zhp-footer-cta__inner">
                    <div class="zhp-footer-cta__copy">
                        <?php
                        /*
                         * Header-only override. Kept inline rather than routed
                         * through CustomSection::render_section_header() because
                         * this heading lives in .zhp-footer-cta__copy, not the
                         * shared .zhp-section-header row. The seller button
                         * beside it is left untouched.
                         */
                        $custom_header = trim( (string) ( $settings['header_html'] ?? '' ) );
                        if ( \ZYMARGHomepage\Core\CustomSection::header_hidden( $settings ) ) :
                        // Header hidden by the section setting.
                    elseif ( '' !== $custom_header ) :
                            // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- admin-authored markup stored verbatim under CustomSection::RAW_KEYS.
                            echo \ZYMARGHomepage\Core\CustomSection::prepare_header( $custom_header, 'footer-cta' );
                        else :
                        ?>
                        <h2 class="zhp-footer-cta__heading" id="<?php echo esc_attr( $heading_id ); ?>"><?php echo esc_html( $heading ); ?></h2>
                        <p class="zhp-footer-cta__sub"><?php echo esc_html( $subheading ); ?></p>
                        <?php endif; ?>
                    </div>
                    <a href="<?php echo esc_url( $btn_url ); ?>"
                       class="zhp-btn-primary zhp-footer-cta__btn">
                        <?php echo esc_html( $btn_label ); ?>
                    </a>
                </div>
            </div>
        </section>
        <?php
        return ob_get_clean();
    }
}
