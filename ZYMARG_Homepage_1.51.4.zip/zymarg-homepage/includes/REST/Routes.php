<?php
/**
 * ZYMARG Homepage – REST API Routes
 *
 * Registers all WP REST API endpoints under the /zhp/v1/ namespace.
 * Registered via rest_api_init in Hooks::register().
 *
 * Available endpoints:
 *
 *   GET  /zhp/v1/products              — paginated product list with filters
 *   GET  /zhp/v1/products/search       — lightweight title/SKU search
 *   GET  /zhp/v1/categories            — product category list
 *   GET  /zhp/v1/sellers               — featured seller list
 *   POST /zhp/v1/newsletter/subscribe  — newsletter sign-up relay
 *
 * All GET endpoints:
 *   - Are public (no authentication required) and rate-limit-friendly via
 *     WordPress object cache.
 *   - Return JSON conforming to WP_REST_Response conventions.
 *   - Validate every parameter through the WP REST API schema system.
 *
 * The newsletter POST endpoint:
 *   - Requires a valid zhp_newsletter nonce in the request body.
 *   - Fires the 'zhp_newsletter_subscribe' action hook so site owners
 *     can connect any email service without modifying plugin code.
 *
 * @package ZYMARGHomepage\REST
 * @since   1.6.0
 * @version 1.31.0
 */

namespace ZYMARGHomepage\REST;

use ZYMARGHomepage\Core\Helpers;
use ZYMARGHomepage\Core\Logger;
use ZYMARGHomepage\Queries\CacheManager;
use ZYMARGHomepage\Queries\CategoryQuery;
use ZYMARGHomepage\Queries\SellerQuery;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Routes
 *
 * Registers all ZYMARG Homepage REST endpoints.
 * Instantiated once; call register() on the rest_api_init hook.
 */
class Routes {

    /**
     * REST namespace.
     *
     * @since 1.6.0
     * @var string
     */
    private const NAMESPACE = 'zhp/v1';

    // ──────────────────────────────────────────────────────────────
    //  Registration
    // ──────────────────────────────────────────────────────────────

    /**
     * Register all routes.
     *
     * Called via add_action( 'rest_api_init', … ) in Hooks::register().
     *
     * @since 1.6.0
     * @return void
     */
    public function register(): void {
        // ── GET /zhp/v1/categories ───────────────────────────────
        register_rest_route( self::NAMESPACE, '/categories', [
            'methods'             => \WP_REST_Server::READABLE,
            'callback'            => [ $this, 'get_categories' ],
            'permission_callback' => '__return_true',
            'args'                => [
                'limit' => [
                    'description'       => __( 'Number of categories.', 'zymarg-homepage' ),
                    'type'              => 'integer',
                    'default'           => 12,
                    'minimum'           => 1,
                    'maximum'           => 50,
                    'sanitize_callback' => 'absint',
                ],
                'parent' => [
                    'description'       => __( '0 = top-level only, -1 = all depths.', 'zymarg-homepage' ),
                    'type'              => 'integer',
                    'default'           => 0,
                    'sanitize_callback' => 'intval',
                ],
                'hide_empty' => [
                    'description'       => __( 'Hide empty categories.', 'zymarg-homepage' ),
                    'type'              => 'boolean',
                    'default'           => true,
                    'sanitize_callback' => 'rest_sanitize_boolean',
                ],
            ],
        ] );

        // ── GET /zhp/v1/sellers ──────────────────────────────────
        register_rest_route( self::NAMESPACE, '/sellers', [
            'methods'             => \WP_REST_Server::READABLE,
            'callback'            => [ $this, 'get_sellers' ],
            'permission_callback' => '__return_true',
            'args'                => [
                'limit' => [
                    'description'       => __( 'Number of sellers.', 'zymarg-homepage' ),
                    'type'              => 'integer',
                    'default'           => 6,
                    'minimum'           => 1,
                    'maximum'           => 24,
                    'sanitize_callback' => 'absint',
                ],
            ],
        ] );

        // ── POST /zhp/v1/newsletter/subscribe ───────────────────
        register_rest_route( self::NAMESPACE, '/newsletter/subscribe', [
            'methods'             => \WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'newsletter_subscribe' ],
            'permission_callback' => '__return_true',
            'args'                => [
                'email' => [
                    'description'       => __( 'Email address to subscribe.', 'zymarg-homepage' ),
                    'type'              => 'string',
                    'required'          => true,
                    'format'            => 'email',
                    'sanitize_callback' => 'sanitize_email',
                    'validate_callback' => function( $value ) {
                        return is_email( $value )
                            ? true
                            : new \WP_Error( 'invalid_email', __( 'A valid email address is required.', 'zymarg-homepage' ) );
                    },
                ],
                'zhp_nonce' => [
                    'description' => __( 'Security nonce.', 'zymarg-homepage' ),
                    'type'        => 'string',
                    'required'    => true,
                ],
            ],
        ] );

        Logger::debug( 'REST Routes: all endpoints registered.' );
    }

    // ──────────────────────────────────────────────────────────────
    //  Callbacks
    // ──────────────────────────────────────────────────────────────

    /**
     * GET /zhp/v1/categories
     *
     * Returns product categories.
     *
     * @since 1.6.0
     * @param \WP_REST_Request $request Incoming REST request.
     * @return \WP_REST_Response|\WP_Error
     */
    public function get_categories( \WP_REST_Request $request ) {
        if ( ! Helpers::is_plugin_enabled() ) {
            return new \WP_Error( 'zhp_disabled', __( 'Plugin disabled.', 'zymarg-homepage' ), [ 'status' => 403 ] );
        }

        $args = [
            'limit'      => (int) ( $request->get_param( 'limit' )      ?? 12 ),
            'parent'     => (int) ( $request->get_param( 'parent' )     ?? 0  ),
            'hide_empty' => (bool) ( $request->get_param( 'hide_empty' ) ?? true ),
        ];

        $cache_args = $args;
        $cached     = CacheManager::get( 'rest_categories', $cache_args );
        if ( null !== $cached ) {
            return rest_ensure_response( [ 'categories' => $cached ] );
        }

        $query   = new CategoryQuery();
        $results = $query->get( $args );

        CacheManager::set( 'rest_categories', $cache_args, $results );

        return rest_ensure_response( [ 'categories' => $results, 'count' => count( $results ) ] );
    }

    /**
     * GET /zhp/v1/sellers
     *
     * Returns featured sellers.
     *
     * @since 1.6.0
     * @param \WP_REST_Request $request Incoming REST request.
     * @return \WP_REST_Response|\WP_Error
     */
    public function get_sellers( \WP_REST_Request $request ) {
        if ( ! Helpers::is_plugin_enabled() ) {
            return new \WP_Error( 'zhp_disabled', __( 'Plugin disabled.', 'zymarg-homepage' ), [ 'status' => 403 ] );
        }

        $limit  = (int) ( $request->get_param( 'limit' ) ?? 6 );
        $cached = CacheManager::get( 'rest_sellers', [ 'limit' => $limit ] );
        if ( null !== $cached ) {
            return rest_ensure_response( [ 'sellers' => $cached ] );
        }

        $query   = new SellerQuery();
        $results = $query->get( [ 'limit' => $limit ] );

        CacheManager::set( 'rest_sellers', [ 'limit' => $limit ], $results );

        return rest_ensure_response( [ 'sellers' => $results, 'count' => count( $results ) ] );
    }

    /**
     * POST /zhp/v1/newsletter/subscribe
     *
     * Validates the request and fires the 'zhp_newsletter_subscribe'
     * action hook so external newsletter plugins can process the sign-up.
     *
     * @since 1.6.0
     * @param \WP_REST_Request $request Incoming REST request.
     * @return \WP_REST_Response|\WP_Error
     */
    public function newsletter_subscribe( \WP_REST_Request $request ) {
        $nonce = sanitize_text_field( $request->get_param( 'zhp_nonce' ) ?? '' );

        if ( ! wp_verify_nonce( $nonce, 'zhp_newsletter' ) ) {
            return new \WP_Error( 'zhp_nonce_invalid', __( 'Security check failed.', 'zymarg-homepage' ), [ 'status' => 403 ] );
        }

        $email = sanitize_email( $request->get_param( 'email' ) ?? '' );

        if ( ! is_email( $email ) ) {
            return new \WP_Error( 'zhp_invalid_email', __( 'A valid email address is required.', 'zymarg-homepage' ), [ 'status' => 400 ] );
        }

        /**
         * Fires when a visitor subscribes via the ZYMARG Homepage newsletter form.
         *
         * Third-party newsletter plugins (Mailchimp for WooCommerce, MC4WP,
         * FluentCRM, etc.) should hook here to process the subscription.
         *
         * @since 1.6.0
         * @param string $email Sanitised email address.
         */
        do_action( 'zhp_newsletter_subscribe', $email );

        Logger::debug( 'REST /newsletter/subscribe', [ 'email' => substr( $email, 0, 3 ) . '…' ] );

        return rest_ensure_response( [
            'subscribed' => true,
            'message'    => __( 'Thank you for subscribing!', 'zymarg-homepage' ),
        ] );
    }

    // ──────────────────────────────────────────────────────────────
    //  Arg schemas
    // ──────────────────────────────────────────────────────────────

}
