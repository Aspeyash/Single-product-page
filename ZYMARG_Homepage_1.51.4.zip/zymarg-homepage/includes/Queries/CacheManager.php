<?php
/**
 * ZYMARG Homepage – Query Cache Manager
 *
 * Higher-level cache utility for the shared query layer. Wraps Core\Cache
 * with helpers that build consistent, collision-free keys from query class
 * names and argument hashes, and provide per-section cache invalidation.
 *
 * All cache reads and writes in this plugin's query classes must go through
 * Core\Cache (the transient layer). This class sits one level above it,
 * handling key construction and group invalidation so individual query
 * classes stay clean.
 *
 * @package ZYMARGHomepage\Queries
 * @since   1.4.0
 * @version 1.4.0
 */

namespace ZYMARGHomepage\Queries;

use ZYMARGHomepage\Core\Cache;
use ZYMARGHomepage\Core\Logger;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class CacheManager
 *
 * Builds deterministic cache keys and provides group-level invalidation
 * for the Queries layer. All methods are static — no state, no instance.
 */
final class CacheManager {

    /**
     * Maximum character length for the raw key segment before hashing.
     *
     * Core\Cache already handles total key length, but we pre-hash anything
     * over this length to keep keys readable in debug tools.
     *
     * @since 1.4.0
     * @var int
     */
    private const HASH_THRESHOLD = 80;

    // ──────────────────────────────────────────────────────────────
    //  Public API
    // ──────────────────────────────────────────────────────────────

    /**
     * Retrieve a cached query result.
     *
     * Returns null on a miss so call-sites can use null-coalescing:
     *   $data = CacheManager::get( 'products', $args ) ?? $this->run_query( $args );
     *
     * @since 1.4.0
     * @param string $group Query group / section slug (e.g. 'products', 'categories').
     * @param array  $args  Query arguments that differentiate this result set.
     * @return array|null Cached result array, or null on a miss.
     */
    public static function get( string $group, array $args = [] ): ?array {
        $key   = static::build_key( $group, $args );
        $value = Cache::get( $key );

        if ( null !== $value ) {
            Logger::debug( "Cache HIT [{$group}]", [ 'key' => $key ] );
        }

        return ( is_array( $value ) ) ? $value : null;
    }

    /**
     * Store a query result in the cache.
     *
     * @since 1.4.0
     * @param string $group       Query group / section slug.
     * @param array  $args        Query arguments used to produce the result.
     * @param array  $data        Result data to store.
     * @param int    $ttl_seconds Optional override TTL in seconds. Defaults to
     *                            the global cache-duration setting.
     * @return bool True on success.
     */
    public static function set(
        string $group,
        array $args,
        array $data,
        int $ttl_seconds = -1
    ): bool {
        $key = static::build_key( $group, $args );
        Logger::debug( "Cache SET [{$group}]", [ 'key' => $key, 'count' => count( $data ) ] );
        return Cache::set( $key, $data, $ttl_seconds );
    }

    /**
     * Delete a single cached result.
     *
     * @since 1.4.0
     * @param string $group Query group / section slug.
     * @param array  $args  Query arguments identifying the entry to remove.
     * @return bool True if the entry was deleted.
     */
    public static function delete( string $group, array $args = [] ): bool {
        $key = static::build_key( $group, $args );
        return Cache::delete( $key );
    }

    /**
     * Invalidate all cached entries for a given query group.
     *
     * Useful when product or category data changes: call
     *   CacheManager::invalidate_group( 'products' )
     * to purge every cached product query without touching unrelated groups.
     *
     * Delegates to Core\Cache::flush_all() when group-level invalidation
     * is not practical — the full flush is fast because WordPress transients
     * are cheap to delete.
     *
     * @since 1.4.0
     * @param string $group Group to invalidate. Pass '' to flush everything.
     * @return int Number of entries deleted.
     */
    public static function invalidate_group( string $group ): int {
        if ( '' === $group ) {
            return Cache::flush_all();
        }

        global $wpdb;

        $prefix  = '_transient_zhp_q_' . sanitize_key( $group ) . '_';
        $deleted = 0;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $rows = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT option_name FROM {$wpdb->options}
                 WHERE option_name LIKE %s
                    OR option_name LIKE %s",
                $prefix . '%',
                '_transient_timeout_zhp_q_' . sanitize_key( $group ) . '_%'
            )
        );

        foreach ( $rows as $option_name ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery
            $wpdb->delete( $wpdb->options, [ 'option_name' => $option_name ] );
            $deleted++;
        }

        Logger::debug( "Cache invalidated [{$group}]", [ 'deleted' => $deleted ] );

        return $deleted;
    }

    // ──────────────────────────────────────────────────────────────
    //  Private helpers
    // ──────────────────────────────────────────────────────────────

    /**
     * Build a deterministic cache key from a group name and argument hash.
     *
     * Format: q_{group}_{args_hash}
     *
     * The Core\Cache layer adds its own 'zhp_' prefix, so the full transient
     * key stored in the database is: zhp_q_{group}_{args_hash}.
     *
     * @since 1.4.0
     * @param string $group Query group slug.
     * @param array  $args  Query arguments.
     * @return string Unique cache key (without the 'zhp_' prefix).
     */
    private static function build_key( string $group, array $args ): string {
        // Sort args so that [ 'limit'=>8, 'order'=>'DESC' ] and
        // [ 'order'=>'DESC', 'limit'=>8 ] produce the same key.
        ksort( $args );
        $serialised = serialize( $args ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions

        $slug = sanitize_key( $group );

        if ( strlen( $serialised ) > self::HASH_THRESHOLD ) {
            $args_hash = md5( $serialised );
        } else {
            $args_hash = substr( md5( $serialised ), 0, 12 );
        }

        return "q_{$slug}_{$args_hash}";
    }
}
