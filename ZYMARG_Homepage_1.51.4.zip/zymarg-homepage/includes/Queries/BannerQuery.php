<?php
/**
 * ZYMARG Homepage – Banner Query
 *
 * Retrieves promotional banner data for the Promo Banner, Hero, and Collections
 * homepage sections. Supports two sources:
 *
 *   1. Custom post type `zhp_banner` — registered in Phase 5 by the PromoBanner
 *      and Collections features. Each post becomes one banner entry.
 *   2. Settings fallback — when the CPT has no published posts, falls back to
 *      the banners array stored inside `zymarg_hp_settings['banners']`.
 *      This allows the admin to configure banners before any CPT content exists.
 *
 * If neither source produces data, an empty array is returned without error.
 *
 * Return shape (each item in the result array):
 * [
 *   'id'          => int,    (post ID, or 0 for settings-based entries)
 *   'image_id'    => int,    (attachment ID, or 0 when there is no featured
 *                            image or the entry came from settings. Consumers
 *                            need this to build a srcset.)
 *   'title'       => string, (HTML-escaped banner title / heading)
 *   'subtitle'    => string, (secondary text line)
 *   'image_url'   => string,
 *   'image_alt'   => string,
 *   'link_url'    => string,
 *   'link_label'  => string, (CTA button label)
 *   'position'    => int,    (sort order, 1-based)
 *   'type'        => string, ('hero'|'promo'|'collection'|''),
 * ]
 *
 * @package ZYMARGHomepage\Queries
 * @since   1.4.0
 * @version 1.26.0
 */

namespace ZYMARGHomepage\Queries;

use ZYMARGHomepage\Core\Helpers;
use ZYMARGHomepage\Core\Logger;
use ZYMARGHomepage\Interfaces\QueryInterface;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class BannerQuery
 *
 * Retrieves promotional banner data from the zhp_banner CPT or settings.
 */
class BannerQuery implements QueryInterface {

    /**
     * Cache group identifier.
     *
     * @since 1.4.0
     * @var string
     */
    public const CACHE_GROUP = 'banners';

    /**
     * Custom post type slug registered by the PromoBanner / Collections features.
     *
     * @since 1.4.0
     * @var string
     */
    public const POST_TYPE = 'zhp_banner';

    // ──────────────────────────────────────────────────────────────
    //  QueryInterface
    // ──────────────────────────────────────────────────────────────

    /**
     * Run the banner query and return structured results.
     *
     * Supported $args keys:
     *   'limit'  (int)    Max banners to return. Default 10.
     *   'type'   (string) Filter by banner type meta ('hero'|'promo'|'collection'|'').
     *                     Empty string = no type filter.
     *   'offset' (int)    Query offset. Default 0.
     *
     * @since  1.4.0
     * @param  array $args Query arguments.
     * @return array       Banner result array. Empty when no banners are configured.
     */
    public function get( array $args = [] ): array {
        $args = $this->parse_args( $args );

        // Try cache.
        $cached = CacheManager::get( self::CACHE_GROUP, $args );
        if ( null !== $cached ) {
            return $cached;
        }

        // Primary source: zhp_banner custom post type (registered in Phase 5).
        $results = post_type_exists( self::POST_TYPE )
            ? $this->query_cpt( $args )
            : [];

        // Settings fallback when CPT has no content yet.
        if ( empty( $results ) ) {
            $results = $this->get_from_settings( $args );
        }

        if ( empty( $results ) ) {
            Logger::debug( 'BannerQuery: no banners found.' );
            return [];
        }

        CacheManager::set( self::CACHE_GROUP, $args, $results );

        Logger::debug(
            'BannerQuery ran.',
            [ 'found' => count( $results ), 'source' => post_type_exists( self::POST_TYPE ) ? 'cpt' : 'settings' ]
        );

        return $results;
    }

    // ──────────────────────────────────────────────────────────────
    //  Argument parsing
    // ──────────────────────────────────────────────────────────────

    /**
     * Parse and normalise raw args.
     *
     * @since 1.4.0
     * @param array $args Raw args.
     * @return array Normalised args.
     */
    private function parse_args( array $args ): array {
        $defaults = [
            'limit'  => 10,
            'type'   => '',
            'offset' => 0,
        ];

        $merged = wp_parse_args( $args, $defaults );

        $merged['limit']  = max( 1, min( 50, (int) $merged['limit'] ) );
        $merged['offset'] = max( 0, (int) $merged['offset'] );
        $merged['type']   = sanitize_key( $merged['type'] );

        return $merged;
    }

    // ──────────────────────────────────────────────────────────────
    //  CPT source
    // ──────────────────────────────────────────────────────────────

    /**
     * Query published banner posts from the zhp_banner CPT.
     *
     * Meta key `_zhp_banner_type` stores the banner type string.
     *
     * @since 1.4.0
     * @param array $args Normalised args.
     * @return array
     */
    private function query_cpt( array $args ): array {
        $query_args = [
            'post_type'              => self::POST_TYPE,
            'post_status'            => 'publish',
            'posts_per_page'         => $args['limit'],
            'offset'                 => $args['offset'],
            'orderby'                => 'menu_order',
            'order'                  => 'ASC',
            'no_found_rows'          => true,
            'update_post_meta_cache' => true,
            'update_post_term_cache' => false,
        ];

        if ( '' !== $args['type'] ) {
            $query_args['meta_query'][] = [
                'key'     => '_zhp_banner_type',
                'value'   => $args['type'],
                'compare' => '=',
            ];
        }

        $query = new \WP_Query( $query_args );

        if ( empty( $query->posts ) ) {
            wp_reset_postdata();
            return [];
        }

        $results = $this->hydrate_posts( $query->posts );
        wp_reset_postdata();

        return $results;
    }

    /**
     * Convert WP_Post objects to the structured return format.
     *
     * @since 1.4.0
     * @param \WP_Post[] $posts Posts from WP_Query.
     * @return array
     */
    private function hydrate_posts( array $posts ): array {
        $results  = [];
        $position = 1;

        foreach ( $posts as $post ) {
            if ( ! $post instanceof \WP_Post ) {
                continue;
            }

            $image_id   = (int) get_post_thumbnail_id( $post->ID );
            $image_url  = $image_id > 0
                ? (string) wp_get_attachment_image_url( $image_id, 'large' )
                : Helpers::placeholder_image_url();
            $image_alt  = $image_id > 0
                ? (string) get_post_meta( $image_id, '_wp_attachment_image_alt', true )
                : esc_attr( get_the_title( $post ) );

            $results[] = [
                'id'         => (int) $post->ID,
                // Exposed so templates can render a responsive <img> instead of
                // a background-image. This was already looked up above and then
                // discarded, forcing consumers to re-resolve it from the URL.
                'image_id'   => $image_id,
                'title'      => esc_html( get_the_title( $post ) ),
                'subtitle'   => esc_html( (string) get_post_meta( $post->ID, '_zhp_banner_subtitle', true ) ),
                'image_url'  => esc_url( $image_url ),
                'image_alt'  => esc_attr( $image_alt ),
                'link_url'   => esc_url( (string) get_post_meta( $post->ID, '_zhp_banner_link_url', true ) ),
                'link_label' => esc_html( (string) get_post_meta( $post->ID, '_zhp_banner_link_label', true ) ),
                'position'   => $position++,
                'type'       => esc_attr( (string) get_post_meta( $post->ID, '_zhp_banner_type', true ) ),
            ];
        }

        return $results;
    }

    // ──────────────────────────────────────────────────────────────
    //  Settings fallback
    // ──────────────────────────────────────────────────────────────

    /**
     * Pull banner data from the admin settings option.
     *
     * The Hero and PromoBanner admin settings panels (Phase 5) store banner
     * config directly in their section settings array. This method reads those
     * entries and normalises them to the same shape as CPT-based banners.
     *
     * @since 1.4.0
     * @param array $args Normalised args.
     * @return array
     */
    private function get_from_settings( array $args ): array {
        $section_order = get_option( 'zymarg_hp_section_order', [] );

        if ( ! is_array( $section_order ) ) {
            return [];
        }

        $results  = [];
        $position = 1;

        /*
         * Section slug => banner type requested by that section's Feature.
         *
         * The slug and the type are NOT the same string, and treating them as
         * the same was a silent bug: this method used to compare
         * sanitize_key( $slug ) against $args['type'] directly. Promo Banner
         * asks BannerQuery for type 'promo' while its slug is 'promo-banner',
         * so the comparison could never be true and the settings fallback
         * returned nothing for it on every request. Only Hero worked, because
         * its slug and type happen to be the same word.
         *
         * 'collections' is deliberately absent. Its settings panel has no
         * per-item fields at all — only a section heading, a limit and a
         * carousel toggle — so there is nothing here to build a collection
         * card from. Inventing one out of the section heading would render a
         * bogus card. As of 1.28.0 Collections does not use this query at all:
         * it stores its cards in its own section settings and reads them via
         * Features\Collections\Settings::items().
         */
        $slug_to_type = [
            'hero'         => 'hero',
            'promo-banner' => 'promo',
        ];

        foreach ( $section_order as $entry ) {
            if ( ! is_array( $entry ) ) {
                continue;
            }

            $slug     = $entry['slug'] ?? '';
            $settings = $entry['settings'] ?? [];

            if ( ! isset( $slug_to_type[ $slug ] ) ) {
                continue;
            }

            $banner_type = $slug_to_type[ $slug ];

            if ( '' !== $args['type'] && $banner_type !== $args['type'] ) {
                continue;
            }

            /*
             * The PromoBanner settings panel stores its image under
             * `image_url`, but the Hero panel stores it under `bg_image`. This
             * only read `image_url`, so a Hero configured through settings
             * never contributed an image here — and a Hero with an image but no
             * heading was skipped entirely by the check below.
             */
            $image = ! empty( $settings['image_url'] )
                ? $settings['image_url']
                : ( $settings['bg_image'] ?? '' );

            /*
             * The two panels do not agree on field names, and this method used
             * to read only the Hero spelling. A Promo Banner configured through
             * settings therefore produced an entry with an empty title and no
             * link even once it matched on type.
             *
             *   Hero panel:        heading / subheading / cta_url  / cta_label
             *   Promo Banner panel: title  / (none)     / link_url / link_label
             *
             * Each field below accepts either spelling, preferring the one the
             * panel that owns this slug actually writes.
             */
            $title      = $settings['title']      ?? ( $settings['heading']    ?? '' );
            $link_url   = $settings['link_url']   ?? ( $settings['cta_url']    ?? '' );
            $link_label = $settings['link_label'] ?? ( $settings['cta_label']  ?? '' );
            $image_alt  = $settings['alt_text']   ?? ( $settings['image_alt']  ?? $title );

            // Only yield an entry when there is at least a title or image.
            if ( '' === (string) $title && empty( $image ) ) {
                continue;
            }

            $results[] = [
                'id'         => 0,
                // Settings store a URL only, never an attachment ID.
                'image_id'   => 0,
                'title'      => esc_html( (string) $title ),
                'subtitle'   => esc_html( $settings['subheading'] ?? '' ),
                'image_url'  => esc_url( '' !== $image ? $image : Helpers::placeholder_image_url() ),
                'image_alt'  => esc_attr( (string) $image_alt ),
                'link_url'   => esc_url( (string) $link_url ),
                'link_label' => esc_html( (string) $link_label ),
                'position'   => $position++,
                // The banner type, not the section slug. Consumers filter on
                // the type vocabulary ('hero'|'promo'|'collection'), and
                // returning the slug here made this field disagree with the
                // 'type' argument callers had just passed in.
                'type'       => esc_attr( $banner_type ),
            ];

            if ( count( $results ) >= $args['limit'] ) {
                break;
            }
        }

        return $results;
    }
}
