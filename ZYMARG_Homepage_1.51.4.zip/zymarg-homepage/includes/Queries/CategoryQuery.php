<?php
/**
 * ZYMARG Homepage – Category Query
 *
 * Retrieves WooCommerce product categories for the Categories homepage section.
 * Results are cached via CacheManager.
 *
 * Return shape (each item in the result array):
 * [
 *   'id'          => int,
 *   'name'        => string  (HTML-escaped term name),
 *   'slug'        => string,
 *   'url'         => string  (term archive URL),
 *   'description' => string  (sanitised term description),
 *   'image_url'   => string  (thumbnail image URL, or placeholder),
 *   'image_alt'   => string,
 *   'count'       => int     (number of published products in this category),
 * ]
 *
 * @package ZYMARGHomepage\Queries
 * @since   1.4.0
 * @version 1.4.0
 */

namespace ZYMARGHomepage\Queries;

use ZYMARGHomepage\Core\Helpers;
use ZYMARGHomepage\Core\Logger;
use ZYMARGHomepage\Interfaces\QueryInterface;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class CategoryQuery
 *
 * Retrieves WooCommerce product category data for the homepage.
 */
class CategoryQuery implements QueryInterface {

    /**
     * Cache group identifier.
     *
     * @since 1.4.0
     * @var string
     */
    private const CACHE_GROUP = 'categories';

    // ──────────────────────────────────────────────────────────────
    //  QueryInterface
    // ──────────────────────────────────────────────────────────────

    /**
     * Run the category query and return structured results.
     *
     * Supported $args keys:
     *   'limit'      (int)    Max categories to return. Default 12.
     *   'parent'     (int)    Restrict to direct children of this term ID.
     *                         0 = top-level categories only. -1 = all levels.
     *   'hide_empty' (bool)   Exclude categories with zero products. Default true.
     *   'orderby'    (string) get_terms() orderby value. Default 'count'.
     *   'order'      (string) 'ASC' or 'DESC'. Default 'DESC'.
     *   'include'    (int[])  Term IDs to include (whitelist). Optional.
     *   'exclude'    (int[])  Term IDs to exclude. Optional.
     *
     * @since  1.4.0
     * @param  array $args Query arguments.
     * @return array       Category result array. Empty array when nothing found.
     */
    public function get( array $args = [] ): array {
        if ( ! function_exists( 'WC' ) ) {
            Logger::debug( 'CategoryQuery: WooCommerce not active.' );
            return [];
        }

        $args = $this->parse_args( $args );

        // Try cache.
        $cached = CacheManager::get( self::CACHE_GROUP, $args );
        if ( null !== $cached ) {
            return $cached;
        }

        $terms = get_terms( $this->build_query_args( $args ) );

        if ( is_wp_error( $terms ) || empty( $terms ) ) {
            Logger::debug( 'CategoryQuery: no terms found.' );
            return [];
        }

        /*
         * Enforce the limit ourselves - 1.51.1
         *
         * Passing 'number' to get_terms() is not enough here. WP_Term_Query
         * deliberately drops the SQL LIMIT whenever it may have to walk a
         * hierarchy - its own comment reads "Don't limit the query results when
         * we have to descend the family tree" - and that applies to us on two
         * counts: product_cat is hierarchical, and we pass an explicit
         * 'parent'. The result was every top-level category being returned
         * regardless of the setting: a live site set to 8 rendered 39, which
         * the marquee then cloned to 78 nodes.
         *
         * Slicing here rather than trusting 'number' keeps the guarantee local
         * and independent of core's internals, and it costs nothing: the terms
         * are already in memory, and the expensive per-term work (term meta
         * lookups and attachment URL resolution in hydrate()) now runs only
         * for the terms actually rendered instead of all of them.
         *
         * 'number' is intentionally left in build_query_args(): when core CAN
         * apply it, the limit happens in SQL, which is cheaper still.
         */
        if ( count( $terms ) > $args['limit'] ) {
            Logger::debug(
                'CategoryQuery: trimming terms get_terms() did not limit.',
                [ 'returned' => count( $terms ), 'limit' => $args['limit'] ]
            );
            $terms = array_slice( $terms, 0, $args['limit'] );
        }

        $results = $this->hydrate( $terms );

        CacheManager::set( self::CACHE_GROUP, $args, $results );

        Logger::debug(
            'CategoryQuery ran.',
            [ 'found' => count( $results ) ]
        );

        return $results;
    }

    // ──────────────────────────────────────────────────────────────
    //  Argument parsing
    // ──────────────────────────────────────────────────────────────

    /**
     * Parse and normalise raw args.
     *
     * @since 1.4.0
     * @param array $args Raw args.
     * @return array Normalised args.
     */
    private function parse_args( array $args ): array {
        $defaults = [
            'limit'      => 12,
            'parent'     => 0,       // 0 = top-level only; -1 = no restriction.
            'hide_empty' => true,
            'orderby'    => 'count',
            'order'      => 'DESC',
            'include'    => [],
            'exclude'    => [],
        ];

        $merged = wp_parse_args( $args, $defaults );

        $merged['limit']      = max( 1, min( 100, (int) $merged['limit'] ) );
        $merged['parent']     = (int) $merged['parent'];
        $merged['hide_empty'] = (bool) $merged['hide_empty'];
        $merged['order']      = in_array( strtoupper( $merged['order'] ), [ 'ASC', 'DESC' ], true )
            ? strtoupper( $merged['order'] )
            : 'DESC';
        $merged['include'] = array_map( 'absint', (array) $merged['include'] );
        $merged['exclude'] = array_map( 'absint', (array) $merged['exclude'] );

        return $merged;
    }

    /**
     * Build the get_terms() args array.
     *
     * @since 1.4.0
     * @param array $args Normalised args.
     * @return array get_terms() args.
     */
    private function build_query_args( array $args ): array {
        $query = [
            'taxonomy'   => 'product_cat',
            'number'     => $args['limit'],
            'hide_empty' => $args['hide_empty'],
            'orderby'    => $args['orderby'],
            'order'      => $args['order'],
        ];

        // Parent: 0 = top-level, -1 = no restriction, positive int = specific parent.
        if ( -1 !== $args['parent'] ) {
            $query['parent'] = $args['parent'];
        }

        if ( ! empty( $args['include'] ) ) {
            $query['include'] = $args['include'];
        }

        if ( ! empty( $args['exclude'] ) ) {
            $query['exclude'] = $args['exclude'];
        }

        return $query;
    }

    // ──────────────────────────────────────────────────────────────
    //  Result hydration
    // ──────────────────────────────────────────────────────────────

    /**
     * Convert WP_Term objects to the structured return format.
     *
     * @since 1.4.0
     * @param \WP_Term[] $terms Terms from get_terms().
     * @return array
     */
    private function hydrate( array $terms ): array {
        $results = [];

        foreach ( $terms as $term ) {
            if ( ! $term instanceof \WP_Term ) {
                continue;
            }

            $image_url = $this->get_category_image( $term->term_id );

            $results[] = [
                'id'          => (int) $term->term_id,
                'name'        => esc_html( $term->name ),
                'slug'        => esc_attr( $term->slug ),
                'url'         => esc_url( get_term_link( $term ) ),
                'description' => wp_kses_post( $term->description ),
                'image_url'   => $image_url,
                'image_alt'   => esc_attr( $term->name ),
                'count'       => (int) $term->count,
            ];
        }

        return $results;
    }

    /**
     * Retrieve the thumbnail image URL for a product category.
     *
     * WooCommerce stores category images as a term meta attachment ID
     * using the key 'thumbnail_id'.
     *
     * @since 1.4.0
     * @param int $term_id Term ID.
     * @return string Absolute image URL, or placeholder when none is set.
     */
    private function get_category_image( int $term_id ): string {
        $thumbnail_id = (int) get_term_meta( $term_id, 'thumbnail_id', true );

        if ( $thumbnail_id > 0 ) {
            $src = wp_get_attachment_image_url( $thumbnail_id, 'medium' );
            if ( $src ) {
                return esc_url( $src );
            }
        }

        // WooCommerce placeholder if available, otherwise our SVG fallback.
        if ( function_exists( 'wc_placeholder_img_src' ) ) {
            return esc_url( wc_placeholder_img_src( 'medium' ) );
        }

        return Helpers::placeholder_image_url();
    }
}
