<?php
/**
 * ZYMARG Homepage – Seller Query
 *
 * Retrieves Dokan vendor/seller data for the Featured Sellers homepage section.
 * Supports both Dokan (via dokan_get_sellers() and Dokan helper functions) and
 * a WooCommerce-only fallback that identifies sellers from order metadata.
 *
 * Detects Dokan at runtime; if Dokan is not active the query returns an empty
 * array cleanly with a debug log entry rather than throwing a fatal error.
 *
 * Return shape (each item in the result array):
 * [
 *   'id'            => int,    (WordPress user ID)
 *   'name'          => string, (store name, or display_name fallback)
 *   'url'           => string, (Dokan store URL, or author archive URL)
 *   'avatar_url'    => string, (store avatar / Gravatar)
 *   'banner_url'    => string, (store banner image URL, or placeholder)
 *   'rating'        => float,  (0.0 – 5.0)
 *   'rating_count'  => int,
 *   'product_count' => int,
 *   'location'      => string, (store address / city)
 * ]
 *
 * @package ZYMARGHomepage\Queries
 * @since   1.4.0
 * @version 1.4.0
 */

namespace ZYMARGHomepage\Queries;

use ZYMARGHomepage\Core\Helpers;
use ZYMARGHomepage\Core\Logger;
use ZYMARGHomepage\Interfaces\QueryInterface;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class SellerQuery
 *
 * Retrieves Dokan vendor/seller data for homepage sections.
 */
class SellerQuery implements QueryInterface {

    /**
     * Cache group identifier.
     *
     * @since 1.4.0
     * @var string
     */
    private const CACHE_GROUP = 'sellers';

    // ──────────────────────────────────────────────────────────────
    //  QueryInterface
    // ──────────────────────────────────────────────────────────────

    /**
     * Run the seller query and return structured results.
     *
     * Supported $args keys:
     *   'limit'    (int)    Number of sellers to return. Default 8.
     *   'featured' (bool)   Limit to featured sellers only. Default false.
     *   'orderby'  (string) 'registered'|'login'|'nicename'|'email'. Default 'registered'.
     *   'order'    (string) 'ASC' or 'DESC'. Default 'DESC'.
     *
     * @since  1.4.0
     * @param  array $args Query arguments.
     * @return array       Seller result array. Empty when Dokan not active or no sellers.
     */
    public function get( array $args = [] ): array {
        if ( ! $this->is_dokan_active() ) {
            Logger::debug( 'SellerQuery: Dokan not active. Returning empty.' );
            return [];
        }

        $args = $this->parse_args( $args );

        // Try cache.
        $cached = CacheManager::get( self::CACHE_GROUP, $args );
        if ( null !== $cached ) {
            return $cached;
        }

        $sellers = $this->fetch_sellers( $args );

        $results = $this->hydrate( $sellers );

        CacheManager::set( self::CACHE_GROUP, $args, $results );

        Logger::debug(
            'SellerQuery ran.',
            [ 'found' => count( $results ) ]
        );

        return $results;
    }

    // ──────────────────────────────────────────────────────────────
    //  Dokan detection
    // ──────────────────────────────────────────────────────────────

    /**
     * Check whether Dokan is installed and active.
     *
     * @since 1.4.0
     * @return bool
     */
    private function is_dokan_active(): bool {
        return function_exists( 'dokan_get_sellers' ) || class_exists( 'WeDevs\Dokan\Vendor\Vendor' );
    }

    // ──────────────────────────────────────────────────────────────
    //  Argument parsing
    // ──────────────────────────────────────────────────────────────

    /**
     * Parse and normalise raw args.
     *
     * @since 1.4.0
     * @param array $args Raw args.
     * @return array Normalised args.
     */
    private function parse_args( array $args ): array {
        $defaults = [
            'limit'    => 8,
            'featured' => false,
            'orderby'  => 'registered',
            'order'    => 'DESC',
        ];

        $merged = wp_parse_args( $args, $defaults );

        $merged['limit']    = max( 1, min( 50, (int) $merged['limit'] ) );
        $merged['featured'] = (bool) $merged['featured'];
        $merged['order']    = in_array( strtoupper( $merged['order'] ), [ 'ASC', 'DESC' ], true )
            ? strtoupper( $merged['order'] )
            : 'DESC';

        $allowed_orderby      = [ 'registered', 'login', 'nicename', 'email', 'display_name' ];
        $merged['orderby']    = in_array( $merged['orderby'], $allowed_orderby, true )
            ? $merged['orderby']
            : 'registered';

        return $merged;
    }

    // ──────────────────────────────────────────────────────────────
    //  Data fetching
    // ──────────────────────────────────────────────────────────────

    /**
     * Fetch sellers from Dokan.
     *
     * dokan_get_sellers() returns [ 'sellers' => WP_User[], 'count' => int ].
     *
     * @since 1.4.0
     * @param array $args Normalised args.
     * @return \WP_User[]
     */
    private function fetch_sellers( array $args ): array {
        $query_args = [
            'number'  => $args['limit'],
            'orderby' => $args['orderby'],
            'order'   => $args['order'],
            'status'  => 'approved',
            'paged'   => 1,
        ];

        if ( $args['featured'] ) {
            $query_args['featured'] = 'yes';
        }

        // dokan_get_sellers() is the canonical public Dokan API.
        if ( function_exists( 'dokan_get_sellers' ) ) {
            $result = dokan_get_sellers( $query_args );
            return is_array( $result['sellers'] ?? null ) ? $result['sellers'] : [];
        }

        // Fallback: WP_User_Query with Dokan's vendor role.
        $user_query = new \WP_User_Query( [
            'role'    => 'seller',
            'number'  => $args['limit'],
            'orderby' => $args['orderby'],
            'order'   => $args['order'],
        ] );

        return $user_query->get_results() ?: [];
    }

    // ──────────────────────────────────────────────────────────────
    //  Result hydration
    // ──────────────────────────────────────────────────────────────

    /**
     * Convert WP_User objects to the structured return format.
     *
     * @since 1.4.0
     * @param \WP_User[] $sellers User objects from Dokan or WP_User_Query.
     * @return array
     */
    private function hydrate( array $sellers ): array {
        $results = [];

        foreach ( $sellers as $user ) {
            if ( ! $user instanceof \WP_User ) {
                continue;
            }

            $store_info = $this->get_store_info( $user );

            $results[] = [
                'id'            => (int) $user->ID,
                'name'          => esc_html( $store_info['store_name'] ?: $user->display_name ),
                'url'           => esc_url( $store_info['store_url'] ?: get_author_posts_url( $user->ID ) ),
                'avatar_url'    => esc_url( $store_info['avatar_url'] ),
                'banner_url'    => esc_url( $store_info['banner_url'] ),
                'rating'        => (float) $store_info['rating'],
                'rating_count'  => (int) $store_info['rating_count'],
                'product_count' => (int) $store_info['product_count'],
                'location'      => esc_html( $store_info['location'] ),
            ];
        }

        return $results;
    }

    /**
     * Build a normalised store-info array from Dokan meta or raw user meta.
     *
     * @since 1.4.0
     * @param \WP_User $user WordPress user object.
     * @return array Store info with guaranteed keys.
     */
    private function get_store_info( \WP_User $user ): array {
        $empty = [
            'store_name'    => '',
            'store_url'     => '',
            'avatar_url'    => get_avatar_url( $user->ID, [ 'size' => 150 ] ),
            'banner_url'    => Helpers::placeholder_image_url(),
            'rating'        => 0.0,
            'rating_count'  => 0,
            'product_count' => 0,
            'location'      => '',
        ];

        // Dokan stores vendor meta in usermeta key 'dokan_profile_settings'.
        $dokan_info = get_user_meta( $user->ID, 'dokan_profile_settings', true );

        if ( empty( $dokan_info ) || ! is_array( $dokan_info ) ) {
            return $empty;
        }

        // Store URL.
        $store_url = '';
        if ( function_exists( 'dokan_get_store_url' ) ) {
            $store_url = (string) dokan_get_store_url( $user->ID );
        }

        // Avatar URL — Dokan stores attachment ID in 'gravatar'.
        $avatar_url = $empty['avatar_url'];
        if ( ! empty( $dokan_info['gravatar'] ) ) {
            $src = wp_get_attachment_image_url( (int) $dokan_info['gravatar'], 'thumbnail' );
            if ( $src ) {
                $avatar_url = $src;
            }
        }

        // Banner URL — Dokan stores attachment ID in 'banner'.
        $banner_url = $empty['banner_url'];
        if ( ! empty( $dokan_info['banner'] ) ) {
            $src = wp_get_attachment_image_url( (int) $dokan_info['banner'], 'large' );
            if ( $src ) {
                $banner_url = $src;
            }
        }

        // Rating.
        $rating       = 0.0;
        $rating_count = 0;

        if ( function_exists( 'dokan_get_seller_rating' ) ) {
            $rating_data  = dokan_get_seller_rating( $user->ID );
            $rating       = (float) ( $rating_data['rating'] ?? 0 );
            $rating_count = (int) ( $rating_data['count'] ?? 0 );
        }

        // Product count.
        $product_count = 0;
        if ( function_exists( 'dokan_count_posts' ) ) {
            $counts        = dokan_count_posts( 'product', $user->ID );
            $product_count = (int) ( $counts->publish ?? 0 );
        } else {
            $product_count = (int) count_user_posts( $user->ID, 'product' );
        }

        // Address / location.
        $address  = $dokan_info['address'] ?? [];
        $location = trim(
            implode( ', ', array_filter( [
                $address['city']    ?? '',
                $address['state']   ?? '',
                $address['country'] ?? '',
            ] ) )
        );

        return [
            'store_name'    => sanitize_text_field( $dokan_info['store_name'] ?? '' ),
            'store_url'     => $store_url,
            'avatar_url'    => $avatar_url,
            'banner_url'    => $banner_url,
            'rating'        => min( 5.0, max( 0.0, $rating ) ),
            'rating_count'  => $rating_count,
            'product_count' => $product_count,
            'location'      => $location,
        ];
    }
}
