<?php
/**
 * ZYMARG Homepage – Homepage Controller
 *
 * The top-level coordinator for all homepage rendering. Instantiated by
 * Plugin::setup() during Phase 2. Responsible for:
 *
 *   1. Booting FeatureRegistry (registering all known features).
 *   2. Wiring the [zymarg_homepage] shortcode.
 *   3. Exposing the zymarg_homepage_render() public PHP function.
 *   4. (Future Phase 5) Registering feature-specific assets when a
 *      feature is enabled and the homepage is being rendered.
 *
 * All add_shortcode / add_action / add_filter calls that relate to the
 * homepage go through Hooks.php — HomepageController only instantiates
 * subsystems and exposes the render method.
 *
 * @package ZYMARGHomepage\Homepage
 * @since   1.1.0
 * @version 1.7.3
 */

namespace ZYMARGHomepage\Homepage;

use ZYMARGHomepage\Core\Logger;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class HomepageController
 *
 * Wires together FeatureRegistry, SectionManager, LayoutEngine, and Renderer.
 */
final class HomepageController {

    /**
     * Renderer instance.
     *
     * @since 1.1.0
     * @var Renderer
     */
    private Renderer $renderer;

    /**
     * Section manager instance — also used by admin pages.
     *
     * @since 1.1.0
     * @var SectionManager
     */
    private SectionManager $section_manager;

    /**
     * Constructor.
     *
     * Boots subsystems in dependency order:
     *   1. Feature registration (populates FeatureRegistry).
     *   2. SectionManager and LayoutEngine.
     *   3. Renderer.
     *
     * @since 1.1.0
     */
    public function __construct() {
        $this->boot_features();

        $this->section_manager = new SectionManager();
        $layout_engine         = new LayoutEngine();
        $this->renderer        = new Renderer( $this->section_manager, $layout_engine );
    }

    // ──────────────────────────────────────────────────────────────
    //  Public API
    // ──────────────────────────────────────────────────────────────

    /**
     * Render the full homepage and return the HTML string.
     *
     * Called by the shortcode handler in Hooks.php and by the public
     * helper function zymarg_homepage_render() below.
     *
     * Returns an empty string (not an error) when:
     *   – The master switch is disabled in global settings.
     *   – No sections are active.
     *
     * @since 1.1.0
     * @return string
     */
    public function render(): string {
        if ( ! $this->is_active() ) {
            Logger::debug( 'HomepageController: master switch disabled — returning empty.' );
            return '';
        }

        return $this->renderer->render();
    }

    /**
     * Return the SectionManager so admin pages can read/write section data.
     *
     * @since 1.1.0
     * @return SectionManager
     */
    public function get_section_manager(): SectionManager {
        return $this->section_manager;
    }

    /**
     * Return true if the plugin master switch is on.
     *
     * Reads from the `zymarg_hp_settings` option. Defaults to true so
     * the homepage renders on activation without requiring manual setup.
     *
     * @since 1.1.0
     * @return bool
     */
    public function is_active(): bool {
        $settings = get_option( 'zymarg_hp_settings', [] );
        return (bool) ( $settings['master_enabled'] ?? true );
    }

    /**
     * Filter callback: automatically override front page content with plugin output.
     *
     * Hooked to the WordPress `the_content` filter by Hooks::register().
     * Replaces the front page post content with the full plugin homepage HTML
     * so no shortcode or manual page edit is required after activation.
     *
     * Falls back silently to the original $content when:
     *   – Not a singular front page request in the main query loop.
     *   – The [zymarg_homepage] shortcode is already present (prevents double render).
     *   – render() returns empty (master switch off / no sections enabled).
     *
     * @since 1.7.3
     * @param string $content Original post content passed by WordPress.
     * @return string Plugin homepage HTML, or original $content as fallback.
     */
    public function maybe_override_content( string $content ): string {
        if ( ! is_singular() )   { return $content; }
        if ( ! is_front_page() ) { return $content; }
        if ( ! in_the_loop() )   { return $content; }
        if ( ! is_main_query() ) { return $content; }

        // Prevent double output when the shortcode is already in the content.
        if ( has_shortcode( $content, 'zymarg_homepage' ) ) {
            return $content;
        }

        $output = $this->render();

        // If render() returns empty, show original content so the page
        // is never blank — the admin will see an empty page and check settings.
        return $output !== '' ? $output : $content;
    }

    // ──────────────────────────────────────────────────────────────
    //  Private helpers
    // ──────────────────────────────────────────────────────────────

    /**
     * Register all known feature sections with FeatureRegistry.
     *
     * Phase 2: registry is populated but empty — no features exist yet.
     * Phase 5: uncomment each feature as it is built.
     *
     * @since 1.1.0
     * @return void
     */
    private function boot_features(): void {
        // ── Phase 5a: Hero ───────────────────────────────────────
        FeatureRegistry::register( new \ZYMARGHomepage\Features\Hero\Feature() );

        // ── Phase 5b: Categories ─────────────────────────────────
        FeatureRegistry::register( new \ZYMARGHomepage\Features\Categories\Feature() );

        // ── Phase 5c: Product Sections (7 independent sub-types) ─
        foreach ( \ZYMARGHomepage\Features\ProductSections\Feature::all_instances() as $product_feature ) {
            FeatureRegistry::register( $product_feature );
        }

        // ── Phase 5d: Featured Sellers ───────────────────────────
        FeatureRegistry::register( new \ZYMARGHomepage\Features\FeaturedSellers\Feature() );

        // ── Phase 5e: Promo Banner ───────────────────────────────
        FeatureRegistry::register( new \ZYMARGHomepage\Features\PromoBanner\Feature() );

        // ── Phase 5f: Collections ────────────────────────────────
        FeatureRegistry::register( new \ZYMARGHomepage\Features\Collections\Feature() );

        // ── Phase 5g: Brands ─────────────────────────────────────
        FeatureRegistry::register( new \ZYMARGHomepage\Features\Brands\Feature() );

        // ── Phase 5h: Newsletter ─────────────────────────────────
        FeatureRegistry::register( new \ZYMARGHomepage\Features\Newsletter\Feature() );

        // ── Phase 5i: Footer CTA ─────────────────────────────────
        FeatureRegistry::register( new \ZYMARGHomepage\Features\FooterCTA\Feature() );

        Logger::debug( 'HomepageController: feature registry booted (' . count( FeatureRegistry::all() ) . ' features).' );
    }
}
