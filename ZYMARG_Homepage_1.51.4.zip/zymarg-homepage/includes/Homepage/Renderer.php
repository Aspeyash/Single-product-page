<?php
/**
 * ZYMARG Homepage – Renderer
 *
 * Wraps the LayoutEngine output in the homepage page wrapper and loads
 * the outer homepage template (`templates/homepage.php`). This is the
 * class HomepageController calls when it needs the final HTML string.
 *
 * Separation of concerns:
 *   LayoutEngine  – iterates features, assembles section fragments.
 *   Renderer      – wraps fragments in the page-level container template.
 *   HomepageController – decides WHEN to render (shortcode, template_redirect).
 *
 * @package ZYMARGHomepage\Homepage
 * @since   1.1.0
 * @version 1.22.0
 */

namespace ZYMARGHomepage\Homepage;

use ZYMARGHomepage\Core\Logger;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Renderer
 *
 * Assembles the outer page wrapper around LayoutEngine output.
 */
final class Renderer {

    /**
     * Section manager — supplies the ordered, enabled section list.
     *
     * @since 1.1.0
     * @var SectionManager
     */
    private SectionManager $section_manager;

    /**
     * Layout engine — renders per-section HTML fragments.
     *
     * @since 1.1.0
     * @var LayoutEngine
     */
    private LayoutEngine $layout_engine;

    /**
     * Constructor.
     *
     * @since 1.1.0
     * @param SectionManager $section_manager Injected section manager.
     * @param LayoutEngine   $layout_engine   Injected layout engine.
     */
    public function __construct(
        SectionManager $section_manager,
        LayoutEngine   $layout_engine
    ) {
        $this->section_manager = $section_manager;
        $this->layout_engine   = $layout_engine;
    }

    /**
     * Render the full homepage and return the HTML string.
     *
     * Loads `templates/homepage.php` which has access to `$sections_html`
     * via the closure below, so the template itself stays logic-free.
     *
     * @since 1.1.0
     * @return string Full homepage HTML.
     */
    public function render(): string {
        $active_sections = $this->section_manager->get_active_sections();
        $sections_html   = $this->layout_engine->render( $active_sections );

        Logger::debug( 'Renderer: rendering homepage with ' . count( $active_sections ) . ' active section(s).' );

        return $this->load_template( $sections_html );
    }

    // ──────────────────────────────────────────────────────────────
    //  Private helpers
    // ──────────────────────────────────────────────────────────────

    /**
     * Load templates/homepage.php in an isolated scope and return its output.
     *
     * The template receives one variable: $sections_html (string).
     * No other variables leak into the template scope.
     *
     * @since 1.1.0
     * @param string $sections_html Assembled section HTML from LayoutEngine.
     * @return string Rendered template output.
     */
    private function load_template( string $sections_html ): string {
        /*
         * Theme override: if the active theme (or child theme) ships a file at
         *   zymarg-homepage/homepage.php
         * inside its directory, that file is used instead of the plugin's own
         * template. This is the standard WordPress template-hierarchy pattern.
         *
         * The plugin template is the fallback, not the override, so a theme
         * customisation survives a plugin update without needing to be redone.
         *
         * locate_template() searches child theme first, then parent theme, and
                  * returns an empty string when neither ships the file.
         *
         * The second argument `false` means "return the path, do not load it";
         * we load it ourselves below in an isolated scope so that only
         * $sections_html is visible to the template.
         *
         * The third argument `false` means "do not require_once" — the
         * function would otherwise mark the file as loaded and refuse to
         * include it again on the same request.
         */
        $theme_template  = locate_template( 'zymarg-homepage/homepage.php', false, false );
        $template_path   = $theme_template !== ''
            ? $theme_template
            : ZYMARG_HP_PLUGIN_DIR . 'templates/homepage.php';

        if ( ! is_readable( $template_path ) ) {
            Logger::debug( 'Renderer: homepage template not found at ' . $template_path );
            return '';
        }

        ob_start();
        // Minimal scope: only $sections_html is visible to the template.
        ( static function ( string $sections_html ) use ( $template_path ): void {
            include $template_path;
        } )( $sections_html );

        return ob_get_clean() ?: '';
    }
}
