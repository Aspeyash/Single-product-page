<?php
/**
 * ZYMARG Homepage – Feature Registry
 *
 * Central registry of all homepage feature sections. Every Feature class
 * that exists registers itself here. FeatureRegistry is the single source
 * of truth for which features the system knows about.
 *
 * Usage:
 *   FeatureRegistry::register( new Hero\Feature() );
 *   $all = FeatureRegistry::all();     // array of FeatureInterface
 *   $f   = FeatureRegistry::get('hero'); // FeatureInterface|null
 *
 * @package ZYMARGHomepage\Homepage
 * @since   1.1.0
 * @version 1.2.0
 */

namespace ZYMARGHomepage\Homepage;

use ZYMARGHomepage\Interfaces\FeatureInterface;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class FeatureRegistry
 *
 * Holds all registered feature instances keyed by slug.
 * All methods are static — no instantiation needed.
 */
final class FeatureRegistry {

    /**
     * Registered feature instances, keyed by slug.
     *
     * @since 1.1.0
     * @var array<string, FeatureInterface>
     */
    private static array $features = [];

    /**
     * Register a feature with the registry.
     *
     * Called once per feature during HomepageController::boot().
     * Silently ignores duplicate slugs (first registration wins).
     *
     * @since 1.1.0
     * @param FeatureInterface $feature Feature instance to register.
     * @return void
     */
    public static function register( FeatureInterface $feature ): void {
        $slug = $feature->get_slug();

        if ( isset( self::$features[ $slug ] ) ) {
            return; // Already registered — first one wins.
        }

        self::$features[ $slug ] = $feature;
    }

    /**
     * Return all registered features, keyed by slug.
     *
     * @since 1.1.0
     * @return array<string, FeatureInterface>
     */
    public static function all(): array {
        return self::$features;
    }

    /**
     * Return a single feature by slug, or null if not registered.
     *
     * @since 1.1.0
     * @param string $slug Feature slug.
     * @return FeatureInterface|null
     */
    public static function get( string $slug ): ?FeatureInterface {
        return self::$features[ $slug ] ?? null;
    }

    /**
     * Return true if a feature with the given slug is registered.
     *
     * @since 1.1.0
     * @param string $slug Feature slug.
     * @return bool
     */
    public static function has( string $slug ): bool {
        return isset( self::$features[ $slug ] );
    }

    /**
     * Clear all registered features.
     *
     * Intended for unit tests only. Not called during normal operation.
     *
     * @since 1.1.0
     * @return void
     */
    public static function reset(): void {
        self::$features = [];
    }
}
