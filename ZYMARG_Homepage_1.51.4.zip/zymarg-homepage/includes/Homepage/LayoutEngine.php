<?php
/**
 * ZYMARG Homepage – Layout Engine
 *
 * Iterates the ordered, enabled-only section list supplied by SectionManager
 * and calls each feature's Query then Template in sequence. Assembles the
 * collected HTML fragments into the final homepage output string.
 *
 * Disabled sections are never touched here — SectionManager has already
 * excluded them before passing the list in.
 *
 * @package ZYMARGHomepage\Homepage
 * @since   1.1.0
 * @version 1.35.0
 */

namespace ZYMARGHomepage\Homepage;

use ZYMARGHomepage\Core\Logger;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class LayoutEngine
 *
 * Drives the per-section render loop.
 */
final class LayoutEngine {

    /**
     * Render all active sections and return the assembled HTML.
     *
     * @since 1.1.0
     * @param array $sections Ordered enabled-only section list from SectionManager.
     *                        Each entry: [ 'slug' => string, 'settings' => array ]
     * @return string Full homepage HTML (without outer page wrapper).
     */
    public function render( array $sections ): string {
        $html = '';

        foreach ( $sections as $section ) {
            $slug     = $section['slug']     ?? '';
            $settings = $section['settings'] ?? [];

            if ( empty( $slug ) ) {
                continue;
            }

            $feature = FeatureRegistry::get( $slug );

            if ( null === $feature ) {
                Logger::debug( "LayoutEngine: no feature registered for slug '{$slug}' — skipping." );
                continue;
            }

            $section_html = $this->render_section( $feature, $settings, $slug );

            if ( ! empty( $section_html ) ) {
                /*
                 * The "Extra CSS" box applies to every section, not only the
                 * ones running a full custom design. Emitted here, in the one
                 * place all sections pass through, so no template has to
                 * remember to do it.
                 */
                $html .= \ZYMARGHomepage\Core\CustomSection::standalone_css( $settings, $slug );
                $html .= $section_html . "\n";
            }
        }

        return $html;
    }

    // ──────────────────────────────────────────────────────────────
    //  Private helpers
    // ──────────────────────────────────────────────────────────────

    /**
     * Render a single section, catching any exceptions so one broken
     * section cannot take down the entire homepage.
     *
     * @since 1.1.0
     * @param \ZYMARGHomepage\Interfaces\FeatureInterface $feature  Feature instance.
     * @param array                                       $settings Per-section settings.
     * @param string                                      $slug     Section slug (for logging).
     * @return string HTML fragment, or empty string on failure.
     */
    private function render_section(
        \ZYMARGHomepage\Interfaces\FeatureInterface $feature,
        array $settings,
        string $slug
    ): string {
        try {
            return $feature->render( $settings );
        } catch ( \Throwable $e ) {
            Logger::debug(
                "LayoutEngine: exception rendering '{$slug}': " . $e->getMessage()
            );
            // In production, return empty rather than a PHP error on the page.
            return '';
        }
    }
}
