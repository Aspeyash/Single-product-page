<?php
/**
 * ZYMARG Homepage – Section Manager
 *
 * Reads the saved section order, toggle states, and per-section settings
 * from the `zymarg_hp_section_order` WordPress option. Returns an ordered
 * list of enabled sections ready for LayoutEngine to render.
 *
 * Data format stored in zymarg_hp_section_order (serialised array):
 *   [
 *     [ 'slug' => 'hero',       'enabled' => true,  'order' => 1, 'settings' => [] ],
 *     [ 'slug' => 'categories', 'enabled' => false, 'order' => 2, 'settings' => [] ],
 *     …
 *   ]
 *
 * When the option is empty or missing, defaults are built from
 * FeatureRegistry so every registered feature appears in the admin list.
 *
 * @package ZYMARGHomepage\Homepage
 * @since   1.1.0
 * @version 1.46.1
 */

namespace ZYMARGHomepage\Homepage;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class SectionManager
 *
 * Reads and normalises section configuration from the database.
 */
final class SectionManager {

    /**
     * WordPress option key that stores section order, toggles, and settings.
     *
     * @since 1.1.0
     */
    public const OPTION_KEY = 'zymarg_hp_section_order';

    /**
     * Return ordered, enabled-only section entries for LayoutEngine.
     *
     * Each entry: [ 'slug' => string, 'settings' => array ]
     * Disabled sections are excluded entirely.
     *
     * @since 1.1.0
     * @return array<int, array{ slug: string, settings: array }>
     */
    public function get_active_sections(): array {
        $all = $this->get_all_sections();

        // Filter to enabled only, then strip the 'enabled' / 'order' keys.
        $active = array_values(
            array_filter( $all, fn( array $s ) => ! empty( $s['enabled'] ) )
        );

        return array_map(
            fn( array $s ) => [
                'slug'     => $s['slug'],
                'settings' => $s['settings'] ?? [],
            ],
            $active
        );
    }

    /**
     * Return ALL section entries (enabled and disabled), sorted by order.
     *
     * Used by the admin panel to build the full drag-and-drop list.
     *
     * @since 1.1.0
     * @return array<int, array{ slug: string, enabled: bool, order: int, settings: array }>
     */
    public function get_all_sections(): array {
        // Slugs retired in past releases can linger in the saved option and
        // would otherwise be counted and listed as real sections.
        $removed = array( 'recently-viewed' );

        $saved = get_option( self::OPTION_KEY, [] );

        // Fall back to defaults when nothing is stored yet.
        //
        // This getter used to call update_option() here. That made a read
        // operation write to the database on the front end, on every request
        // where the option was empty — including AJAX and REST requests. It
        // also persisted defaults built from whatever happened to be in
        // FeatureRegistry at that moment, which is empty during activation,
        // so an empty array could be written and then read back as "empty"
        // forever. Defaults are now computed in memory; persisting them is
        // the job of save().
        if ( empty( $saved ) || ! is_array( $saved ) ) {
            $saved = $this->build_defaults();
        }

        // Normalise each row and sort ascending by order.
        $sections = array_map( [ $this, 'normalise_row' ], $saved );

        usort( $sections, fn( array $a, array $b ) => $a['order'] <=> $b['order'] );

        /*
         * Merge in features that are registered but absent from the saved
         * option (1.46.1).
         *
         * Defaults were only ever built when the option was completely empty,
         * so on any site that had saved a section order even once, a newly
         * added feature could never appear: it was registered in
         * FeatureRegistry, it rendered correctly, but the admin list was built
         * purely from the stored rows and therefore had no row to toggle it
         * with. Every section added after a site's first save was invisible.
         *
         * New features are appended using their own declared default order and
         * default enabled state, then the whole list is re-sorted, so a new
         * section lands where its author intended rather than at the bottom.
         */
        $saved_slugs = array_column( $sections, 'slug' );

        foreach ( FeatureRegistry::all() as $feature ) {
            $slug = $feature->get_slug();

            if ( in_array( $slug, $saved_slugs, true ) || in_array( $slug, $removed, true ) ) {
                continue;
            }

            $sections[] = [
                'slug'     => $slug,
                'enabled'  => $feature->is_enabled_by_default(),
                'order'    => $feature->get_default_order(),
                'settings' => [],
            ];
        }

        $sections = array_values( array_filter(
            $sections,
            static function ( $row ) use ( $removed ) {
                return ! in_array( ( $row['slug'] ?? '' ), $removed, true );
            }
        ) );

        // Re-sort after the merge so appended features take their declared
        // position instead of trailing the list.
        usort( $sections, fn( array $a, array $b ) => $a['order'] <=> $b['order'] );

        return $sections;
    }

    /**
     * Persist a new section order / state array to the database.
     *
     * Called by the admin AJAX save handler. Input is validated and
     * sanitised before writing.
     *
     * @since 1.1.0
     * @param array $sections Raw data from the admin POST.
     * @return bool True on success, false on failure.
     */
    public function save( array $sections ): bool {
        $sanitised = array_map( [ $this, 'sanitise_row' ], $sections );
        return update_option( self::OPTION_KEY, array_values( $sanitised ) );
    }

    // ──────────────────────────────────────────────────────────────
    //  Private helpers
    // ──────────────────────────────────────────────────────────────

    /**
     * Build default section order from registered features.
     *
     * Called the first time SectionManager::get_all_sections() runs and
     * the option is empty. Every registered feature starts as enabled.
     *
     * @since 1.1.0
     * @return array
     */
    private function build_defaults(): array {
        $features = FeatureRegistry::all();

        // Sort by the feature's declared default order.
        uasort( $features, fn( $a, $b ) => $a->get_default_order() <=> $b->get_default_order() );

        $rows  = [];
        $order = 1;

        foreach ( $features as $feature ) {
            $rows[] = [
                'slug'     => $feature->get_slug(),
                'enabled'  => $feature->is_enabled_by_default(),
                'order'    => $order++,
                'settings' => [],
            ];
        }

        return $rows;
    }

    /**
     * Normalise a stored row, filling in missing keys with safe defaults.
     *
     * @since 1.1.0
     * @param mixed $row Raw row value from the option.
     * @return array Normalised row.
     */
    private function normalise_row( mixed $row ): array {
        if ( ! is_array( $row ) ) {
            $row = [];
        }

        return [
            'slug'     => isset( $row['slug'] ) ? sanitize_key( $row['slug'] ) : '',
            'enabled'  => ! empty( $row['enabled'] ),
            'order'    => isset( $row['order'] ) ? absint( $row['order'] ) : 999,
            'settings' => isset( $row['settings'] ) && is_array( $row['settings'] )
                ? $row['settings']
                : [],
        ];
    }

    /**
     * Sanitise a row coming in from the admin POST before saving.
     *
     * @since 1.1.0
     * @param mixed $row Raw row from POST data.
     * @return array Sanitised row.
     */
    private function sanitise_row( mixed $row ): array {
        $clean = $this->normalise_row( $row );

        // Deep-sanitise the settings sub-array.
        $clean['settings'] = $this->sanitise_settings( $clean['settings'] );

        return $clean;
    }

    /**
     * Recursively sanitise a settings array so no raw unsanitised values
     * are written to the database from admin input.
     *
     * @since 1.1.0
     * @param array $settings Settings array from POST.
     * @return array Sanitised settings.
     */
    private function sanitise_settings( array $settings ): array {
        $clean = [];

        foreach ( $settings as $key => $value ) {
            $clean_key = sanitize_key( $key );

            if ( is_array( $value ) ) {
                $clean[ $clean_key ] = $this->sanitise_settings( $value );
            } elseif ( in_array( $clean_key, \ZYMARGHomepage\Core\CustomSection::RAW_KEYS, true ) ) {
                /*
                 * These keys hold the administrator's own HTML and CSS. Running
                 * them through sanitize_text_field() would strip every tag and
                 * silently destroy the pasted design on save, so they are stored
                 * verbatim. Only users who passed the manage_options check in
                 * DragDrop::handle_save() can reach this point, and the markup is
                 * adapted and confined to its section by CustomSection at render
                 * time rather than being mangled on the way in.
                 */
                $clean[ $clean_key ] = (string) $value;
            } elseif ( is_bool( $value ) || is_int( $value ) ) {
                $clean[ $clean_key ] = $value;
            } else {
                // Treat all other scalars as text.
                $clean[ $clean_key ] = sanitize_text_field( (string) $value );
            }
        }

        return $clean;
    }
}
