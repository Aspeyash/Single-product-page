<?php
/**
 * ZYMARG Homepage – Page Wrapper Template
 *
 * This file is loaded by Renderer::load_template() in an isolated scope.
 * It receives exactly one variable:
 *
 *   $sections_html (string) — assembled HTML from LayoutEngine.
 *
 * Rules:
 *   – No query logic here. No wp_enqueue_* calls here.
 *   – No inline <style> or <script> blocks.
 *   – Use zhp- CSS class prefix exclusively.
 *   – Escape everything: esc_html(), esc_attr(), esc_url(), wp_kses_post().
 *   – The wrapper div is always rendered, even when $sections_html is empty,
 *     so JavaScript and CSS hooks always have a target element on the page.
 *
 * @package ZYMARGHomepage
 * @since   1.1.0
 * @version 1.20.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// $sections_html is provided by Renderer::load_template() — always a string.
/** @var string $sections_html */
?>
<?php
/*
 * role="main" was removed in 1.20.0: <main> already exposes that role, and a
 * redundant role is a defect rather than belt-and-braces — it is what screen
 * readers report when a theme's own <main> is also present, turning one
 * mislabelled landmark into two.
 *
 * The aria-label was removed at the same time. It named this landmark
 * "ZYMARG Homepage", so screen reader users heard the plugin's brand read out
 * as the name of the page's main region. An unlabelled <main> is announced
 * simply as "main", which is correct and is what a sighted user perceives.
 */
?>
<main
    id="zhp-homepage"
    class="zhp-homepage"
>
    <?php
    // ─────────────────────────────────────────────────────────────
    //  DO NOT wrap this in wp_kses_post().
    //
    //  $sections_html is built entirely by this plugin's own feature
    //  templates, which escape every dynamic value at the point of
    //  output (esc_html / esc_attr / esc_url / wp_kses_post on the
    //  single field that legitimately carries markup: price_html).
    //
    //  wp_kses_post() only permits *post content* HTML. It strips
    //  <form>, <input>, <button>, <svg> and every data-* attribute,
    //  which silently destroyed the newsletter form, the load-more
    //  and filter controls, all inline icons, and every data-zhp-*
    //  JavaScript hook on the page.
    //
    //  Re-filtering already-escaped trusted output is not a security
    //  gain — it is data loss. Escaping stays at the source.
    // ─────────────────────────────────────────────────────────────

    /**
     * Filter the fully assembled homepage section HTML before output.
     *
     * @since 1.9.5
     * @param string $sections_html Assembled section markup.
     */
    echo apply_filters( 'zhp_homepage_sections_html', $sections_html ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped at source by each feature template.
    ?>
</main><!-- #zhp-homepage -->
