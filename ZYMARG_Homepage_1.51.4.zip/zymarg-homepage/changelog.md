## 1.51.3

### Changed

- Content Width now applies above 768px instead of above 1440px. The control
  was previously gated to very large monitors, which meant that on a 1366px or
  1440px laptop the homepage stayed at its fixed 1280px cap while the Connection
  Engine and Store Page plugins - whose matching Content Width controls apply
  from 769px - had already widened. Setting the same number in all three plugins
  now produces the same width on every screen above a phone.
- Phones are still excluded, so the Side Gap (Mobile) alignment with the
  Connection Engine is unchanged.
- No default changed. Content Width still ships at 0, meaning the 1280px design
  as shipped, so this is inert until an administrator sets a value.

## 1.51.2

### Changed
- The Categories section now explains itself. The screen asked for a number of
  categories but never said which ones it would pick, so there was no way for an
  admin to know selection is by product count, that empty categories are skipped,
  or that the number is a ceiling rather than a target. Added helper text for both
  the count and the carousel toggle, using the same description pattern the
  rotation fields already use.

## 1.51.1

### Fixed
- The Categories section ignored its own "Number of Categories" setting. Passing
  `number` to `get_terms()` is not honoured when the taxonomy is hierarchical or
  an explicit `parent` is supplied - both true here - so WP_Term_Query dropped the
  SQL LIMIT and returned every top-level category. A live site whose field allows
  at most 20 rendered 39, which the marquee cloned to 78 nodes. The limit is now
  enforced in PHP after the query, so the per-term meta and attachment lookups in
  hydrate() also run only for terms actually rendered.

## 1.51.0

### Added
- **Content Width** setting. Content was capped at a fixed 1280px, so on a 2560px
  or 4K screen every section sat in a centred column with about half the viewport
  empty while the hero band behind it stretched edge to edge. The control is a
  percentage of the viewport, so it keeps adjusting to whatever screen the page is
  opened on. 0 keeps the shipped 1280px cap and emits no CSS at all. Applies above
  1440px only, so the mobile side gap tuned to the Connection Engine is untouched.
- **Hero Text Width** setting. The hero copy was locked to 600px, which is the
  other half of why a full-bleed hero looked empty on a large screen.

### Fixed
- Product sections whose query matched nothing rendered a heading above the
  engine's "No products found." message instead of being hidden. The engine
  returns an empty-state block rather than an empty string, so neither the empty
  check nor the HIDE_WIDGET sentinel caught it. Such rows are now dropped whole.
- Carousel autoplay measured a slide with `offsetWidth`, ignoring the flex gap, so
  each tick under-scrolled by one gap. Measured live: 150px cards, 16px gap, 166px
  true pitch, losing 16px per tick until the leftmost card was sliced mid-word.
  The slide is now measured between consecutive card offsets, so drift is zero.

## 1.50.1 - 2026-08-07

### Fixed

- Side gap did not actually match the Connection Engine on screen despite both being set to 4px. The homepage sat roughly 21px from each edge against the engine's ~5px on the same phone.
- Nothing in this plugin accounted for the difference: .zhp-section has no horizontal padding, .zhp-grid-host is unstyled, and every section is wrapped in .zhp-container. The remainder belongs to the Product Grid engine, which renders its own grid wrapper inside .zhp-grid-host with its own gutter, so the two insets stacked.
- The Connection Engine never showed this because it draws engine cards into its own .zceb-grid, so the engine's grid wrapper is never used and there is only one gutter. The engine wrapper's horizontal padding and margin are now zeroed inside our host, leaving .zhp-container as the single gap layer so the typed pixel value is the real distance from the screen edge.
- Carousel tracks are excluded, since they rely on their own inline padding to stop card hover shadows clipping.

## 1.50.0 - 2026-08-07

### Added

- Master Gap. One control that scales every vertical gap at once - section spacing, heading spacing, band padding and all the Gap Below controls. Ranges 0-300 rather than 0-100, since the useful direction for a master control is usually loosening. Each individual control still applies its own factor on top, so the existing settings keep working as fine-tuning.
- Card Gap. Scales the space between cards, across a row and between rows, from the built-in 12px on phones and up to 32px on wide grids. Previously only reachable by hand-editing the token stylesheet.
- Cards Per Row, with separate Desktop, Tablet and Mobile values. The column count previously lived in three disagreeing places - a rule added in 1.49.5, the auto-fill rules in the section stylesheets, and columns => 4 hardcoded in ProductGridBridge - none of which could be reached from the settings screen. All three are now driven by one setting each.
- Side Gap (Mobile), in pixels. The number typed in is the gap, matching how the Connection Engine's own field behaves, so both plugins can be set to the same figure and line up.

### Changed

- The spacing registry now supports per-control bounds and two new emitter modes, one for pixel lengths and one for bare integers. Ranges are declared once in the registry and read by the sanitiser, the CSS emitter and the settings markup, instead of 0-100 being restated in each.

## 1.49.6 - 2026-08-07

### Changed

- Mobile side gap corrected to 4px to genuinely match the Connection Engine. 1.49.4 set 12px after reading the engine's .zceb-main padding, but that rule is cancelled further down the engine's own stylesheet, so it never takes effect. The engine's real mobile geometry is a full-bleed shell at 100% width with the container padding as the only gap layer, set from the Browse tab and defaulting to 4px.
- Mobile card gap now tightens from 12px to 10px below 600px, which is what the engine grid does.
- Both plugins are now full-bleed on mobile and inset by the same 4px, so a homepage section and a browse page line up on the same phone.
- The Side Padding control still scales the side gap, so a moved slider keeps its own value.

## 1.49.5 - 2026-08-07

### Fixed

- Product rows still showed four cards across on mobile. The homepage does not always draw its own cards: when Use Product Grid Cards is enabled, ProductGridBridge hands the entire section to the Product Grid engine and wraps the result in .zhp-grid-host. The element that actually lays the cards out is then the engine's own grid, carrying .zymarg-wcpg__grid and a cols-N class derived from the bridge config, which requests four columns.
- That element is neither .zhp-product-grid nor, outside carousel mode, a .zhp-carousel-track, so every rule added in 1.49.1 through 1.49.4 missed it entirely. The column count is now overridden from the .zhp-grid-host wrapper, with the selector doubled for specificity so the engine's own cols-N rule cannot win on stylesheet load order.
- Engine cards are allowed to shrink into the narrower column, since a fixed card width would otherwise push the row wider than the screen.
- Carousel tracks stay excluded, so a section switched to carousel mode remains a single scrolling row.

## 1.49.4 - 2026-08-07

### Fixed

- Every section showed four cards on mobile instead of two. Earlier releases only ever touched the carousel, but carousel.css is enqueued solely when a section has its carousel setting enabled - so sections left on the default wrapping grid were never covered by any of those fixes.
- The section grids also disagreed with each other. Products and Sellers asked for two columns below 767px, Categories resolved to roughly three because it used auto-fill with a 110px minimum, Collections had no mobile rule at all, and Brands had no grid rules whatsoever.
- Mobile breakpoint widened from 767px to 900px across every section and the carousel. 767px left tablet-width phones on the desktop layout, which is where the persistent four-across came from, and 900px is the width the carousel already treats as touch, so the two now agree.
- Every section grid gained an explicit two-column mobile rule, and Brands gained a flex-basis since it is a centred strip rather than a grid. All of them carry :not(.zhp-carousel-track) so a section switched to carousel mode still stays a single scrolling row.

### Changed

- Default mobile side gap reduced from 16px to 12px to match the Connection Engine browse page, which insets its main column by 12px below 768px. The two plugins previously sat at different widths on the same phone. The Side Padding control still scales this value.

## 1.49.3 - 2026-08-07

### Fixed

- Mobile carousels still showed four cards in a single row after 1.49.2. The cause was not card width but the column count: the Product Grid engine paints grid-template-columns onto the very element the carousel promotes, with !important, at a specificity this stylesheet cannot reliably outrank. Escalating the grid rules was never going to settle it.
- On mobile the track is now a flex row rather than a grid. grid-template-columns has no meaning on a flex container, so every engine column rule goes inert at once instead of being overridden one at a time, and card width moves to a flex-basis on the children - a property those grid rules cannot address.
- Full-width banner slides are excluded from the flex switch, so Hero and Promo Banner still show one slide per view.

## 1.49.2 - 2026-08-07

### Fixed

- Mobile carousels still showed four cards after 1.49.1. A media query adds no specificity of its own, and the per-section widths are two-class selectors such as .zhp-categories__grid.zhp-carousel-track. The 1.49.1 mobile rule was a single class, so it lost the cascade outright and the desktop width survived straight into mobile. The mobile selector now repeats its class to outrank the per-section widths, which keeps the fix out of !important territory.

## 1.49.1 - 2026-08-07

### Fixed

- Carousel cards were sliced flat along the top when tapped. The track sets overflow-y to hidden, which a horizontal scroll container must do, so anything a card paints outside its own box is clipped. Only 4px of vertical padding was allowed for this, while cards lift 4px on hover and cast a shadow above that. Padding raised to 20px with a matching negative margin, so the clip box grows while the row stays put. It read as touch-only because tapping leaves :hover stuck on.
- Carousel mobile breakpoint moved from 600px to 768px to match the container tokens and the hero, which both already treat 768px as mobile.
- Mobile card widths now match engine-promoted product grids. They were written as compound pairs like .zhp-product-grid.zhp-carousel-track, but the element that actually scrolls on a Product Grid row is the engine's own grid, which gains .zhp-carousel-track and never carries .zhp-product-grid.
- Card width is measured from the visible track instead of guessed in vw, so two cards fit at any phone size, less a deliberate sliver of the third as the swipe affordance.

## 1.49.0 - 2026-08-07

### Added

- Four new spacing controls covering every edge of the hero and the sides of the page.
- **Gap Above Hero** - space between the top of the page and the banner.
- **Gap Beside Hero** - insets the full-bleed banner from the screen edges for a card-style hero. The banner keeps its own centring, so hero text re-centres as it narrows.
- **Hero Padding (Sides)** - horizontal space between the hero text and the banner edges. Inside counterpart to Gap Beside Hero.
- **Side Padding** - horizontal equivalent of Section Gap. Scales the container padding, so it reaches every section plus the content inside the full-bleed bands.
- All four are Core\Spacing registry entries, so default, sanitiser clamp, settings markup, admin JS key and CSS emitter derive from one definition.
- Defaults reproduce the shipped layout exactly and emit no CSS at all, so upgrading changes nothing on screen.

### Fixed

- ZYMARG_HP_VERSION was stuck at 1.46.2 while the header read 1.48.0. That constant cache-busts every enqueued stylesheet and script, so browsers were free to keep serving CSS and JS from before 1.47.0.

## 1.48.0 - 2026-08-07

### Changed

- Explore More now points at the Connection Engine's Explore page instead of the virtual Browse page. A real page cannot be claimed by another plugin's template_include hook, which is what was replacing /category/ with an unrelated template.
- Falls back to the Browse page when running against Connection Engine 1.10.x, and to the Shop page when the engine is absent, so nothing breaks on an older engine.

# ZYMARG Homepage — Changelog

## 1.47.1 - 2026-08-06

### Changed
- Explore More now defaults to the Browse page instead of the Shop page. In 1.47.0 this was opt-in per section, which meant the feature shipped switched off and every section still went to the Shop page until seven separate dropdowns were changed by hand. The fallback guards already handled every unsafe case, so the opt-in protected nothing.
- Sections explicitly set to "Shop page" keep that setting. Any section with an Explore More Link URL filled in is unaffected, as before.

### Fixed
- Explore More can no longer point at a 404 when the Connection Engine browse page is switched off. The bridge now gets an empty string back and falls through to the Shop page.

## 1.47.0 - 2026-08-06

### Added

- **Explore More Destination** setting on every section that has an Explore
  More link. Choose "Browse page, showing this section's products" and the link
  opens the Connection Engine browse page scoped to that section's own feed,
  instead of an unfiltered Shop page that has nothing to do with what the
  shopper just clicked.
- `ProductGridBridge::browse_url_for_slug()`, which builds that URL and returns
  an empty string whenever the promise cannot be kept.

### Changed

- `ProductGridBridge::is_source_available()` now asks the Product Grid engine
  directly (`Public_API::has_source()`) when it is new enough to answer. The
  hardcoded `ENGINE_SOURCES` / `EXTERNAL_SOURCE_CLASSES` lists were a copy of a
  list owned by another plugin, and a copy goes stale silently in both
  directions -- hiding a source that was added, or advertising one that was
  removed. Both lists remain as the fallback for older engine versions.
- The Explore More URL field description now says it overrides the destination
  setting rather than describing the Shop page fallback.

### Note

- **Nothing on a live homepage moves as a result of installing this.** The new
  setting defaults to "Shop page", which is the existing behaviour, and each
  section has to be opted in individually. The option is only offered when
  Connection Engine 1.10.0+ is active.
- An explicit Explore More URL still wins over the destination setting, exactly
  as before.
- Sections with no equivalent product feed -- and any section at all if the
  Connection Engine is inactive or too old -- fall back to the Shop page.

---

## 1.46.2 - 2026-08-06

### Fixed

- **New Arrivals was showing each visitor their own browsing history instead of the newest products.** The section was mapped to the Product Grid engine's `recent` source, which despite its name is the engine's *recently viewed* source: `Source_Recent` opens by calling `Recently_Viewed::get_ids()` and contains no date-ordered query at all. The consequences were easy to miss, because the row still looked plausible to anyone who had browsed the shop — it showed real products, just the wrong ones, personalised per visitor and in recency-of-viewing order. For a first-time visitor with no history the source returned nothing and the row silently disappeared, which read as an intermittent layout glitch rather than a wrong-source bug.
- New Arrivals is now mapped to `all` with an explicit `orderby = date`, `order = DESC`, which is what the section has always claimed to show, and which always returns products regardless of who is looking.

### Changed

- `build_config()` now sets ordering for the `all` source. `Source_All` already defaults to date DESC, so the fix would work without this, but the section's entire meaning rests on that ordering and leaving it implicit would let a future change to the engine's default silently repurpose the row. Both values remain overridable so a later section can reuse `all` with different ordering.

### Note

- No settings change and no migration. Existing per-section settings on the New Arrivals row are preserved: they only ever held `limit` and card toggles, none of which were source-specific.
- The engine's `recent` source is now unused by this plugin. It remains the correct source for a dedicated Recently Viewed section, which is still filtered out by the `$removed` list in `SectionManager::get_all_sections()` and is not part of this release.
## 1.46.1 - 2026-08-06

### Fixed

- **Newly added sections never appeared in the admin section list.** `SectionManager::get_all_sections()` built its list purely from the saved `zymarg_hp_section_order` option, and the full default list was only ever generated when that option was completely empty. On any site that had saved a section order even once, a newly registered feature was therefore invisible: it was correctly registered, and it would have rendered correctly, but no row existed to toggle it with. This affected every section added after a site's first save, and it is why **Just For You** did not show up after installing 1.46.0. Registered features that are missing from the saved option are now merged into the list using their own declared default order and default enabled state, then the list is re-sorted, so a new section lands where its author intended rather than at the end.
- The admin screen's hardcoded `SLUG_LABELS` and `DEFAULT_SLUGS` lists were a second, independent copy of the section list, so even once a section reached the list it would have been labelled from its slug. Both now include `dynamic-picks`, and label lookup falls back to the feature's own `get_label()` before prettifying the slug. Existing labels are resolved from the hardcoded map first and are unchanged, so nothing in the UI is renamed by this release.

### Note

- No database migration is needed. The merge happens on read, so existing saved orders, toggles and per-section settings are left untouched, and Just For You appears in its intended position immediately after upgrading.
## 1.46.0 - 2026-08-06

### Added

- A seventh product section, **Just For You**, driven by the Product Grid engine's `dynamic` source. Where the existing rows each read one fixed signal — Featured reads a flag, Best Sellers reads sales, New Arrivals reads a date — this one scores every published product on three signals at once and shows the highest scoring. A small jitter is applied on top, so the row shifts subtly between page loads rather than showing the same eight products until the cache expires. Off by default; enable it on the Homepage screen like any other section.
- Four settings on that section, shown only for it:
  - **Newness weight**, **Rating weight** and **Sales weight**. Left blank they fall back to the engine's own 60 / 30 / 10 split. The three numbers are relative rather than percentages, so 60/30/10 and 6/3/1 behave identically, and a 0 removes that signal entirely.
  - **Reshuffle how often** — how long the 200-product candidate pool is cached: every minute, hourly, or daily. The visible order still moves on every page load regardless of this setting, so the lightest option does not make the row look frozen.

### Changed

- `ProductGridBridge::build_config()` now forwards the dynamic scoring keys into the engine's query config. It previously sent only `source`, `limit` and the card toggles, so any new per-section query setting was silently dropped on the way to the engine. Weights are forwarded only when the administrator actually entered one: sending `0` for an untouched field would have been read as a deliberate zero weight and flattened the scoring, whereas omitting the key lets the engine apply its own default.
- The engine needed no changes. `Query_Adapter` passes query keys it has no mapping for through unchanged, and `Config_Normalizer` deep-merges the `query` section without discarding unrecognised keys, so the settings arrive at `Source_Dynamic` intact.

### Known issue, not fixed here

- **New Arrivals is mapped to the wrong engine source.** `SOURCE_MAP` sends it to `recent`, which despite its name is the engine's *recently viewed* source: `Source_Dynamic`'s sibling `Source_Recent` opens by calling `Recently_Viewed::get_ids()` and contains no date-ordered query at all. The row therefore shows each visitor's own browsing history, and returns nothing for a first-time visitor, which reads as the section intermittently vanishing rather than as a wrong-source bug. The fix is to point `new-arrivals` at `all` with `orderby => date`, and to add a separate Recently Viewed section for `recent` — which also requires removing `recently-viewed` from the `$removed` list in `SectionManager::get_all_sections()`. Left out of this release to keep it to one change.
## 1.45.1 - 2026-07-31

### Fixed

- A custom **Explore More HTML** drifted to the centre of the heading row and stopped looking like a right-aligned link, but only when **Custom Header HTML** was filled in as well. `explore_more()` builds custom markup by calling `prepare_header()`, the heading builder, so the result carried the heading's `.zhp-custom-header` class. In a custom heading row both children then matched the greedy `flex: 1 1 auto` rule intended for the heading alone, each claimed half the row, and the rule that pins the link right matched nothing at all. The custom link now carries `.zhp-explore-more--custom` and has its own rule. With only one of the two boxes filled the row was never a custom row, which is why the problem appeared only in combination.
- A custom **Explore More HTML** was not clickable. That path never emitted an anchor, so unless the supplied markup contained its own link the result was styled but inert text. Custom markup is now wrapped in a link to the Explore More URL automatically, and skipped when the markup already contains an anchor, so hand-written links still win and anchors can never nest.
- **Explore More URL** was silently ignored the moment anything was typed into the Explore More HTML box, because the destination was only resolved further down, on the default-markup path. It is now resolved before the custom branch and both paths use it.

## 1.45.0 - 2026-07-31

### Added

- Seven new spacing controls on the Settings screen, all 0-100:
  - **Hero Height** and **Hero Padding**. The hero was fixed to a minimum height of roughly 420-560px with no way to change it.
  - **Gap Below Hero**, **Gap Between Sections**, **Gap Below Promo Banner**, **Gap Below Newsletter** and **Gap Below Footer CTA**. These control separation *between* blocks, which nothing controlled before.
- The Newsletter and Footer CTA could not be parted at any setting. Both are full-bleed blocks carrying their own background with no outer margin, so the two colours met at a hard seam. **Gap Below Newsletter** is the fix.

### Changed

- **Band Spacing** is now labelled **Band Padding**, which is what it always did: it sets padding *inside* the three full-bleed bands, so raising it makes them taller and can never push them apart. The setting key is unchanged, so saved values carry over untouched.
- All ten spacing controls now come from one registry, `Core\Spacing`. Each control previously needed the same edit in five files - a default, a clamp, a block of markup, a JS key and a CSS emitter - with its bounds restated in four of them and nothing keeping the copies honest. Adding a control is now a single registry entry.
- The Help screen's spacing reference is generated from that registry, so it can no longer fall behind the controls it documents.

### Fixed

- Activation seeded the settings option without `section_gap`, `header_gap` or `band_gap`, despite a comment in the file stating the list had to match `Admin\Settings::DEFAULTS`. Values still read correctly, because reads merge against the defaults, but the keys were absent from the database on a fresh install until the settings form was first saved.

### Notes on defaults

- The new gap controls default to **0**, not 100. For the scale controls 100 means "the design as shipped"; for a gap that does not exist yet, 0 is the design as shipped. The rule that holds for every control is that its default reproduces the current layout and is the only value that emits no CSS at all. Upgrading changes nothing until a control is moved.
- **Hero Padding** has no visible effect until **Hero Height** is low enough that the hero's content, rather than its minimum height, decides how tall it is. Hero Height is the control that makes the banner shorter.

## 1.44.3 - 2026-07-31

### Fixed
- The round "+" add-to-cart button was sliced in half along the bottom edge of
  every ZYMARG branded card. The card template positions that button inside a
  zero-height anchor and centres it on the boundary between the price row and
  the vendor row with `translateY(-50%)`, which only works while a vendor row
  actually follows it. With the vendor row disabled the anchor becomes the last
  child of the card body and sits flush against the bottom of the content box,
  so the button's lower half fell outside the card shell and was clipped by the
  `overflow: hidden` that rounds the card's corners. `products.css` now gives
  the anchor the button's bottom half as real height when it is the last child,
  which returns the whole button to the clip region without moving it relative
  to the price row. Scoped to `.zhp-grid-host` and to `:last-child`, so cards
  rendered elsewhere and cards that do show a vendor row are untouched. No
  files outside this plugin are modified.

## 1.44.2 - 2026-07-31

### Fixed
- Layout shift on reload in every product section when the ZYMARG branded card
  is selected. The Product Grid engine enqueues a card template's `style.css`
  from inside its render routine, and on the homepage that render happens
  during `the_content()` — after `wp_head()` has already been sent — so
  WordPress printed the `<link>` in the footer. The branded card therefore
  painted before the stylesheet that defines its 1:1 image box, so every
  product image rendered at its natural size and the grid snapped down once
  the CSS arrived. The engine's default card was unaffected because its rules
  ship inside `zymarg-wcpg-frontend`, which does reach the `<head>`.
  `Core\Assets` now resolves the selected card's stylesheet through the
  engine's `Template_Manager` and enqueues it during `wp_enqueue_scripts`,
  before first paint. It registers under the engine's own handle, so the
  engine's later render-time enqueue is a no-op and the URL and version are
  unchanged. No files outside this plugin are touched.

## 1.44.1 - 2026-07-31

### Fixed
- Layout shift on reload for carousel-enabled product sections. 1.40.0 styled
  the engine grid straight from the `data-zhp-carousel-host` attribute so the
  row was a row on the first paint, but the CSS matched only
  `[class*="wcpg__grid"]` while carousel.js also accepts `[data-columns-desktop]`.
  A grid carrying only that attribute painted as a wrapping multi-row grid and
  then collapsed to one row when the script ran - measured at 616px to 308px,
  so everything below it jumped. The CSS selector lists now mirror the script's.
- Layout shift from the Promo Banner image. The template hardcodes
  `width="1200" height="300"` on the `<img>` regardless of the file actually
  uploaded, so the browser reserved a 4:1 box and then resized it to the real
  ratio on load. The reserved box is now pinned to 4:1 in CSS, and the image is
  cropped into it by the existing `object-fit: cover`.

## 1.44.0 - 2026-07-31

### Added
- Band Spacing setting (0-100%) on the Settings screen. Controls the vertical
  padding inside the three full-bleed bands - Newsletter, Footer CTA and Promo
  Banner - on its own `--zhp-band-scale` property, independent of both Section
  Gap and Header Gap. Defaults to 100 and emits no CSS at that value.

### Fixed
- Newsletter and Footer CTA were half-coupled to Section Gap. Their flat
  `padding: 48px 0` lost the top edge to `.zhp-section + .zhp-section`, a
  two-class selector and therefore more specific, so the top scaled with
  Section Gap while the bottom stayed at a fixed 48px. Tightening the page left
  both bands visibly lopsided. Their padding now comes from a two-class rule of
  its own, which wins both edges, and is symmetric top and bottom.

### Changed
- Promo Banner moved from the section rhythm onto Band Spacing, so the three
  full-bleed bands are controlled together.
- The bottom edge of Newsletter and Footer CTA now uses the same responsive
  clamp as the top rather than a flat 48px, so at Band Spacing 100 on a 1280px
  viewport it renders 51.2px instead of 48px. The top edge is unchanged.

## 1.43.1 - 2026-07-31

### Fixed
- Header Gap had no visible effect on a real store. The setting saved and
  emitted its CSS correctly, but the cards are drawn by the Product Grid
  engine, whose markup is wrapped in an unstyled `.zhp-grid-host`. That wrapper
  is an adjacent normal-flow sibling of the heading row, so the engine's own
  top margin and the heading row's `margin-bottom` collapsed to the larger of
  the two rather than adding. Whenever the engine's margin was larger it won at
  every setting. The top margin of the wrapper and of its first child is now
  zeroed directly after a heading row, so the heading row's `margin-bottom` is
  the only thing producing this gap and 0-100% maps to 0-24px exactly.

## 1.43.0 - 2026-07-31

### Added
- Header Gap setting (0-100%) on the Settings screen. Scales the space between
  a section heading and the product cards beneath it. 100 is the spacing as
  shipped (24px), 50 halves it, 0 sits the cards directly under the heading.
  Independent of Section Gap: it runs on its own `--zhp-header-scale` custom
  property, so neither control moves the other. Defaults to 100 and emits no
  CSS at that value, so an existing install is unchanged until it is touched.

## 1.42.0 - 2026-07-31

### Added
- Section Gap setting (0-100%) on the Settings screen. Scales the vertical
  space between every homepage section. 100 is the spacing as shipped, so an
  existing install is unchanged until the value is touched.

## 1.41.0 - 2026-07-31

### Changed
- Help page now documents auto-rotate on row carousels, the Rotation Style
  choice, Seconds Between Slides and the Continuous speed, and corrects the
  Glide Speed entry to cover rows as well as banners.

### Removed
- Dead nonces for zhp_load_more, zhp_search and zhp_filter. Those AJAX actions
  were removed in 1.30.0, so the nonces signed handlers that no longer exist.
- The unused loadMore i18n string and the stale load-more.js / filters.js
  comments left behind by that same removal.

## 1.40.0 - 2026-07-31

### Added
- Rotation Style choice on every section that rotates - the ten row carousels
  and the Hero, Promo Banner and Footer CTA banners. "Step" is the default and
  is unchanged; "Continuous" drifts the row steadily from right to left with no
  pauses, looping seamlessly, at a configurable pixels-per-second speed.

### Fixed
- Sections with auto-rotate on shifted their layout on every page load. The
  engine grid was only turned into a single row once the script ran, so the
  cards first painted as a wrapping multi-row grid and then snapped. The
  carousel layout is now applied from the markup itself, before any script.

## 1.39.0 - 2026-07-31

### Added
- Auto-rotate for row carousels, including the six product sections. Each of
  the ten carousel sections now has "Rotate the carousel automatically",
  "Seconds Between Slides" and "Glide Speed". Rotation stops permanently on
  any shopper interaction and never starts under reduced motion.
- Glide Speed now applies to row carousels, not just banners, so the arrows
  use the same easing there.

## 1.38.0 - 2026-07-31

### Fixed
- Carousel had no effect on the six product sections. The engine returns a
  wrapper holding a heading, the card grid and pagination, but the promotion
  step targeted that wrapper instead of the grid, so the carousel laid out
  three blocks as columns while the cards kept wrapping into rows. The card
  grid itself is now promoted.
- The Explore More controls (URL, label, custom HTML and the hide toggle) were
  missing on all six product sections. They are the only sections that do not
  call render_admin_fields(), so the link rendered on those rows with no way
  to configure it.

## 1.37.0 - 2026-07-31

### Fixed
- Save Changes no longer shifts the header. Swapping the label to "Saving..."
  resized the button, moving the whole header row twice per save. The measured
  width is now pinned while the label changes.
- The save confirmation is built on demand when a screen has no notice
  element, so a successful save can no longer look like nothing happened.
- Reset to Defaults re-renders the sections screen through the admin router
  instead of reloading the page, matching the rest of the admin.
- Explore More was still dropped by a custom heading on the six product
  sections. They render their own header rather than going through
  CustomSection::render_section_header(), so the 1.36.0 fix never reached
  them. Both now render together there too.

## 1.36.0 - 2026-07-31

### Fixed
- Saving on the Sections screen no longer makes the page jump. The
  confirmation was a block in normal flow, so showing it pushed the list down
  and fading it out pulled it back up. It is now a floating toast.
- Horizontal carousel had no effect on the six product sections. The engine
  grid carries its own column rules at the same CSS specificity as the
  carousel track, so load order decided the winner and the row stayed a
  wrapping multi-row grid. The column count is now overridden outright.
- "Show countdown timer" appeared on all six product sections although it only
  ever applied to Flash Deals. It is now rendered only for Flash Deals.
- A custom heading silently removed the Explore More link, because the custom
  branch returned before the link was added. Both now render together.

## 1.35.0 - 2026-07-31

### Added
- Glide Speed control for banner sliders (Hero, Promo Banner, Newsletter,
  Footer CTA). Sets how long the slide movement takes, 100-3000ms, default 400.
  Replaces the browser's fixed smooth scroll with an eased animation, which the
  native behaviour gave no way to tune. Reduced-motion visitors still jump.
- Brands can now be entered by hand in the Brands panel. Hand-entered rows
  replace the automatic list, so the section no longer needs a pa_brand or
  zhp_brand taxonomy to show anything.
- Help: new "Section Features" and "Dashboard Status Rows" groups covering
  Explore More, multibanner, auto-rotate, glide speed, per-section carousel,
  the seller-name toggle and the card design setting.

### Fixed
- The Extra CSS box was silently discarded unless the "My HTML Design" box also
  had content, because the only code reading it sat behind that check. It now
  applies to any section.
- Help listed the removed zhp_load_more, zhp_search and zhp_filter endpoints and
  a stale zhpAjax payload. Replaced with the endpoints that actually exist.
- Help troubleshooting no longer refers to the removed Load More, Filters and
  Recently Viewed features.

## 1.34.1 - 2026-07-31

### Changed
- The admin version badge now sits against the right edge of the page header
  instead of hugging the page title, on the Dashboard and Homepage Sections
  screens. Settings and Help already aligned right and are unchanged.

## 1.34.0 - 2026-07-31

### Added
- Multibanner for Hero, Promo Banner, Footer CTA and Newsletter. Each panel now
  holds a repeater; add a second row to turn the section into a swipeable
  carousel using the shared plain (scrollbar-free) track.
- Auto-rotate with an adjustable delay on Hero, Promo Banner and Footer CTA.
  Rotation pauses on hover and stops permanently on any pointer, touch,
  keyboard or scroll interaction, and never starts under reduced motion.
- Newsletter is swipe-only by design: auto-rotating a sign-up form would slide
  the email field away from a visitor part-way through typing.

### Notes
- A section with one banner renders exactly as before. No carousel wrapper,
  no extra markup and no behaviour change reach an unchanged section.
- Existing single banners are read from their original settings keys and shown
  as banner 1 on upgrade. Nothing is migrated, rewritten or overwritten.

## 1.33.0 - 2026-07-31

### Fixed
- Restored the "Explore More" link in section headings. It was dropped in 1.30.0
  during the Load More cleanup, which left the "Explore More size" setting and
  four stylesheets pointing at an element that no longer rendered. Regression.

### Added
- Per-section Explore More URL, label and hide toggle.
- Custom Explore More HTML box, scoped through the same safety pipeline as the
  Custom Header HTML box.
- Empty URL falls back to the WooCommerce shop page.

## 1.32.1 - 2026-07-31

### Changed
- Carousel is opt-in again, per section. 1.32.0 turned it on by default for
  every row-based section; that decision belongs to the site owner, not the
  plugin. Each section starts as a static grid until its own "Horizontal
  swipeable carousel" toggle is switched on.
- The plain, scrollbar-free carousel design from 1.32.0 is unchanged.

## 1.32.0 - 2026-07-31

### Changed
- The carousel scrollbar is hidden. The row still scrolls, swipes and snaps
  exactly as before; only the grey bar under the cards is gone, so the strip
  reads as a plain row. The nav arrows and the partly visible next card are
  the affordance instead.
- Horizontal carousel is now on by default for every section that shows a row
  of items: Categories, Brands, Collections, Featured Sellers and all six
  product sections. Any section already saved keeps whatever you chose, and
  every section can still be switched back to a static grid.

## 1.31.1 - 2026-07-31

### Fixed
- Template Pack detection was wrong. It tested for the engine's
  Template_Manager class, which exists whenever the Product Grid plugin is
  active, with or without the pack. The "Template Pack not detected" note on
  the Settings page could therefore never appear. Detection now asks the card
  registry whether the 'zymarg' card is registered, which only the pack does.
- Sections retired in earlier releases could linger in the saved section order
  and be counted and listed as real sections. Recently Viewed, removed in
  1.31.0, was still being counted in the dashboard total.

### Added
- Dashboard status rows for Product Grid Engine, ZYMARG Template Pack and
  Flash Deals Source, so it is obvious at a glance which pieces are installed.

## 1.31.0 - 2026-07-31

### Changed
- Product rows are now queried by the ZYMARG WC Product Grid engine instead of
  this plugin. Each section sends a source key and the engine returns finished
  cards, so there is one place where product logic lives.
- Section slugs map to engine sources: Featured -> featured, Trending ->
  trending, Best Sellers -> best_selling, New Arrivals -> recent,
  Recommended -> recommended, Flash Deals -> flash_deals.
- Unknown source keys are now rejected before the engine sees them. The engine
  silently substitutes its 'all' source for anything it does not recognise,
  which would have filled a row with unrelated products.
- The Flash Deals countdown counts down to the real soonest sale end among the
  products on screen, read from the engine's zymarg_products filter. It falls
  back to end of day when nothing has a scheduled end.

### Added
- Settings -> Product Card Design -> Card design: choose the branded ZYMARG
  Template Pack card or the engine's default card.
- Per-section 'Show seller name on each card' toggle for the Dokan vendor row.

### Removed
- The Recently Viewed section, including its settings row and defaults.
- ProductQuery and the REST endpoints it backed (/zhp/v1/products and
  /zhp/v1/products/search), which existed only for the Load More, Search and
  Filter handlers removed in 1.30.0.
- 19 unused files: seven per-type query stubs, seven per-type template stubs,
  and the SectionHeader, EmptyState, Badges, Slider and Buttons components.
- Dead product-card, skeleton, badge and Explore More rules from products.css
  (362 lines down to 133).

### Notes
- Flash Deals stays hidden from visitors until the Product Grid plugin adds a
  flash_deals source. Administrators see an explanatory notice in its place.

## 1.30.0 - 2026-07-30

### Removed
- Product card and grid rendering. The ZYMARG WC Product Grid engine already drew every card on the live site; this plugin no longer duplicates that work. Deleted ProductCard, Skeleton and Pagination components.
- Load More, product Filters and product Search AJAX handlers, plus load-more.js and filters.js. Pagination belongs to the engine.
- The "Explore More" control, which was injected by load-more.js.

### Changed
- ProductGrid is now a delegating shell. It is deliberately kept, not deleted, because it is the single place the homepage fires zhp_product_grid_html_pre, which is how the engine is invoked. Its render() signature is unchanged.
- zhpAjax moved from load-more.js to a data-only zhp-runtime handle, so the newsletter nonce and carousel labels survive. The carousel script now depends on it.
- When the engine is absent, not booted or switched off, product rows render an administrator-only "Product engine not connected" notice. Visitors see nothing.

### Kept
- countdown.js and carousel.js, which the engine does not provide.
- The query layer. The homepage still decides which products each section shows and in what order; the engine only decides how each card looks.

## 1.29.0 - 2026-07-30

### Added
- Custom Header HTML is now protected. Pasted markup runs through the same pipeline the full custom-design box uses: the document wrapper is removed, scripts are stripped, and CSS is confined to the section. A pasted preview file can no longer break the homepage layout.
- A reviewer under each header box reports exactly what will be changed, both live while typing and after saving.
- All 7 product sections now expose the Custom Header HTML box. The template already honoured header_html; only the admin field was missing.
- New "Hide section header" checkbox on every section. Removes the heading row only.
- New Help page section, "Custom Code Boxes", documenting what each of the three boxes accepts, the placeholder syntax, and where the code is stored.

### Changed
- render_section_header() accepts a section slug, used to build the CSS scope class.
- ProductSections\Settings::render_settings_fields() accepts the slug so product panels can render the shared header field.

### Fixed
- Header CSS is no longer global. Rules targeting body, html or :root are scoped, and page-level layout properties are dropped.

## 1.28.0 - 2026-07-30

### Collections moved into Homepage > Sections; Banners menu removed

The separate **Banners** menu is gone. Collection cards are now added and edited
in the **Collections** panel on **Homepage > Sections**, alongside every other
section setting.

**Why the menu was wrong**

Of the three banner types it offered, two were pure duplication: Hero and Promo
Banner already had complete settings panels on the Sections screen. Worse, they
were not merely redundant. `BannerQuery::get()` preferred the custom post type
over the settings panels, and `query_cpt()` had no empty-content guard, so a
single blank banner post silently overrode a working panel and blanked the
section. Only Collections genuinely lacked an editor.

**Added**

- Collection cards repeater in the Collections settings panel. Each card takes a
  Title, Image URL, Image Alt Text, Link URL and Link Label, matching the plain
  URL fields used by the Hero and Promo Banner panels.
- Add and Remove buttons for card rows, delegated from the document so rows
  added after page load keep working and the AJAX router can swap the screen.
- `Collections\Settings::items()` normalises saved cards, drops blank rows and
  falls back to the title for a missing alt text. Shared with the front end so
  the editor and the homepage cannot disagree about what counts as a usable card.
- Repeater styling in the admin stylesheet, using the existing brand tokens.

**Fixed**

- Nested settings fields could never be saved. `collectSectionSettings()` in
  `zymarg-drag-drop.js` matched names with a single-level pattern,
  `/^settings\[([^\]]+)\]$/`, which cannot match `settings[items][0][title]`.
  Such names fell through to being stored as one flat literal key, so no
  repeating list could ever have been persisted. Field names are now parsed as a
  bracket path at any depth and rebuilt into real nested arrays.
- Removing a middle card row left a hole in the index sequence, which would have
  reached PHP as a sparse list containing nulls. Lists are now compacted before
  they are sent.
- The repeater's clone template is excluded from collection, so it cannot be
  saved as a blank card on every save.

**Removed**

- The `zhp_banner` custom post type registration and its Banners menu, along
  with `includes/Core/BannerPostType.php`, the banner admin stylesheet
  `assets/css/admin/zymarg-banner.css`, and the banner branch, screen check and
  help panel in `Admin\Assets`.
- `Collections\Feature` no longer calls `BannerQuery`; it reads its own settings.

**Notes**

- `BannerQuery` itself is unchanged and still serves Hero and Promo Banner. Its
  `post_type_exists()` guard is simply false from now on, so both resolve from
  their settings panels, which already hold every field they need.
- Any banner posts created under the old menu become inert. Their content is not
  migrated, because Hero and Promo Banner already have their values in settings
  and Collections had no usable cards to migrate.
- No PHP runtime is available in the build environment, so this release is
  verified by static review only. Activate on staging before production.

## 1.27.0 - 2026-07-30

### Added
- **Brand styling for the Banners screens** — new
  `assets/css/admin/zymarg-banner.css`. The banner list table, the add/edit
  screen, the Banner Details panel, the featured image box and the Publish
  button now use the ZYMARG palette instead of stock WordPress grey.
- **A "How banners work" help panel** on the Banners screens
  (`Admin\Assets::render_banner_help()`, hooked to `admin_notices`). Nothing
  about a stock post editor tells an admin that the title becomes the heading
  or that Banner Type decides which section is fed, so the screen now says so.

### Fixed
- **Admin CSS was never loading on the Banners screens at all.**
  `Admin\Assets::enqueue()` matched on `$_GET['page']` against a list of plugin
  page slugs. The banner screens are core editor screens (`edit.php`,
  `post.php`, `post-new.php`) and carry no `page` argument, so the method
  returned early every time. That is the root cause of the Banners menu looking
  nothing like the rest of the plugin. Screen detection now uses
  `get_current_screen()->post_type`.

### Notes
- Scoping: every rule in the new stylesheet is scoped under
  `body.post-type-zhp_banner`, so nothing can leak into Posts, Pages, Products
  or any other admin screen.
- The main `zymarg-admin.css` is deliberately NOT loaded on these screens. It
  is written against the plugin's own markup (`.zhp-card`, the section manager,
  the AJAX router shell), none of which exists on a core editor screen.
- **These screens still use normal page loads, not the plugin's AJAX
  navigation.** That was a deliberate choice for this release: they are core
  WordPress screens, and routing them through `AjaxRouter` would mean
  reimplementing the post editor. Only the appearance was changed.

## 1.26.1 - 2026-07-30

### Fixed
- **The plugin reported itself as 1.24.0 everywhere.** `ZYMARG_HP_VERSION` in
  `Core/Constants.php` was never bumped past `1.24.0`. The `Version:` header in
  the main plugin file was updated in 1.25.0 and 1.26.0, but that header is only
  read by the WordPress plugins screen. The constant is what the plugin's own
  admin UI prints, and what is appended to every enqueued CSS and JS file as the
  cache-busting query string. Two consequences:
    1. Every admin screen kept showing v1.24.0 after two releases.
    2. Because the cache-buster never changed, browsers and any page cache were
       entitled to keep serving the **1.24.0 copies of the CSS and JS**, so
       style and script changes from 1.25.0 and 1.26.0 could silently fail to
       appear until a hard refresh.
  `Constants.php` documents a six-point release checklist directly above this
  constant; points 2, 3, 4 and 6 had all been skipped.
- **`package.json` still said 1.24.0.**
- **Stale `@version` tags** on every file changed in 1.25.0 and 1.26.0 —
  `CustomSection.php` claimed 1.19.2, `BannerQuery.php` claimed 1.17.0.

## 1.26.0 - 2026-07-30

### Fixed
- **The `zhp_banner` post type never existed.** `BannerQuery` had claimed since
  1.4.0 that this post type was "registered in Phase 5", and guarded its primary
  code path with `post_type_exists( self::POST_TYPE )`. No `register_post_type()`
  call existed anywhere in the plugin, so that branch was permanently dead and
  every request silently fell through to the settings-based fallback. This is
  why the Collections section could never display anything.
- **Section slug was compared against banner type.** The settings fallback
  tested `sanitize_key( $slug ) !== $args['type']`. Hero happened to work
  because its slug and type are both `hero`. Promo Banner (type `promo`, slug
  `promo-banner`) and Collections (type `collection`, slug `collections`) could
  never match.
- **The fallback only understood Hero's field names**, reading `heading` /
  `cta_url` / `cta_label` while the Promo Banner panel saves `title` /
  `link_url` / `link_label`. Field aliasing added.
- **`type` in settings-derived results returned the section slug**, disagreeing
  with the `type` argument the caller had just passed in.

### Added
- **`Core/BannerPostType.php`** — registers the `zhp_banner` post type with a
  Banner Details meta box (type, subtitle, link URL, link label), full nonce and
  capability checks on save, and automatic cache invalidation on save, trash,
  untrash and delete.
- A **Banners** submenu under Homepage.

### Notes
- Collections is intentionally CPT-only. Its settings panel has just `heading`,
  `limit` and `carousel` — no per-item fields — so a settings fallback would
  render a bogus card built from the section heading.
- The post type is registered with `public => false`, so it creates no rewrite
  rules and needs no activation flush.
- **Collections is disabled by default** and must be enabled under
  Homepage > Sections in addition to creating banners.

## 1.25.0 - 2026-07-30

### Fixed
- **Custom Header HTML was destroyed on save** — `header_html` was missing from
  `CustomSection::RAW_KEYS`. Every value pasted into a "Custom Header HTML" box
  was therefore pushed through `sanitize_text_field()` by
  `SectionManager::sanitise_settings()`, which strips all tags. The markup was
  silently wiped on save while the templates that read it were correct all
  along. Four sections had shipped this box since 1.7.0, so the feature had
  never actually worked. Adding the key to `RAW_KEYS` fixes all of them at
  once, and also switches on the header override in
  `ProductSections/Template.php`, which already read the key.
  **Any header HTML entered before this release is gone and must be re-pasted.**
- **Colliding field ids in the admin panel** — The four hand-written header
  boxes built their `id` from `$settings['slug']`, a key that is not present in
  the settings array. All four fell back to `zhp-header-html-section`, so the
  ids collided and the `<label for>` clicked the wrong field. The shared helper
  now builds the id from the real section slug.

### Added
- **Custom Header HTML on all 8 non-product sections** — Hero, Categories,
  Promo Banner, Featured Sellers, Collections, Brands, Newsletter and Footer
  CTA now all offer a header override. Previously only four did.
- **Full custom HTML design on all 8 non-product sections** — Featured Sellers,
  Collections, Brands, Newsletter and Footer CTA gained the `design_source` /
  `custom_html` / `custom_css` path that Hero, Categories and Promo Banner
  already had. Sellers, collections and brands are passed to the author's
  markup as repeating placeholder blocks, so a custom design still renders live
  data.
- **Placeholder hints for the five new sections** — the admin panel now lists
  the available `{{placeholders}}` for sellers, collections, brands, newsletter
  and footer CTA, including the loop syntax.

### Changed
- **One shared implementation for the header row** —
  `CustomSection::render_header_field()` renders the admin box and
  `CustomSection::render_section_header()` renders the front-end row. The four
  duplicated copies in Categories, Brands, Collections and Featured Sellers
  have been removed. The field name is unchanged (`settings[header_html]`), so
  no saved data is affected, and the emitted markup is byte-identical, so there
  is no visual change.
- **Custom designs no longer vanish when a query returns nothing** — In
  Featured Sellers, Collections and Brands the `CustomSection::is_active()`
  check now runs *before* the `empty( $data )` guard, matching the pattern Promo
  Banner already used. A hand-written design may be entirely static, and it
  should not disappear because Dokan is inactive or no brand taxonomy exists.
  The built-in markup still bails on empty data, exactly as before.
- **Promo Banner accepts a header-only banner** — the "needs an image or a
  title" guard now also counts custom header markup as content.

### Notes
- Hero, Promo Banner, Newsletter and Footer CTA keep their header override
  inline rather than calling `render_section_header()`, because their headings
  live in section-specific wrappers (`.zhp-hero__content`,
  `.zhp-promo-banner__overlay`, `.zhp-newsletter__copy`,
  `.zhp-footer-cta__copy`) rather than the shared `.zhp-section-header` row.
  Emitting the shared row there would land outside their CSS.
- The 7 product sections were deliberately left untouched in this release. They
  gain the header override for free through the `RAW_KEYS` fix. Slimming their
  query, card and AJAX logic in favour of the product grid engine is planned
  separately.
- No PHP runtime is available in the build environment; this release was
  verified by static reading and grep checks only.

## 1.24.0 - 2026-07-30

### Fixed
- **Single token source** — The full PHP constants table in `Constants.php`
  had zero callers across the entire plugin. All token constants except
  `ZHP_COLOR_PRIMARY` (still needed for PHP inline styles) have been removed.
  `zymarg-tokens.css` is now the only place design values are defined.
- **Help page wrong colours** — The Design Tokens code example on the Help
  page showed `#36003D` as the primary colour and `#FF6B00` as the accent.
  Both were wrong. Corrected to match `zymarg-tokens.css` exactly: primary
  `#9500A5`, secondary `#BD00D1`, accent `#FEA9FF`, dark `#36003D`.
- **Settings schema out of sync** — `Plugin.php` seeded only 4 of 7 settings
  on first activation. The 3 missing keys (`use_product_grid_cards`,
  `section_title_size`, `explore_link_size`) now seed correctly, so a fresh
  install has a complete settings row in the database from day one.

### Added
- **Menu brand colour** — The "Homepage" label in the WordPress sidebar now
  renders in brand purple (`#9500A5`, semi-bold). A small `<style>` block is
  output on `admin_head` (runs on every admin page) so the colour appears
  whenever an admin user is logged in, not only on plugin pages.
- **Theme template override** — `Renderer.php` now checks the active theme
  for `zymarg-homepage/homepage.php` before falling back to the plugin's own
  template. Place that file in your child theme to customise the page wrapper
  without editing plugin files; the customisation will survive plugin updates.

### Notes
- No JS or CSS changes in this release; the build reported 0 stale assets.
- PHP verified by reading and by `audit_regex.py` (0 problems). No PHP runtime
  available.
- `ZHP_COLOR_PRIMARY` is the only colour constant remaining in PHP. Any PHP
  code that needs a token value should use this constant; everything else
  should use a CSS custom property.

## 1.21.0 - 2026-07-30

### Changed
- The pagination control under each product row has moved into that section's
  heading, right-aligned on the same line as the title, and now reads
  "Explore More →" instead of "Load More". Its behaviour is unchanged: it still
  appends the next batch of products in place.
- On screens narrower than 480px the control drops onto its own line below the
  heading and aligns left, because a single right-aligned control beneath a
  left-aligned heading reads as a layout error.

### Added
- Two text-size settings under Settings → Text Sizes: "Section heading size"
  (14–48px) and "Explore More size" (10–24px). Both default to 0, meaning
  automatic, which leaves the existing responsive `clamp()` in charge so the
  text keeps scaling with the viewport. A value is emitted as a CSS custom
  property on `:root` only when it is set.
- New localised string `exploreMore` on the `zhpAjax` object. The old
  `loadMore` string is retained: it is part of a public contract that
  third-party code may read, so removing it would be a breaking change.

### Notes
- Two files build this control — `load-more.js` on first render and
  `filters.js` after a filter changes the result set. Both were updated;
  either one can be the first to create the button, so their markup must stay
  in step.
- Size bounds are enforced twice, in the save handler and again before the CSS
  is emitted, because the option can also be written by WP-CLI or a migration
  without passing through the settings form.
- Unchanged from 1.20.0: this release was verified by reading and by the asset
  build, not by executing PHP. No PHP runtime was available.

## 1.20.0 - 2026-07-30

Third slice of the design overhaul: loading states, colour discipline and
landmarks.

An audit was run first, and it changed the scope of this slice considerably. Two
of its three intended areas turned out to be substantially complete already, so
this release is smaller than planned and says so rather than inventing work.

### Added - skeleton placeholders while a product batch loads

Pressing **Load More** previously disabled the button and changed its text to
"Loading…". Nothing else happened until the cards arrived, so on a slow
connection the page looked inert, and when the batch did land the grid grew
abruptly.

The grid now fills with placeholder cards for the duration of the request.

- The placeholder mirrors `.zhp-product-card` exactly — same surface, radius,
  shadow, 1:1 image ratio, body padding. This is the entire point: a placeholder
  of a different size makes the page jump when the real cards replace it, which
  is worse than showing nothing.
- One placeholder per product still expected, so the grid grows once, up front,
  to the size it is about to become.
- `aria-busy="true"` is set on the grid while the request is in flight, and the
  placeholders themselves are `aria-hidden`. The button already announces
  "Loading…"; a screen reader has no use for a dozen empty grey boxes.
- The shimmer is a single animated `background-position` on each grey block — no
  moving pseudo-elements, nothing on the layout path.
- Under `prefers-reduced-motion: reduce` the animation is dropped entirely and
  the blocks are painted flat. They still read as "loading" from shape alone.
- Placeholders are cleared before anything is measured or inserted, so they can
  never be counted as real cards by the offset logic, and they are cleared on
  network failure too — a dropped connection must not leave the grid shimmering
  with no way to retry.
- Removal searches the whole `<section>`, not the grid captured before the
  request. In `replace` mode the server returns a brand-new grid and the old one
  is discarded, so a grid-scoped query would miss placeholders still on the page.

Built in JavaScript rather than through the PHP `Skeleton` component, because a
placeholder must appear the instant the button is pressed, before any request is
made. Server-rendering it would mean shipping markup on every page load that is
hidden virtually all of the time. `Components/Skeleton/Skeleton.php` therefore
remains an unimplemented stub, and is now redundant.

### Fixed - the one hard-coded colour in the front-end stylesheets

`zymarg-tokens.css` states that no stylesheet may hard-code a hex value. An
audit of all ten front-end stylesheets found exactly one violation:
`carousel.css` painted the arrow hover state `#FFFFFF` directly. It now uses
`var(--zhp-color-surface)`, which is the same colour today and will track the
token if it ever changes.

No other colour work was needed. `--zhp-color-accent` is referenced twice in the
whole plugin — its own declaration and one focus outline — so the "colour
restraint" concern that prompted this slice does not exist in the current code.

### Changed - removed a redundant and a misleading landmark attribute

`templates/homepage.php` rendered `<main role="main" aria-label="ZYMARG
Homepage">`. Both attributes were removed.

- `role="main"` is what `<main>` already exposes. A redundant role is not
  belt-and-braces; it is what causes two main landmarks to be reported when the
  active theme outputs its own `<main>`.
- The `aria-label` named this landmark after the plugin, so screen reader users
  heard a brand name as the name of the page's main region. An unlabelled
  `<main>` is announced as "main", which is correct and matches what a sighted
  visitor perceives.

Every feature section was already a correctly-formed region: `<section>` with
`aria-labelledby` pointing at a real `<h2>` (or the `<h1>` in the Hero), with
`role="list"` / `role="listitem"` on card collections. That work landed in
earlier phases, so no further landmark changes were warranted.

### Note

No PHP runtime is available here, so the two PHP-side changes are verified by
static analysis and by rebuild/drift checks only, never executed.

## 1.19.2 - 2026-07-30

### Fixed - custom section designs rendered as nothing (critical)

A pasted HTML design saved correctly, passed every activation check, and then
rendered as an empty section while emitting:

    Warning: preg_replace(): Unknown modifier '/' in .../CustomSection.php on line 336

The pattern that clears unused `{{placeholder}}` tags was written as
`'#\{\{[#/]?[a-z0-9_\-]*\}\}#i'`. `#` is the pattern delimiter, and PHP ends the
pattern at the first unescaped `#` **even inside a character class** — so the
pattern terminated at `[#`, and the `/` that followed was read as a modifier
flag. `preg_replace()` then returned `null`, and `(string) null` is `''`, so the
final step of the render pipeline discarded the entire design.

This is why the failure was so confusing: nothing was wrong with the pasted
file, the Design Source setting, or the save path. The markup was built
correctly and thrown away on the last line.

Two changes:

- The `#` inside the character class is now escaped, with a comment recording
  why it must stay that way.
- A `null` result from that `preg_replace()` no longer destroys the markup. It
  now falls back to the unstripped HTML, so any future regex failure shows the
  design with a stray `{{placeholder}}` visible instead of a blank section that
  gives no clue what broke.

All 21 regex literals in the codebase were audited for the same delimiter
collision. This was the only occurrence.

### Fixed - "Saving\u2026" shown on the save button

The save button displayed the literal text `Saving\u2026` instead of `Saving…`.

Three strings in `Admin/Assets.php` were written as `__( 'Saving\u2026' )` in
single quotes. PHP does not process `\u` escapes in single-quoted strings at all,
so the six characters were passed through verbatim. The identical text in the
JavaScript fallbacks was always correct, because `\u2026` *is* a valid escape in
a JavaScript string literal — which is why the two looked the same in the source
but only one of them worked. The PHP value is the one that reaches the button.

Replaced with a literal `…` in all three places: the settings save button, the
sections save button, and the router loading text.

### Note

No change to the section manager, the AJAX router, or any front-end template.
Still unverified by execution: there is no PHP runtime available here, so both
fixes are verified by static analysis only.

## 1.19.1 - 2026-07-30

### Added - reorder sections without a mouse

Each row in the section manager now has a **Move up** / **Move down** button
pair beside its settings button.

This is not a convenience alternative to dragging. jQuery UI Sortable binds
`mousedown` / `mousemove` / `mouseup` only, and WordPress bundles no touch
shim for it, so the drag handle has never functioned on a phone or tablet in
any version of this plugin. On a touch device the section order was simply not
editable. The same gap applied to keyboard and screen reader users, who had no
reorder path at all.

The buttons reorder the same list through the same save path:

- The row element is relocated rather than having its contents copied, so an
  expanded settings panel, any unsaved field values and the toggle state all
  travel with the row.
- `collectSections()` already derives order from document position, so no
  separate order bookkeeping was needed and the AJAX save contract is
  unchanged.
- Nothing is persisted on press. The new order is staged in the DOM and written
  only when **Save Changes** is pressed, matching drag behaviour exactly, so a
  mis-tap is undone by leaving the screen without saving.

### Notes on details that are easy to get wrong

- The up button on the first row and the down button on the last are disabled,
  so neither can be pressed into a no-op. That state is recalculated after every
  move, after every drag, and after every AJAX screen swap — not rendered in PHP,
  because it is only correct at one moment in time.
- Moving a focused element in the DOM drops focus in some browsers, which would
  strand a keyboard user mid-list. Focus is restored to the same button so
  repeated presses keep working, and falls back to the partner button when the
  pressed one has just become disabled at an end of the list.
- The moved row flashes briefly and is scrolled into view. On a phone the rest
  of a 15-row list is off screen, so without this a press has no visible result.
- The click handler is bound to the document rather than to the buttons, for the
  same reason Save and Reset are: an AJAX screen swap replaces every row.
- On screens below 782px the drag handle is dimmed, since it cannot work there.
  It is kept rather than hidden so the layout does not shift between viewports.

Dragging is unchanged on desktop. The Sortable `update` callback now also
refreshes the button states, because a drag changes which rows are first and
last.

### Note

This release touches the section manager admin screen only — markup, admin CSS
and the drag-drop script. No front-end file, query, template or save handler was
modified. 1.18.0 remains pending test.

## 1.19.0 - 2026-07-29

### Added - AJAX admin navigation

- The plugin's four admin screens (Dashboard, Homepage, Settings, Help) now load
  in place. Clicking a submenu item fetches the screen over `admin-ajax.php` and
  swaps the content without a full WordPress page load.
- New `Admin\AjaxRouter` serves the screens via the `zhp_admin_page` action. It
  reuses the existing page classes and captures their output, so there is only
  one rendering path and the AJAX response is identical to a normal page load.
- The router enforces the same access rules as a normal admin page: a nonce, a
  `manage_options` capability check, and a slug allowlist so the action can only
  ever render this plugin's own four screens.
- Browser URL, tab title, submenu highlight, and Back/Forward all stay in sync.
- Focus moves to the new screen's heading after a swap for keyboard and screen
  reader users.
- New `assets/js/admin/zymarg-admin-router.js`.

### Changed - admin scripts survive a screen swap

- `zymarg-drag-drop.js` now re-attaches jQuery UI Sortable on the new nodes and
  binds its Save and Reset buttons to the document, so the section manager keeps
  working when reached without a page load.
- The dashboard status check re-runs after a swap instead of only on first load.
- The drag-and-drop script is now enqueued on all four plugin admin screens
  rather than only the section manager, because `admin_enqueue_scripts` does not
  run again during AJAX navigation.

### Notes

- Only this plugin's screens are intercepted. Every other wp-admin link is left
  untouched.
- Any failure - expired nonce, PHP error, dropped connection - falls back to a
  normal page load rather than showing an error, so a click always arrives
  somewhere useful.
- Ctrl/Cmd/Shift/middle clicks and links with a target still open normally.

## 1.18.0 - 2026-07-29

### Added - per-section custom HTML designs

The Hero, Category Showcase and Promo Banner sections each gained a **Design
Source** dropdown in their admin panel: *Plugin default design* or *My own HTML
design*. Choosing the latter reveals a code box and an optional extra CSS box.

Each section is independent. The hero can run a hand-written design while the
category showcase keeps the built-in one. Switching back to the default takes one
dropdown change and does not delete the pasted code, so designs can be compared
and reverted freely.

The code box expects a **complete standalone HTML document** — the kind of file a
developer hands over, which opens and works on its own in a browser. That is the
easiest thing for a human to write and preview, but a whole document cannot be
dropped into the middle of a page unchanged, so `Core/CustomSection.php`
translates rather than merely accepting it:

- **The document wrapper is removed.** `<!DOCTYPE>`, `<html>`, `<head>`,
  `<body>`, `<meta>` and `<title>` carry no meaning inside a page. Stylesheet
  and preconnect `<link>` tags found in the head are preserved, because a design
  that loads its webfont or icon set that way would otherwise break silently.
- **Every CSS selector is confined to the section.** A rule for `.avatar` becomes
  `.zhp-custom--hero .avatar`, so generic class names cannot collide with the
  theme or another plugin.
- **A universal reset is contained.** `* { margin: 0 }` in a standalone file is
  normal and correct; dropped into a live page it would strip the margins from
  the theme's header, menu and footer. It is rewritten to apply only inside the
  section.
- **`html` / `body` rules are retargeted, and the destructive parts dropped.**
  Inside a standalone file `body` is the outermost box of the design, so those
  rules move onto the section wrapper — except for `overflow`, `height`,
  `display`, `position`, `margin`, `padding` and their relatives.
  `body { overflow: hidden; height: 100dvh; display: flex }` is common in a
  standalone layout and would otherwise stop the whole page from scrolling,
  making everything below the fold unreachable. Custom properties are always
  kept: they do nothing until something uses them.
- **`:root` is retargeted to the wrapper**, so a design's design-token block
  works inside the section without leaking its variables site-wide.
- `@media`, `@supports`, `@container` and `@layer` are recursed into and their
  contents scoped. `@keyframes` and `@font-face` are passed through untouched,
  because their bodies are not selector lists and prefixing them would break the
  rule.

CSS scoping is a brace-counting walk rather than a regular expression, because
nested at-rules cannot be matched reliably with one.

### Added - live data placeholders

Pasted markup would otherwise be frozen content. Placeholders let a custom design
keep using real data:

- Hero: `{{heading}}`, `{{subheading}}`, `{{cta_label}}`, `{{cta_url}}`,
  `{{bg_image}}`
- Promo Banner: `{{title}}`, `{{image_url}}`, `{{alt_text}}`, `{{link_url}}`,
  `{{link_label}}`
- Category Showcase: `{{heading}}`, plus a repeating block
  `{{#categories}} … {{/categories}}` exposing `{{name}}`, `{{url}}`,
  `{{image_url}}`, `{{image_alt}}`, `{{count}}`, `{{slug}}`, `{{description}}`
  and `{{id}}` per row.

Values are escaped by key name: anything ending in `url`, `link`, `permalink` or
`src` goes through `esc_url()`, everything else through `esc_attr()`.
`esc_attr()` rather than `esc_html()` because a placeholder is as likely to sit
inside an attribute as in text, and it renders correctly in both. Placeholders
with no matching value are removed, so a typo such as `{{headding}}` does not
appear on the front end.

### Changed - section settings are no longer blanket text-sanitised

`SectionManager::sanitise_settings()` ran every scalar through
`sanitize_text_field()`, which strips tags. Pasted HTML would have been destroyed
the moment Save was pressed. `custom_html` and `custom_css` are now stored
verbatim, listed on `CustomSection::RAW_KEYS`; every other key is sanitised
exactly as before. Only users who pass the existing `manage_options` check in
`DragDrop::handle_save()` can reach that code path.

### Notes on scripts

`<script>` tags and inline `onclick` handlers are **kept**. Real handed-over
designs are interactive, and stripping scripts would have delivered designs that
look correct and do nothing. Saving here already requires the capability to
install plugins — anyone able to abuse it can already upload PHP — so forbidding
scripts would prevent nothing while breaking the intended use. Filter
`zhp_custom_section_allow_scripts` to `false` to strip them anyway.

## 1.17.0 - 2026-07-29

Second slice of the design overhaul: the hero's Largest Contentful Paint.

### Changed - the hero image is a real `<img>`, not a CSS background

`Features/Hero/Template.php` emitted the image as an inline
`style="background-image: url(...)"` on the `<section>`. That carried three
costs that cannot be worked around while it stays a background:

- The browser's preload scanner cannot discover a background image until the
  stylesheet has loaded and the element has been matched, so the single most
  important image on the page started downloading late.
- A background image cannot carry `fetchpriority="high"`.
- A background image cannot have a `srcset`, so phones downloaded the full
  desktop file.

The hero now renders `<img class="zhp-hero__bg">` with `fetchpriority="high"`,
`loading="eager"` and `decoding="async"`. `loading="eager"` is set explicitly
because `wp_get_attachment_image()` defaults to `lazy`, and lazy-loading the LCP
element is actively harmful.

The image is decorative — the `<h1>` carries the meaning — so it takes an empty
`alt` and `aria-hidden="true"` rather than duplicating the heading for screen
reader users.

`srcset` requires an attachment ID, and the admin panel only stores a URL
string, so the template resolves one via `attachment_url_to_postid()`. That is a
database query and the hero renders on every homepage view, so the result is
cached for a day — including the `0` result, so an external URL is not
re-queried on every page load. External and CDN-hosted URLs still get eager,
high-priority loading; WordPress simply cannot generate a `srcset` for them.

### Added - `image_id` in the BannerQuery return shape

`BannerQuery::hydrate_posts()` already looked up `get_post_thumbnail_id()` and
then discarded it, so consumers had no way to build a `srcset` without
re-resolving the ID from the URL. It is now returned as `image_id` (`0` for
settings-based entries, which only ever store a URL).

### Fixed - Hero images were invisible to the BannerQuery settings fallback

The settings fallback read `$settings['image_url']`, but the Hero settings panel
saves its field as `settings[bg_image]`. PromoBanner does use `image_url`, so
this affected the Hero only. Two consequences: a Hero configured through
settings never contributed an image to the banner data, and a Hero with an image
but no heading was skipped by the "title or image" guard entirely. The fallback
now accepts either key.

This was latent rather than visible, because `Hero/Template.php` reads
`$settings['bg_image']` directly and only consults the query as a fallback.

### Changed - hero stacking is now explicit

With the image as a real element rather than a background paint, the overlay and
content need declared order: image `z-index: 0`, overlay `1`, content `2`. The
now-dead `background-size` / `background-position` pair was removed; the
gradient remains as the paint behind the image and as the whole hero when no
image is set.

## 1.16.1 - 2026-07-29

### Fixed - buttons and inputs now use the theme's typeface

`--zhp-font-family` declared `'Inter Variable', ui-sans-serif, system-ui,
sans-serif`, but nothing in this plugin ever loaded that font. Two consequences:

- `'Inter Variable'` is the `@fontsource` package name. A theme that loads Inter
  from Google Fonts registers the family as plain `Inter`, so even on a site
  where Inter is present the first entry in that stack could not match and
  everything fell through to `system-ui`.
- The token is applied only to `.zhp-btn-primary`, `.zhp-btn-secondary` and
  `.zhp-input`. Form controls do not inherit `font-family` from the page by
  default, so those three components were pinned to a hard-coded stack while the
  rest of the homepage used the theme's font.

The token is now `inherit`, so the plugin's buttons and inputs pick up whatever
typeface the active theme provides. This is the intended behaviour for a plugin
that does not own the typography.

`ZHP_FONT_FAMILY` in `includes/Core/Constants.php` still holds the old string.
It has no consumers anywhere in the plugin and is left untouched in this patch.

## 1.16.0 - 2026-07-29

First slice of the design overhaul: the typography and spacing foundation.
Deliberately shipped as a minor release rather than 2.0.0, because 2.0.0 is
reserved for the completed overhaul and this changes tokens only — no markup,
no PHP, no JavaScript.

### Added - fluid display type

- `--zhp-font-size-xxl`, `-xl` and `-lg` are now `clamp()` values that scale with
  the viewport. The hero heading was previously fixed at 30px on desktop and
  24px on mobile, which is small for a headline on a wide screen; it now runs up
  to 52px and still lands at 30px on a phone.
- Body and UI sizes (`-md` and below) are intentionally still fixed. Scaling
  reading text with the viewport hurts legibility and would distort card layout.
- Because the clamps cover the small-screen case, the now-redundant heading size
  overrides were removed from the `hero.css` and `products.css` media queries.

### Added - line-height and tracking tokens

- `--zhp-leading-flat` / `-display` / `-heading` / `-snug` / `-body`. There were
  no line-height tokens at all before, so every stylesheet hard-coded its own
  and the same kind of text was set at 1.2, 1.3 and 1.4 in different sections.
- `--zhp-tracking-tight` (-0.02em) and `--zhp-tracking-flat`.
- `--zhp-letter-spacing-normal` keeps its existing 0.08em value despite the
  misleading name, because the badge component depends on it. The name is now
  documented in place rather than changed.

### Added - vertical rhythm

- `--zhp-section-y: clamp(48px, 7vw, 104px)` and `--zhp-section-y-tight`.
  `.zhp-section` was a flat 48px band at every viewport, which made every
  section feel equally weighted and cramped on wide screens.
- Adjacent sections now use the tighter value for their top padding, so two
  consecutive bands no longer stack into one oversized gap.

### Fixed

- The hero heading used `--zhp-letter-spacing-normal` (0.08em). Wide positive
  tracking on large bold display type reads as loose and unintentional; it now
  uses the tight tracking token.
- The shared `.zhp-card-image` rule set `object-fit` and the hover `transform`
  on the wrapping `<a>` rather than on the image inside it. `object-fit` has no
  effect on an anchor, and the hover scale enlarged the whole box including its
  rounded corners. Both now target the child image. In practice this rule was
  dormant — the only consumer, the product card, already overrides it in
  `products.css` — so this is a correctness fix to a shared rule, not a visible
  change to the product grid.
- Long headings use `text-wrap: balance` and the hero sub-heading `text-wrap:
  pretty` with a 46ch measure, to stop single orphaned words on the last line.

## 1.15.0 - 2026-07-29

### Fixed - Load More and filters work when the Product Grid engine draws the cards

1.14.0 handed card rendering to the ZYMARG WC Product Grid engine, but only on
the initial page render. Both AJAX paths still assumed this plugin's own markup,
which would have broken them outright once the engine was active:

- `load-more.js` counted the existing cards with `.zhp-product-card` to work out
  the offset. Engine cards do not carry that class, so the count was `0`, the
  `offset < limit` test passed, and the Load More button was **never injected**.
- `filters.js` looked for `.zhp-product-grid` and returned early when it was
  absent, so category, sort and price filtering **silently did nothing**.
- `LoadMore.php` and `Filters.php` both called `ProductCard::render_many()`
  directly, bypassing `zhp_product_grid_html_pre`. Had the two points above been
  fixed alone, a row would have mixed engine cards with homepage cards.

### Added - a stable grid hook, and a render mode in the AJAX contract

- Every product grid now carries `data-zhp-grid`, whoever rendered it. Engine
  output is always wrapped in a `.zhp-grid-host` element owned by this plugin,
  rather than relying on the engine's class names, which its own documentation
  excludes from the public contract.
- AJAX responses now include `mode`. `append`/`inner` keeps the existing
  behaviour of injecting card fragments. `replace` means the payload is one
  complete grid element and the client swaps the grid itself.
- `replace` is used when the engine owns the cards, because its only public
  entry point renders a whole grid — single cards cannot be produced, so they
  cannot be appended. In that mode Load More re-renders the cumulative set
  (`0` to `offset + limit`) and `has_more` is derived from the new batch size.
- Both scripts post a `carousel` flag so a replaced grid keeps its carousel
  wrapper classes, and both call `zhpCarousel.refresh( section )` afterwards,
  which is what makes a freshly swapped grid swipeable.
- `filters.js` reassigns its `grid` reference after a swap, and `load-more.js`
  re-resolves the grid on every click, so neither holds a detached element.

### Changed

- `ProductGrid::render()` emits `data-zhp-grid` on its wrapper.
- `Filters::render_cards()` takes a third `$is_carousel` argument and renders a
  full grid when the bridge is active, falling back to card fragments otherwise.
- If the engine is expected but returns nothing, both handlers fall back to
  homepage cards for the whole set and still report `replace`, since the payload
  is a full grid either way.

## 1.14.1 - 2026-07-29

### Fixed - carousels now re-measure after AJAX injects cards

- `assets/js/frontend/load-more.js` and `assets/js/frontend/filters.js` now call
  `window.zhpCarousel.refresh()` after injecting markup. Neither did before, even
  though `carousel.js` exposes `refresh()` for exactly this purpose and its own
  comment says these two scripts should call it. Nothing re-measured a carousel
  after its contents changed.
- Why it mattered in "Load more": appending cards grows the track's `scrollWidth`
  but not the track's own box, so the `ResizeObserver` in `carousel.js` never
  fires. The next/prev arrows kept the enabled/disabled state from before the
  append, so "next" could sit disabled with more products to scroll to.
- Why it mattered in filter/sort: the track element is reused and keeps its
  `zhpCarouselReady` flag, so re-initialising is skipped, and the arrows kept the
  scroll state of the previous, unfiltered result set.
- `load-more.js` calls `refresh()` with no argument, because `fetchMore()` only
  receives `btn` and `grid`, and `grid` is the track itself, which cannot contain
  itself. `filters.js` scopes the call to its `section`.
- Both call sites are feature-detected, so a page that loads the AJAX scripts
  without `carousel.js` is unaffected.

## 1.14.0 - 2026-07-29

### Added - optional Product Grid card rendering, with automatic fallback

The site can now show a single product card design everywhere. When the ZYMARG
WC Product Grid plugin is installed and running, it draws the homepage product
rows; otherwise the homepage draws its own. No configuration is required for
either state.

**New: `includes/Integration/ProductGridBridge.php`**

Hooks `zhp_product_grid_html_pre` (added in 1.13.0) and hands rendering to the
engine's `Public_API::render()`. The homepage still chooses and orders the
products - real `WC_Product` objects are passed in, so the engine skips its own
query entirely and only decides how each card looks. Section headings,
carousels, load-more, filters, caching and admin toggles all stay with the
homepage.

**Detection asks whether the engine booted, not whether it is installed.**

This distinction matters and is the reason a naive check would ship broken
rows. The engine gates its own start-up on a compatibility test, and when that
test fails it returns early *before* initialising its API bootstrap. In that
state every class is loaded and `class_exists()` passes, but
`Public_API::render()` returns an empty string. So the bridge asks the engine
itself, via `Api_Bootstrap::is_initialized()` - the same flag the engine's own
render path consults.

**Every failure returns `null`, meaning "homepage renders normally":**

- engine absent, or missing an expected class or method
- engine present but not booted
- admin toggle off
- no resolvable WooCommerce products (a deleted product is skipped, not fatal)
- engine returns an empty string or its hide-widget sentinel
- engine throws anything at all (wrapped in `try`/`catch \Throwable`, despite
  the engine documenting that it never throws - a bridge should not depend on
  another plugin honouring its own contract)

**New setting: Product Card Design.** A toggle on the Settings screen, defaulted
to on, so installing the engine later switches the site over with no settings
visit. The row also reports live status: whether the engine was detected, and
which card is currently in use.

**Carousels keep working with engine markup.** The carousel needs the element
that directly contains the cards to be the scroll track, but the engine emits
its own grid wrapper this plugin cannot add attributes to. Engine output is
therefore wrapped in a host element, and `carousel.js` promotes the host's
first child to a track at run time - reusing the existing carousel CSS, arrows
and keyboard behaviour rather than duplicating them.

**New filters**

- `zhp_use_product_grid_cards` - force the bridge on or off in code.
- `zhp_product_grid_engine_config` - adjust the config sent to the engine
  (card template, columns, which card elements show) without editing this
  plugin.

### Note

The engine's cards draw their icons with Font Awesome, which Elementor
normally supplies. On a site without Elementor those buttons still work and
stay accessible, but render no glyph until a font is provided or a card
template using inline SVG is registered. This affects the engine's card only,
never the homepage's own card.

## 1.13.0 - 2026-07-29

### Added - one shared product card, and hooks for third-party card rendering

Product card markup existed in three hand-copied places, each exercised by a
different user action, so drift between them was invisible in code review and
only showed up on the live site:

1. `Features/ProductSections/Template.php` - initial page render
2. `Ajax/LoadMore.php` - the "Load more" button
3. `Ajax/Filters.php` - price filter and sort changes

The `Components/ProductCard`, `Components/ProductGrid` and `Components/Badges`
classes had been scaffolded in 1.8.0 but their `render()` methods returned an
empty string and were marked `@todo Phase 8`. They are now implemented, and all
three call sites delegate to them. Card markup lives in exactly one file.

Four filters make the card and grid replaceable by another plugin, which is the
supported way to hand rendering to a dedicated product-grid plugin while this
plugin keeps querying, caching, per-section admin settings and the carousel:

- `zhp_product_card_html_pre` - return a string to replace a single card
- `zhp_product_card_html` - adjust the finished card markup
- `zhp_product_grid_html_pre` - return a string to replace the whole grid
- `zhp_product_grid_html` - adjust the finished grid markup

### Fixed - filtering a section changed its badges

`Ajax/Filters.php` re-derived the badge with its own inline priority chain
which, unlike `ProductQuery::resolve_badge()`, did not treat a flash-deals row
as a sale. Applying a price filter or changing the sort order on Flash Deals
therefore silently relabelled every card. Badge resolution now mirrors the
query exactly.

### Fixed - product names containing & or ' displayed as escaped entities

`ProductQuery::hydrate()` pre-escaped `title`, `permalink`, `image_alt`, `sku`
and the price strings, and every template then escaped them a second time. A
product named "Tom & Jerry" was encoded to `Tom &amp; Jerry` and then to
`Tom &amp;amp; Jerry`, so shoppers saw the literal text "Tom &amp; Jerry". The
same double-encoded values were served over the REST API.

Hydration now returns raw values and escaping happens once, at output. If you
consume `/wp-json/zhp/v1/products` and were compensating for double-encoded
fields, that workaround is no longer needed.

### Fixed - other drift between the three copies

- The filter response used the product name as image `alt` text; the other two
  used the real attachment alt text. All three now use the attachment alt text
  and fall back to the product name.
- Two copies guarded `review_count` with `?? 0`; the section template did not,
  emitting an undefined-key warning for products with no reviews.
- Only one copy passed the badge through `sanitize_html_class()`.

### Changed - badge labels are now translatable

All three copies built the label with `ucfirst( $type )`, which produced "Sale"
and "Hot" in English regardless of locale. `Badges` now uses a translatable
label map.

## 1.12.0 - 2026-07-29

### Added - a real build step for minified assets

Every `.min.css` and `.min.js` in this plugin was previously maintained by
hand. WordPress serves the `.min` twin in production and the plain source only
when `SCRIPT_DEBUG` is enabled, so any divergence between the two produced
bugs that were invisible during development and broke only live sites.

Three such bugs shipped in a single release cycle:

1. `.min` twins that did not exist at all, producing silent 404s.
2. `zymarg-drag-drop.min.js` used the selector `.zhp-section-settings[name]`
   where the source correctly used `.zhp-section-settings [name]`. The missing
   space meant no per-section setting ever saved in production.
3. `zymarg-admin.min.css` had a comment whose opening `/*` was lost, leaving
   roughly 200 characters of prose in the stylesheet as live tokens.

`tools/build.mjs` now generates all 19 minified assets from their sources, so
this class of bug is structurally impossible. Usage:

    npm run build      # regenerate every .min asset
    npm run check      # exit non-zero if any .min file is stale (for CI)
    npm run build:dry  # preview, and report hand-edits that would be lost

**Never edit a `.min` file again.** Edit the source and run `npm run build`.

The tool has zero dependencies so it runs on a bare Node install with no
network access. Its minifier is therefore deliberately conservative: for CSS,
comments and whitespace only, preserving the space in selectors like
`.wrap :focus` where it is semantically significant; for JS, comments and
indentation only, preserving every newline so Automatic Semicolon Insertion
behaviour cannot change. This gives up some compression in exchange for being
unable to corrupt the program. Total asset weight still drops 35%, from 99,700
to 64,715 bytes. To compress harder, install `terser` and `clean-css` and swap
the two `minify*` functions; discovery and drift detection stay as they are.

All 14 JavaScript files, sources and generated output alike, are verified with
`node --check`.

### Fixed - a missing minified file silently removed a section's styling

All nine `Features/*/Assets.php` classes tested `file_exists()` against the
**minified** path and, when it failed, skipped the enqueue entirely instead of
falling back to the source file. A stylesheet shipped without a hand-written
`.min` twin therefore caused that section to render with no CSS at all, rather
than merely unminified CSS. `carousel.css` and `carousel.js` had no twins and
only worked because they were routed through a separate one-off helper.

### Changed - one asset resolver replaces twelve copies of the same idiom

Twelve classes each carried their own copy of:

    $this->min = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';

and appended the result straight onto a path. That logic now lives once, in
`ZYMARGHomepage\Core\AssetPath`, which resolves the best available variant of
an asset: the built file when it exists, the source when it does not, and an
empty string only when neither is present, so a caller can never enqueue a URL
that 404s. Results are memoised per request.

The superseded `Core\Assets::asset_suffix()` helper was removed, along with the
now-redundant `$min` properties and the constructors that existed only to set
them. Twenty call sites were converted.

## 1.11.2 - 2026-07-29

### Changed - version badge moved beside the page title

The `v1.11.2` badge previously sat inside `.zhp-admin-header__actions`,
the same flex container as the Reset to Defaults and Save Changes buttons,
so it read as a third item in the button group. Below 782px this got worse:
that container becomes `width: 100%` and `.zhp-admin-btn` gets `flex: 1`,
leaving the badge wedged between two stretched buttons.

The badge now sits on a `.zhp-admin-header__titlerow` flex line next to the
"Homepage Sections" heading, above the hint text. The actions container now
holds only the two buttons.

### Fixed - broken comment in the minified admin stylesheet

`assets/css/admin/zymarg-admin.min.css` contained a comment whose opening
`/*` had been lost, leaving roughly 200 characters of prose ("Settings.php
emits bare <label> ...") sitting in the stylesheet as live tokens ahead of
an orphaned `*/`. Browsers recover from this, but recovery means discarding
tokens until the parser resynchronises, which put the rules immediately
afterwards at risk. Restored the opening delimiter.

This is the third defect this cycle traced to a hand-maintained minified
file drifting from its source. A real build step is strongly recommended.

## 1.11.1 - 2026-07-29

### Fixed - critical: per-section settings were never saved (any of them, ever)

Ticking the new carousel checkbox appeared to do nothing. The cause was not
the carousel: **no per-section setting has ever persisted in production.**

`assets/js/admin/zymarg-drag-drop.min.js` collected settings fields with
the selector `.zhp-section-settings[name]` — with no space. That reads as
"an element that is itself `.zhp-section-settings` AND carries a `name`
attribute". The settings panel is a `<div class="zhp-section-settings">`
with no `name`, and the inputs are its descendants, so the selector matched
zero elements and every save posted `settings: {}` for every section.

The unminified source had the correct descendant selector
(`.zhp-section-settings [name]`), so this was invisible whenever
`SCRIPT_DEBUG` was on and only ever broke real production sites. The
minified twin had silently drifted from its source.

A second defect sat behind the first: fields are rendered as
`name="settings[key]"`, but the collector used that raw attribute as the
object key. Even with the selector repaired, settings would have been saved
as `settings[carousel]` rather than `carousel`, and the templates — which
read `$settings['carousel']` — would still have seen nothing. The collector
now unwraps `settings[key]` to `key`.

Both the source and the minified file were corrected.

Consequence: section headings, item counts, the Flash Deals countdown
toggle and the new carousel toggle should all now actually take effect.
Saved values were never written before, so every section will still read
from defaults until you set and save them once.

### Fixed - Featured Products and Trending Products rendered identical rows

`Queries\ProductQuery::SUPPORTED_TYPES` keys on `featured` and `trending`,
but the feature registry instantiates those sections with the slugs
`featured-products` and `trending-products`. `parse_args()` checked the
incoming slug against `SUPPORTED_TYPES`, failed to match either, and fell
back to the `featured` default — so both sections ran the same query and
returned the same products.

`Ajax\Filters` and `Ajax\LoadMore` each already carried a `TYPE_MAP` to
translate these slugs; the query layer itself never got one. Added
`SLUG_ALIASES` and applied it in `parse_args()`.

Note that this also means the AJAX filter and load-more paths were
translating slugs correctly while the initial server render was not, so a
section could change its products after a filter interaction.

## 1.11.0 - 2026-07-29

### Added - horizontal swipeable carousels, per section

Every card row can now be displayed as a horizontally swipeable carousel
instead of a wrapping grid. This is opt-in per section via a new
"Horizontal swipeable carousel" checkbox in the admin section settings, so
the default appearance of an existing site does not change on upgrade.

Available on all five card-row section types: product sections (all seven
sub-types), categories, collections, featured sellers, and brands.

Implementation notes:

- Swiping is native. `overflow-x` plus `scroll-snap-type: x mandatory`
  gives touch, trackpad and shift-scroll behaviour with no JavaScript,
  which is smoother than a JS-driven transform and needs no resize maths.
- `carousel.js` only adds the arrow buttons and their enabled/disabled
  state. It is pure progressive enhancement: if it fails to load, every
  carousel is still fully usable by swiping or scrolling.
- The track keeps `display: grid` and switches to `grid-auto-flow: column`,
  so it overrides each section's own grid rules without `!important`.
- Arrows are hidden below 900px, where they would overlap cards and where
  touch users swipe instead. Item widths switch to viewport units below
  600px so a partial next card is visible as a swipe affordance.
- `prefers-reduced-motion` disables smooth scrolling.
- The track is focusable so keyboard users can scroll it with the arrow
  keys. Arrows are `aria-hidden` and untabbable, since they would
  otherwise be redundant stops for screen reader users.
- `window.zhpCarousel.refresh()` is exposed so the load-more and filter
  scripts can re-sync arrow state after injecting new cards.

### Fixed - enqueueing a minified asset that does not exist

`Assets::$min` appended `.min` to every asset path in production, but this
plugin has no build step and its `.min` twins are maintained by hand. Any
asset without a hand-made minified copy would have been enqueued as a 404.
Asset paths now resolve through `Assets::asset_suffix()`, which falls back
to the unminified file when the minified twin is genuinely missing.

The carousel assets ship unminified for this reason. Introducing a real
build step remains the correct long-term fix.

### Note - carousel assets load only when used

`carousel.css` and `carousel.js` are enqueued only when at least one active
section actually has its carousel setting enabled, so sites that keep the
default wrapping grids pay nothing for this feature.

## 1.10.0 - 2026-07-29

### Fixed - critical: no section CSS was ever loaded (everything stacked vertically)

All nine `includes/Features/*/Assets.php` classes contain a correct,
working `enqueue()` method. **Nothing ever called them.**

`Hooks::register()` — the plugin's single hook registry — bound only the
global `Core\Assets::enqueue_frontend()`, which enqueues `zymarg-tokens.css`
and two JS files. There was no instantiation of any feature `Assets` class
and no `->enqueue()` call anywhere in the codebase.

The consequence: `brands.css`, `categories.css`, `collections.css`,
`footer-cta.css`, `hero.css`, `newsletter.css`, `products.css`,
`promo-banner.css` and `sellers.css` were dead files that never reached the
browser.

`zymarg-tokens.css` contains **zero** layout rules — no `display: grid`, no
`grid-template-columns`, no `display: flex`. Every layout rule in the plugin
lives in the per-feature stylesheets. With none of them loaded, every card
fell back to default block flow and the entire homepage rendered as one long
vertical stack.

`Core\Assets` now resolves each active feature's `Assets` class from that
feature's own namespace via reflection and calls `enqueue()`. This requires
no change to `FeatureInterface` or to any `Feature` class. The seven
`ProductSections` sub-features share one namespace and therefore one
stylesheet, de-duplicated here and again by WordPress via the shared handle.

### Changed - plugin assets no longer load site-wide

`enqueue_frontend()` previously ran on every page of the site, loading the
tokens stylesheet and both JS bundles on posts, archives, checkout and
everything else. It now returns early unless the request is the front page
or a singular post/page containing the `[zymarg_homepage]` shortcode.

Section stylesheets load only for sections that are actually enabled, so a
homepage with four active sections no longer downloads nine stylesheets.

### Fixed - a getter was writing to the database

`SectionManager::get_all_sections()` called `update_option()` inside a read
path. Every front-end, AJAX and REST request that hit it while the option
was empty performed a database write.

Worse, it persisted defaults built from whatever was in `FeatureRegistry` at
that moment. During activation the registry is empty, so an empty array
could be written and then read back as "empty" indefinitely. Defaults are
now computed in memory; persisting them is `save()`'s job.

### Fixed - live search could never find a product by SKU

`Ajax\Search::run_search()` set both `s` and a `_sku` `meta_query` on one
`WP_Query`. The docblock described this as an OR. It is not: `WP_Query`
joins the `s` clause and the `meta_query` clause with **AND**, so the
search actually required the term to match the title *and* the SKU. A
product whose SKU matched but whose title did not could never be returned
— the precise case SKU search exists to serve. The `'relation' => 'OR'`
key had no effect, as the `meta_query` held a single clause.

Replaced with two id-only queries (keyword, then SKU) merged and
de-duplicated, with title matches ranked first.

### Fixed - sorting by price silently sorted by the wrong column

`Ajax\Filters` set a bare `meta_key` alongside a `meta_query`. With both
present, `orderby => 'meta_value_num'` is ambiguous: `WP_Query` adds a
second postmeta JOIN and the sort can apply to the wrong clause. Any
request that filtered by price *and* sorted by price hit this. Ordering
now targets a named `meta_query` clause.

### Fixed - sorting by rating or popularity hid products

The same bare `meta_key` produced an INNER JOIN on postmeta, so every
product without a `_wc_average_rating` or `total_sales` row disappeared
from the results. Sorting a catalogue should reorder it, not filter it:
never-rated and never-sold products were being dropped. The sort key is
now registered as an `EXISTS` / `NOT EXISTS` pair joined with `OR`.

## 1.9.5 - 2026-07-29

### Fixed - critical: homepage markup was being stripped before output

`templates/homepage.php` passed the fully assembled section markup through
`wp_kses_post()` before echoing it. `wp_kses_post()` only allows *post content*
HTML, so it silently deleted:

- `<form>`, `<input>`, `<button>` — the newsletter form and every filter and
  load-more control were removed from the DOM entirely
- inline `<svg>` — all icons disappeared
- every `data-*` attribute — which removed all `data-zhp-*` hooks the
  JavaScript binds to, so even surviving controls were inert

The markup was already escaped at the point of output by each feature template
(`esc_html` / `esc_attr` / `esc_url`, with `wp_kses_post` on `price_html`, the
one field that legitimately carries markup). Re-filtering trusted,
already-escaped output was not a security gain — it was data loss.

The output is now echoed directly, with a new `zhp_homepage_sections_html`
filter for extension. Escaping remains at the source.

### Fixed - fatal error in the admin dashboard status endpoint

`Ajax\DashboardStatus` called `$section_manager->get_all()`, which does not
exist — the method is `get_all_sections()`. Any request to
`wp_ajax_zhp_dashboard_status` threw a fatal `Call to undefined method`.

### Security - attribute injection in AJAX-rendered product cards

`Ajax\LoadMore` and `Ajax\Filters` both built `aria-label` attributes with:

```php
printf( esc_attr__( 'View %s', 'zymarg-homepage' ), $product['title'] );
```

This escapes the *translated format string* and then interpolates the product
name into it **unescaped**. A product title containing a quote could break out
of the attribute. Both call sites now escape the composed result:

```php
echo esc_attr( sprintf( __( 'View %s', 'zymarg-homepage' ), $product['title'] ) );
```

The same pattern was fixed on the star-rating labels in both files.

### Fixed - TypeError could take down the filter endpoint

`Ajax\Filters` passed raw `$_POST['orderby']` and `$_POST['type']` straight to
`array_key_exists()` before sanitising. Posting an array (`orderby[]=x`) threw
a `TypeError`. Both inputs are now sanitised first, then validated against
their allow-list.

### Fixed - fatal errors when WooCommerce is inactive

WooCommerce is a hard dependency, but nothing enforced it:

- `Helpers::product_image_url()` called `wc_placeholder_img_src()` unguarded;
  it now falls back to `Helpers::placeholder_image_url()`
- `Helpers::format_price()` called `get_woocommerce_currency_symbol()` unguarded
  in the branch that runs precisely when WooCommerce is missing
- the plugin now refuses to boot without WooCommerce and shows a recoverable
  admin notice instead of a front-end white screen
- added the `Requires Plugins: woocommerce` header for WP 6.5+

## 1.9.4 - 2026-07-28

### Removed - dead loading-spinner tokens

ZYMARG does not use loading spinners. The Discovery Spark is the loading
indicator across both the front end and the admin, so a spinner token has no
legitimate consumer in this plugin.

Two leftovers were carrying a spinner definition forward:

- `--zhp-anim-spinner: 650ms linear infinite` in
  `assets/css/frontend/zymarg-tokens.css` (and the minified build).
- `ZHP_ANIM_SPINNER` in `includes/Core/Constants.php`.

Both were verified unused before removal - nothing in any PHP, JS or CSS file
referenced either one. This is a cleanup with no rendered output change; it
exists so that a future contributor cannot find the token and assume a spinner
is sanctioned.

The stale `@version 1.7.0` header on the frontend token file was also corrected.

See the ZYMARG design tokens document, "THE NO SPINNER RULE", for the full
policy and the Discovery Spark loading markup that replaces it.

## 1.9.3 - 2026-07-28

### Fixed - admin stylesheet never loaded on three of the four screens

The Homepage, Settings and Help screens rendered with no plugin CSS or JS at
all. Every brand change since 1.8.0 was invisible on them; only the Dashboard
ever picked up the design system.

Root cause: Assets::enqueue() matched the admin hook suffix against a
hardcoded list built from the PARENT SLUG:

    zymarg-homepage_page_zymarg-homepage-settings

WordPress builds submenu hook suffixes from sanitize_title() of the parent
MENU TITLE, not the parent slug. The parent title is "Homepage", so the real
hook suffix is:

    homepage_page_zymarg-homepage-settings

None of the three submenu entries could ever match, so enqueue() returned
early. Only "toplevel_page_zymarg-homepage" (the Dashboard) was correct.

- Asset loading now matches on the page slug instead of the hook suffix, which
  is stable and survives any future change to the menu title.
- The drag-and-drop script guard on the Homepage screen had the same defect and
  is fixed the same way. jQuery UI Sortable, section reordering, the reset
  dialog and section saving were all non-functional on that screen.

This bug predates the brand work; it has been present since the submenu pages
were introduced.

## 1.9.2 - 2026-07-28

### Fixed - brand design now reaches every admin screen

1.9.1 styled the shell, but three surfaces still rendered as raw WordPress.

- **Section settings panels (Homepage screen).** The nine feature classes in
  Features/*/Settings.php emit 29 form controls with no CSS class at all and 29
  bare <label> tags, so none of them matched the .zhp-settings-row__label /
  .zhp-settings-text rules. They are now styled by element inside
  .zhp-settings-row, which brands every expanded section panel without editing
  nine PHP files. Covers text, url, number, checkbox, select and textarea.
- **Help tables.** The four tables carry the WordPress core classes .widefat
  and .striped, whose core styles outranked .zhp-help-table. Brand table
  styling is now reasserted at matching specificity.
- **Reset confirmation dialog.** zymarg-drag-drop.js appends the modal to
  <body>, outside .zhp-admin-wrap, where every --zg-* token was undefined, so
  the dialog rendered with no colours, radius or shadow. The token block is now
  declared on .zhp-confirm-modal as well.

### Fixed - build

- **Minifier corrupted a selector.** The whitespace pass collapsed
  ".zhp-admin-wrap :focus-visible" into ".zhp-admin-wrap:focus-visible",
  turning a descendant selector into an element selector and disabling focus
  rings on every control in the shipped .min.css (the file WordPress actually
  enqueues). Whitespace before a colon is now preserved.

## 1.9.1 - 2026-07-28

### Fixed

- **Discovery Spark is now animated.** 1.9.0 shipped the Spark as a static
  shape. The canonical sequential lens pulse is restored (accent 0.20s ->
  companion 0.40s -> hero 0.40s, cubic-bezier(.25,1,.5,1), per-shape
  transform-origins). Timings and keyframe percentages are verbatim from the
  canonical source; only the glow colour is brand-aligned to #9500A5.
- **Version badge moved to the right of the header** and now shows the number
  only (v1.9.1) instead of the phrase "Version 1.9.1".
- **All four admin screens now share one header.** Previously
  .zhp-admin-header__version held a version string on Dashboard and Help but a
  descriptive subtitle on Sections and Settings, so the gradient pill styling
  applied to whichever text each page happened to use. The class is now always
  the muted subtitle, and the version pill is a separate
  .zhp-admin-header__badge in the header actions area.
- Dashboard and Help gained proper subtitles now that the version string has
  moved into the badge.
- prefers-reduced-motion holds the Spark static at 70% opacity.

## 1.9.0 - 2026-07-28

### Changed - Admin brand design system

Admin CSS is now a faithful port of the canonical ZYMARG brand design system
(reference: ZYMARG Login & Security v1.8.4). Version 1.8.0 only recoloured the
existing layout; this release replaces the components themselves.

- BRAND PRIMARY locked to #9500A5 across the whole admin surface.
- Header: full-bleed gradient bar replaced by a white card (1px #d8bfd3,
  16px radius) with a 3px gradient top strip.
- Wordmark: solid #9500A5 at 22px/700. Never gradient-filled text.
- Logo: the plain "Z" chip is replaced by the Discovery Spark, recoloured
  from #6833EA to brand #9500A5. Gold core #FFD166 retained.
- Version now renders as the brand gradient pill badge.
- Buttons: gradient primary with lift; white bordered secondary/ghost.
- Cards, panels, settings groups and status bars share one surface recipe.
- Section titles standardised to 12px / 700 / uppercase / .14em purple.
- Toggle normalised to canonical 44x24 track, 18px thumb, 20px travel.
- Admin typography moved to the canonical system stack. Frontend unchanged.
- Focus states use :focus-visible; prefers-reduced-motion supported.

### Notes

- No PHP logic changed. The four admin page headers were edited only to swap
  the letter chip for the Discovery Spark markup.
- Frontend --zhp-* tokens are deliberately untouched.

## 1.7.3 — 2026-07-27

### Change — WP sidebar label
- Shortened the admin sidebar menu label from "ZYMARG Homepage" to "Homepage".

**Version bumped:** `1.7.2 → 1.7.3` across plugin header, `ZYMARG_HP_VERSION`, and all files modified in this release.

---

## 1.7.2 — 2026-07-27

### Feature — Zero-configuration activation

The plugin now configures itself automatically when activated. No manual page creation, no Settings → Reading changes, no shortcode placement required.

**Added**

#### includes/Core/Activator.php — new
Runs once via `register_activation_hook`. Resolves the front page using a three-step priority chain:
1. WordPress already has a static front page set → use it as-is, record its ID.
2. A published page with slug `home` exists → set it as the static front page.
3. Neither → create a new published `Home` page (slug: `home`) and set it as the front page.

Stores `zymarg_hp_front_page_id` and `zymarg_hp_page_created` options. Never modifies an existing page's content.

#### includes/Homepage/HomepageController.php — `maybe_override_content()`
New `the_content` filter callback. On every front page request it replaces the post content with the plugin's full homepage output. Guards: `is_singular()`, `is_front_page()`, `in_the_loop()`, `is_main_query()`. Skips silently when the `[zymarg_homepage]` shortcode is already in the content (prevents double render). Falls back to original content if `render()` returns empty.

**Changed**

#### includes/Core/Plugin.php — `activate()`
Now calls `Activator::run()` after seeding default options. `support_email` added to the default settings seed (was missing).

#### includes/Core/Hooks.php
`the_content` filter registered pointing to `HomepageController::maybe_override_content()`.

#### includes/Admin/Pages/Help.php — Initial Setup section
Rewritten to document the zero-config behaviour. Old three-step manual guide replaced with an explanation of the automatic priority chain plus a note on optional theme interference reduction.

**Version bumped:** `1.7.1 → 1.7.2` across plugin header, `ZYMARG_HP_VERSION`, and all 6 files modified in this release.

---

## 1.7.1 — 2026-07-27

### Patch — Post-release fixes and additions

**Fixed**

- `Admin/Pages/Settings.php` and `Admin/Pages/Dashboard.php` — `@version` left on `1.3.0` after Phase 7 edits; bumped to `1.7.1`.

**Added**

#### includes/Admin/Pages/Help.php
- New **Help & Documentation** admin page covering initial setup (3-step guide with direct admin links), section reference table for all 15 sections, shortcode and PHP function usage, design token override guide, developer hooks and filters, AJAX/REST endpoint reference, asset debug mode instructions, and a troubleshooting checklist for 6 common problems.

#### includes/Admin/Pages/Settings.php + includes/Admin/Settings.php
- New `support_email` setting — configurable contact address shown on the Help page. Defaults to empty (block hidden when blank). Sanitized via `sanitize_email()`. Removed the hardcoded `engineering@zymarg.com` that was previously baked into `Help.php`.

#### includes/Ajax/DashboardStatus.php
- New AJAX handler (`wp_ajax_zhp_dashboard_status`). Returns live plugin health data: master switch state, sections enabled/total count, front page configuration, shortcode presence on front page, WooCommerce active, Dokan active.

#### Admin Dashboard
- Static status bar replaced with two bars: a static one (Version, Shortcode, PHP Function) and a live AJAX-driven bar that loads on page open and shows real-time plugin health with green/red indicators.

**Improved**

#### includes/Admin/Assets.php
- `zhpAdmin` JS global moved from Settings-page-only to **all plugin admin pages**. Added full `i18n` object (13 translated strings) and `nonceDashboard` for the status check.
- `zhpDragDrop.i18n` — added `save`, `cancel`, and `confirmOk` keys; existing `confirm` string updated to match the new inline modal.

#### assets/js/admin/zymarg-admin.js
- All hardcoded English strings (`'Saving…'`, `'Save Settings'`, `'Enabled'`, `'Disabled'`, etc.) replaced with `zhpAdmin.i18n.*` references. Fallback literals kept only as graceful-degradation defaults.
- Added dashboard status AJAX call on page load; populates the live status bar via `setStatus()` helper.

#### assets/js/admin/zymarg-drag-drop.js
- Replaced `window.confirm()` with a fully custom inline modal: semi-transparent overlay, focusable confirm/cancel buttons, Escape key and overlay-click dismissal, ARIA `role="dialog"` and `aria-modal`. No native browser dialogs remain.
- Hardcoded `'Save Changes'` button text replaced with `i18n.save`.

#### Empty files and directories (previously reported as OB)
- `LICENSE` — written as a proper proprietary notice.
- All 7 `ProductSections/Queries/*.php` stubs — valid PSR-4 class shells implementing `QueryInterface` with typed `get()` signatures and `@todo Phase 8` markers.
- All 7 `ProductSections/Templates/*.php` stubs — valid PHP with full variable contracts and `@todo Phase 8` guidance.
- All 10 `includes/Components/*/` stubs — proper class files with typed `render()` signatures and `@todo Phase 8` markers.
- `languages/zymarg-homepage.pot` — minimal valid `.pot` header with generation instructions.
- `composer.json` — added to project root documenting namespace mapping and Composer scripts for `pot`/`mo` generation.
- `.gitkeep` files added to `assets/fonts/`, `assets/icons/`, `assets/images/`, `templates/components/`, `templates/features/`, `vendor/`.

**Version bumped:** `1.7.0 → 1.7.1` across plugin header, `ZYMARG_HP_VERSION` constant, and all 13 PHP/JS/CSS files modified in this patch.

---

## 1.7.0 — 2026-07-26

### Phase 7 — Polish & Production Readiness

**Added**

#### assets/css/frontend/zymarg-tokens.css
- New design tokens: `--zhp-color-danger` (#E53E3E), `--zhp-color-warning` (#ED8936), `--zhp-color-star` (#F6AD55) — mirrors every hardcoded value that existed in component CSS.
- `:focus-visible` outlines on `.zhp-btn-primary` (accent colour) and `.zhp-btn-secondary` (primary colour) — previously only hover states existed.

#### includes/Core/Constants.php
- `ZHP_COLOR_DANGER`, `ZHP_COLOR_WARNING`, `ZHP_COLOR_STAR` constants — PHP mirrors of the three new CSS tokens.

#### Minified assets (`.min.css` / `.min.js`)
- Created minified counterparts for all 10 frontend CSS files, 1 admin CSS file, 4 frontend JS files, and 2 admin JS files (22 – 55 % size reduction).

#### includes/Core/Assets.php + all Feature Assets.php files
- `$this->min` property and constructor added to every Assets class. Resolves to `.min` in production and `''` when `SCRIPT_DEBUG` is true, so all `wp_enqueue_style` / `wp_enqueue_script` calls automatically load the correct file variant.

#### readme.md
- Wrote the full plugin readme: overview, requirements, section table, admin panel tabs, AJAX/REST endpoint reference, JS API docs, developer hooks/filters, asset-loading notes, design-token override guide, and accessibility summary.

**Fixed**

#### includes/Features/ProductSections/Template.php
- **Security:** `$product['title']` was interpolated raw into an `aria-label` HTML attribute. Wrapped with `esc_attr()` so values containing `"` or `>` cannot break attribute context.

#### includes/Features/Newsletter/Template.php
- **Accessibility / HTML validity:** `id="zhp-email"` was hardcoded, producing duplicate IDs when the section was rendered more than once per page. Replaced with `wp_unique_id('zhp-email-')` for the `<input>` and its paired `<label for="…">`.

#### assets/css/frontend/products.css
- Replaced three hardcoded hex values (`#E53E3E`, `#ED8936`, `#F6AD55`) with the corresponding new design tokens (`var(--zhp-color-danger)`, `var(--zhp-color-warning)`, `var(--zhp-color-star)`).
- Replaced hardcoded `#fff` in badge rules with `var(--zhp-color-surface)` for token consistency.
- Added `:focus-visible` outline on `.zhp-product-card__title` links (was missing while all other card types already had it).

**Improved — Accessibility (all Template.php files)**

All nine feature `<section>` elements now carry `aria-labelledby` pointing to a `wp_unique_id()`-generated `id` on their heading. This turns every section into a properly labelled ARIA landmark, allowing screen-reader users to navigate by region.

| Template | Change |
|---|---|
| `Brands/Template.php` | `<section aria-labelledby>` + `<h2 id>` |
| `Categories/Template.php` | `<section aria-labelledby>` + `<h2 id>` |
| `Collections/Template.php` | `<section aria-labelledby>` + `<h2 id>` |
| `FeaturedSellers/Template.php` | `<section aria-labelledby>` + `<h2 id>` |
| `FooterCTA/Template.php` | `<section aria-labelledby>` + `<h2 id>` |
| `Hero/Template.php` | `<section aria-labelledby>` + `<h1 id>` |
| `Newsletter/Template.php` | `<section aria-labelledby>` + `<h2 id>` |
| `ProductSections/Template.php` | `<section aria-labelledby>` + `<h2 id>` |
| `PromoBanner/Template.php` | `aria-labelledby` when title present; `aria-label` from alt text otherwise |

**Version bumped:** every PHP `@version` docblock, CSS `@version` comment, WordPress plugin header, and `ZYMARG_HP_VERSION` constant updated from 1.6.0 → 1.7.0.

---

## 1.6.0 — 2026-07-26

### Phase 6 — AJAX & REST

**Added**

#### Ajax/LoadMore.php
- Handles `wp_ajax_zhp_load_more` and `wp_ajax_nopriv_zhp_load_more`.
- Accepts POST: `zhp_nonce`, `type` (product section slug), `offset`, `limit`, `category`.
- Validates nonce (`zhp_load_more`) and plugin master switch before any processing.
- Maps admin-facing section slugs (`featured-products`, `trending-products`, etc.) to `ProductQuery` type keys via `TYPE_MAP`.
- Returns JSON: `{ html, has_more, next_offset }` — `html` is a fragment of `<article>` product cards ready to append to the existing grid; `has_more` tells the JS whether to keep the Load More button visible.
- Probes one item beyond the current batch to determine `has_more` without running a costly `found_posts` count.
- `render_cards()` reuses the same card markup as Phase 5 `ProductSections\Template` for visual consistency.

#### Ajax/Search.php
- Handles `wp_ajax_zhp_search` and `wp_ajax_nopriv_zhp_search`.
- Accepts POST: `zhp_nonce`, `query` (min 2 chars, max 100), `limit` (default 8, max 20), `category`.
- Validates nonce (`zhp_search`). Returns empty results (not an error) for queries under `MIN_LENGTH`.
- WP_Query searches by title (`s` parameter) plus an OR meta_query on `_sku` so SKU entries surface even when the title doesn't match.
- Results cached via `CacheManager` keyed on `{ q, limit, category }`.
- Return shape per item: `{ id, title, permalink, image_url, price_html, rating, badge, category, sku }` — lightweight enough for autocomplete dropdowns.

#### Ajax/Filters.php
- Handles `wp_ajax_zhp_filter` and `wp_ajax_nopriv_zhp_filter`.
- Accepts POST: `zhp_nonce`, `type`, `category`, `orderby` (date / price / price-desc / rating / popularity), `min_price`, `max_price`, `limit`, `paged`.
- Validates nonce (`zhp_filter`) and maps `orderby` values to WP_Query `[ orderby, order ]` pairs via `ORDERBY_MAP`.
- Builds a full paginated `WP_Query` with price meta filter, category tax filter, and type-specific visibility constraints (mirrors Phase 4 `ProductQuery` logic).
- Returns JSON: `{ html, total, pages, paged, has_more }` — `html` is the full grid replacement (or a localised "No products found" message); pagination metadata lets JS update a page indicator and the Load More button.

#### REST/Routes.php
- Registers five endpoints under the `zhp/v1` REST namespace on `rest_api_init`.
- `GET /zhp/v1/products` — paginated product list; parameters: `type`, `limit`, `offset`, `category`; validated by WP REST schema; cached via `CacheManager`.
- `GET /zhp/v1/products/search` — lightweight search returning `{ results, query }`; identical data shape to Ajax/Search; min-length guard; cached.
- `GET /zhp/v1/categories` — product category list; parameters: `limit`, `parent`, `hide_empty`; delegates to `CategoryQuery`; cached.
- `GET /zhp/v1/sellers` — featured seller list; parameter: `limit`; delegates to `SellerQuery`; cached.
- `POST /zhp/v1/newsletter/subscribe` — validates `email` (format schema) and `zhp_nonce` (`zhp_newsletter`); fires `do_action( 'zhp_newsletter_subscribe', $email )` so any newsletter plugin can hook in without modifying plugin code; returns `{ subscribed: true, message }`.
- All GET endpoints use `permission_callback => '__return_true'` (public); newsletter POST validates its own nonce in the callback.

#### assets/js/frontend/load-more.js
- Vanilla JS; no jQuery.
- On `DOMContentLoaded`, scans for `.zhp-products[data-zhp-section]` elements; injects a `.zhp-load-more-btn` button beneath each grid when the initial card count equals the section's limit (more may exist).
- On click: sets `btn.disabled`, fires `fetch()` to `admin-ajax.php` with action `zhp_load_more`, appends returned cards to the grid, updates offset, removes button when `has_more` is false.
- All strings and nonces read from the localised `window.zhpAjax` object.

#### assets/js/frontend/filters.js
- Vanilla JS; no jQuery.
- On `DOMContentLoaded`, binds `change`/`input` listeners to `[data-zhp-filter]` controls inside each product section.
- Category pill buttons toggle `is-active` / `aria-pressed` state.
- All controls debounced at 350 ms to avoid firing on every keystroke.
- On change: sets `grid[aria-busy]` and reduces opacity; fires `fetch()` to `admin-ajax.php` with action `zhp_filter`; swaps `grid.innerHTML` with returned HTML; updates/removes Load More button based on `has_more`.

**Updated**
- `includes/Core/Hooks.php` — registers `wp_ajax_zhp_load_more`, `wp_ajax_nopriv_zhp_load_more`, `wp_ajax_zhp_search`, `wp_ajax_nopriv_zhp_search`, `wp_ajax_zhp_filter`, `wp_ajax_nopriv_zhp_filter`, and `rest_api_init → Routes::register()`; version bump to 1.6.0.
- `includes/Core/Assets.php` — `enqueue_frontend()` now enqueues `load-more.js` and `filters.js` (footer, in dependency order); localises `window.zhpAjax` onto `load-more.js` with `ajaxUrl`, `restUrl`, per-action nonces (`loadMore`, `search`, `filter`, `newsletter`), and i18n strings; version bump to 1.6.0.
- `includes/Features/ProductSections/Template.php` — `<section>` element now carries `data-zhp-section` (type slug) and `data-zhp-limit` (card count) attributes so `load-more.js` and `filters.js` can find and bind to the correct grid; version bump to 1.6.0.
- `includes/Core/Constants.php` — version bump to 1.6.0.
- `zymarg-homepage.php` — version bump to 1.6.0.

**Goal met:** Load More works on all seven product section types. Search returns lightweight JSON for autocomplete. Filters let visitors narrow by category, price, and sort order without a page reload. Five REST endpoints are live under `/wp-json/zhp/v1/`. Newsletter subscribe fires the `zhp_newsletter_subscribe` action hook for third-party plugin integration. No PHP errors on activation.

---

## 1.5.0 — 2026-07-26

### Phase 5 — Features (all 9 completed)

**Added**

#### 5a. Hero
- `includes/Features/Hero/Feature.php` — registers `hero` slug (order 1, enabled by default); proxies `render_settings_fields()` to `Settings`.
- `includes/Features/Hero/Query.php` — delegates to `BannerQuery` with `type=hero`.
- `includes/Features/Hero/Template.php` — full-width banner; prefers per-section settings over CPT data; graceful fallback to defaults when neither exists; inline `style` attribute with `esc_attr()` for background image URL.
- `includes/Features/Hero/Settings.php` — five fields: Heading, Sub-heading, CTA Label, CTA URL, Background Image URL.
- `includes/Features/Hero/Assets.php` — conditionally enqueues `hero.css` (file-exists guard).
- `assets/css/frontend/hero.css` — full-width gradient / image hero; overlay; heading; CTA button; mobile breakpoint.

#### 5b. Categories
- `includes/Features/Categories/Feature.php` — slug `categories`, order 2.
- `includes/Features/Categories/Query.php` — wraps `CategoryQuery`.
- `includes/Features/Categories/Template.php` — responsive auto-fill grid of category cards with image, name, product count.
- `includes/Features/Categories/Settings.php` — Section Heading, Number of Categories.
- `includes/Features/Categories/Assets.php` — conditionally enqueues `categories.css`.
- `assets/css/frontend/categories.css` — circular thumbnail cards, hover lift.

#### 5c. ProductSections (7 independent sub-types)
- `includes/Features/ProductSections/Feature.php` — single class handles all 7 sub-types (`featured-products`, `trending-products`, `best-sellers`, `flash-deals`, `new-arrivals`, `recommended`, `recently-viewed`); `Feature::all_instances()` returns one Feature per slug; each slug gets its own toggle, order, and settings row in the admin.
- `includes/Features/ProductSections/Template.php` — shared product grid template; product cards with image, title, star rating, price HTML, View Product CTA, badge; Flash Deals renders a live countdown timer via `[data-zhp-countdown]` / `[data-zhp-timer]` attributes.
- `includes/Features/ProductSections/Settings.php` — Section Heading, Products to Show (per-section override), Countdown Timer checkbox.
- `includes/Features/ProductSections/Assets.php` — enqueues `products.css` and `countdown.js`.
- `assets/css/frontend/products.css` — section header with countdown, product grid, card image with hover scale, badge variants (sale/new/hot/featured), star rating via CSS custom property `--zhp-rating`, price, CTA.
- `assets/js/frontend/countdown.js` — vanilla JS; counts down to midnight UTC; updates `[data-zhp-timer]` every second; no-op when no countdown elements are present.

#### 5d. Featured Sellers
- `includes/Features/FeaturedSellers/Feature.php` — slug `featured-sellers`, order 10.
- `includes/Features/FeaturedSellers/Query.php` — wraps `SellerQuery`.
- `includes/Features/FeaturedSellers/Template.php` — seller cards with banner, avatar (offset over banner), store name, location, star rating, product count.
- `includes/Features/FeaturedSellers/Settings.php` — Section Heading, Sellers to Show.
- `includes/Features/FeaturedSellers/Assets.php` — conditionally enqueues `sellers.css`.
- `assets/css/frontend/sellers.css` — seller card with banner strip, avatar overlap, body copy, hover lift.

#### 5e. Promo Banner
- `includes/Features/PromoBanner/Feature.php` — slug `promo-banner`, order 11; queries `BannerQuery` with `type=promo`.
- `includes/Features/PromoBanner/Template.php` — full-width clickable image banner with optional overlay title and CTA; renders nothing when both image and title are empty.
- `includes/Features/PromoBanner/Settings.php` — Banner Title, Image URL, Link URL, Link Label, Alt Text.
- `includes/Features/PromoBanner/Assets.php` — conditionally enqueues `promo-banner.css`.
- `assets/css/frontend/promo-banner.css` — responsive banner with gradient overlay on left third; hover shadow.

#### 5f. Collections
- `includes/Features/Collections/Feature.php` — slug `collections`, order 12, disabled by default; queries `BannerQuery` with `type=collection`.
- `includes/Features/Collections/Template.php` — masonry-style image cards with bottom gradient overlay, title, CTA badge.
- `includes/Features/Collections/Settings.php` — Section Heading, Collections to Show.
- `includes/Features/Collections/Assets.php` — conditionally enqueues `collections.css`.
- `assets/css/frontend/collections.css` — 3:2 aspect-ratio cards; image zoom on hover; bottom overlay.

#### 5g. Brands
- `includes/Features/Brands/Feature.php` — slug `brands`, order 13, disabled by default.
- `includes/Features/Brands/Query.php` — reads `pa_brand` taxonomy (YITH/custom attribute); falls back to `zhp_brand` CPT taxonomy; returns empty array cleanly when neither exists; results cached via `CacheManager`.
- `includes/Features/Brands/Template.php` — flex logo strip; image with 40% grayscale that lifts to full colour on hover; text fallback when no logo image is set.
- `includes/Features/Brands/Settings.php` — Section Heading, Brands to Show.
- `includes/Features/Brands/Assets.php` — conditionally enqueues `brands.css`.
- `assets/css/frontend/brands.css` — logo pill cards, hover grayscale lift.

#### 5h. Newsletter
- `includes/Features/Newsletter/Feature.php` — slug `newsletter`, order 14, enabled by default.
- `includes/Features/Newsletter/Template.php` — two-column gradient strip: copy left, email field + subscribe button right; fires `zhp:newsletter:subscribe` custom DOM event for third-party plugin integration; shows inline success message without page reload.
- `includes/Features/Newsletter/Settings.php` — Heading, Sub-heading, Button Label, Success Message.
- `includes/Features/Newsletter/Assets.php` — enqueues `newsletter.css` and `newsletter.js`.
- `assets/css/frontend/newsletter.css` — gradient background matching `--zhp-gradient-primary`; semi-transparent input; white CTA; mobile stacks vertically.
- `assets/js/frontend/newsletter.js` — vanilla JS; validates email regex client-side; dispatches `zhp:newsletter:subscribe` custom event; shows success message; no jQuery.

#### 5i. Footer CTA
- `includes/Features/FooterCTA/Feature.php` — slug `footer-cta`, order 15, enabled by default.
- `includes/Features/FooterCTA/Template.php` — two-column strip on `--zhp-color-container` background; heading, sub-heading, CTA button linking to `/vendor-registration` by default.
- `includes/Features/FooterCTA/Settings.php` — Heading, Sub-heading, Button Label, Button URL.
- `includes/Features/FooterCTA/Assets.php` — conditionally enqueues `footer-cta.css`.
- `assets/css/frontend/footer-cta.css` — contained strip layout; responsive single-column on mobile.

**Updated**
- `includes/Homepage/HomepageController.php` — `boot_features()` now registers all 15 section features (9 top-level + 7 ProductSection sub-types = 15 independent slugs); version bump to 1.5.0.
- `includes/Core/Constants.php` — version bump to 1.5.0.
- `zymarg-homepage.php` — version bump to 1.5.0.
- `assets/css/frontend/zymarg-tokens.css` — added `.zhp-section` base padding class shared by all feature section wrappers.

**Goal met:** All 15 homepage section slugs are registered, renderable, and independently togglable and orderable from the admin panel. Each feature: renders correctly on desktop and mobile; uses only `--zhp-*` design tokens; escapes all output with `esc_html()`, `esc_attr()`, `esc_url()`, `wp_kses_post()`; never hard-codes colours or pixel values; degrades cleanly when data is absent (returns empty string, no errors). No PHP errors on activation.

---

## 1.4.0 ��� 2026-07-25

### Phase 4 — Shared Query Layer

**Added**
- `includes/Queries/CacheManager.php` — higher-level cache utility wrapping `Core\Cache`; builds deterministic, collision-free keys from a group name + argument hash; provides `get()`, `set()`, `delete()`, and `invalidate_group()` for group-level transient purging without touching unrelated cache entries.
- `includes/Queries/ProductQuery.php` — shared WooCommerce product query; implements `QueryInterface`; supports seven section types via `$args['type']`: `featured`, `trending`, `best-sellers`, `flash-deals`, `new-arrivals`, `recommended`, and `recently-viewed`; each type selects the correct `WP_Query` configuration (tax queries, meta queries, date ranges, sort keys); recently-viewed reads from the `woocommerce_recently_viewed` cookie with no database hit; hydrates results to a consistent array shape including `id`, `title`, `permalink`, `price_html`, `on_sale`, `is_featured`, `rating`, `review_count`, `image_url`, `image_alt`, `badge`, `sku`; resolves badge type per section context (`sale`, `hot`, `new`, `featured`); all results cached via `CacheManager`.
- `includes/Queries/CategoryQuery.php` — WooCommerce product category query; implements `QueryInterface`; wraps `get_terms()` for the `product_cat` taxonomy; supports `limit`, `parent` (0 = top-level, -1 = all levels), `hide_empty`, `orderby`, `order`, `include`, and `exclude` args; retrieves Dokan/WooCommerce category thumbnail from `thumbnail_id` term meta with placeholder fallback; results cached via `CacheManager`.
- `includes/Queries/SellerQuery.php` — Dokan vendor query; implements `QueryInterface`; detects Dokan at runtime via `dokan_get_sellers()` / class existence; falls back to `WP_User_Query` with `seller` role when Dokan core functions are unavailable; hydrates each user to a consistent shape including store name, URL, avatar, banner, rating, rating count, product count, and location (city/state/country from Dokan address meta); returns empty array cleanly when Dokan is not active.
- `includes/Queries/BannerQuery.php` — promotional banner query; implements `QueryInterface`; primary source is the `zhp_banner` custom post type (registered in Phase 5); reads `_zhp_banner_type`, `_zhp_banner_subtitle`, `_zhp_banner_link_url`, and `_zhp_banner_link_label` post meta; falls back to banner config stored in `zymarg_hp_section_order` section settings (Hero, Promo Banner) when no CPT posts exist yet; supports `limit`, `type`, and `offset` args; results cached via `CacheManager`.

**Updated**
- `includes/Core/Constants.php` — version bump to 1.4.0.
- `zymarg-homepage.php` — version bump to 1.4.0.

**Goal met:** All five shared query classes are implemented and caching correctly. `ProductQuery` covers all seven product section sub-types. `SellerQuery` degrades gracefully when Dokan is absent. `BannerQuery` serves data even before the `zhp_banner` CPT exists. Phase 5 Feature classes can call any of these directly with typed `$args` and receive a predictable array shape. No PHP errors on activation.

---

## 1.3.0 — 2026-07-25

### Phase 3 ��� Admin Panel

**Added**
- `includes/Admin/Admin.php` — top-level admin coordinator; instantiated by `Plugin::setup()` when `is_admin()`; exposes `get_menu()`, `get_assets()`, `get_drag_drop()` for Hooks binding.
- `includes/Admin/Menu.php` — registers top-level menu (`ZYMARG Homepage`) and three sub-pages: Dashboard, Homepage, Settings. Uses `add_menu_page` / `add_submenu_page`.
- `includes/Admin/Assets.php` — enqueues `zymarg-admin.css` and `zymarg-admin.js` on all plugin admin pages; enqueues `jquery-ui-sortable` + `zymarg-drag-drop.js` + `zhpDragDrop` localized data on the Homepage section manager page only.
- `includes/Admin/Settings.php` — read/write layer for `zymarg_hp_settings` option; handles `wp_ajax_zhp_save_settings` AJAX action; sanitises and range-clamps all values.
- `includes/Admin/DragDrop.php` — handles `wp_ajax_zhp_save_sections` and `wp_ajax_zhp_reset_sections`; validates nonce and capability; delegates persistence to `SectionManager::save()`.
- `includes/Admin/Pages/Dashboard.php` — overview page with quick-link cards (Homepage, Settings) and a status bar showing plugin version, shortcode, and public function.
- `includes/Admin/Pages/Homepage.php` — full drag-and-drop section manager; renders all 15 section rows from `SectionManager`; falls back to the canonical default slug list when the option is empty; each row has a drag handle, toggle switch, label+slug badge, and expand button that reveals a per-section settings panel. Settings panel delegates to the Feature's `render_settings_fields()` when registered, or shows a Phase 5 placeholder.
- `includes/Admin/Pages/Settings.php` — global settings form: master switch toggle, products-per-section number input, cache-duration number input; saves via AJAX to `zhp_save_settings`.
- `assets/css/admin/zymarg-admin.css` — full admin stylesheet; uses ZYMARG brand colours and tokens; covers header, cards, status bar, section list, drag-and-drop states, toggle switches, settings form, notices, and responsive breakpoints down to 782 px.
- `assets/js/admin/zymarg-admin.js` �� shared admin JS: expand/collapse section settings panels, toggle switch disabled-row state, settings AJAX save handler.
- `assets/js/admin/zymarg-drag-drop.js` — jQuery UI Sortable initialisation, section data collection (order, enabled, per-section settings), AJAX save (`zhp_save_sections`), AJAX reset (`zhp_reset_sections`).

**Updated**
- `includes/Core/Plugin.php` — instantiates `Admin` when `is_admin()`; passes it to `Hooks::register()`; version bump to 1.3.0.
- `includes/Core/Hooks.php` — `register()` now accepts optional `Admin`; registers `admin_menu`, `admin_enqueue_scripts`, `wp_ajax_zhp_save_sections`, `wp_ajax_zhp_reset_sections`, `wp_ajax_zhp_save_settings`; version bump to 1.3.0.
- `includes/Core/Constants.php` — version bump to 1.3.0.
- `zymarg-homepage.php` — version bump to 1.3.0.

**Goal met:** Admin menu visible in WordPress. Dashboard, Homepage, and Settings pages render correctly. Drag-and-drop list shows all 15 sections with toggle switches, order handles, and expandable settings panels. Toggle and order changes save to `zymarg_hp_section_order` via AJAX. Global settings save to `zymarg_hp_settings` via AJAX. No PHP errors on activation.

---

## 1.2.0 — 2026-07-25

### Phase 2 — Homepage Engine

**Added**
- `includes/Interfaces/FeatureInterface.php` — contract all feature sections must implement (`get_slug`, `get_label`, `get_default_order`, `is_enabled_by_default`, `render`).
- `includes/Interfaces/QueryInterface.php` — contract all query classes must implement (`get`).
- `includes/Interfaces/Renderable.php` — contract all template classes must implement (`render`).
- `includes/Homepage/FeatureRegistry.php` — static registry; features register themselves here; exposes `register()`, `all()`, `get()`, `has()`, `reset()`.
- `includes/Homepage/SectionManager.php` — reads/writes `zymarg_hp_section_order`; `get_active_sections()` returns ordered enabled-only list; `get_all_sections()` returns full list for admin; `save()` persists admin changes with full sanitisation.
- `includes/Homepage/LayoutEngine.php` — iterates active sections, calls each Feature's `render()`, assembles HTML fragments; exceptions in one section are caught and logged without breaking the page.
- `includes/Homepage/Renderer.php` — wraps LayoutEngine output in `templates/homepage.php`; loads template in isolated scope exposing only `$sections_html`.
- `includes/Homepage/HomepageController.php` — top-level coordinator; boots FeatureRegistry, constructs SectionManager/LayoutEngine/Renderer; exposes `render()`, `is_active()`, `get_section_manager()`; `boot_features()` stub ready for Phase 5.
- `templates/homepage.php` — outer `<main id="zhp-homepage">` wrapper; receives `$sections_html`; uses `wp_kses_post()` for output escaping; always renders even when sections list is empty.
- `zymarg_homepage_render()` public PHP function registered in `zymarg-homepage.php`; calls `do_shortcode('[zymarg_homepage]')` as fallback; filterable via `zymarg_homepage_controller`.

**Updated**
- `includes/Core/Plugin.php` — instantiates `HomepageController` in `setup()`; passes it to `Hooks::register()`.
- `includes/Core/Hooks.php` — `register()` now accepts `HomepageController`; registers `[zymarg_homepage]` shortcode bound to `HomepageController::render`.
- `includes/Core/Constants.php` — version bump to 1.2.0.
- `zymarg-homepage.php` — version bump to 1.2.0; adds public `zymarg_homepage_render()` function.

**Goal met:** `[zymarg_homepage]` renders a valid `<main id="zhp-homepage">` wrapper with correct HTML structure. Zero sections render (expected — no features registered until Phase 5). No PHP errors on activation.

---

## 1.1.0 — 2026-07-25

### Phase 1 — Core Foundation

**Added**
- `zymarg-homepage.php` — plugin bootstrap with correct WordPress plugin headers and activation/deactivation hook registration.
- `includes/Core/Loader.php` — PSR-4 autoloader mapping `ZYMARGHomepage\*` → `includes/`.
- `includes/Core/Plugin.php` — singleton main class; boots all subsystems on `plugins_loaded`.
- `includes/Core/Hooks.php` — central hook registry; all `add_action` / `add_filter` calls live here only.
- `includes/Core/Assets.php` — global asset manager; enqueues the design-token stylesheet on the frontend.
- `includes/Core/Logger.php` — debug logging wrapper; respects `WP_DEBUG` / `WP_DEBUG_LOG`; prefixes entries with `[ZYMARG-HP vX.X.X]`.
- `includes/Core/Cache.php` — WordPress transient wrapper with `zhp_` prefix; respects global cache duration setting; includes `flush_all()` helper.
- `includes/Core/Helpers.php` — shared utility methods: settings access, image URLs, text truncation, price formatting, HTML attribute builder, section class builder.
- `uninstall.php` — removes all plugin options and `zhp_*` transients on deletion; multisite-aware.

**Fixed**
- `includes/Core/Constants.php` — removed incorrect path constant definitions (moved to `zymarg-homepage.php`); file now contains version constant and ZYMARG Design Tokens v1.1 only.

**Goal met:** Plugin appears in WordPress plugin list as *ZYMARG Homepage v1.1.0*. Activates, deactivates, and uninstalls cleanly. No PHP errors.

---

## 1.0.1 — 2026-07-25 (scaffold)

Initial plugin scaffold. `Constants.php` and `zymarg-tokens.css` written. All other files empty stubs awaiting Phase 1 build.
