<?php
/**
 * Plugin Name:       ZYMARG Homepage
 * Plugin URI:        https://zymarg.com
 * Description:       Generates the complete ZYMARG marketplace homepage, fully independent from the active WordPress theme. No theme templates. No page builders. No hardcoded page content.
 * Version:            1.51.4
 * Requires at least: 6.4
 * Requires PHP:      8.1
 * Requires Plugins:  woocommerce
 * Author:            ZYMARG
 * License:           Proprietary
 * Text Domain:       zymarg-homepage
 * Domain Path:       /languages
 *
 * @package ZYMARGHomepage
 * @since   1.0.1
 * @version 1.25.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// ── 1. Plugin path constants (must come before Constants.php) ────
define( 'ZYMARG_HP_PLUGIN_FILE', __FILE__ );
define( 'ZYMARG_HP_PLUGIN_DIR',  plugin_dir_path( __FILE__ ) );
define( 'ZYMARG_HP_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );

// ── 2. Design tokens + version constant ─────────────────────────
require_once ZYMARG_HP_PLUGIN_DIR . 'includes/Core/Constants.php';

// ── 3. PSR-4 autoloader ─────────────────────────────────────────
require_once ZYMARG_HP_PLUGIN_DIR . 'includes/Core/Loader.php';
\ZYMARGHomepage\Core\Loader::register();

// ── 4. Activation / deactivation ────────────────────────────────
register_activation_hook( __FILE__, [ \ZYMARGHomepage\Core\Plugin::class, 'activate' ] );
register_deactivation_hook( __FILE__, [ \ZYMARGHomepage\Core\Plugin::class, 'deactivate' ] );

// ── 5. Boot the plugin after all plugins have loaded ─────────────
//
// WooCommerce is a hard dependency: every product/category/seller query and
// most templates call wc_* functions. The "Requires Plugins" header covers
// WP 6.5+, but this plugin supports 6.4, so we guard explicitly. Without
// this, deactivating WooCommerce produced a white-screen fatal on the front
// end instead of a recoverable admin notice.
add_action(
    'plugins_loaded',
    static function (): void {
        if ( ! class_exists( 'WooCommerce' ) ) {
            add_action( 'admin_notices', 'zymarg_homepage_missing_wc_notice' );
            return;
        }

        \ZYMARGHomepage\Core\Plugin::get_instance();
    }
);

if ( ! function_exists( 'zymarg_homepage_missing_wc_notice' ) ) {
    /**
     * Admin notice shown when WooCommerce is missing or inactive.
     *
     * @since 1.9.5
     * @return void
     */
    function zymarg_homepage_missing_wc_notice(): void {
        if ( ! current_user_can( 'activate_plugins' ) ) {
            return;
        }

        printf(
            '<div class="notice notice-error"><p><strong>%1$s</strong> %2$s</p></div>',
            esc_html__( 'ZYMARG Homepage:', 'zymarg-homepage' ),
            esc_html__( 'WooCommerce is required but is not active. The homepage will not render until WooCommerce is installed and activated.', 'zymarg-homepage' )
        );
    }
}

// ── 6. Public PHP API ────────────────────────────────────────────

if ( ! function_exists( 'zymarg_homepage_render' ) ) {
    /**
     * Render the ZYMARG homepage and return the full HTML string.
     *
     * Public API — call from any theme template or plugin that needs to
     * embed the homepage. Equivalent to the [zymarg_homepage] shortcode.
     *
     * Returns an empty string when:
     *   – The plugin is not active.
     *   – The master switch is disabled in ZYMARG Homepage › Settings.
     *   – No sections are enabled.
     *
     * @since 1.1.0
     * @return string Homepage HTML, or empty string.
     */
    function zymarg_homepage_render(): string {
        $instance = \ZYMARGHomepage\Core\Plugin::get_instance();

        // Access the controller through a WordPress filter so third-party
        // code can hook in. The filter is intentionally named and documented.
        $controller = apply_filters(
            'zymarg_homepage_controller',
            null
        );

        // Fallback: call the shortcode handler which is always bound.
        if ( null === $controller ) {
            return do_shortcode( '[zymarg_homepage]' );
        }

        return $controller->render();
    }
}
