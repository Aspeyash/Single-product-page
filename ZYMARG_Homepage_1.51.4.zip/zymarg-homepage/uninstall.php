<?php
/**
 * ZYMARG Homepage – Uninstall Cleanup
 *
 * Executed by WordPress when the user deletes the plugin from the admin panel
 * (Plugins → Delete). Removes all database entries created by this plugin.
 *
 * IMPORTANT:
 *   • This file is loaded directly by WordPress — not via the autoloader.
 *   • Never use plugin-specific classes or constants here; they are not loaded.
 *   • Only delete data when the user has explicitly chosen to delete the plugin.
 *
 * Data removed:
 *   • zymarg_hp_section_order  — section order, toggle states, per-section settings
 *   • zymarg_hp_settings       — global plugin settings
 *   • All transients prefixed with 'zhp_'  — cached query results
 *
 * @package ZYMARGHomepage
 * @since   1.0.1
 * @version 1.1.0
 */

// WordPress sets WP_UNINSTALL_PLUGIN before including this file.
// Bail if this file is accessed directly to prevent accidental data loss.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

// ── Remove plugin options ────────────────────────────────────────
delete_option( 'zymarg_hp_section_order' );
delete_option( 'zymarg_hp_settings' );

// ── Remove all plugin transients ────────────────────────────────
global $wpdb;

// phpcs:ignore WordPress.DB.DirectDatabaseQuery
$wpdb->query(
    "DELETE FROM {$wpdb->options}
     WHERE option_name LIKE '_transient_zhp_%'
        OR option_name LIKE '_transient_timeout_zhp_%'"
);

// On multisite: clean up each site's options.
if ( is_multisite() ) {
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery
    $blog_ids = $wpdb->get_col( "SELECT blog_id FROM {$wpdb->blogs}" );

    foreach ( $blog_ids as $blog_id ) {
        switch_to_blog( (int) $blog_id );

        delete_option( 'zymarg_hp_section_order' );
        delete_option( 'zymarg_hp_settings' );

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $wpdb->query(
            "DELETE FROM {$wpdb->options}
             WHERE option_name LIKE '_transient_zhp_%'
                OR option_name LIKE '_transient_timeout_zhp_%'"
        );

        restore_current_blog();
    }
}
