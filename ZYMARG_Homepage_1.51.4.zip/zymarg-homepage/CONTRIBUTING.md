# ZYMARG Homepage — Developer Reference

> This is the single source of truth for the ZYMARG Homepage plugin.
> Read the entire document before writing a single line of code.
> If you are starting a build session with an AI assistant, paste this
> entire file as your first message. Everything needed is here.

---

## 0. Goal

The plugin generates the complete ZYMARG homepage. It is fully independent
from the active WordPress theme. No theme templates. No page builders. No
hardcoded page content inside the theme. Everything belongs inside the plugin.

---

## 1. Plugin Identity

| Field            | Value                                                    |
|------------------|----------------------------------------------------------|
| Plugin Name      | ZYMARG Homepage                                          |
| Version          | 1.0.1                                                    |
| Text Domain      | zymarg-homepage                                          |
| WordPress folder | `zymarg-homepage` (never versioned, never renamed)       |
| PHP Namespace    | `ZYMARGHomepage` (PSR-4, not procedural prefixes)        |
| Version constant | `ZYMARG_HP_VERSION` in `includes/Core/Constants.php`     |
| Bootstrap file   | `zymarg-homepage.php`                                    |

---

## 2. Version Bump — Mandatory Checklist

**Every time any file in this plugin is changed** — no matter how small — the
version must be bumped **everywhere** before the zip is packaged.

Work through this checklist in order:

- [ ] `zymarg-homepage.php` → `Version:` header line
- [ ] `includes/Core/Constants.php` → `ZYMARG_HP_VERSION` constant
- [ ] Every **changed PHP file** → `@version` doc-comment at the top
- [ ] Every **changed JS file** → `@version` comment at the top
- [ ] Every **changed CSS file** → `@version` comment at the top
- [ ] Any new function or class → add `@since X.X.X` tag
- [ ] Zip filename → `ZYMARG Homepage {version}.zip`

**Never ship two different zips with the same version number.**

### Semver convention

| Change type                                    | Bump  |
|------------------------------------------------|-------|
| Bug fix, CSS tweak, copy change                | PATCH |
| New section, feature, or admin setting         | MINOR |
| Architectural overhaul or breaking change      | MAJOR |

---

## 3. Architecture

This plugin uses a Feature-based OOP architecture. Do not create flat renderer
files at the root level. Do not use procedural functions as the primary pattern.

### Boot sequence

```
zymarg-homepage.php
  → includes/Core/Plugin.php
    → includes/Core/Loader.php
    → includes/Core/Hooks.php
    → includes/Core/Assets.php
    → includes/Homepage/HomepageController.php
      → includes/Homepage/FeatureRegistry.php
      → includes/Homepage/SectionManager.php
      → includes/Homepage/LayoutEngine.php
      → includes/Homepage/Renderer.php
```

### Feature structure

Each homepage section is a Feature. Every Feature lives in its own folder
under `includes/Features/{FeatureName}/` and contains exactly these files:

| File           | Responsibility                                                        |
|----------------|-----------------------------------------------------------------------|
| `Feature.php`  | Registers with FeatureRegistry. Defines slug, label, default order, default enabled state. Implements `FeatureInterface`. |
| `Query.php`    | All data retrieval. Implements `QueryInterface`.                      |
| `Template.php` | All HTML output. Implements `Renderable`.                             |
| `Settings.php` | Admin settings fields for this section.                               |
| `Assets.php`   | Enqueues section-specific CSS/JS conditionally — only when this section is enabled. |

### Features already scaffolded

```
includes/Features/Hero/
includes/Features/Categories/
includes/Features/FeaturedSellers/
includes/Features/ProductSections/
  └── Queries/   (one file per product section sub-type)
  └── Templates/ (one file per product section sub-type)
includes/Features/Newsletter/
includes/Features/PromoBanner/
includes/Features/Collections/
includes/Features/Brands/
includes/Features/FooterCTA/
```

### Shared layers

```
includes/Queries/          — shared query classes used across multiple features
  ProductQuery.php
  SellerQuery.php
  CategoryQuery.php
  BannerQuery.php
  CacheManager.php

includes/Interfaces/       — contracts every feature must implement
  FeatureInterface.php
  QueryInterface.php
  Renderable.php

includes/Ajax/             — AJAX handlers
  LoadMore.php
  Search.php
  Filters.php

includes/REST/
  Routes.php               — REST API endpoints

includes/Core/
  Plugin.php               — main plugin class
  Loader.php               — class autoloader
  Hooks.php                — ALL add_action / add_filter calls live here only
  Assets.php               — global asset enqueueing
  Cache.php                — query result caching wrapper
  Logger.php               — debug logging wrapper, never use error_log() directly
  Helpers.php              — shared utility functions
  Constants.php            — version constant and all design token constants
```

### Shortcode and public API

Register shortcode: `[zymarg_homepage]`
Also expose: `zymarg_homepage_render()` as a public PHP function.

Both call `HomepageController` → `LayoutEngine` → `SectionManager` which
iterates enabled features in their saved order, calls each Feature's
`Query.php` then `Template.php`, and returns the full homepage HTML.

---

## 4. Admin Panel — Full Specification

The plugin ships a complete WordPress admin panel. Every part must be built.
Nothing is optional.

### Menu structure

```
ZYMARG Homepage
  ├── Dashboard
  ├── Homepage   ← section manager
  └── Settings
```

Registered in `includes/Admin/Menu.php`. Pages rendered by `includes/Admin/Pages/`.

### Homepage section manager — three levels of control

The Homepage admin page is the heart of the admin panel. It gives the site
owner complete control over every homepage section without touching any code.

**Level 1 — Toggle (show / hide)**
Every section has a toggle switch. When toggled OFF:
- The section produces zero HTML output on the homepage.
- Its Query is never called.
- Its assets are never loaded.
- All saved settings and configuration are fully preserved.

When toggled back ON the section returns to its saved position with all
settings intact. Toggling never deletes any data.

**Level 2 — Order (drag up / drag down)**
Every section row is draggable. The site owner drags any section to any
position on the page. The saved order is the exact order sections render
on the live homepage. There is no limit to how many times order can be changed.

**Level 3 — Per-section settings**
Each section row has an expandable settings panel. The site owner configures
what that section displays without writing code. Every section defines its own
settings fields in its `Settings.php` file. Examples:

| Section      | Configurable settings                                          |
|--------------|----------------------------------------------------------------|
| Hero         | Background image, heading, subheading, CTA label, CTA URL      |
| Categories   | Number of categories to show, display style                    |
| Flash Deals  | Source category, countdown timer toggle                        |
| Newsletter   | Heading, subheading, button label, success message             |
| Promo Banner | Image URL, link URL, alt text                                  |

### How the system works technically

- `DragDrop.php` powers the drag-and-drop interface using WordPress-bundled
  jQuery UI Sortable (admin side only — vanilla JS is used on the frontend).
- On save, section order, toggle states, and per-section settings are written
  to a single WordPress option: `zymarg_hp_section_order`.
- `SectionManager.php` reads `zymarg_hp_section_order` on every homepage render
  and passes the ordered, enabled-only list to `LayoutEngine.php`.
- `LayoutEngine.php` iterates that list and calls each Feature's `Query.php`
  then `Template.php` in sequence.
- Sections toggled OFF are skipped entirely — no query, no output, no assets.

### Data storage format

`zymarg_hp_section_order` stores a serialised array. Each entry contains:

| Field      | Type   | Description                                          |
|------------|--------|------------------------------------------------------|
| `slug`     | string | Unique section identifier e.g. `hero`, `flash-deals` |
| `enabled`  | bool   | `true` = visible on homepage, `false` = hidden        |
| `order`    | int    | Position on page, 1-based                            |
| `settings` | array  | This section's own config values                     |

### Complete section slug list

Every slug below must appear in the admin drag-and-drop list.
Every one is draggable. Every one is togglable. Every one has its own
settings panel.

```
hero
categories
featured-products
trending-products
best-sellers
flash-deals
new-arrivals
recommended
recently-viewed
featured-sellers
promo-banner
collections
brands
newsletter
footer-cta
```

**Note on ProductSections:** the seven product section types
(`featured-products`, `trending-products`, `best-sellers`, `flash-deals`,
`new-arrivals`, `recommended`, `recently-viewed`) each appear as their own
independent draggable and togglable row in the admin. They share code under
`includes/Features/ProductSections/` but behave as fully independent sections
for all ordering and toggling purposes. For example: Flash Deals at position 2
and New Arrivals at position 9, independently.

### Global Settings page

`includes/Admin/Pages/Settings.php` handles:
- Master switch — enable or disable all plugin output globally
- Default number of products per section
- Cache duration in minutes
- Any future global configuration

---

## 5. Design Tokens — Non-Negotiable

All visual values (colours, spacing, radii, shadows, animation durations) are
defined in two mirrored files. **Never hard-code a hex, px, or ms value anywhere else.**

| Layer | File                                      |
|-------|-------------------------------------------|
| CSS   | `assets/css/frontend/zymarg-tokens.css`   |
| PHP   | `includes/Core/Constants.php`             |

If a token value changes, update **both files** and bump the version.

### Brand colours

| CSS Variable              | Value     | Usage                       |
|---------------------------|-----------|-----------------------------|
| `--zhp-color-primary`     | `#9500A5` | CTAs, links, active states  |
| `--zhp-color-secondary`   | `#BD00D1` | Gradient mid-stop           |
| `--zhp-color-accent`      | `#FEA9FF` | Highlights, badges          |
| `--zhp-color-dark`        | `#36003D` | Headings, overlays          |
| `--zhp-color-body-text`   | `#534152` | Paragraph text              |
| `--zhp-color-border`      | `#D8BFD3` | Dividers, input borders     |
| `--zhp-color-background`  | `#FAF5FB` | Page background             |
| `--zhp-color-surface`     | `#FFFFFF` | Card / modal backgrounds    |
| `--zhp-color-container`   | `#EAEDFF` | Subtle section fills        |

Primary gradient → `135deg · #9500A5 0% · #BD00D1 60% · #FEA9FF 130%`

### All token categories

```
Colors            --zhp-color-*
Gradients         --zhp-gradient-*
Typography        --zhp-font-*         Inter Variable, sizes 10px–30px, weights 500–800
Spacing scale     --zhp-space-*        2px through 64px
Container         --zhp-container-*    max-width 1280px
Grid gaps         --zhp-gap-*          grid 32px, card 16px, small 12px, tiny 8px
Border radius     --zhp-radius-*       cards 16px, buttons 12px, inputs 14px, badges 9999px
Button styles     --zhp-btn-*
Input styles      --zhp-input-*
Shadows           --zhp-shadow-*
Image rules       --zhp-img-*          object-cover, radius 16px, hover scale 1.05
Animations        --zhp-anim-*         fast 100ms, input 180ms, standard 300ms
```

### Utility classes already defined in zymarg-tokens.css

Use these in templates before writing any new CSS:

```
.zhp-container
.zhp-btn-primary
.zhp-btn-secondary
.zhp-card
.zhp-card-image
.zhp-badge
.zhp-input
.zhp-text-gradient
```

---

## 6. Style Principles

Every template, component, and admin screen must follow these nine principles:

1. **Large white surfaces** — cards and sections feel open, never cramped.
2. **Soft shadows** — use `--zhp-shadow-card` / `--zhp-shadow-hover`; never harsh drop-shadows.
3. **Large rounded corners** — minimum 12px on interactive elements, 16px on cards and images.
4. **Purple gradient highlights** — use `--zhp-gradient-primary` for primary actions and hero accents.
5. **Comfortable whitespace** — follow the spacing scale; never compress sections.
6. **Minimal layout** — no visual noise; every element earns its place.
7. **Premium appearance** — Inter Variable only; weights 500–800 only.
8. **Consistent spacing** — use `--zhp-space-*` variables; never ad-hoc pixel values.
9. **Smooth hover animations** — `transition` duration `300ms ease-in-out` on cards and images.

---

## 7. File, Folder, and Naming Rules

- WordPress plugin folder is always `zymarg-homepage` — **never versioned**.
- Class files use `PascalCase.php`; template output files use `kebab-case.php`.
- CSS and JS files use `kebab-case`.
- PHP namespace matches folder path: `ZYMARGHomepage\Features\Hero\Feature`
- All frontend HTML element classes use the `zhp-` prefix to prevent theme conflicts.
- Enqueue global assets through `includes/Core/Assets.php` only.
- Enqueue feature assets through each Feature's `Assets.php` only — conditionally.
- Never call `wp_enqueue_*` from a template file.
- All query logic lives in `includes/Queries/` or a Feature's `Query.php` — never in templates.
- All `add_action` and `add_filter` calls live in `includes/Core/Hooks.php` only.

---

## 8. Assets

```
assets/css/frontend/   public-facing stylesheets
assets/css/admin/      admin-only stylesheets
assets/js/frontend/    public-facing scripts
assets/js/admin/       admin-only scripts
assets/images/         plugin-owned images
assets/icons/          plugin-owned icons
assets/fonts/          plugin-owned fonts
```

No inline `<style>` blocks in HTML output.
No inline `<script>` blocks in HTML output.
**Exception:** PHP-generated CSS custom property overrides set on a wrapper
element are permitted when values come from admin-saved settings
(e.g. a custom hero image URL). Must be escaped with `esc_attr()`.

---

## 9. JavaScript Rules

- Vanilla JavaScript on the frontend. No jQuery on the frontend.
- One responsibility per JS file.
- Use `data-*` attributes for PHP-to-JS communication — not inline `onclick` handlers.
- jQuery UI Sortable (WordPress-bundled) is permitted in the admin panel only.

---

## 10. Responsive Breakpoints

| Breakpoint | Range               | Container padding |
|------------|---------------------|-------------------|
| Mobile     | up to 767px         | 16px              |
| Tablet     | 768px – 1023px      | 24px              |
| Laptop     | 1024px – 1279px     | 24px              |
| Desktop    | 1280px and above    | 32px              |

Use `.zhp-container` on all section wrappers.

---

## 11. Performance

- Lazy load all images with `loading="lazy"` and explicit `width` and `height` attributes.
- Minimise DOM depth.
- No duplicated CSS rules.
- Avoid layout shift on load.
- Feature CSS and JS load only when that feature is enabled.
- Sections toggled OFF generate zero HTML output and load zero assets.

---

## 12. Accessibility

- Semantic HTML throughout.
- Keyboard navigation on all interactive elements.
- ARIA attributes where native semantics are insufficient.
- Visible focus states using `--zhp-input-focus-ring` (`rgba(149,0,165,0.15)`).
- Correct heading hierarchy within each section.
- Alt text on all images.

---

## 13. WordPress Standards

- Follow WordPress coding standards throughout.
- Escape all output: `esc_html()`, `esc_attr()`, `esc_url()`, `wp_kses_post()`.
- Sanitize all input and all data read from the database before use.
- Use translation functions on all user-facing strings. Text domain: `zymarg-homepage`.
- Nonce-protect all AJAX calls and form submissions.

---

## 14. Adding a New Feature Section

1. Create `includes/Features/{FeatureName}/` with all five files:
   `Feature.php`, `Query.php`, `Template.php`, `Settings.php`, `Assets.php`
2. Register it in `includes/Homepage/FeatureRegistry.php`.
3. Add its slug to the default order array in `SectionManager.php`.
4. Add its template to `templates/features/` if it needs a standalone file.
5. The section will automatically appear in the admin drag-and-drop list
   with its own toggle switch and settings panel.
6. Bump the version (MINOR).

**A section is not considered done until it has a working toggle, a draggable
admin row, and a functional settings panel. All three are required.**

---

## 15. Build Phases — Follow This Order

### Phase 1 — Core Foundation
Plugin boots cleanly. Activates and deactivates without errors. Nothing visible yet.

Files: `zymarg-homepage.php`, `Core/Plugin.php`, `Core/Loader.php`,
`Core/Hooks.php`, `Core/Assets.php`, `Core/Helpers.php`, `Core/Cache.php`,
`Core/Logger.php`, `uninstall.php`

Goal: Plugin appears in WordPress plugin list with correct name and version. No PHP errors.

### Phase 2 — Homepage Engine
The rendering engine. No actual sections yet, just the system that will run them.

Files: All three Interfaces, `FeatureRegistry.php`, `SectionManager.php`,
`LayoutEngine.php`, `HomepageController.php`, `Renderer.php`,
shortcode registration, `zymarg_homepage_render()`, `templates/homepage.php`

Goal: `[zymarg_homepage]` renders an empty page wrapper with correct HTML and CSS classes. No errors.

### Phase 3 — Admin Panel
Full admin panel before any section exists. The section list structure must
work with empty slots so sections can be managed as they are added in Phase 5.

Files: `Admin.php`, `Menu.php`, `Admin/Assets.php`, `Settings.php`,
`DragDrop.php`, `Pages/Dashboard.php`, `Pages/Homepage.php`, `Pages/Settings.php`,
admin CSS and JS

Goal: Admin menu visible. Drag-and-drop list renders. Toggle switches work.
Section order saves and reads correctly from `zymarg_hp_section_order`.

### Phase 4 — Shared Query Layer
All shared data classes built and tested before any Feature needs them.

Files: `ProductQuery.php`, `SellerQuery.php`, `CategoryQuery.php`,
`BannerQuery.php`, `CacheManager.php`

Goal: All query classes return correct data from WooCommerce and Dokan. Caching works.

### Phase 5 — Features, one by one
Build each Feature as a complete unit before starting the next. After each
Feature confirm: renders correctly on desktop and mobile, respects design
tokens, toggles on/off from admin, reorders correctly from admin.

Recommended build order:
```
5a.  Hero
5b.  Categories
5c.  ProductSections — build one sub-type at a time:
       Featured Products → Trending → Best Sellers → Flash Deals
       → New Arrivals → Recommended → Recently Viewed
5d.  FeaturedSellers
5e.  PromoBanner
5f.  Collections
5g.  Brands
5h.  Newsletter
5i.  FooterCTA
```

### Phase 6 — AJAX and REST
`LoadMore.php`, `Search.php`, `Filters.php`, `REST/Routes.php`

Goal: Load more on product sections works. Search and filter interactions work.
REST endpoints respond correctly.

### Phase 7 — Polish and Production Readiness
Accessibility audit · Performance audit · Responsive check across all four
breakpoints · Minify CSS and JS · Clear all `console.log`, `var_dump`,
`error_log` · Write `changelog.md` entries · Update `readme.md` ·
Final version bump · Package zip.

---

## 16. Packaging Checklist

Before handing over or deploying any zip:

- [ ] Version bumped everywhere (Section 2)
- [ ] No `console.log`, `var_dump`, or `error_log` left in production code
- [ ] All assets minified (or clearly noted as dev builds)
- [ ] `changelog.md` updated with the new version entry and change summary
- [ ] `readme.md` "Tested up to" WordPress version is current
- [ ] Zip named exactly: `ZYMARG Homepage {X.X.X}.zip`
- [ ] Zip root folder extracts as `zymarg-homepage/` — never `zymarg-homepage-1.0.1/`

---

## 17. What Not To Do

- Do not create flat renderer files (e.g. `HeroRenderer.php`) outside the Feature folder structure.
- Do not use procedural `zymarg_homepage_` prefixes as the primary code pattern.
- Do not hard-code any colour, spacing, radius, shadow, or animation value — look it up in the tokens.
- Do not enqueue assets from template files.
- Do not put query logic inside template files.
- Do not use jQuery on the frontend.
- Do not use inline `<style>` or `<script>` blocks in HTML output (see the permitted exception in Section 8).
- Do not version the plugin folder name.
- Do not ship a zip without bumping the version everywhere.
- Do not introduce any design value not present in the ZYMARG Design Tokens.
- Do not consider a section done until it has a working toggle, a draggable admin row, and a functional settings panel. All three are required.

---

*ZYMARG Design Tokens v1.1 · Plugin bootstrap: ZYMARG Homepage v1.0.1*
