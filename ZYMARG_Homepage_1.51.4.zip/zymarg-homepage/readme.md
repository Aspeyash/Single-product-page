# ZYMARG Homepage

**Version:** 1.46.2
**Requires WordPress:** 6.4+  
**Requires PHP:** 8.1+  
**License:** Proprietary — © ZYMARG. All rights reserved.

---

## Overview

ZYMARG Homepage is a self-contained WordPress plugin that generates the complete ZYMARG marketplace homepage. It renders directly into `wp_head` / `wp_footer` without relying on the active theme's templates, page builders, or hardcoded page content. Every section is independently enabled, ordered, and configured from the WordPress admin panel.

---

## Requirements

| Dependency | Minimum version |
|---|---|
| WordPress | 6.4 |
| PHP | 8.1 |
| WooCommerce | 8.0 |
| Dokan (multivendor) | 3.8 |

---

## Installation

1. Upload the `zymarg-homepage` folder to `/wp-content/plugins/`.
2. Activate the plugin via **Plugins → Installed Plugins**.
3. Navigate to **ZYMARG → Homepage** in the admin sidebar.
4. Enable the sections you want, drag them into order, and save.

---

## Homepage Sections

All nine sections ship enabled by default. Each can be individually toggled and reordered.

| Section | Slug | Description |
|---|---|---|
| Hero | `hero` | Full-width banner with heading, subtext, and dual CTAs. |
| Categories | `categories` | Product category grid pulled from WooCommerce. |
| Best Sellers | `best-seller-products` | Top-selling products sorted by total sales. |
| New Arrivals | `new-arrivals` | Most recently published products. |
| Featured Products | `featured-products` | Products marked Featured in WooCommerce. |
| Flash Deals | `flash-deals` | On-sale products with a live countdown timer. |
| Trending | `trending-products` | High-view-count products (requires WooCommerce analytics). |
| Recently Viewed | `recently-viewed` | Personalised list from the visitor's session. |
| Recommended | `recommended` | Upsell/cross-sell products from the visitor's last purchase. |
| Featured Sellers | `featured-sellers` | Dokan seller cards with avatar, rating, and product count. |
| Promo Banner | `promo-banner` | Full-width image banner with optional overlay title and CTA. |
| Collections | `collections` | Curated category collections with cover images. |
| Brands | `brands` | Brand logo grid linking to brand archive pages. |
| Newsletter | `newsletter` | AJAX-powered email capture with Dokan/WooCommerce hook. |
| Footer CTA | `footer-cta` | Bottom-of-page call-to-action with dual buttons. |

---

## Admin Panel

**ZYMARG → Homepage** exposes three tabs:

- **Sections** — toggle and drag-and-drop reorder all 15 section slots.
- **Settings** — per-section controls (heading text, item counts, image URLs, etc.).
- **Advanced** — cache TTL, AJAX concurrency limit, debug logging toggle.

---

## AJAX & REST Endpoints

| Type | Action / Route | Description |
|---|---|---|
| AJAX | `zhp_load_more` | Loads the next page of products for any section. |
| AJAX | `zhp_search` | Live product search with debounce. |
| AJAX | `zhp_filter` | Applies category / sort / price filters without a page reload. |
| AJAX | `zhp_newsletter` | Subscribes an email address; fires the `zhp_newsletter_subscribe` action. |
| REST | `GET /zhp/v1/products` | JSON product list (supports `type`, `page`, `per_page`). |
| REST | `GET /zhp/v1/sections` | Returns enabled section order and settings. |
| REST | `GET /zhp/v1/search` | Keyword product search. |

All AJAX handlers require a valid nonce (`zhpAjax.nonces.*`). REST routes require `read` capability.

---

## JavaScript API

The `zhpAjax` global is localised onto every page where the plugin renders:

```js
window.zhpAjax = {
  ajaxUrl:  '/wp-admin/admin-ajax.php',
  restUrl:  '/wp-json/zhp/v1/',
  nonces: {
    loadMore:   '…',
    search:     '…',
    filter:     '…',
    newsletter: '…',
  },
  i18n: {
    loadMore: 'Load More',
    loading:  'Loading…',
    noMore:   'No more products.',
    error:    'Something went wrong. Please try again.',
  },
};
```

---

## Developer Hooks

### Actions

| Hook | When it fires |
|---|---|
| `zhp_before_render` | Before the full homepage HTML is output. |
| `zhp_after_render` | After the full homepage HTML is output. |
| `zhp_newsletter_subscribe` | After a successful newsletter AJAX signup. Receives `$email`. |

### Filters

| Filter | What it controls |
|---|---|
| `zhp_section_data_{$type}` | Raw data array before a section renders. |
| `zhp_product_query_args` | WP_Query args before any product query runs. |
| `zhp_cache_ttl` | Cache lifetime in seconds (default: 3600). |
| `zhp_enabled_sections` | Ordered array of enabled section slugs. |

---

## Asset Loading

In production (`SCRIPT_DEBUG` not defined or `false`) the plugin enqueues minified assets:

```
assets/css/frontend/zymarg-tokens.min.css
assets/css/frontend/{section}.min.css
assets/js/frontend/load-more.min.js
assets/js/frontend/filters.min.js
assets/js/frontend/countdown.min.js
```

Set `define( 'SCRIPT_DEBUG', true );` in `wp-config.php` to load the unminified originals for development.

---

## Design Tokens (CSS Custom Properties)

All visual values are defined in `zymarg-tokens.css` as CSS custom properties on `:root`. Override them in your child theme's stylesheet to retheme without touching plugin files:

```css
:root {
  --zhp-color-primary: #36003D;
  --zhp-color-accent:  #FF6B00;
  --zhp-font-base:     'Inter', system-ui, sans-serif;
  /* … see zymarg-tokens.css for the full list */
}
```

---

## Accessibility

- All section landmarks are labelled with `aria-labelledby` pointing to their visible heading.
- All interactive elements expose `:focus-visible` outlines using `--zhp-color-primary` / `--zhp-color-accent`.
- All images carry explicit `width`, `height`, and `loading="lazy"` attributes to prevent layout shift.
- Screen-reader-only labels are provided for icon-only buttons and form inputs.
- Heading hierarchy is enforced: one `<h1>` (Hero), all other sections use `<h2>`.

---

## Changelog

See [changelog.md](changelog.md) for the full version history.

---

## Support

Internal plugin — contact the ZYMARG engineering team via the project Slack channel or configure a support email in **ZYMARG Homepage → Settings → Support Email**.
