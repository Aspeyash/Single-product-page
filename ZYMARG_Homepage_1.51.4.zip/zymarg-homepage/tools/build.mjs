#!/usr/bin/env node
/**
 * ZYMARG Homepage - asset build tool
 *
 * Regenerates every `*.min.css` / `*.min.js` from its unminified source so the
 * two can never drift apart again.
 *
 * WHY THIS EXISTS
 * ---------------
 * The minified assets in this plugin were hand-maintained. Because WordPress
 * loads the `.min` twin in production and the plain source only when
 * SCRIPT_DEBUG is on, any divergence between the two produced bugs that were
 * invisible in development and only ever broke live sites. Three shipped in a
 * single release cycle:
 *
 *   1. `.min` twins that did not exist at all -> stylesheet 404s.
 *   2. `zymarg-drag-drop.min.js` used the selector `.zhp-section-settings[name]`
 *      where the source correctly used `.zhp-section-settings [name]` (note the
 *      space). Result: no per-section setting ever saved in production.
 *   3. `zymarg-admin.min.css` had a comment whose opening `/*` was lost,
 *      leaving prose in the stylesheet as live tokens.
 *
 * A generated build makes all three structurally impossible.
 *
 * DESIGN: DELIBERATELY CONSERVATIVE
 * ---------------------------------
 * This has zero dependencies - it runs on a bare Node install with no network
 * access and no `npm install`. That rules out terser/cssnano, so rather than
 * attempt an aggressive minifier (easy to get subtly, dangerously wrong) it
 * performs only transformations that are provably safe:
 *
 *   CSS: strip comments, collapse whitespace runs, and remove spaces adjacent
 *        to `{ } ; ,` and after `:` inside declaration blocks. Space *before*
 *        `:` is preserved, because `.wrap :focus` (descendant pseudo-element)
 *        means something different from `.wrap:focus`.
 *
 *   JS:  strip comments, strip indentation and blank lines - but preserve every
 *        newline. Because no line is ever joined to another, Automatic
 *        Semicolon Insertion behaviour cannot change. This gives up perhaps ten
 *        percent of the savings a real minifier would achieve in exchange for
 *        being unable to corrupt the program.
 *
 * Both use a character scanner that understands string literals, template
 * literals and (for JS) regex literals, so nothing inside a string is ever
 * touched.
 *
 * If you later want true minification, install terser and clean-css on a
 * networked machine and swap the two `minify*` functions - the file discovery,
 * drift checking and reporting all stay as they are.
 *
 * USAGE
 * -----
 *   node tools/build.mjs            Rebuild every .min asset in place.
 *   node tools/build.mjs --check    Verify .min assets match source. Exit 1 if
 *                                   any are stale. Use this in CI.
 *   node tools/build.mjs --dry-run  Show what would change, write nothing.
 *   node tools/build.mjs --report   Also list tokens present in the existing
 *                                   .min file but absent from a fresh build,
 *                                   i.e. hand-edits that would be lost.
 *
 * @package ZYMARGHomepage
 * @since   1.12.0
 */

import { readdir, readFile, writeFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { dirname, extname, join, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = resolve( dirname( fileURLToPath( import.meta.url ) ), '..' );
const ASSETS = join( ROOT, 'assets' );

const args = new Set( process.argv.slice( 2 ) );
const CHECK = args.has( '--check' );
const DRY = args.has( '--dry-run' );
const REPORT = args.has( '--report' );

/* ------------------------------------------------------------------ *
 * Scanner primitives
 * ------------------------------------------------------------------ */

/**
 * Decide whether a `/` at index i begins a regex literal rather than division.
 *
 * Looks backwards past whitespace for the previous significant character. If it
 * is an operator, an opening bracket, or the end of a keyword like `return`,
 * then a regex can legally start here. This is the standard heuristic and is
 * sufficient for hand-written source; it errs toward treating `/` as division,
 * which is the safe direction because a mis-detected regex could swallow code.
 *
 * @param {string} src
 * @param {number} i Index of the `/`.
 * @return {boolean}
 */
function regexAllowedAt( src, i ) {
	let j = i - 1;
	while ( j >= 0 && /\s/.test( src[ j ] ) ) {
		j--;
	}
	if ( j < 0 ) {
		return true;
	}
	const c = src[ j ];
	if ( '(,=:[!&|?{};+-*%~^<>'.includes( c ) ) {
		return true;
	}
	// `return /re/`, `typeof /re/`, `case /re/` etc.
	const word = /[A-Za-z_$]+$/.exec( src.slice( 0, j + 1 ) );
	return !! word && [ 'return', 'typeof', 'case', 'in', 'of', 'delete', 'void', 'instanceof', 'new', 'do', 'else', 'yield', 'await' ].includes( word[ 0 ] );
}

/**
 * Split source into a list of segments, each flagged as code or literal.
 *
 * Literal segments (strings, template literals, regexes) are passed through
 * untouched by every later transformation. Comments are dropped here.
 *
 * @param {string} src
 * @param {'css'|'js'} lang
 * @return {Array<{ text: string, literal: boolean }>}
 */
function tokenize( src, lang ) {
	const out = [];
	let buf = '';
	const pushCode = () => {
		if ( buf ) {
			out.push( { text: buf, literal: false } );
			buf = '';
		}
	};

	for ( let i = 0; i < src.length; i++ ) {
		const c = src[ i ];
		const next = src[ i + 1 ];

		// Block comment.
		if ( c === '/' && next === '*' ) {
			const end = src.indexOf( '*/', i + 2 );
			i = end === -1 ? src.length : end + 1;
			continue;
		}

		// Line comment (JS only - CSS has none).
		if ( lang === 'js' && c === '/' && next === '/' ) {
			const end = src.indexOf( '\n', i );
			if ( end === -1 ) {
				i = src.length;
			} else {
				i = end - 1; // Preserve the newline itself.
			}
			continue;
		}

		// String and template literals.
		if ( c === '"' || c === "'" || ( lang === 'js' && c === '`' ) ) {
			pushCode();
			let lit = c;
			let j = i + 1;
			for ( ; j < src.length; j++ ) {
				lit += src[ j ];
				if ( src[ j ] === '\\' ) {
					lit += src[ ++j ] ?? '';
					continue;
				}
				if ( src[ j ] === c ) {
					break;
				}
			}
			out.push( { text: lit, literal: true } );
			i = j;
			continue;
		}

		// Regex literal.
		if ( lang === 'js' && c === '/' && regexAllowedAt( src, i ) ) {
			let lit = '/';
			let j = i + 1;
			let inClass = false;
			let closed = false;
			for ( ; j < src.length; j++ ) {
				const d = src[ j ];
				lit += d;
				if ( d === '\\' ) {
					lit += src[ ++j ] ?? '';
					continue;
				}
				if ( d === '\n' ) {
					break; // Not a regex after all.
				}
				if ( d === '[' ) {
					inClass = true;
				} else if ( d === ']' ) {
					inClass = false;
				} else if ( d === '/' && ! inClass ) {
					closed = true;
					break;
				}
			}
			if ( closed ) {
				// Trailing flags.
				while ( j + 1 < src.length && /[a-z]/.test( src[ j + 1 ] ) ) {
					lit += src[ ++j ];
				}
				pushCode();
				out.push( { text: lit, literal: true } );
				i = j;
				continue;
			}
		}

		buf += c;
	}

	pushCode();
	return out;
}

/* ------------------------------------------------------------------ *
 * CSS
 * ------------------------------------------------------------------ */

/**
 * Minify CSS: comments out, whitespace collapsed, safe punctuation tightening.
 *
 * Brace depth is tracked so that space after `:` is only removed inside a
 * declaration block. At depth 0 a `:` is part of a selector, where surrounding
 * whitespace is semantically significant.
 *
 * @param {string} src
 * @return {string}
 */
function minifyCss( src ) {
	const parts = tokenize( src, 'css' );
	let out = '';
	let depth = 0;

	for ( const part of parts ) {
		if ( part.literal ) {
			out += part.text;
			continue;
		}

		let text = part.text.replace( /\s+/g, ' ' );

		let chunk = '';
		for ( let i = 0; i < text.length; i++ ) {
			const c = text[ i ];

			if ( c === '{' ) {
				depth++;
				chunk = chunk.replace( /\s+$/, '' ) + '{';
				continue;
			}
			if ( c === '}' ) {
				depth = Math.max( 0, depth - 1 );
				chunk = chunk.replace( /[\s;]+$/, '' ) + '}';
				continue;
			}
			if ( c === ';' ) {
				chunk = chunk.replace( /\s+$/, '' ) + ';';
				continue;
			}
			if ( c === ',' ) {
				chunk = chunk.replace( /\s+$/, '' ) + ',';
				continue;
			}
			if ( c === ' ' ) {
				const prev = chunk[ chunk.length - 1 ];
				// Never emit a leading space, or one right after punctuation we
				// have already tightened.
				if ( prev === undefined || '{};,'.includes( prev ) ) {
					continue;
				}
				if ( prev === ':' && depth > 0 ) {
					continue;
				}
				chunk += ' ';
				continue;
			}
			chunk += c;
		}
		out += chunk;
	}

	return out.replace( /\s+/g, ' ' ).trim();
}

/* ------------------------------------------------------------------ *
 * JS
 * ------------------------------------------------------------------ */

/**
 * Minify JS conservatively: drop comments, indentation and blank lines while
 * preserving every newline, so ASI behaviour is bit-for-bit unchanged.
 *
 * @param {string} src
 * @return {string}
 */
function minifyJs( src ) {
	const parts = tokenize( src, 'js' );

	// Rebuild with placeholders so line handling cannot touch literals.
	const literals = [];
	let stitched = '';
	for ( const part of parts ) {
		if ( part.literal ) {
			stitched += `\u0000${ literals.push( part.text ) - 1 }\u0000`;
		} else {
			stitched += part.text;
		}
	}

	const body = stitched
		.split( '\n' )
		.map( ( line ) => line.replace( /[ \t]+/g, ' ' ).trim() )
		.filter( ( line ) => line !== '' )
		.join( '\n' );

	return body.replace( /\u0000(\d+)\u0000/g, ( _m, n ) => literals[ Number( n ) ] );
}

/* ------------------------------------------------------------------ *
 * Build
 * ------------------------------------------------------------------ */

/**
 * Recursively collect buildable source files under assets/.
 *
 * @param {string} dir
 * @return {Promise<string[]>}
 */
async function collect( dir ) {
	const found = [];
	for ( const entry of await readdir( dir, { withFileTypes: true } ) ) {
		const full = join( dir, entry.name );
		if ( entry.isDirectory() ) {
			found.push( ...( await collect( full ) ) );
			continue;
		}
		const ext = extname( entry.name );
		if ( ( ext !== '.css' && ext !== '.js' ) || entry.name.includes( '.min.' ) ) {
			continue;
		}
		found.push( full );
	}
	return found.sort();
}

/**
 * Identifiers used for drift reporting: class names, custom properties,
 * at-rules and bare words. Lets us spot content that exists only in the
 * hand-written .min file and would be lost by regenerating it.
 *
 * @param {string} text
 * @return {Set<string>}
 */
function tokensOf( text ) {
	return new Set( text.match( /[A-Za-z_$@-][A-Za-z0-9_$-]{2,}/g ) ?? [] );
}

const banner = ( name, ext ) => {
	const note = `${ name } | generated by tools/build.mjs - do not edit, edit the source instead`;
	return ext === '.css' ? `/* ${ note } */` : `/* ${ note } */\n`;
};

async function main() {
	if ( ! existsSync( ASSETS ) ) {
		console.error( `No assets directory at ${ ASSETS }` );
		process.exit( 2 );
	}

	const sources = await collect( ASSETS );
	const stale = [];
	const created = [];
	const unchanged = [];
	const driftNotes = [];
	let savedFrom = 0;
	let savedTo = 0;

	for ( const src of sources ) {
		const ext = extname( src );
		const target = src.replace( new RegExp( `\\${ ext }$` ), `.min${ ext }` );
		const rel = relative( ROOT, src );
		const relTarget = relative( ROOT, target );
		const code = await readFile( src, 'utf8' );

		const built =
			banner( relTarget, ext ) +
			( ext === '.css' ? minifyCss( code ) : minifyJs( code ) ) +
			'\n';

		savedFrom += Buffer.byteLength( code );
		savedTo += Buffer.byteLength( built );

		const exists = existsSync( target );
		const current = exists ? await readFile( target, 'utf8' ) : null;

		if ( ! exists ) {
			created.push( relTarget );
		} else if ( current === built ) {
			unchanged.push( relTarget );
		} else {
			stale.push( relTarget );
		}

		// Drift report: what does the existing .min contain that a fresh build
		// of the source does not? Anything listed here is a hand-edit that only
		// ever existed in the minified file.
		if ( REPORT && current ) {
			const only = [ ...tokensOf( current ) ].filter(
				( t ) => ! tokensOf( built ).has( t )
			);
			if ( only.length ) {
				driftNotes.push( { file: relTarget, only } );
			}
		}

		if ( ! CHECK && ! DRY && current !== built ) {
			await writeFile( target, built, 'utf8' );
		}
	}

	const pct = savedFrom ? Math.round( ( 1 - savedTo / savedFrom ) * 100 ) : 0;

	console.log( `sources        ${ sources.length }` );
	console.log( `up to date     ${ unchanged.length }` );
	console.log( `stale          ${ stale.length }` );
	console.log( `missing        ${ created.length }` );
	console.log( `total size     ${ savedFrom } -> ${ savedTo } bytes (${ pct }% smaller)` );

	if ( created.length ) {
		console.log( `\nmissing .min twins:` );
		created.forEach( ( f ) => console.log( `  + ${ f }` ) );
	}
	if ( stale.length ) {
		console.log( `\nout of sync with source:` );
		stale.forEach( ( f ) => console.log( `  ~ ${ f }` ) );
	}
	if ( driftNotes.length ) {
		console.log( `\ntokens present only in the existing .min file:` );
		for ( const note of driftNotes ) {
			console.log( `  ${ note.file }` );
			console.log( `    ${ note.only.slice( 0, 40 ).join( ' ' ) }` );
			if ( note.only.length > 40 ) {
				console.log( `    ... and ${ note.only.length - 40 } more` );
			}
		}
	}

	if ( CHECK && ( stale.length || created.length ) ) {
		console.error(
			`\nFAIL: ${ stale.length + created.length } asset(s) do not match source. Run: node tools/build.mjs`
		);
		process.exit( 1 );
	}

	if ( CHECK ) {
		console.log( `\nOK: every .min asset matches its source.` );
	} else if ( DRY ) {
		console.log( `\nDry run - nothing written.` );
	} else {
		console.log( `\nWrote ${ stale.length + created.length } file(s).` );
	}
}

main().catch( ( err ) => {
	console.error( err );
	process.exit( 2 );
} );
