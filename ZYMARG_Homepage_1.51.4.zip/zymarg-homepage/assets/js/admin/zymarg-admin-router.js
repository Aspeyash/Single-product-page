/**
 * ZYMARG Homepage – Admin AJAX Router
 *
 * Turns the plugin's admin area into a single-page app. Clicks on the
 * WordPress submenu items (Dashboard, Homepage, Settings, Help) and on
 * in-page links between those screens are intercepted, the target screen is
 * fetched over admin-ajax.php, and the content is swapped in place.
 *
 * Deliberate behaviours:
 *
 *   • Only this plugin's own screens are intercepted. A link to any other
 *     part of wp-admin is left completely alone, so the rest of the admin
 *     keeps working normally.
 *
 *   • Any failure falls back to a real page load rather than showing an
 *     error. An expired nonce, a PHP error or a lost connection therefore
 *     degrades to exactly the behaviour the admin had before this file
 *     existed — the click always ends up somewhere useful.
 *
 *   • Modified clicks (Ctrl, Cmd, Shift, middle mouse) and links with a
 *     target are ignored, so "open in new tab" still works.
 *
 *   • The URL is kept in sync with history.pushState and Back/Forward are
 *     handled, so the browser buttons and bookmarking behave as expected.
 *
 *   • After every swap a `zhp:admin:loaded` event is dispatched on the
 *     document. Scripts that bind directly to elements (the section
 *     sortable, the dashboard status poll) listen for it and re-initialise,
 *     because those elements are new nodes after a swap.
 *
 * @package ZYMARGHomepage
 * @since   1.19.0
 * @version 1.37.0
 */

( function ( $ ) {
    'use strict';

    if ( typeof zhpRouter === 'undefined' || ! zhpRouter.ajaxUrl ) {
        return;
    }

    const CONTAINER = '.wrap.zhp-admin-wrap';
    const slugs     = zhpRouter.slugs || [];
    const i18n      = zhpRouter.i18n  || {};

    let busy = false;

    // ── Helpers ────────────────────────────────────────────────

    /**
     * Return the plugin page slug a URL points at, or '' if it is not one
     * of this plugin's screens.
     *
     * @param {string} href Absolute or relative URL.
     * @return {string} Allowlisted slug, or empty string.
     */
    function slugFromHref( href ) {
        if ( ! href ) {
            return '';
        }

        let url;

        try {
            url = new URL( href, window.location.origin );
        } catch ( e ) {
            return '';
        }

        // Same origin only, and only the admin.php entry point.
        if ( url.origin !== window.location.origin ) {
            return '';
        }

        if ( url.pathname.indexOf( 'admin.php' ) === -1 ) {
            return '';
        }

        const page = url.searchParams.get( 'page' ) || '';

        return slugs.indexOf( page ) !== -1 ? page : '';
    }

    /**
     * Give up on AJAX and let the browser load the page normally.
     *
     * @param {string} href Destination.
     */
    function hardNav( href ) {
        window.location.href = href;
    }

    /**
     * Move the "current" highlight in the WordPress submenu.
     *
     * Scoped to this plugin's own submenu so no other menu's state is
     * touched.
     *
     * @param {string} slug Newly active slug.
     */
    function highlight( slug ) {
        const $anyLink = $( '#adminmenu' ).find( 'a' ).filter( function () {
            return slugFromHref( this.href ) !== '';
        } );

        if ( ! $anyLink.length ) {
            return;
        }

        const $submenu = $anyLink.first().closest( '.wp-submenu' );

        $submenu.find( 'li' ).removeClass( 'current' );
        $submenu.find( 'a' ).removeClass( 'current' ).removeAttr( 'aria-current' );

        const $target = $submenu.find( 'a' ).filter( function () {
            return slugFromHref( this.href ) === slug;
        } ).first();

        $target.addClass( 'current' )
               .attr( 'aria-current', 'page' )
               .closest( 'li' ).addClass( 'current' );
    }

    /**
     * Update the browser tab title, keeping the WordPress suffix intact.
     *
     * WordPress titles look like "Settings – ZYMARG Homepage ‹ Site —
     * WordPress". Only the part before the ‹ belongs to the screen.
     *
     * @param {string} pageTitle Submenu label of the new screen.
     */
    function setTitle( pageTitle ) {
        if ( ! pageTitle ) {
            return;
        }

        const sep   = ' \u2039 ';
        const parts = document.title.split( sep );
        const brand = zhpRouter.brand || 'ZYMARG Homepage';

        parts[ 0 ]     = pageTitle + ' \u2013 ' + brand;
        document.title = parts.join( sep );
    }

    /**
     * Swap in the new screen and re-initialise page scripts.
     *
     * outerHTML is used rather than jQuery insertion so that any inline
     * markup in the response is parsed by the browser exactly as it would
     * be on a normal page load, and so leading whitespace in the response
     * cannot break parsing.
     *
     * @param {Object} data Response payload: slug, title, html.
     */
    function swap( data ) {
        const host = document.querySelector( CONTAINER );

        if ( ! host ) {
            return false;
        }

        host.outerHTML = data.html;

        highlight( data.slug );
        setTitle( data.title );

        window.scrollTo( 0, 0 );

        // Move focus to the new heading so keyboard and screen-reader users
        // land on the new content instead of staying on a removed node.
        const heading = document.querySelector( CONTAINER + ' h1' );

        if ( heading ) {
            heading.setAttribute( 'tabindex', '-1' );
            heading.focus( { preventScroll: true } );
        }

        $( document ).trigger( 'zhp:admin:loaded', [ data.slug ] );

        return true;
    }

    /**
     * Fetch and display a plugin screen.
     *
     * @param {string}  slug Allowlisted plugin page slug.
     * @param {string}  href URL to show in the address bar / fall back to.
     * @param {boolean} push Whether to add a history entry.
     */
    function navigate( slug, href, push ) {
        if ( busy ) {
            return;
        }

        busy = true;

        const $host = $( CONTAINER ).first();

        $host.addClass( 'zhp-router-loading' ).attr( 'aria-busy', 'true' );
        $( 'body' ).addClass( 'zhp-router-busy' );

        $.post(
            zhpRouter.ajaxUrl,
            {
                action: 'zhp_admin_page',
                nonce:  zhpRouter.nonce,
                slug:   slug
            }
        ).done( function ( response ) {
            if ( ! response || ! response.success || ! response.data || ! response.data.html ) {
                hardNav( href );
                return;
            }

            if ( ! swap( response.data ) ) {
                hardNav( href );
                return;
            }

            if ( push && window.history && window.history.pushState ) {
                window.history.pushState( { zhpSlug: slug }, '', href );
            }

            busy = false;
            $( 'body' ).removeClass( 'zhp-router-busy' );
        } ).fail( function () {
            // Nonce expiry, PHP error, dropped connection — do the thing the
            // user asked for the slow way rather than showing an error.
            hardNav( href );
        } );
    }

    // ── Link interception ─────────────────────────────────────────

    $( document ).on( 'click', 'a[href]', function ( event ) {
        // Let the browser handle modified clicks and new-tab intents.
        if ( event.which === 2 || event.metaKey || event.ctrlKey ||
             event.shiftKey || event.altKey || event.defaultPrevented ) {
            return;
        }

        if ( this.getAttribute( 'target' ) || this.hasAttribute( 'download' ) ) {
            return;
        }

        const slug = slugFromHref( this.href );

        if ( ! slug ) {
            return;
        }

        // Already here — nothing to fetch.
        if ( slug === currentSlug() && ! busy ) {
            event.preventDefault();
            return;
        }

        event.preventDefault();
        navigate( slug, this.href, true );
    } );

    /**
     * The slug currently shown, taken from the address bar.
     *
     * @return {string}
     */
    function currentSlug() {
        return slugFromHref( window.location.href );
    }

    // ── Back / Forward ────────────────────────────────────────────

    $( window ).on( 'popstate', function () {
        const slug = currentSlug();

        if ( ! slug ) {
            // Stepped outside the plugin's screens — let WordPress render it.
            window.location.reload();
            return;
        }

        busy = false;
        navigate( slug, window.location.href, false );
    } );

    /*
     * Expose the router so other admin scripts can re-render a screen in
     * place. Reset to Defaults used to call window.location.reload(), which
     * threw away the single-page behaviour the rest of the admin has.
     *
     * @since 1.37.0
     */
    window.zhpAdminRouter = {
        navigate: function ( slug ) {
            busy = false;
            navigate( slug || currentSlug(), window.location.href, false );
        },
        currentSlug: currentSlug
    };

    // Seed the first history entry so the first Back press has a state to
    // return to rather than falling through to a reload.
    if ( window.history && window.history.replaceState && currentSlug() ) {
        window.history.replaceState(
            { zhpSlug: currentSlug() },
            '',
            window.location.href
        );
    }

} )( jQuery );
