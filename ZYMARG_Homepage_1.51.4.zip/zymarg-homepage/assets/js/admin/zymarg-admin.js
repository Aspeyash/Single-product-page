/**
 * ZYMARG Homepage – Admin Base Script
 *
 * Shared admin behaviour:
 *   • expand/collapse section settings panels
 *   • toggle switch label updates
 *   • settings form AJAX save
 *   • dashboard status AJAX load
 *
 * All user-facing strings come from zhpAdmin.i18n (localised via
 * wp_localize_script in Admin/Assets.php). No hardcoded English strings.
 *
 * Uses jQuery (WordPress admin bundle). Admin-only — never loaded on frontend.
 *
 * @package ZYMARGHomepage
 * @since   1.3.0
 * @version 1.42.0
 */

( function ( $ ) {
    'use strict';

    const i18n    = ( typeof zhpAdmin !== 'undefined' && zhpAdmin.i18n )    ? zhpAdmin.i18n    : {};
    const ajaxUrl = ( typeof zhpAdmin !== 'undefined' && zhpAdmin.ajaxUrl ) ? zhpAdmin.ajaxUrl : '';

    // ── Expand / collapse section settings panels ────────────────

    $( document ).on( 'click', '.zhp-expand-btn', function () {
        const $btn    = $( this );
        const panelId = $btn.attr( 'aria-controls' );
        const $panel  = $( '#' + panelId );
        const isOpen  = $btn.attr( 'aria-expanded' ) === 'true';

        $btn.attr( 'aria-expanded', isOpen ? 'false' : 'true' );
        $panel.attr( 'hidden', isOpen ? '' : null );
    } );

    // ── Toggle switch: update disabled class on section row ──────

    $( document ).on( 'change', '.zhp-section-enabled', function () {
        $( this ).closest( '.zhp-section-row' )
            .toggleClass( 'zhp-section-row--disabled', ! this.checked );
    } );

    // ── Settings page: master toggle label update ─────────────────

    $( document ).on( 'change', '#zhp-master-enabled', function () {
        const $label = $( this ).closest( '.zhp-settings-row__control' )
            .find( '.zhp-settings-row__toggle-label' );

        $label.text( this.checked
            ? ( i18n.enabled  || 'Enabled'  )
            : ( i18n.disabled || 'Disabled' )
        );
    } );

    // ── Settings page: AJAX save ─────────────────────────────────

    $( document ).on( 'click', '#zhp-save-settings-btn', function () {
        const $btn    = $( this );
        const $notice = $( '#zhp-settings-notice' );
        const $text   = $( '#zhp-settings-notice-text' );

        const settings = {
            master_enabled:       $( '#zhp-master-enabled' ).is( ':checked' ) ? 1 : 0,
            products_per_section: parseInt( $( '#zhp-products-per-section' ).val(), 10 ) || 8,
            cache_duration:       parseInt( $( '#zhp-cache-duration' ).val(), 10 )       || 15,
            support_email:        ( $( '#zhp-support-email' ).val() || '' ).trim(),
            use_product_grid_cards: $( '#zhp-use-product-grid-cards' ).is( ':checked' ) ? 1 : 0,
            // Blank means "automatic" and must post 0, not NaN. An empty input
            // gives parseInt('') === NaN, which JSON-encodes to null and would
            // reach absint() as an unusable value.
            section_title_size:   parseInt( $( '#zhp-section-title-size' ).val(), 10 )   || 0,
            explore_link_size:    parseInt( $( '#zhp-explore-link-size' ).val(), 10 )    || 0,
            // The select only exists on the settings screen; default rather
            // than post undefined, which would reach the sanitiser as ''.
            card_template:        $( '#zhp-card-template' ).val() || 'zymarg',
        };

        /*
         * Spacing controls are read from the DOM rather than listed above.
         *
         * Each one renders with data-zhp-spacing="<setting key>" and
         * data-zhp-default, so a control added to the PHP registry is picked
         * up here with no change to this file. Previously every slider needed
         * its own hand-written entry, which is how the same guard ended up
         * copied three times with the default restated in each copy.
         *
         * 0 is a legitimate value for all of them, so the `|| default` idiom
         * used above would be wrong here - it would silently turn "no gap"
         * into the default. A blank or non-numeric input falls back to that
         * control's own default instead, and the range is clamped client-side
         * as well as server-side so a hand-edited input cannot post nonsense.
         */
        $( '[data-zhp-spacing]' ).each( function () {
            const $input   = $( this );
            const key      = $input.attr( 'data-zhp-spacing' );
            const parsed   = parseInt( $input.val(), 10 );
            const fallback = parseInt( $input.attr( 'data-zhp-default' ), 10 );

            if ( ! key ) {
                return;
            }

            settings[ key ] = isNaN( parsed )
                ? ( isNaN( fallback ) ? 0 : fallback )
                : Math.max( 0, Math.min( 100, parsed ) );
        } );

        $btn.prop( 'disabled', true ).text( i18n.saving || 'Saving\u2026' );

        $.post(
            ajaxUrl,
            {
                action:   'zhp_save_settings',
                nonce:    zhpAdmin.nonce,
                settings: settings,
            },
            function ( response ) {
                $btn.prop( 'disabled', false ).text( i18n.save || 'Save Settings' );
                $notice
                    .removeClass( 'zhp-notice--error' )
                    .addClass( 'zhp-notice--success' );
                $text.text( response.data && response.data.message
                    ? response.data.message
                    : ( i18n.saved || 'Settings saved.' )
                );
                $notice.show();
                setTimeout( function () { $notice.fadeOut( 300 ); }, 3000 );
            }
        ).fail( function () {
            $btn.prop( 'disabled', false ).text( i18n.save || 'Save Settings' );
            $notice
                .removeClass( 'zhp-notice--success' )
                .addClass( 'zhp-notice--error' );
            $text.text( i18n.error || 'Save failed. Please try again.' );
            $notice.show();
        } );
    } );

    // ── Dashboard: live status check ─────────────────────────────

    /**
     * Fetch and display the live dashboard status values.
     *
     * Wrapped in a function and re-run on `zhp:admin:loaded` because the AJAX
     * router replaces the page content: after a swap the status elements are
     * brand new nodes, so values written into the previous ones are gone and
     * the placeholders would sit at their dash forever.
     */
    function loadDashboardStatus() {
        const $statusBar = $( '#zhp-dashboard-status' );

        if ( ! $statusBar.length || typeof zhpAdmin === 'undefined' || ! zhpAdmin.nonceDashboard ) {
            return;
        }

        $.post(
            ajaxUrl,
            {
                action: 'zhp_dashboard_status',
                nonce:  zhpAdmin.nonceDashboard,
            },
            function ( response ) {
                if ( ! response.success ) { return; }
                const d = response.data;

                setStatus( 'zhp-ds-master',    d.master_enabled,        i18n.on  || 'On',  i18n.off || 'Off' );
                setStatus( 'zhp-ds-frontpage', d.front_page_configured, i18n.configured || 'Configured', i18n.notConfigured || 'Not configured' );
                setStatus( 'zhp-ds-shortcode', d.shortcode_on_front,    i18n.found || 'Found', i18n.missing || 'Missing' );
                setStatus( 'zhp-ds-woo',       d.woocommerce_active,    i18n.active || 'Active', i18n.inactive || 'Inactive' );
                setStatus( 'zhp-ds-dokan',     d.dokan_active,          i18n.active || 'Active', i18n.inactive || 'Inactive' );
                setStatus( 'zhp-ds-engine',    d.product_grid_active,   i18n.active || 'Active', i18n.missing  || 'Not found' );
                setStatus( 'zhp-ds-pack',      d.template_pack_active,  i18n.active || 'Active', i18n.missing  || 'Not found' );
                setStatus( 'zhp-ds-flash',     d.flash_deals_ready,     i18n.found  || 'Ready',  i18n.missing  || 'Not built yet' );

                $( '#zhp-ds-sections' ).text( d.sections_enabled + ' / ' + d.sections_total );
            }
        );
    }

    loadDashboardStatus();

    $( document ).on( 'zhp:admin:loaded', loadDashboardStatus );

    /**
     * Update a status span with a green/red value.
     *
     * @param {string}  id      Element ID.
     * @param {boolean} ok      True = success state.
     * @param {string}  okText
     * @param {string}  failText
     */
    function setStatus( id, ok, okText, failText ) {
        const $el = $( '#' + id );
        $el.text( ok ? okText : failText )
           .removeClass( 'zhp-status--ok zhp-status--warn' )
           .addClass( ok ? 'zhp-status--ok' : 'zhp-status--warn' );
    }


    // -- Custom Header HTML reviewer (1.29.0) --------------------

    /**
     * Mirror of CustomSection::analyse_header() so the administrator sees the
     * same findings while typing, before anything is saved.
     *
     * @param {string} code Raw header markup.
     * @return {Array} List of localised notes.
     */
    function zhpHeaderNotes( code ) {
        const notes = [];

        if ( ! code || ! code.trim() ) {
            return notes;
        }

        if ( /<!DOCTYPE|<html\b|<head\b|<body\b/i.test( code ) ) {
            notes.push( i18n.hdrDoc );
        }

        const styles = code.match( /<style\b[^>]*>[\s\S]*?<\/style>/gi );
        const css    = styles ? styles.join( '\n' ) : '';

        if ( css && /(^|[\s,}])(body|html|:root)\b/i.test( css ) ) {
            notes.push( i18n.hdrRoot );

            if ( /(^|[;{\s])(display|margin|padding|position|min-height|height|width|overflow|inset|justify-content|align-items)\s*:/i.test( css ) ) {
                notes.push( i18n.hdrLayout );
            }
        }

        if ( /<script\b/i.test( code ) || /\son[a-z]+\s*=/i.test( code ) ) {
            notes.push( i18n.hdrScript );
        }

        if ( code.toLowerCase().indexOf( 'zhp-section-header' ) === -1 ) {
            notes.push( i18n.hdrWrap );
        }

        return notes.filter( Boolean );
    }

    let zhpHeaderTimer = null;

    $( document ).on( 'input', 'textarea[name="settings[header_html]"]', function () {
        const $ta = $( this );

        window.clearTimeout( zhpHeaderTimer );

        zhpHeaderTimer = window.setTimeout( function () {
            const $box = $ta.closest( '.zhp-settings-row' ).find( '[data-zhp-header-check]' );

            if ( ! $box.length ) {
                return;
            }

            const value = $ta.val() || '';
            const notes = zhpHeaderNotes( value );
            const $list = $box.find( '[data-zhp-header-notes]' );
            const $ok   = $box.find( '[data-zhp-header-ok]' );

            $list.empty();

            notes.forEach( function ( note ) {
                $list.append( $( '<li/>' ).text( note ) );
            } );

            $list.attr( 'hidden', notes.length ? null : '' );
            $ok.attr( 'hidden', ( '' !== value.trim() && ! notes.length ) ? null : '' );
        }, 250 );
    } );

} )( jQuery );
