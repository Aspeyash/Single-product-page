/**
 * ZYMARG Homepage – Drag-and-Drop Section Manager
 *
 * Powers the jQuery UI Sortable interface on the Homepage admin page.
 * Collects section order, enabled states, and per-section settings,
 * then sends them to the server via AJAX.
 *
 * Changes in 1.7.0:
 *   • Replaced window.confirm() with an inline custom confirm dialog
 *     so the reset flow never breaks the AJAX experience with a native
 *     browser popup.
 *   • All user-facing strings come from zhpDragDrop.i18n — no hardcoded
 *     English text remains.
 *
 * jQuery UI Sortable is WordPress-bundled — no external dependency.
 * Loaded only on the Homepage section manager admin page.
 *
 * Changes in 1.19.1:
 *   • Move up / Move down buttons. jQuery UI Sortable binds mouse events
 *     only and WordPress bundles no touch shim, so the drag handle has
 *     never worked on a phone or tablet. These buttons reorder the same
 *     list through the same save path, and also give keyboard and screen
 *     reader users a route that dragging never provided.
 *
 * @package ZYMARGHomepage
 * @since   1.3.0
 * @version 1.37.0
 */

( function ( $ ) {
    'use strict';

    // This script now loads on every plugin admin screen, not only the
    // section manager, so that AJAX navigation can reach the sortable list
    // without a page load. Bail out quietly if the localised data is absent.
    if ( typeof zhpDragDrop === 'undefined' ) {
        return;
    }

    const i18n    = zhpDragDrop.i18n    || {};
    const nonce   = zhpDragDrop.nonce   || '';
    const ajaxUrl = zhpDragDrop.ajaxUrl || '';

    // ── Inline confirm dialog ─────────────────────────────────────

    /**
     * Build and inject the confirm modal once, reuse on every call.
     * The modal sits in the DOM hidden; showConfirm() wires the callback.
     */
    const $modal = $( [
        '<div id="zhp-confirm-modal" class="zhp-confirm-modal" hidden aria-modal="true" role="dialog">',
        '  <div class="zhp-confirm-modal__box">',
        '    <p  id="zhp-confirm-modal-msg" class="zhp-confirm-modal__msg"></p>',
        '    <div class="zhp-confirm-modal__actions">',
        '      <button id="zhp-confirm-cancel"  class="zhp-admin-btn zhp-admin-btn--secondary">',
        '        ' + ( i18n.cancel || 'Cancel' ),
        '      </button>',
        '      <button id="zhp-confirm-ok" class="zhp-admin-btn zhp-admin-btn--danger">',
        '        ' + ( i18n.confirmOk || 'Yes, reset' ),
        '      </button>',
        '    </div>',
        '  </div>',
        '</div>',
    ].join( '' ) );

    $( 'body' ).append( $modal );

    let _confirmCallback = null;

    /**
     * Show the inline confirm dialog.
     *
     * @param {string}   message  Text to display.
     * @param {Function} callback Executed if the user confirms.
     */
    function showConfirm( message, callback ) {
        $( '#zhp-confirm-modal-msg' ).text( message );
        _confirmCallback = callback;
        $modal.removeAttr( 'hidden' );
        $( '#zhp-confirm-ok' ).trigger( 'focus' );
    }

    $( document ).on( 'click', '#zhp-confirm-ok', function () {
        $modal.attr( 'hidden', '' );
        if ( typeof _confirmCallback === 'function' ) {
            _confirmCallback();
            _confirmCallback = null;
        }
    } );

    $( document ).on( 'click', '#zhp-confirm-cancel', function () {
        $modal.attr( 'hidden', '' );
        _confirmCallback = null;
    } );

    // Close on overlay click.
    $( document ).on( 'click', '#zhp-confirm-modal', function ( e ) {
        if ( $( e.target ).is( '#zhp-confirm-modal' ) ) {
            $modal.attr( 'hidden', '' );
            _confirmCallback = null;
        }
    } );

    // Close on Escape key.
    $( document ).on( 'keydown', function ( e ) {
        if ( e.key === 'Escape' && ! $modal.attr( 'hidden' ) ) {
            $modal.attr( 'hidden', '' );
            _confirmCallback = null;
        }
    } );

    // ── Init Sortable ────────────────────────────────────────────

    /**
     * Attach jQuery UI Sortable to the section list.
     *
     * Called on first load and again after every AJAX screen swap. A swap
     * replaces the list with a new element, and Sortable attached to the old
     * node does not follow it, so dragging would silently stop working. The
     * data flag makes re-running this harmless when the list is unchanged.
     */
    function initSortable() {
        const $list = $( '#zhp-section-list' );

        if ( ! $list.length || $list.data( 'zhpSortable' ) ) {
            return;
        }

        $list.sortable( {
            handle:      '.zhp-section-row__drag',
            axis:        'y',
            placeholder: 'zhp-section-row zhp-section-row--placeholder',
            tolerance:   'pointer',
            cursor:      'grabbing',
            opacity:     0.90,
            revert:      120,
            update: function () {
                updateOrderAttributes();
                // A drag changes which rows are first and last, so the
                // button disabled states have to be recalculated too.
                refreshMoveButtons();
            },
        } );

        $list.data( 'zhpSortable', true );
    }

    // ── Helpers ──────────────────────────────────────────────────

    function updateOrderAttributes() {
        $( '#zhp-section-list .zhp-section-row' ).each( function ( index ) {
            $( this ).attr( 'data-order', index + 1 );
        } );
    }

    // ── Move up / Move down ──────────────────────────────────────

    /**
     * Disable the up button on the first row and the down button on the
     * last, so neither can be pressed into a no-op.
     *
     * Must run after anything that changes row order or replaces the list:
     * first load, every move, and every AJAX screen swap. Sortable drags
     * also reorder rows, so `update` calls this too.
     */
    function refreshMoveButtons() {
        const $rows = $( '#zhp-section-list .zhp-section-row' );

        if ( ! $rows.length ) {
            return;
        }

        $rows.find( '.zhp-move-btn' ).prop( 'disabled', false );
        $rows.first().find( '.zhp-move-btn--up' ).prop( 'disabled', true );
        $rows.last().find( '.zhp-move-btn--down' ).prop( 'disabled', true );
    }

    /**
     * Move one row up or down by one position.
     *
     * The row element itself is relocated rather than having its contents
     * copied, so the expanded settings panel, any unsaved field values and
     * the toggle state all travel with it. collectSections() reads document
     * order, so no separate order bookkeeping is needed.
     *
     * Nothing is persisted here. This matches the drag behaviour exactly:
     * the new order is staged in the DOM and written only when Save Changes
     * is pressed, so a mis-tap can be undone by leaving without saving.
     *
     * @param {jQuery} $btn       The pressed button.
     * @param {string} direction  'up' or 'down'.
     */
    function moveRow( $btn, direction ) {
        const $row       = $btn.closest( '.zhp-section-row' );
        const $neighbour = ( 'up' === direction )
            ? $row.prev( '.zhp-section-row' )
            : $row.next( '.zhp-section-row' );

        if ( ! $row.length || ! $neighbour.length ) {
            return;
        }

        if ( 'up' === direction ) {
            $row.insertBefore( $neighbour );
        } else {
            $row.insertAfter( $neighbour );
        }

        updateOrderAttributes();
        refreshMoveButtons();

        /*
         * Moving a focused element in the DOM drops focus in some browsers,
         * which would strand a keyboard user mid-list. Restore it to the same
         * button so repeated presses keep working. If that button just became
         * disabled because the row reached an end, move focus to its partner
         * rather than to nothing.
         */
        let $target = $row.find( '.zhp-move-btn--' + direction );

        if ( $target.prop( 'disabled' ) ) {
            $target = $row.find(
                'up' === direction ? '.zhp-move-btn--down' : '.zhp-move-btn--up'
            );
        }

        $target.trigger( 'focus' );

        // Visible confirmation that the tap did something, which matters on a
        // phone where the rest of the list may be off screen.
        $row.addClass( 'zhp-section-row--just-moved' );
        setTimeout( function () {
            $row.removeClass( 'zhp-section-row--just-moved' );
        }, 600 );

        /*
         * Keep the moved row in view. A row near the edge of a long list can
         * otherwise scroll out of sight on the press that moved it.
         * Feature-detected: scrollIntoView options are ignored by older
         * browsers, and the method itself is absent in very old ones.
         */
        const node = $row.get( 0 );

        if ( node && typeof node.scrollIntoView === 'function' ) {
            node.scrollIntoView( { block: 'nearest', behavior: 'smooth' } );
        }
    }

    /*
     * Bound to the document, not to the buttons, so the handler survives an
     * AJAX screen swap replacing every row — the same reason Save and Reset
     * are bound this way.
     */
    $( document ).on( 'click', '.zhp-move-btn', function ( e ) {
        e.preventDefault();

        const $btn = $( this );

        if ( $btn.prop( 'disabled' ) ) {
            return;
        }

        moveRow( $btn, $btn.attr( 'data-zhp-move' ) === 'up' ? 'up' : 'down' );
    } );

    function collectSections() {
        const sections = [];
        $( '#zhp-section-list .zhp-section-row' ).each( function ( index ) {
            const $row = $( this );
            sections.push( {
                slug:     $row.data( 'slug' )                                || '',
                enabled:  $row.find( '.zhp-section-enabled' ).is( ':checked' ),
                order:    index + 1,
                settings: collectSectionSettings( $row ),
            } );
        } );
        return sections;
    }

    /**
     * Split a field name into its bracket path segments.
     *
     * 'settings[carousel]'          -> [ 'carousel' ]
     * 'settings[items][0][title]'   -> [ 'items', '0', 'title' ]
     *
     * Returns an empty array for anything that is not a settings[...] name.
     */
    function parseSettingPath( attr ) {
        if ( attr.indexOf( 'settings[' ) !== 0 ) { return []; }

        const segments = [];
        const re = /\[([^\]]*)\]/g;
        let m;
        while ( ( m = re.exec( attr ) ) !== null ) {
            segments.push( m[ 1 ] );
        }
        return segments;
    }

    /**
     * Write a value into a nested object/array structure, creating any
     * missing levels on the way down. A numeric next-segment creates an
     * array, anything else creates an object, so repeater rows survive the
     * round trip to PHP as a real list rather than a map of numeric keys.
     */
    function assignSettingPath( target, path, value ) {
        let node = target;

        for ( let i = 0; i < path.length - 1; i++ ) {
            const seg  = path[ i ];
            const next = path[ i + 1 ];

            if ( ! node[ seg ] || typeof node[ seg ] !== 'object' ) {
                node[ seg ] = /^\d+$/.test( next ) ? [] : {};
            }
            node = node[ seg ];
        }

        node[ path[ path.length - 1 ] ] = value;
    }

    function collectSectionSettings( $row ) {
        const settings = {};
        $row.find( '.zhp-section-settings [name]' ).each( function () {
            const $el  = $( this );
            const attr = $el.attr( 'name' );
            if ( ! attr ) { return; }

            // Skip the repeater's clone template, which exists only to be
            // copied. Saving it would write a blank card on every save.
            if ( $el.closest( '.zhp-repeater__template' ).length ) { return; }

            let value;
            if      ( $el.is( ':checkbox' )        ) { value = $el.is( ':checked' ) ? 1 : 0; }
            else if ( $el.is( 'select[multiple]' ) ) { value = $el.val() || []; }
            else                                     { value = $el.val() || ''; }

            /*
             * Fields are rendered as name="settings[key]", but the saved
             * option stores plain keys and the templates read plain keys.
             * Collecting the raw attribute stored 'settings[carousel]'
             * instead of 'carousel', so no setting ever took effect.
             *
             * Repeater fields add a second and third level, e.g.
             * 'settings[items][0][title]'. The previous single-level regex
             * could not match those at all and fell through to storing the
             * whole raw attribute as one flat key, so a card list could never
             * be saved. Paths are now walked properly at any depth.
             */
            const path = parseSettingPath( attr );

            if ( ! path.length ) {
                settings[ attr ] = value;
                return;
            }

            assignSettingPath( settings, path, value );
        } );

        /*
         * Removing a middle row leaves a hole in the index sequence, which
         * would arrive in PHP as a sparse list containing nulls. Compact every
         * list so PHP receives a clean, densely indexed array.
         */
        Object.keys( settings ).forEach( function ( key ) {
            if ( Array.isArray( settings[ key ] ) ) {
                settings[ key ] = settings[ key ].filter( function ( entry ) {
                    return entry !== null && entry !== undefined;
                } );
            }
        } );

        return settings;
    }

    /*
     * -- Repeater rows -------------------------------------------
     * Used by the Collections panel so several cards can be managed
     * in place, without a separate admin menu. Delegated from the
     * document so rows added after page load keep working, and so
     * this survives the AJAX router swapping the screen out.
     */
    $( document ).on( 'click', '.zhp-repeater__add', function ( e ) {
        e.preventDefault();

        const $repeater = $( this ).closest( '.zhp-repeater' );
        const $list     = $repeater.find( '.zhp-repeater__rows' ).first();
        const template  = $repeater.find( '.zhp-repeater__template' ).first().html();

        if ( ! template ) { return; }

        /*
         * Index from the highest index already present rather than from the
         * row count: after a deletion those two disagree, and reusing an
         * existing index would make two rows overwrite each other on save.
         */
        let nextIndex = 0;
        $list.find( '.zhp-repeater__row' ).each( function () {
            const idx = parseInt( $( this ).attr( 'data-index' ), 10 );
            if ( ! isNaN( idx ) && idx >= nextIndex ) { nextIndex = idx + 1; }
        } );

        $list.append( template.replace( /__INDEX__/g, String( nextIndex ) ) );
        $list.find( '.zhp-repeater__row' ).last().find( 'input' ).first().trigger( 'focus' );
    } );

    $( document ).on( 'click', '.zhp-repeater__remove', function ( e ) {
        e.preventDefault();
        $( this ).closest( '.zhp-repeater__row' ).remove();
    } );

    /*
     * Swap a button's label without resizing it.
     *
     * "Save Changes" and "Saving…" are different widths, so changing the
     * text mid-save resized the button and visibly shifted the whole header
     * row - twice per save, once each way. Pinning the measured width for the
     * duration keeps the row completely still.
     */
    function setBusyLabel( $btn, label ) {
        if ( ! $btn.data( 'zhpWidth' ) ) {
            $btn.data( 'zhpWidth', $btn.outerWidth() );
        }

        $btn.css( 'min-width', $btn.data( 'zhpWidth' ) + 'px' ).text( label );
    }

    function showNotice( message, type ) {
        let $notice = $( '#zhp-save-notice' );
        let $text   = $( '#zhp-save-notice-text' );

        /*
         * Build the toast on demand when the screen has no notice element.
         * The confirmation silently went nowhere on any screen that did not
         * ship the markup, which made a successful save look like a no-op.
         */
        if ( ! $notice.length ) {
            $notice = $( '<div class="zhp-notice zhp-notice--info" id="zhp-save-notice" style="display:none;"><span id="zhp-save-notice-text"></span></div>' );
            $( 'body' ).append( $notice );
            $text = $notice.find( '#zhp-save-notice-text' );
        }

        $notice.stop( true, true );
        $notice
            .removeClass( 'zhp-notice--success zhp-notice--error' )
            .addClass( 'zhp-notice--' + ( type || 'info' ) );
        $text.text( message );
        $notice.show();
        if ( 'error' !== type ) {
            setTimeout( function () { $notice.fadeOut( 300 ); }, 3000 );
        }
    }

    // ── Save sections ────────────────────────────────────────────

    $( document ).on( 'click', '#zhp-save-sections', function () {
        const $btn     = $( this );
        const sections = collectSections();

        $btn.prop( 'disabled', true );
        setBusyLabel( $btn, i18n.saving || 'Saving\u2026' );

        $.post(
            ajaxUrl,
            {
                action:   'zhp_save_sections',
                nonce:    nonce,
                sections: JSON.stringify( sections ),
            },
            function ( response ) {
                $btn.prop( 'disabled', false );
                setBusyLabel( $btn, i18n.save || 'Save Changes' );
                if ( response.success ) {
                    showNotice( response.data && response.data.message
                        ? response.data.message
                        : ( i18n.saved || 'Changes saved.' ), 'success' );
                } else {
                    showNotice( response.data && response.data.message
                        ? response.data.message
                        : ( i18n.error || 'Save failed.' ), 'error' );
                }
            }
        ).fail( function () {
            $btn.prop( 'disabled', false );
                setBusyLabel( $btn, i18n.save || 'Save Changes' );
            showNotice( i18n.error || 'Save failed. Please try again.', 'error' );
        } );
    } );

    // ── Reset sections ───────────────────────────────────────────

    $( document ).on( 'click', '#zhp-reset-sections', function () {
        showConfirm(
            i18n.confirm || 'Reset section order to defaults? This cannot be undone.',
            function () {
                $.post(
                    ajaxUrl,
                    { action: 'zhp_reset_sections', nonce: nonce },
                    function ( response ) {
                        if ( response.success ) {
                            /*
                             * Re-render the sections screen in place. A full
                             * page reload here contradicted the rest of the
                             * admin, which never reloads. Falls back to a
                             * reload only when the router is unavailable.
                             */
                            showNotice( i18n.saved || 'Changes saved.', 'success' );

                            if ( window.zhpAdminRouter ) {
                                window.zhpAdminRouter.navigate( 'zymarg-homepage-sections' );
                            } else {
                                window.location.reload();
                            }
                        } else {
                            showNotice( response.data && response.data.message
                                ? response.data.message
                                : ( i18n.error || 'Reset failed.' ), 'error' );
                        }
                    }
                ).fail( function () {
                    showNotice( i18n.error || 'Reset failed. Please try again.', 'error' );
                } );
            }
        );
    } );

    // ── Init ─────────────────────────────────────────────────────

    initSortable();
    updateOrderAttributes();
    refreshMoveButtons();

    // Re-run after an AJAX screen swap. The button handlers are bound to the
    // document so they survive on their own; only the Sortable instance, the
    // order attributes and the move-button states need rebuilding against the
    // new nodes.
    $( document ).on( 'zhp:admin:loaded', function () {
        initSortable();
        updateOrderAttributes();
        refreshMoveButtons();
    } );

} )( jQuery );
