/**
 * ZYMARG Homepage - Countdown timer for Flash Deals
 *
 * Each [data-zhp-countdown] may carry data-zhp-deadline, a Unix timestamp in
 * seconds for the soonest sale end among the products actually on screen. That
 * value is captured server side from the Product Grid engine's zymarg_products
 * filter, so the timer reflects a real WooCommerce sale schedule.
 *
 * Without that attribute the element falls back to end of day UTC, which is
 * what every timer did before 1.31.0.
 *
 * @package ZYMARGHomepage
 * @since   1.5.0
 * @version 1.31.0
 */

( function () {
    'use strict';

    function pad( n ) { return String( n ).padStart( 2, '0' ); }

    function endOfDay() {
        var midnight = new Date();
        midnight.setUTCHours( 23, 59, 59, 999 );
        return midnight.getTime();
    }

    function deadlineFor( root ) {
        var raw = root.getAttribute( 'data-zhp-deadline' );
        var ts  = raw ? parseInt( raw, 10 ) : 0;

        // Stored in seconds; JavaScript compares in milliseconds.
        return ts > 0 ? ts * 1000 : endOfDay();
    }

    function format( diff ) {
        if ( diff < 0 ) { diff = 0; }

        var d = Math.floor( diff / 86400000 );
        var h = Math.floor( ( diff % 86400000 ) / 3600000 );
        var m = Math.floor( ( diff % 3600000 ) / 60000 );
        var s = Math.floor( ( diff % 60000 ) / 1000 );

        // Only show days once the sale runs past midnight, so the common case
        // keeps the familiar HH:MM:SS shape.
        return ( d > 0 ? d + 'd ' : '' ) + pad( h ) + ':' + pad( m ) + ':' + pad( s );
    }

    function tick( roots ) {
        var now = Date.now();

        roots.forEach( function ( root ) {
            var timer = root.querySelector( '[data-zhp-timer]' );

            if ( ! timer ) { return; }

            timer.textContent = format( deadlineFor( root ) - now );
        } );
    }

    document.addEventListener( 'DOMContentLoaded', function () {
        var roots = Array.prototype.slice.call(
            document.querySelectorAll( '[data-zhp-countdown]' )
        );

        if ( ! roots.length ) { return; }

        tick( roots );
        setInterval( function () { tick( roots ); }, 1000 );
    } );
} () );
