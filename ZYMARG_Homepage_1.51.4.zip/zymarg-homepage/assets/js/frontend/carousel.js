/**
 * ZYMARG Homepage – Horizontal Carousel
 *
 * Progressive enhancement for sections with the carousel setting enabled.
 *
 * Swiping, trackpad scrolling and scroll-snap are handled entirely by CSS.
 * This file only adds what CSS cannot: arrow buttons, their enabled state,
 * and keyboard access. If this script fails to load, every carousel is
 * still fully usable by swiping or scrolling.
 *
 * @package ZYMARGHomepage
 * @since   1.11.0
 * @version 1.40.0
 */

( function () {
    'use strict';

    var TRACK_SELECTOR = '[data-zhp-carousel]';
    var HOST_SELECTOR  = '[data-zhp-carousel-host]';

    // The element that actually contains the cards inside an engine host.
    var GRID_SELECTOR  = '.zymarg-wcpg__grid, [class*="wcpg__grid"], [data-columns-desktop]';
    var INIT_FLAG      = 'zhpCarouselReady';

    var i18n = ( window.zhpAjax && window.zhpAjax.i18n ) || {};
    var LABEL_PREV = i18n.carouselPrev || 'Scroll left';
    var LABEL_NEXT = i18n.carouselNext || 'Scroll right';

    var ICON_PREV = '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><polyline points="15 18 9 12 15 6"></polyline></svg>';
    var ICON_NEXT = '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><polyline points="9 18 15 12 9 6"></polyline></svg>';

    /**
     * Build one arrow button.
     */
    function makeButton( direction, label, icon ) {
        var btn = document.createElement( 'button' );

        btn.type      = 'button';
        btn.className = 'zhp-carousel__nav zhp-carousel__nav--' + direction;
        btn.innerHTML = icon;

        btn.setAttribute( 'aria-label', label );
        // The track is exposed to assistive tech directly, so the buttons
        // are a redundant visual affordance for pointer users.
        btn.setAttribute( 'tabindex', '-1' );
        btn.setAttribute( 'aria-hidden', 'true' );

        return btn;
    }

    /**
     * How far one arrow press should travel.
     *
     * Just under one full viewport of the track, so a card is always kept
     * partly visible as a visual anchor.
     */
    function step( track ) {
        return Math.max( 1, Math.round( track.clientWidth * 0.85 ) );
    }

    /**
     * Glide the track to a position over a set duration.
     *
     * The browser's own smooth scrolling has no speed control - the duration
     * is picked by the engine and cannot be set from CSS or JS. When the admin
     * has chosen a glide speed we therefore animate scrollLeft ourselves;
     * otherwise we hand straight back to the native behaviour, which is
     * cheaper and already respects prefers-reduced-motion.
     *
     * @since 1.35.0
     */
    /*
     * Read a motion attribute from the track, falling back to the section that
     * contains it. Product rows are drawn by the engine, so this plugin cannot
     * put attributes on the track itself; the section carries them instead.
     */
    function motionAttr( track, name ) {
        if ( track.hasAttribute( name ) ) {
            return track.getAttribute( name );
        }

        var owner = track.closest ? track.closest( '[data-zhp-carousel-motion]' ) : null;

        return owner ? owner.getAttribute( name ) : null;
    }

    function glideTo( track, target, duration ) {
        var max = track.scrollWidth - track.clientWidth;

        target = Math.max( 0, Math.min( target, max ) );

        if ( ! duration || window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ) {
            track.scrollTo( { left: target, behavior: duration ? 'auto' : 'smooth' } );
            return;
        }

        // A new glide always supersedes one still running.
        if ( track.zhpGlideFrame ) {
            cancelAnimationFrame( track.zhpGlideFrame );
        }

        var start = track.scrollLeft;
        var delta = target - start;

        if ( 0 === delta ) {
            return;
        }

        var began = null;

        function frame( now ) {
            if ( null === began ) {
                began = now;
            }

            var progress = Math.min( 1, ( now - began ) / duration );
            // easeInOutCubic: starts and stops gently, no abrupt halt.
            var eased = progress < 0.5
                ? 4 * progress * progress * progress
                : 1 - Math.pow( -2 * progress + 2, 3 ) / 2;

            track.scrollLeft = start + ( delta * eased );

            if ( progress < 1 ) {
                track.zhpGlideFrame = requestAnimationFrame( frame );
            } else {
                track.zhpGlideFrame = null;
            }
        }

        track.zhpGlideFrame = requestAnimationFrame( frame );
    }

    /**
     * The admin-chosen glide duration in milliseconds, or 0 for native.
     *
     * @since 1.35.0
     */
    function glideMs( track ) {
        var ms = parseInt( motionAttr( track, 'data-zhp-glide' ), 10 );

        return ( ms >= 100 && ms <= 3000 ) ? ms : 0;
    }

    /**
     * Enable/disable the arrows based on scroll position.
     */
    function syncButtons( track, prev, next ) {
        // 2px tolerance absorbs sub-pixel rounding and zoom.
        var TOLERANCE = 2;
        var maxScroll = track.scrollWidth - track.clientWidth;

        // Nothing overflows: no arrows needed at all.
        if ( maxScroll <= TOLERANCE ) {
            prev.disabled = true;
            next.disabled = true;
            return;
        }

        // Math.abs handles right-to-left locales, where scrollLeft is negative.
        var position = Math.abs( track.scrollLeft );

        prev.disabled = position <= TOLERANCE;
        next.disabled = position >= ( maxScroll - TOLERANCE );
    }

    /**
     * Initialise a single track. Safe to call repeatedly.
     */
    function initTrack( track ) {
        if ( track.dataset[ INIT_FLAG ] === '1' ) {
            return;
        }

        var parent = track.parentNode;
        if ( ! parent ) {
            return;
        }

        // Wrap the track so the arrows can be absolutely positioned
        // against it, unless a previous run already wrapped it.
        var shell;
        if ( parent.classList && parent.classList.contains( 'zhp-carousel' ) ) {
            shell = parent;
        } else {
            shell = document.createElement( 'div' );
            shell.className = 'zhp-carousel';
            parent.insertBefore( shell, track );
            shell.appendChild( track );
        }

        var prev = makeButton( 'prev', LABEL_PREV, ICON_PREV );
        var next = makeButton( 'next', LABEL_NEXT, ICON_NEXT );

        shell.appendChild( prev );
        shell.appendChild( next );

        // Let keyboard users scroll the row with the arrow keys. The
        // browser does this natively once the element is focusable.
        if ( ! track.hasAttribute( 'tabindex' ) ) {
            track.setAttribute( 'tabindex', '0' );
        }

        function scrollBy( amount ) {
            // scrollBy with behavior:'smooth' respects the CSS
            // scroll-behavior:auto set under prefers-reduced-motion.
            glideTo( track, track.scrollLeft + amount, glideMs( track ) );
        }

        prev.addEventListener( 'click', function () {
            scrollBy( -step( track ) );
        } );

        next.addEventListener( 'click', function () {
            scrollBy( step( track ) );
        } );

        var queued = false;
        function requestSync() {
            if ( queued ) {
                return;
            }
            queued = true;
            window.requestAnimationFrame( function () {
                queued = false;
                syncButtons( track, prev, next );
            } );
        }

        track.addEventListener( 'scroll', requestSync, { passive: true } );
        window.addEventListener( 'resize', requestSync );

        // Cards loading in (images, AJAX appends) change scrollWidth.
        if ( 'ResizeObserver' in window ) {
            new window.ResizeObserver( requestSync ).observe( track );
        }

        track.dataset[ INIT_FLAG ] = '1';
        syncButtons( track, prev, next );
    }

    /**
     * Adopt grids rendered by another plugin.
     *
     * When the ZYMARG WC Product Grid engine draws the cards, it emits its own
     * grid wrapper that this plugin cannot add attributes to. The PHP side
     * wraps that output in a host element instead, and here the host's first
     * child — the element that actually contains the cards — is promoted to a
     * normal track. Everything downstream then behaves identically to a
     * homepage-rendered carousel, reusing the same CSS and arrows.
     */
    function promoteHosts( scope ) {
        var hosts = scope.querySelectorAll( HOST_SELECTOR );

        Array.prototype.forEach.call( hosts, function ( host ) {
            /*
             * The engine returns a wrapper element that holds an optional
             * heading, the card grid and an optional pagination block. Taking
             * firstElementChild therefore promoted the wrapper, so the
             * carousel laid out those three blocks as columns while the real
             * card grid kept wrapping into rows underneath - the toggle looked
             * dead. Target the grid itself and fall back to the old behaviour
             * for any host that has no recognisable grid inside it.
             */
            var track = host.querySelector( GRID_SELECTOR ) || host.firstElementChild;

            if ( ! track ) {
                return;
            }

            track.classList.add( 'zhp-carousel-track' );
            track.setAttribute( 'data-zhp-carousel', '' );

            // Promote once; the track now matches TRACK_SELECTOR on its own.
            host.removeAttribute( 'data-zhp-carousel-host' );
        } );
    }

    /**
     * Initialise every carousel on the page.
     */
    function init( root ) {
        var scope = root || document;

        promoteHosts( scope );

        var tracks = scope.querySelectorAll( TRACK_SELECTOR );

        Array.prototype.forEach.call( tracks, initTrack );
        Array.prototype.forEach.call( tracks, initAutoplay );
        Array.prototype.forEach.call( tracks, initMarquee );
    }

    /*
     * Auto-rotation for multibanner sections.
     *
     * Deliberately conservative. It stops permanently the moment the visitor
     * shows any intent of their own - pointer, touch, keyboard focus or a
     * manual scroll - because a banner that yanks itself away mid-interaction
     * is worse than one that never moved. Reduced-motion users never start it.
     */
    /*
     * Continuous ("marquee") rotation.
     *
     * An additional choice alongside step rotation, not a replacement. Rather
     * than jumping a screen at a time it advances the scroll position a few
     * pixels every frame, so the row reads as a live ticker drifting right to
     * left. The children are cloned once and the scroll position wraps at the
     * halfway point, which is what makes the loop seamless instead of snapping
     * back at the end. Clones are hidden from assistive tech and taken out of
     * the tab order so the duplicate cards are not announced twice.
     *
     * @since 1.40.0
     */
    function initMarquee( track ) {
        if ( track.zhpMarqueeBound ) {
            return;
        }

        var raw = parseInt( motionAttr( track, 'data-zhp-marquee' ), 10 );

        if ( isNaN( raw ) || raw <= 0 ) {
            return;
        }

        // Never animate for visitors who asked for reduced motion.
        if ( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ) {
            return;
        }

        var originals = Array.prototype.slice.call( track.children );

        if ( originals.length < 2 ) {
            return;
        }

        var speed = Math.min( 200, Math.max( 10, raw ) );

        track.zhpMarqueeBound = true;
        track.classList.add( 'zhp-carousel-track--marquee' );

        originals.forEach( function ( node ) {
            var clone = node.cloneNode( true );

            clone.setAttribute( 'aria-hidden', 'true' );
            clone.setAttribute( 'data-zhp-marquee-clone', '' );

            var focusable = clone.querySelectorAll( 'a, button, input, select, textarea' );

            Array.prototype.forEach.call( focusable, function ( el ) {
                el.setAttribute( 'tabindex', '-1' );
            } );

            track.appendChild( clone );
        } );

        var last   = 0;
        var paused = false;

        function frame( now ) {
            if ( ! last ) {
                last = now;
            }

            var elapsed = ( now - last ) / 1000;

            last = now;

            // A backgrounded tab can hand back a huge gap; clamp it so the row
            // does not lurch forward when the visitor returns.
            if ( elapsed > 0.1 ) {
                elapsed = 0.1;
            }

            if ( ! paused ) {
                var half = track.scrollWidth / 2;

                track.scrollLeft += speed * elapsed;

                if ( half > 0 && track.scrollLeft >= half ) {
                    track.scrollLeft -= half;
                }
            }

            track.zhpMarqueeFrame = window.requestAnimationFrame( frame );
        }

        // Pause on hover or keyboard focus so shoppers can read a card, then
        // resume - unlike step rotation this mode is meant to keep going.
        track.addEventListener( 'mouseenter', function () {
            paused = true;
        } );

        track.addEventListener( 'mouseleave', function () {
            paused = false;
        } );

        track.addEventListener( 'focusin', function () {
            paused = true;
        } );

        track.addEventListener( 'focusout', function () {
            paused = false;
        } );

        track.zhpMarqueeFrame = window.requestAnimationFrame( frame );
    }

    function initAutoplay( track ) {
        if ( track.zhpAutoplayBound ) {
            return;
        }

        // Continuous rotation is a separate mode; never run both on one track.
        if ( null !== motionAttr( track, 'data-zhp-marquee' ) ) {
            return;
        }

        var raw = parseInt( motionAttr( track, 'data-zhp-autoplay' ), 10 );

        if ( ! raw || raw < 2 ) {
            return;
        }

        if ( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ) {
            return;
        }

        track.zhpAutoplayBound = true;

        var timer   = null;
        var stopped = false;

        function advance() {
            if ( stopped || ! track.isConnected || document.hidden ) {
                return;
            }

            /*
             * offsetWidth ignores the flex gap, so every advance under-scrolled
             * by exactly one gap. Measured live at 2560px: cards are 150px with
             * a 16px gap, a true pitch of 166px, so each tick lost 16px - 9.6%
             * of a card. The error accumulated with no re-alignment, which is
             * why the leftmost card was sliced mid-word after roughly nine
             * rotations. Measuring one card's offsetLeft to the next includes
             * the gap, so drift is zero however long autoplay runs. - 1.51.0
             */
            var first  = track.firstElementChild;
            var second = first ? first.nextElementSibling : null;
            var slide  = first ? first.offsetWidth : track.clientWidth;

            if ( first && second ) {
                slide = Math.abs( second.offsetLeft - first.offsetLeft ) || slide;
            }
            var max   = track.scrollWidth - track.clientWidth;

            // Loop back to the first banner once the last one is showing.
            var next = ( track.scrollLeft + slide >= max - 2 ) ? 0 : track.scrollLeft + slide;

            glideTo( track, next, glideMs( track ) );
        }

        function stop() {
            stopped = true;

            if ( timer ) {
                clearInterval( timer );
                timer = null;
            }
        }

        timer = setInterval( advance, raw * 1000 );

        [ 'pointerdown', 'touchstart', 'wheel', 'focusin', 'keydown' ].forEach( function ( evt ) {
            track.addEventListener( evt, stop, { passive: true, once: true } );
        } );

        track.addEventListener( 'mouseenter', function () {
            if ( timer ) {
                clearInterval( timer );
                timer = null;
            }
        } );

        track.addEventListener( 'mouseleave', function () {
            if ( ! stopped && ! timer ) {
                timer = setInterval( advance, raw * 1000 );
            }
        } );
    }

    if ( 'loading' === document.readyState ) {
        document.addEventListener( 'DOMContentLoaded', function () {
            init();
        } );
    } else {
        init();
    }

    // Load-more and filter responses swap card markup in. Those scripts
    // can call window.zhpCarousel.refresh() after injecting content.
    window.zhpCarousel = {
        init: init,
        refresh: function ( root ) {
            init( root );

            var scope  = root || document;
            var tracks = scope.querySelectorAll( TRACK_SELECTOR );

            Array.prototype.forEach.call( tracks, function ( track ) {
                var shell = track.parentNode;
                if ( ! shell || ! shell.classList.contains( 'zhp-carousel' ) ) {
                    return;
                }

                syncButtons(
                    track,
                    shell.querySelector( '.zhp-carousel__nav--prev' ),
                    shell.querySelector( '.zhp-carousel__nav--next' )
                );
            } );
        }
    };
} )();
