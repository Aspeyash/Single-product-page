/**
 * ZYMARG Homepage – Newsletter signup handler
 *
 * Vanilla JS. No jQuery. Fires a `zhp:newsletter:subscribe` custom event
 * with { email } on the document so a third-party newsletter plugin can
 * listen and handle the actual subscription.
 *
 * @package ZYMARGHomepage
 * @since   1.5.0
 * @version 1.5.0
 */

( function () {
    'use strict';

    document.addEventListener( 'DOMContentLoaded', function () {
        document.querySelectorAll( '[data-zhp-newsletter-submit]' ).forEach( function ( btn ) {
            var wrap  = btn.closest( '[data-zhp-success]' );
            var input = wrap ? wrap.querySelector( '[data-zhp-newsletter-email]' ) : null;

            // Allow Enter key on the email input to trigger subscribe.
            if ( input ) {
                input.addEventListener( 'keydown', function ( e ) {
                    if ( e.key === 'Enter' ) {
                        e.preventDefault();
                        btn.click();
                    }
                } );
            }

            btn.addEventListener( 'click', function () {
                var wrap  = btn.closest( '[data-zhp-success]' );
                var input = wrap ? wrap.querySelector( '[data-zhp-newsletter-email]' ) : null;
                if ( ! input ) { return; }

                var email = input.value.trim();
                if ( ! email || ! /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test( email ) ) {
                    input.focus();
                    input.setAttribute( 'aria-invalid', 'true' );
                    return;
                }

                input.removeAttribute( 'aria-invalid' );

                // Fire event for newsletter plugin to catch.
                document.dispatchEvent( new CustomEvent( 'zhp:newsletter:subscribe', {
                    bubbles: true,
                    detail:  { email: email }
                } ) );

                // Show success message.
                var successEl = wrap.querySelector( '.zhp-newsletter__success' );
                if ( successEl ) {
                    successEl.textContent = wrap.dataset.zhpSuccess || '';
                    successEl.hidden = false;
                }

                var formEl = wrap.querySelector( '.zhp-newsletter__form' );
                if ( formEl ) { formEl.hidden = true; }
            } );
        } );
    } );
} () );
