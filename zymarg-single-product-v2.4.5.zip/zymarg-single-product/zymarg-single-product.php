<?php
/**
 * Plugin Name:       ZYMARG Single Product
 * Plugin URI:        https://github.com/Aspeyash/zymarg-single-product
 * Description:       Standalone single product page template for ZYMARG Marketplace. Overrides WooCommerce default single product template with a fully custom layout including gallery, swatches, price display, add to cart, buy now, seller card, and reviews (rendered by ZYMARG Reviews Engine). All sections are configurable from the admin panel.
 * Version:           2.4.5
 * Author:            ZYMARG
 * Author URI:        https://github.com/Aspeyash
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       zymarg-single-product
 * Domain Path:       /languages
 * Requires at least: 6.0
 * Requires PHP:      8.0
 * WC requires at least: 8.0
 * WC tested up to:   9.9
 *
 * @package ZymargSingleProduct
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ── Constants ──────────────────────────────────────────────────────────────
define( 'ZYMARG_SP_VERSION',   '2.4.5' );
define( 'ZYMARG_SP_FILE',      __FILE__ );
define( 'ZYMARG_SP_PATH',      plugin_dir_path( __FILE__ ) );
define( 'ZYMARG_SP_URL',       plugin_dir_url( __FILE__ ) );
define( 'ZYMARG_SP_BASENAME',  plugin_basename( __FILE__ ) );
define( 'ZYMARG_SP_ASSETS',    ZYMARG_SP_URL  . 'assets/' );
define( 'ZYMARG_SP_TPL_PATH',  ZYMARG_SP_PATH . 'templates/' );

// ── HPOS compatibility ─────────────────────────────────────────────────────
add_action(
	'before_woocommerce_init',
	function () {
		if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
				'custom_order_tables',
				__FILE__,
				true
			);
		}
	}
);

// ── Bootstrap ──────────────────────────────────────────────────────────────
add_action(
	'plugins_loaded',
	function () {
		load_plugin_textdomain(
			'zymarg-single-product',
			false,
			dirname( ZYMARG_SP_BASENAME ) . '/languages'
		);

		require_once ZYMARG_SP_PATH . 'includes/class-options.php';
		require_once ZYMARG_SP_PATH . 'includes/class-sections.php';
		require_once ZYMARG_SP_PATH . 'includes/class-assets.php';
		require_once ZYMARG_SP_PATH . 'includes/class-template-override.php';
		require_once ZYMARG_SP_PATH . 'includes/class-buy-now.php';
		require_once ZYMARG_SP_PATH . 'includes/class-wishlist-ajax.php';
		require_once ZYMARG_SP_PATH . 'includes/class-breadcrumbs.php';
		require_once ZYMARG_SP_PATH . 'includes/class-seller-card.php';
		require_once ZYMARG_SP_PATH . 'includes/class-price-renderer.php';

		// Native swatches engine (WSE_* → native port).
		require_once ZYMARG_SP_PATH . 'includes/swatches/class-attribute-types.php';
		require_once ZYMARG_SP_PATH . 'includes/swatches/class-term-meta.php';
		require_once ZYMARG_SP_PATH . 'includes/swatches/class-renderer.php';
		require_once ZYMARG_SP_PATH . 'includes/swatches/class-product-video.php';

		require_once ZYMARG_SP_PATH . 'includes/class-admin.php';
		require_once ZYMARG_SP_PATH . 'includes/class-plugin.php';

		ZymargSP\Plugin::instance()->init();
	},
	5
);

// ── Activation / deactivation ──────────────────────────────────────────────
register_activation_hook(
	__FILE__,
	function () {
		require_once ZYMARG_SP_PATH . 'includes/class-options.php';
		ZymargSP\Options::set_defaults();
		flush_rewrite_rules();
	}
);

register_deactivation_hook(
	__FILE__,
	function () {
		flush_rewrite_rules();
	}
);

// ── Reviews Engine soft dependency (v2.0.0) ────────────────────────
// Reviews used to live inside this plugin. They now come from the standalone
// ZYMARG Reviews Engine plugin. The dependency is soft: everything else on the
// single product page keeps working when the engine is missing, we only hide
// the reviews accordion and warn administrators.

function zymarg_sp_reviews_engine_active(): bool {
	return function_exists( 'zymarg_reviews_render' );
}

add_action(
	'admin_notices',
	function () {
		if ( zymarg_sp_reviews_engine_active() || ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		if ( get_user_meta( get_current_user_id(), 'zymarg_sp_engine_notice_off', true ) ) {
			return;
		}
		?>
		<div class="notice notice-warning is-dismissible" id="zymarg-sp-engine-notice">
			<p>
				<strong><?php esc_html_e( 'ZYMARG Single Product', 'zymarg-single-product' ); ?></strong>
				&mdash;
				<?php esc_html_e( 'the Reviews accordion needs the ZYMARG Reviews Engine plugin. Install and activate it to show product reviews again. Your existing reviews and review settings are untouched.', 'zymarg-single-product' ); ?>
			</p>
		</div>
		<script>
		document.addEventListener( 'click', function ( e ) {
			var btn = e.target.closest( '#zymarg-sp-engine-notice .notice-dismiss' );
			if ( ! btn ) { return; }
			var body = new FormData();
			body.append( 'action', 'zymarg_sp_dismiss_engine_notice' );
			body.append( 'nonce', '<?php echo esc_js( wp_create_nonce( 'zymarg_sp_engine_notice' ) ); ?>' );
			fetch( '<?php echo esc_url_raw( admin_url( 'admin-ajax.php' ) ); ?>', { method: 'POST', credentials: 'same-origin', body: body } );
		} );
		</script>
		<?php
	}
);

add_action(
	'wp_ajax_zymarg_sp_dismiss_engine_notice',
	function () {
		check_ajax_referer( 'zymarg_sp_engine_notice', 'nonce' );
		update_user_meta( get_current_user_id(), 'zymarg_sp_engine_notice_off', 1 );
		wp_send_json_success();
	}
);
